use nuclear_performance_engine::core::engine::NuclearPerformanceEngine;

#[test]
fn test_nominal_pwr_initialization() {
    let engine = NuclearPerformanceEngine::new_nominal_pwr_1200mw();
    assert!(engine.current_state.net_electrical_output_mwe > 1100.0);
    assert!(engine.current_state.thermal_efficiency_pct > 30.0);
    assert!(engine.current_state.reactor.thermal_margin_dnbr >= 1.30);
}

#[test]
fn test_reactive_optimiser_safety_enforcement() {
    let engine = NuclearPerformanceEngine::new_nominal_pwr_1200mw();
    let recs = engine.run_reactive_optimisation();
    for rec in recs {
        assert!(rec.risk_score < 4.0, "Optimiser must never recommend high risk action");
        assert!(rec.net_mw_gain > 0.0);
    }
}
