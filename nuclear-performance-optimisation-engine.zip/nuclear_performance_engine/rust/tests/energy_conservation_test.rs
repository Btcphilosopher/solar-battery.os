use nuclear_performance_engine::core::engine::NuclearPerformanceEngine;

#[test]
fn test_first_law_thermodynamics_energy_conservation_invariant() {
    let mut engine = NuclearPerformanceEngine::new_nominal_pwr_1200mw();
    let state = engine.step_simulation(1.0);
    
    let thermal_in = state.reactor.thermal_output_mw;
    let net_elec = state.net_electrical_output_mwe;
    let aux_load = state.electrical.auxiliary_load_mwe;
    let tx_loss = state.electrical.main_transformer_losses_mw;
    let mech_loss = state.turbine.mechanical_losses_mw;
    let gen_losses = state.generator.stator_copper_losses_mw + state.generator.rotor_excitation_losses_mw + state.generator.core_iron_losses_mw;
    let thermal_pipe_loss = state.thermal.piping_thermal_losses_mw;
    let heat_rejected = state.cooling.rejected_heat_mw;

    let total_accounted = net_elec + aux_load + tx_loss + mech_loss + gen_losses + thermal_pipe_loss + heat_rejected;
    let energy_delta = (thermal_in - total_accounted).abs();

    assert!(
        energy_delta < 0.1,
        "Energy Conservation Failure! Unaccounted MW: {:.4} MW (Thermal in: {:.2}, Total accounted: {:.2})",
        energy_delta, thermal_in, total_accounted
    );
}
