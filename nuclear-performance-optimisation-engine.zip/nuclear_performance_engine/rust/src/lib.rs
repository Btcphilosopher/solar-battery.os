//! Nuclear Performance Optimisation Engine Core Library
//! Strict SI Units: Watts (W/MW), Pascals (Pa/MPa), Kelvin/Celsius (K/°C), kg/s, Joules (J/MJ).
//! 
//! Architecture:
//! - core: Plant state tracking, timestep execution, telemetry events
//! - reactor: Core thermal output, primary coolant loop, reactor operating envelope
//! - thermal: Secondary steam cycle heat balance, enthalpy, thermal losses
//! - turbine: Steam expansion, stage efficiency, degradation models
//! - generator: Mechanical-to-electrical conversion, rotor/stator losses
//! - cooling: Condenser performance, cooling tower heat rejection
//! - electrical: Transformers, auxiliary loads, grid connection
//! - optimisation: Safe constrained optimiser and objective functions
//! - telemetry: Sensor validation, stream ingestion, signal filtering
//! - api: C/JSON/R interop layer

pub mod core;
pub mod reactor;
pub mod thermal;
pub mod turbine;
pub mod generator;
pub mod cooling;
pub mod electrical;
pub mod optimisation;
pub mod telemetry;
pub mod api;

pub use core::engine::NuclearPerformanceEngine;
pub use core::plant_state::PlantState;
pub use reactor::operating_envelope::OperatingEnvelope;
pub use optimisation::optimiser::ReactiveOptimiser;
