pub fn optimize_auxiliary_pumping_schedule(
    required_cooling_mw: f64,
    ambient_temp_c: f64,
) -> f64 {
    // Variable speed drive optimization for secondary circulating water pumps
    if ambient_temp_c < 15.0 {
        22.0 // Low ambient allows reduced pump speed
    } else if ambient_temp_c < 25.0 {
        28.0 // Standard pump duty
    } else {
        34.0 // High ambient requires maximum circulating flow
    }
}
