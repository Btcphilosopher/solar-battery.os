pub use crate::core::plant_state::ElectricalStateData;

impl ElectricalStateData {
    pub fn total_house_consumption_mwe(&self) -> f64 {
        self.primary_pump_power_mwe + self.secondary_pump_power_mwe + self.cooling_fan_pump_power_mwe + self.station_service_mwe
    }
}
