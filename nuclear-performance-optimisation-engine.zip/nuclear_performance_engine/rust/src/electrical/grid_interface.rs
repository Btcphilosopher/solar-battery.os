pub fn check_grid_frequency_stability(frequency_hz: f64) -> bool {
    frequency_hz >= 49.5 && frequency_hz <= 50.5
}
