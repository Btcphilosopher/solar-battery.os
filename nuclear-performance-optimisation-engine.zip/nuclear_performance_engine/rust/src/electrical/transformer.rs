pub fn calculate_transformer_loss_mw(gross_mwe: f64, fixed_loss_mw: f64, impedance_pct: f64) -> f64 {
    let load_ratio = gross_mwe / 1300.0;
    fixed_loss_mw + (load_ratio * load_ratio) * (impedance_pct / 100.0) * 12.0
}
