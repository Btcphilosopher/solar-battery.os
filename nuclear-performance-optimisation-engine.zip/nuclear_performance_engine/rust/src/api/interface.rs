use crate::core::engine::NuclearPerformanceEngine;

pub fn export_plant_state_json(engine: &NuclearPerformanceEngine) -> String {
    serde_json::to_string_pretty(&engine.current_state).unwrap_or_else(|_| "{}".to_string())
}

pub fn export_optimisation_recommendations_json(engine: &NuclearPerformanceEngine) -> String {
    let recs = engine.run_reactive_optimisation();
    serde_json::to_string_pretty(&recs).unwrap_or_else(|_| "[]".to_string())
}
