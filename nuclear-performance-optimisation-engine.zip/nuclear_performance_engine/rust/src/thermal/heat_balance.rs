pub fn compute_heat_balance_mw(
    thermal_input_mw: f64,
    piping_losses_mw: f64,
    turbine_gross_mw: f64,
    rejected_condenser_mw: f64,
) -> f64 {
    thermal_input_mw - (piping_losses_mw + turbine_gross_mw + rejected_condenser_mw)
}
