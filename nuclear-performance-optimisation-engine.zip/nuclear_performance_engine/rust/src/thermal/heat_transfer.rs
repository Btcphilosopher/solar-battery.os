pub fn steam_generator_heat_transfer_mw(
    u_value_w_m2k: f64,
    area_m2: f64,
    lmtd_k: f64,
) -> f64 {
    (u_value_w_m2k * area_m2 * lmtd_k) / 1_000_000.0
}
