pub fn estimate_piping_thermal_loss_mw(pipe_surface_area_m2: f64, insulation_efficiency: f64, ambient_temp_c: f64, steam_temp_c: f64) -> f64 {
    let delta_t = steam_temp_c - ambient_temp_c;
    let h_conv = 15.0; // W/m2-K
    let loss_w = pipe_surface_area_m2 * h_conv * delta_t * (1.0 - insulation_efficiency);
    loss_w / 1_000_000.0
}
