pub fn steam_mass_flow_kg_s(heat_duty_mw: f64, h_steam_kj_kg: f64, h_feed_kj_kg: f64) -> f64 {
    let delta_h = h_steam_kj_kg - h_feed_kj_kg;
    if delta_h <= 0.0 { return 0.0; }
    (heat_duty_mw * 1000.0) / delta_h
}
