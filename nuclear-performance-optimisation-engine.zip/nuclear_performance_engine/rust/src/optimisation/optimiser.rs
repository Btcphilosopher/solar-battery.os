use crate::core::plant_state::PlantState;
use crate::reactor::operating_envelope::OperatingEnvelope;
use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OptimiserRecommendation {
    pub id: String,
    pub title: String,
    pub subsystem: String,
    pub net_mw_gain: f64,
    pub efficiency_gain_pct: f64,
    pub risk_score: f64, // 0.0 = completely safe, 10.0 = trips safety limit
    pub action_description: String,
    pub parameter_modifications: Vec<(String, f64, f64)>, // (Parameter Name, Current, Proposed)
    pub payback_time_days: f64,
}

#[derive(Default)]
pub struct ReactiveOptimiser;

impl ReactiveOptimiser {
    pub fn evaluate(&self, state: &PlantState, envelope: &OperatingEnvelope) -> Vec<OptimiserRecommendation> {
        let mut recommendations = Vec::new();

        // 1. Condenser Vacuum & Cleanliness Optimisation
        if state.cooling.condenser_pressure_kpa > 3.8 {
            let pressure_drop = state.cooling.condenser_pressure_kpa - 3.5;
            let mw_recovery = pressure_drop * 7.8;
            recommendations.push(OptimiserRecommendation {
                id: "REC-COND-01".into(),
                title: "Optimize Condenser Vacuum via Circulating Pump VFD Adjustment".into(),
                subsystem: "Cooling / Condenser".into(),
                net_mw_gain: mw_recovery,
                efficiency_gain_pct: (mw_recovery / state.reactor.thermal_output_mw) * 100.0,
                risk_score: 1.2,
                action_description: "Increase secondary circulating water flow rate by 4.2 m³/s to reduce backpressure from 4.5 kPa to 3.6 kPa.".into(),
                parameter_modifications: vec![
                    ("condenser_pressure_kpa".into(), state.cooling.condenser_pressure_kpa, 3.6),
                    ("cooling_water_flow_m3_s".into(), state.cooling.cooling_water_flow_m3_s, 49.2),
                ],
                payback_time_days: 0.1,
            });
        }

        // 2. Feedwater Heating Optimization
        if state.thermal.feedwater_temp_c < 225.0 {
            let mw_gain = 5.2;
            recommendations.push(OptimiserRecommendation {
                id: "REC-THERM-02".into(),
                title: "Optimize High-Pressure Feedwater Heater Extraction Valve Position".into(),
                subsystem: "Thermal / Secondary Loop".into(),
                net_mw_gain: mw_gain,
                efficiency_gain_pct: (mw_gain / state.reactor.thermal_output_mw) * 100.0,
                risk_score: 1.8,
                action_description: "Trim extraction steam valve position on HP Heater 6 to raise feedwater return temperature to 224.5 °C.".into(),
                parameter_modifications: vec![
                    ("feedwater_temp_c".into(), state.thermal.feedwater_temp_c, 224.5),
                ],
                payback_time_days: 1.5,
            });
        }

        // 3. Auxiliary Power Optimization
        if state.electrical.auxiliary_load_mwe > 55.0 {
            let mw_saved = 3.8;
            recommendations.push(OptimiserRecommendation {
                id: "REC-AUX-03".into(),
                title: "De-energize Standby Auxiliary Cooling Fans during Low Ambient Period".into(),
                subsystem: "Electrical / Auxiliary Load".into(),
                net_mw_gain: mw_saved,
                efficiency_gain_pct: (mw_saved / state.reactor.thermal_output_mw) * 100.0,
                risk_score: 0.8,
                action_description: "Switch 2 secondary cooling tower fans to auto-standby based on low current ambient temperature.".into(),
                parameter_modifications: vec![
                    ("auxiliary_load_mwe".into(), state.electrical.auxiliary_load_mwe, state.electrical.auxiliary_load_mwe - mw_saved),
                ],
                payback_time_days: 0.0,
            });
        }

        // Verify safety constraints
        recommendations.retain(|rec| {
            // Guarantee risk score is low and does not violate operating envelope
            rec.risk_score < 4.0 && envelope.is_within_safety_limits(
                state.reactor.thermal_output_mw,
                state.reactor.primary_coolant_pressure_mpa,
                state.reactor.primary_coolant_temp_out_c,
                state.reactor.thermal_margin_dnbr,
                state.cooling.condenser_pressure_kpa,
            )
        });

        recommendations.sort_by(|a, b| b.net_mw_gain.partial_cmp(&a.net_mw_gain).unwrap());
        recommendations
    }
}
