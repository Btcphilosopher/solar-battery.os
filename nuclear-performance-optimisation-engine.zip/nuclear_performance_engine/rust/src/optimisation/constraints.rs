pub fn validate_hard_safety_constraints(
    dnbr: f64,
    primary_pressure_mpa: f64,
    primary_temp_out_c: f64,
) -> Result<(), &'static str> {
    if dnbr < 1.30 {
        return Err("VIOLATION: Departure from Nucleate Boiling Ratio below safety limit (1.30)");
    }
    if primary_pressure_mpa > 16.8 {
        return Err("VIOLATION: Primary system pressure exceeds overpressure trip limit (16.8 MPa)");
    }
    if primary_temp_out_c > 335.0 {
        return Err("VIOLATION: Core outlet coolant temperature exceeds maximum trip limit (335.0 °C)");
    }
    Ok(())
}
