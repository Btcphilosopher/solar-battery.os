pub fn turbine_reheating_efficiency_gain_mwe(reheat_temp_c: f64, baseline_temp_c: f64) -> f64 {
    let delta_t = (reheat_temp_c - baseline_temp_c).max(0.0);
    delta_t * 0.18
}
