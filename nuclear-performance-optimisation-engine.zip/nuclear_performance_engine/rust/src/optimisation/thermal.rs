pub fn thermal_optimization_potential_mw(current_steam_gen_efficiency: f64, target_efficiency: f64, thermal_mw: f64) -> f64 {
    let delta = (target_efficiency - current_steam_gen_efficiency).max(0.0) / 100.0;
    thermal_mw * delta
}
