pub fn calculate_performance_score(
    net_output_mwe: f64,
    thermal_efficiency_pct: f64,
    availability_factor: f64,
) -> f64 {
    net_output_mwe * thermal_efficiency_pct * availability_factor
}
