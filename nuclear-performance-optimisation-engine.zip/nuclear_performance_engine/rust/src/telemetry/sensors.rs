use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SensorReading {
    pub sensor_id: String,
    pub parameter_name: String,
    pub value: f64,
    pub unit: String,
    pub quality_flag: String, // "GOOD", "SUSPECT", "BAD", "OUT_OF_RANGE"
    pub timestamp_epoch_ms: u64,
}
