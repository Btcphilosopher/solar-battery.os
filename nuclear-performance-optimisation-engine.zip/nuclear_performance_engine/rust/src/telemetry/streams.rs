use crate::telemetry::sensors::SensorReading;

pub struct TelemetryStreamIngestor {
    pub total_processed: u64,
    pub bad_readings_rejected: u64,
}

impl TelemetryStreamIngestor {
    pub fn new() -> Self {
        Self {
            total_processed: 0,
            bad_readings_rejected: 0,
        }
    }

    pub fn ingest(&mut self, reading: SensorReading) -> Option<SensorReading> {
        self.total_processed += 1;
        if reading.quality_flag == "BAD" || reading.value.is_nan() || reading.value.is_infinite() {
            self.bad_readings_rejected += 1;
            None
        } else {
            Some(reading)
        }
    }
}
