pub fn validate_sensor_physical_range(sensor_type: &str, value: f64) -> bool {
    match sensor_type {
        "primary_coolant_temp" => value >= 10.0 && value <= 400.0,
        "primary_pressure" => value >= 0.1 && value <= 25.0,
        "steam_pressure" => value >= 0.1 && value <= 15.0,
        "neutron_flux" => value >= 0.0 && value <= 120.0,
        "condenser_pressure" => value >= 0.5 && value <= 50.0,
        _ => true,
    }
}
