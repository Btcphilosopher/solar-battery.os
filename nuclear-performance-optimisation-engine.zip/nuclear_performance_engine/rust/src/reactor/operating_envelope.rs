use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SafetyLimit {
    pub min_allowed: f64,
    pub max_allowed: f64,
    pub trip_threshold: f64,
    pub unit: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OperatingEnvelope {
    pub thermal_power_mwth: SafetyLimit,
    pub primary_pressure_mpa: SafetyLimit,
    pub primary_temp_out_c: SafetyLimit,
    pub core_delta_t_c: SafetyLimit,
    pub dnbr_margin: SafetyLimit,
    pub steam_pressure_mpa: SafetyLimit,
    pub condenser_pressure_kpa: SafetyLimit,
    pub turbine_vibration_mm_s: SafetyLimit,
}

impl OperatingEnvelope {
    pub fn pwr_standard_limits() -> Self {
        Self {
            thermal_power_mwth: SafetyLimit { min_allowed: 0.0, max_allowed: 3411.0, trip_threshold: 3580.0, unit: "MWth".into() },
            primary_pressure_mpa: SafetyLimit { min_allowed: 14.0, max_allowed: 16.0, trip_threshold: 16.8, unit: "MPa".into() },
            primary_temp_out_c: SafetyLimit { min_allowed: 280.0, max_allowed: 330.0, trip_threshold: 335.0, unit: "°C".into() },
            core_delta_t_c: SafetyLimit { min_allowed: 10.0, max_allowed: 38.0, trip_threshold: 42.0, unit: "°C".into() },
            dnbr_margin: SafetyLimit { min_allowed: 1.30, max_allowed: 3.50, trip_threshold: 1.30, unit: "ratio".into() },
            steam_pressure_mpa: SafetyLimit { min_allowed: 5.5, max_allowed: 7.2, trip_threshold: 7.8, unit: "MPa".into() },
            condenser_pressure_kpa: SafetyLimit { min_allowed: 2.5, max_allowed: 8.0, trip_threshold: 12.0, unit: "kPa".into() },
            turbine_vibration_mm_s: SafetyLimit { min_allowed: 0.0, max_allowed: 4.5, trip_threshold: 7.1, unit: "mm/s".into() },
        }
    }

    pub fn is_within_safety_limits(&self, thermal_mw: f64, press_mpa: f64, temp_out: f64, dnbr: f64, cond_kpa: f64) -> bool {
        thermal_mw <= self.thermal_power_mwth.trip_threshold
            && press_mpa >= self.primary_pressure_mpa.min_allowed
            && press_mpa <= self.primary_pressure_mpa.trip_threshold
            && temp_out <= self.primary_temp_out_c.trip_threshold
            && dnbr >= self.dnbr_margin.min_allowed
            && cond_kpa <= self.condenser_pressure_kpa.trip_threshold
    }
}
