pub fn calculate_coolant_density_kg_m3(temp_c: f64, pressure_mpa: f64) -> f64 {
    // IAPWS-97 simplified correlation for light water pressurized at 15.5 MPa
    750.0 - 1.2 * (temp_c - 300.0) + 0.05 * (pressure_mpa - 15.0)
}
