pub use crate::core::plant_state::ReactorStateData;

impl ReactorStateData {
    pub fn is_nominal(&self) -> bool {
        self.thermal_margin_dnbr >= 1.50 && self.primary_coolant_pressure_mpa >= 15.0
    }
}
