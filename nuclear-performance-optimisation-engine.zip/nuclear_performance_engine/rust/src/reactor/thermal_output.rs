pub fn calculate_core_thermal_output_mw(
    coolant_flow_kg_s: f64,
    specific_heat_kj_kg_k: f64,
    temp_out_c: f64,
    temp_in_c: f64,
) -> f64 {
    let delta_t = temp_out_c - temp_in_c;
    (coolant_flow_kg_s * specific_heat_kj_kg_k * delta_t) / 1000.0
}
