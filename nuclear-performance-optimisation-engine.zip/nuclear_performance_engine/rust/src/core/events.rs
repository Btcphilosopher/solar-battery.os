use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum PlantEventType {
    Info,
    Warning,
    SafetyEnvelopeApproach,
    OptimisationOpportunity,
    SensorAnomaly,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PlantEvent {
    pub timestamp_utc: String,
    pub event_type: PlantEventType,
    pub subsystem: String,
    pub message: String,
    pub parameter_name: String,
    pub current_value: f64,
    pub limit_value: f64,
}
