use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ReactorStateData {
    pub thermal_output_mw: f64,
    pub neutron_flux_pct: f64,
    pub control_rod_position_pct: f64,
    pub primary_coolant_temp_in_c: f64,
    pub primary_coolant_temp_out_c: f64,
    pub primary_coolant_pressure_mpa: f64,
    pub primary_coolant_flow_kg_s: f64,
    pub thermal_margin_dnbr: f64, // Departure from Nucleate Boiling Ratio (> 1.30 safety limit)
    pub core_delta_t_c: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ThermalStateData {
    pub secondary_steam_pressure_mpa: f64,
    pub secondary_steam_temp_c: f64,
    pub secondary_steam_flow_kg_s: f64,
    pub steam_enthalpy_kj_kg: f64,
    pub feedwater_temp_c: f64,
    pub piping_thermal_losses_mw: f64,
    pub steam_generator_heat_duty_mw: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TurbineStateData {
    pub hp_turbine_power_mw: f64,
    pub lp_turbine_power_mw: f64,
    pub turbine_speed_rpm: f64,
    pub isentropic_efficiency_pct: f64,
    pub mechanical_losses_mw: f64,
    pub exhaust_steam_quality: f64,
    pub blade_degradation_factor: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GeneratorStateData {
    pub gross_output_mwe: f64,
    pub electrical_efficiency_pct: f64,
    pub power_factor: f64,
    pub stator_copper_losses_mw: f64,
    pub rotor_excitation_losses_mw: f64,
    pub core_iron_losses_mw: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CoolingStateData {
    pub condenser_pressure_kpa: f64,
    pub condenser_temp_c: f64,
    pub cooling_water_flow_m3_s: f64,
    pub cooling_water_inlet_temp_c: f64,
    pub cooling_water_outlet_temp_c: f64,
    pub rejected_heat_mw: f64,
    pub condenser_cleanliness_factor: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ElectricalStateData {
    pub main_transformer_losses_mw: f64,
    pub auxiliary_load_mwe: f64,
    pub primary_pump_power_mwe: f64,
    pub secondary_pump_power_mwe: f64,
    pub cooling_fan_pump_power_mwe: f64,
    pub station_service_mwe: f64,
    pub net_grid_output_mwe: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PlantState {
    pub timestamp_utc: String,
    pub reactor: ReactorStateData,
    pub thermal: ThermalStateData,
    pub turbine: TurbineStateData,
    pub generator: GeneratorStateData,
    pub cooling: CoolingStateData,
    pub electrical: ElectricalStateData,
    pub net_electrical_output_mwe: f64,
    pub thermal_efficiency_pct: f64,
    pub availability_factor: f64,
    pub energy_balance_delta_mw: f64, // Invariant: Thermal Input - (Net + Aux + Losses + Rejection)
}
