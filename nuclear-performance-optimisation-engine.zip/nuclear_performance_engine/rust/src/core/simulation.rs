use crate::core::engine::NuclearPerformanceEngine;
use crate::core::plant_state::PlantState;
use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SimulationConfig {
    pub total_duration_sec: f64,
    pub timestep_sec: f64,
    pub scenario_name: String,
    pub ambient_temp_delta_c: f64,
    pub condenser_cleanliness_degradation: f64,
    pub turbine_degradation_factor: f64,
}

pub struct SimulationRunner {
    pub engine: NuclearPerformanceEngine,
    pub config: SimulationConfig,
    pub history: Vec<PlantState>,
}

impl SimulationRunner {
    pub fn new(config: SimulationConfig) -> Self {
        let engine = NuclearPerformanceEngine::new_nominal_pwr_1200mw();
        Self {
            engine,
            config,
            history: Vec::new(),
        }
    }

    pub fn run(&mut self) -> &Vec<PlantState> {
        let steps = (self.config.total_duration_sec / self.config.timestep_sec) as usize;
        for _ in 0..steps {
            // Apply transient disturbances
            self.engine.current_state.cooling.cooling_water_inlet_temp_c += self.config.ambient_temp_delta_c / steps as f64;
            self.engine.current_state.cooling.condenser_cleanliness_factor -= self.config.condenser_cleanliness_degradation / steps as f64;
            self.engine.current_state.turbine.blade_degradation_factor -= self.config.turbine_degradation_factor / steps as f64;

            let state = self.engine.step_simulation(self.config.timestep_sec);
            self.history.push(state);
        }
        &self.history
    }
}
