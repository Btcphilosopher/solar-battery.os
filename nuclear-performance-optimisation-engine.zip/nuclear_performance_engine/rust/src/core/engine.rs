use crate::core::plant_state::*;
use crate::reactor::operating_envelope::OperatingEnvelope;
use crate::optimisation::optimiser::{ReactiveOptimiser, OptimiserRecommendation};
use chrono::Utc;

pub struct NuclearPerformanceEngine {
    pub current_state: PlantState,
    pub envelope: OperatingEnvelope,
    pub optimiser: ReactiveOptimiser,
    pub simulation_time_sec: f64,
}

impl NuclearPerformanceEngine {
    pub fn new_nominal_pwr_1200mw() -> Self {
        let envelope = OperatingEnvelope::pwr_standard_limits();
        let optimiser = ReactiveOptimiser::default();
        
        let reactor = ReactorStateData {
            thermal_output_mw: 3411.0,
            neutron_flux_pct: 100.0,
            control_rod_position_pct: 88.5,
            primary_coolant_temp_in_c: 292.0,
            primary_coolant_temp_out_c: 326.0,
            primary_coolant_pressure_mpa: 15.5,
            primary_coolant_flow_kg_s: 18200.0,
            thermal_margin_dnbr: 1.85,
            core_delta_t_c: 34.0,
        };

        let thermal = ThermalStateData {
            secondary_steam_pressure_mpa: 6.8,
            secondary_steam_temp_c: 284.0,
            secondary_steam_flow_kg_s: 1910.0,
            steam_enthalpy_kj_kg: 2772.0,
            feedwater_temp_c: 220.0,
            piping_thermal_losses_mw: 18.5,
            steam_generator_heat_duty_mw: 3392.5,
        };

        let turbine = TurbineStateData {
            hp_turbine_power_mw: 420.0,
            lp_turbine_power_mw: 820.0,
            turbine_speed_rpm: 1500.0,
            isentropic_efficiency_pct: 88.2,
            mechanical_losses_mw: 12.0,
            exhaust_steam_quality: 0.88,
            blade_degradation_factor: 0.985,
        };

        let generator = GeneratorStateData {
            gross_output_mwe: 1240.0,
            electrical_efficiency_pct: 98.6,
            power_factor: 0.92,
            stator_copper_losses_mw: 8.5,
            rotor_excitation_losses_mw: 4.2,
            core_iron_losses_mw: 4.8,
        };

        let cooling = CoolingStateData {
            condenser_pressure_kpa: 4.5,
            condenser_temp_c: 31.2,
            cooling_water_flow_m3_s: 45.0,
            cooling_water_inlet_temp_c: 18.0,
            cooling_water_outlet_temp_c: 28.5,
            rejected_heat_mw: 2132.5,
            condenser_cleanliness_factor: 0.89,
        };

        let electrical = ElectricalStateData {
            main_transformer_losses_mw: 8.0,
            auxiliary_load_mwe: 61.0,
            primary_pump_power_mwe: 28.0,
            secondary_pump_power_mwe: 16.0,
            cooling_fan_pump_power_mwe: 12.0,
            station_service_mwe: 5.0,
            net_grid_output_mwe: 1171.0,
        };

        let net = generator.gross_output_mwe - electrical.auxiliary_load_mwe - electrical.main_transformer_losses_mw;
        let efficiency = (net / reactor.thermal_output_mw) * 100.0;
        
        // Energy balance check
        let total_out = net + electrical.auxiliary_load_mwe + electrical.main_transformer_losses_mw 
            + turbine.mechanical_losses_mw + generator.stator_copper_losses_mw 
            + generator.rotor_excitation_losses_mw + generator.core_iron_losses_mw 
            + thermal.piping_thermal_losses_mw + cooling.rejected_heat_mw;
        let energy_balance_delta = reactor.thermal_output_mw - total_out;

        let state = PlantState {
            timestamp_utc: Utc::now().to_rfc3339(),
            reactor,
            thermal,
            turbine,
            generator,
            cooling,
            electrical,
            net_electrical_output_mwe: net,
            thermal_efficiency_pct: efficiency,
            availability_factor: 0.98,
            energy_balance_delta_mw: energy_balance_delta,
        };

        Self {
            current_state: state,
            envelope,
            optimiser,
            simulation_time_sec: 0.0,
        }
    }

    pub fn step_simulation(&mut self, dt_sec: f64) -> PlantState {
        self.simulation_time_sec += dt_sec;
        // Deterministic cycle physics recalculation
        self.recalculate_physics();
        self.current_state.clone()
    }

    pub fn run_reactive_optimisation(&self) -> Vec<OptimiserRecommendation> {
        self.optimiser.evaluate(&self.current_state, &self.envelope)
    }

    fn recalculate_physics(&mut self) {
        let r = &mut self.current_state.reactor;
        let t = &mut self.current_state.thermal;
        let tur = &mut self.current_state.turbine;
        let g = &mut self.current_state.generator;
        let c = &mut self.current_state.cooling;
        let e = &mut self.current_state.electrical;

        // Core Delta T
        r.core_delta_t_c = r.primary_coolant_temp_out_c - r.primary_coolant_temp_in_c;
        // Thermal output Q = m * Cp * dT
        let cp_water = 5.5; // kJ/(kg*K) average pressurized water
        r.thermal_output_mw = (r.primary_coolant_flow_kg_s * cp_water * r.core_delta_t_c) / 1000.0;

        t.steam_generator_heat_duty_mw = r.thermal_output_mw - t.piping_thermal_losses_mw;

        // Condenser pressure influence on turbine work
        let vacuum_penalty_mw = (c.condenser_pressure_kpa - 3.5).max(0.0) * 8.5;
        tur.hp_turbine_power_mw = t.steam_generator_heat_duty_mw * 0.125 * tur.blade_degradation_factor;
        tur.lp_turbine_power_mw = (t.steam_generator_heat_duty_mw * 0.245 - vacuum_penalty_mw) * tur.blade_degradation_factor;

        let total_shaft_power = tur.hp_turbine_power_mw + tur.lp_turbine_power_mw - tur.mechanical_losses_mw;
        g.gross_output_mwe = total_shaft_power * (g.electrical_efficiency_pct / 100.0);

        // Auxiliary load summation
        e.auxiliary_load_mwe = e.primary_pump_power_mwe + e.secondary_pump_power_mwe 
            + e.cooling_fan_pump_power_mwe + e.station_service_mwe;

        e.net_grid_output_mwe = g.gross_output_mwe - e.auxiliary_load_mwe - e.main_transformer_losses_mw;
        self.current_state.net_electrical_output_mwe = e.net_grid_output_mwe;
        self.current_state.thermal_efficiency_pct = (e.net_grid_output_mwe / r.thermal_output_mw) * 100.0;

        // Heat rejection = Thermal input - Gross Generation - Piping losses
        c.rejected_heat_mw = r.thermal_output_mw - g.gross_output_mwe - t.piping_thermal_losses_mw;

        let total_accounted = e.net_grid_output_mwe + e.auxiliary_load_mwe + e.main_transformer_losses_mw
            + tur.mechanical_losses_mw + g.stator_copper_losses_mw + g.rotor_excitation_losses_mw 
            + g.core_iron_losses_mw + t.piping_thermal_losses_mw + c.rejected_heat_mw;
        self.current_state.energy_balance_delta_mw = (r.thermal_output_mw - total_accounted).abs();
    }
}
