use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TimestepMetadata {
    pub step_index: u64,
    pub dt_seconds: f64,
    pub elapsed_time_seconds: f64,
    pub solver_iterations: u32,
    pub residual_error: f64,
}

impl TimestepMetadata {
    pub fn new(index: u64, dt: f64) -> Self {
        Self {
            step_index: index,
            dt_seconds: dt,
            elapsed_time_seconds: index as f64 * dt,
            solver_iterations: 1,
            residual_error: 1e-8,
        }
    }
}
