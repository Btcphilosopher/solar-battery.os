use nuclear_performance_engine::core::engine::NuclearPerformanceEngine;
use nuclear_performance_engine::core::plant_state::PlantState;

fn main() {
    println!("============================================================");
    println!("  NUCLEAR POWER STATION PERFORMANCE OPTIMISATION ENGINE    ");
    println!("  Production-Grade Physics & Reactive Decision Engine      ");
    println!("============================================================");

    let mut engine = NuclearPerformanceEngine::new_nominal_pwr_1200mw();
    println!("[INIT] Loaded baseline plant model: PWR-1200 (1,200 MW Net Nom.)");
    
    // Execute baseline timestep
    let state: PlantState = engine.step_simulation(1.0);
    println!("[STATE] Core Thermal Output: {:.2} MWth", state.reactor.thermal_output_mw);
    println!("[STATE] Gross Generator Power: {:.2} MWe", state.generator.gross_output_mwe);
    println!("[STATE] Auxiliary Load: {:.2} MWe", state.electrical.auxiliary_load_mwe);
    println!("[STATE] Net Electrical Output: {:.2} MWe", state.net_electrical_output_mwe);
    println!("[STATE] Thermal Efficiency: {:.2}%", state.thermal_efficiency_pct);
    println!("[STATE] Energy Conservation Invariant Delta: {:.4} MW", state.energy_balance_delta_mw);

    // Run optimisation search within hard safety constraints
    println!("\n[OPTIMISER] Evaluating safe operating space...");
    let recs = engine.run_reactive_optimisation();
    for (i, rec) in recs.iter().enumerate() {
        println!("  #{}: [{}] Gain: +{:.2} MWe | Efficiency: +{:.3}% | Risk Score: {:.1}/10", 
            i + 1, rec.title, rec.net_mw_gain, rec.efficiency_gain_pct, rec.risk_score);
        println!("      Action: {}", rec.action_description);
    }
}
