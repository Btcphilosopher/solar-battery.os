pub fn actual_turbine_efficiency(
    baseline_efficiency_pct: f64,
    condenser_backpressure_kpa: f64,
    blade_degradation_factor: f64,
) -> f64 {
    let pressure_penalty = (condenser_backpressure_kpa - 3.5).max(0.0) * 0.45; // % loss per kPa backpressure rise
    (baseline_efficiency_pct - pressure_penalty) * blade_degradation_factor
}
