pub fn evaluate_blade_erosion_loss_mw(
    operating_hours: f64,
    wetness_fraction: f64,
    nominal_power_mw: f64,
) -> f64 {
    let erosion_rate = 1e-6 * (wetness_fraction.max(0.10) - 0.08);
    let cumulative_degradation = (operating_hours * erosion_rate).min(0.08);
    nominal_power_mw * cumulative_degradation
}
