pub use crate::core::plant_state::TurbineStateData;

impl TurbineStateData {
    pub fn total_power_mw(&self) -> f64 {
        self.hp_turbine_power_mw + self.lp_turbine_power_mw - self.mechanical_losses_mw
    }
}
