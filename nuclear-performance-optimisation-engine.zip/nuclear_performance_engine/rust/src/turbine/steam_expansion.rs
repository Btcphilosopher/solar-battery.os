pub fn calculate_isentropic_work_mw(
    steam_flow_kg_s: f64,
    h_in_kj_kg: f64,
    h_out_isentropic_kj_kg: f64,
) -> f64 {
    let dh = h_in_kj_kg - h_out_isentropic_kj_kg;
    (steam_flow_kg_s * dh) / 1000.0
}
