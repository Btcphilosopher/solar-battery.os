pub use crate::core::plant_state::GeneratorStateData;

impl GeneratorStateData {
    pub fn net_shaft_conversion_mwe(&self, shaft_mechanical_mw: f64) -> f64 {
        shaft_mechanical_mw * (self.electrical_efficiency_pct / 100.0)
    }
}
