pub fn generator_loss_breakdown_mw(
    gross_output_mwe: f64,
    stator_cu_mw: f64,
    rotor_ex_mw: f64,
    core_fe_mw: f64,
) -> f64 {
    let total_loss = stator_cu_mw + rotor_ex_mw + core_fe_mw;
    let input_mech = gross_output_mwe + total_loss;
    if input_mech <= 0.0 { return 0.0; }
    (gross_output_mwe / input_mech) * 100.0
}
