pub fn calculate_apparent_power_mva(active_power_mw: f64, power_factor: f64) -> f64 {
    if power_factor <= 0.0 { return 0.0; }
    active_power_mw / power_factor
}
