pub fn compute_cooling_pumping_power_mwe(
    flow_m3_s: f64,
    head_m: f64,
    pump_efficiency: f64,
) -> f64 {
    let rho = 1000.0; // kg/m3
    let g = 9.81; // m/s2
    let hydraulic_power_w = flow_m3_s * rho * g * head_m;
    (hydraulic_power_w / pump_efficiency) / 1_000_000.0
}
