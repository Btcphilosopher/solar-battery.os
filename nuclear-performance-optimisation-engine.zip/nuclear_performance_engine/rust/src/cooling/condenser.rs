pub use crate::core::plant_state::CoolingStateData;

impl CoolingStateData {
    pub fn cooling_water_delta_t_c(&self) -> f64 {
        self.cooling_water_outlet_temp_c - self.cooling_water_inlet_temp_c
    }
}
