pub fn condenser_heat_rejection_capacity_mw(
    u_overall_w_m2k: f64,
    area_m2: f64,
    condenser_temp_c: f64,
    water_in_c: f64,
    water_out_c: f64,
) -> f64 {
    let delta_t1 = condenser_temp_c - water_in_c;
    let delta_t2 = condenser_temp_c - water_out_c;
    if delta_t1 <= 0.0 || delta_t2 <= 0.0 || (delta_t1 - delta_t2).abs() < 1e-4 {
        return 0.0;
    }
    let lmtd = (delta_t1 - delta_t2) / (delta_t1 / delta_t2).ln();
    (u_overall_w_m2k * area_m2 * lmtd) / 1_000_000.0
}
