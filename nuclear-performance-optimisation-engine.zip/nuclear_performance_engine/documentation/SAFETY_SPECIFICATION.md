# Nuclear Safety & Operating Envelope Specification

## Safety Hierarchy Principles
1. **SAFETY ENVELOPE (Hard Non-Negotiable Limits)**
   - Reactor Protection System (RPS) trip points.
   - Departure from Nucleate Boiling Ratio (DNBR) $\ge 1.30$.
   - Primary overpressure relief limit $16.8$ MPa.
   - Core outlet maximum temperature $335.0$ °C.

2. **OPERATING ENVELOPE (Normal Operational Constraints)**
   - Nominal steady state parameters.
   - Thermal power $\le 3,411.0$ MWth ($100\%$ licensed rating).
   - Condenser vacuum limit $8.0$ kPa.

3. **OPTIMISATION ENGINE (Decision Support)**
   - Operates strictly within the Operating Envelope.
   - Read-only recommendations; zero direct actuator write permissions.
   - Risk scoring algorithm evaluates proximity to safety margins before issuing recommendations.
