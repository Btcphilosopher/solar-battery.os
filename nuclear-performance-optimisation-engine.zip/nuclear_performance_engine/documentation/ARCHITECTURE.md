# Nuclear Performance Engine: Software Architecture Specification

## 1. High-Level Architecture
The Nuclear Performance Engine is built around a two-language architecture:
- **Rust Core**: Real-time deterministic state evaluation, thermal-hydraulic energy conservation solvers, safety envelope verification, and reactive optimization loops.
- **R Analytics**: Statistical regression, Monte Carlo uncertainty propagation, degradation trend forecasting, and executive engineering reports.

## 2. Conversion Chain Physics
The engine tracks the complete energy conversion chain:
1. **Nuclear Reaction**: Core thermal power $Q_{th}$ (MWth), neutron flux, DNBR.
2. **Coolant System**: Primary flow $m_{p}$ (kg/s), $T_{in}$, $T_{out}$, $P_{p}$ (MPa).
3. **Steam Generation**: Heat transfer $Q_{sg}$, steam pressure $P_{s}$, steam flow $m_{s}$.
4. **Steam Turbine**: Isentropic expansion across HP/LP stages, blade erosion, exhaust quality.
5. **Generator**: Mechanical shaft torque to electrical gross output $W_{gross}$ (MWe).
6. **Electrical Output & Grid**: Transformer loss $P_{tx}$, auxiliary load $P_{aux}$, net grid output $W_{net}$.
7. **Cooling & Rejection**: Condenser backpressure $P_{cond}$, cooling water flow, rejected heat $Q_{rej}$.

## 3. Energy Conservation Invariant
For all timesteps $t$:
$$Q_{th} = W_{net} + P_{aux} + P_{tx} + W_{mech} + P_{gen\_losses} + Q_{piping\_loss} + Q_{rej}$$
Delta must resolve to $< 0.1$ MW.
