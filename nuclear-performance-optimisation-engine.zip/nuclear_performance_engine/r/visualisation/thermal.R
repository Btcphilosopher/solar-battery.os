# Thermal Sankey Energy Flow Renderer in R

generate_thermal_sankey_data <- function(thermal_in_mw, gross_mwe, aux_mwe, rejected_mw) {
  nodes <- data.frame(name = c("Core Heat", "Turbine Shaft", "Gross Elec", "Net Grid", "Condenser Waste", "Aux Load"))
  return(nodes)
}
