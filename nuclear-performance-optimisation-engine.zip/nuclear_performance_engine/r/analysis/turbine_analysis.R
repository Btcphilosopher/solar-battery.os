# Turbine Isentropic Expansion Regression Model in R

fit_turbine_degradation_curve <- function(operating_hours, measured_efficiency) {
  model <- lm(measured_efficiency ~ poly(operating_hours, 2))
  degradation_rate <- coef(model)[2]
  return(list(model = model, degradation_rate = degradation_rate))
}
