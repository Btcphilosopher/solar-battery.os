# Electrical Loss Breakdown & House Load Optimization in R

analyze_house_load <- function(primary_pump_mwe, secondary_pump_mwe, fans_mwe, station_svc_mwe) {
  total_aux <- primary_pump_mwe + secondary_pump_mwe + fans_mwe + station_svc_mwe
  pct_primary <- (primary_pump_mwe / total_aux) * 100
  pct_secondary <- (secondary_pump_mwe / total_aux) * 100
  return(list(total_aux_mwe = total_aux, primary_pct = pct_primary, secondary_pct = pct_secondary))
}
