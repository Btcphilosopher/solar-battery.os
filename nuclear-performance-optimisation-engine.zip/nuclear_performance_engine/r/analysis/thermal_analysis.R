# Thermal Heat Balance & Enthalpy Drop Analysis in R

calculate_steam_generator_duty <- function(coolant_flow_kg_s, temp_hot_c, temp_cold_c) {
  cp <- 5.5 # kJ/kg-K
  delta_t <- temp_hot_c - temp_cold_c
  duty_mw <- (coolant_flow_kg_s * cp * delta_t) / 1000
  return(duty_mw)
}
