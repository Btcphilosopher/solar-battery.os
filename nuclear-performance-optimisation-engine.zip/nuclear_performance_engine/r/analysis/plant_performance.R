# R Engineering Analytics: Nuclear Station Overall Performance Model
# Analyzes plant telemetry datasets, thermal heat balance, and net efficiency.

library(jsonlite)

analyze_plant_performance <- function(telemetry_df) {
  cat("[R ANALYTICS] Executing overall plant performance analysis...\n")
  
  # Calculate Carnot and Rankine reference efficiencies
  tc_k <- telemetry_df$cooling_temp_c + 273.15
  th_k <- telemetry_df$steam_temp_c + 273.15
  carnot_efficiency <- (1 - (tc_k / th_k)) * 100
  
  gross_mwe <- telemetry_df$gross_mwe
  net_mwe <- gross_mwe - telemetry_df$aux_load_mwe - telemetry_df$transformer_loss_mwe
  thermal_efficiency <- (net_mwe / telemetry_df$thermal_mwth) * 100
  
  summary_stats <- list(
    mean_net_mwe = mean(net_mwe),
    max_net_mwe = max(net_mwe),
    mean_thermal_efficiency_pct = mean(thermal_efficiency),
    mean_carnot_limit_pct = mean(carnot_efficiency),
    second_law_efficiency_pct = (mean(thermal_efficiency) / mean(carnot_efficiency)) * 100
  )
  
  return(summary_stats)
}
