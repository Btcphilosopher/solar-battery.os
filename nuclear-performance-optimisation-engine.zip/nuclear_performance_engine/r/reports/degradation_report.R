# Long-Term Component Health & Degradation Report in R

generate_degradation_report <- function(turbine_factor, condenser_factor) {
  report <- sprintf(
    "COMPONENT HEALTH MONITOR:\n- Turbine Blade Isentropic Health: %.1f%%\n- Condenser Tube Cleanliness Ratio: %.1f%%\nStatus: Safe operating regime.",
    turbine_factor * 100, condenser_factor * 100
  )
  return(report)
}
