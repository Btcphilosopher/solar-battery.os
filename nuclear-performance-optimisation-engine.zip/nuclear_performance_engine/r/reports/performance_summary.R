# Executive Engineering Performance Report Generator in R

generate_executive_summary <- function(baseline_mw, optimised_mw, efficiency_gain) {
  report <- sprintf(
    "============================================================\n  NUCLEAR POWER STATION PERFORMANCE ENGINEERING REPORT      \n============================================================\nBaseline Net Output:  %.1f MWe\nOptimised Net Output: %.1f MWe\nNet Gain:             +%.1f MWe (+%.2f percentage points efficiency)\n",
    baseline_mw, optimised_mw, optimised_mw - baseline_mw, efficiency_gain
  )
  return(report)
}
