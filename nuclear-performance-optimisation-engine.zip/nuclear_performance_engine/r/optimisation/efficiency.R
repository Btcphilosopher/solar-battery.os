# Multi-Objective Optimization in R

optimize_plant_operating_point <- function(baseline_net_mw, ambient_temp_range) {
  gains <- c()
  for (t in ambient_temp_range) {
    # Temperature penalty: 0.8 MW loss per °C above 15°C
    delta_t <- max(0, t - 15.0)
    penalty <- delta_t * 0.8
    gains <- c(gains, baseline_net_mw - penalty)
  }
  return(data.frame(ambient_c = ambient_temp_range, expected_net_mwe = gains))
}
