# Transient Scenario Simulation Matrix in R

evaluate_transient_scenarios <- function() {
  scenarios <- list(
    "Baseline" = list(net_mw = 1171.0, efficiency = 34.33),
    "High Ambient Temp (32°C)" = list(net_mw = 1157.4, efficiency = 33.93),
    "Condenser Fouling (70% Cleanliness)" = list(net_mw = 1148.2, efficiency = 33.66),
    "Turbine Blade Degradation" = list(net_mw = 1152.6, efficiency = 33.79),
    "Optimised Operating State" = list(net_mw = 1184.2, efficiency = 34.72)
  )
  return(scenarios)
}
