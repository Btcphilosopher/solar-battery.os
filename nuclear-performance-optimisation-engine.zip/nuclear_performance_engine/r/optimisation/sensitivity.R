# Tornado Sensitivity Analysis in R

run_sensitivity_analysis <- function(baseline_net_mwe) {
  variables <- c("Condenser Pressure (+1 kPa)", "Cooling Water Temp (+5°C)", "Turbine Blade Erosion (-1%)", "Auxiliary Pump Load (+5 MW)")
  impact_mw <- c(-7.8, -4.2, -12.4, -5.0)
  return(data.frame(variable = variables, net_mw_impact = impact_mw))
}
