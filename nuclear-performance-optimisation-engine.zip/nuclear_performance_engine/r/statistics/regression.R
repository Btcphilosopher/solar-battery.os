# Multivariate Non-Linear Regression for Heat Rate & Net Generation

fit_heat_rate_regression <- function(thermal_in, steam_press, condenser_press, net_mw) {
  df <- data.frame(thermal_in, steam_press, condenser_press, net_mw)
  model <- lm(net_mw ~ thermal_in + I(steam_press^2) + condenser_press, data = df)
  return(summary(model))
}
