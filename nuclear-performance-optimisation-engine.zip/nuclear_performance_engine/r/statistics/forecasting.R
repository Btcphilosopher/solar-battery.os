# Time Series Forecasting for Equipment Performance Degradation

forecast_condenser_fouling <- function(historical_cleanliness, days_ahead = 30) {
  t <- 1:length(historical_cleanliness)
  fit <- lm(historical_cleanliness ~ t)
  future_t <- (length(historical_cleanliness) + 1):(length(historical_cleanliness) + days_ahead)
  forecast_vals <- predict(fit, newdata = data.frame(t = future_t))
  return(forecast_vals)
}
