# Monte Carlo Uncertainty Analysis in R (5,000 Iterations)
# Propagates sensor noise and ambient weather fluctuations to Net MWe distribution.

run_monte_carlo_uncertainty <- function(baseline_mw = 1171.0, n_sim = 5000) {
  set.seed(42)
  temp_variance <- rnorm(n_sim, mean = 0, sd = 2.5) # °C ambient noise
  pressure_variance <- rnorm(n_sim, mean = 0, sd = 0.2) # kPa condenser noise
  efficiency_variance <- rnorm(n_sim, mean = 0, sd = 0.005) # turbine noise
  
  simulated_net_mw <- baseline_mw - (temp_variance * 0.8) - (pressure_variance * 7.8) + (efficiency_variance * 1200)
  
  quantile_95 <- quantile(simulated_net_mw, probs = c(0.025, 0.50, 0.975))
  
  return(list(
    mean_mw = mean(simulated_net_mw),
    sd_mw = sd(simulated_net_mw),
    p025_mw = quantile_95[1],
    median_mw = quantile_95[2],
    p975_mw = quantile_95[3],
    simulations = simulated_net_mw
  ))
}
