import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import { NuclearPhysicsEngine } from './src/engine/physicsEngine';
import { RAnalyticsEngine } from './src/engine/rAnalyticsEngine';

const engine = new NuclearPhysicsEngine();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get('/api/plant-state', (req, res) => {
    res.json(engine.getPlantState());
  });

  app.post('/api/step-simulation', (req, res) => {
    const { dtSec = 1.0, perturbation } = req.body || {};
    const newState = engine.stepSimulation(dtSec, perturbation);
    res.json(newState);
  });

  app.get('/api/optimisation', (req, res) => {
    res.json(engine.getOptimiserRecommendations());
  });

  app.get('/api/loss-tree', (req, res) => {
    res.json(engine.getEnergyLossTree());
  });

  app.get('/api/safety-limits', (req, res) => {
    res.json(engine.getSafetyLimitsChecks());
  });

  app.get('/api/r-analytics/monte-carlo', (req, res) => {
    const state = engine.getPlantState();
    const mc = RAnalyticsEngine.runMonteCarloSimulation(state.net_electrical_output_mwe, 5000);
    res.json(mc);
  });

  app.get('/api/r-analytics/sensitivity', (req, res) => {
    const state = engine.getPlantState();
    const sens = RAnalyticsEngine.getSensitivityTornadoData(state.net_electrical_output_mwe);
    res.json(sens);
  });

  app.get('/api/r-analytics/scenarios', (req, res) => {
    const state = engine.getPlantState();
    const scenarios = RAnalyticsEngine.runScenarioMatrix(state.net_electrical_output_mwe);
    res.json(scenarios);
  });

  app.get('/api/r-analytics/strike-price', (req, res) => {
    const state = engine.getPlantState();
    const strike = RAnalyticsEngine.calculateStrikePriceModel(state.net_electrical_output_mwe, state.reactor.thermal_output_mw);
    res.json(strike);
  });

  app.get('/api/combustion-benchmarks', (req, res) => {
    res.json(engine.getCombustionBenchmarks());
  });

  // Codebase Explorer Endpoints
  const getFilesRecursively = (dir: string): string[] => {
    let results: string[] = [];
    if (!fs.existsSync(dir)) return results;
    const list = fs.readdirSync(dir);
    list.forEach((file) => {
      const filePath = path.join(dir, file);
      const stat = fs.statSync(filePath);
      if (stat && stat.isDirectory()) {
        results = results.concat(getFilesRecursively(filePath));
      } else {
        results.push(filePath);
      }
    });
    return results;
  };

  app.get('/api/codebase', (req, res) => {
    const rootDir = path.join(process.cwd(), 'nuclear_performance_engine');
    const allFiles = getFilesRecursively(rootDir);
    const relativeFiles = allFiles.map((f) => path.relative(process.cwd(), f));
    res.json(relativeFiles);
  });

  app.get('/api/codebase/file', (req, res) => {
    const fileRelPath = req.query.path as string;
    if (!fileRelPath) return res.status(400).json({ error: 'Path required' });
    const fullPath = path.join(process.cwd(), fileRelPath);
    if (!fullPath.startsWith(path.join(process.cwd(), 'nuclear_performance_engine'))) {
      return res.status(403).json({ error: 'Access denied' });
    }
    if (!fs.existsSync(fullPath)) return res.status(404).json({ error: 'File not found' });
    const content = fs.readFileSync(fullPath, 'utf-8');
    res.json({ path: fileRelPath, content });
  });

  app.post('/api/codebase/file', (req, res) => {
    const { path: fileRelPath, content } = req.body;
    if (!fileRelPath || content === undefined) return res.status(400).json({ error: 'Path and content required' });
    const fullPath = path.join(process.cwd(), fileRelPath);
    if (!fullPath.startsWith(path.join(process.cwd(), 'nuclear_performance_engine'))) {
      return res.status(403).json({ error: 'Access denied' });
    }
    fs.writeFileSync(fullPath, content, 'utf-8');
    res.json({ success: true, message: 'File saved successfully' });
  });

  // Vite Middleware in Dev vs Static in Prod
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[NUCLEAR ENGINE SERVER] Running on http://localhost:${PORT}`);
  });
}

startServer();
