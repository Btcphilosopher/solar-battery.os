export interface ReactorState {
  thermal_output_mw: number;
  neutron_flux_pct: number;
  control_rod_position_pct: number;
  primary_coolant_temp_in_c: number;
  primary_coolant_temp_out_c: number;
  primary_coolant_pressure_mpa: number;
  primary_coolant_flow_kg_s: number;
  thermal_margin_dnbr: number;
  core_delta_t_c: number;
}

export interface ThermalState {
  secondary_steam_pressure_mpa: number;
  secondary_steam_temp_c: number;
  secondary_steam_flow_kg_s: number;
  steam_enthalpy_kj_kg: number;
  feedwater_temp_c: number;
  piping_thermal_losses_mw: number;
  steam_generator_heat_duty_mw: number;
}

export interface TurbineState {
  hp_turbine_power_mw: number;
  lp_turbine_power_mw: number;
  turbine_speed_rpm: number;
  isentropic_efficiency_pct: number;
  mechanical_losses_mw: number;
  exhaust_steam_quality: number;
  blade_degradation_factor: number;
}

export interface GeneratorState {
  gross_output_mwe: number;
  electrical_efficiency_pct: number;
  power_factor: number;
  stator_copper_losses_mw: number;
  rotor_excitation_losses_mw: number;
  core_iron_losses_mw: number;
}

export interface CoolingState {
  condenser_pressure_kpa: number;
  condenser_temp_c: number;
  cooling_water_flow_m3_s: number;
  cooling_water_inlet_temp_c: number;
  cooling_water_outlet_temp_c: number;
  rejected_heat_mw: number;
  condenser_cleanliness_factor: number;
}

export interface ElectricalState {
  main_transformer_losses_mw: number;
  auxiliary_load_mwe: number;
  primary_pump_power_mwe: number;
  secondary_pump_power_mwe: number;
  cooling_fan_pump_power_mwe: number;
  station_service_mwe: number;
  net_grid_output_mwe: number;
}

export interface PlantState {
  timestamp_utc: string;
  reactor: ReactorState;
  thermal: ThermalState;
  turbine: TurbineState;
  generator: GeneratorState;
  cooling: CoolingState;
  electrical: ElectricalState;
  net_electrical_output_mwe: number;
  thermal_efficiency_pct: number;
  availability_factor: number;
  energy_balance_delta_mw: number;
}

export interface OptimiserRecommendation {
  id: string;
  title: string;
  subsystem: string;
  net_mw_gain: number;
  efficiency_gain_pct: number;
  risk_score: number;
  action_description: string;
  parameter_modifications: Array<[string, number, number]>;
  payback_time_days: number;
}

export interface LossTreeNode {
  id: string;
  name: string;
  category: string;
  loss_mw: number;
  pct_total: number;
  persistence: 'CONTINUOUS' | 'TRANSIENT' | 'DEGRADING';
  recoverability: 'RECOVERABLE_IMMEDIATE' | 'RECOVERABLE_MAINTENANCE' | 'UNRECOVERABLE_PHYSICAL';
  equipment_impact: 'LOW' | 'MEDIUM' | 'HIGH';
  children?: LossTreeNode[];
}

export interface SafetyLimitCheck {
  parameter: string;
  current_value: number;
  operating_max: number;
  operating_min: number;
  trip_threshold: number;
  unit: string;
  status: 'OPTIMAL' | 'WARNING' | 'CRITICAL' | 'TRIPPED';
  margin_pct: number;
}

export interface ScenarioResult {
  scenario_id: string;
  scenario_name: string;
  gross_mwe: number;
  net_mwe: number;
  efficiency_pct: number;
  auxiliary_load_mwe: number;
  rejected_heat_mw: number;
  delta_from_baseline_mwe: number;
}

export interface MonteCarloSummary {
  mean_net_mwe: number;
  sd_net_mwe: number;
  p025_mwe: number;
  median_mwe: number;
  p975_mwe: number;
  distribution_bins: Array<{ bin_center: number; count: number }>;
}

export interface CombustionBenchmarkItem {
  plant_type: string;
  thermal_efficiency_pct: number;
  fuel_energy_density_mj_kg: number;
  heat_rejection_mw_per_gwe: number;
  auxiliary_consumption_pct: number;
  capacity_factor_pct: number;
  ramp_rate_pct_min: number;
  co2_intensity_g_kwh: number;
}

export interface StrikePriceModel {
  physical_thermal_in_mw: number;
  net_output_mwe: number;
  annual_generation_gwh: number;
  fuel_cost_per_mwh: number;
  om_fixed_cost_per_mwh: number;
  capital_amortization_per_mwh: number;
  total_lcoe_per_mwh: number;
  recommended_strike_price_gbp: number;
  breakeven_electricity_price: number;
}

export interface CodeFileItem {
  path: string;
  language: 'rust' | 'r' | 'json' | 'markdown' | 'csv';
  content: string;
}
