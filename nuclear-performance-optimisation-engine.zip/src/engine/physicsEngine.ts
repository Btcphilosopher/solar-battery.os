import { PlantState, OptimiserRecommendation, LossTreeNode, SafetyLimitCheck, CombustionBenchmarkItem } from '../types/nuclear';

export class NuclearPhysicsEngine {
  private state: PlantState;
  private simulationTimeSec: number = 0;

  constructor() {
    this.state = this.createBaselineState();
  }

  public getPlantState(): PlantState {
    return JSON.parse(JSON.stringify(this.state));
  }

  public createBaselineState(): PlantState {
    const reactor = {
      thermal_output_mw: 3411.0,
      neutron_flux_pct: 100.0,
      control_rod_position_pct: 88.5,
      primary_coolant_temp_in_c: 292.0,
      primary_coolant_temp_out_c: 326.0,
      primary_coolant_pressure_mpa: 15.5,
      primary_coolant_flow_kg_s: 18200.0,
      thermal_margin_dnbr: 1.85,
      core_delta_t_c: 34.0,
    };

    const thermal = {
      secondary_steam_pressure_mpa: 6.8,
      secondary_steam_temp_c: 284.0,
      secondary_steam_flow_kg_s: 1910.0,
      steam_enthalpy_kj_kg: 2772.0,
      feedwater_temp_c: 220.0,
      piping_thermal_losses_mw: 18.5,
      steam_generator_heat_duty_mw: 3392.5,
    };

    const turbine = {
      hp_turbine_power_mw: 420.0,
      lp_turbine_power_mw: 820.0,
      turbine_speed_rpm: 1500.0,
      isentropic_efficiency_pct: 88.2,
      mechanical_losses_mw: 12.0,
      exhaust_steam_quality: 0.88,
      blade_degradation_factor: 0.985,
    };

    const generator = {
      gross_output_mwe: 1240.0,
      electrical_efficiency_pct: 98.6,
      power_factor: 0.92,
      stator_copper_losses_mw: 8.5,
      rotor_excitation_losses_mw: 4.2,
      core_iron_losses_mw: 4.8,
    };

    const cooling = {
      condenser_pressure_kpa: 4.5,
      condenser_temp_c: 31.2,
      cooling_water_flow_m3_s: 45.0,
      cooling_water_inlet_temp_c: 18.0,
      cooling_water_outlet_temp_c: 28.5,
      rejected_heat_mw: 2132.5,
      condenser_cleanliness_factor: 0.89,
    };

    const electrical = {
      main_transformer_losses_mw: 8.0,
      auxiliary_load_mwe: 61.0,
      primary_pump_power_mwe: 28.0,
      secondary_pump_power_mwe: 16.0,
      cooling_fan_pump_power_mwe: 12.0,
      station_service_mwe: 5.0,
      net_grid_output_mwe: 1171.0,
    };

    const net = generator.gross_output_mwe - electrical.auxiliary_load_mwe - electrical.main_transformer_losses_mw;
    const efficiency = (net / reactor.thermal_output_mw) * 100;
    const totalOut = net + electrical.auxiliary_load_mwe + electrical.main_transformer_losses_mw
      + turbine.mechanical_losses_mw + generator.stator_copper_losses_mw
      + generator.rotor_excitation_losses_mw + generator.core_iron_losses_mw
      + thermal.piping_thermal_losses_mw + cooling.rejected_heat_mw;
    const energy_balance_delta_mw = Math.abs(reactor.thermal_output_mw - totalOut);

    return {
      timestamp_utc: new Date().toISOString(),
      reactor,
      thermal,
      turbine,
      generator,
      cooling,
      electrical,
      net_electrical_output_mwe: net,
      thermal_efficiency_pct: efficiency,
      availability_factor: 0.982,
      energy_balance_delta_mw,
    };
  }

  public stepSimulation(dtSec: number, perturbation?: { ambientTempC?: number; condenserFouling?: number; bladeDegradation?: number; powerTargetPct?: number }): PlantState {
    this.simulationTimeSec += dtSec;
    const state = this.state;

    if (perturbation) {
      if (perturbation.ambientTempC !== undefined) {
        state.cooling.cooling_water_inlet_temp_c = perturbation.ambientTempC;
      }
      if (perturbation.condenserFouling !== undefined) {
        state.cooling.condenser_cleanliness_factor = Math.max(0.60, 1.0 - perturbation.condenserFouling);
      }
      if (perturbation.bladeDegradation !== undefined) {
        state.turbine.blade_degradation_factor = Math.max(0.90, 1.0 - perturbation.bladeDegradation);
      }
      if (perturbation.powerTargetPct !== undefined) {
        state.reactor.neutron_flux_pct = perturbation.powerTargetPct;
      }
    }

    // Core Thermal calculation Q = m * Cp * dT * flux
    const fluxFactor = state.reactor.neutron_flux_pct / 100.0;
    state.reactor.core_delta_t_c = 34.0 * fluxFactor;
    state.reactor.primary_coolant_temp_out_c = state.reactor.primary_coolant_temp_in_c + state.reactor.core_delta_t_c;
    
    // Q = (18200 kg/s * 5.5 kJ/kgK * dT) / 1000
    state.reactor.thermal_output_mw = (state.reactor.primary_coolant_flow_kg_s * 5.5 * state.reactor.core_delta_t_c) / 1000.0;
    state.thermal.steam_generator_heat_duty_mw = state.reactor.thermal_output_mw - state.thermal.piping_thermal_losses_mw;

    // Condenser backpressure is influenced by cooling water inlet temp and tube cleanliness
    const ambientTemp = state.cooling.cooling_water_inlet_temp_c;
    const cleanliness = state.cooling.condenser_cleanliness_factor;
    state.cooling.condenser_temp_c = ambientTemp + (12.5 / cleanliness);
    
    // Saturation pressure approximation around 30-40°C
    state.cooling.condenser_pressure_kpa = 3.2 + (state.cooling.condenser_temp_c - 25.0) * 0.22;

    // Turbine work calculation
    const backpressurePenaltyMW = Math.max(0, state.cooling.condenser_pressure_kpa - 3.5) * 8.2;
    const degFactor = state.turbine.blade_degradation_factor;

    state.turbine.hp_turbine_power_mw = state.thermal.steam_generator_heat_duty_mw * 0.125 * degFactor;
    state.turbine.lp_turbine_power_mw = (state.thermal.steam_generator_heat_duty_mw * 0.245 - backpressurePenaltyMW) * degFactor;
    state.turbine.isentropic_efficiency_pct = 89.5 * degFactor - (state.cooling.condenser_pressure_kpa - 3.5) * 0.4;

    const shaftPowerMW = state.turbine.hp_turbine_power_mw + state.turbine.lp_turbine_power_mw - state.turbine.mechanical_losses_mw;
    state.generator.gross_output_mwe = shaftPowerMW * (state.generator.electrical_efficiency_pct / 100.0);

    // Aux load calculation
    state.electrical.auxiliary_load_mwe = state.electrical.primary_pump_power_mwe 
      + state.electrical.secondary_pump_power_mwe 
      + state.electrical.cooling_fan_pump_power_mwe 
      + state.electrical.station_service_mwe;

    state.electrical.net_grid_output_mwe = state.generator.gross_output_mwe 
      - state.electrical.auxiliary_load_mwe 
      - state.electrical.main_transformer_losses_mw;

    state.net_electrical_output_mwe = state.electrical.net_grid_output_mwe;
    state.thermal_efficiency_pct = (state.net_electrical_output_mwe / state.reactor.thermal_output_mw) * 100.0;

    // Rejected heat = Thermal input - Gross elec - piping loss
    state.cooling.rejected_heat_mw = state.reactor.thermal_output_mw - state.generator.gross_output_mwe - state.thermal.piping_thermal_losses_mw;

    // Exact energy balance invariant verification
    const totalAccounted = state.net_electrical_output_mwe + state.electrical.auxiliary_load_mwe 
      + state.electrical.main_transformer_losses_mw + state.turbine.mechanical_losses_mw 
      + state.generator.stator_copper_losses_mw + state.generator.rotor_excitation_losses_mw 
      + state.generator.core_iron_losses_mw + state.thermal.piping_thermal_losses_mw 
      + state.cooling.rejected_heat_mw;

    state.energy_balance_delta_mw = Math.abs(state.reactor.thermal_output_mw - totalAccounted);
    state.timestamp_utc = new Date().toISOString();

    return this.getPlantState();
  }

  public getOptimiserRecommendations(): OptimiserRecommendation[] {
    const recs: OptimiserRecommendation[] = [];
    const state = this.state;

    if (state.cooling.condenser_pressure_kpa > 3.8) {
      const pressureDrop = state.cooling.condenser_pressure_kpa - 3.6;
      const mwRecovery = pressureDrop * 8.2;
      recs.push({
        id: 'REC-COND-01',
        title: 'Optimize Condenser Vacuum via Circulating Pump VFD Trimming',
        subsystem: 'Cooling / Condenser',
        net_mw_gain: Number(mwRecovery.toFixed(2)),
        efficiency_gain_pct: Number(((mwRecovery / state.reactor.thermal_output_mw) * 100).toFixed(3)),
        risk_score: 1.1,
        action_description: 'Increase secondary circulating water flow rate by 4.2 m³/s to drop condenser backpressure from ' + state.cooling.condenser_pressure_kpa.toFixed(2) + ' kPa to 3.60 kPa.',
        parameter_modifications: [
          ['condenser_pressure_kpa', Number(state.cooling.condenser_pressure_kpa.toFixed(2)), 3.60],
          ['cooling_water_flow_m3_s', state.cooling.cooling_water_flow_m3_s, 49.2],
        ],
        payback_time_days: 0.1,
      });
    }

    if (state.thermal.feedwater_temp_c < 225.0) {
      recs.push({
        id: 'REC-THERM-02',
        title: 'High-Pressure Feedwater Heater 6 Steam Extraction Trim',
        subsystem: 'Thermal / Secondary Loop',
        net_mw_gain: 5.4,
        efficiency_gain_pct: 0.158,
        risk_score: 1.6,
        action_description: 'Modulate HP extraction valve position to elevate feedwater return temperature from ' + state.thermal.feedwater_temp_c.toFixed(1) + ' °C to 224.5 °C.',
        parameter_modifications: [
          ['feedwater_temp_c', state.thermal.feedwater_temp_c, 224.5],
        ],
        payback_time_days: 1.2,
      });
    }

    if (state.electrical.auxiliary_load_mwe > 56.0) {
      recs.push({
        id: 'REC-AUX-03',
        title: 'Cooling Tower Fan Duty Cycle Reduction during Low Ambient Window',
        subsystem: 'Electrical / Auxiliary Load',
        net_mw_gain: 3.8,
        efficiency_gain_pct: 0.111,
        risk_score: 0.7,
        action_description: 'Shift 2 secondary cooling tower forced-draft fans to automatic variable speed control given current low ambient wet-bulb temperature.',
        parameter_modifications: [
          ['auxiliary_load_mwe', state.electrical.auxiliary_load_mwe, state.electrical.auxiliary_load_mwe - 3.8],
        ],
        payback_time_days: 0.0,
      });
    }

    if (state.reactor.control_rod_position_pct < 90.0) {
      recs.push({
        id: 'REC-CORE-04',
        title: 'Axial Flux Difference (AFD) Optimization',
        subsystem: 'Reactor / Core Control',
        net_mw_gain: 4.1,
        efficiency_gain_pct: 0.120,
        risk_score: 2.2,
        action_description: 'Fine-tune control rod bank D insertion by +1.5% to flatten axial flux distribution and increase core average delta T by 0.35 °C.',
        parameter_modifications: [
          ['control_rod_position_pct', state.reactor.control_rod_position_pct, 90.0],
          ['thermal_margin_dnbr', state.reactor.thermal_margin_dnbr, 1.82],
        ],
        payback_time_days: 0.0,
      });
    }

    return recs.sort((a, b) => b.net_mw_gain - a.net_mw_gain);
  }

  public getEnergyLossTree(): LossTreeNode {
    const s = this.state;
    const totalThermal = s.reactor.thermal_output_mw;

    return {
      id: 'NODE-ROOT',
      name: 'Total Core Thermal Energy',
      category: 'NUCLEAR_REACTION',
      loss_mw: totalThermal,
      pct_total: 100.0,
      persistence: 'CONTINUOUS',
      recoverability: 'UNRECOVERABLE_PHYSICAL',
      equipment_impact: 'LOW',
      children: [
        {
          id: 'NODE-NET-OUTPUT',
          name: 'Useful Net Grid Generation',
          category: 'ELECTRICAL_OUTPUT',
          loss_mw: s.net_electrical_output_mwe,
          pct_total: (s.net_electrical_output_mwe / totalThermal) * 100,
          persistence: 'CONTINUOUS',
          recoverability: 'UNRECOVERABLE_PHYSICAL',
          equipment_impact: 'LOW',
        },
        {
          id: 'NODE-CONDENSER-REJECTION',
          name: 'Condenser Cooling Heat Rejection',
          category: 'COOLING_SYSTEM',
          loss_mw: s.cooling.rejected_heat_mw,
          pct_total: (s.cooling.rejected_heat_mw / totalThermal) * 100,
          persistence: 'CONTINUOUS',
          recoverability: 'RECOVERABLE_IMMEDIATE', // Vacuum optimization can recover ~10-25 MW!
          equipment_impact: 'MEDIUM',
        },
        {
          id: 'NODE-AUX-LOAD',
          name: 'Station Auxiliary Electrical Load',
          category: 'ELECTRICAL',
          loss_mw: s.electrical.auxiliary_load_mwe,
          pct_total: (s.electrical.auxiliary_load_mwe / totalThermal) * 100,
          persistence: 'CONTINUOUS',
          recoverability: 'RECOVERABLE_IMMEDIATE',
          equipment_impact: 'LOW',
          children: [
            {
              id: 'NODE-AUX-PUMPS-PRIMARY',
              name: 'Primary Coolant Pumps Duty',
              category: 'ELECTRICAL',
              loss_mw: s.electrical.primary_pump_power_mwe,
              pct_total: (s.electrical.primary_pump_power_mwe / totalThermal) * 100,
              persistence: 'CONTINUOUS',
              recoverability: 'UNRECOVERABLE_PHYSICAL',
              equipment_impact: 'HIGH',
            },
            {
              id: 'NODE-AUX-PUMPS-SECONDARY',
              name: 'Secondary Feedwater & Circulating Pumps',
              category: 'ELECTRICAL',
              loss_mw: s.electrical.secondary_pump_power_mwe + s.electrical.cooling_fan_pump_power_mwe,
              pct_total: ((s.electrical.secondary_pump_power_mwe + s.electrical.cooling_fan_pump_power_mwe) / totalThermal) * 100,
              persistence: 'CONTINUOUS',
              recoverability: 'RECOVERABLE_IMMEDIATE',
              equipment_impact: 'MEDIUM',
            },
          ]
        },
        {
          id: 'NODE-TURBINE-MECHANICAL',
          name: 'Turbine Mechanical & Stage Expansion Losses',
          category: 'TURBINE',
          loss_mw: s.turbine.mechanical_losses_mw + (1.0 - s.turbine.blade_degradation_factor) * 35.0,
          pct_total: ((s.turbine.mechanical_losses_mw + (1.0 - s.turbine.blade_degradation_factor) * 35.0) / totalThermal) * 100,
          persistence: 'DEGRADING',
          recoverability: 'RECOVERABLE_MAINTENANCE',
          equipment_impact: 'HIGH',
        },
        {
          id: 'NODE-GENERATOR-LOSSES',
          name: 'Generator Stator, Rotor & Core Losses',
          category: 'GENERATOR',
          loss_mw: s.generator.stator_copper_losses_mw + s.generator.rotor_excitation_losses_mw + s.generator.core_iron_losses_mw,
          pct_total: ((s.generator.stator_copper_losses_mw + s.generator.rotor_excitation_losses_mw + s.generator.core_iron_losses_mw) / totalThermal) * 100,
          persistence: 'CONTINUOUS',
          recoverability: 'RECOVERABLE_MAINTENANCE',
          equipment_impact: 'MEDIUM',
        },
        {
          id: 'NODE-TRANSFORMER-LOSSES',
          name: 'Main Step-Up Transformer Loss',
          category: 'ELECTRICAL',
          loss_mw: s.electrical.main_transformer_losses_mw,
          pct_total: (s.electrical.main_transformer_losses_mw / totalThermal) * 100,
          persistence: 'CONTINUOUS',
          recoverability: 'RECOVERABLE_MAINTENANCE',
          equipment_impact: 'MEDIUM',
        },
        {
          id: 'NODE-PIPING-THERMAL-LOSS',
          name: 'Steam Piping Insulation & Radiation Losses',
          category: 'THERMAL',
          loss_mw: s.thermal.piping_thermal_losses_mw,
          pct_total: (s.thermal.piping_thermal_losses_mw / totalThermal) * 100,
          persistence: 'CONTINUOUS',
          recoverability: 'RECOVERABLE_MAINTENANCE',
          equipment_impact: 'LOW',
        },
      ]
    };
  }

  public getSafetyLimitsChecks(): SafetyLimitCheck[] {
    const s = this.state;
    return [
      {
        parameter: 'Departure from Nucleate Boiling Ratio (DNBR)',
        current_value: Number(s.reactor.thermal_margin_dnbr.toFixed(2)),
        operating_min: 1.50,
        operating_max: 3.50,
        trip_threshold: 1.30,
        unit: 'ratio',
        status: s.reactor.thermal_margin_dnbr < 1.30 ? 'TRIPPED' : s.reactor.thermal_margin_dnbr < 1.50 ? 'WARNING' : 'OPTIMAL',
        margin_pct: Number((((s.reactor.thermal_margin_dnbr - 1.30) / 1.30) * 100).toFixed(1)),
      },
      {
        parameter: 'Primary Coolant Pressure',
        current_value: Number(s.reactor.primary_coolant_pressure_mpa.toFixed(2)),
        operating_min: 14.8,
        operating_max: 15.8,
        trip_threshold: 16.8,
        unit: 'MPa',
        status: s.reactor.primary_coolant_pressure_mpa > 16.5 ? 'WARNING' : 'OPTIMAL',
        margin_pct: Number((((16.8 - s.reactor.primary_coolant_pressure_mpa) / 16.8) * 100).toFixed(1)),
      },
      {
        parameter: 'Reactor Core Outlet Temperature',
        current_value: Number(s.reactor.primary_coolant_temp_out_c.toFixed(1)),
        operating_min: 310.0,
        operating_max: 330.0,
        trip_threshold: 335.0,
        unit: '°C',
        status: s.reactor.primary_coolant_temp_out_c > 332.0 ? 'CRITICAL' : 'OPTIMAL',
        margin_pct: Number((((335.0 - s.reactor.primary_coolant_temp_out_c) / 335.0) * 100).toFixed(1)),
      },
      {
        parameter: 'Condenser Vacuum Backpressure',
        current_value: Number(s.cooling.condenser_pressure_kpa.toFixed(2)),
        operating_min: 2.5,
        operating_max: 6.5,
        trip_threshold: 12.0,
        unit: 'kPa',
        status: s.cooling.condenser_pressure_kpa > 8.0 ? 'WARNING' : 'OPTIMAL',
        margin_pct: Number((((12.0 - s.cooling.condenser_pressure_kpa) / 12.0) * 100).toFixed(1)),
      },
    ];
  }

  public getCombustionBenchmarks(): CombustionBenchmarkItem[] {
    return [
      {
        plant_type: 'Pressurized Water Reactor (Nuclear PWR-1200)',
        thermal_efficiency_pct: 34.33,
        fuel_energy_density_mj_kg: 3_900_000, // Enriched U-235 (3.5% U235)
        heat_rejection_mw_per_gwe: 1820.0,
        auxiliary_consumption_pct: 4.92,
        capacity_factor_pct: 93.5,
        ramp_rate_pct_min: 5.0, // Modern load-following PWR
        co2_intensity_g_kwh: 12.0, // Lifecycle CO2
      },
      {
        plant_type: 'Ultra-Supercritical Coal Station',
        thermal_efficiency_pct: 44.5,
        fuel_energy_density_mj_kg: 27.0, // Bituminous coal
        heat_rejection_mw_per_gwe: 1240.0,
        auxiliary_consumption_pct: 8.5,
        capacity_factor_pct: 78.0,
        ramp_rate_pct_min: 3.0,
        co2_intensity_g_kwh: 820.0,
      },
      {
        plant_type: 'Combined Cycle Gas Turbine (CCGT Natural Gas)',
        thermal_efficiency_pct: 61.2,
        fuel_energy_density_mj_kg: 50.0, // Methane
        heat_rejection_mw_per_gwe: 630.0,
        auxiliary_consumption_pct: 2.1,
        capacity_factor_pct: 65.0,
        ramp_rate_pct_min: 12.0,
        co2_intensity_g_kwh: 370.0,
      },
      {
        plant_type: 'Biomass Direct Combustion Station',
        thermal_efficiency_pct: 31.0,
        fuel_energy_density_mj_kg: 16.0, // Wood pellets
        heat_rejection_mw_per_gwe: 2150.0,
        auxiliary_consumption_pct: 9.2,
        capacity_factor_pct: 72.0,
        ramp_rate_pct_min: 2.5,
        co2_intensity_g_kwh: 230.0,
      },
    ];
  }
}
