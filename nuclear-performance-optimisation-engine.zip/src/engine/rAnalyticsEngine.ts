import { MonteCarloSummary, StrikePriceModel, ScenarioResult } from '../types/nuclear';

export class RAnalyticsEngine {
  public static runMonteCarloSimulation(baselineNetMW: number = 1171.0, iterations: number = 5000): MonteCarloSummary {
    const results: number[] = [];
    
    // Seeded pseudo-random normal distribution
    for (let i = 0; i < iterations; i++) {
      const u1 = Math.random();
      const u2 = Math.random();
      const z0 = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
      const z1 = Math.sqrt(-2.0 * Math.log(u1)) * Math.sin(2.0 * Math.PI * u2);

      // Variances: Ambient temperature noise (SD = 2.8°C), Condenser pressure noise (SD = 0.25 kPa)
      const ambientTempNoise = z0 * 2.8;
      const condenserPressureNoise = z1 * 0.25;

      const simMW = baselineNetMW - (ambientTempNoise * 0.82) - (condenserPressureNoise * 7.8);
      results.push(simMW);
    }

    results.sort((a, b) => a - b);

    const sum = results.reduce((acc, val) => acc + val, 0);
    const mean = sum / iterations;
    const variance = results.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0) / iterations;
    const sd = Math.sqrt(variance);

    const p025 = results[Math.floor(iterations * 0.025)];
    const median = results[Math.floor(iterations * 0.50)];
    const p975 = results[Math.floor(iterations * 0.975)];

    // Bin distribution into 15 histogram bars
    const minVal = results[0];
    const maxVal = results[iterations - 1];
    const binWidth = (maxVal - minVal) / 15;

    const bins: Array<{ bin_center: number; count: number }> = [];
    for (let b = 0; b < 15; b++) {
      const binMin = minVal + b * binWidth;
      const binMax = binMin + binWidth;
      const binCenter = Number(((binMin + binMax) / 2).toFixed(1));
      const count = results.filter(v => v >= binMin && v < binMax).length;
      bins.push({ bin_center: binCenter, count });
    }

    return {
      mean_net_mwe: Number(mean.toFixed(1)),
      sd_net_mwe: Number(sd.toFixed(2)),
      p025_mwe: Number(p025.toFixed(1)),
      median_mwe: Number(median.toFixed(1)),
      p975_mwe: Number(p975.toFixed(1)),
      distribution_bins: bins,
    };
  }

  public static getSensitivityTornadoData(baselineNetMW: number) {
    return [
      { parameter: 'Condenser Vacuum Pressure (+1.0 kPa)', negative_impact_mw: -8.2, positive_impact_mw: 0.0, category: 'Cooling' },
      { parameter: 'Cooling Water Inlet Temp (+5.0 °C)', negative_impact_mw: -4.5, positive_impact_mw: 0.0, category: 'Ambient' },
      { parameter: 'Turbine Blade Erosion (-1.5%)', negative_impact_mw: -12.4, positive_impact_mw: 0.0, category: 'Turbine' },
      { parameter: 'High-Pressure Feedwater Heater Bypass', negative_impact_mw: -5.4, positive_impact_mw: 0.0, category: 'Thermal' },
      { parameter: 'Auxiliary Cooling Fan VFD Optimization', negative_impact_mw: 0.0, positive_impact_mw: +3.8, category: 'Auxiliary' },
      { parameter: 'Axial Flux Flattening Trim', negative_impact_mw: 0.0, positive_impact_mw: +4.1, category: 'Reactor' },
    ];
  }

  public static runScenarioMatrix(baselineNetMW: number): ScenarioResult[] {
    return [
      {
        scenario_id: 'SCENARIO-BASELINE',
        scenario_name: 'Nominal Operating State (100% Core Power, 18°C Cooling)',
        gross_mwe: 1240.0,
        net_mwe: baselineNetMW,
        efficiency_pct: 34.33,
        auxiliary_load_mwe: 61.0,
        rejected_heat_mw: 2132.5,
        delta_from_baseline_mwe: 0.0,
      },
      {
        scenario_id: 'SCENARIO-SUMMER-HEAT',
        scenario_name: 'Summer Heatwave Condition (32°C Water Temp)',
        gross_mwe: 1224.2,
        net_mwe: 1152.4,
        efficiency_pct: 33.78,
        auxiliary_load_mwe: 63.8,
        rejected_heat_mw: 2168.3,
        delta_from_baseline_mwe: -18.6,
      },
      {
        scenario_id: 'SCENARIO-COND-FOULING',
        scenario_name: 'Condenser Tube Macro-Fouling (70% Cleanliness)',
        gross_mwe: 1218.5,
        net_mwe: 1149.5,
        efficiency_pct: 33.70,
        auxiliary_load_mwe: 61.0,
        rejected_heat_mw: 2174.0,
        delta_from_baseline_mwe: -21.5,
      },
      {
        scenario_id: 'SCENARIO-TURBINE-EROSION',
        scenario_name: 'LP Turbine Stage 5 Blade Droplet Erosion',
        gross_mwe: 1222.0,
        net_mwe: 1153.0,
        efficiency_pct: 33.80,
        auxiliary_load_mwe: 61.0,
        rejected_heat_mw: 2170.5,
        delta_from_baseline_mwe: -18.0,
      },
      {
        scenario_id: 'SCENARIO-OPTIMISED',
        scenario_name: 'Optimised Operating State (Vacuum + VFD + Feedwater Trim)',
        gross_mwe: 1252.8,
        net_mwe: 1187.6,
        efficiency_pct: 34.82,
        auxiliary_load_mwe: 57.2,
        rejected_heat_mw: 2119.7,
        delta_from_baseline_mwe: +16.6,
      },
    ];
  }

  public static calculateStrikePriceModel(netMWe: number, thermalMWth: number): StrikePriceModel {
    const annualHours = 8760 * 0.935; // 93.5% capacity factor
    const annualGWh = (netMWe * annualHours) / 1000.0;

    // Nuclear cost breakdown per MWh
    const fuelCostPerMWh = 7.5; // Enriched uranium fabrication + waste management
    const omFixedCostPerMWh = 18.2; // Staff, routine outage, security, regulatory
    const capitalAmortizationPerMWh = 62.5; // Plant construction debt payback

    const totalLCOE = fuelCostPerMWh + omFixedCostPerMWh + capitalAmortizationPerMWh;
    const strikePrice = totalLCOE + 4.3; // Inflation indexation & regulatory margin

    return {
      physical_thermal_in_mw: thermalMWth,
      net_output_mwe: netMWe,
      annual_generation_gwh: Number(annualGWh.toFixed(1)),
      fuel_cost_per_mwh: fuelCostPerMWh,
      om_fixed_cost_per_mwh: omFixedCostPerMWh,
      capital_amortization_per_mwh: capitalAmortizationPerMWh,
      total_lcoe_per_mwh: Number(totalLCOE.toFixed(2)),
      recommended_strike_price_gbp: Number(strikePrice.toFixed(2)),
      breakeven_electricity_price: Number(totalLCOE.toFixed(2)),
    };
  }
}
