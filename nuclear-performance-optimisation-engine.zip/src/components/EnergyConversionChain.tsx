import React, { useState } from 'react';
import { PlantState } from '../types/nuclear';
import { Flame, Droplet, Wind, Zap, Gauge, ArrowRight, Activity, ShieldCheck } from 'lucide-react';

interface EnergyConversionChainProps {
  plantState: PlantState;
}

export const EnergyConversionChain: React.FC<EnergyConversionChainProps> = ({ plantState }) => {
  const [selectedStage, setSelectedStage] = useState<string>('reactor');

  const r = plantState.reactor;
  const th = plantState.thermal;
  const tur = plantState.turbine;
  const g = plantState.generator;
  const c = plantState.cooling;
  const e = plantState.electrical;

  const stages = [
    {
      id: 'reaction',
      title: 'Nuclear Reaction',
      icon: Flame,
      color: 'border-amber-500/40 text-amber-400 bg-amber-500/10',
      metric: `${r.neutron_flux_pct.toFixed(1)}% Flux`,
      subtext: `Control Rods: ${r.control_rod_position_pct.toFixed(1)}%`,
    },
    {
      id: 'reactor',
      title: 'Reactor / Core',
      icon: ShieldCheck,
      color: 'border-amber-500/40 text-amber-400 bg-amber-500/10',
      metric: `${r.thermal_output_mw.toFixed(1)} MWth`,
      subtext: `DNBR: ${r.thermal_margin_dnbr.toFixed(2)}`,
    },
    {
      id: 'coolant',
      title: 'Primary Coolant',
      icon: Droplet,
      color: 'border-blue-500/40 text-blue-400 bg-blue-500/10',
      metric: `${r.primary_coolant_flow_kg_s.toFixed(0)} kg/s`,
      subtext: `${r.primary_coolant_temp_out_c.toFixed(1)}°C @ ${r.primary_coolant_pressure_mpa.toFixed(1)}MPa`,
    },
    {
      id: 'steam',
      title: 'Steam Generator',
      icon: Wind,
      color: 'border-cyan-500/40 text-cyan-400 bg-cyan-500/10',
      metric: `${th.secondary_steam_flow_kg_s.toFixed(0)} kg/s`,
      subtext: `${th.secondary_steam_temp_c.toFixed(1)}°C @ ${th.secondary_steam_pressure_mpa.toFixed(1)}MPa`,
    },
    {
      id: 'turbine',
      title: 'Steam Turbine',
      icon: Gauge,
      color: 'border-indigo-500/40 text-indigo-400 bg-indigo-500/10',
      metric: `${(tur.hp_turbine_power_mw + tur.lp_turbine_power_mw).toFixed(1)} MW`,
      subtext: `Speed: ${tur.turbine_speed_rpm.toFixed(0)} RPM`,
    },
    {
      id: 'generator',
      title: 'Generator',
      icon: Zap,
      color: 'border-emerald-500/40 text-emerald-400 bg-emerald-500/10',
      metric: `${g.gross_output_mwe.toFixed(1)} MWe`,
      subtext: `Efficiency: ${g.electrical_efficiency_pct.toFixed(1)}%`,
    },
    {
      id: 'electrical',
      title: 'Electrical / Grid',
      icon: Activity,
      color: 'border-emerald-400 text-emerald-300 bg-emerald-500/20',
      metric: `${e.net_grid_output_mwe.toFixed(1)} MWe`,
      subtext: `Aux Load: -${e.auxiliary_load_mwe.toFixed(1)} MWe`,
    },
  ];

  return (
    <div className="space-y-6 font-mono">
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
        <h2 className="text-sm font-bold text-cyan-400 tracking-wider mb-2 flex items-center gap-2">
          <Flame className="w-4 h-4 text-amber-400" />
          COMPLETE PHYSICAL ENERGY CONVERSION CHAIN
        </h2>
        <p className="text-xs text-slate-400 mb-6">
          Nuclear Thermal Hydration $\rightarrow$ Primary Coolant $\rightarrow$ Secondary Steam Enthalpy $\rightarrow$ Mechanical Shaft Work $\rightarrow$ Net Electrical Grid Injection
        </p>

        {/* Chain Interactive Diagram */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-7 gap-3">
          {stages.map((stage, idx) => {
            const Icon = stage.icon;
            const isSelected = selectedStage === stage.id;
            return (
              <div key={stage.id} className="relative">
                <button
                  onClick={() => setSelectedStage(stage.id)}
                  className={`w-full text-left p-3.5 rounded-xl border transition-all ${stage.color} ${
                    isSelected ? 'ring-2 ring-cyan-400 shadow-lg scale-102' : 'hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <Icon className="w-5 h-5" />
                    <span className="text-[10px] text-slate-500 font-bold">#0{idx + 1}</span>
                  </div>
                  <div className="text-xs font-bold mb-1 truncate">{stage.title}</div>
                  <div className="text-sm font-extrabold text-white">{stage.metric}</div>
                  <div className="text-[10px] text-slate-400 mt-1">{stage.subtext}</div>
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Stage Inspection Detail Panel */}
      <div className="bg-slate-950 border border-slate-800 rounded-xl p-6">
        <h3 className="text-xs font-bold text-cyan-400 uppercase tracking-widest mb-4">
          SUBSYSTEM DETAILED THERMAL-HYDRAULIC & ELECTRICAL AUDIT :: {selectedStage.toUpperCase()}
        </h3>

        {selectedStage === 'reactor' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div className="bg-slate-900 p-4 rounded-lg border border-slate-800">
              <span className="text-slate-500 block mb-1">CORE THERMAL POWER</span>
              <span className="text-xl font-bold text-amber-400">{r.thermal_output_mw.toFixed(1)} MWth</span>
              <p className="text-slate-400 mt-2">Nominal licensed rating: 3,411.0 MWth (100% Full Power).</p>
            </div>
            <div className="bg-slate-900 p-4 rounded-lg border border-slate-800">
              <span className="text-slate-500 block mb-1">DEPARTURE FROM NUCLEATE BOILING (DNBR)</span>
              <span className="text-xl font-bold text-emerald-400">{r.thermal_margin_dnbr.toFixed(2)}</span>
              <p className="text-slate-400 mt-2">Hard safety trip envelope limit: &ge; 1.30 ratio.</p>
            </div>
            <div className="bg-slate-900 p-4 rounded-lg border border-slate-800">
              <span className="text-slate-500 block mb-1">CORE DELTA T (&Delta;T)</span>
              <span className="text-xl font-bold text-cyan-400">{r.core_delta_t_c.toFixed(1)} °C</span>
              <p className="text-slate-400 mt-2">Difference between coolant outlet (326°C) and inlet (292°C).</p>
            </div>
          </div>
        )}

        {selectedStage === 'coolant' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div className="bg-slate-900 p-4 rounded-lg border border-slate-800">
              <span className="text-slate-500 block mb-1">PRIMARY SYSTEM PRESSURE</span>
              <span className="text-xl font-bold text-blue-400">{r.primary_coolant_pressure_mpa.toFixed(2)} MPa</span>
              <p className="text-slate-400 mt-2">Pressurizer setpoint maintaining subcooled liquid phase.</p>
            </div>
            <div className="bg-slate-900 p-4 rounded-lg border border-slate-800">
              <span className="text-slate-500 block mb-1">PRIMARY MASS FLOW RATE</span>
              <span className="text-xl font-bold text-blue-400">{r.primary_coolant_flow_kg_s.toFixed(0)} kg/s</span>
              <p className="text-slate-400 mt-2">Driven by 4 reactor coolant pumps (28.0 MWe total house load).</p>
            </div>
            <div className="bg-slate-900 p-4 rounded-lg border border-slate-800">
              <span className="text-slate-500 block mb-1">PUMP HOUSE CONSUMPTION</span>
              <span className="text-xl font-bold text-amber-400">{e.primary_pump_power_mwe.toFixed(1)} MWe</span>
              <p className="text-slate-400 mt-2">Uninterrupted safety power supply.</p>
            </div>
          </div>
        )}

        {selectedStage === 'steam' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div className="bg-slate-900 p-4 rounded-lg border border-slate-800">
              <span className="text-slate-500 block mb-1">SECONDARY STEAM PRESSURE</span>
              <span className="text-xl font-bold text-cyan-400">{th.secondary_steam_pressure_mpa.toFixed(2)} MPa</span>
              <p className="text-slate-400 mt-2">Dry saturated steam exiting 4 steam generators.</p>
            </div>
            <div className="bg-slate-900 p-4 rounded-lg border border-slate-800">
              <span className="text-slate-500 block mb-1">STEAM SPECIFIC ENTHALPY</span>
              <span className="text-xl font-bold text-cyan-400">{th.steam_enthalpy_kj_kg.toFixed(0)} kJ/kg</span>
              <p className="text-slate-400 mt-2">Feedwater return temperature: {th.feedwater_temp_c.toFixed(1)} °C.</p>
            </div>
            <div className="bg-slate-900 p-4 rounded-lg border border-slate-800">
              <span className="text-slate-500 block mb-1">STEAM GENERATOR HEAT DUTY</span>
              <span className="text-xl font-bold text-amber-400">{th.steam_generator_heat_duty_mw.toFixed(1)} MWth</span>
              <p className="text-slate-400 mt-2">Piping thermal radiation loss: {th.piping_thermal_losses_mw.toFixed(1)} MWth.</p>
            </div>
          </div>
        )}

        {selectedStage === 'turbine' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div className="bg-slate-900 p-4 rounded-lg border border-slate-800">
              <span className="text-slate-500 block mb-1">HIGH-PRESSURE (HP) TURBINE</span>
              <span className="text-xl font-bold text-indigo-400">{tur.hp_turbine_power_mw.toFixed(1)} MW</span>
              <p className="text-slate-400 mt-2">Single double-flow HP cylinder expansion.</p>
            </div>
            <div className="bg-slate-900 p-4 rounded-lg border border-slate-800">
              <span className="text-slate-500 block mb-1">LOW-PRESSURE (LP) TURBINES</span>
              <span className="text-xl font-bold text-indigo-400">{tur.lp_turbine_power_mw.toFixed(1)} MW</span>
              <p className="text-slate-400 mt-2">3 LP double-flow cylinders expanding to condenser vacuum.</p>
            </div>
            <div className="bg-slate-900 p-4 rounded-lg border border-slate-800">
              <span className="text-slate-500 block mb-1">ISENTROPIC EFFICIENCY & DEGRADATION</span>
              <span className="text-xl font-bold text-emerald-400">{tur.isentropic_efficiency_pct.toFixed(1)}%</span>
              <p className="text-slate-400 mt-2">Blade erosion degradation factor: {(tur.blade_degradation_factor * 100).toFixed(1)}%.</p>
            </div>
          </div>
        )}

        {selectedStage === 'generator' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div className="bg-slate-900 p-4 rounded-lg border border-slate-800">
              <span className="text-slate-500 block mb-1">GROSS GENERATOR ELECTRICITY</span>
              <span className="text-xl font-bold text-emerald-400">{g.gross_output_mwe.toFixed(1)} MWe</span>
              <p className="text-slate-400 mt-2">Power factor: {g.power_factor.toFixed(2)} lagging.</p>
            </div>
            <div className="bg-slate-900 p-4 rounded-lg border border-slate-800">
              <span className="text-slate-500 block mb-1">STATOR & ROTOR COPPER LOSSES</span>
              <span className="text-xl font-bold text-rose-400">{(g.stator_copper_losses_mw + g.rotor_excitation_losses_mw).toFixed(1)} MW</span>
              <p className="text-slate-400 mt-2">Hydrogen/water cooled synchronous alternator.</p>
            </div>
            <div className="bg-slate-900 p-4 rounded-lg border border-slate-800">
              <span className="text-slate-500 block mb-1">ELECTRICAL EFFICIENCY</span>
              <span className="text-xl font-bold text-cyan-400">{g.electrical_efficiency_pct.toFixed(1)}%</span>
              <p className="text-slate-400 mt-2">Core iron loss: {g.core_iron_losses_mw.toFixed(1)} MW.</p>
            </div>
          </div>
        )}

        {selectedStage === 'electrical' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div className="bg-slate-900 p-4 rounded-lg border border-slate-800">
              <span className="text-slate-500 block mb-1">NET GRID EXPORT POWER</span>
              <span className="text-xl font-bold text-emerald-300">{e.net_grid_output_mwe.toFixed(1)} MWe</span>
              <p className="text-slate-400 mt-2">Gross output minus house load and transformer losses.</p>
            </div>
            <div className="bg-slate-900 p-4 rounded-lg border border-slate-800">
              <span className="text-slate-500 block mb-1">STATION AUXILIARY HOUSE LOAD</span>
              <span className="text-xl font-bold text-amber-400">{e.auxiliary_load_mwe.toFixed(1)} MWe</span>
              <p className="text-slate-400 mt-2">Cooling fans, pumps, instrumentation, and water treatment.</p>
            </div>
            <div className="bg-slate-900 p-4 rounded-lg border border-slate-800">
              <span className="text-slate-500 block mb-1">MAIN TRANSFORMER LOSSES</span>
              <span className="text-xl font-bold text-rose-400">{e.main_transformer_losses_mw.toFixed(1)} MW</span>
              <p className="text-slate-400 mt-2">Step-up transformer to 400kV grid interface.</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
