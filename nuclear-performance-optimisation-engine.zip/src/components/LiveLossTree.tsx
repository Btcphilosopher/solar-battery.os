import React from 'react';
import { LossTreeNode } from '../types/nuclear';
import { GitFork, ArrowDownRight, Layers, AlertCircle, ShieldAlert } from 'lucide-react';

interface LiveLossTreeProps {
  lossTree: LossTreeNode;
}

export const LiveLossTree: React.FC<LiveLossTreeProps> = ({ lossTree }) => {
  const children = lossTree.children || [];

  return (
    <div className="space-y-6 font-mono">
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-sm font-bold text-cyan-400 tracking-wider flex items-center gap-2">
            <GitFork className="w-4 h-4 text-cyan-400" />
            LIVE THERMAL-ELECTRICAL ENERGY LOSS TREE
          </h2>
          <span className="text-xs text-slate-400 font-normal">
            Where is the next MW of potential improvement?
          </span>
        </div>
        <p className="text-xs text-slate-400">
          Ranks energy sink channels by lost MW, percentage of core thermal input, persistence, recoverability, and equipment impact.
        </p>
      </div>

      {/* Root Node Banner */}
      <div className="bg-slate-950 border border-slate-800 rounded-xl p-5">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
          <div className="flex items-center space-x-3">
            <span className="w-3 h-3 rounded-full bg-amber-400 animate-pulse" />
            <div>
              <span className="text-xs text-slate-500 font-bold block">TOTAL CORE THERMAL INPUT</span>
              <span className="text-xl font-bold text-amber-400">{lossTree.loss_mw.toFixed(1)} MWth</span>
            </div>
          </div>
          <div className="text-right">
            <span className="text-xs text-slate-500 block">ENERGY CONSERVATION</span>
            <span className="text-xs font-bold text-emerald-400">100.0% Accounted</span>
          </div>
        </div>

        {/* Children Loss Nodes List */}
        <div className="space-y-3">
          {children.map((node) => {
            const isNetOutput = node.category === 'ELECTRICAL_OUTPUT';
            const isCondenser = node.category === 'COOLING_SYSTEM';

            return (
              <div
                key={node.id}
                className={`p-4 rounded-xl border transition-all ${
                  isNetOutput
                    ? 'bg-emerald-950/20 border-emerald-500/40'
                    : isCondenser
                    ? 'bg-rose-950/20 border-rose-500/40'
                    : 'bg-slate-900 border-slate-800'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-2">
                  <div className="flex items-center space-x-3">
                    <ArrowDownRight className={`w-4 h-4 ${isNetOutput ? 'text-emerald-400' : 'text-slate-500'}`} />
                    <div>
                      <span className="text-xs font-bold text-white block">{node.name}</span>
                      <span className="text-[10px] text-slate-500">[{node.category}]</span>
                    </div>
                  </div>

                  <div className="flex items-center space-x-4">
                    <div className="text-right">
                      <span className={`text-sm font-extrabold ${isNetOutput ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {node.loss_mw.toFixed(1)} MW
                      </span>
                      <span className="text-[10px] text-slate-500 block">{node.pct_total.toFixed(2)}% of Core</span>
                    </div>

                    <div className="flex items-center space-x-1 text-[10px]">
                      <span className="px-2 py-0.5 rounded bg-slate-950 text-slate-300 border border-slate-800">
                        {node.persistence}
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded font-bold ${
                          node.recoverability === 'RECOVERABLE_IMMEDIATE'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                            : 'bg-slate-950 text-slate-400 border border-slate-800'
                        }`}
                      >
                        {node.recoverability.replace('_', ' ')}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Sub-children nested details */}
                {node.children && node.children.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-slate-800/80 pl-6 space-y-2">
                    {node.children.map((sub) => (
                      <div key={sub.id} className="flex items-center justify-between text-xs text-slate-400 bg-slate-950/80 p-2 rounded border border-slate-800/60">
                        <span>&bull; {sub.name}</span>
                        <span className="font-bold text-amber-300">{sub.loss_mw.toFixed(1)} MW</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
