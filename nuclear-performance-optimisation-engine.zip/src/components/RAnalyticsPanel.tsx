import React, { useState, useEffect } from 'react';
import { MonteCarloSummary, StrikePriceModel } from '../types/nuclear';
import { RAnalyticsEngine } from '../engine/rAnalyticsEngine';
import { BarChart3, LineChart, DollarSign, Activity, FileSpreadsheet } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface RAnalyticsPanelProps {
  netMW: number;
  thermalMW: number;
}

export const RAnalyticsPanel: React.FC<RAnalyticsPanelProps> = ({ netMW, thermalMW }) => {
  const [mcSummary, setMcSummary] = useState<MonteCarloSummary | null>(null);
  const [strikeModel, setStrikeModel] = useState<StrikePriceModel | null>(null);

  useEffect(() => {
    const mc = RAnalyticsEngine.runMonteCarloSimulation(netMW, 5000);
    setMcSummary(mc);
    const strike = RAnalyticsEngine.calculateStrikePriceModel(netMW, thermalMW);
    setStrikeModel(strike);
  }, [netMW, thermalMW]);

  const sensitivityData = RAnalyticsEngine.getSensitivityTornadoData(netMW);

  return (
    <div className="space-y-6 font-mono">
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-sm font-bold text-cyan-400 tracking-wider flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-cyan-400" />
            R SCIENTIFIC STATISTICAL ANALYTICS & UNCERTAINTY LABORATORY
          </h2>
          <span className="text-xs px-2.5 py-1 rounded bg-indigo-500/10 text-indigo-300 border border-indigo-500/30">
            R Engine Kernel v4.3
          </span>
        </div>
        <p className="text-xs text-slate-400">
          Provides Monte Carlo uncertainty analysis, tornado sensitivity analysis, turbine degradation regression, and downstream generation cost / strike price calculations.
        </p>
      </div>

      {/* Monte Carlo Section */}
      {mcSummary && (
        <div className="bg-slate-950 border border-slate-800 rounded-xl p-6">
          <h3 className="text-xs font-bold text-cyan-400 tracking-wider mb-4 flex items-center justify-between">
            <span>MONTE CARLO UNCERTAINTY PROPAGATION (5,000 SIMULATIONS)</span>
            <span className="text-slate-500 font-normal">Sensor Noise & Weather Stochastic Models</span>
          </h3>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6 text-xs">
            <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span className="text-slate-500 block">MEAN NET OUTPUT</span>
              <span className="text-lg font-bold text-cyan-400">{mcSummary.mean_net_mwe} MWe</span>
            </div>
            <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span className="text-slate-500 block">STD DEVIATION (&sigma;)</span>
              <span className="text-lg font-bold text-amber-400">&plusmn;{mcSummary.sd_net_mwe} MWe</span>
            </div>
            <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span className="text-slate-500 block">95% CONFIDENCE LOWER (p2.5)</span>
              <span className="text-lg font-bold text-slate-300">{mcSummary.p025_mwe} MWe</span>
            </div>
            <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span className="text-slate-500 block">95% CONFIDENCE UPPER (p97.5)</span>
              <span className="text-lg font-bold text-emerald-400">{mcSummary.p975_mwe} MWe</span>
            </div>
          </div>

          <div className="h-60">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={mcSummary.distribution_bins}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="bin_center" stroke="#64748b" tick={{ fontSize: 10 }} label={{ value: 'Net Output (MWe)', position: 'insideBottom', offset: -5, fill: '#64748b', fontSize: 10 }} />
                <YAxis stroke="#64748b" tick={{ fontSize: 10 }} />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }} />
                <Bar dataKey="count" fill="#3b82f6" name="Simulation Frequency" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* Tornado Sensitivity Chart */}
      <div className="bg-slate-950 border border-slate-800 rounded-xl p-6">
        <h3 className="text-xs font-bold text-cyan-400 tracking-wider mb-4">
          TORNADO SENSITIVITY ANALYSIS :: NET ELECTRICAL OUTPUT IMPACT (MWe)
        </h3>

        <div className="space-y-3 text-xs">
          {sensitivityData.map((s) => {
            const isPos = s.positive_impact_mw > 0;
            const val = isPos ? s.positive_impact_mw : s.negative_impact_mw;

            return (
              <div key={s.parameter} className="bg-slate-900 p-3 rounded-lg border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <span className="font-bold text-white block">{s.parameter}</span>
                  <span className="text-[10px] text-slate-500">[{s.category}]</span>
                </div>
                <div className="flex items-center space-x-3">
                  <span className={`text-sm font-bold ${isPos ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {isPos ? '+' : ''}{val.toFixed(1)} MWe
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Downstream Strike Price Calculation Module */}
      {strikeModel && (
        <div className="bg-slate-950 border border-slate-800 rounded-xl p-6">
          <div className="flex items-center space-x-2 mb-2">
            <DollarSign className="w-5 h-5 text-emerald-400" />
            <h3 className="text-xs font-bold text-emerald-400 tracking-wider">
              DOWNSTREAM ECONOMICS & STRIKE PRICE ANALYTICS (EXPLICIT SECONDARY OUTPUT)
            </h3>
          </div>
          <p className="text-xs text-slate-400 mb-4">
            Notice: Economic variables are calculated solely as downstream outputs. Financial prices NEVER drive unsafe physical operation.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs">
            <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
              <span className="text-slate-500 block mb-1">ANNUAL GENERATION</span>
              <span className="text-xl font-bold text-white">{strikeModel.annual_generation_gwh.toLocaleString()} GWh</span>
              <p className="text-[11px] text-slate-500 mt-1">93.5% capacity factor</p>
            </div>
            <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
              <span className="text-slate-500 block mb-1">FUEL & O&M COST</span>
              <span className="text-xl font-bold text-cyan-400">£{(strikeModel.fuel_cost_per_mwh + strikeModel.om_fixed_cost_per_mwh).toFixed(2)}/MWh</span>
              <p className="text-[11px] text-slate-500 mt-1">Enriched uranium & station O&M</p>
            </div>
            <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
              <span className="text-slate-500 block mb-1">LEVELISED COST (LCOE)</span>
              <span className="text-xl font-bold text-amber-400">£{strikeModel.total_lcoe_per_mwh.toFixed(2)}/MWh</span>
              <p className="text-[11px] text-slate-500 mt-1">Breakeven generation price</p>
            </div>
            <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
              <span className="text-slate-500 block mb-1">RECOMMENDED STRIKE PRICE</span>
              <span className="text-xl font-bold text-emerald-400">£{strikeModel.recommended_strike_price_gbp.toFixed(2)}/MWh</span>
              <p className="text-[11px] text-slate-500 mt-1">CfD contractual strike price</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
