import React, { useState, useEffect } from 'react';
import { Code2, FileCode2, Save, Check, RefreshCw, Terminal, Search } from 'lucide-react';

export const CodebaseExplorer: React.FC = () => {
  const [fileList, setFileList] = useState<string[]>([]);
  const [selectedFilePath, setSelectedFilePath] = useState<string>('nuclear_performance_engine/rust/src/main.rs');
  const [fileContent, setFileContent] = useState<string>('');
  const [isLoadingContent, setIsLoadingContent] = useState<boolean>(false);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [saveMessage, setSaveMessage] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');

  useEffect(() => {
    fetch('/api/codebase')
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data)) {
          setFileList(data);
        }
      })
      .catch((err) => console.error('Failed to load codebase files:', err));
  }, []);

  useEffect(() => {
    if (!selectedFilePath) return;
    setIsLoadingContent(true);
    fetch(`/api/codebase/file?path=${encodeURIComponent(selectedFilePath)}`)
      .then((res) => res.json())
      .then((data) => {
        setFileContent(data.content || '');
        setIsLoadingContent(false);
      })
      .catch((err) => {
        console.error('Failed to fetch file content:', err);
        setIsLoadingContent(false);
      });
  }, [selectedFilePath]);

  const handleSave = () => {
    setIsSaving(true);
    setSaveMessage(null);
    fetch('/api/codebase/file', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ path: selectedFilePath, content: fileContent }),
    })
      .then((res) => res.json())
      .then((data) => {
        setIsSaving(false);
        setSaveMessage('File saved successfully!');
        setTimeout(() => setSaveMessage(null), 3000);
      })
      .catch((err) => {
        setIsSaving(false);
        setSaveMessage('Error saving file');
      });
  };

  const filteredFiles = fileList.filter((f) => f.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <div className="space-y-6 font-mono">
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-sm font-bold text-cyan-400 tracking-wider flex items-center gap-2">
            <Code2 className="w-4 h-4 text-cyan-400" />
            NUCLEAR PERFORMANCE ENGINE :: SOURCE CODE EXPLORER & EDITOR
          </h2>
          <span className="text-xs px-2.5 py-1 rounded bg-cyan-500/10 text-cyan-300 border border-cyan-500/30">
            Rust + R Multi-Language Engine Architecture
          </span>
        </div>
        <p className="text-xs text-slate-400">
          Browse, inspect, and edit the production-grade Rust core simulation engine, thermal-hydraulic solvers, safety envelope logic, and R analytics scripts.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 h-[650px] overflow-hidden">
        {/* File Tree Navigator */}
        <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 flex flex-col h-full overflow-hidden">
          <div className="relative mb-3">
            <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-slate-500" />
            <input
              type="text"
              placeholder="Search source files..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="flex-1 overflow-y-auto space-y-1 text-xs pr-1 scrollbar-thin scrollbar-thumb-slate-800">
            {filteredFiles.map((filePath) => {
              const isSelected = selectedFilePath === filePath;
              const fileName = filePath.split('/').pop() || filePath;
              const isRust = filePath.endsWith('.rs');
              const isR = filePath.endsWith('.R');

              return (
                <button
                  key={filePath}
                  onClick={() => setSelectedFilePath(filePath)}
                  className={`w-full text-left px-3 py-2 rounded-lg transition-all flex items-center space-x-2 ${
                    isSelected
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                  }`}
                >
                  <FileCode2 className={`w-3.5 h-3.5 ${isRust ? 'text-amber-400' : isR ? 'text-blue-400' : 'text-slate-500'}`} />
                  <span className="truncate">{fileName}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Editor & Viewer Area */}
        <div className="md:col-span-3 bg-slate-950 border border-slate-800 rounded-xl p-4 flex flex-col h-full overflow-hidden">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
            <div className="flex items-center space-x-2 text-xs font-bold text-slate-200">
              <Terminal className="w-4 h-4 text-cyan-400" />
              <span>{selectedFilePath}</span>
            </div>

            <div className="flex items-center space-x-2">
              {saveMessage && <span className="text-xs text-emerald-400 font-bold">{saveMessage}</span>}
              <button
                onClick={handleSave}
                disabled={isSaving || isLoadingContent}
                className="flex items-center space-x-2 px-3 py-1.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold rounded-lg text-xs transition-all disabled:opacity-50"
              >
                <Save className="w-3.5 h-3.5" />
                <span>{isSaving ? 'SAVING...' : 'SAVE FILE'}</span>
              </button>
            </div>
          </div>

          <div className="flex-1 overflow-hidden relative">
            {isLoadingContent ? (
              <div className="absolute inset-0 flex items-center justify-center bg-slate-950/80">
                <RefreshCw className="w-6 h-6 text-cyan-400 animate-spin" />
              </div>
            ) : (
              <textarea
                value={fileContent}
                onChange={(e) => setFileContent(e.target.value)}
                className="w-full h-full bg-slate-900 border border-slate-800 rounded-lg p-4 font-mono text-xs text-slate-100 leading-relaxed focus:outline-none focus:border-cyan-500/60 resize-none scrollbar-thin scrollbar-thumb-slate-700"
                spellCheck={false}
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
