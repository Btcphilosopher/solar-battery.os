import React from 'react';
import { CombustionBenchmarkItem } from '../types/nuclear';
import { Flame, ShieldCheck, Zap, Activity } from 'lucide-react';

interface CombustionBenchmarkProps {
  benchmarks: CombustionBenchmarkItem[];
}

export const CombustionBenchmark: React.FC<CombustionBenchmarkProps> = ({ benchmarks }) => {
  return (
    <div className="space-y-6 font-mono">
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-sm font-bold text-cyan-400 tracking-wider flex items-center gap-2">
            <Flame className="w-4 h-4 text-amber-400" />
            SECONDARY THERMAL GENERATION TECHNICAL BENCHMARK MODULE
          </h2>
          <span className="text-xs text-slate-400">Pure Physical & Thermodynamics Comparison</span>
        </div>
        <p className="text-xs text-slate-400">
          Compares nuclear station physical performance parameters with conventional combustion thermal generation assets (Coal, CCGT, Biomass).
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {benchmarks.map((item) => {
          const isNuclear = item.plant_type.includes('Nuclear') || item.plant_type.includes('PWR');

          return (
            <div
              key={item.plant_type}
              className={`p-5 rounded-xl border transition-all ${
                isNuclear
                  ? 'bg-slate-950 border-cyan-500/50 shadow-lg shadow-cyan-500/10'
                  : 'bg-slate-900/80 border-slate-800'
              }`}
            >
              <div className="flex items-center justify-between mb-3 border-b border-slate-800 pb-2">
                <span className="text-sm font-bold text-white">{item.plant_type}</span>
                {isNuclear && (
                  <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold">
                    PRIMARY PLANT
                  </span>
                )}
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <span className="text-slate-500 block">THERMAL EFFICIENCY</span>
                  <span className="font-bold text-cyan-400 text-sm">{item.thermal_efficiency_pct}%</span>
                </div>
                <div>
                  <span className="text-slate-500 block">FUEL ENERGY DENSITY</span>
                  <span className="font-bold text-amber-400 text-sm">{item.fuel_energy_density_mj_kg.toLocaleString()} MJ/kg</span>
                </div>
                <div>
                  <span className="text-slate-500 block">HEAT REJECTION / GWe</span>
                  <span className="font-bold text-rose-400 text-sm">{item.heat_rejection_mw_per_gwe} MW</span>
                </div>
                <div>
                  <span className="text-slate-500 block">AUXILIARY HOUSE CONSUMPTION</span>
                  <span className="font-bold text-amber-300 text-sm">{item.auxiliary_consumption_pct}%</span>
                </div>
                <div>
                  <span className="text-slate-500 block">CAPACITY FACTOR</span>
                  <span className="font-bold text-emerald-400 text-sm">{item.capacity_factor_pct}%</span>
                </div>
                <div>
                  <span className="text-slate-500 block">LOAD RAMP RATE</span>
                  <span className="font-bold text-blue-400 text-sm">{item.ramp_rate_pct_min}% / min</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
