import React from 'react';
import { PlantState } from '../types/nuclear';
import { Cpu, CheckCircle2, AlertTriangle, RefreshCw } from 'lucide-react';

interface DigitalTwinProps {
  plantState: PlantState;
}

export const DigitalTwin: React.FC<DigitalTwinProps> = ({ plantState }) => {
  const expectedNetMW = 1171.0;
  const actualNetMW = plantState.net_electrical_output_mwe;
  const optimisedNetMW = 1187.6;

  const deviationMW = actualNetMW - expectedNetMW;

  const parameters = [
    {
      name: 'Net Electrical Output',
      expected: '1,171.0 MWe',
      actual: `${actualNetMW.toFixed(1)} MWe`,
      optimised: `${optimisedNetMW.toFixed(1)} MWe`,
      delta: `${deviationMW >= 0 ? '+' : ''}${deviationMW.toFixed(1)} MWe`,
      status: Math.abs(deviationMW) < 2.0 ? 'NOMINAL' : deviationMW < 0 ? 'DEGRADED' : 'OPTIMISED',
    },
    {
      name: 'Thermal Efficiency',
      expected: '34.33%',
      actual: `${plantState.thermal_efficiency_pct.toFixed(2)}%`,
      optimised: '34.82%',
      delta: `${(plantState.thermal_efficiency_pct - 34.33).toFixed(2)}%`,
      status: plantState.thermal_efficiency_pct >= 34.3 ? 'NOMINAL' : 'DEGRADED',
    },
    {
      name: 'Condenser Pressure',
      expected: '3.60 kPa',
      actual: `${plantState.cooling.condenser_pressure_kpa.toFixed(2)} kPa`,
      optimised: '3.50 kPa',
      delta: `+${(plantState.cooling.condenser_pressure_kpa - 3.60).toFixed(2)} kPa`,
      status: plantState.cooling.condenser_pressure_kpa <= 4.0 ? 'NOMINAL' : 'ATTENTION',
    },
    {
      name: 'Auxiliary House Power',
      expected: '56.0 MWe',
      actual: `${plantState.electrical.auxiliary_load_mwe.toFixed(1)} MWe`,
      optimised: '52.2 MWe',
      delta: `+${(plantState.electrical.auxiliary_load_mwe - 56.0).toFixed(1)} MWe`,
      status: plantState.electrical.auxiliary_load_mwe <= 58.0 ? 'NOMINAL' : 'ATTENTION',
    },
  ];

  return (
    <div className="space-y-6 font-mono">
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-sm font-bold text-cyan-400 tracking-wider flex items-center gap-2">
            <Cpu className="w-4 h-4 text-cyan-400" />
            DIGITAL PERFORMANCE TWIN :: REAL-TIME MODEL VS TELEMETRY COMPARISON
          </h2>
          <span className="text-xs text-slate-400">Continuous Anomaly Detection Engine</span>
        </div>
        <p className="text-xs text-slate-400">
          Maintains a digital representation updated in real-time to detect physical deviations between expected engineering baseline and actual station telemetry.
        </p>
      </div>

      <div className="bg-slate-950 border border-slate-800 rounded-xl p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6 text-xs">
          <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
            <span className="text-slate-500 block mb-1">EXPECTED BASELINE MODEL</span>
            <span className="text-xl font-bold text-slate-200">1,171.0 MWe</span>
            <p className="text-[11px] text-slate-500 mt-1">Design thermal balance curve</p>
          </div>
          <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
            <span className="text-slate-500 block mb-1">ACTUAL PLANT TELEMETRY</span>
            <span className="text-xl font-bold text-cyan-400">{actualNetMW.toFixed(1)} MWe</span>
            <p className="text-[11px] text-slate-500 mt-1">Live grid meter telemetry</p>
          </div>
          <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
            <span className="text-slate-500 block mb-1">SAFE OPTIMISED TARGET</span>
            <span className="text-xl font-bold text-emerald-400">1,187.6 MWe</span>
            <p className="text-[11px] text-slate-500 mt-1">+16.6 MWe potential gain</p>
          </div>
        </div>

        {/* Detailed Comparison Matrix */}
        <div className="border border-slate-800 rounded-lg overflow-hidden">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-900 text-slate-400 border-b border-slate-800">
              <tr>
                <th className="p-3">PARAMETER</th>
                <th className="p-3">EXPECTED</th>
                <th className="p-3">ACTUAL</th>
                <th className="p-3">OPTIMISED</th>
                <th className="p-3">DEVIATION</th>
                <th className="p-3">TWIN STATUS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-200">
              {parameters.map((p) => (
                <tr key={p.name} className="hover:bg-slate-900/50">
                  <td className="p-3 font-bold text-white">{p.name}</td>
                  <td className="p-3 text-slate-400">{p.expected}</td>
                  <td className="p-3 text-cyan-400 font-bold">{p.actual}</td>
                  <td className="p-3 text-emerald-400 font-bold">{p.optimised}</td>
                  <td className="p-3 font-bold text-amber-400">{p.delta}</td>
                  <td className="p-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        p.status === 'NOMINAL' || p.status === 'OPTIMISED'
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                          : 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                      }`}
                    >
                      {p.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
