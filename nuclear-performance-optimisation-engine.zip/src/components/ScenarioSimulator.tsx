import React, { useState } from 'react';
import { ScenarioResult } from '../types/nuclear';
import { RAnalyticsEngine } from '../engine/rAnalyticsEngine';
import { Layers, Play, CheckCircle2, AlertTriangle, ArrowRight } from 'lucide-react';

interface ScenarioSimulatorProps {
  baselineNetMW: number;
  onRunScenario: (scenarioId: string) => void;
}

export const ScenarioSimulator: React.FC<ScenarioSimulatorProps> = ({
  baselineNetMW,
  onRunScenario,
}) => {
  const [selectedScenarioId, setSelectedScenarioId] = useState<string>('SCENARIO-BASELINE');

  const scenarios: ScenarioResult[] = RAnalyticsEngine.runScenarioMatrix(baselineNetMW);

  const activeScenario = scenarios.find((s) => s.scenario_id === selectedScenarioId) || scenarios[0];

  return (
    <div className="space-y-6 font-mono">
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-sm font-bold text-cyan-400 tracking-wider flex items-center gap-2">
            <Layers className="w-4 h-4 text-cyan-400" />
            TRANSIENT SCENARIO & DISTURBANCE SIMULATION MATRIX
          </h2>
          <span className="text-xs text-slate-400">Offline & Online Transient Analysis</span>
        </div>
        <p className="text-xs text-slate-400">
          Simulates environmental transients, fouling, blade erosion, and auxiliary load spikes to calculate resulting net electrical output and heat rejection impact.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Scenario Selection List */}
        <div className="space-y-3">
          <span className="text-xs text-slate-400 font-bold block mb-2">SELECT TRANSIENT SCENARIO:</span>
          {scenarios.map((sc) => {
            const isSelected = selectedScenarioId === sc.scenario_id;

            return (
              <button
                key={sc.scenario_id}
                onClick={() => {
                  setSelectedScenarioId(sc.scenario_id);
                  onRunScenario(sc.scenario_id);
                }}
                className={`w-full text-left p-4 rounded-xl border transition-all ${
                  isSelected
                    ? 'bg-cyan-500/15 border-cyan-400 text-cyan-300 ring-1 ring-cyan-400'
                    : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-bold text-white">{sc.scenario_name}</span>
                </div>
                <div className="flex items-center justify-between text-xs mt-2">
                  <span className="text-slate-400">Net Output:</span>
                  <span className="font-bold text-cyan-400">{sc.net_mwe.toFixed(1)} MWe</span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Selected Scenario Detailed Physics Outcome */}
        <div className="md:col-span-2 bg-slate-950 border border-slate-800 rounded-xl p-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
            <div>
              <span className="text-[10px] text-slate-500 font-bold block">SCENARIO ANALYSIS OUTCOME</span>
              <h3 className="text-sm font-bold text-white">{activeScenario.scenario_name}</h3>
            </div>
            <div className="text-right">
              <span className="text-xs text-slate-500 block">NET MW DELTA</span>
              <span
                className={`text-lg font-bold ${
                  activeScenario.delta_from_baseline_mwe >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {activeScenario.delta_from_baseline_mwe >= 0 ? '+' : ''}
                {activeScenario.delta_from_baseline_mwe.toFixed(1)} MWe
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs mb-6">
            <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span className="text-slate-500 block">GROSS GENERATION</span>
              <span className="text-lg font-bold text-blue-400">{activeScenario.gross_mwe.toFixed(1)} MWe</span>
            </div>
            <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span className="text-slate-500 block">NET GRID OUTPUT</span>
              <span className="text-lg font-bold text-cyan-400">{activeScenario.net_mwe.toFixed(1)} MWe</span>
            </div>
            <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span className="text-slate-500 block">THERMAL EFFICIENCY</span>
              <span className="text-lg font-bold text-emerald-400">{activeScenario.efficiency_pct.toFixed(2)}%</span>
            </div>
            <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span className="text-slate-500 block">AUXILIARY HOUSE LOAD</span>
              <span className="text-lg font-bold text-amber-400">{activeScenario.auxiliary_load_mwe.toFixed(1)} MWe</span>
            </div>
            <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
              <span className="text-slate-500 block">CONDENSER REJECTED HEAT</span>
              <span className="text-lg font-bold text-rose-400">{activeScenario.rejected_heat_mw.toFixed(1)} MW</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
