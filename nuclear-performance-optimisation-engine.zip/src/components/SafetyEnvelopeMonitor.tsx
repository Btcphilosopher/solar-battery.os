import React from 'react';
import { SafetyLimitCheck } from '../types/nuclear';
import { ShieldCheck, AlertTriangle, Lock, CheckCircle2, AlertOctagon } from 'lucide-react';

interface SafetyEnvelopeMonitorProps {
  safetyChecks: SafetyLimitCheck[];
}

export const SafetyEnvelopeMonitor: React.FC<SafetyEnvelopeMonitorProps> = ({ safetyChecks }) => {
  return (
    <div className="space-y-6 font-mono">
      {/* Architecture Separation Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
        <div className="flex items-center space-x-3 mb-3">
          <div className="p-2 bg-emerald-500/10 border border-emerald-500/30 rounded-lg text-emerald-400">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white tracking-wider">
              SAFETY-FIRST ARCHITECTURE :: INDEPENDENT SAFETY ENVELOPE
            </h2>
            <p className="text-xs text-slate-400">
              Read-Only Decision Support System. The optimiser cannot bypass or replace Reactor Protection Systems (RPS), Interlocks, or Safety Valves.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs mt-4">
          <div className="p-3 bg-rose-950/40 border border-rose-800/60 rounded-lg text-rose-300">
            <span className="font-bold block text-rose-400 mb-1">1. SAFETY ENVELOPE</span>
            <span className="text-[11px] block">RPS Trip Limits, Emergency Core Cooling System (ECCS), DNBR &ge; 1.30. Hard code boundary.</span>
          </div>
          <div className="p-3 bg-amber-950/40 border border-amber-800/60 rounded-lg text-amber-300">
            <span className="font-bold block text-amber-400 mb-1">2. OPERATING ENVELOPE</span>
            <span className="text-[11px] block">Technical Specifications & Operating Limits. Normal steady state parameter boundaries.</span>
          </div>
          <div className="p-3 bg-cyan-950/40 border border-cyan-800/60 rounded-lg text-cyan-300">
            <span className="font-bold block text-cyan-400 mb-1">3. OPTIMISATION ENGINE</span>
            <span className="text-[11px] block">Safe space evaluation. Searches for net electrical MW gains within the operating envelope.</span>
          </div>
          <div className="p-3 bg-emerald-950/40 border border-emerald-800/60 rounded-lg text-emerald-300">
            <span className="font-bold block text-emerald-400 mb-1">4. RECOMMENDATIONS</span>
            <span className="text-[11px] block">Advisory output for licensed senior reactor operators (SRO) review.</span>
          </div>
        </div>
      </div>

      {/* Live Safety Checks Grid */}
      <div className="bg-slate-950 border border-slate-800 rounded-xl p-6">
        <h3 className="text-xs font-bold text-cyan-400 tracking-wider mb-4 flex items-center justify-between">
          <span>REAL-TIME SAFETY INSTRUMENTATION ENVELOPE CHECKS</span>
          <span className="text-slate-500 font-normal">All Interlocks Active & Verified</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {safetyChecks.map((check) => {
            const isOptimal = check.status === 'OPTIMAL';
            const isWarning = check.status === 'WARNING';

            return (
              <div
                key={check.parameter}
                className={`p-4 rounded-xl border ${
                  isOptimal
                    ? 'bg-slate-900/90 border-slate-800'
                    : isWarning
                    ? 'bg-amber-950/30 border-amber-800/80'
                    : 'bg-rose-950/40 border-rose-800'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-slate-200">{check.parameter}</span>
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                      isOptimal
                        ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                        : isWarning
                        ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                        : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                    }`}
                  >
                    {check.status}
                  </span>
                </div>

                <div className="flex items-baseline justify-between mb-2">
                  <div className="text-xl font-bold text-white">
                    {check.current_value} <span className="text-xs font-normal text-slate-400">{check.unit}</span>
                  </div>
                  <div className="text-xs text-slate-400">
                    Trip Limit: <span className="text-rose-400 font-bold">{check.trip_threshold} {check.unit}</span>
                  </div>
                </div>

                {/* Safety Margin Gauge Bar */}
                <div>
                  <div className="flex justify-between text-[11px] text-slate-500 mb-1">
                    <span>Safety Margin to Trip</span>
                    <span className="font-bold text-emerald-400">{check.margin_pct}% Margin</span>
                  </div>
                  <div className="w-full bg-slate-950 rounded-full h-2 border border-slate-800 overflow-hidden">
                    <div
                      className={`h-2 rounded-full transition-all ${
                        check.margin_pct > 25
                          ? 'bg-emerald-400'
                          : check.margin_pct > 10
                          ? 'bg-amber-400'
                          : 'bg-rose-500'
                      }`}
                      style={{ width: `${Math.min(100, Math.max(5, check.margin_pct))}%` }}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
