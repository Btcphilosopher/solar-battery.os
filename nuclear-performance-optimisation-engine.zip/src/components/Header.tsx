import React from 'react';
import { Activity, ShieldCheck, Zap, BarChart3, GitFork, Cpu, Flame, Code2, Layers } from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  plantStatus: 'OPTIMAL' | 'WARNING' | 'CRITICAL';
  netMW: number;
  efficiencyPct: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  plantStatus,
  netMW,
  efficiencyPct,
}) => {
  const tabs = [
    { id: 'overview', label: 'Command Center', icon: Activity },
    { id: 'conversion_chain', label: 'Conversion Chain', icon: Flame },
    { id: 'safety_envelope', label: 'Safety Envelope', icon: ShieldCheck },
    { id: 'optimiser', label: 'Reactive Optimiser', icon: Zap },
    { id: 'loss_tree', label: 'Energy Loss Tree', icon: GitFork },
    { id: 'digital_twin', label: 'Digital Twin', icon: Cpu },
    { id: 'r_analytics', label: 'R Analytics & Stats', icon: BarChart3 },
    { id: 'scenarios', label: 'Scenarios & Transients', icon: Layers },
    { id: 'combustion', label: 'Combustion Benchmark', icon: Flame },
    { id: 'codebase', label: 'Rust + R Codebase', icon: Code2 },
  ];

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-slate-100 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-cyan-500/10 border border-cyan-500/30 rounded-xl text-cyan-400 shadow-sm">
              <Zap className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-lg font-bold tracking-tight text-white font-mono">
                  NUCLEAR PERFORMANCE OPTIMISATION ENGINE
                </h1>
                <span className="text-xs px-2 py-0.5 rounded font-mono font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                  Rust + R v1.0
                </span>
              </div>
              <p className="text-xs text-slate-400 font-mono">
                Production-Grade Physical Engineering & Reactive Decision Support System
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-4 bg-slate-950/80 p-2 rounded-xl border border-slate-800 text-xs font-mono">
            <div className="flex items-center space-x-2 px-2.5 py-1 rounded-lg bg-slate-900">
              <span className="text-slate-400">STATUS:</span>
              <span
                className={`font-bold flex items-center gap-1.5 ${
                  plantStatus === 'OPTIMAL'
                    ? 'text-emerald-400'
                    : plantStatus === 'WARNING'
                    ? 'text-amber-400'
                    : 'text-rose-400'
                }`}
              >
                <span
                  className={`w-2 h-2 rounded-full ${
                    plantStatus === 'OPTIMAL'
                      ? 'bg-emerald-400 animate-ping'
                      : plantStatus === 'WARNING'
                      ? 'bg-amber-400 animate-ping'
                      : 'bg-rose-400 animate-ping'
                  }`}
                />
                {plantStatus}
              </span>
            </div>

            <div className="flex items-center space-x-2 px-2.5 py-1 rounded-lg bg-slate-900">
              <span className="text-slate-400">NET OUTPUT:</span>
              <span className="font-bold text-cyan-400">{netMW.toFixed(1)} MWe</span>
            </div>

            <div className="flex items-center space-x-2 px-2.5 py-1 rounded-lg bg-slate-900">
              <span className="text-slate-400">THERMAL EFF:</span>
              <span className="font-bold text-emerald-400">{efficiencyPct.toFixed(2)}%</span>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex items-center space-x-1 mt-3 overflow-x-auto pb-1 scrollbar-thin scrollbar-thumb-slate-700">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/40 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-cyan-400' : 'text-slate-400'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
