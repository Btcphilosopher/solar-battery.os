import React from 'react';
import { PlantState } from '../types/nuclear';
import { Flame, Zap, Gauge, Cpu, RefreshCw, AlertTriangle, Play, Pause } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface CommandCenterProps {
  plantState: PlantState;
  history: PlantState[];
  isSimulating: boolean;
  onToggleSimulation: () => void;
  onStepOne: () => void;
  onResetState: () => void;
}

export const CommandCenter: React.FC<CommandCenterProps> = ({
  plantState,
  history,
  isSimulating,
  onToggleSimulation,
  onStepOne,
  onResetState,
}) => {
  const chartData = history.slice(-30).map((s, idx) => ({
    time: `t-${history.length - idx}s`,
    netMW: Number(s.net_electrical_output_mwe.toFixed(1)),
    thermalMW: Number(s.reactor.thermal_output_mw.toFixed(1)),
    efficiency: Number(s.thermal_efficiency_pct.toFixed(2)),
    auxMW: Number(s.electrical.auxiliary_load_mwe.toFixed(1)),
    rejectedMW: Number(s.cooling.rejected_heat_mw.toFixed(1)),
  }));

  const perfRatio = (plantState.thermal_efficiency_pct / 36.0) * 100;

  return (
    <div className="space-y-6">
      {/* Action Controls Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 p-4 rounded-xl">
        <div className="flex items-center space-x-3">
          <div className="w-3 h-3 rounded-full bg-cyan-400 animate-ping" />
          <span className="font-mono text-sm text-slate-200 font-semibold">
            Real-Time Plant Telemetry & Physical State Solver
          </span>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={onToggleSimulation}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-mono text-xs font-bold transition-all ${
              isSimulating
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 hover:bg-amber-500/30'
                : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 hover:bg-cyan-500/30'
            }`}
          >
            {isSimulating ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            <span>{isSimulating ? 'PAUSE ENGINE' : 'LIVE CYCLE ENGINE'}</span>
          </button>
          <button
            onClick={onStepOne}
            disabled={isSimulating}
            className="flex items-center space-x-2 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-mono text-xs font-medium disabled:opacity-50"
          >
            <span>STEP (1s)</span>
          </button>
          <button
            onClick={onResetState}
            className="flex items-center space-x-2 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 font-mono text-xs font-medium"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>RESET NOMINAL</span>
          </button>
        </div>
      </div>

      {/* Main Terminal Command Center Box */}
      <div className="bg-slate-950 border border-slate-800 rounded-xl p-6 font-mono text-slate-200 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-4 opacity-10 pointer-events-none">
          <Cpu className="w-48 h-48 text-cyan-400" />
        </div>

        <div className="border-b border-slate-800 pb-3 mb-6 flex items-center justify-between">
          <h2 className="text-sm font-bold text-cyan-400 tracking-wider flex items-center gap-2">
            <Gauge className="w-4 h-4" />
            NUCLEAR PERFORMANCE ENGINE :: PRIMARY TECHNICAL COMMAND CENTER
          </h2>
          <span className="text-xs text-slate-500">TIMESTAMP: {plantState.timestamp_utc}</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-lg">
            <div className="text-slate-400 text-xs flex items-center justify-between mb-1">
              <span>THERMAL INPUT</span>
              <Flame className="w-3.5 h-3.5 text-amber-400" />
            </div>
            <div className="text-2xl font-bold text-amber-400">
              {plantState.reactor.thermal_output_mw.toFixed(1)} <span className="text-xs font-normal text-slate-400">MWth</span>
            </div>
            <div className="text-[11px] text-slate-500 mt-1">Core Delta T: {plantState.reactor.core_delta_t_c.toFixed(1)} °C</div>
          </div>

          <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-lg">
            <div className="text-slate-400 text-xs flex items-center justify-between mb-1">
              <span>GROSS OUTPUT</span>
              <Zap className="w-3.5 h-3.5 text-blue-400" />
            </div>
            <div className="text-2xl font-bold text-blue-400">
              {plantState.generator.gross_output_mwe.toFixed(1)} <span className="text-xs font-normal text-slate-400">MWe</span>
            </div>
            <div className="text-[11px] text-slate-500 mt-1">Gen Efficiency: {plantState.generator.electrical_efficiency_pct.toFixed(1)}%</div>
          </div>

          <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-lg">
            <div className="text-slate-400 text-xs flex items-center justify-between mb-1">
              <span>NET GRID OUTPUT</span>
              <Zap className="w-3.5 h-3.5 text-emerald-400" />
            </div>
            <div className="text-2xl font-bold text-emerald-400">
              {plantState.net_electrical_output_mwe.toFixed(1)} <span className="text-xs font-normal text-slate-400">MWe</span>
            </div>
            <div className="text-[11px] text-slate-500 mt-1">Grid Target: 1,171.0 MWe</div>
          </div>

          <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-lg">
            <div className="text-slate-400 text-xs flex items-center justify-between mb-1">
              <span>THERMAL EFFICIENCY</span>
              <Gauge className="w-3.5 h-3.5 text-cyan-400" />
            </div>
            <div className="text-2xl font-bold text-cyan-400">
              {plantState.thermal_efficiency_pct.toFixed(2)} <span className="text-xs font-normal text-slate-400">%</span>
            </div>
            <div className="text-[11px] text-slate-500 mt-1">Carnot Limit Ref: 42.4%</div>
          </div>
        </div>

        {/* Secondary Parameters Matrix */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-900/60 p-4 rounded-lg border border-slate-800 text-xs mb-6">
          <div>
            <span className="text-slate-500 block">TURBINE EFFICIENCY</span>
            <span className="text-cyan-300 font-bold text-sm">{plantState.turbine.isentropic_efficiency_pct.toFixed(1)}%</span>
          </div>
          <div>
            <span className="text-slate-500 block">AUXILIARY LOAD</span>
            <span className="text-amber-300 font-bold text-sm">{plantState.electrical.auxiliary_load_mwe.toFixed(1)} MWe</span>
          </div>
          <div>
            <span className="text-slate-500 block">HEAT REJECTION</span>
            <span className="text-rose-300 font-bold text-sm">{plantState.cooling.rejected_heat_mw.toFixed(1)} MW</span>
          </div>
          <div>
            <span className="text-slate-500 block">ENERGY CONSERVATION DELTA</span>
            <span className="text-emerald-400 font-bold text-sm">{plantState.energy_balance_delta_mw.toFixed(4)} MW</span>
          </div>
        </div>

        {/* Ascii Visual Meter & System Status */}
        <div className="space-y-4">
          <div>
            <div className="flex justify-between text-xs text-slate-400 mb-1">
              <span>PLANT PERFORMANCE SCORE</span>
              <span className="font-bold text-cyan-400">{perfRatio.toFixed(1)}% of Design Target</span>
            </div>
            <div className="w-full bg-slate-900 rounded-full h-3 border border-slate-800 overflow-hidden">
              <div
                className="bg-gradient-to-r from-cyan-500 to-emerald-400 h-3 rounded-full transition-all duration-300"
                style={{ width: `${Math.min(100, perfRatio)}%` }}
              />
            </div>
          </div>

          <div className="border border-slate-800 rounded-lg p-3 bg-slate-900/40">
            <span className="text-xs text-slate-400 font-bold block mb-2">SUBSYSTEM HEALTH REGIME STATUS:</span>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
              <div className="flex items-center justify-between p-2 rounded bg-slate-900 border border-slate-800">
                <span className="text-slate-400">THERMAL</span>
                <span className="text-emerald-400 font-bold">OPTIMAL</span>
              </div>
              <div className="flex items-center justify-between p-2 rounded bg-slate-900 border border-slate-800">
                <span className="text-slate-400">TURBINE</span>
                <span className="text-emerald-400 font-bold">GOOD</span>
              </div>
              <div className="flex items-center justify-between p-2 rounded bg-slate-900 border border-slate-800">
                <span className="text-slate-400">GENERATOR</span>
                <span className="text-emerald-400 font-bold">GOOD</span>
              </div>
              <div className="flex items-center justify-between p-2 rounded bg-slate-900 border border-slate-800">
                <span className="text-slate-400">COOLING</span>
                <span className={`font-bold ${plantState.cooling.condenser_pressure_kpa > 4.0 ? 'text-amber-400' : 'text-emerald-400'}`}>
                  {plantState.cooling.condenser_pressure_kpa > 4.0 ? 'DEGRADED' : 'OPTIMAL'}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Trend Graph */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-mono font-bold text-slate-200">
            REAL-TIME PHYSICAL TELEMETRY TREND (LAST {chartData.length} TIMESTEPS)
          </h3>
          <span className="text-xs font-mono text-slate-500">1.0s Resolution Deterministic Solver</span>
        </div>

        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="colorNet" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#06b6d4" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="time" stroke="#64748b" tick={{ fontSize: 10 }} />
              <YAxis domain={['auto', 'auto']} stroke="#64748b" tick={{ fontSize: 10 }} />
              <Tooltip
                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '12px' }}
              />
              <Area type="monotone" dataKey="netMW" stroke="#06b6d4" fillOpacity={1} fill="url(#colorNet)" name="Net Output (MWe)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
