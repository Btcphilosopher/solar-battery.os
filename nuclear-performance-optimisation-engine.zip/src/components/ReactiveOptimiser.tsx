import React, { useState } from 'react';
import { OptimiserRecommendation } from '../types/nuclear';
import { Zap, CheckCircle2, ShieldAlert, ArrowUpRight, Check, Sliders } from 'lucide-react';

interface ReactiveOptimiserProps {
  recommendations: OptimiserRecommendation[];
  onApplyRecommendation: (rec: OptimiserRecommendation) => void;
}

export const ReactiveOptimiser: React.FC<ReactiveOptimiserProps> = ({
  recommendations,
  onApplyRecommendation,
}) => {
  const [appliedIds, setAppliedIds] = useState<string[]>([]);

  const handleApply = (rec: OptimiserRecommendation) => {
    onApplyRecommendation(rec);
    if (!appliedIds.includes(rec.id)) {
      setAppliedIds([...appliedIds, rec.id]);
    }
  };

  return (
    <div className="space-y-6 font-mono">
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-sm font-bold text-cyan-400 tracking-wider flex items-center gap-2">
            <Zap className="w-4 h-4 text-cyan-400" />
            REACTIVE PERFORMANCE OPTIMISER :: RANKED SAFE RECOMMENDATIONS
          </h2>
          <span className="text-xs px-2.5 py-1 rounded bg-cyan-500/10 text-cyan-300 border border-cyan-500/30">
            {recommendations.length} Active Opportunities Identified
          </span>
        </div>
        <p className="text-xs text-slate-400">
          Evaluates alternative operating states within the explicit safe operating envelope. Ranks candidates by Net Electrical Output gain + Thermal Efficiency while ensuring Risk Score &lt; 4.0/10.
        </p>
      </div>

      <div className="space-y-4">
        {recommendations.map((rec, idx) => {
          const isApplied = appliedIds.includes(rec.id);

          return (
            <div
              key={rec.id}
              className={`bg-slate-950 border rounded-xl p-5 transition-all ${
                isApplied
                  ? 'border-emerald-500/60 bg-emerald-950/10'
                  : 'border-slate-800 hover:border-cyan-500/40'
              }`}
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-3">
                <div className="flex items-start space-x-3">
                  <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-cyan-400 font-bold text-xs">
                    #{idx + 1}
                  </div>
                  <div>
                    <div className="flex items-center space-x-2">
                      <h3 className="text-sm font-bold text-white">{rec.title}</h3>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-slate-900 text-slate-400 border border-slate-800">
                        {rec.subsystem}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 mt-1">{rec.action_description}</p>
                  </div>
                </div>

                <div className="flex items-center space-x-3 border-t md:border-t-0 pt-3 md:pt-0 border-slate-800">
                  <div className="text-right">
                    <div className="text-lg font-extrabold text-emerald-400">+{rec.net_mw_gain.toFixed(2)} MWe</div>
                    <div className="text-[10px] text-slate-500">+{rec.efficiency_gain_pct.toFixed(3)}% Thermal Eff</div>
                  </div>

                  <button
                    onClick={() => handleApply(rec)}
                    disabled={isApplied}
                    className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-xs font-bold transition-all ${
                      isApplied
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 shadow-md shadow-cyan-500/20'
                    }`}
                  >
                    {isApplied ? <Check className="w-4 h-4" /> : <ArrowUpRight className="w-4 h-4" />}
                    <span>{isApplied ? 'OPTIMISATION APPLIED' : 'APPLY RECOMMENDATION'}</span>
                  </button>
                </div>
              </div>

              {/* Parameter Modification Specs */}
              <div className="bg-slate-900/80 border border-slate-800/80 rounded-lg p-3 text-xs">
                <span className="text-slate-500 text-[11px] font-bold block mb-2 flex items-center gap-1.5">
                  <Sliders className="w-3.5 h-3.5 text-cyan-400" />
                  PHYSICAL PARAMETER ADJUSTMENT SPECIFICATIONS:
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                  {rec.parameter_modifications.map(([param, curr, prop]) => (
                    <div key={param} className="flex items-center justify-between bg-slate-950 p-2 rounded border border-slate-800/60">
                      <span className="text-slate-400">{param}:</span>
                      <span className="text-slate-200 font-bold">
                        {curr} &rarr; <span className="text-emerald-400">{prop}</span>
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
