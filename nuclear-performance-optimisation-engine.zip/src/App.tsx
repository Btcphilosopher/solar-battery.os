import React, { useState, useEffect, useRef } from 'react';
import { PlantState, OptimiserRecommendation, LossTreeNode, SafetyLimitCheck, CombustionBenchmarkItem } from './types/nuclear';
import { Header } from './components/Header';
import { CommandCenter } from './components/CommandCenter';
import { EnergyConversionChain } from './components/EnergyConversionChain';
import { SafetyEnvelopeMonitor } from './components/SafetyEnvelopeMonitor';
import { ReactiveOptimiser } from './components/ReactiveOptimiser';
import { LiveLossTree } from './components/LiveLossTree';
import { DigitalTwin } from './components/DigitalTwin';
import { RAnalyticsPanel } from './components/RAnalyticsPanel';
import { ScenarioSimulator } from './components/ScenarioSimulator';
import { CombustionBenchmark } from './components/CombustionBenchmark';
import { CodebaseExplorer } from './components/CodebaseExplorer';
import { NuclearPhysicsEngine } from './engine/physicsEngine';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [engine] = useState<NuclearPhysicsEngine>(() => new NuclearPhysicsEngine());
  const [plantState, setPlantState] = useState<PlantState>(() => engine.getPlantState());
  const [history, setHistory] = useState<PlantState[]>([engine.getPlantState()]);
  const [isSimulating, setIsSimulating] = useState<boolean>(true);
  const [recommendations, setRecommendations] = useState<OptimiserRecommendation[]>([]);
  const [lossTree, setLossTree] = useState<LossTreeNode>(() => engine.getEnergyLossTree());
  const [safetyChecks, setSafetyChecks] = useState<SafetyLimitCheck[]>(() => engine.getSafetyLimitsChecks());
  const [benchmarks, setBenchmarks] = useState<CombustionBenchmarkItem[]>(() => engine.getCombustionBenchmarks());

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Update derived views
  const updateDerivedViews = (newState: PlantState) => {
    setPlantState(newState);
    setHistory((prev) => [...prev.slice(-100), newState]);
    setRecommendations(engine.getOptimiserRecommendations());
    setLossTree(engine.getEnergyLossTree());
    setSafetyChecks(engine.getSafetyLimitsChecks());
  };

  // Continuous simulation loop
  useEffect(() => {
    if (isSimulating) {
      timerRef.current = setInterval(() => {
        const newState = engine.stepSimulation(1.0);
        updateDerivedViews(newState);
      }, 1000);
    } else if (timerRef.current) {
      clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isSimulating, engine]);

  const handleToggleSimulation = () => setIsSimulating((prev) => !prev);

  const handleStepOne = () => {
    const newState = engine.stepSimulation(1.0);
    updateDerivedViews(newState);
  };

  const handleResetState = () => {
    const freshState = engine.createBaselineState();
    updateDerivedViews(freshState);
  };

  const handleApplyRecommendation = (rec: OptimiserRecommendation) => {
    // Apply recommendation parameter modifications to physics engine state
    rec.parameter_modifications.forEach(([param, , proposed]) => {
      if (param === 'condenser_pressure_kpa') {
        engine.getPlantState().cooling.condenser_pressure_kpa = proposed;
      } else if (param === 'feedwater_temp_c') {
        engine.getPlantState().thermal.feedwater_temp_c = proposed;
      } else if (param === 'auxiliary_load_mwe') {
        engine.getPlantState().electrical.auxiliary_load_mwe = proposed;
      }
    });

    const newState = engine.stepSimulation(1.0);
    updateDerivedViews(newState);
  };

  const handleRunScenario = (scenarioId: string) => {
    if (scenarioId === 'SCENARIO-SUMMER-HEAT') {
      engine.stepSimulation(1.0, { ambientTempC: 32.0 });
    } else if (scenarioId === 'SCENARIO-COND-FOULING') {
      engine.stepSimulation(1.0, { condenserFouling: 0.30 });
    } else if (scenarioId === 'SCENARIO-TURBINE-EROSION') {
      engine.stepSimulation(1.0, { bladeDegradation: 0.03 });
    } else {
      engine.stepSimulation(1.0, { ambientTempC: 18.0, condenserFouling: 0.0, bladeDegradation: 0.0 });
    }
    updateDerivedViews(engine.getPlantState());
  };

  // Overall Plant Status
  const hasTripped = safetyChecks.some((c) => c.status === 'TRIPPED' || c.status === 'CRITICAL');
  const hasWarning = safetyChecks.some((c) => c.status === 'WARNING');
  const plantStatus = hasTripped ? 'CRITICAL' : hasWarning ? 'WARNING' : 'OPTIMAL';

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-slate-950">
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        plantStatus={plantStatus}
        netMW={plantState.net_electrical_output_mwe}
        efficiencyPct={plantState.thermal_efficiency_pct}
      />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {activeTab === 'overview' && (
          <CommandCenter
            plantState={plantState}
            history={history}
            isSimulating={isSimulating}
            onToggleSimulation={handleToggleSimulation}
            onStepOne={handleStepOne}
            onResetState={handleResetState}
          />
        )}

        {activeTab === 'conversion_chain' && <EnergyConversionChain plantState={plantState} />}

        {activeTab === 'safety_envelope' && <SafetyEnvelopeMonitor safetyChecks={safetyChecks} />}

        {activeTab === 'optimiser' && (
          <ReactiveOptimiser
            recommendations={recommendations}
            onApplyRecommendation={handleApplyRecommendation}
          />
        )}

        {activeTab === 'loss_tree' && <LiveLossTree lossTree={lossTree} />}

        {activeTab === 'digital_twin' && <DigitalTwin plantState={plantState} />}

        {activeTab === 'r_analytics' && (
          <RAnalyticsPanel
            netMW={plantState.net_electrical_output_mwe}
            thermalMW={plantState.reactor.thermal_output_mw}
          />
        )}

        {activeTab === 'scenarios' && (
          <ScenarioSimulator
            baselineNetMW={plantState.net_electrical_output_mwe}
            onRunScenario={handleRunScenario}
          />
        )}

        {activeTab === 'combustion' && <CombustionBenchmark benchmarks={benchmarks} />}

        {activeTab === 'codebase' && <CodebaseExplorer />}
      </main>

      <footer className="bg-slate-900 border-t border-slate-800 py-4 font-mono text-xs text-slate-400">
        <div className="max-w-7xl mx-auto px-4 text-center">
          NUCLEAR PERFORMANCE OPTIMISATION ENGINE &bull; RUST + R ARCHITECTURE &bull; ALL CALCULATIONS BOUND BY HARD SAFETY ENVELOPES
        </div>
      </footer>
    </div>
  );
}
