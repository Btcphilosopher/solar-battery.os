# TURBOFLUX

**Steam Turbine Digital Twin and Energy Optimisation Engine**

TURBOFLUX is a research-grade Python simulator that answers one question:

> Given a steam supply and a turbine-generator architecture, what combination
> of thermodynamic and mechanical operating parameters produces the greatest
> practical **net electrical output**, without violating any safety limit?

It is not a dashboard. It is a physics-based digital twin of the full energy
conversion chain — **steam source → boiler/superheater → control valve →
nozzle → turbine stages → shaft → gearbox → generator → electrical output** —
wired to a constrained, multi-objective optimisation engine built on
`scipy.optimize`.

The central philosophy: **maximum RPM is not automatically maximum power**,
and **more rotor mass does not create energy**. TURBOFLUX exists to find the
real optimum, not the obvious guess.

## Quick start

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python main.py            # quick end-to-end study (~3-5 minutes)
python main.py --thorough # larger optimiser/Monte-Carlo/Pareto budgets (much slower)
pytest                    # run the test suite
```

Outputs (CSV sweeps, PNG plots, an HTML Sankey diagram, a PNG dashboard, and
a text final report) are written to `turboflux_output/`.

## Why is a `simulate()` call ~150-200 ms?

Every steady-state evaluation calls the IAPWS-IF97 steam property routines
dozens of times (once or twice per turbine stage, per condenser fixed-point
iteration). That is the honest cost of using an industry-standard property
formulation instead of an invented polynomial fit. `main.py --quick` (the
default) keeps the optimiser/Monte-Carlo/Pareto sample budgets small enough
to finish in a few minutes; `--thorough` trades runtime for search quality.

## Data provenance

Every number in TURBOFLUX is tagged with where it came from
(`core/state.py::DataProvenance`):

| Tag | Meaning |
|---|---|
| `MEASURED` | Real plant instrumentation (no live SCADA feed in this offline build - the type exists for a future adapter) |
| `ESTIMATED` | Inferred via the digital twin's state estimator (a complementary filter blending simulated telemetry with the model) |
| `MODELLED` | Computed from first-principles/correlation physics given known inputs |
| `SIMULATED` | Produced by driving the simulation engine forward |
| `OPTIMISED` | The output of an optimisation search - a *candidate*, not yet validated as safe by a human |
| `PREDICTED` | A forecast of a future state |

Mixing these silently is treated as a bug, not a shortcut - see
`Tagged.assert_provenance()`.

## Safety policy

Section 27 of the spec, enforced in code: **TURBOFLUX never automatically
controls real machinery**, and every optimisation candidate is checked
against the plant's `SafetyLimits` (`core/configuration.py`) via
`optimisation/constraints.py`. A candidate that violates a limit is
**rejected**, never relaxed to claim more power. The digital twin's
`recommend()` output is explicitly labelled a recommendation for a qualified
engineer to review - see `digital_twin/prediction.py::Recommendation.disclaimer`.

## Project layout

```
core/            configuration, state/provenance types, the central engine, clock, transient simulation
thermodynamics/  IAPWS-IF97 steam properties, isentropic/actual expansion, cycle energy balance
turbine/         nozzle, blade-speed-ratio, multi-stage expansion, losses, efficiency aggregation
mechanical/      shaft stress, bearings, simplified Jeffcott-rotor vibration, inertia/spin-up, gearbox
generator/       generator efficiency curve, electrical quantities, grid synchronous-speed compliance
thermal/         heat transfer, cooling water, condenser (solved via a 1-D root find), temperature effects
optimisation/    objectives (7 modes), constraints, parameter sweeps, sensitivity, Pareto, Monte Carlo, the optimiser
digital_twin/    twin state, simulated-telemetry state estimator, calibration (least-squares), recommendations
economics/       fuel cost, maintenance cost, operating cost, revenue/margin
analytics/       KPIs, loss/bottleneck breakdown, baseline-vs-optimised + energy-balance reports, what-if engine
visualisation/   matplotlib/plotly plots: RPM sweeps, thermodynamic plots, optimisation landscape, dashboard, Sankey
examples/        the baseline 30 MW-class turbine used throughout
tests/           pytest suite: thermodynamics, energy conservation, mechanical, generator, optimisation
main.py          runs the full section-25 study end to end
```

## Key modelling choices (read before trusting a number)

- **Steam properties**: IAPWS-IF97 via the `iapws` package - not an invented
  correlation.
- **Turbine staging**: the HP/IP/LP sections are each represented by several
  *elemental* pressure stages (see `examples/baseline_turbine.py`) because a
  single stage per section would over-expand the flow for a ~1700:1 overall
  pressure ratio and produce unrealistic nozzle velocities relative to blade
  speed. A single constant rotor (blade) diameter is used for the whole
  turbine - real machines flare the LP diameter; this is a documented
  simplification.
- **Blade-speed utilisation**: stage efficiency is scaled by a smooth
  Gaussian-type penalty around the classical optimal blade-speed ratio
  (u/c1 ≈ 0.5 impulse, up to ≈1.0 for higher-reaction stages) - this is the
  concrete mechanism behind "max RPM ≠ max power".
- **Vibration**: a single-mass Jeffcott-rotor model (`mechanical/vibration.py`)
  - explicitly *not* a full finite-element rotordynamic analysis.
- **Condenser**: solved as a 1-D root find (`scipy.optimize.brentq`) balancing
  steam-side condensation heat against cooling-water-side LMTD heat transfer;
  the *achieved* condenser pressure (`SystemState.achieved_condenser_pressure_pa`)
  can differ from the operating point's requested/target value and is what
  actually drives the turbine expansion and the feasibility check.
- **Energy balance**: `core/engine.py` derives every loss term from the same
  h1-h2-h3-h4 Rankine identity (including feed-pump work), so
  `SystemState.energy_balance_residual_w` is a genuine consistency check, not
  a cosmetic number - a broken accounting path will show up there and in
  `optimisation/constraints.py`.
- **No regenerative feedwater heating / reheat**: a single boiler pass, single
  feed pump. A clearly flagged simplification, not a hidden one.
- **Rotor mass vs energy output**: `mechanical/inertia.py` and
  `analytics/whatif.py` both explicitly separate *stored rotational kinetic
  energy* (a reservoir, `E = 1/2 I omega^2`) from *continuous electrical
  output* (a throughput set by the steady-state steam energy balance) - the
  codebase never lets one masquerade as the other.

## Optimisation modes

`optimisation/objectives.py::ObjectiveMode`: `MAX_POWER`, `MAX_EFFICIENCY`,
`MIN_STEAM_CONSUMPTION`, `MAX_NET_ENERGY`, `MIN_OPERATING_COST`,
`MAX_ECONOMIC_RETURN`, `BALANCED_OPTIMUM`. All maximise a common convention
(minimisation targets are negated internally); an infeasible candidate scores
a large, rank-preserving negative penalty rather than `-inf`, so gradient-free
search still gets useful signal.

## Testing

```bash
pytest -q
```

Covers: thermodynamic expansion (entropy conservation, efficiency bounds),
energy conservation across an RPM sweep, mechanical relationships (torque/RPM,
shaft stress, gearbox power conservation, critical-speed flagging), generator
conversion, and optimisation constraint rejection.

## Extending

- **PyTorch surrogate modelling**: not wired in by default (listed as
  optional in the spec); `digital_twin/calibration.py` shows the intended
  seam - replace the `scipy.optimize.least_squares` calibration with a
  learned surrogate if you have enough historical telemetry to justify one.
- **Regenerative feedwater heating / reheat**: extend `thermodynamics/cycle.py`
  and add extraction points on `turbine/stage.py`'s stage results.
- **Parallel optimisation**: `optimisation/optimiser.py` currently runs
  `differential_evolution` single-threaded (the objective closes over live
  Python objects, which are not picklable for `workers>1` without further
  refactoring into a top-level callable) - a natural next step for large
  search budgets.
