"""
thermodynamics/steam.py
=========================
Thin, explicit wrapper around IAPWS-IF97 (the international-standard steam
property formulation used across the power industry) via the `iapws`
package. We never invent our own p-h-s correlations for water/steam.

Units: all TURBOFLUX-facing quantities are SI (Pa, K, J/kg, J/kg/K,
m^3/kg). `iapws.IAPWS97` internally uses MPa, K, kJ/kg, kJ/kg/K, m^3/kg -
conversions happen only at this boundary, in one place.

ASSUMPTION: pure water/steam, no dissolved solids, equilibrium
thermodynamic properties (no non-equilibrium wetness/supersaturation
modelling in the LP end - see turbine/losses.py for the empirical wetness
loss correction that partially compensates for this simplification).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from iapws import IAPWS97

_MPA = 1.0e6  # Pa per MPa
_KJ = 1.0e3   # J per kJ


@dataclass(frozen=True)
class SteamState:
    """A single equilibrium thermodynamic state point, SI units."""

    pressure_pa: float
    temperature_k: float
    enthalpy_j_kg: float
    entropy_j_kgk: float
    specific_volume_m3_kg: float
    quality: Optional[float]  # None if single-phase (superheated/subcooled)

    @property
    def is_two_phase(self) -> bool:
        return self.quality is not None and 0.0 < self.quality < 1.0

    @property
    def is_saturated_or_wet(self) -> bool:
        return self.quality is not None


def _from_iapws(state: IAPWS97) -> SteamState:
    if not state.status:
        raise ValueError(
            f"IAPWS97 could not converge for the requested state "
            f"(P={state.P} MPa). Check inputs are within the IF97 validity "
            f"region (P<=100 MPa, T<=1073.15/2273.15 K depending on region)."
        )
    x = None
    # IAPWS97 reports x in [0,1] only inside the two-phase dome; -1 or None
    # elsewhere depending on version - normalise to Python None.
    try:
        if 0.0 <= state.x <= 1.0 and state.region == 4:
            x = float(state.x)
    except Exception:
        x = None
    return SteamState(
        pressure_pa=state.P * _MPA,
        temperature_k=state.T,
        enthalpy_j_kg=state.h * _KJ,
        entropy_j_kgk=state.s * _KJ,
        specific_volume_m3_kg=state.v,
        quality=x,
    )


def state_pt(pressure_pa: float, temperature_k: float) -> SteamState:
    """State from pressure + temperature (valid for subcooled/superheated)."""
    s = IAPWS97(P=pressure_pa / _MPA, T=temperature_k)
    return _from_iapws(s)


def state_px(pressure_pa: float, quality: float) -> SteamState:
    """Saturated state from pressure + quality (0=sat. liquid, 1=sat. vapour)."""
    if not 0.0 <= quality <= 1.0:
        raise ValueError("quality must be in [0, 1]")
    s = IAPWS97(P=pressure_pa / _MPA, x=quality)
    return _from_iapws(s)


def state_ps(pressure_pa: float, entropy_j_kgk: float) -> SteamState:
    """State from pressure + entropy - the workhorse for isentropic
    expansion: hold entropy fixed, drop pressure, read off enthalpy."""
    s = IAPWS97(P=pressure_pa / _MPA, s=entropy_j_kgk / _KJ)
    return _from_iapws(s)


def state_ph(pressure_pa: float, enthalpy_j_kg: float) -> SteamState:
    s = IAPWS97(P=pressure_pa / _MPA, h=enthalpy_j_kg / _KJ)
    return _from_iapws(s)


def saturation_temperature_k(pressure_pa: float) -> float:
    return IAPWS97(P=pressure_pa / _MPA, x=0.5).T


def saturation_pressure_pa(temperature_k: float) -> float:
    return IAPWS97(T=temperature_k, x=0.5).P * _MPA
