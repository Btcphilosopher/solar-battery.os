"""
thermodynamics/entropy.py
===========================
Entropy generation / irreversibility bookkeeping. Useful for exergy-style
loss accounting: the actual expansion generates entropy relative to the
isentropic (reversible) path, and that generated entropy times the
"sink" (condenser/environment) temperature is lost exergy - a direct
measure of where thermodynamic potential was destroyed by inefficiency.
"""
from __future__ import annotations

from .steam import SteamState


def entropy_generated_j_kgk(inlet: SteamState, actual_outlet: SteamState) -> float:
    """Specific entropy generation across an irreversible (real) expansion.
    Always >= 0 for a physically valid process; a negative result signals
    a modelling error (e.g. outlet state computed inconsistently)."""
    return actual_outlet.entropy_j_kgk - inlet.entropy_j_kgk


def lost_work_j_kg(entropy_generated_j_kgk_: float, sink_temperature_k: float) -> float:
    """Gouy-Stodola theorem: exergy destroyed = T0 * sigma_generated."""
    if entropy_generated_j_kgk_ < -1e-6:
        raise ValueError("entropy_generated must be >= 0 for a valid irreversible process")
    return max(0.0, sink_temperature_k * entropy_generated_j_kgk_)


def second_law_efficiency(actual_work_j_kg: float, ideal_work_j_kg: float) -> float:
    if ideal_work_j_kg <= 0:
        raise ValueError("ideal_work_j_kg must be positive")
    return actual_work_j_kg / ideal_work_j_kg
