"""
thermodynamics/properties.py
==============================
Convenience property lookups built on thermodynamics/steam.py. Nothing
here re-implements IAPWS-IF97; this module only composes it.
"""
from __future__ import annotations

from .steam import SteamState, saturation_pressure_pa, saturation_temperature_k, state_ph, state_ps, state_pt, state_px

R_WATER_J_KGK = 461.52  # specific gas constant of water vapour (ideal-gas limit reference only)


def superheat_k(state: SteamState) -> float:
    """Degrees of superheat above saturation at this pressure. Negative
    means the state is below the saturation line (should not occur for a
    single-phase superheated state; returns 0 for two-phase states)."""
    if state.is_two_phase:
        return 0.0
    t_sat = saturation_temperature_k(state.pressure_pa)
    return state.temperature_k - t_sat


def wetness_fraction(state: SteamState) -> float:
    """1 - quality, i.e. liquid mass fraction. 0 for superheated/subcooled
    single-phase states."""
    if state.quality is None:
        return 0.0
    return 1.0 - state.quality


def specific_volume(state: SteamState) -> float:
    return state.specific_volume_m3_kg


def density_kg_m3(state: SteamState) -> float:
    return 1.0 / state.specific_volume_m3_kg


def volumetric_flow_m3_s(mass_flow_kg_s: float, state: SteamState) -> float:
    return mass_flow_kg_s * state.specific_volume_m3_kg
