"""thermodynamics/enthalpy.py - enthalpy-drop bookkeeping helpers."""
from __future__ import annotations

from .steam import SteamState


def available_enthalpy_drop_j_kg(inlet: SteamState, isentropic_outlet: SteamState) -> float:
    """The maximum thermodynamically available specific work between two
    pressure levels (ideal, reversible, adiabatic expansion)."""
    return inlet.enthalpy_j_kg - isentropic_outlet.enthalpy_j_kg


def specific_work_j_kg(inlet: SteamState, actual_outlet: SteamState) -> float:
    return inlet.enthalpy_j_kg - actual_outlet.enthalpy_j_kg


def power_from_enthalpy_drop_w(mass_flow_kg_s: float, enthalpy_drop_j_kg: float) -> float:
    """P = mdot * dh - the fundamental turbine relationship (section 5),
    used without an efficiency term here; efficiency is applied upstream
    when `enthalpy_drop_j_kg` is chosen as the ideal or actual drop."""
    return mass_flow_kg_s * enthalpy_drop_j_kg


def reheat_factor(stage_isentropic_drops_j_kg: list[float], overall_isentropic_drop_j_kg: float) -> float:
    """Reheat factor: sum of individual stage isentropic drops divided by
    the overall (single-expansion) isentropic drop. >1 because reheating
    between stages (the divergence of constant-pressure lines on a Mollier
    chart) makes the sum of stage-isentropic works exceed the single-step
    ideal - a standard multi-stage turbine correction."""
    if overall_isentropic_drop_j_kg <= 0:
        raise ValueError("overall_isentropic_drop_j_kg must be positive")
    return sum(stage_isentropic_drops_j_kg) / overall_isentropic_drop_j_kg
