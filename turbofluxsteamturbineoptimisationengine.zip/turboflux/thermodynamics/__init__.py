"""Steam thermodynamics built on the IAPWS-IF97 industry-standard property
formulation (via the `iapws` package), not invented correlations."""
