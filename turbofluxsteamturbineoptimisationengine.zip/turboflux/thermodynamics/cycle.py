"""
thermodynamics/cycle.py
=========================
Whole-cycle (simplified Rankine) thermal accounting: boiler heat input,
turbine work, condenser heat rejection, feed-pump work, and the resulting
cycle thermal efficiency. This underpins the "cycle_thermal_efficiency"
field on SystemState and the boiler fuel-input estimate used by
economics/fuel.py.

ASSUMPTION: single feed-pump, no regenerative feedwater heating train
(no extraction stages). Adding regen extraction is a natural extension
point in turbine/stage.py (stages already expose extraction-capable
outlet states) but is out of scope for this reference build; the
docstring flags it explicitly so nobody mistakes this for an FWH-optimised
cycle.
"""
from __future__ import annotations

from dataclasses import dataclass

from .steam import SteamState, state_ph, state_px


@dataclass(frozen=True)
class CycleEnergyBalance:
    boiler_heat_input_w: float
    turbine_work_w: float
    pump_work_w: float
    condenser_heat_rejected_w: float
    net_cycle_work_w: float
    thermal_efficiency: float
    carnot_efficiency_limit: float


def feed_pump_work_j_kg(condensate: SteamState, boiler_pressure_pa: float, pump_isentropic_efficiency: float = 0.8) -> float:
    """Small but non-zero pump work to raise condensate back to boiler
    pressure; specific volume of the (near-incompressible) liquid is used
    directly: w_pump = v * dP / eta_pump."""
    v = condensate.specific_volume_m3_kg
    dp = boiler_pressure_pa - condensate.pressure_pa
    ideal_work = v * dp
    return ideal_work / pump_isentropic_efficiency


def cycle_energy_balance(
    mass_flow_kg_s: float,
    boiler_inlet_enthalpy_j_kg: float,
    turbine_inlet_enthalpy_j_kg: float,
    turbine_exhaust_enthalpy_j_kg: float,
    condenser_pressure_pa: float,
    boiler_pressure_pa: float,
) -> CycleEnergyBalance:
    """Compute the classical Rankine-cycle heat/work balance.

    boiler_inlet_enthalpy_j_kg: enthalpy of the feedwater entering the
        boiler (after the pump), i.e. h1 in the standard 1-2-3-4 Rankine
        state numbering (1=pump inlet/condenser out, 2=pump out/boiler in,
        3=turbine in, 4=turbine out).
    """
    condensate = state_px(condenser_pressure_pa, 0.0)
    pump_w = feed_pump_work_j_kg(condensate, boiler_pressure_pa)

    q_boiler = turbine_inlet_enthalpy_j_kg - boiler_inlet_enthalpy_j_kg
    if q_boiler <= 0:
        raise ValueError("Boiler heat input computed non-positive - check state ordering")

    turbine_work = turbine_inlet_enthalpy_j_kg - turbine_exhaust_enthalpy_j_kg
    q_condenser = turbine_exhaust_enthalpy_j_kg - condensate.enthalpy_j_kg

    net_work = turbine_work - pump_w
    eta_thermal = net_work / q_boiler

    # Carnot bound using the actual source/sink temperatures as a sanity
    # ceiling - cycle efficiency must never exceed this without signalling
    # a modelling bug.
    t_source = state_px(boiler_pressure_pa, 1.0).temperature_k
    t_sink = condensate.temperature_k
    carnot = 1.0 - t_sink / t_source

    return CycleEnergyBalance(
        boiler_heat_input_w=mass_flow_kg_s * q_boiler,
        turbine_work_w=mass_flow_kg_s * turbine_work,
        pump_work_w=mass_flow_kg_s * pump_w,
        condenser_heat_rejected_w=mass_flow_kg_s * q_condenser,
        net_cycle_work_w=mass_flow_kg_s * net_work,
        thermal_efficiency=eta_thermal,
        carnot_efficiency_limit=carnot,
    )
