"""
thermodynamics/expansion.py
=============================
Isentropic vs actual steam expansion through a turbine (or a single
stage). This is the thermodynamic core of every power calculation in
TURBOFLUX.

Definitions (standard turbine convention):

    isentropic (ideal) outlet state: same entropy as inlet, pressure
    dropped to outlet pressure. h_out_ideal = h(P_out, s_in).

    isentropic efficiency:  eta_s = (h_in - h_out_actual) / (h_in - h_out_ideal)

    actual outlet enthalpy:  h_out_actual = h_in - eta_s * (h_in - h_out_ideal)

All energies are per unit mass [J/kg] unless multiplied by mass flow.
"""
from __future__ import annotations

from dataclasses import dataclass

from .steam import SteamState, state_ph, state_ps


@dataclass(frozen=True)
class ExpansionResult:
    inlet: SteamState
    outlet_ideal: SteamState
    outlet_actual: SteamState
    isentropic_enthalpy_drop_j_kg: float
    actual_enthalpy_drop_j_kg: float
    isentropic_efficiency: float

    @property
    def specific_work_j_kg(self) -> float:
        return self.actual_enthalpy_drop_j_kg


def isentropic_outlet(inlet: SteamState, outlet_pressure_pa: float) -> SteamState:
    """Ideal (constant-entropy) outlet state at the given pressure."""
    return state_ps(outlet_pressure_pa, inlet.entropy_j_kgk)


def expand(inlet: SteamState, outlet_pressure_pa: float, isentropic_efficiency: float) -> ExpansionResult:
    """Expand steam from `inlet` down to `outlet_pressure_pa` through a
    device (nozzle+stage or whole turbine) of the given isentropic
    efficiency, and return both the ideal and actual outlet states.
    """
    if not 0.0 < isentropic_efficiency <= 1.0:
        raise ValueError("isentropic_efficiency must be in (0, 1]")
    if outlet_pressure_pa >= inlet.pressure_pa:
        raise ValueError("outlet_pressure_pa must be lower than inlet pressure for expansion")

    ideal_outlet = isentropic_outlet(inlet, outlet_pressure_pa)
    dh_isentropic = inlet.enthalpy_j_kg - ideal_outlet.enthalpy_j_kg
    if dh_isentropic <= 0:
        raise ValueError("Non-positive isentropic enthalpy drop - check inlet/outlet pressures")

    dh_actual = isentropic_efficiency * dh_isentropic
    h_out_actual = inlet.enthalpy_j_kg - dh_actual
    actual_outlet = state_ph(outlet_pressure_pa, h_out_actual)

    return ExpansionResult(
        inlet=inlet,
        outlet_ideal=ideal_outlet,
        outlet_actual=actual_outlet,
        isentropic_enthalpy_drop_j_kg=dh_isentropic,
        actual_enthalpy_drop_j_kg=dh_actual,
        isentropic_efficiency=isentropic_efficiency,
    )


def pressure_ratio(inlet_pressure_pa: float, outlet_pressure_pa: float) -> float:
    return outlet_pressure_pa / inlet_pressure_pa


def stage_pressures_geometric(p_in: float, p_out: float, n_stages: int) -> list[float]:
    """Split an overall expansion into n_stages using equal pressure
    ratios per stage (the classical first-guess distribution; the
    optimiser is free to move away from this - see optimisation/pareto.py
    and the multi-stage pressure-distribution optimisation in
    turbine/turbine.py)."""
    if n_stages < 1:
        raise ValueError("n_stages must be >= 1")
    ratio = (p_out / p_in) ** (1.0 / n_stages)
    pressures = [p_in * (ratio ** i) for i in range(n_stages + 1)]
    pressures[-1] = p_out  # avoid floating point drift
    return pressures
