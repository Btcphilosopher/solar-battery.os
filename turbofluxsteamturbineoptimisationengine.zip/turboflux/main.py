#!/usr/bin/env python3
"""
TURBOFLUX - Steam Turbine Digital Twin and Energy Optimisation Engine
========================================================================
Runs the full baseline study described in the project specification,
section 25:

    1. baseline simulation
    2. RPM sweep
    3. steam pressure sweep
    4. mass-flow sweep
    5. condenser (cooling-water flow) optimisation
    6. gearbox ratio optimisation / direct-vs-geared comparison
    7. complete multi-variable optimisation (global + local refine)

...plus sensitivity analysis, Pareto-frontier sampling, Monte Carlo
uncertainty propagation, the what-if engine, a digital-twin degradation
demo, and a full set of engineering plots + an energy-balance/dashboard
report - all written to ./turboflux_output/.

Run: python main.py [--quick]
    --quick   use small optimiser/Monte-Carlo/Pareto sample budgets
              (default; a full run end-to-end takes ~2-4 minutes because
              every evaluation calls the IAPWS-IF97 steam property
              routines several times). Pass --thorough for larger,
              publication-quality search budgets (much slower).
"""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np

from analytics.bottlenecks import largest_bottleneck, stage_bottleneck
from analytics.performance import compute_kpis
from analytics.reports import baseline_vs_optimised_report, energy_balance_report
from analytics.whatif import run_all_what_ifs
from core.engine import simulate
from core.simulation import simulate_spin_up
from core.state import ComponentHealth, DataProvenance
from digital_twin.twin import DigitalTwin
from examples.baseline_turbine import build_baseline_config, build_baseline_operating_point
from mechanical.gearbox import compare_direct_vs_geared
from optimisation.monte_carlo import run_monte_carlo, summarise
from optimisation.objectives import ObjectiveMode, score
from optimisation.optimiser import optimise
from optimisation.parameter_sweep import find_optimum_in_sweep, sweep_1d
from optimisation.pareto import pareto_frontier
from optimisation.sensitivity import run_sensitivity
from turbine.rotor import RotorGeometry
from visualisation import dashboard, optimisation_plots, thermodynamic_plots, turbine_plots


def section(title: str) -> None:
    print("\n" + "=" * 78)
    print(title)
    print("=" * 78)


def main(quick: bool = True) -> None:
    out_dir = Path(__file__).resolve().parent / "turboflux_output"
    out_dir.mkdir(exist_ok=True)
    t_start = time.time()

    budgets = dict(opt_maxiter=8, opt_popsize=6, mc_trials=150, pareto_samples=150) if quick else dict(
        opt_maxiter=40, opt_popsize=20, mc_trials=800, pareto_samples=800
    )

    # ------------------------------------------------------------------ #
    section("0. BUILD BASELINE PLANT + OPERATING POINT")
    config = build_baseline_config()
    base_point = build_baseline_operating_point(config)
    print(f"Plant: {config.name}")
    print(f"Turbine stages: {[s.name for s in config.turbine.stages]}")

    # ------------------------------------------------------------------ #
    section("1. BASELINE SIMULATION")
    baseline_state = simulate(config, base_point, provenance=DataProvenance.SIMULATED)
    kpi = compute_kpis(baseline_state)
    print(f"Net electrical power: {kpi.net_electrical_power_kw:,.1f} kW")
    print(f"Overall efficiency:   {kpi.overall_efficiency_pct:.2f} %")
    print(f"Shaft RPM / torque:   {kpi.shaft_rpm:,.0f} rpm / {kpi.shaft_torque_n_m:,.0f} N.m")
    print(f"Feasible:             {baseline_state.is_feasible}")
    print(energy_balance_report(baseline_state))

    # ------------------------------------------------------------------ #
    section("2. RPM SWEEP")
    rpm_values = np.linspace(config.limits.min_rpm, config.limits.max_rpm, 24)
    rpm_df = sweep_1d(config, base_point, "shaft_rpm", rpm_values)
    rpm_df.to_csv(out_dir / "sweep_rpm.csv", index=False)
    best_rpm_row = find_optimum_in_sweep(rpm_df)
    print(f"Best feasible RPM in sweep: {best_rpm_row['shaft_rpm']:.0f} rpm -> "
          f"{best_rpm_row['net_electrical_power_w']/1e3:,.1f} kW "
          f"(coarse grid - MUCH more RPM/power detail in sweep_rpm.csv)")
    turbine_plots.power_torque_efficiency_vs_rpm(rpm_df, best_rpm_row["shaft_rpm"], str(out_dir / "power_torque_efficiency_vs_rpm.png"))

    # ------------------------------------------------------------------ #
    section("3. STEAM PRESSURE SWEEP")
    p_values = np.linspace(config.limits.min_inlet_pressure_pa, config.limits.max_inlet_pressure_pa, 15)
    p_df = sweep_1d(config, base_point, "inlet_pressure_pa", p_values)
    p_df.to_csv(out_dir / "sweep_inlet_pressure.csv", index=False)
    turbine_plots.pressure_ratio_vs_power(p_df, str(out_dir / "pressure_vs_power.png"))
    best_p_row = find_optimum_in_sweep(p_df)
    print(f"Best feasible inlet pressure: {best_p_row['inlet_pressure_pa']/1e6:.2f} MPa -> "
          f"{best_p_row['net_electrical_power_w']/1e3:,.1f} kW")

    # ------------------------------------------------------------------ #
    section("4. STEAM MASS-FLOW SWEEP")
    m_values = np.linspace(config.steam_supply.min_mass_flow_kg_s, config.steam_supply.max_mass_flow_kg_s, 15)
    m_df = sweep_1d(config, base_point, "steam_mass_flow_kg_s", m_values)
    m_df.to_csv(out_dir / "sweep_mass_flow.csv", index=False)
    turbine_plots.steam_flow_vs_power(m_df, str(out_dir / "steam_flow_vs_power.png"))
    best_m_row = find_optimum_in_sweep(m_df)
    print(f"Best feasible mass flow: {best_m_row['steam_mass_flow_kg_s']:.2f} kg/s -> "
          f"{best_m_row['net_electrical_power_w']/1e3:,.1f} kW")

    # ------------------------------------------------------------------ #
    section("5. CONDENSER (COOLING-WATER FLOW) OPTIMISATION")
    cw_values = np.linspace(200.0, config.condenser.max_cooling_water_flow_kg_s, 15)
    cw_df = sweep_1d(config, base_point, "cooling_water_flow_kg_s", cw_values)
    cw_df.to_csv(out_dir / "sweep_cooling_water_flow.csv", index=False)
    best_cw_row = find_optimum_in_sweep(cw_df)
    print(f"Best feasible cooling water flow: {best_cw_row['cooling_water_flow_kg_s']:.0f} kg/s -> "
          f"{best_cw_row['net_electrical_power_w']/1e3:,.1f} kW "
          f"(NOTE: pumping-power cost of higher cooling flow is not modelled - "
          f"a real optimum trades this off against pump auxiliary load)")
    thermodynamic_plots.condenser_pressure_vs_turbine_power(
        sweep_1d(config, base_point, "condenser_pressure_pa",
                 np.linspace(config.limits.min_condenser_pressure_pa, config.limits.max_condenser_pressure_pa, 15)),
        str(out_dir / "condenser_pressure_vs_power.png"),
    )

    # ------------------------------------------------------------------ #
    section("6. GEARBOX RATIO OPTIMISATION / DIRECT vs GEARED")
    gear_values = np.linspace(config.limits.min_gear_ratio, config.limits.max_gear_ratio, 15)
    gear_df = sweep_1d(config, base_point, "gear_ratio", gear_values)
    gear_df.to_csv(out_dir / "sweep_gear_ratio.csv", index=False)
    thermodynamic_plots.gear_ratio_vs_generator_output(gear_df, str(out_dir / "gear_ratio_vs_output.png"))
    comparison = compare_direct_vs_geared(
        config.gearbox, turbine_rpm=best_rpm_row["shaft_rpm"], turbine_torque_n_m=best_rpm_row["shaft_torque_n_m"],
        target_generator_rpm=config.generator.synchronous_rpm,
    )
    print(f"At {best_rpm_row['shaft_rpm']:.0f} rpm: direct-drive generator RPM would be "
          f"{comparison['direct_drive'].generator_rpm:.0f} (sync={config.generator.synchronous_rpm:.0f}); "
          f"geared drive (ratio={comparison['required_gear_ratio']:.3f}) delivers "
          f"{comparison['geared_drive'].output_power_w/1e3:,.1f} kW to the generator "
          f"vs {comparison['direct_drive'].output_power_w/1e3:,.1f} kW direct.")

    # ------------------------------------------------------------------ #
    section("7. COMPLETE MULTI-VARIABLE OPTIMISATION")
    t0 = time.time()
    opt_result = optimise(
        config, mode=ObjectiveMode.MAX_NET_ENERGY,
        maxiter=budgets["opt_maxiter"], popsize=budgets["opt_popsize"], seed=config.economics.random_seed,
    )
    print(f"Optimiser wall time: {time.time()-t0:.1f} s")
    optimised_state = opt_result.best_state
    print(f"Optimised feasible: {optimised_state.is_feasible}")
    if not optimised_state.is_feasible:
        print(f"  -> REJECTED candidate violations: {optimised_state.constraint_violations}")
    print(energy_balance_report(optimised_state))

    print("\nAll seven objective-mode scores evaluated AT THE SAME optimised state "
          "(illustrating section 17 - each mode would drive the search toward a "
          "different point if optimised for directly):")
    for mode in ObjectiveMode:
        print(f"  {mode.value:<24} {score(mode, optimised_state, config.economics, config.steam_supply):,.3f}")

    # ------------------------------------------------------------------ #
    section("8. SENSITIVITY ANALYSIS")
    sens_df = run_sensitivity(config, base_point)
    sens_df.to_csv(out_dir / "sensitivity.csv", index=False)
    optimisation_plots.sensitivity_tornado(sens_df, str(out_dir / "sensitivity_tornado.png"))
    print(sens_df[["variable", "perturbation_pct", "delta_power_pct", "delta_margin_per_s"]].to_string(index=False))

    # ------------------------------------------------------------------ #
    section("9. PARETO FRONTIER (Power vs Specific Steam Consumption)")
    pareto_df = pareto_frontier(
        config, n_samples=budgets["pareto_samples"],
        maximise_cols=["net_electrical_power_w"], minimise_cols=["specific_steam_consumption_kg_per_kwh"],
    )
    pareto_df.to_csv(out_dir / "pareto.csv", index=False)
    if not pareto_df.empty:
        optimisation_plots.pareto_frontier_plot(
            pareto_df, "specific_steam_consumption_kg_per_kwh", "net_electrical_power_w", str(out_dir / "pareto_frontier.png")
        )
        print(f"{int(pareto_df['is_pareto_optimal'].sum())} of {len(pareto_df)} feasible samples are Pareto-optimal.")

    # ------------------------------------------------------------------ #
    section("10. MONTE CARLO UNCERTAINTY ANALYSIS")
    mc_df = run_monte_carlo(config, base_point, n_trials=budgets["mc_trials"])
    mc_summary = summarise(mc_df)
    for k, v in mc_summary.items():
        print(f"  {k}: {v:,.3f}" if isinstance(v, float) else f"  {k}: {v}")

    # ------------------------------------------------------------------ #
    section("11. WHAT-IF ENGINEERING QUESTIONS")
    for result in run_all_what_ifs(config, base_point):
        print(f"\nQ: {result.question}")
        print(f"   BASELINE:     {result.baseline_power_w/1e3:,.1f} kW @ {result.baseline_efficiency*100:.2f}% eff")
        print(f"   NEW CONDITION:{result.new_power_w/1e3:,.1f} kW @ {result.new_efficiency*100:.2f}% eff")
        print(f"   CHANGE:       {result.change_power_pct:+.2f}% power")
        print(f"   NET EFFECT:   {'feasible' if result.new_state_feasible else 'INFEASIBLE'}")
        print(f"   INTERPRETATION: {result.interpretation}")

    # ------------------------------------------------------------------ #
    section("12. ROTOR SPIN-UP TRANSIENT (mechanical inertia, section 8)")
    rotor = RotorGeometry(config.turbine.rotor_diameter_m, config.turbine.rotor_mass_kg, config.turbine.rotor_length_m)
    spin_up = simulate_spin_up(config, base_point, rotor, target_rpm=config.generator.rated_rpm)
    print(f"Rotor mass {rotor.mass_kg:.0f} kg, polar inertia {rotor.polar_moment_of_inertia_kg_m2:,.1f} kg.m^2")
    print(f"Time to reach {spin_up.target_rpm:.0f} rpm from standstill: "
          f"{spin_up.time_to_target_s:.1f} s" if spin_up.reached_target else "  did not reach target within horizon")

    # ------------------------------------------------------------------ #
    section("13. DIGITAL TWIN + DEGRADATION DEMONSTRATION")
    twin = DigitalTwin(config=config)
    twin.update(base_point)
    twin.advance_degradation(days=400)
    twin.update(base_point)
    needs_maintenance, reasons = twin.maintenance_recommended()
    print(f"After 400 simulated days of operation: maintenance recommended = {needs_maintenance}")
    for r in reasons:
        print(f"  - {r}")
    recommendation = twin.recommend(mode=ObjectiveMode.MAX_NET_ENERGY)
    print(f"Digital twin recommendation predicted gain: {recommendation.predicted_power_gain_w/1e3:,.1f} kW "
          f"(actionable={recommendation.is_actionable})")

    # ------------------------------------------------------------------ #
    section("14. FINAL REPORT: BASELINE vs OPTIMISED")
    report_text = baseline_vs_optimised_report(baseline_state, optimised_state)
    print(report_text)
    (out_dir / "final_report.txt").write_text(report_text)

    turbine_plots.stage_energy_conversion(optimised_state, str(out_dir / "stage_energy_conversion.png"))
    turbine_plots.energy_balance_sankey(optimised_state, str(out_dir / "energy_balance_sankey.html"))
    dashboard.render_dashboard(baseline_state, optimised_state, str(out_dir / "dashboard.png"))

    print(f"\nAll outputs written to: {out_dir}")
    print(f"Total wall time: {time.time()-t_start:.1f} s")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="TURBOFLUX baseline study")
    parser.add_argument("--thorough", action="store_true", help="use larger, slower optimisation/Monte-Carlo/Pareto budgets")
    args = parser.parse_args()
    main(quick=not args.thorough)
