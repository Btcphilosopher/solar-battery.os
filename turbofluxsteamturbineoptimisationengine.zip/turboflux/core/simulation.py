"""
core/simulation.py
====================
Transient (time-domain) simulation, distinct from the steady-state
core/engine.simulate(). Two capabilities:

1) Rotor spin-up transient (section 8): integrate I * domega/dt =
   T_available(omega) using scipy.integrate.solve_ivp, where
   T_available(omega) is the net accelerating torque (turbine torque minus
   bearing friction, generator breaker open / unloaded) at each speed,
   obtained by pre-computing a torque-speed curve with the steady-state
   engine and interpolating. This directly demonstrates the section-8
   distinction between rotor inertia (which sets *how fast* the machine
   can accelerate) and continuous energy output (a completely separate,
   steady-state quantity).

2) A simple digital-twin day-stepper that advances degradation and
   records SystemState snapshots over simulated time (used by
   examples/baseline_turbine.py and digital_twin/twin.py).
"""
from __future__ import annotations

from dataclasses import dataclass, replace

import numpy as np
from scipy.integrate import solve_ivp

from core.configuration import PlantConfig
from core.engine import simulate as steady_state_simulate
from core.state import ComponentHealth, DataProvenance, OperatingPoint
from mechanical.inertia import angular_acceleration_rad_s2
from mechanical.torque import rad_s_to_rpm, rpm_to_rad_s
from turbine.rotor import RotorGeometry


@dataclass
class SpinUpResult:
    time_s: np.ndarray
    rpm: np.ndarray
    target_rpm: float
    time_to_target_s: float
    reached_target: bool
    torque_curve_rpm: np.ndarray
    torque_curve_n_m: np.ndarray


def build_unloaded_torque_curve(
    config: PlantConfig, base_point: OperatingPoint, health: ComponentHealth, n_points: int = 25
) -> tuple[np.ndarray, np.ndarray]:
    """Net accelerating torque (post-bearing-loss, pre-generator-coupling)
    versus RPM, at fixed steam admission conditions. Used as the RHS
    lookup for the spin-up ODE integration."""
    rpm_grid = np.linspace(max(50.0, config.limits.min_rpm * 0.2), config.limits.max_rpm, n_points)
    torques = []
    for rpm in rpm_grid:
        op = replace(base_point, shaft_rpm=float(rpm))
        state = steady_state_simulate(config, op, health, provenance=DataProvenance.SIMULATED)
        omega = rpm_to_rad_s(rpm)
        # net_shaft_power_w is already net of bearing loss and reflects
        # unloaded acceleration capability (gearbox/generator coupling is
        # a downstream steady-state concern, not part of spin-up torque).
        torque = state.net_shaft_power_w / omega if omega > 0 else 0.0
        torques.append(torque)
    return rpm_grid, np.array(torques)


def simulate_spin_up(
    config: PlantConfig,
    base_point: OperatingPoint,
    rotor: RotorGeometry,
    health: ComponentHealth | None = None,
    target_rpm: float | None = None,
    t_max_s: float = 600.0,
) -> SpinUpResult:
    health = health or ComponentHealth()
    target_rpm = target_rpm or config.generator.rated_rpm

    rpm_grid, torque_grid = build_unloaded_torque_curve(config, base_point, health)
    I = rotor.polar_moment_of_inertia_kg_m2

    def torque_at_rpm(rpm: float) -> float:
        return float(np.interp(rpm, rpm_grid, torque_grid, left=torque_grid[0], right=torque_grid[-1]))

    def rhs(t, y):
        rpm = rad_s_to_rpm(y[0])
        torque = torque_at_rpm(rpm)
        alpha = angular_acceleration_rad_s2(max(torque, 0.0), I)
        return [alpha]

    def hit_target(t, y):
        return rad_s_to_rpm(y[0]) - target_rpm

    hit_target.terminal = True
    hit_target.direction = 1

    sol = solve_ivp(
        rhs,
        t_span=(0.0, t_max_s),
        y0=[rpm_to_rad_s(max(1.0, config.limits.min_rpm * 0.1))],
        events=hit_target,
        max_step=1.0,
        dense_output=True,
        rtol=1e-6,
        atol=1e-6,
    )

    t_dense = np.linspace(0, sol.t[-1], 300)
    omega_dense = sol.sol(t_dense)[0]
    rpm_dense = rad_s_to_rpm(omega_dense)

    reached = len(sol.t_events[0]) > 0
    time_to_target = float(sol.t_events[0][0]) if reached else float("nan")

    return SpinUpResult(
        time_s=t_dense,
        rpm=rpm_dense,
        target_rpm=target_rpm,
        time_to_target_s=time_to_target,
        reached_target=reached,
        torque_curve_rpm=rpm_grid,
        torque_curve_n_m=torque_grid,
    )
