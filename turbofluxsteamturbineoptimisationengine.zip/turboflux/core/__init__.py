"""Core orchestration layer: state representation, configuration, clock, engine."""
