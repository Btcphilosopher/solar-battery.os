"""
core/state.py
==============
TURBOFLUX distinguishes six kinds of numeric provenance everywhere a value
crosses a module boundary. A caller must never have to guess whether a
number came off a sensor, a correlation, or an optimiser.

    MEASURED   - taken directly from real plant instrumentation (not used
                 in this offline research build, but the type exists so a
                 future SCADA/historian adapter has somewhere to put data
                 without breaking the provenance contract).
    ESTIMATED  - inferred from measurements via a state estimator/filter
                 (see digital_twin/state_estimator.py) - noisy, indirect.
    MODELLED   - computed from first-principles / correlation models given
                 known inputs (thermodynamics, mechanics) - deterministic.
    SIMULATED  - produced by the simulation engine driving the full plant
                 model forward (core/simulation.py, digital_twin telemetry).
    OPTIMISED  - the output of an optimisation routine (scipy.optimize) -
                 a candidate operating point, not yet validated as safe.
    PREDICTED  - a forecast of a future state (digital_twin/prediction.py).

Every physical quantity that flows between modules is wrapped in a
``Tagged`` value carrying its provenance and unit. Silently mixing, say, an
OPTIMISED RPM with a MEASURED torque without acknowledging that one of them
is a proposal and the other is fact, is exactly what this module prevents.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Generic, Optional, TypeVar

T = TypeVar("T")


class DataProvenance(str, Enum):
    MEASURED = "MEASURED"
    ESTIMATED = "ESTIMATED"
    MODELLED = "MODELLED"
    SIMULATED = "SIMULATED"
    OPTIMISED = "OPTIMISED"
    PREDICTED = "PREDICTED"


@dataclass(frozen=True)
class Tagged(Generic[T]):
    """A single value with explicit unit and provenance."""

    value: T
    unit: str
    provenance: DataProvenance
    source: str = ""

    def __float__(self) -> float:
        return float(self.value)  # type: ignore[arg-type]

    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        src = f" <{self.source}>" if self.source else ""
        return f"{self.value:.6g} {self.unit} [{self.provenance.value}]{src}"

    def assert_provenance(self, *allowed: DataProvenance) -> "Tagged[T]":
        if self.provenance not in allowed:
            raise ValueError(
                f"Value tagged {self.provenance.value} is not permitted here "
                f"(expected one of {[p.value for p in allowed]}). "
                f"TURBOFLUX refuses to silently blur data provenance."
            )
        return self


def tag(value: T, unit: str, provenance: DataProvenance, source: str = "") -> Tagged[T]:
    return Tagged(value=value, unit=unit, provenance=provenance, source=source)


# ---------------------------------------------------------------------------
# Steady-state operating point: the vector the optimiser searches over and
# the simulation engine consumes.
# ---------------------------------------------------------------------------
@dataclass
class OperatingPoint:
    """Free variables that fully determine one steady-state plant condition."""

    inlet_pressure_pa: float          # throttle/inlet steam pressure [Pa]
    inlet_temperature_k: float        # throttle steam temperature [K]
    steam_mass_flow_kg_s: float       # total steam mass flow [kg/s]
    condenser_pressure_pa: float      # condenser (final exhaust) pressure [Pa]
    shaft_rpm: float                  # turbine shaft rotational speed [rpm]
    gear_ratio: float                 # turbine_rpm / generator_rpm (>=1 for step-down)
    stage_pressure_ratios: tuple = field(default_factory=tuple)  # per-stage p_out/p_in
    cooling_water_flow_kg_s: float = 0.0
    cooling_water_inlet_temp_k: float = 288.15
    generator_load_fraction: float = 1.0  # fraction of generator rated MVA delivered

    def as_dict(self) -> dict:
        return {
            "inlet_pressure_pa": self.inlet_pressure_pa,
            "inlet_temperature_k": self.inlet_temperature_k,
            "steam_mass_flow_kg_s": self.steam_mass_flow_kg_s,
            "condenser_pressure_pa": self.condenser_pressure_pa,
            "shaft_rpm": self.shaft_rpm,
            "gear_ratio": self.gear_ratio,
            "stage_pressure_ratios": tuple(self.stage_pressure_ratios),
            "cooling_water_flow_kg_s": self.cooling_water_flow_kg_s,
            "cooling_water_inlet_temp_k": self.cooling_water_inlet_temp_k,
            "generator_load_fraction": self.generator_load_fraction,
        }


@dataclass
class ComponentHealth:
    """Degradation multipliers, 1.0 = as-new. See fault/degradation model."""

    turbine_efficiency_factor: float = 1.0
    bearing_friction_factor: float = 1.0
    gearbox_efficiency_factor: float = 1.0
    condenser_fouling_factor: float = 1.0  # >1 reduces effective U*A
    generator_efficiency_factor: float = 1.0


@dataclass
class SystemState:
    """Full snapshot of the plant produced by one simulation/engine call.

    This is the object the digital twin stores, the analytics layer reports
    on, and the optimiser scores. Every numeric field carries its own
    provenance via the Tagged wrapper where ambiguity is possible; the
    dataclass itself is stamped SIMULATED/MODELLED/OPTIMISED as a whole via
    ``provenance``.
    """

    timestamp: datetime
    provenance: DataProvenance
    operating_point: OperatingPoint
    health: ComponentHealth

    # thermodynamics
    inlet_enthalpy_j_kg: float = 0.0
    exhaust_enthalpy_j_kg: float = 0.0
    exhaust_quality: Optional[float] = None
    isentropic_enthalpy_drop_j_kg: float = 0.0
    actual_enthalpy_drop_j_kg: float = 0.0

    # power flow (all watts unless noted)
    ideal_turbine_power_w: float = 0.0
    actual_turbine_power_w: float = 0.0
    turbine_health_degradation_loss_w: float = 0.0
    mechanical_loss_w: float = 0.0
    net_shaft_power_w: float = 0.0
    gearbox_loss_w: float = 0.0
    generator_input_power_w: float = 0.0
    generator_loss_w: float = 0.0
    net_electrical_power_w: float = 0.0
    condenser_heat_rejected_w: float = 0.0
    achieved_condenser_pressure_pa: float = 0.0  # solved from cooling-water heat balance; may differ from operating_point.condenser_pressure_pa (the target/initial guess)

    # efficiencies (dimensionless, 0-1)
    turbine_isentropic_efficiency: float = 0.0
    cycle_thermal_efficiency: float = 0.0
    generator_efficiency: float = 0.0
    overall_efficiency: float = 0.0

    # mechanical / rotordynamics
    shaft_torque_n_m: float = 0.0
    generator_rpm: float = 0.0
    shaft_stress_pa: float = 0.0
    vibration_amplitude_m: float = 0.0
    nearest_critical_speed_rpm: float = 0.0
    critical_speed_margin_pct: float = 0.0

    # bookkeeping
    stage_results: list = field(default_factory=list)
    constraint_violations: list = field(default_factory=list)
    energy_balance_residual_w: float = 0.0
    notes: list = field(default_factory=list)

    @property
    def is_feasible(self) -> bool:
        return len(self.constraint_violations) == 0

    def summary(self) -> dict:
        return {
            "timestamp": self.timestamp.isoformat(),
            "provenance": self.provenance.value,
            "net_electrical_power_kw": self.net_electrical_power_w / 1e3,
            "cycle_thermal_efficiency_pct": self.cycle_thermal_efficiency * 100,
            "overall_efficiency_pct": self.overall_efficiency * 100,
            "shaft_rpm": self.operating_point.shaft_rpm,
            "generator_rpm": self.generator_rpm,
            "shaft_torque_n_m": self.shaft_torque_n_m,
            "feasible": self.is_feasible,
            "violations": list(self.constraint_violations),
        }


def utcnow() -> datetime:
    return datetime.now(timezone.utc)
