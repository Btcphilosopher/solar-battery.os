"""
core/configuration.py
======================
Pydantic configuration models for the whole plant. These are the
engineering "nameplate + safety envelope" describing one turbine-generator
architecture. All optimisation and simulation activity is bounded by
``SafetyLimits`` — see section 27 of the spec: an optimisation result that
violates a configured limit is REJECTED, never relaxed.

All quantities are SI unless a field name says otherwise (rpm, pct, etc,
each of which is documented at the field).
"""
from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, Field, model_validator


class SteamSupplyConfig(BaseModel):
    """Boiler / steam generator + superheater outlet conditions available
    to the turbine. This is the upper boundary of the energy conversion
    chain (STEAM SOURCE -> BOILER -> SUPERHEATER -> ... -> TURBINE)."""

    rated_pressure_pa: float = Field(8.0e6, gt=0, description="Design throttle pressure [Pa]")
    rated_temperature_k: float = Field(773.15, gt=273.15, description="Design throttle temperature [K] (500 C)")
    max_mass_flow_kg_s: float = Field(80.0, gt=0, description="Maximum steam the boiler can deliver [kg/s]")
    min_mass_flow_kg_s: float = Field(5.0, ge=0)
    boiler_thermal_efficiency: float = Field(0.90, gt=0, le=1.0, description="Fuel->steam thermal energy efficiency")
    fuel_lhv_j_kg: float = Field(42.0e6, gt=0, description="Fuel lower heating value [J/kg], default fuel oil-like")

    @model_validator(mode="after")
    def _check_flow(self):
        if self.min_mass_flow_kg_s >= self.max_mass_flow_kg_s:
            raise ValueError("min_mass_flow_kg_s must be < max_mass_flow_kg_s")
        return self


class StageConfig(BaseModel):
    """Design data for a single turbine stage (HP/IP/LP or finer split)."""

    name: str
    isentropic_efficiency: float = Field(0.85, gt=0, le=1.0)
    mechanical_efficiency: float = Field(0.99, gt=0, le=1.0)
    nozzle_efficiency: float = Field(0.97, gt=0, le=1.0)
    reaction: float = Field(0.5, ge=0.0, le=1.0, description="Degree of reaction 0=impulse,1=full reaction")
    max_partial_admission: bool = False


class TurbineConfig(BaseModel):
    stages: list[StageConfig] = Field(default_factory=list)
    rotor_diameter_m: float = Field(1.2, gt=0)
    rotor_mass_kg: float = Field(4500.0, gt=0)
    rotor_length_m: float = Field(3.5, gt=0)
    windage_loss_coefficient: float = Field(1.2e-6, ge=0, description="Empirical windage loss scale factor")
    leakage_loss_fraction: float = Field(0.02, ge=0, le=0.2)

    @model_validator(mode="after")
    def _need_stages(self):
        if not self.stages:
            raise ValueError("TurbineConfig requires at least one StageConfig")
        return self


class ShaftConfig(BaseModel):
    diameter_m: float = Field(0.35, gt=0)
    length_m: float = Field(6.0, gt=0)
    material_density_kg_m3: float = Field(7850.0, gt=0, description="Forged steel rotor/shaft")
    allowable_shear_stress_pa: float = Field(120e6, gt=0, description="Design allowable torsional shear stress")
    youngs_modulus_pa: float = Field(200e9, gt=0)
    shear_modulus_pa: float = Field(80e9, gt=0)
    torsional_stiffness_safety_factor: float = Field(2.5, gt=1.0)


class BearingConfig(BaseModel):
    count: int = Field(2, ge=1)
    friction_coefficient: float = Field(0.0015, gt=0, description="Effective journal-bearing friction coeff")
    load_capacity_n: float = Field(2.0e6, gt=0)


class GearboxConfig(BaseModel):
    present: bool = True
    rated_ratio: float = Field(1.0, gt=0, description="turbine_rpm / generator_rpm; 1.0 = direct drive")
    base_efficiency: float = Field(0.985, gt=0, le=1.0)
    efficiency_ratio_sensitivity: float = Field(0.01, ge=0, description="Efficiency loss per unit ratio deviation from design")


class GeneratorConfig(BaseModel):
    rated_electrical_power_w: float = Field(20.0e6, gt=0)
    rated_rpm: float = Field(3000.0, gt=0)
    poles: int = Field(2, ge=2, description="Determines synchronous speed for grid frequency lock")
    grid_frequency_hz: float = Field(50.0, gt=0)
    no_load_loss_fraction: float = Field(0.01, ge=0, le=0.2, description="Iron/core loss, ~constant with load")
    full_load_copper_loss_fraction: float = Field(0.02, ge=0, le=0.2, description="I^2R loss at rated load")
    power_factor: float = Field(0.9, gt=0, le=1.0)

    @property
    def synchronous_rpm(self) -> float:
        return 120.0 * self.grid_frequency_hz / self.poles


class CondenserConfig(BaseModel):
    design_pressure_pa: float = Field(5.0e3, gt=0)
    cooling_water_inlet_temp_k: float = Field(288.15, gt=273.15)
    terminal_temperature_difference_k: float = Field(4.0, gt=0, description="Hotwell T - cooling water outlet T")
    overall_heat_transfer_coefficient_w_m2k: float = Field(2500.0, gt=0)
    heat_transfer_area_m2: float = Field(6000.0, gt=0)
    max_cooling_water_flow_kg_s: float = Field(2500.0, gt=0)
    min_pressure_pa: float = Field(2.0e3, gt=0, description="Vacuum limit (air in-leakage / backpressure floor)")
    max_pressure_pa: float = Field(15.0e3, gt=0)


class SafetyLimits(BaseModel):
    """Hard operating envelope. The optimiser MUST reject any candidate
    operating point that violates any of these (section 27)."""

    min_rpm: float = Field(500.0, ge=0)
    max_rpm: float = Field(3600.0, gt=0)
    critical_speed_margin_pct: float = Field(15.0, ge=0, description="Required separation from any critical speed")
    max_vibration_amplitude_m: float = Field(75e-6, gt=0, description="ISO-style alarm limit, 75 microns")
    max_shaft_stress_pa: float = Field(120e6, gt=0)
    min_inlet_pressure_pa: float = Field(1.0e6, gt=0)
    max_inlet_pressure_pa: float = Field(12.0e6, gt=0)
    min_inlet_temperature_k: float = Field(473.15, gt=0)
    max_inlet_temperature_k: float = Field(823.15, gt=0)
    max_exhaust_wetness_fraction: float = Field(0.12, ge=0, le=1.0, description="Max moisture at LP exhaust, erosion limit")
    min_condenser_pressure_pa: float = Field(2.0e3, gt=0)
    max_condenser_pressure_pa: float = Field(20.0e3, gt=0)
    max_generator_load_fraction: float = Field(1.05, gt=0, description="Short-term overload allowance")
    min_gear_ratio: float = Field(0.2, gt=0)
    max_gear_ratio: float = Field(30.0, gt=0)

    @model_validator(mode="after")
    def _order(self):
        if self.min_rpm >= self.max_rpm:
            raise ValueError("min_rpm must be < max_rpm")
        if self.min_inlet_pressure_pa >= self.max_inlet_pressure_pa:
            raise ValueError("min_inlet_pressure_pa must be < max_inlet_pressure_pa")
        return self


class EconomicConfig(BaseModel):
    fuel_cost_per_j: float = Field(3.5e-9, gt=0, description="$/J of fuel input (~ $3.5/GJ typical industrial gas)")
    electricity_price_per_wh: float = Field(0.00007, gt=0, description="$/Wh sale price (~ $70/MWh)")
    fixed_om_cost_per_s: float = Field(0.02, ge=0, description="$/s fixed operating & maintenance overhead")
    variable_maintenance_cost_per_rpm_hour: float = Field(1.5e-6, ge=0, description="$ per (rpm x hour) of wear-driven maintenance accrual")
    random_seed: int = Field(42, description="Deterministic seed for Monte Carlo / stochastic studies")


class PlantConfig(BaseModel):
    """The complete plant configuration bundle."""

    name: str = "TURBOFLUX Baseline Unit"
    steam_supply: SteamSupplyConfig = Field(default_factory=SteamSupplyConfig)
    turbine: TurbineConfig
    shaft: ShaftConfig = Field(default_factory=ShaftConfig)
    bearings: BearingConfig = Field(default_factory=BearingConfig)
    gearbox: GearboxConfig = Field(default_factory=GearboxConfig)
    generator: GeneratorConfig = Field(default_factory=GeneratorConfig)
    condenser: CondenserConfig = Field(default_factory=CondenserConfig)
    limits: SafetyLimits = Field(default_factory=SafetyLimits)
    economics: EconomicConfig = Field(default_factory=EconomicConfig)

    model_config = {"arbitrary_types_allowed": True}
