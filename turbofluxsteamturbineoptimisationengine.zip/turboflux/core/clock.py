"""core/clock.py - a trivial deterministic simulation clock."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class SimulationClock:
    dt_s: float
    t_s: float = 0.0
    step_count: int = 0

    def tick(self) -> float:
        self.t_s += self.dt_s
        self.step_count += 1
        return self.t_s

    def reset(self) -> None:
        self.t_s = 0.0
        self.step_count = 0
