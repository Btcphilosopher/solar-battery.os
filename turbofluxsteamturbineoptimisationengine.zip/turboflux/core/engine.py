"""
core/engine.py
================
The central steady-state simulation engine: STEAM -> TURBINE -> SHAFT ->
GEARBOX -> GENERATOR -> ELECTRICAL OUTPUT, with a fully closed energy
balance (section 15). This is the single function the optimiser,
parameter sweeps, sensitivity analysis, Monte Carlo, and the digital twin
all call to turn one OperatingPoint into a scored SystemState.

Energy accounting identity enforced here (derived directly from the
Rankine h1-h2-h3-h4 energy balance, see thermodynamics/cycle.py):

    Q_boiler + W_pump
        = P_windage_leakage_loss + P_turbine_health_loss + P_bearing_loss
          + P_gearbox_loss + P_generator_loss + P_net_electrical
          + Q_condenser

If this identity does not hold to a tight tolerance, ``energy_balance_residual_w``
is non-zero and a note is attached - the model refuses to silently
present an inconsistent energy balance.
"""
from __future__ import annotations

import math

from core.configuration import PlantConfig
from core.state import ComponentHealth, DataProvenance, OperatingPoint, SystemState, utcnow
from generator.generator import run_generator
from mechanical.bearings import bearing_loss_w
from mechanical.gearbox import apply_gearbox
from mechanical.shaft import evaluate_shaft
from mechanical.torque import power_from_torque, rpm_to_rad_s, torque_from_power
from mechanical.vibration import evaluate_vibration
from thermal.condenser import solve_condenser
from thermodynamics.cycle import cycle_energy_balance, feed_pump_work_j_kg
from thermodynamics.properties import wetness_fraction
from thermodynamics.steam import state_pt, state_px
from turbine.rotor import RotorGeometry
from turbine.turbine import run_turbine

GRAVITY_M_S2 = 9.80665


def simulate(
    config: PlantConfig,
    operating_point: OperatingPoint,
    health: ComponentHealth | None = None,
    provenance: DataProvenance = DataProvenance.SIMULATED,
    condenser_iterations: int = 2,
) -> SystemState:
    health = health or ComponentHealth()
    notes: list[str] = []

    inlet = state_pt(operating_point.inlet_pressure_pa, operating_point.inlet_temperature_k)
    rotor = RotorGeometry(
        diameter_m=config.turbine.rotor_diameter_m,
        mass_kg=config.turbine.rotor_mass_kg,
        length_m=config.turbine.rotor_length_m,
    )

    # --- fixed-point resolve of condenser pressure vs turbine exhaust ---
    condenser_p = operating_point.condenser_pressure_pa
    turbine_result = None
    condenser_result = None
    for _ in range(max(1, condenser_iterations)):
        turbine_result = run_turbine(
            config.turbine,
            rotor,
            inlet,
            condenser_p,
            operating_point.steam_mass_flow_kg_s,
            operating_point.shaft_rpm,
            operating_point.stage_pressure_ratios or None,
        )
        if operating_point.cooling_water_flow_kg_s > 0:
            condenser_result = solve_condenser(
                config.condenser,
                operating_point.steam_mass_flow_kg_s,
                turbine_result.exhaust_state.enthalpy_j_kg,
                operating_point.cooling_water_flow_kg_s,
                operating_point.cooling_water_inlet_temp_k,
                health.condenser_fouling_factor,
            )
            new_p = condenser_result.condenser_pressure_pa
        else:
            new_p = condenser_p
        converged = abs(new_p - condenser_p) <= max(1.0, 1e-3 * condenser_p)
        condenser_p = new_p
        if converged:
            break
    # Re-run the turbine once more at the converged condenser pressure so
    # the exhaust state used downstream is exactly consistent with the
    # condenser pressure fed into the whole-cycle energy balance below -
    # otherwise a not-quite-converged fixed point would leak a small but
    # "unexplained" energy-balance residual (section 15 explicitly
    # requires such discrepancies to be flagged, not hidden by reuse of a
    # stale intermediate state).
    turbine_result = run_turbine(
        config.turbine,
        rotor,
        inlet,
        condenser_p,
        operating_point.steam_mass_flow_kg_s,
        operating_point.shaft_rpm,
        operating_point.stage_pressure_ratios or None,
    )
    notes.extend(turbine_result.notes)
    if condenser_result:
        notes.extend(condenser_result.notes)
    if abs(condenser_p - operating_point.condenser_pressure_pa) > max(200.0, 0.05 * operating_point.condenser_pressure_pa):
        notes.append(
            f"Achieved condenser pressure ({condenser_p:.0f} Pa) diverged from the requested/target "
            f"operating_point.condenser_pressure_pa ({operating_point.condenser_pressure_pa:.0f} Pa) once "
            f"solved against the given cooling-water flow/temperature - the achieved value drives the "
            f"turbine expansion and is reported separately as achieved_condenser_pressure_pa."
        )

    # --- whole-cycle thermodynamic accounting (h1-h2-h3-h4) ---
    # h1 = condensate (pump inlet); h2 = boiler inlet = h1 + feed-pump work
    # (no FWH train - documented simplification). Skipping the pump-work
    # addend here would silently leak mass_flow*w_pump out of the energy
    # balance - exactly the kind of "unexplained discrepancy" section 15
    # requires this model to catch, not produce.
    condensate = state_px(condenser_p, 0.0)
    pump_work_specific_j_kg = feed_pump_work_j_kg(condensate, operating_point.inlet_pressure_pa)
    boiler_inlet_enthalpy_j_kg = condensate.enthalpy_j_kg + pump_work_specific_j_kg
    cycle = cycle_energy_balance(
        mass_flow_kg_s=operating_point.steam_mass_flow_kg_s,
        boiler_inlet_enthalpy_j_kg=boiler_inlet_enthalpy_j_kg,
        turbine_inlet_enthalpy_j_kg=inlet.enthalpy_j_kg,
        turbine_exhaust_enthalpy_j_kg=turbine_result.exhaust_state.enthalpy_j_kg,
        condenser_pressure_pa=condenser_p,
        boiler_pressure_pa=operating_point.inlet_pressure_pa,
    )

    # --- mechanical loss / windage-leakage accounting ---
    p_windage_leakage_loss = max(0.0, cycle.turbine_work_w - turbine_result.total_actual_power_w)
    p_health_loss = turbine_result.total_actual_power_w * (1.0 - health.turbine_efficiency_factor)
    p_turbine_delivered = turbine_result.total_actual_power_w * health.turbine_efficiency_factor

    omega = rpm_to_rad_s(operating_point.shaft_rpm)
    turbine_torque = p_turbine_delivered / omega if omega > 0 else 0.0

    rotor_weight_n = rotor.mass_kg * GRAVITY_M_S2
    bearing = bearing_loss_w(config.bearings, rotor_weight_n, config.shaft.diameter_m, operating_point.shaft_rpm)
    p_bearing_loss = bearing.friction_power_loss_w * health.bearing_friction_factor
    p_net_shaft = max(0.0, p_turbine_delivered - p_bearing_loss)
    net_shaft_torque = p_net_shaft / omega if omega > 0 else 0.0

    gearbox = apply_gearbox(
        config.gearbox, operating_point.shaft_rpm, net_shaft_torque, operating_point.gear_ratio, health.gearbox_efficiency_factor
    )

    generator = run_generator(config.generator, gearbox.output_power_w, health.generator_efficiency_factor)

    # --- energy balance closure check ---
    lhs = cycle.boiler_heat_input_w + cycle.pump_work_w
    rhs = (
        p_windage_leakage_loss
        + p_health_loss
        + p_bearing_loss
        + gearbox.loss_w
        + generator.loss_w
        + generator.electrical_output_w
        + cycle.condenser_heat_rejected_w
    )
    residual = lhs - rhs
    if abs(residual) > max(1.0, 1e-4 * max(lhs, 1.0)):
        notes.append(
            f"Energy balance residual {residual:.2f} W exceeds tolerance "
            f"(input {lhs:.1f} W vs accounted {rhs:.1f} W) - investigate before trusting this result."
        )

    # --- mechanical safety diagnostics ---
    shaft_check = evaluate_shaft(config.shaft, turbine_torque)
    vibration = evaluate_vibration(config.shaft, rotor.mass_kg, operating_point.shaft_rpm, config.limits)
    exhaust_wetness = wetness_fraction(turbine_result.exhaust_state)

    state = SystemState(
        timestamp=utcnow(),
        provenance=provenance,
        operating_point=operating_point,
        health=health,
        inlet_enthalpy_j_kg=inlet.enthalpy_j_kg,
        exhaust_enthalpy_j_kg=turbine_result.exhaust_state.enthalpy_j_kg,
        exhaust_quality=turbine_result.exhaust_state.quality,
        isentropic_enthalpy_drop_j_kg=cycle.turbine_work_w / operating_point.steam_mass_flow_kg_s if operating_point.steam_mass_flow_kg_s > 0 else 0.0,
        actual_enthalpy_drop_j_kg=(inlet.enthalpy_j_kg - turbine_result.exhaust_state.enthalpy_j_kg),
        ideal_turbine_power_w=turbine_result.efficiency.total_ideal_power_w,
        actual_turbine_power_w=p_turbine_delivered,
        turbine_health_degradation_loss_w=p_health_loss,
        mechanical_loss_w=p_bearing_loss + p_windage_leakage_loss,
        net_shaft_power_w=p_net_shaft,
        gearbox_loss_w=gearbox.loss_w,
        generator_input_power_w=gearbox.output_power_w,
        generator_loss_w=generator.loss_w,
        net_electrical_power_w=generator.electrical_output_w,
        condenser_heat_rejected_w=cycle.condenser_heat_rejected_w,
        achieved_condenser_pressure_pa=condenser_p,
        turbine_isentropic_efficiency=turbine_result.efficiency.overall_isentropic_efficiency,
        cycle_thermal_efficiency=cycle.thermal_efficiency,
        generator_efficiency=generator.efficiency,
        overall_efficiency=(generator.electrical_output_w / cycle.boiler_heat_input_w) if cycle.boiler_heat_input_w > 0 else 0.0,
        shaft_torque_n_m=turbine_torque,
        generator_rpm=gearbox.generator_rpm,
        shaft_stress_pa=shaft_check.shear_stress_pa,
        vibration_amplitude_m=vibration.amplitude_m,
        nearest_critical_speed_rpm=vibration.nearest_critical_rpm,
        critical_speed_margin_pct=vibration.margin_pct,
        stage_results=turbine_result.stages,
        energy_balance_residual_w=residual,
        notes=notes,
    )

    from optimisation.constraints import check_constraints  # local import: avoid module-load cycle

    state.constraint_violations = check_constraints(config, operating_point, state, exhaust_wetness, shaft_check.within_allowable)
    return state
