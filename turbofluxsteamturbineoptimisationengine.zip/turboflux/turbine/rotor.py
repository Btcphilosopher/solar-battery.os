"""
turbine/rotor.py
==================
Turbine rotor geometry. Inertial dynamics (I, KE, spin-up) live in
mechanical/inertia.py; this module owns the geometric description used by
the blade-speed and stress calculations.
"""
from __future__ import annotations

from dataclasses import dataclass
import math


@dataclass(frozen=True)
class RotorGeometry:
    diameter_m: float
    mass_kg: float
    length_m: float

    @property
    def radius_m(self) -> float:
        return self.diameter_m / 2.0

    @property
    def polar_moment_of_inertia_kg_m2(self) -> float:
        """Solid-cylinder approximation: I = 1/2 * m * r^2. Real rotors are
        stepped/hollow assemblies; this is a first-order MODELLED estimate
        documented here rather than treated as a measured value."""
        return 0.5 * self.mass_kg * self.radius_m ** 2

    @property
    def volume_m3(self) -> float:
        return math.pi * self.radius_m ** 2 * self.length_m

    def tip_speed_m_s(self, rpm: float) -> float:
        return math.pi * self.diameter_m * rpm / 60.0
