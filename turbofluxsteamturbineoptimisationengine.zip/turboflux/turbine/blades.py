"""
turbine/blades.py
===================
Blade-speed / velocity-triangle relationships. This is where "RPM" gets
tied to steam jet velocity and hence to stage efficiency: an impulse
stage's peak efficiency occurs near a blade-speed ratio nu = u / c1 of
about 0.5 (single-row impulse), NOT at the highest achievable u. Running
faster than the optimal ratio does not automatically raise power - this
is the concrete mechanism behind the section-7 requirement that "maximum
RPM is NOT automatically maximum power".
"""
from __future__ import annotations

from dataclasses import dataclass
import math


@dataclass(frozen=True)
class BladeSpeedResult:
    blade_speed_m_s: float
    velocity_ratio: float  # u / c1
    optimal_velocity_ratio: float
    stage_utilisation_factor: float  # actual/optimal efficiency scaling in [0,1]


def blade_speed_m_s(rotor_diameter_m: float, rpm: float) -> float:
    """u = pi * D * N / 60."""
    return math.pi * rotor_diameter_m * rpm / 60.0


def optimal_velocity_ratio(reaction: float) -> float:
    """Classical optimum blade-speed ratio:
    - impulse stage (reaction=0):        u/c1 ~= cos(alpha1)/2 -> use 0.5 nominal
    - 50% reaction stage (reaction=0.5): u/c1 ~= cos(alpha1)   -> use ~0.7-0.85 nominal
    Interpolated linearly in `reaction` between the two textbook nominal
    values (0.5 impulse -> 0.75 reaction) for a smooth, monotonic model
    suitable for gradient-based optimisation."""
    return 0.5 + 0.5 * reaction  # reaction=0 -> 0.5 ; reaction=1 -> 1.0


def stage_utilisation(velocity_ratio: float, opt_ratio: float, sharpness: float = 2.5) -> float:
    """Smooth penalty (a raised cosine / parabola around the optimum)
    representing how much of the maximum attainable stage efficiency is
    realised at a given off-design blade-speed ratio. 1.0 at nu=nu_opt,
    falling off symmetrically. This is an explicit MODELLED simplification
    of full velocity-triangle blade-loss curves, not a measured curve."""
    delta = (velocity_ratio - opt_ratio) / max(opt_ratio, 1e-9)
    factor = math.exp(-sharpness * delta * delta)
    return max(0.0, min(1.0, factor))


def evaluate_blade_speed(rotor_diameter_m: float, rpm: float, nozzle_exit_velocity_m_s: float, reaction: float) -> BladeSpeedResult:
    u = blade_speed_m_s(rotor_diameter_m, rpm)
    nu = u / nozzle_exit_velocity_m_s if nozzle_exit_velocity_m_s > 0 else 0.0
    nu_opt = optimal_velocity_ratio(reaction)
    util = stage_utilisation(nu, nu_opt)
    return BladeSpeedResult(
        blade_speed_m_s=u,
        velocity_ratio=nu,
        optimal_velocity_ratio=nu_opt,
        stage_utilisation_factor=util,
    )
