"""
turbine/losses.py
===================
Empirical/semi-empirical stage-level loss mechanisms not already captured
by the nozzle/blade-speed-ratio model:

- windage / disc friction loss (churning of steam-side atmosphere around
  spinning discs, grows strongly with RPM)
- leakage loss (steam bypassing the blading through seal clearances)
- wetness loss (Baumann rule: each 1% moisture in the LP stages costs
  roughly 1% stage efficiency - a widely used industry rule of thumb)

These are MODELLED, empirically-calibrated corrections, not derived from
first principles - documented per-function.
"""
from __future__ import annotations

import math

# Baumann coefficient: fractional efficiency loss per unit average wetness
# fraction across a wet stage. Typical accepted range 0.8-1.2; 1.0 used.
BAUMANN_COEFFICIENT = 1.0


def windage_loss_w(rotor_diameter_m: float, rpm: float, coefficient: float) -> float:
    """Disc-friction/windage power loss, scaled ~ D^5 * N^3 (classic
    Stodola-type windage correlation), with an empirical `coefficient`
    absorbing steam density, disc count and clearance effects so this
    stays dimensionally a single calibrated scale factor rather than a
    claimed absolute physical constant."""
    omega = 2.0 * math.pi * rpm / 60.0
    return coefficient * rotor_diameter_m ** 5 * omega ** 3


def leakage_loss_fraction_of_flow(clearance_loss_fraction: float) -> float:
    """Fraction of stage mass flow that bypasses the blading via seal/tip
    clearances and therefore does no work; directly configured per-stage."""
    return max(0.0, min(clearance_loss_fraction, 0.5))


def wetness_efficiency_multiplier(average_wetness_fraction: float) -> float:
    """Baumann rule: eta_multiplier = 1 - k * wetness_fraction."""
    return max(0.0, 1.0 - BAUMANN_COEFFICIENT * average_wetness_fraction)


def partial_admission_loss_fraction(admitted_arc_fraction: float) -> float:
    """Extra loss when steam is only admitted through part of the nozzle
    annulus (control-stage governing). Approximate loss scales with the
    non-admitted arc due to windage of idle buckets through inactive
    sectors; a simple linear model is used here."""
    if not 0.0 < admitted_arc_fraction <= 1.0:
        raise ValueError("admitted_arc_fraction must be in (0, 1]")
    return 0.15 * (1.0 - admitted_arc_fraction)
