"""
turbine/turbine.py
====================
Multi-stage turbine orchestration: HP -> IP -> LP (or however many stages
are configured), chaining stage outlet -> next stage inlet, and rolling up
stage results into a whole-turbine power and efficiency figure.

Also implements the stage pressure-ratio distribution optimiser referenced
in section 6: given an overall inlet/outlet pressure and a stage count,
search for the pressure split across stages that maximises total actual
power (rather than assuming equal pressure ratios, which is only a
reasonable first guess when all stages share identical efficiency and
blade-speed characteristics).
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
from scipy.optimize import minimize

from core.configuration import TurbineConfig
from thermodynamics.expansion import stage_pressures_geometric
from thermodynamics.steam import SteamState
from .efficiency import TurbineEfficiencyReport, aggregate
from .rotor import RotorGeometry
from .stage import StageResult, finalise_stage_power, run_stage


@dataclass
class TurbineResult:
    stages: list = field(default_factory=list)
    efficiency: TurbineEfficiencyReport = None
    exhaust_state: SteamState = None
    total_actual_power_w: float = 0.0
    total_torque_n_m: float = 0.0
    notes: list = field(default_factory=list)


def run_turbine(
    config: TurbineConfig,
    rotor: RotorGeometry,
    inlet: SteamState,
    condenser_pressure_pa: float,
    mass_flow_kg_s: float,
    rpm: float,
    stage_pressure_ratios: tuple[float, ...] | None = None,
) -> TurbineResult:
    """Expand steam through all configured stages in series.

    stage_pressure_ratios, if given, is the per-stage p_out/p_in (length
    == number of stages); otherwise an equal-pressure-ratio split is used
    as the default distribution.
    """
    n_stages = len(config.stages)
    if stage_pressure_ratios is None:
        pressures = stage_pressures_geometric(inlet.pressure_pa, condenser_pressure_pa, n_stages)
    else:
        if len(stage_pressure_ratios) != n_stages:
            raise ValueError("stage_pressure_ratios length must match number of configured stages")
        pressures = [inlet.pressure_pa]
        for r in stage_pressure_ratios:
            pressures.append(pressures[-1] * r)
        pressures[-1] = condenser_pressure_pa  # last stage always ends at condenser pressure

    stage_results: list[StageResult] = []
    current_inlet = inlet
    notes: list[str] = []

    for i, stage_cfg in enumerate(config.stages):
        p_out = pressures[i + 1]
        if p_out <= 0 or p_out >= current_inlet.pressure_pa:
            raise ValueError(f"Invalid stage pressure split at stage {i}: p_in={current_inlet.pressure_pa}, p_out={p_out}")

        stage_res = run_stage(
            stage_cfg,
            current_inlet,
            p_out,
            rotor.diameter_m,
            rpm,
            config.windage_loss_coefficient,
        )
        # apply the configured leakage fraction to this stage explicitly
        stage_res.leaked_flow_fraction = config.leakage_loss_fraction
        stage_res = finalise_stage_power(stage_res, mass_flow_kg_s, rpm)
        stage_results.append(stage_res)
        notes.extend(stage_res.notes)
        current_inlet = stage_res.outlet_actual

    final_isentropic_outlet_h = stage_results[-1].outlet_ideal.enthalpy_j_kg if stage_results else inlet.enthalpy_j_kg
    eff_report = aggregate(stage_results, inlet.enthalpy_j_kg, final_isentropic_outlet_h)

    total_power = sum(s.actual_power_w for s in stage_results)
    import math
    omega = 2.0 * math.pi * rpm / 60.0
    total_torque = total_power / omega if omega > 0 else 0.0

    return TurbineResult(
        stages=stage_results,
        efficiency=eff_report,
        exhaust_state=current_inlet,
        total_actual_power_w=total_power,
        total_torque_n_m=total_torque,
        notes=notes,
    )


def optimise_stage_pressure_distribution(
    config: TurbineConfig,
    rotor: RotorGeometry,
    inlet: SteamState,
    condenser_pressure_pa: float,
    mass_flow_kg_s: float,
    rpm: float,
) -> tuple[tuple[float, ...], TurbineResult]:
    """Search for the per-stage pressure-ratio split that maximises total
    actual turbine power at a fixed overall expansion, RPM and mass flow.
    Uses SLSQP with the product-of-ratios constraint held via a reduction
    (we optimise n-1 free ratios in log-space and derive the last stage's
    pressure directly from the condenser pressure, guaranteeing p_final ==
    condenser_pressure_pa exactly).
    """
    n_stages = len(config.stages)
    overall_ratio = condenser_pressure_pa / inlet.pressure_pa

    if n_stages == 1:
        ratios = (overall_ratio,)
        result = run_turbine(config, rotor, inlet, condenser_pressure_pa, mass_flow_kg_s, rpm, ratios)
        return ratios, result

    # decision vector: log of the first (n_stages - 1) stage pressure
    # ratios; the last stage ratio is derived so the product equals
    # overall_ratio exactly (keeps the search unconstrained & robust).
    x0 = np.full(n_stages - 1, np.log(overall_ratio) / n_stages)

    def ratios_from_x(x: np.ndarray) -> tuple[float, ...]:
        free_ratios = np.exp(x)
        last_ratio = overall_ratio / np.prod(free_ratios)
        return tuple(free_ratios.tolist() + [float(last_ratio)])

    def negative_power(x: np.ndarray) -> float:
        ratios = ratios_from_x(x)
        if any(r <= 0 or r >= 1.0 for r in ratios):
            return 1e12
        try:
            res = run_turbine(config, rotor, inlet, condenser_pressure_pa, mass_flow_kg_s, rpm, ratios)
        except Exception:
            return 1e12
        return -res.total_actual_power_w

    opt = minimize(negative_power, x0, method="Nelder-Mead", options={"xatol": 1e-4, "fatol": 1.0, "maxiter": 400})
    best_ratios = ratios_from_x(opt.x)
    best_result = run_turbine(config, rotor, inlet, condenser_pressure_pa, mass_flow_kg_s, rpm, best_ratios)
    return best_ratios, best_result
