"""
turbine/nozzle.py
===================
Converging (or converging-diverging) nozzle model: converts enthalpy drop
into steam kinetic energy ahead of the moving blades.

    c1 = nozzle_efficiency-weighted spouting velocity
       = sqrt(2 * eta_nozzle * dh_isentropic)   [steady-flow energy eqn,
         neglecting inlet velocity and elevation change]

Also implements the classical critical (choking) pressure ratio for
steam, beyond which the nozzle throat velocity saturates at sonic and
further downstream pressure reduction does not increase throat mass
flow - this bounds how much a single converging nozzle stage can exploit
pressure ratio, a real constraint the RPM/pressure optimiser must respect.
"""
from __future__ import annotations

from dataclasses import dataclass

# For low-superheat/wet steam the isentropic exponent used for the
# critical-pressure-ratio estimate is taken as k=1.135 (standard textbook
# value for wet/saturated steam expansion; k=1.3 is used for superheated
# steam). This is a well-known simplification (Zeuner/Rankine practice),
# clearly documented rather than silently assumed.
K_SUPERHEATED = 1.3
K_SATURATED = 1.135


@dataclass(frozen=True)
class NozzleResult:
    exit_velocity_m_s: float
    isentropic_enthalpy_drop_j_kg: float
    actual_enthalpy_drop_j_kg: float
    is_choked: bool
    critical_pressure_ratio: float


def critical_pressure_ratio(is_superheated: bool) -> float:
    k = K_SUPERHEATED if is_superheated else K_SATURATED
    return (2.0 / (k + 1.0)) ** (k / (k - 1.0))


def spouting_velocity_m_s(isentropic_enthalpy_drop_j_kg: float, nozzle_efficiency: float) -> float:
    if isentropic_enthalpy_drop_j_kg < 0:
        raise ValueError("isentropic_enthalpy_drop_j_kg must be >= 0")
    return (2.0 * nozzle_efficiency * isentropic_enthalpy_drop_j_kg) ** 0.5


def evaluate_nozzle(
    inlet_pressure_pa: float,
    outlet_pressure_pa: float,
    isentropic_enthalpy_drop_j_kg: float,
    nozzle_efficiency: float,
    is_superheated: bool,
) -> NozzleResult:
    r_crit = critical_pressure_ratio(is_superheated)
    r_actual = outlet_pressure_pa / inlet_pressure_pa
    choked = r_actual < r_crit

    dh_actual = nozzle_efficiency * isentropic_enthalpy_drop_j_kg
    c1 = spouting_velocity_m_s(isentropic_enthalpy_drop_j_kg, nozzle_efficiency)

    return NozzleResult(
        exit_velocity_m_s=c1,
        isentropic_enthalpy_drop_j_kg=isentropic_enthalpy_drop_j_kg,
        actual_enthalpy_drop_j_kg=dh_actual,
        is_choked=choked,
        critical_pressure_ratio=r_crit,
    )
