"""
turbine/efficiency.py
=======================
Aggregation of per-stage results into whole-turbine efficiency figures.
"""
from __future__ import annotations

from dataclasses import dataclass

from thermodynamics.enthalpy import reheat_factor


@dataclass(frozen=True)
class TurbineEfficiencyReport:
    overall_isentropic_efficiency: float
    reheat_factor: float
    total_ideal_power_w: float
    total_actual_power_w: float
    total_windage_loss_w: float


def aggregate(stage_results: list, inlet_enthalpy_j_kg: float, final_isentropic_outlet_enthalpy_j_kg: float) -> TurbineEfficiencyReport:
    total_ideal = sum(s.ideal_power_w for s in stage_results)
    total_actual = sum(s.actual_power_w for s in stage_results)
    total_windage = sum(s.windage_loss_w for s in stage_results)

    overall_isentropic_drop = inlet_enthalpy_j_kg - final_isentropic_outlet_enthalpy_j_kg
    mass_flow = stage_results[0].mass_flow_kg_s if stage_results else 0.0
    overall_ideal_power = mass_flow * overall_isentropic_drop if overall_isentropic_drop > 0 else total_ideal

    eta_overall = total_actual / overall_ideal_power if overall_ideal_power > 0 else 0.0

    rf = reheat_factor(
        [s.isentropic_enthalpy_drop_j_kg for s in stage_results],
        overall_isentropic_drop,
    ) if overall_isentropic_drop > 0 else 1.0

    return TurbineEfficiencyReport(
        overall_isentropic_efficiency=max(0.0, min(1.0, eta_overall)),
        reheat_factor=rf,
        total_ideal_power_w=total_ideal,
        total_actual_power_w=total_actual,
        total_windage_loss_w=total_windage,
    )
