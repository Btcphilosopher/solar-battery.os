"""Multi-stage turbine model: nozzle -> blading -> rotor, stage by stage."""
