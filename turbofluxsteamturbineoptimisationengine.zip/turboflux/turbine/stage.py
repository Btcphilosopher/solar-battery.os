"""
turbine/stage.py
==================
A single turbine stage: nozzle -> moving blades -> stage exit. Combines
thermodynamics/expansion.py (enthalpy drop), turbine/nozzle.py (velocity),
turbine/blades.py (blade-speed-ratio utilisation) and turbine/losses.py
(windage, leakage, wetness) into one MODELLED stage result.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from core.configuration import StageConfig
from thermodynamics.expansion import expand, isentropic_outlet
from thermodynamics.properties import wetness_fraction
from thermodynamics.steam import SteamState
from .blades import evaluate_blade_speed
from .losses import leakage_loss_fraction_of_flow, wetness_efficiency_multiplier, windage_loss_w
from .nozzle import evaluate_nozzle


@dataclass
class StageResult:
    name: str
    inlet: SteamState
    outlet_ideal: SteamState
    outlet_actual: SteamState
    pressure_ratio: float
    mass_flow_kg_s: float
    isentropic_enthalpy_drop_j_kg: float
    actual_enthalpy_drop_j_kg: float
    effective_isentropic_efficiency: float
    blade_speed_m_s: float
    velocity_ratio: float
    optimal_velocity_ratio: float
    stage_utilisation_factor: float
    windage_loss_w: float
    leaked_flow_fraction: float
    ideal_power_w: float
    actual_power_w: float
    torque_n_m: float
    notes: list = field(default_factory=list)


def run_stage(
    config: StageConfig,
    inlet: SteamState,
    outlet_pressure_pa: float,
    rotor_diameter_m: float,
    rpm: float,
    windage_coefficient: float,
) -> StageResult:
    notes: list[str] = []

    # 1) blade-speed utilisation modifies the *effective* isentropic
    #    efficiency actually realised at this RPM - this is the mechanism
    #    that stops "spin faster -> more power" being true unconditionally.
    is_superheated = inlet.quality is None
    # Only the isentropic (constant-entropy) outlet is needed here, not a
    # full actual-expansion result - one IAPWS call instead of two, on the
    # hottest path in the whole simulation (called once per stage, several
    # times per steady-state simulate() call).
    ideal_dh_probe = inlet.enthalpy_j_kg - isentropic_outlet(inlet, outlet_pressure_pa).enthalpy_j_kg
    nozzle_result = evaluate_nozzle(
        inlet.pressure_pa, outlet_pressure_pa, ideal_dh_probe, config.nozzle_efficiency, is_superheated
    )
    blade_result = evaluate_blade_speed(rotor_diameter_m, rpm, nozzle_result.exit_velocity_m_s, config.reaction)

    if nozzle_result.is_choked:
        notes.append(
            f"Stage '{config.name}': nozzle choked (pressure ratio "
            f"{outlet_pressure_pa/inlet.pressure_pa:.3f} < critical "
            f"{nozzle_result.critical_pressure_ratio:.3f}); throat velocity sonic-limited."
        )

    effective_eta = config.isentropic_efficiency * blade_result.stage_utilisation_factor

    # 2) apply wetness (Baumann) correction using the *ideal* outlet's
    #    wetness as a proxy for average in-stage wetness.
    probe_expansion = expand(inlet, outlet_pressure_pa, max(effective_eta, 1e-6))
    avg_wetness = 0.5 * (wetness_fraction(inlet) + wetness_fraction(probe_expansion.outlet_actual))
    if avg_wetness > 0:
        wet_mult = wetness_efficiency_multiplier(avg_wetness)
        effective_eta *= wet_mult
        notes.append(f"Stage '{config.name}': wetness correction applied, multiplier={wet_mult:.4f}")

    effective_eta = max(1e-6, min(0.995, effective_eta))

    expansion = expand(inlet, outlet_pressure_pa, effective_eta)

    leak_frac = leakage_loss_fraction_of_flow(0.0)  # per-stage clearance loss set by caller via mass flow adj.
    windage_w = windage_loss_w(rotor_diameter_m, rpm, windage_coefficient)

    return StageResult(
        name=config.name,
        inlet=inlet,
        outlet_ideal=expansion.outlet_ideal,
        outlet_actual=expansion.outlet_actual,
        pressure_ratio=outlet_pressure_pa / inlet.pressure_pa,
        mass_flow_kg_s=0.0,  # filled in by caller (turbine.py) once flow is known
        isentropic_enthalpy_drop_j_kg=expansion.isentropic_enthalpy_drop_j_kg,
        actual_enthalpy_drop_j_kg=expansion.actual_enthalpy_drop_j_kg,
        effective_isentropic_efficiency=effective_eta,
        blade_speed_m_s=blade_result.blade_speed_m_s,
        velocity_ratio=blade_result.velocity_ratio,
        optimal_velocity_ratio=blade_result.optimal_velocity_ratio,
        stage_utilisation_factor=blade_result.stage_utilisation_factor,
        windage_loss_w=windage_w,
        leaked_flow_fraction=leak_frac,
        ideal_power_w=0.0,
        actual_power_w=0.0,
        torque_n_m=0.0,
        notes=notes,
    )


def finalise_stage_power(stage: StageResult, mass_flow_kg_s: float, rpm: float) -> StageResult:
    """Apply the known net stage mass flow to compute power and torque,
    after leakage has removed its share of flow from doing work."""
    import math

    effective_flow = mass_flow_kg_s * (1.0 - stage.leaked_flow_fraction)
    stage.mass_flow_kg_s = mass_flow_kg_s
    stage.ideal_power_w = effective_flow * stage.isentropic_enthalpy_drop_j_kg
    gross_actual_power = effective_flow * stage.actual_enthalpy_drop_j_kg
    stage.actual_power_w = max(0.0, gross_actual_power - stage.windage_loss_w)
    omega = 2.0 * math.pi * rpm / 60.0
    stage.torque_n_m = stage.actual_power_w / omega if omega > 0 else 0.0
    return stage
