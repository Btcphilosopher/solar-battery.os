"""
visualisation/turbine_plots.py
=================================
Power/torque/efficiency vs RPM, steam-flow vs power, pressure-ratio vs
power, stage-by-stage energy conversion, and the whole-plant Sankey
energy balance (section 23).
"""
from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import plotly.graph_objects as go

from core.state import SystemState


def power_torque_efficiency_vs_rpm(df: pd.DataFrame, optimal_rpm: float | None, out_path: str) -> str:
    fig, axes = plt.subplots(3, 1, figsize=(8, 10), sharex=True)

    axes[0].plot(df["shaft_rpm"], df["net_electrical_power_w"] / 1e3, color="#1f77b4", lw=2)
    axes[0].set_ylabel("Net electrical power [kW]")
    axes[0].set_title("Power, Torque and Efficiency vs Shaft RPM")

    axes[1].plot(df["shaft_rpm"], df["shaft_torque_n_m"], color="#d62728", lw=2)
    axes[1].set_ylabel("Shaft torque [N.m]")

    axes[2].plot(df["shaft_rpm"], df["overall_efficiency"] * 100, color="#2ca02c", lw=2)
    axes[2].set_ylabel("Overall efficiency [%]")
    axes[2].set_xlabel("Shaft RPM")

    if optimal_rpm is not None:
        for ax in axes:
            ax.axvline(optimal_rpm, color="k", linestyle="--", alpha=0.6, label=f"Optimal RPM = {optimal_rpm:.0f}")
        axes[0].legend()

    for ax in axes:
        ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return out_path


def steam_flow_vs_power(df: pd.DataFrame, out_path: str) -> str:
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.plot(df["steam_mass_flow_kg_s"], df["net_electrical_power_w"] / 1e3, color="#9467bd", lw=2, marker="o", ms=3)
    ax.set_xlabel("Steam mass flow [kg/s]")
    ax.set_ylabel("Net electrical power [kW]")
    ax.set_title("Steam Flow vs Net Electrical Power")
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return out_path


def pressure_ratio_vs_power(df: pd.DataFrame, out_path: str) -> str:
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.plot(df["inlet_pressure_pa"] / 1e6, df["net_electrical_power_w"] / 1e3, color="#ff7f0e", lw=2, marker="o", ms=3)
    ax.set_xlabel("Inlet pressure [MPa]")
    ax.set_ylabel("Net electrical power [kW]")
    ax.set_title("Inlet Pressure vs Net Electrical Power")
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return out_path


def stage_energy_conversion(state: SystemState, out_path: str) -> str:
    names = [s.name for s in state.stage_results]
    ideal = [s.ideal_power_w / 1e3 for s in state.stage_results]
    actual = [s.actual_power_w / 1e3 for s in state.stage_results]

    x = range(len(names))
    fig, ax = plt.subplots(figsize=(8, 5))
    width = 0.35
    ax.bar([i - width / 2 for i in x], ideal, width, label="Ideal (isentropic) power", color="#aec7e8")
    ax.bar([i + width / 2 for i in x], actual, width, label="Actual power", color="#1f77b4")
    ax.set_xticks(list(x))
    ax.set_xticklabels(names)
    ax.set_ylabel("Power [kW]")
    ax.set_title("Stage-by-Stage Energy Conversion")
    ax.legend()
    ax.grid(axis="y", alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return out_path


def energy_balance_sankey(state: SystemState, out_path: str) -> str:
    """Whole-plant Sankey diagram (section 15/23): boiler heat input flows
    serially through the shaft, gearbox and generator, with every loss
    term and the final electrical output and condenser heat rejection
    drawn as explicit branches - built strictly from the same terms
    core/engine.py uses to close the energy balance (net_shaft_power_w =
    boiler heat minus turbine/bearing losses minus condenser rejection;
    gearbox output = net shaft power minus gearbox loss; net electrical =
    gearbox output minus generator loss), so this diagram and the numeric
    energy balance report can never silently disagree.

    Rendered with Plotly and saved as a standalone HTML file (Sankey
    layouts don't translate well to a static PNG without an extra
    `kaleido` dependency, so HTML keeps this dependency-light while
    staying fully inspectable in a browser)."""
    turbine_bearing_losses = state.mechanical_loss_w + state.turbine_health_degradation_loss_w

    labels = [
        "Boiler Heat Input",                                     # 0
        "Net Shaft Power",                                       # 1
        "Turbine & Bearing Losses\n(windage, leakage, friction, degradation)",  # 2
        "Condenser Heat Rejected",                               # 3
        "Gearbox Output",                                        # 4
        "Gearbox Loss",                                          # 5
        "Net Electrical Output",                                 # 6
        "Generator Loss",                                        # 7
    ]
    source = [0, 0, 0, 1, 1, 4, 4]
    target = [1, 2, 3, 4, 5, 6, 7]
    value = [
        state.net_shaft_power_w,
        turbine_bearing_losses,
        state.condenser_heat_rejected_w,
        state.generator_input_power_w,
        state.gearbox_loss_w,
        state.net_electrical_power_w,
        state.generator_loss_w,
    ]

    fig = go.Figure(go.Sankey(
        node=dict(
            label=labels,
            pad=20,
            thickness=18,
            color=["#4c78a8", "#4c78a8", "#e45756", "#e45756", "#4c78a8", "#e45756", "#54a24b", "#e45756"],
        ),
        link=dict(source=source, target=target, value=[max(v, 0.0) for v in value]),
    ))
    fig.update_layout(title_text="TURBOFLUX Whole-Plant Energy Balance (W)", font_size=12)
    fig.write_html(out_path)
    return out_path
