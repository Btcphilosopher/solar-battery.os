"""Engineering plots for TURBOFLUX. Matplotlib runs headless (Agg)."""
import matplotlib

matplotlib.use("Agg")
