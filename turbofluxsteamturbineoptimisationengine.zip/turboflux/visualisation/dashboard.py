"""
visualisation/dashboard.py
=============================
Section 24: a single-figure engineering dashboard summarising turbine
status, current vs optimised operating point, and the power/efficiency
improvement.
"""
from __future__ import annotations

import matplotlib.pyplot as plt

from analytics.bottlenecks import loss_breakdown
from analytics.performance import compute_kpis
from core.state import SystemState


def render_dashboard(current: SystemState, optimised: SystemState, out_path: str) -> str:
    fig = plt.figure(figsize=(14, 9))
    gs = fig.add_gridspec(3, 3, hspace=0.55, wspace=0.4)

    c_kpi = compute_kpis(current)
    o_kpi = compute_kpis(optimised)

    # --- panel: status text block ---
    ax_status = fig.add_subplot(gs[0, 0])
    ax_status.axis("off")
    status_lines = [
        "TURBINE STATUS (current)",
        f"RPM: {c_kpi.shaft_rpm:,.0f}",
        f"Torque: {c_kpi.shaft_torque_n_m:,.0f} N.m",
        f"Steam flow: {current.operating_point.steam_mass_flow_kg_s:,.2f} kg/s",
        f"Inlet P/T: {current.operating_point.inlet_pressure_pa/1e6:.2f} MPa / {current.operating_point.inlet_temperature_k-273.15:.0f} C",
        f"Exhaust P: {current.operating_point.condenser_pressure_pa/1e3:.2f} kPa",
        f"Shaft power: {current.net_shaft_power_w/1e3:,.0f} kW",
        f"Generator power: {current.net_electrical_power_w/1e3:,.0f} kW",
        f"Efficiency: {c_kpi.overall_efficiency_pct:.2f} %",
        f"Vibration: {current.vibration_amplitude_m*1e6:.1f} um",
        f"Feasible: {current.is_feasible}",
    ]
    ax_status.text(0, 1, "\n".join(status_lines), va="top", fontsize=10, family="monospace")

    # --- panel: optimal targets text block ---
    ax_opt = fig.add_subplot(gs[0, 1])
    ax_opt.axis("off")
    opt_lines = [
        "OPTIMISED TARGETS",
        f"RPM: {o_kpi.shaft_rpm:,.0f}",
        f"Mass flow: {optimised.operating_point.steam_mass_flow_kg_s:,.2f} kg/s",
        f"Inlet P/T: {optimised.operating_point.inlet_pressure_pa/1e6:.2f} MPa / {optimised.operating_point.inlet_temperature_k-273.15:.0f} C",
        f"Gear ratio: {optimised.operating_point.gear_ratio:.3f}",
        f"Condenser P: {optimised.operating_point.condenser_pressure_pa/1e3:.2f} kPa",
        f"Generator power: {optimised.net_electrical_power_w/1e3:,.0f} kW",
        f"Efficiency: {o_kpi.overall_efficiency_pct:.2f} %",
        f"Feasible: {optimised.is_feasible}",
    ]
    ax_opt.text(0, 1, "\n".join(opt_lines), va="top", fontsize=10, family="monospace", color="#1f5c1f")

    # --- panel: improvement summary ---
    ax_imp = fig.add_subplot(gs[0, 2])
    ax_imp.axis("off")
    power_gain_pct = (optimised.net_electrical_power_w - current.net_electrical_power_w) / max(current.net_electrical_power_w, 1.0) * 100
    eff_gain_pts = o_kpi.overall_efficiency_pct - c_kpi.overall_efficiency_pct
    imp_lines = [
        "IMPROVEMENT",
        f"Power gain: {power_gain_pct:+.2f} %",
        f"Efficiency gain: {eff_gain_pts:+.2f} pts",
        "",
        ("RECOMMENDATION ACTIONABLE" if optimised.is_feasible else "OPTIMISER RESULT INFEASIBLE\n(rejected per safety policy)"),
    ]
    ax_imp.text(0, 1, "\n".join(imp_lines), va="top", fontsize=11, family="monospace",
                color=("#1f5c1f" if optimised.is_feasible else "#a61c1c"))

    # --- panel: current vs optimised bar comparison ---
    # Power [kW], efficiency [%] and torque [kN.m] live on wildly different
    # scales (~1e4, ~1e1, ~1e2) - sharing one y-axis would make two of the
    # three bar pairs invisible, so each metric gets its own small axis
    # instead of a single misleading shared-scale chart.
    bar_specs = [
        ("Power [kW]", current.net_electrical_power_w / 1e3, optimised.net_electrical_power_w / 1e3),
        ("Efficiency [%]", c_kpi.overall_efficiency_pct, o_kpi.overall_efficiency_pct),
        ("Torque [kN.m]", current.shaft_torque_n_m / 1e3, optimised.shaft_torque_n_m / 1e3),
    ]
    gs_bar = gs[1, :2].subgridspec(1, 3, wspace=0.6)
    for i, (label, cur_v, opt_v) in enumerate(bar_specs):
        ax = fig.add_subplot(gs_bar[0, i])
        ax.bar([0], [cur_v], width=0.6, label="Current", color="#4c78a8")
        ax.bar([1], [opt_v], width=0.6, label="Optimised", color="#54a24b")
        ax.set_xticks([0, 1])
        ax.set_xticklabels(["Cur", "Opt"], fontsize=8)
        ax.set_title(label, fontsize=9)
        ax.grid(axis="y", alpha=0.3)
        if i == 0:
            ax.legend(fontsize=7, loc="lower right")
    fig.text(0.02, 0.635, "Current vs Optimised Operating Point", fontsize=11, fontweight="bold")

    # --- panel: loss breakdown pie ---
    ax_pie = fig.add_subplot(gs[1, 2])
    entries = [e for e in loss_breakdown(optimised)]
    labels = [e.component.split(" (")[0] for e in entries]
    values = [max(e.loss_w, 0.0) for e in entries]
    ax_pie.pie(values, labels=None, autopct=lambda p: f"{p:.0f}%" if p > 3 else "", startangle=90)
    ax_pie.set_title("Energy Destination (optimised)", fontsize=10)
    ax_pie.legend(labels, loc="upper center", bbox_to_anchor=(0.5, -0.05), fontsize=7, ncol=1)

    # --- panel: thermal/mechanical state ---
    ax_thermal = fig.add_subplot(gs[2, :])
    ax_thermal.axis("off")
    thermal_lines = (
        f"THERMAL STATE (optimised)   Exhaust quality: {optimised.exhaust_quality}   "
        f"Exhaust wetness limit respected: {optimised.is_feasible}\n"
        f"Nearest critical speed: {optimised.nearest_critical_speed_rpm:,.0f} rpm   "
        f"Margin: {optimised.critical_speed_margin_pct:.1f}%   "
        f"Shaft stress: {optimised.shaft_stress_pa/1e6:.1f} MPa\n"
        f"Constraint violations: {optimised.constraint_violations if optimised.constraint_violations else 'NONE'}"
    )
    ax_thermal.text(0, 1, thermal_lines, va="top", fontsize=10, family="monospace")

    fig.suptitle("TURBOFLUX Engineering Dashboard", fontsize=16, fontweight="bold")
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return out_path
