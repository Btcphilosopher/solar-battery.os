"""
visualisation/optimisation_plots.py
======================================
Optimisation landscape heatmap, Pareto frontier scatter, and a
sensitivity tornado chart.
"""
from __future__ import annotations

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def optimisation_landscape(df2d: pd.DataFrame, field_x: str, field_y: str, value_col: str, out_path: str) -> str:
    pivot = df2d.pivot(index=field_y, columns=field_x, values=value_col)
    fig, ax = plt.subplots(figsize=(7.5, 6))
    im = ax.pcolormesh(pivot.columns, pivot.index, pivot.values, shading="auto", cmap="viridis")
    fig.colorbar(im, ax=ax, label=value_col)
    ax.set_xlabel(field_x)
    ax.set_ylabel(field_y)
    ax.set_title(f"Optimisation Landscape: {value_col}")

    if pivot.values.size:
        max_idx = np.unravel_index(np.nanargmax(pivot.values), pivot.values.shape)
        ax.scatter(pivot.columns[max_idx[1]], pivot.index[max_idx[0]], color="red", marker="*", s=200, label="Best found")
        ax.legend()

    fig.tight_layout()
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return out_path


def pareto_frontier_plot(df: pd.DataFrame, x_col: str, y_col: str, out_path: str) -> str:
    fig, ax = plt.subplots(figsize=(7.5, 6))
    dominated = df[~df["is_pareto_optimal"]]
    frontier = df[df["is_pareto_optimal"]].sort_values(x_col)

    ax.scatter(dominated[x_col], dominated[y_col], color="lightgray", s=14, label="Dominated candidates")
    ax.plot(frontier[x_col], frontier[y_col], color="#d62728", marker="o", ms=5, lw=1.5, label="Pareto frontier")
    ax.set_xlabel(x_col)
    ax.set_ylabel(y_col)
    ax.set_title("Pareto Frontier")
    ax.legend()
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return out_path


def sensitivity_tornado(sensitivity_df: pd.DataFrame, out_path: str, value_col: str = "delta_power_pct") -> str:
    df = sensitivity_df.dropna(subset=[value_col]).copy()
    df = df.reindex(df[value_col].abs().sort_values().index)

    fig, ax = plt.subplots(figsize=(8, max(3, 0.5 * len(df))))
    colors = ["#d62728" if v < 0 else "#2ca02c" for v in df[value_col]]
    ax.barh(df["variable"], df[value_col], color=colors)
    ax.axvline(0, color="k", lw=1)
    ax.set_xlabel(f"{value_col} (%)")
    ax.set_title("Sensitivity Tornado Chart")
    ax.grid(axis="x", alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return out_path
