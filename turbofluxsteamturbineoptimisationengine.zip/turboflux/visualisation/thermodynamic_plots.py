"""
visualisation/thermodynamic_plots.py
=======================================
Rotor mass vs dynamic response, gear ratio vs generator output, condenser
pressure vs turbine power, steam temperature vs efficiency.
"""
from __future__ import annotations

import matplotlib.pyplot as plt
import pandas as pd


def rotor_mass_vs_dynamic_response(df: pd.DataFrame, out_path: str) -> str:
    """df columns: rotor_mass_kg, spin_up_time_s, rotational_kinetic_energy_j."""
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
    axes[0].plot(df["rotor_mass_kg"], df["spin_up_time_s"], color="#e45756", lw=2, marker="o", ms=3)
    axes[0].set_xlabel("Rotor mass [kg]")
    axes[0].set_ylabel("Spin-up time to target RPM [s]")
    axes[0].set_title("Rotor Mass vs Start-up Time")
    axes[0].grid(alpha=0.3)

    axes[1].plot(df["rotor_mass_kg"], df["rotational_kinetic_energy_j"] / 1e6, color="#4c78a8", lw=2, marker="o", ms=3)
    axes[1].set_xlabel("Rotor mass [kg]")
    axes[1].set_ylabel("Stored rotational KE [MJ]")
    axes[1].set_title("Rotor Mass vs Stored Kinetic Energy\n(NOT continuous output - see notes)")
    axes[1].grid(alpha=0.3)

    fig.tight_layout()
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return out_path


def gear_ratio_vs_generator_output(df: pd.DataFrame, out_path: str) -> str:
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.plot(df["gear_ratio"], df["net_electrical_power_w"] / 1e3, color="#72b7b2", lw=2, marker="o", ms=3)
    ax.set_xlabel("Gear ratio (turbine RPM / generator RPM)")
    ax.set_ylabel("Net electrical power [kW]")
    ax.set_title("Gear Ratio vs Net Electrical Output")
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return out_path


def condenser_pressure_vs_turbine_power(df: pd.DataFrame, out_path: str) -> str:
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.plot(df["condenser_pressure_pa"] / 1e3, df["net_electrical_power_w"] / 1e3, color="#f58518", lw=2, marker="o", ms=3)
    ax.set_xlabel("Condenser pressure [kPa]")
    ax.set_ylabel("Net electrical power [kW]")
    ax.set_title("Condenser Pressure vs Turbine/Net Power")
    ax.invert_xaxis()
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return out_path


def steam_temperature_vs_efficiency(df: pd.DataFrame, out_path: str) -> str:
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.plot(df["inlet_temperature_k"] - 273.15, df["overall_efficiency"] * 100, color="#b279a2", lw=2, marker="o", ms=3)
    ax.set_xlabel("Steam inlet temperature [C]")
    ax.set_ylabel("Overall efficiency [%]")
    ax.set_title("Steam Temperature vs Overall Efficiency")
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=140)
    plt.close(fig)
    return out_path
