"""
digital_twin/prediction.py
=============================
Turns the current (calibrated) twin state into a RECOMMENDED operating
point via the optimiser. This module NEVER writes to real machinery -
its only output is a PREDICTED/OPTIMISED recommendation object intended
for a human engineer to review and, at their discretion, apply manually
or through the plant's own (separately safety-interlocked) control
system. See section 20/27.
"""
from __future__ import annotations

from dataclasses import dataclass

from core.configuration import PlantConfig
from core.state import ComponentHealth, DataProvenance, OperatingPoint, SystemState, utcnow
from optimisation.objectives import ObjectiveMode
from optimisation.optimiser import optimise


@dataclass(frozen=True)
class Recommendation:
    generated_at: str
    mode: ObjectiveMode
    current_state: SystemState
    recommended_operating_point: OperatingPoint
    recommended_state: SystemState
    predicted_power_gain_w: float
    is_actionable: bool  # False if the recommendation itself is infeasible
    disclaimer: str = (
        "This is an engineering RECOMMENDATION only (DataProvenance.PREDICTED/OPTIMISED). "
        "TURBOFLUX does not and must not automatically control real machinery. "
        "A qualified engineer must review this recommendation, and the plant's own "
        "independent safety interlocks remain the final authority."
    )


def recommend_operating_point(
    config: PlantConfig,
    current_state: SystemState,
    current_health: ComponentHealth,
    mode: ObjectiveMode = ObjectiveMode.MAX_NET_ENERGY,
) -> Recommendation:
    opt_result = optimise(config, mode=mode, health=current_health)
    gain = opt_result.best_state.net_electrical_power_w - current_state.net_electrical_power_w

    return Recommendation(
        generated_at=utcnow().isoformat(),
        mode=mode,
        current_state=current_state,
        recommended_operating_point=opt_result.best_operating_point,
        recommended_state=opt_result.best_state,
        predicted_power_gain_w=gain,
        is_actionable=opt_result.best_state.is_feasible,
    )
