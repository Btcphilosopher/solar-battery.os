"""
Digital twin: MODEL -> SIMULATED SENSOR DATA -> STATE ESTIMATION ->
MODEL UPDATE -> OPTIMISER -> RECOMMENDED OPERATING POINT.

Never automatically controls real machinery - see prediction.py.
"""
