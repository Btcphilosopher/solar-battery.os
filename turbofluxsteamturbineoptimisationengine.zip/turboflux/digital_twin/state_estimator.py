"""
digital_twin/state_estimator.py
==================================
Simulated telemetry generator + a simple complementary-filter state
estimator. This is deliberately simple (no Kalman filter/EKF) because the
research build has no real sensor noise model to calibrate a covariance
matrix against - the honest thing to do is a transparent low-pass blend,
clearly labelled ESTIMATED, rather than a Kalman filter dressed up with
made-up covariances.

    SIMULATED SENSOR DATA = MODELLED value + noise      (this module)
    ESTIMATED STATE        = alpha * sensor + (1-alpha) * prior model prediction
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from core.state import DataProvenance, SystemState, Tagged, tag


@dataclass(frozen=True)
class SimulatedTelemetry:
    net_electrical_power_w: Tagged
    shaft_rpm: Tagged
    shaft_torque_n_m: Tagged
    vibration_amplitude_m: Tagged
    inlet_pressure_pa: Tagged
    inlet_temperature_k: Tagged


def simulate_sensor_noise(state: SystemState, rng: np.random.Generator, noise_std_frac: float = 0.01) -> SimulatedTelemetry:
    """Overlay Gaussian sensor noise on a MODELLED/SIMULATED SystemState to
    produce something that stands in for real plant instrumentation, tagged
    SIMULATED so nobody downstream mistakes it for a real sensor feed."""

    def noisy(value: float) -> float:
        return float(value * (1 + rng.normal(0, noise_std_frac)))

    return SimulatedTelemetry(
        net_electrical_power_w=tag(noisy(state.net_electrical_power_w), "W", DataProvenance.SIMULATED, "sim-telemetry"),
        shaft_rpm=tag(noisy(state.operating_point.shaft_rpm), "rpm", DataProvenance.SIMULATED, "sim-telemetry"),
        shaft_torque_n_m=tag(noisy(state.shaft_torque_n_m), "N.m", DataProvenance.SIMULATED, "sim-telemetry"),
        vibration_amplitude_m=tag(noisy(max(state.vibration_amplitude_m, 1e-9)), "m", DataProvenance.SIMULATED, "sim-telemetry"),
        inlet_pressure_pa=tag(noisy(state.operating_point.inlet_pressure_pa), "Pa", DataProvenance.SIMULATED, "sim-telemetry"),
        inlet_temperature_k=tag(noisy(state.operating_point.inlet_temperature_k), "K", DataProvenance.SIMULATED, "sim-telemetry"),
    )


def estimate_state(
    telemetry: SimulatedTelemetry, model_prediction: SystemState, alpha: float = 0.6
) -> dict:
    """Complementary-filter blend of noisy telemetry and the model's own
    prediction, producing ESTIMATED values. alpha weights trust in the
    (noisy) sensor vs the (smooth but potentially stale) model."""
    if not 0.0 <= alpha <= 1.0:
        raise ValueError("alpha must be in [0, 1]")

    def blend(sensor: Tagged, model_value: float, unit: str) -> Tagged:
        blended = alpha * float(sensor) + (1 - alpha) * model_value
        return tag(blended, unit, DataProvenance.ESTIMATED, "complementary-filter")

    return {
        "net_electrical_power_w": blend(telemetry.net_electrical_power_w, model_prediction.net_electrical_power_w, "W"),
        "shaft_rpm": blend(telemetry.shaft_rpm, model_prediction.operating_point.shaft_rpm, "rpm"),
        "shaft_torque_n_m": blend(telemetry.shaft_torque_n_m, model_prediction.shaft_torque_n_m, "N.m"),
        "vibration_amplitude_m": blend(telemetry.vibration_amplitude_m, model_prediction.vibration_amplitude_m, "m"),
    }
