"""
digital_twin/twin.py
======================
The DigitalTwin ties together: current plant configuration, current
ComponentHealth (degradation state - section 21), a rolling history of
SystemState snapshots, and the MODEL -> SIMULATED SENSOR DATA -> STATE
ESTIMATION -> MODEL UPDATE -> OPTIMISER -> RECOMMENDED OPERATING POINT
loop (section 20).

Degradation model (section 21): each call to `advance_degradation` nudges
ComponentHealth multipliers slightly worse, using simple monotone decay
curves. This is a deliberately simple, documented degradation
trajectory - not a physics-of-failure or reliability model - sufficient
to demonstrate how the optimiser's recommended operating point and
maintenance flag shift as the machine ages.
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace

import numpy as np

from core.configuration import PlantConfig
from core.engine import simulate
from core.state import ComponentHealth, DataProvenance, OperatingPoint, SystemState, utcnow
from .prediction import Recommendation, recommend_operating_point
from .state_estimator import estimate_state, simulate_sensor_noise


@dataclass
class DegradationRates:
    """Fractional health-factor decline per simulated "day" of operation."""

    turbine_efficiency_per_day: float = 0.00008   # blade fouling / erosion
    bearing_friction_growth_per_day: float = 0.0004
    gearbox_efficiency_per_day: float = 0.00003
    condenser_fouling_growth_per_day: float = 0.0006
    generator_efficiency_per_day: float = 0.00002


@dataclass
class DigitalTwin:
    config: PlantConfig
    health: ComponentHealth = field(default_factory=ComponentHealth)
    degradation_rates: DegradationRates = field(default_factory=DegradationRates)
    history: list = field(default_factory=list)
    rng_seed: int = 42

    def __post_init__(self):
        self._rng = np.random.default_rng(self.rng_seed)

    def update(self, operating_point: OperatingPoint) -> SystemState:
        """MODEL step: run the physics model at the current health state,
        overlay simulated sensor noise, blend into an ESTIMATED state, and
        record both in the twin's history."""
        modelled = simulate(self.config, operating_point, self.health, provenance=DataProvenance.MODELLED)
        telemetry = simulate_sensor_noise(modelled, self._rng)
        estimated = estimate_state(telemetry, modelled)

        modelled.notes.append(
            f"ESTIMATED (sensor-fused) net_electrical_power = {float(estimated['net_electrical_power_w']):.1f} W "
            f"vs MODELLED {modelled.net_electrical_power_w:.1f} W"
        )
        self.history.append(modelled)
        return modelled

    def advance_degradation(self, days: float) -> ComponentHealth:
        r = self.degradation_rates
        self.health = replace(
            self.health,
            turbine_efficiency_factor=max(0.5, self.health.turbine_efficiency_factor - r.turbine_efficiency_per_day * days),
            bearing_friction_factor=self.health.bearing_friction_factor + r.bearing_friction_growth_per_day * days,
            gearbox_efficiency_factor=max(0.5, self.health.gearbox_efficiency_factor - r.gearbox_efficiency_per_day * days),
            condenser_fouling_factor=self.health.condenser_fouling_factor + r.condenser_fouling_growth_per_day * days,
            generator_efficiency_factor=max(0.5, self.health.generator_efficiency_factor - r.generator_efficiency_per_day * days),
        )
        return self.health

    def maintenance_recommended(self, thresholds: dict | None = None) -> tuple[bool, list[str]]:
        thresholds = thresholds or {
            "turbine_efficiency_factor": 0.92,
            "bearing_friction_factor": 1.3,
            "gearbox_efficiency_factor": 0.95,
            "condenser_fouling_factor": 1.25,
            "generator_efficiency_factor": 0.95,
        }
        reasons = []
        if self.health.turbine_efficiency_factor < thresholds["turbine_efficiency_factor"]:
            reasons.append(f"Turbine efficiency factor degraded to {self.health.turbine_efficiency_factor:.3f}")
        if self.health.bearing_friction_factor > thresholds["bearing_friction_factor"]:
            reasons.append(f"Bearing friction factor elevated to {self.health.bearing_friction_factor:.3f}")
        if self.health.gearbox_efficiency_factor < thresholds["gearbox_efficiency_factor"]:
            reasons.append(f"Gearbox efficiency factor degraded to {self.health.gearbox_efficiency_factor:.3f}")
        if self.health.condenser_fouling_factor > thresholds["condenser_fouling_factor"]:
            reasons.append(f"Condenser fouling factor elevated to {self.health.condenser_fouling_factor:.3f}")
        if self.health.generator_efficiency_factor < thresholds["generator_efficiency_factor"]:
            reasons.append(f"Generator efficiency factor degraded to {self.health.generator_efficiency_factor:.3f}")
        return (len(reasons) > 0, reasons)

    def recommend(self, mode=None) -> Recommendation:
        from optimisation.objectives import ObjectiveMode

        mode = mode or ObjectiveMode.MAX_NET_ENERGY
        current = self.history[-1] if self.history else simulate(
            self.config,
            OperatingPoint(
                inlet_pressure_pa=self.config.steam_supply.rated_pressure_pa,
                inlet_temperature_k=self.config.steam_supply.rated_temperature_k,
                steam_mass_flow_kg_s=self.config.steam_supply.max_mass_flow_kg_s * 0.8,
                condenser_pressure_pa=self.config.condenser.design_pressure_pa,
                shaft_rpm=self.config.generator.rated_rpm,
                gear_ratio=self.config.gearbox.rated_ratio,
                cooling_water_flow_kg_s=self.config.condenser.max_cooling_water_flow_kg_s * 0.7,
                cooling_water_inlet_temp_k=self.config.condenser.cooling_water_inlet_temp_k,
            ),
            self.health,
        )
        return recommend_operating_point(self.config, current, self.health, mode)
