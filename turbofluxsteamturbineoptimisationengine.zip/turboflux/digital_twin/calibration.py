"""
digital_twin/calibration.py
==============================
Calibrate MODELLED parameters (currently: turbine efficiency health
factor) against ESTIMATED/MEASURED observations using a least-squares fit
(scipy.optimize.least_squares). This is how a digital twin's model is
kept honest against reality over time - a bounded, explicit, auditable
fit, not a black-box learned correction.
"""
from __future__ import annotations

from dataclasses import dataclass, replace

from scipy.optimize import least_squares

from core.configuration import PlantConfig
from core.engine import simulate
from core.state import ComponentHealth, DataProvenance, OperatingPoint


@dataclass(frozen=True)
class CalibrationResult:
    fitted_turbine_efficiency_factor: float
    residual_w: float
    converged: bool
    notes: list


def calibrate_turbine_efficiency(
    config: PlantConfig,
    operating_point: OperatingPoint,
    observed_net_electrical_power_w: float,
    initial_guess: float = 1.0,
) -> CalibrationResult:
    """Fit health.turbine_efficiency_factor so the model's predicted
    net_electrical_power_w matches an observed (ESTIMATED/MEASURED) value.
    Bounded to [0.5, 1.05] - calibration should never be allowed to imply
    a turbine performing at implausible or super-unity efficiency; a
    residual that cannot be closed within bounds is reported, not hidden."""

    def residual(x):
        factor = float(x[0])
        health = ComponentHealth(turbine_efficiency_factor=factor)
        state = simulate(config, operating_point, health, provenance=DataProvenance.SIMULATED)
        return [state.net_electrical_power_w - observed_net_electrical_power_w]

    result = least_squares(residual, x0=[initial_guess], bounds=([0.5], [1.05]), xtol=1e-8)
    notes = []
    if not result.success:
        notes.append(f"Calibration least-squares fit did not converge cleanly: {result.message}")
    fitted = float(result.x[0])
    if abs(fitted - 0.5) < 1e-3 or abs(fitted - 1.05) < 1e-3:
        notes.append(
            "Fitted turbine_efficiency_factor sits at a calibration bound - the model "
            "structure likely cannot explain the observed power at this operating point; "
            "investigate other degraded components before trusting this fit."
        )
    return CalibrationResult(
        fitted_turbine_efficiency_factor=fitted,
        residual_w=float(result.fun[0]),
        converged=bool(result.success),
        notes=notes,
    )
