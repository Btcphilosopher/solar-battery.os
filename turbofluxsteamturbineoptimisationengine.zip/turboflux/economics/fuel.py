"""economics/fuel.py - fuel cost behind the boiler heat input."""
from __future__ import annotations

from core.configuration import EconomicConfig, SteamSupplyConfig


def boiler_fuel_energy_input_w(boiler_heat_input_w: float, steam_supply: SteamSupplyConfig) -> float:
    """Fuel chemical energy input rate required to deliver the given
    boiler heat input, accounting for boiler thermal efficiency."""
    return boiler_heat_input_w / steam_supply.boiler_thermal_efficiency


def fuel_cost_per_s(boiler_heat_input_w: float, steam_supply: SteamSupplyConfig, economics: EconomicConfig) -> float:
    fuel_w = boiler_fuel_energy_input_w(boiler_heat_input_w, steam_supply)
    return fuel_w * economics.fuel_cost_per_j


def fuel_mass_flow_kg_s(boiler_heat_input_w: float, steam_supply: SteamSupplyConfig) -> float:
    fuel_w = boiler_fuel_energy_input_w(boiler_heat_input_w, steam_supply)
    return fuel_w / steam_supply.fuel_lhv_j_kg
