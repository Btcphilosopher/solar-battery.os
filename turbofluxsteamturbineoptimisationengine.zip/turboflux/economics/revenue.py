"""economics/revenue.py - electricity revenue and net operating margin."""
from __future__ import annotations

from core.configuration import EconomicConfig, SteamSupplyConfig
from core.state import SystemState
from .operating_cost import compute_operating_cost


def revenue_per_s(state: SystemState, economics: EconomicConfig) -> float:
    return state.net_electrical_power_w * economics.electricity_price_per_wh / 3600.0


def net_operating_margin_per_s(state: SystemState, economics: EconomicConfig, steam_supply: SteamSupplyConfig) -> float:
    """Revenue minus fuel + maintenance + fixed O&M, for the plant's
    *actual* configured steam supply - the caller must pass it explicitly
    so a mismatched fuel/efficiency assumption can never silently sneak in."""
    cost = compute_operating_cost(state, steam_supply, economics)
    return revenue_per_s(state, economics) - cost.total_cost_per_s
