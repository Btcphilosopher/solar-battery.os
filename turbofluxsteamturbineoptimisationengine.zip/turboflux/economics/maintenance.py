"""
economics/maintenance.py
==========================
Wear-driven maintenance cost accrual. Modelled as scaling with RPM (higher
speed -> more bearing/blade wear and fatigue cycling) so the economic
optimiser can discover that a slightly lower RPM operating point may cost
less in accrued maintenance even though it produces marginally less gross
power (section 22's central example).
"""
from __future__ import annotations

from core.configuration import EconomicConfig


def maintenance_cost_per_s(rpm: float, economics: EconomicConfig) -> float:
    per_hour = economics.variable_maintenance_cost_per_rpm_hour * rpm
    return per_hour / 3600.0


def fixed_om_cost_per_s(economics: EconomicConfig) -> float:
    return economics.fixed_om_cost_per_s
