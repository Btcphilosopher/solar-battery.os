"""Fuel, operating cost, maintenance and revenue - economic optimisation."""
