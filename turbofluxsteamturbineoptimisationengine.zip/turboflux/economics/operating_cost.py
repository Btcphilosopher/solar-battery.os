"""economics/operating_cost.py - aggregate OPEX per second."""
from __future__ import annotations

from dataclasses import dataclass

from core.configuration import EconomicConfig, SteamSupplyConfig
from core.state import SystemState
from .fuel import fuel_cost_per_s
from .maintenance import fixed_om_cost_per_s, maintenance_cost_per_s


@dataclass(frozen=True)
class OperatingCostBreakdown:
    fuel_cost_per_s: float
    maintenance_cost_per_s: float
    fixed_om_cost_per_s: float
    total_cost_per_s: float


def compute_operating_cost(state: SystemState, steam_supply: SteamSupplyConfig, economics: EconomicConfig) -> OperatingCostBreakdown:
    boiler_heat_w = state.net_electrical_power_w / max(state.overall_efficiency, 1e-9)
    fuel = fuel_cost_per_s(boiler_heat_w, steam_supply, economics)
    maint = maintenance_cost_per_s(state.operating_point.shaft_rpm, economics)
    fixed = fixed_om_cost_per_s(economics)
    return OperatingCostBreakdown(
        fuel_cost_per_s=fuel,
        maintenance_cost_per_s=maint,
        fixed_om_cost_per_s=fixed,
        total_cost_per_s=fuel + maint + fixed,
    )
