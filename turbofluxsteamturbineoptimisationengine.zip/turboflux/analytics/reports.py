"""
analytics/reports.py
======================
Baseline vs optimised summary report (section 25), and a full energy
balance report (section 15). Text output only here; visualisation/dashboard.py
handles the graphical dashboard.
"""
from __future__ import annotations

from core.state import SystemState
from .bottlenecks import largest_bottleneck, loss_breakdown, stage_bottleneck
from .performance import compute_kpis


def energy_balance_report(state: SystemState) -> str:
    lines = [
        "=" * 70,
        "ENERGY BALANCE REPORT",
        "=" * 70,
        f"Provenance: {state.provenance.value}",
        f"Ideal turbine power (isentropic):   {state.ideal_turbine_power_w/1e3:12,.1f} kW",
        f"Actual turbine power (delivered):   {state.actual_turbine_power_w/1e3:12,.1f} kW",
        f"Mechanical loss (bearing+windage):  {state.mechanical_loss_w/1e3:12,.1f} kW",
        f"Net shaft power:                    {state.net_shaft_power_w/1e3:12,.1f} kW",
        f"Gearbox loss:                       {state.gearbox_loss_w/1e3:12,.1f} kW",
        f"Generator input power:              {state.generator_input_power_w/1e3:12,.1f} kW",
        f"Generator loss:                     {state.generator_loss_w/1e3:12,.1f} kW",
        f"NET ELECTRICAL POWER:               {state.net_electrical_power_w/1e3:12,.1f} kW",
        f"Condenser heat rejected:            {state.condenser_heat_rejected_w/1e3:12,.1f} kW",
        f"Energy balance residual:            {state.energy_balance_residual_w:12,.3f} W",
        "-" * 70,
        "Loss breakdown (share of gross energy input):",
    ]
    for entry in loss_breakdown(state):
        lines.append(f"  {entry.component:<65} {entry.share_pct:6.2f}%")
    if state.notes:
        lines.append("-" * 70)
        lines.append("Notes:")
        for n in state.notes:
            lines.append(f"  - {n}")
    return "\n".join(lines)


def baseline_vs_optimised_report(baseline: SystemState, optimised: SystemState) -> str:
    b_kpi = compute_kpis(baseline)
    o_kpi = compute_kpis(optimised)

    def pct_change(base, new):
        return (new - base) / abs(base) * 100.0 if base else float("nan")

    lines = [
        "=" * 70,
        "TURBOFLUX BASELINE vs OPTIMISED REPORT",
        "=" * 70,
        f"{'Metric':<38}{'Baseline':>14}{'Optimised':>14}{'Change':>10}",
        "-" * 70,
        _row("Net electrical power [kW]", b_kpi.net_electrical_power_kw, o_kpi.net_electrical_power_kw),
        _row("Overall efficiency [%]", b_kpi.overall_efficiency_pct, o_kpi.overall_efficiency_pct),
        _row("Cycle thermal efficiency [%]", b_kpi.cycle_thermal_efficiency_pct, o_kpi.cycle_thermal_efficiency_pct),
        _row("Turbine isentropic efficiency [%]", b_kpi.turbine_isentropic_efficiency_pct, o_kpi.turbine_isentropic_efficiency_pct),
        _row("Generator efficiency [%]", b_kpi.generator_efficiency_pct, o_kpi.generator_efficiency_pct),
        _row("Shaft RPM", b_kpi.shaft_rpm, o_kpi.shaft_rpm),
        _row("Generator RPM", b_kpi.generator_rpm, o_kpi.generator_rpm),
        _row("Shaft torque [N.m]", b_kpi.shaft_torque_n_m, o_kpi.shaft_torque_n_m),
        _row("Specific steam consumption [kg/kWh]", b_kpi.specific_steam_consumption_kg_per_kwh, o_kpi.specific_steam_consumption_kg_per_kwh),
        _row("Heat rate [kJ/kWh]", b_kpi.heat_rate_kj_per_kwh, o_kpi.heat_rate_kj_per_kwh),
        "-" * 70,
        f"Baseline feasible: {b_kpi.feasible}   Optimised feasible: {o_kpi.feasible}",
        "",
        "ENGINEERING INTERPRETATION:",
    ]
    lines.extend(_explain_change(baseline, optimised))
    bottleneck = largest_bottleneck(optimised)
    lines.append(f"  - Largest remaining loss at the optimised point: {bottleneck.component} ({bottleneck.share_pct:.1f}% of gross input)")
    sb = stage_bottleneck(optimised)
    if sb:
        lines.append(f"  - {sb['interpretation']}")
    return "\n".join(lines)


def _row(label: str, base: float, new: float) -> str:
    change = new - base
    pct = (change / abs(base) * 100.0) if base else float("nan")
    return f"{label:<38}{base:>14,.2f}{new:>14,.2f}{pct:>9.1f}%"


def _explain_change(baseline: SystemState, optimised: SystemState) -> list[str]:
    reasons = []
    d_rpm = optimised.operating_point.shaft_rpm - baseline.operating_point.shaft_rpm
    d_p = optimised.operating_point.inlet_pressure_pa - baseline.operating_point.inlet_pressure_pa
    d_t = optimised.operating_point.inlet_temperature_k - baseline.operating_point.inlet_temperature_k
    d_mdot = optimised.operating_point.steam_mass_flow_kg_s - baseline.operating_point.steam_mass_flow_kg_s
    d_cond = optimised.operating_point.condenser_pressure_pa - baseline.operating_point.condenser_pressure_pa

    if abs(d_rpm) > 1e-6:
        direction = "increased" if d_rpm > 0 else "decreased"
        reasons.append(f"  - Shaft RPM {direction} by {abs(d_rpm):.0f} rpm, moving stage blade-speed ratios closer to their optimum.")
    if abs(d_p) > 1e3:
        direction = "raised" if d_p > 0 else "lowered"
        reasons.append(f"  - Inlet pressure {direction} by {abs(d_p)/1e3:.0f} kPa, changing the available isentropic enthalpy drop.")
    if abs(d_t) > 0.5:
        direction = "raised" if d_t > 0 else "lowered"
        reasons.append(f"  - Inlet temperature {direction} by {abs(d_t):.1f} K.")
    if abs(d_mdot) > 1e-3:
        direction = "increased" if d_mdot > 0 else "decreased"
        reasons.append(f"  - Steam mass flow {direction} by {abs(d_mdot):.2f} kg/s.")
    if abs(d_cond) > 100:
        direction = "raised" if d_cond > 0 else "lowered"
        reasons.append(f"  - Condenser pressure {direction} by {abs(d_cond):.0f} Pa, trading exhaust wetness against expansion ratio.")
    if not reasons:
        reasons.append("  - Optimiser converged near the baseline operating point; limited additional headroom found under the current constraints.")
    return reasons
