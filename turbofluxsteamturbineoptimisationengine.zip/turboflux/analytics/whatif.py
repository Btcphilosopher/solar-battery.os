"""
analytics/whatif.py
======================
The "what-if" engineering question engine (section 19). Each scenario is
a (description, modify_fn) pair; modify_fn takes the baseline
(config, operating_point, health) and returns a modified triple. The
engine re-simulates and reports BASELINE / NEW CONDITION / CHANGE / NET
EFFECT / ENGINEERING INTERPRETATION for each.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Callable

from core.configuration import PlantConfig
from core.engine import simulate
from core.state import ComponentHealth, OperatingPoint, SystemState
from thermal.temperature import (
    qualitative_effect_of_higher_inlet_pressure,
    qualitative_effect_of_lower_condenser_pressure,
)

ModifyFn = Callable[[PlantConfig, OperatingPoint, ComponentHealth], tuple[PlantConfig, OperatingPoint, ComponentHealth]]


@dataclass(frozen=True)
class WhatIfResult:
    question: str
    baseline_power_w: float
    new_power_w: float
    baseline_efficiency: float
    new_efficiency: float
    change_power_pct: float
    new_state_feasible: bool
    interpretation: str


def run_what_if(
    config: PlantConfig,
    base_point: OperatingPoint,
    base_health: ComponentHealth,
    question: str,
    modify_fn: ModifyFn,
    interpretation: str,
) -> WhatIfResult:
    baseline_state = simulate(config, base_point, base_health)
    new_config, new_point, new_health = modify_fn(config, base_point, base_health)
    new_state = simulate(new_config, new_point, new_health)

    change_pct = (
        (new_state.net_electrical_power_w - baseline_state.net_electrical_power_w)
        / abs(baseline_state.net_electrical_power_w) * 100.0
        if baseline_state.net_electrical_power_w else float("nan")
    )

    return WhatIfResult(
        question=question,
        baseline_power_w=baseline_state.net_electrical_power_w,
        new_power_w=new_state.net_electrical_power_w,
        baseline_efficiency=baseline_state.overall_efficiency,
        new_efficiency=new_state.overall_efficiency,
        change_power_pct=change_pct,
        new_state_feasible=new_state.is_feasible,
        interpretation=interpretation if new_state.is_feasible else (
            interpretation + " NOTE: the new condition VIOLATES configured safety limits "
            f"({new_state.constraint_violations}) and would be REJECTED by the optimiser."
        ),
    )


def _rpm_plus_10pct(config, point, health):
    return config, replace(point, shaft_rpm=point.shaft_rpm * 1.10), health


def _rotor_20pct_heavier(config, point, health):
    new_config = config.model_copy(deep=True)
    new_config.turbine.rotor_mass_kg *= 1.20
    return new_config, point, health


def _gear_ratio_changed(config, point, health):
    new_ratio = min(point.gear_ratio * 1.25, config.limits.max_gear_ratio)
    return config, replace(point, gear_ratio=new_ratio), health


def _steam_pressure_increase(config, point, health):
    new_p = min(point.inlet_pressure_pa * 1.08, config.limits.max_inlet_pressure_pa)
    return config, replace(point, inlet_pressure_pa=new_p), health


def _condenser_pressure_decrease(config, point, health):
    # The ACHIEVED condenser pressure is solved from the cooling-water heat
    # balance (thermal/condenser.py), not set directly - see
    # core/engine.py::achieved_condenser_pressure_pa. So "decrease condenser
    # pressure" is modelled honestly as improving the cooling system (more
    # flow, colder source water) rather than by editing the advisory target
    # field, which the solver would mostly override anyway.
    new_flow = min(point.cooling_water_flow_kg_s * 1.4, config.condenser.max_cooling_water_flow_kg_s)
    new_temp = max(point.cooling_water_inlet_temp_k - 4.0, 275.15)
    new_point = replace(point, cooling_water_flow_kg_s=new_flow, cooling_water_inlet_temp_k=new_temp)
    return config, new_point, health


def _add_turbine_stage(config, point, health):
    from core.configuration import StageConfig

    new_config = config.model_copy(deep=True)
    # Insert an extra LP-section stage (splitting the LP expansion finer,
    # a common way to reduce per-stage enthalpy drop / exhaust wetness).
    new_config.turbine.stages.append(
        StageConfig(name="LP-4", isentropic_efficiency=0.82, nozzle_efficiency=0.95, reaction=0.5)
    )
    return new_config, point, health


def _generator_efficiency_improves(config, point, health):
    new_health = replace(health, generator_efficiency_factor=health.generator_efficiency_factor * 1.05)
    return config, point, new_health


STANDARD_SCENARIOS: list[tuple[str, ModifyFn, str]] = [
    (
        "What happens if turbine RPM increases 10%?",
        _rpm_plus_10pct,
        "Blade-speed ratio moves further from each stage's optimum (or closer, "
        "depending on the starting point) - the effect on power is NOT guaranteed "
        "positive; see the RPM sweep and optimiser result for this configuration's "
        "actual optimum.",
    ),
    (
        "What happens if the rotor is 20% heavier?",
        _rotor_20pct_heavier,
        "A heavier rotor stores more rotational kinetic energy and resists speed "
        "changes more strongly (longer start-up time, slower response to load "
        "changes), and shifts the lateral critical speed lower (k unchanged, mass "
        "up -> omega_n = sqrt(k/m) down). It does NOT add continuous electrical "
        "output - steady-state power is set entirely by the steam-side energy "
        "balance, not by rotor mass.",
    ),
    (
        "What happens if the gearbox ratio changes?",
        _gear_ratio_changed,
        "Generator RPM changes inversely with gear ratio; gearbox efficiency "
        "degrades away from its design ratio (see mechanical/gearbox.py), trading "
        "off against how well the resulting generator RPM tracks synchronous speed.",
    ),
    (
        "What happens if steam pressure increases?",
        _steam_pressure_increase,
        qualitative_effect_of_higher_inlet_pressure(),
    ),
    (
        "What happens if condenser pressure decreases?",
        _condenser_pressure_decrease,
        qualitative_effect_of_lower_condenser_pressure()
        + " Modelled here via more/colder cooling water (+40% flow, -4 K inlet "
        "temperature) rather than by editing the condenser pressure directly - "
        "the ACHIEVED condenser pressure is solved from the cooling-water heat "
        "balance, not set as a free input (see achieved_condenser_pressure_pa).",
    ),
    (
        "What happens if another turbine stage is added?",
        _add_turbine_stage,
        "Finer pressure staging reduces the enthalpy drop (and exhaust wetness) "
        "taken in the last stage, generally improving stage efficiency and easing "
        "the erosion constraint, at the cost of added mechanical complexity/length "
        "not modelled here (rotor length/inertia held fixed in this comparison).",
    ),
    (
        "What happens if generator efficiency improves?",
        _generator_efficiency_improves,
        "A direct, nearly one-for-one improvement in net electrical output for the "
        "same mechanical input - generator efficiency sits at the very end of the "
        "chain with no compounding thermodynamic side effects upstream.",
    ),
]


def run_all_what_ifs(config: PlantConfig, base_point: OperatingPoint, base_health: ComponentHealth | None = None) -> list[WhatIfResult]:
    base_health = base_health or ComponentHealth()
    return [
        run_what_if(config, base_point, base_health, question, modify_fn, interpretation)
        for question, modify_fn, interpretation in STANDARD_SCENARIOS
    ]
