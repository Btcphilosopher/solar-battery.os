"""analytics/performance.py - headline KPIs for a SystemState."""
from __future__ import annotations

from dataclasses import dataclass

from core.state import SystemState
from optimisation.objectives import specific_steam_consumption_kg_per_kwh


@dataclass(frozen=True)
class PerformanceKPIs:
    net_electrical_power_kw: float
    overall_efficiency_pct: float
    cycle_thermal_efficiency_pct: float
    turbine_isentropic_efficiency_pct: float
    generator_efficiency_pct: float
    specific_steam_consumption_kg_per_kwh: float
    heat_rate_kj_per_kwh: float
    shaft_rpm: float
    generator_rpm: float
    shaft_torque_n_m: float
    exhaust_quality: float | None
    feasible: bool


def compute_kpis(state: SystemState) -> PerformanceKPIs:
    ssc = specific_steam_consumption_kg_per_kwh(state)
    heat_rate = (3600.0 / state.overall_efficiency) if state.overall_efficiency > 0 else float("inf")  # kJ/kWh via 3600 kJ/kWh basis
    return PerformanceKPIs(
        net_electrical_power_kw=state.net_electrical_power_w / 1e3,
        overall_efficiency_pct=state.overall_efficiency * 100,
        cycle_thermal_efficiency_pct=state.cycle_thermal_efficiency * 100,
        turbine_isentropic_efficiency_pct=state.turbine_isentropic_efficiency * 100,
        generator_efficiency_pct=state.generator_efficiency * 100,
        specific_steam_consumption_kg_per_kwh=ssc,
        heat_rate_kj_per_kwh=heat_rate,
        shaft_rpm=state.operating_point.shaft_rpm,
        generator_rpm=state.generator_rpm,
        shaft_torque_n_m=state.shaft_torque_n_m,
        exhaust_quality=state.exhaust_quality,
        feasible=state.is_feasible,
    )
