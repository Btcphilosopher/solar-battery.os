"""
analytics/bottlenecks.py
===========================
Identify which component in the STEAM -> ... -> ELECTRICAL chain is
consuming the largest share of losses, using the same energy-balance
terms tracked in core/engine.py.
"""
from __future__ import annotations

from dataclasses import dataclass

from core.state import SystemState


@dataclass(frozen=True)
class LossBreakdownEntry:
    component: str
    loss_w: float
    share_pct: float


def loss_breakdown(state: SystemState) -> list[LossBreakdownEntry]:
    # engine.py folds bearing + windage/leakage into mechanical_loss_w together;
    # for a readable breakdown we report the aggregates that ARE separable
    # from SystemState directly, and label the rest clearly.
    breakdown = {
        "Turbine internal losses (windage, leakage, blade/nozzle inefficiency)": state.mechanical_loss_w,
        "Turbine health/degradation loss": state.turbine_health_degradation_loss_w,
        "Gearbox losses": state.gearbox_loss_w,
        "Generator losses": state.generator_loss_w,
        "Condenser heat rejection (thermodynamic, not recoverable at this pressure)": state.condenser_heat_rejected_w,
    }
    total = sum(breakdown.values()) + state.net_electrical_power_w
    entries = [
        LossBreakdownEntry(component=name, loss_w=value, share_pct=(value / total * 100 if total > 0 else 0.0))
        for name, value in breakdown.items()
    ]
    entries.append(LossBreakdownEntry(
        component="Net electrical output (delivered, not a loss)",
        loss_w=state.net_electrical_power_w,
        share_pct=(state.net_electrical_power_w / total * 100 if total > 0 else 0.0),
    ))
    return sorted(entries, key=lambda e: e.loss_w, reverse=True)


def largest_bottleneck(state: SystemState) -> LossBreakdownEntry:
    entries = [e for e in loss_breakdown(state) if "Net electrical" not in e.component]
    return max(entries, key=lambda e: e.loss_w)


def stage_bottleneck(state: SystemState) -> dict | None:
    """Which turbine stage utilises its blade speed ratio worst (furthest
    from optimum) - a design-level bottleneck indicator distinct from the
    whole-chain loss breakdown above."""
    if not state.stage_results:
        return None
    worst = min(state.stage_results, key=lambda s: s.stage_utilisation_factor)
    return {
        "stage": worst.name,
        "stage_utilisation_factor": worst.stage_utilisation_factor,
        "velocity_ratio": worst.velocity_ratio,
        "optimal_velocity_ratio": worst.optimal_velocity_ratio,
        "interpretation": (
            f"Stage '{worst.name}' is running at blade-speed ratio {worst.velocity_ratio:.3f} "
            f"vs an optimum of {worst.optimal_velocity_ratio:.3f} - only "
            f"{worst.stage_utilisation_factor*100:.1f}% of its attainable efficiency is realised "
            f"at the current RPM."
        ),
    }
