"""
generator/generator.py
========================
Mechanical shaft power -> electrical output conversion (section 10).
"""
from __future__ import annotations

from dataclasses import dataclass

from core.configuration import GeneratorConfig
from .efficiency import generator_efficiency, generator_losses_w


@dataclass(frozen=True)
class GeneratorResult:
    mechanical_input_w: float
    electrical_output_w: float
    loss_w: float
    efficiency: float
    load_fraction: float
    over_rated: bool


def run_generator(config: GeneratorConfig, mechanical_power_w: float, health_factor: float = 1.0) -> GeneratorResult:
    eta = generator_efficiency(config, mechanical_power_w, health_factor)
    electrical = mechanical_power_w * eta
    loss = mechanical_power_w - electrical
    load_fraction = mechanical_power_w / config.rated_electrical_power_w if config.rated_electrical_power_w > 0 else 0.0
    return GeneratorResult(
        mechanical_input_w=mechanical_power_w,
        electrical_output_w=electrical,
        loss_w=loss,
        efficiency=eta,
        load_fraction=load_fraction,
        over_rated=load_fraction > 1.0,
    )


def match_generator_to_turbine(config: GeneratorConfig, turbine_mechanical_power_w: float) -> dict:
    """Simple turbine-generator matching diagnostic: how close is the
    delivered mechanical power to the generator's best-efficiency band
    (~70-90% load is typical for synchronous generators)."""
    load_fraction = turbine_mechanical_power_w / config.rated_electrical_power_w
    if load_fraction < 0.4:
        verdict = "Generator significantly under-loaded - efficiency penalised by fixed no-load losses."
    elif load_fraction > 1.0:
        verdict = "Generator overloaded relative to nameplate rating - thermal/current limits at risk."
    elif 0.7 <= load_fraction <= 0.95:
        verdict = "Generator operating near its best-efficiency band."
    else:
        verdict = "Generator loaded but away from best-efficiency band."
    return {"load_fraction": load_fraction, "verdict": verdict}
