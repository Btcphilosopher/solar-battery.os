"""
generator/electrical.py
=========================
Real/apparent power and grid synchronisation relationships.
"""
from __future__ import annotations

import math

from core.configuration import GeneratorConfig


def apparent_power_va(real_power_w: float, power_factor: float) -> float:
    if not 0 < power_factor <= 1.0:
        raise ValueError("power_factor must be in (0, 1]")
    return real_power_w / power_factor


def reactive_power_var(real_power_w: float, power_factor: float) -> float:
    s = apparent_power_va(real_power_w, power_factor)
    p = real_power_w
    q = math.sqrt(max(s ** 2 - p ** 2, 0.0))
    return q


def synchronous_speed_rpm(config: GeneratorConfig) -> float:
    return config.synchronous_rpm


def speed_deviation_from_sync_pct(config: GeneratorConfig, generator_rpm: float) -> float:
    sync = synchronous_speed_rpm(config)
    return (generator_rpm - sync) / sync * 100.0
