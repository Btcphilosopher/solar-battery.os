"""
generator/grid.py
===================
Grid-connection constraints: a synchronous generator directly coupled to
the grid must run at (very close to) synchronous speed = 120*f/poles.
Any gearbox/turbine-RPM optimisation feeding a synchronous machine is
therefore constrained to hit that generator RPM exactly (within a very
small tolerance) - this module makes that constraint explicit and
checkable rather than left implicit.
"""
from __future__ import annotations

from dataclasses import dataclass

from core.configuration import GeneratorConfig

DEFAULT_SYNC_TOLERANCE_PCT = 0.5  # +/-0.5% is already generous for a directly-coupled sync machine


@dataclass(frozen=True)
class GridComplianceResult:
    synchronous_rpm: float
    actual_generator_rpm: float
    deviation_pct: float
    grid_compliant: bool
    notes: list


def check_grid_compliance(config: GeneratorConfig, generator_rpm: float, tolerance_pct: float = DEFAULT_SYNC_TOLERANCE_PCT) -> GridComplianceResult:
    sync_rpm = config.synchronous_rpm
    deviation = abs(generator_rpm - sync_rpm) / sync_rpm * 100.0
    compliant = deviation <= tolerance_pct
    notes = []
    if not compliant:
        notes.append(
            f"Generator RPM {generator_rpm:.1f} deviates {deviation:.2f}% from the "
            f"synchronous speed {sync_rpm:.1f} rpm required for direct grid coupling "
            f"at {config.grid_frequency_hz:.0f} Hz with {config.poles} poles. Either "
            f"adjust the gear ratio / turbine RPM, or model a variable-frequency "
            f"converter interface (not modelled in this reference build)."
        )
    return GridComplianceResult(
        synchronous_rpm=sync_rpm,
        actual_generator_rpm=generator_rpm,
        deviation_pct=deviation,
        grid_compliant=compliant,
        notes=notes,
    )
