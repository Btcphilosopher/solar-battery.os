"""
generator/efficiency.py
=========================
Simplified two-loss-term generator efficiency curve:

    P_loss = P_no_load + P_copper(load_fraction)
    P_no_load     = no_load_loss_fraction * P_rated              (~constant, core/iron loss)
    P_copper      = full_load_copper_loss_fraction * P_rated * load_fraction^2   (I^2R loss)

This reproduces the well-known real-generator behaviour that efficiency is
poor at very low load (fixed losses dominate), rises to a peak at
moderate-to-high load, and falls off again near/above rated load as
resistive losses grow with the square of current - so "run the generator
at 100% load" is not automatically the most efficient point either.
"""
from __future__ import annotations

from core.configuration import GeneratorConfig


def generator_losses_w(config: GeneratorConfig, load_fraction: float) -> tuple[float, float]:
    """Returns (no_load_loss_w, copper_loss_w)."""
    p_rated = config.rated_electrical_power_w
    no_load = config.no_load_loss_fraction * p_rated
    copper = config.full_load_copper_loss_fraction * p_rated * load_fraction ** 2
    return no_load, copper


def generator_efficiency(config: GeneratorConfig, mechanical_input_w: float, health_factor: float = 1.0) -> float:
    if mechanical_input_w <= 0:
        return 0.0
    load_fraction = min(mechanical_input_w / config.rated_electrical_power_w, 2.0)
    no_load, copper = generator_losses_w(config, load_fraction)
    total_loss = (no_load + copper) / max(health_factor, 1e-6)
    electrical_out = max(0.0, mechanical_input_w - total_loss)
    return electrical_out / mechanical_input_w if mechanical_input_w > 0 else 0.0
