"""Generator conversion, electrical output, and grid interface."""
