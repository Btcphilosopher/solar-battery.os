import pytest

from thermal.condenser import solve_condenser
from thermal.cooling import cooling_water_outlet_temp_k, required_cooling_flow_kg_s
from thermal.heat_transfer import lmtd_k
from thermodynamics.steam import state_pt


def test_lmtd_matches_manual_formula():
    import math

    t_hot_in, t_hot_out, t_cold_in, t_cold_out = 400.0, 400.0, 300.0, 320.0
    dt1 = t_hot_in - t_cold_out   # 80
    dt2 = t_hot_out - t_cold_in   # 100
    expected = (dt1 - dt2) / math.log(dt1 / dt2)
    assert lmtd_k(t_hot_in, t_hot_out, t_cold_in, t_cold_out) == pytest.approx(expected)


def test_lmtd_degenerates_when_both_approach_temps_equal():
    # dt1 == dt2 (here: no cold-side temperature rise) -> LMTD == that constant approach
    lmtd = lmtd_k(400.0, 400.0, 320.0, 320.0)
    assert lmtd == pytest.approx(80.0)


def test_required_cooling_flow_scales_inversely_with_delta_t():
    flow_small_dt = required_cooling_flow_kg_s(1e6, 2.0)
    flow_large_dt = required_cooling_flow_kg_s(1e6, 10.0)
    assert flow_small_dt > flow_large_dt


def test_condenser_solve_converges_for_adequate_cooling(config):
    exhaust = state_pt(6.0e3, 320.0)  # a rough exhaust-region state for the probe
    result = solve_condenser(
        config.condenser,
        steam_mass_flow_kg_s=28.0,
        exhaust_enthalpy_j_kg=exhaust.enthalpy_j_kg,
        cooling_water_flow_kg_s=2000.0,
        cooling_water_inlet_temp_k=288.15,
    )
    assert config.condenser.min_pressure_pa <= result.condenser_pressure_pa <= config.condenser.max_pressure_pa
    assert result.cooling_water_outlet_temp_k > 288.15


def test_condenser_pressure_rises_with_less_cooling_flow(config):
    exhaust = state_pt(6.0e3, 320.0)
    generous = solve_condenser(config.condenser, 28.0, exhaust.enthalpy_j_kg, 2000.0, 288.15)
    scarce = solve_condenser(config.condenser, 28.0, exhaust.enthalpy_j_kg, 400.0, 288.15)
    assert scarce.condenser_pressure_pa >= generous.condenser_pressure_pa
