import math

import pytest

from mechanical.gearbox import apply_gearbox, compare_direct_vs_geared
from mechanical.inertia import angular_acceleration_rad_s2, rotational_kinetic_energy_j
from mechanical.shaft import evaluate_shaft, shaft_shear_stress_pa
from mechanical.torque import power_from_torque, rpm_to_rad_s, torque_from_power
from mechanical.vibration import evaluate_vibration, first_critical_speed_rpm


def test_torque_power_round_trip():
    torque = 1000.0
    rpm = 3000.0
    power = power_from_torque(torque, rpm)
    torque_back = torque_from_power(power, rpm)
    assert torque_back == pytest.approx(torque, rel=1e-9)


def test_rotational_kinetic_energy_scales_with_inertia_and_speed_squared():
    I = 1000.0
    ke_1x = rotational_kinetic_energy_j(I, 10.0)
    ke_2x_speed = rotational_kinetic_energy_j(I, 20.0)
    assert ke_2x_speed == pytest.approx(4 * ke_1x)

    ke_2x_inertia = rotational_kinetic_energy_j(2 * I, 10.0)
    assert ke_2x_inertia == pytest.approx(2 * ke_1x)


def test_angular_acceleration_inverse_with_inertia():
    torque = 5000.0
    alpha_light = angular_acceleration_rad_s2(torque, 100.0)
    alpha_heavy = angular_acceleration_rad_s2(torque, 200.0)
    assert alpha_heavy == pytest.approx(alpha_light / 2)


def test_shaft_stress_formula():
    torque = 10000.0
    diameter = 0.3
    tau = shaft_shear_stress_pa(torque, diameter)
    expected = 16.0 * torque / (math.pi * diameter ** 3)
    assert tau == pytest.approx(expected)


def test_shaft_safety_factor_flags_overstress(config):
    huge_torque = config.shaft.allowable_shear_stress_pa * math.pi * config.shaft.diameter_m ** 3 / 16.0 * 2.0
    result = evaluate_shaft(config.shaft, huge_torque)
    assert not result.within_allowable
    assert result.safety_factor < 1.0


def test_gearbox_conserves_power_minus_losses(config):
    result = apply_gearbox(config.gearbox, turbine_rpm=6000.0, turbine_torque_n_m=5000.0, gear_ratio=2.0)
    assert result.output_power_w == pytest.approx(result.input_power_w - result.loss_w)
    assert result.generator_rpm == pytest.approx(3000.0)


def test_gearbox_direct_drive_has_no_loss(config):
    result = apply_gearbox(config.gearbox, turbine_rpm=3000.0, turbine_torque_n_m=1000.0, gear_ratio=1.0)
    assert result.loss_w == pytest.approx(0.0)
    assert result.efficiency == pytest.approx(1.0)


def test_compare_direct_vs_geared(config):
    comparison = compare_direct_vs_geared(config.gearbox, turbine_rpm=6000.0, turbine_torque_n_m=5000.0, target_generator_rpm=3000.0)
    assert comparison["geared_drive"].generator_rpm == pytest.approx(3000.0, rel=1e-6)
    assert not comparison["direct_drive_matches_target"]


def test_first_critical_speed_positive(config):
    n1 = first_critical_speed_rpm(config.shaft, config.turbine.rotor_mass_kg)
    assert n1 > 0


def test_vibration_flags_near_critical_speed(config):
    n1 = first_critical_speed_rpm(config.shaft, config.turbine.rotor_mass_kg)
    result = evaluate_vibration(config.shaft, config.turbine.rotor_mass_kg, n1 * 0.98, config.limits)
    assert not result.within_limits
