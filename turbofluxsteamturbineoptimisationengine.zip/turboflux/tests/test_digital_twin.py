from core.state import DataProvenance
from digital_twin.calibration import calibrate_turbine_efficiency
from digital_twin.twin import DigitalTwin


def test_twin_update_produces_modelled_state(config, base_point):
    twin = DigitalTwin(config=config)
    state = twin.update(base_point)
    assert state.provenance == DataProvenance.MODELLED
    assert len(twin.history) == 1


def test_degradation_reduces_turbine_health(config):
    twin = DigitalTwin(config=config)
    before = twin.health.turbine_efficiency_factor
    twin.advance_degradation(days=1000)
    after = twin.health.turbine_efficiency_factor
    assert after < before


def test_maintenance_flagged_after_heavy_degradation(config):
    twin = DigitalTwin(config=config)
    twin.advance_degradation(days=5000)
    needed, reasons = twin.maintenance_recommended()
    assert needed
    assert len(reasons) > 0


def test_maintenance_not_flagged_when_new(config):
    twin = DigitalTwin(config=config)
    needed, reasons = twin.maintenance_recommended()
    assert not needed
    assert reasons == []


def test_calibration_recovers_known_factor(config, base_point):
    from core.engine import simulate
    from core.state import ComponentHealth

    true_factor = 0.9
    observed = simulate(config, base_point, ComponentHealth(turbine_efficiency_factor=true_factor)).net_electrical_power_w
    result = calibrate_turbine_efficiency(config, base_point, observed)
    assert abs(result.fitted_turbine_efficiency_factor - true_factor) < 0.02
