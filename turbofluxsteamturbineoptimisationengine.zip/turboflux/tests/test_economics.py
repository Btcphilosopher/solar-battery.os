from core.engine import simulate
from economics.fuel import fuel_cost_per_s
from economics.maintenance import maintenance_cost_per_s
from economics.operating_cost import compute_operating_cost
from economics.revenue import net_operating_margin_per_s, revenue_per_s


def test_revenue_scales_with_power(config, base_point):
    state = simulate(config, base_point)
    revenue = revenue_per_s(state, config.economics)
    expected = state.net_electrical_power_w * config.economics.electricity_price_per_wh / 3600.0
    assert revenue == expected


def test_maintenance_cost_increases_with_rpm(config):
    low = maintenance_cost_per_s(2000.0, config.economics)
    high = maintenance_cost_per_s(6000.0, config.economics)
    assert high > low


def test_operating_cost_breakdown_sums_correctly(config, base_point):
    state = simulate(config, base_point)
    breakdown = compute_operating_cost(state, config.steam_supply, config.economics)
    assert breakdown.total_cost_per_s == breakdown.fuel_cost_per_s + breakdown.maintenance_cost_per_s + breakdown.fixed_om_cost_per_s


def test_net_margin_is_revenue_minus_cost(config, base_point):
    state = simulate(config, base_point)
    margin = net_operating_margin_per_s(state, config.economics, config.steam_supply)
    revenue = revenue_per_s(state, config.economics)
    cost = compute_operating_cost(state, config.steam_supply, config.economics).total_cost_per_s
    assert margin == revenue - cost
