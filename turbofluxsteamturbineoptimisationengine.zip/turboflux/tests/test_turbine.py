import pytest

from thermodynamics.steam import state_pt
from turbine.rotor import RotorGeometry
from turbine.turbine import run_turbine


@pytest.fixture
def rotor(config):
    return RotorGeometry(config.turbine.rotor_diameter_m, config.turbine.rotor_mass_kg, config.turbine.rotor_length_m)


def test_run_turbine_produces_positive_power(config, rotor):
    inlet = state_pt(8.5e6, 773.15)
    result = run_turbine(config.turbine, rotor, inlet, condenser_pressure_pa=5.0e3, mass_flow_kg_s=28.0, rpm=3000.0)
    assert result.total_actual_power_w > 0
    assert len(result.stages) == len(config.turbine.stages)


def test_run_turbine_stage_chain_monotonically_decreases_pressure(config, rotor):
    inlet = state_pt(8.5e6, 773.15)
    result = run_turbine(config.turbine, rotor, inlet, condenser_pressure_pa=5.0e3, mass_flow_kg_s=28.0, rpm=3000.0)
    pressures = [s.inlet.pressure_pa for s in result.stages] + [result.exhaust_state.pressure_pa]
    assert all(pressures[i] > pressures[i + 1] for i in range(len(pressures) - 1))


def test_run_turbine_exhaust_reaches_condenser_pressure(config, rotor):
    inlet = state_pt(8.5e6, 773.15)
    result = run_turbine(config.turbine, rotor, inlet, condenser_pressure_pa=5.0e3, mass_flow_kg_s=28.0, rpm=3000.0)
    assert result.exhaust_state.pressure_pa == pytest.approx(5.0e3, rel=1e-6)


def test_actual_power_never_exceeds_ideal_power(config, rotor):
    inlet = state_pt(8.5e6, 773.15)
    result = run_turbine(config.turbine, rotor, inlet, condenser_pressure_pa=5.0e3, mass_flow_kg_s=28.0, rpm=3000.0)
    assert result.total_actual_power_w <= result.efficiency.total_ideal_power_w


def test_invalid_stage_pressure_split_raises(config, rotor):
    inlet = state_pt(8.5e6, 773.15)
    n = len(config.turbine.stages)
    # ratios > 1 would raise stage pressure instead of dropping it - must be rejected
    with pytest.raises(ValueError):
        run_turbine(config.turbine, rotor, inlet, condenser_pressure_pa=5.0e3, mass_flow_kg_s=28.0, rpm=3000.0,
                    stage_pressure_ratios=tuple([2.0] * n))
