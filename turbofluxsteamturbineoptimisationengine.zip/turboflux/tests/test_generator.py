import pytest

from generator.electrical import speed_deviation_from_sync_pct, synchronous_speed_rpm
from generator.generator import run_generator
from generator.grid import check_grid_compliance


def test_generator_conversion_conserves_energy(config):
    result = run_generator(config.generator, mechanical_power_w=20.0e6)
    assert result.electrical_output_w == pytest.approx(result.mechanical_input_w - result.loss_w)
    assert 0.0 < result.efficiency < 1.0


def test_generator_efficiency_degrades_at_low_load(config):
    high_load = run_generator(config.generator, mechanical_power_w=0.9 * config.generator.rated_electrical_power_w)
    low_load = run_generator(config.generator, mechanical_power_w=0.05 * config.generator.rated_electrical_power_w)
    assert high_load.efficiency > low_load.efficiency


def test_synchronous_speed_50hz_2pole(config):
    assert synchronous_speed_rpm(config.generator) == pytest.approx(3000.0)


def test_grid_compliance_flags_deviation(config):
    result = check_grid_compliance(config.generator, generator_rpm=2500.0)
    assert not result.grid_compliant
    result_ok = check_grid_compliance(config.generator, generator_rpm=3000.0)
    assert result_ok.grid_compliant


def test_speed_deviation_sign(config):
    dev = speed_deviation_from_sync_pct(config.generator, 3030.0)
    assert dev == pytest.approx(1.0, rel=1e-6)
