import pytest

from thermodynamics.expansion import expand, isentropic_outlet, stage_pressures_geometric
from thermodynamics.steam import saturation_pressure_pa, saturation_temperature_k, state_pt, state_px


def test_saturation_round_trip():
    p = 1.0e6
    t_sat = saturation_temperature_k(p)
    p_back = saturation_pressure_pa(t_sat)
    assert p_back == pytest.approx(p, rel=1e-3)


def test_isentropic_expansion_conserves_entropy():
    inlet = state_pt(8.5e6, 773.15)
    outlet = isentropic_outlet(inlet, 1.0e6)
    assert outlet.entropy_j_kgk == pytest.approx(inlet.entropy_j_kgk, rel=1e-6)
    assert outlet.enthalpy_j_kg < inlet.enthalpy_j_kg


def test_actual_expansion_efficiency_bounds():
    inlet = state_pt(8.5e6, 773.15)
    result = expand(inlet, 1.0e6, isentropic_efficiency=0.85)
    assert result.actual_enthalpy_drop_j_kg == pytest.approx(0.85 * result.isentropic_enthalpy_drop_j_kg, rel=1e-6)
    # actual drop must be less than isentropic (irreversibility)
    assert result.actual_enthalpy_drop_j_kg < result.isentropic_enthalpy_drop_j_kg


def test_expansion_rejects_invalid_efficiency():
    inlet = state_pt(8.5e6, 773.15)
    with pytest.raises(ValueError):
        expand(inlet, 1.0e6, isentropic_efficiency=1.5)
    with pytest.raises(ValueError):
        expand(inlet, 1.0e6, isentropic_efficiency=0.0)


def test_expansion_requires_pressure_drop():
    inlet = state_pt(8.5e6, 773.15)
    with pytest.raises(ValueError):
        expand(inlet, 9.0e6, isentropic_efficiency=0.85)  # outlet > inlet


def test_stage_pressures_geometric_endpoints():
    pressures = stage_pressures_geometric(8.5e6, 5.0e3, 5)
    assert pressures[0] == pytest.approx(8.5e6)
    assert pressures[-1] == pytest.approx(5.0e3)
    assert len(pressures) == 6
    # monotonically decreasing
    assert all(pressures[i] > pressures[i + 1] for i in range(len(pressures) - 1))


def test_state_px_quality_bounds():
    wet = state_px(1.0e5, 0.9)
    assert wet.quality == pytest.approx(0.9, abs=1e-6)
    assert wet.is_two_phase
