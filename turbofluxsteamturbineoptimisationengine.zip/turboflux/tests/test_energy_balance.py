import pytest

from core.engine import simulate


def test_energy_balance_closes(config, base_point):
    state = simulate(config, base_point)
    assert abs(state.energy_balance_residual_w) < 1.0


def test_energy_balance_closes_across_rpm_sweep(config, base_point):
    from dataclasses import replace

    for rpm in [2000.0, 3000.0, 5000.0, 7000.0]:
        op = replace(base_point, shaft_rpm=rpm)
        state = simulate(config, op)
        assert abs(state.energy_balance_residual_w) < 1.0, f"residual too large at rpm={rpm}"


def test_net_electrical_power_positive(config, base_point):
    state = simulate(config, base_point)
    assert state.net_electrical_power_w > 0


def test_losses_are_nonnegative(config, base_point):
    state = simulate(config, base_point)
    assert state.mechanical_loss_w >= 0
    assert state.gearbox_loss_w >= 0
    assert state.generator_loss_w >= 0
    assert state.condenser_heat_rejected_w >= 0
    assert state.turbine_health_degradation_loss_w >= -1e-6


def test_overall_efficiency_below_carnot_style_sanity_bound(config, base_point):
    state = simulate(config, base_point)
    # A real Rankine cycle must sit comfortably below 60% - if it doesn't,
    # something in the energy chain is badly wrong.
    assert 0.0 < state.overall_efficiency < 0.60
