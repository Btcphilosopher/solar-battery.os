from dataclasses import replace

import numpy as np

from core.engine import simulate
from optimisation.constraints import check_constraints
from optimisation.objectives import ObjectiveMode, score
from optimisation.optimiser import optimise
from optimisation.parameter_sweep import find_optimum_in_sweep, sweep_1d
from optimisation.sensitivity import run_sensitivity


def test_infeasible_operating_point_is_rejected_by_score(config, base_point):
    # push RPM far outside the allowed envelope
    bad_point = replace(base_point, shaft_rpm=config.limits.max_rpm * 5)
    state = simulate(config, bad_point)
    assert not state.is_feasible
    s = score(ObjectiveMode.MAX_POWER, state, config.economics, config.steam_supply)
    assert s < -1e6  # heavily penalised, never a "good" score


def test_feasible_baseline_has_no_violations(config, base_point):
    state = simulate(config, base_point)
    assert state.constraint_violations == []


def test_rpm_out_of_range_is_flagged(config, base_point):
    bad_point = replace(base_point, shaft_rpm=config.limits.min_rpm * 0.1)
    state = simulate(config, bad_point)
    assert any("RPM" in v for v in state.constraint_violations)


def test_sweep_1d_returns_expected_columns(config, base_point):
    df = sweep_1d(config, base_point, "shaft_rpm", np.linspace(2000, 4000, 4))
    assert "net_electrical_power_w" in df.columns
    assert len(df) == 4


def test_find_optimum_in_sweep_prefers_feasible(config, base_point):
    df = sweep_1d(config, base_point, "shaft_rpm", np.linspace(1500, 9000, 8))
    best = find_optimum_in_sweep(df)
    assert bool(best["feasible"]) is True


def test_optimiser_smoke_test_converges_and_improves_or_matches_baseline(config, base_point):
    baseline_state = simulate(config, base_point)
    result = optimise(config, mode=ObjectiveMode.MAX_NET_ENERGY, maxiter=4, popsize=6, seed=1)
    assert result.best_state is not None
    # with a tiny search budget we only require the machinery runs end to
    # end and returns a plausible (finite, non-negative) power figure
    assert result.best_state.net_electrical_power_w >= 0
    assert np.isfinite(result.best_state.net_electrical_power_w)


def test_sensitivity_returns_ranked_dataframe(config, base_point):
    df = run_sensitivity(config, base_point)
    assert "rank_by_power_impact" in df.columns
    assert len(df) >= 5
