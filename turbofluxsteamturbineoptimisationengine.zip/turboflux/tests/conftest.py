import pytest

from examples.baseline_turbine import build_baseline_config, build_baseline_operating_point


@pytest.fixture
def config():
    return build_baseline_config()


@pytest.fixture
def base_point(config):
    return build_baseline_operating_point(config)
