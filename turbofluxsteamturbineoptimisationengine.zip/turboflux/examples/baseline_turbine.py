"""
examples/baseline_turbine.py
===============================
The complete baseline example system (section 25): a ~25 MW-class
condensing steam turbine-generator with a 3-stage (HP/IP/LP) turbine, a
geared drive (so shaft RPM and generator RPM are decoupled - letting the
RPM optimiser demonstrate section 7's "max RPM != max power" point
honestly instead of pretending RPM is free when a direct-coupled 2-pole
generator would actually clamp it to 3000 rpm), and a water-cooled
surface condenser.

This module only builds configuration/operating-point objects - running
the sequence of studies described in section 25 lives in main.py, which
imports this baseline.
"""
from __future__ import annotations

from core.configuration import (
    BearingConfig,
    CondenserConfig,
    EconomicConfig,
    GearboxConfig,
    GeneratorConfig,
    PlantConfig,
    SafetyLimits,
    ShaftConfig,
    StageConfig,
    SteamSupplyConfig,
    TurbineConfig,
)
from core.state import OperatingPoint


def build_baseline_config() -> PlantConfig:
    return PlantConfig(
        name="TURBOFLUX Baseline 30 MW-class Condensing Turbine",
        steam_supply=SteamSupplyConfig(
            rated_pressure_pa=8.5e6,
            rated_temperature_k=773.15,  # 500 C
            max_mass_flow_kg_s=40.0,
            min_mass_flow_kg_s=4.0,
            boiler_thermal_efficiency=0.90,
            fuel_lhv_j_kg=42.0e6,
        ),
        turbine=TurbineConfig(
            # 10 elemental pressure stages grouped HP(4)/IP(3)/LP(3) - a
            # single "HP" row in a real machine would over-expand the flow
            # given an ~1700:1 overall pressure ratio, so the HP/IP/LP
            # sections used elsewhere in this codebase (e.g. section-9
            # comparisons) are each represented here by several elemental
            # stages, keeping per-stage enthalpy drop (and hence nozzle
            # exit velocity / blade-speed ratio) in a physically sane range.
            stages=[
                StageConfig(name="HP-1", isentropic_efficiency=0.83, nozzle_efficiency=0.97, reaction=0.25),
                StageConfig(name="HP-2", isentropic_efficiency=0.84, nozzle_efficiency=0.97, reaction=0.3),
                StageConfig(name="HP-3", isentropic_efficiency=0.85, nozzle_efficiency=0.97, reaction=0.3),
                StageConfig(name="HP-4", isentropic_efficiency=0.85, nozzle_efficiency=0.97, reaction=0.35),
                StageConfig(name="IP-1", isentropic_efficiency=0.87, nozzle_efficiency=0.97, reaction=0.45),
                StageConfig(name="IP-2", isentropic_efficiency=0.88, nozzle_efficiency=0.97, reaction=0.5),
                StageConfig(name="IP-3", isentropic_efficiency=0.88, nozzle_efficiency=0.97, reaction=0.5),
                StageConfig(name="LP-1", isentropic_efficiency=0.87, nozzle_efficiency=0.96, reaction=0.5),
                StageConfig(name="LP-2", isentropic_efficiency=0.85, nozzle_efficiency=0.96, reaction=0.5),
                StageConfig(name="LP-3", isentropic_efficiency=0.82, nozzle_efficiency=0.95, reaction=0.5),
            ],
            rotor_diameter_m=1.8,
            rotor_mass_kg=4200.0,
            rotor_length_m=3.2,
            windage_loss_coefficient=8.0e-7,
            leakage_loss_fraction=0.02,
        ),
        shaft=ShaftConfig(diameter_m=0.32, length_m=5.5),
        bearings=BearingConfig(count=2, friction_coefficient=0.0015),
        gearbox=GearboxConfig(present=True, rated_ratio=1.6, base_efficiency=0.985, efficiency_ratio_sensitivity=0.008),
        generator=GeneratorConfig(
            rated_electrical_power_w=32.0e6,
            rated_rpm=3000.0,
            poles=2,
            grid_frequency_hz=50.0,
            no_load_loss_fraction=0.008,
            full_load_copper_loss_fraction=0.018,
            power_factor=0.9,
        ),
        condenser=CondenserConfig(
            design_pressure_pa=5.0e3,
            cooling_water_inlet_temp_k=288.15,
            terminal_temperature_difference_k=4.0,
            overall_heat_transfer_coefficient_w_m2k=2600.0,
            heat_transfer_area_m2=5500.0,
            max_cooling_water_flow_kg_s=2200.0,
            min_pressure_pa=2.5e3,
            max_pressure_pa=15.0e3,
        ),
        limits=SafetyLimits(
            min_rpm=1500.0,
            max_rpm=9000.0,
            critical_speed_margin_pct=15.0,
            max_vibration_amplitude_m=75e-6,
            max_shaft_stress_pa=120e6,
            min_inlet_pressure_pa=3.0e6,
            max_inlet_pressure_pa=9.5e6,
            min_inlet_temperature_k=573.15,
            max_inlet_temperature_k=793.15,
            max_exhaust_wetness_fraction=0.12,
            min_condenser_pressure_pa=2.5e3,
            max_condenser_pressure_pa=15.0e3,
            max_generator_load_fraction=1.05,
            min_gear_ratio=0.5,
            max_gear_ratio=6.0,
        ),
        economics=EconomicConfig(
            fuel_cost_per_j=3.5e-9,
            electricity_price_per_wh=7.0e-5,
            fixed_om_cost_per_s=0.03,
            variable_maintenance_cost_per_rpm_hour=2.0e-6,
            random_seed=42,
        ),
    )


def build_baseline_operating_point(config: PlantConfig) -> OperatingPoint:
    """A deliberately conservative, non-optimised starting point - close
    to design conditions but with a round-number RPM and gear ratio, not
    yet tuned by the optimiser. This is the BASELINE the optimiser is
    compared against in section 25."""
    return OperatingPoint(
        inlet_pressure_pa=config.steam_supply.rated_pressure_pa,
        inlet_temperature_k=config.steam_supply.rated_temperature_k,
        steam_mass_flow_kg_s=28.0,
        condenser_pressure_pa=config.condenser.design_pressure_pa,
        shaft_rpm=3000.0,
        gear_ratio=1.0,
        cooling_water_flow_kg_s=1400.0,
        cooling_water_inlet_temp_k=config.condenser.cooling_water_inlet_temp_k,
    )
