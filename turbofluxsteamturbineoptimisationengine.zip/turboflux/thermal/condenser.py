"""
thermal/condenser.py
======================
Condenser model (section 14): steam-side condensation heat rejection
balanced against cooling-water-side heat pickup through a UA (overall
heat-transfer-coefficient x area) exchanger, solved self-consistently for
the achievable condensing pressure.

Given:
    steam mass flow, turbine exhaust enthalpy,
    cooling water inlet temperature and flow,
    exchanger UA (from CondenserConfig, degraded by fouling_factor),
    terminal temperature difference (TTD) is implicit in the LMTD solve
    (not added separately - the LMTD formulation already captures the
    approach temperature between the isothermal steam side and the
    warming cooling-water side).

Solve for the saturation temperature Tsat (and hence P_cond) at which:

    Q_steam(Tsat) = mdot_steam * (h_exhaust - h_saturated_liquid(Tsat))
    Q_transfer(Tsat) = UA * LMTD(Tsat, T_cw_in, T_cw_out(Tsat))

balance, using Brent's method (scipy.optimize.brentq) - a 1-D root find,
robust and fast enough for repeated calls inside an optimiser.
"""
from __future__ import annotations

from dataclasses import dataclass

from scipy.optimize import brentq

from core.configuration import CondenserConfig
from thermal.cooling import WATER_CP_J_KGK, cooling_water_outlet_temp_k
from thermal.heat_transfer import lmtd_k
from thermodynamics.steam import saturation_pressure_pa, saturation_temperature_k, state_px


@dataclass(frozen=True)
class CondenserResult:
    condenser_pressure_pa: float
    saturation_temperature_k: float
    cooling_water_outlet_temp_k: float
    heat_rejected_w: float
    ua_w_k: float
    converged: bool
    notes: list


def effective_ua_w_k(config: CondenserConfig, fouling_factor: float = 1.0) -> float:
    """UA degraded by fouling (>1 fouling_factor = more fouled = lower
    effective UA)."""
    return (config.overall_heat_transfer_coefficient_w_m2k * config.heat_transfer_area_m2) / max(fouling_factor, 1e-6)


def solve_condenser(
    config: CondenserConfig,
    steam_mass_flow_kg_s: float,
    exhaust_enthalpy_j_kg: float,
    cooling_water_flow_kg_s: float,
    cooling_water_inlet_temp_k: float,
    fouling_factor: float = 1.0,
) -> CondenserResult:
    ua = effective_ua_w_k(config, fouling_factor)
    notes: list[str] = []

    def residual(t_sat: float) -> float:
        p_sat = saturation_pressure_pa(t_sat)
        h_liq = state_px(p_sat, 0.0).enthalpy_j_kg
        q_steam = steam_mass_flow_kg_s * (exhaust_enthalpy_j_kg - h_liq)
        cw_out = cooling_water_outlet_temp_k(cooling_water_inlet_temp_k, q_steam, cooling_water_flow_kg_s)
        if cw_out >= t_sat:
            # t_sat is too low for the cooling water to ever reach (the
            # LMTD approach would go negative) - the achievable heat
            # transfer at/below this t_sat is effectively zero, so the
            # residual (duty - transfer) is large and POSITIVE, exactly
            # the sign brentq needs to keep searching upward from here.
            return q_steam
        lmtd = lmtd_k(t_sat, t_sat, cooling_water_inlet_temp_k, cw_out)
        q_transfer = ua * lmtd
        return q_steam - q_transfer

    t_low = cooling_water_inlet_temp_k + 0.5
    t_high = saturation_temperature_k(config.max_pressure_pa)

    try:
        r_low, r_high = residual(t_low), residual(t_high)
        if r_low * r_high > 0:
            # No sign change - fall back to the configured design pressure
            # and flag it rather than returning a spuriously "solved" value.
            notes.append(
                "Condenser heat balance did not bracket a root within the "
                "configured pressure range; falling back to design pressure. "
                "Check cooling water flow/temperature adequacy."
            )
            p_cond = config.design_pressure_pa
            t_sat = saturation_temperature_k(p_cond)
            converged = False
        else:
            t_sat = brentq(residual, t_low, t_high, xtol=1e-4)
            p_cond = saturation_pressure_pa(t_sat)
            converged = True
    except Exception as exc:  # pragma: no cover - defensive
        notes.append(f"Condenser solve failed ({exc}); falling back to design pressure.")
        p_cond = config.design_pressure_pa
        t_sat = saturation_temperature_k(p_cond)
        converged = False

    p_cond = min(max(p_cond, config.min_pressure_pa), config.max_pressure_pa)
    h_liq = state_px(p_cond, 0.0).enthalpy_j_kg
    q_steam = steam_mass_flow_kg_s * (exhaust_enthalpy_j_kg - h_liq)
    cw_out = cooling_water_outlet_temp_k(cooling_water_inlet_temp_k, q_steam, cooling_water_flow_kg_s)

    return CondenserResult(
        condenser_pressure_pa=p_cond,
        saturation_temperature_k=t_sat,
        cooling_water_outlet_temp_k=cw_out,
        heat_rejected_w=q_steam,
        ua_w_k=ua,
        converged=converged,
        notes=notes,
    )
