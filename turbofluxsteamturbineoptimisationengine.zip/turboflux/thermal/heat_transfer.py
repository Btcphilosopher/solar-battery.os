"""thermal/heat_transfer.py - LMTD / UA heat exchanger relationships."""
from __future__ import annotations

import math


def lmtd_k(t_hot_in: float, t_hot_out: float, t_cold_in: float, t_cold_out: float) -> float:
    """Log-mean temperature difference for a counter-flow exchanger
    (used here for the condenser: steam side is isothermal at Tsat, so
    this reduces cleanly for that case too)."""
    dt1 = t_hot_in - t_cold_out
    dt2 = t_hot_out - t_cold_in
    if dt1 <= 0 or dt2 <= 0:
        raise ValueError("Non-physical temperature crossing in LMTD calculation")
    if abs(dt1 - dt2) < 1e-9:
        return dt1
    return (dt1 - dt2) / math.log(dt1 / dt2)


def heat_duty_w(U_w_m2k: float, area_m2: float, lmtd_k_: float) -> float:
    return U_w_m2k * area_m2 * lmtd_k_


def required_area_m2(duty_w: float, U_w_m2k: float, lmtd_k_: float) -> float:
    if U_w_m2k <= 0 or lmtd_k_ <= 0:
        raise ValueError("U and LMTD must be positive")
    return duty_w / (U_w_m2k * lmtd_k_)
