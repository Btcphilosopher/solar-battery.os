"""
thermal/temperature.py
========================
Simplified casing/rotor thermal-state bookkeeping, and the qualitative
effects of steam temperature/pressure/condenser-pressure changes on cycle
performance (section 13), expressed as first-order sensitivities used by
analytics/bottlenecks.py and the "what-if" engine.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ThermalState:
    steam_inlet_temp_k: float
    casing_temp_estimate_k: float
    exhaust_temp_k: float


def estimate_casing_temperature_k(steam_inlet_temp_k: float, exhaust_temp_k: float, casing_thermal_lag_fraction: float = 0.85) -> float:
    """Very simple lumped-mass approximation: casing metal temperature
    tracks toward the mass-flow-weighted average of the through-flow
    steam temperatures, lagged by a fraction (thick-walled HP casings run
    closer to inlet temperature than a lumped average would suggest,
    hence a lag factor > 0.5)."""
    avg = casing_thermal_lag_fraction * steam_inlet_temp_k + (1 - casing_thermal_lag_fraction) * exhaust_temp_k
    return avg


def qualitative_effect_of_higher_inlet_temperature() -> str:
    return (
        "Higher steam inlet temperature (at fixed pressure) increases the "
        "isentropic enthalpy drop available to the turbine (moves the "
        "expansion line further right/up on the h-s diagram before it "
        "crosses into the wet region), raising both power and cycle "
        "efficiency, and reduces exhaust wetness - beneficial up to "
        "material temperature limits (SafetyLimits.max_inlet_temperature_k)."
    )


def qualitative_effect_of_higher_inlet_pressure() -> str:
    return (
        "Higher steam inlet pressure (at fixed temperature) increases the "
        "available enthalpy drop for a given expansion ratio, generally "
        "raising power and efficiency, but drives the expansion line "
        "toward higher exhaust wetness at a fixed condenser pressure - "
        "trading exhaust-blade erosion risk against thermal efficiency."
    )


def qualitative_effect_of_lower_condenser_pressure() -> str:
    return (
        "Lower condenser pressure increases the overall expansion ratio "
        "and available enthalpy drop (more of the h-s diagram is used), "
        "raising turbine power and cycle efficiency - but increases LP "
        "exhaust wetness/erosion risk, requires more cooling water or "
        "colder cooling water, and needs a deeper vacuum system; there is "
        "a practical floor set by SafetyLimits.min_condenser_pressure_pa "
        "and by cooling-water/condenser-area availability."
    )
