"""Thermal system: heat transfer, cooling, condenser, temperature effects."""
