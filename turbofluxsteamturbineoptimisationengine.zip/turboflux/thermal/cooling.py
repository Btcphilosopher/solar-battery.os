"""thermal/cooling.py - cooling-water flow sizing."""
from __future__ import annotations

WATER_CP_J_KGK = 4186.0  # specific heat of liquid cooling water, near-ambient


def required_cooling_flow_kg_s(heat_duty_w: float, delta_t_k: float) -> float:
    if delta_t_k <= 0:
        raise ValueError("delta_t_k must be positive")
    return heat_duty_w / (WATER_CP_J_KGK * delta_t_k)


def cooling_water_outlet_temp_k(inlet_temp_k: float, heat_duty_w: float, flow_kg_s: float) -> float:
    if flow_kg_s <= 0:
        raise ValueError("flow_kg_s must be positive")
    return inlet_temp_k + heat_duty_w / (WATER_CP_J_KGK * flow_kg_s)
