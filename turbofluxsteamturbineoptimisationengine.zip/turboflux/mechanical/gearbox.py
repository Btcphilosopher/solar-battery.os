"""
mechanical/gearbox.py
=======================
Turbine shaft -> gearbox -> generator shaft (section 9).

    generator_rpm = turbine_rpm / gear_ratio
    generator_torque = turbine_torque * gear_ratio * efficiency
    P_out = P_in * efficiency

Gearbox efficiency is modelled as peaking at the design ratio and
degrading (extra meshing/windage losses) the further the operating ratio
is pushed from that design point - a simple, monotone, documented
MODELLED penalty, not a manufacturer loss map.
"""
from __future__ import annotations

from dataclasses import dataclass

from core.configuration import GearboxConfig


@dataclass(frozen=True)
class GearboxResult:
    generator_rpm: float
    input_torque_n_m: float
    output_torque_n_m: float
    input_power_w: float
    output_power_w: float
    loss_w: float
    efficiency: float


def effective_efficiency(config: GearboxConfig, operating_ratio: float) -> float:
    deviation = abs(operating_ratio - config.rated_ratio)
    penalty = config.efficiency_ratio_sensitivity * deviation
    return max(0.5, config.base_efficiency - penalty)


def apply_gearbox(config: GearboxConfig, turbine_rpm: float, turbine_torque_n_m: float, gear_ratio: float, health_factor: float = 1.0) -> GearboxResult:
    if not config.present or abs(gear_ratio - 1.0) < 1e-9:
        # direct drive: no ratio change, negligible coupling loss
        p_in = _power(turbine_torque_n_m, turbine_rpm)
        return GearboxResult(
            generator_rpm=turbine_rpm,
            input_torque_n_m=turbine_torque_n_m,
            output_torque_n_m=turbine_torque_n_m,
            input_power_w=p_in,
            output_power_w=p_in,
            loss_w=0.0,
            efficiency=1.0,
        )

    if gear_ratio <= 0:
        raise ValueError("gear_ratio must be positive")

    eta = effective_efficiency(config, gear_ratio) * health_factor
    generator_rpm = turbine_rpm / gear_ratio
    p_in = _power(turbine_torque_n_m, turbine_rpm)
    p_out = p_in * eta
    loss = p_in - p_out
    output_torque = _torque(p_out, generator_rpm)

    return GearboxResult(
        generator_rpm=generator_rpm,
        input_torque_n_m=turbine_torque_n_m,
        output_torque_n_m=output_torque,
        input_power_w=p_in,
        output_power_w=p_out,
        loss_w=loss,
        efficiency=eta,
    )


def _power(torque_n_m: float, rpm: float) -> float:
    import math
    return torque_n_m * 2.0 * math.pi * rpm / 60.0


def _torque(power_w: float, rpm: float) -> float:
    import math
    omega = 2.0 * math.pi * rpm / 60.0
    return power_w / omega if omega > 0 else 0.0


def compare_direct_vs_geared(
    config: GearboxConfig, turbine_rpm: float, turbine_torque_n_m: float, target_generator_rpm: float
) -> dict:
    """Section 9: compare DIRECT DRIVE vs GEARED DRIVE for reaching a
    target generator speed (e.g. the synchronous speed for grid lock)."""
    direct_cfg = GearboxConfig(present=False, rated_ratio=1.0, base_efficiency=1.0, efficiency_ratio_sensitivity=0.0)
    direct = apply_gearbox(direct_cfg, turbine_rpm, turbine_torque_n_m, 1.0)

    required_ratio = turbine_rpm / target_generator_rpm if target_generator_rpm > 0 else 1.0
    geared = apply_gearbox(config, turbine_rpm, turbine_torque_n_m, required_ratio)

    return {
        "direct_drive": direct,
        "geared_drive": geared,
        "required_gear_ratio": required_ratio,
        "direct_drive_matches_target": abs(turbine_rpm - target_generator_rpm) < 1e-6,
    }
