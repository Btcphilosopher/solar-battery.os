"""
mechanical/shaft.py
=====================
Shaft torsional stress and safety-factor check.

Standard solid-round-shaft torsion formula:

    tau_max = 16 * T / (pi * d^3)      [max shear stress at the surface]

This is a strength-of-materials first-pass check, not a fatigue/notch/
stress-concentration analysis. Documented explicitly as a simplified
static check.
"""
from __future__ import annotations

from dataclasses import dataclass
import math

from core.configuration import ShaftConfig


@dataclass(frozen=True)
class ShaftStressResult:
    shear_stress_pa: float
    safety_factor: float
    within_allowable: bool


def shaft_shear_stress_pa(torque_n_m: float, diameter_m: float) -> float:
    if diameter_m <= 0:
        raise ValueError("diameter_m must be positive")
    return 16.0 * abs(torque_n_m) / (math.pi * diameter_m ** 3)


def evaluate_shaft(config: ShaftConfig, torque_n_m: float) -> ShaftStressResult:
    tau = shaft_shear_stress_pa(torque_n_m, config.diameter_m)
    sf = config.allowable_shear_stress_pa / tau if tau > 0 else float("inf")
    return ShaftStressResult(
        shear_stress_pa=tau,
        safety_factor=sf,
        within_allowable=tau <= config.allowable_shear_stress_pa,
    )


def torsional_stiffness_n_m_per_rad(config: ShaftConfig) -> float:
    """k_theta = G * J / L, with J the shaft's (not rotor's) polar second
    moment of area for a solid round section: J = pi * d^4 / 32."""
    J = math.pi * config.diameter_m ** 4 / 32.0
    return config.shear_modulus_pa * J / config.length_m
