"""mechanical/torque.py - torque/power/speed conversions."""
from __future__ import annotations

import math


def torque_from_power(power_w: float, rpm: float) -> float:
    omega = 2.0 * math.pi * rpm / 60.0
    if omega <= 0:
        return 0.0
    return power_w / omega


def power_from_torque(torque_n_m: float, rpm: float) -> float:
    omega = 2.0 * math.pi * rpm / 60.0
    return torque_n_m * omega


def rpm_to_rad_s(rpm: float) -> float:
    return 2.0 * math.pi * rpm / 60.0


def rad_s_to_rpm(omega_rad_s: float) -> float:
    return omega_rad_s * 60.0 / (2.0 * math.pi)
