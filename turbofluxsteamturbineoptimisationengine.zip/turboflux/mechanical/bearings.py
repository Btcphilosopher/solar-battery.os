"""
mechanical/bearings.py
========================
Journal-bearing friction loss, modelled as a simple Petroff-type viscous
friction torque scaling with rotor weight and speed:

    P_bearing_loss = n_bearings * f * W_per_bearing * u_journal_surface_speed

where f is an effective friction coefficient (already lumps oil viscosity,
clearance, etc, into one calibrated number) and u is the journal surface
speed. This grows with RPM, consistent with section 11's requirement that
mechanical losses may increase with RPM.
"""
from __future__ import annotations

from dataclasses import dataclass
import math

from core.configuration import BearingConfig


@dataclass(frozen=True)
class BearingLossResult:
    friction_power_loss_w: float
    load_per_bearing_n: float
    within_capacity: bool


def bearing_loss_w(config: BearingConfig, rotor_weight_n: float, shaft_diameter_m: float, rpm: float) -> BearingLossResult:
    load_per_bearing = rotor_weight_n / config.count
    journal_surface_speed = math.pi * shaft_diameter_m * rpm / 60.0
    loss = config.count * config.friction_coefficient * load_per_bearing * journal_surface_speed
    return BearingLossResult(
        friction_power_loss_w=loss,
        load_per_bearing_n=load_per_bearing,
        within_capacity=load_per_bearing <= config.load_capacity_n,
    )
