"""Shaft, bearings, gearbox, inertia and simplified rotordynamics."""
