"""
mechanical/vibration.py
=========================
SIMPLIFIED lateral rotordynamics using a single-mass Jeffcott-rotor model.
This is explicitly NOT a full finite-element rotordynamic analysis (no
gyroscopic coupling, no distributed mass, no multi-mode Campbell diagram).
It exists to give the optimiser a physically-grounded critical-speed and
unbalance-response constraint cheap enough to evaluate thousands of times
inside an optimisation loop; a real project would validate any candidate
operating point against a proper FE rotordynamic model before commissioning.

Jeffcott rotor:
    lateral stiffness (simply-supported shaft, central point mass):
        k = 48 * E * I_area / L^3
    first critical (natural) speed:
        omega_n = sqrt(k / m)
    unbalance response amplitude at running speed omega:
        A(omega) = e * r^2 / sqrt((1 - r^2)^2 + (2 * zeta * r)^2),  r = omega/omega_n
"""
from __future__ import annotations

from dataclasses import dataclass
import math

from core.configuration import ShaftConfig, SafetyLimits
from mechanical.torque import rpm_to_rad_s, rad_s_to_rpm

DEFAULT_ECCENTRICITY_M = 5.0e-5   # 50 micron residual mass-eccentricity, typical balance-grade assumption
DEFAULT_DAMPING_RATIO = 0.05      # lightly damped steel rotor on oil-film bearings, typical order of magnitude


@dataclass(frozen=True)
class VibrationResult:
    first_critical_rpm: float
    second_critical_rpm: float
    operating_rpm: float
    nearest_critical_rpm: float
    margin_pct: float
    amplitude_m: float
    within_limits: bool
    notes: list


def lateral_stiffness_n_per_m(shaft: ShaftConfig, rotor_mass_kg: float) -> float:
    I_area = math.pi * shaft.diameter_m ** 4 / 64.0  # bending second moment of area
    return 48.0 * shaft.youngs_modulus_pa * I_area / shaft.length_m ** 3


def first_critical_speed_rpm(shaft: ShaftConfig, rotor_mass_kg: float) -> float:
    k = lateral_stiffness_n_per_m(shaft, rotor_mass_kg)
    omega_n = math.sqrt(k / rotor_mass_kg)
    return rad_s_to_rpm(omega_n)


def unbalance_amplitude_m(operating_rpm: float, critical_rpm: float, eccentricity_m: float = DEFAULT_ECCENTRICITY_M, damping_ratio: float = DEFAULT_DAMPING_RATIO) -> float:
    if critical_rpm <= 0:
        return float("inf")
    r = operating_rpm / critical_rpm
    denom = math.sqrt((1 - r ** 2) ** 2 + (2 * damping_ratio * r) ** 2)
    if denom == 0:
        return float("inf")
    return eccentricity_m * r ** 2 / denom


def evaluate_vibration(shaft: ShaftConfig, rotor_mass_kg: float, operating_rpm: float, limits: SafetyLimits) -> VibrationResult:
    notes = [
        "SIMPLIFIED single-mass Jeffcott rotor model - not a substitute for "
        "full finite-element rotordynamic analysis before real commissioning."
    ]
    n1 = first_critical_speed_rpm(shaft, rotor_mass_kg)
    n2 = n1 * 2.0  # second mode of a simply-supported uniform shaft ~ 4x n1 for a distributed
    # beam, but for the Jeffcott (single central mass) idealisation the
    # commonly used engineering rule-of-thumb spacing to the next mode is
    # taken conservatively at ~2x; documented as an approximation.

    nearest = min([n1, n2], key=lambda n: abs(operating_rpm - n))
    margin_pct = abs(operating_rpm - nearest) / nearest * 100.0 if nearest > 0 else 0.0

    amplitude = unbalance_amplitude_m(operating_rpm, n1)

    within = (margin_pct >= limits.critical_speed_margin_pct) and (amplitude <= limits.max_vibration_amplitude_m)
    if margin_pct < limits.critical_speed_margin_pct:
        notes.append(
            f"Operating RPM {operating_rpm:.0f} is within {margin_pct:.1f}% of a critical "
            f"speed ({nearest:.0f} rpm); required margin is {limits.critical_speed_margin_pct:.1f}%."
        )
    if amplitude > limits.max_vibration_amplitude_m:
        notes.append(
            f"Predicted unbalance amplitude {amplitude*1e6:.1f} micron exceeds the "
            f"configured limit {limits.max_vibration_amplitude_m*1e6:.1f} micron."
        )

    return VibrationResult(
        first_critical_rpm=n1,
        second_critical_rpm=n2,
        operating_rpm=operating_rpm,
        nearest_critical_rpm=nearest,
        margin_pct=margin_pct,
        amplitude_m=amplitude,
        within_limits=within,
        notes=notes,
    )
