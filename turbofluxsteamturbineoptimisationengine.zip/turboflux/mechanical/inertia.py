"""
mechanical/inertia.py
=======================
Rotor mass / polar moment of inertia and rotational dynamics (section 8).

TURBOFLUX explicitly separates two different physical quantities that are
easy to conflate:

    STORED ROTATIONAL ENERGY   E = 1/2 * I * omega^2   (a reservoir)
    CONTINUOUS ENERGY OUTPUT   P_electrical(t)           (a throughput)

A heavier rotor stores more kinetic energy at a given speed and resists
speed changes more (tau = I * alpha), which affects transient response,
start-up time and vibration sensitivity - but it does NOT add continuously
extractable power. At steady state the rotor's stored energy is constant
and every watt of electrical output still has to come from the steam-side
enthalpy drop. This module exists specifically so that relationship is
never confused elsewhere in the codebase.
"""
from __future__ import annotations

from dataclasses import dataclass

from turbine.rotor import RotorGeometry


@dataclass(frozen=True)
class InertiaReport:
    polar_moment_of_inertia_kg_m2: float
    rotational_kinetic_energy_j: float
    startup_time_s: float
    startup_torque_n_m: float
    notes: list


def rotational_kinetic_energy_j(inertia_kg_m2: float, omega_rad_s: float) -> float:
    return 0.5 * inertia_kg_m2 * omega_rad_s ** 2


def angular_acceleration_rad_s2(net_torque_n_m: float, inertia_kg_m2: float) -> float:
    """tau = I * alpha -> alpha = tau / I."""
    if inertia_kg_m2 <= 0:
        raise ValueError("inertia_kg_m2 must be positive")
    return net_torque_n_m / inertia_kg_m2


def spin_up_time_s(inertia_kg_m2: float, available_accel_torque_n_m: float, target_omega_rad_s: float) -> float:
    """Time to accelerate from rest to target speed assuming constant net
    accelerating torque (a first-order estimate; real start-up curves are
    non-constant as turbine torque itself varies with speed - see
    turboflux.core.simulation for a stepped transient integration)."""
    alpha = angular_acceleration_rad_s2(available_accel_torque_n_m, inertia_kg_m2)
    if alpha <= 0:
        return float("inf")
    return target_omega_rad_s / alpha


def evaluate_inertia(rotor: RotorGeometry, target_rpm: float, available_accel_torque_n_m: float) -> InertiaReport:
    import math

    I = rotor.polar_moment_of_inertia_kg_m2
    omega = 2.0 * math.pi * target_rpm / 60.0
    ke = rotational_kinetic_energy_j(I, omega)
    t_startup = spin_up_time_s(I, available_accel_torque_n_m, omega)

    notes = [
        "Rotational kinetic energy is a stored reservoir, not a source of "
        "continuous electrical output; it does not appear in the steady-"
        "state power balance (see core/engine.py energy balance).",
        f"Higher rotor mass ({rotor.mass_kg:.0f} kg) increases stored energy "
        f"and start-up time ({t_startup:.1f} s) but does not by itself "
        f"increase net_electrical_power_w.",
    ]
    return InertiaReport(
        polar_moment_of_inertia_kg_m2=I,
        rotational_kinetic_energy_j=ke,
        startup_time_s=t_startup,
        startup_torque_n_m=available_accel_torque_n_m,
        notes=notes,
    )
