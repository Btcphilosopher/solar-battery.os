"""
optimisation/sensitivity.py
==============================
One-at-a-time (OAT) sensitivity analysis (section 18): perturb each
listed input by a configured percentage, re-simulate, and rank inputs by
their effect on electrical output, efficiency, operating cost and shaft
stress (a proxy for mechanical stress impact).
"""
from __future__ import annotations

from dataclasses import dataclass, replace

import pandas as pd

from core.configuration import PlantConfig
from core.engine import simulate
from core.state import ComponentHealth, DataProvenance, OperatingPoint
from economics.revenue import net_operating_margin_per_s

# (field name on OperatingPoint or ComponentHealth, perturbation, target object)
DEFAULT_PERTURBATIONS = [
    ("inlet_pressure_pa", +0.05, "operating_point"),
    ("inlet_temperature_k", +0.10, "operating_point"),
    ("steam_mass_flow_kg_s", +0.05, "operating_point"),
    ("shaft_rpm", +0.10, "operating_point"),
    ("condenser_pressure_pa", -0.10, "operating_point"),
    ("turbine_efficiency_factor", +0.05, "health"),
    ("gearbox_efficiency_factor", +0.05, "health"),
]

ROTOR_MASS_LABEL = "rotor_mass_kg (+10%, structural config)"


def run_sensitivity(
    config: PlantConfig,
    base_point: OperatingPoint,
    base_health: ComponentHealth | None = None,
    perturbations: list[tuple[str, float, str]] | None = None,
) -> pd.DataFrame:
    base_health = base_health or ComponentHealth()
    perturbations = perturbations or DEFAULT_PERTURBATIONS

    base_state = simulate(config, base_point, base_health, provenance=DataProvenance.SIMULATED)
    base_margin = net_operating_margin_per_s(base_state, config.economics, config.steam_supply)

    rows = []
    for field_name, pct, target in perturbations:
        op, health = base_point, base_health
        if target == "operating_point":
            current = getattr(base_point, field_name)
            op = replace(base_point, **{field_name: current * (1.0 + pct)})
        elif target == "health":
            current = getattr(base_health, field_name)
            health = replace(base_health, **{field_name: min(current * (1.0 + pct), 1.0) if pct > 0 and "factor" in field_name else current * (1.0 + pct)})
        else:
            raise ValueError(f"Unknown perturbation target: {target}")

        try:
            state = simulate(config, op, health, provenance=DataProvenance.SIMULATED)
            margin = net_operating_margin_per_s(state, config.economics, config.steam_supply)
            rows.append({
                "variable": field_name,
                "perturbation_pct": pct * 100,
                "delta_power_w": state.net_electrical_power_w - base_state.net_electrical_power_w,
                "delta_power_pct": _pct_change(base_state.net_electrical_power_w, state.net_electrical_power_w),
                "delta_efficiency_pct_pts": (state.overall_efficiency - base_state.overall_efficiency) * 100,
                "delta_margin_per_s": margin - base_margin,
                "delta_shaft_stress_pct": _pct_change(base_state.shaft_stress_pa, state.shaft_stress_pa),
                "feasible": state.is_feasible,
            })
        except Exception as exc:
            rows.append({"variable": field_name, "perturbation_pct": pct * 100, "error": str(exc), "feasible": False})

    # explicit rotor-mass architecture sensitivity (structural config, not
    # an operating-point variable - handled separately by rebuilding the
    # turbine config's rotor mass, section 8/18)
    heavier_config = config.model_copy(deep=True)
    heavier_config.turbine.rotor_mass_kg *= 1.10
    try:
        heavier_state = simulate(heavier_config, base_point, base_health, provenance=DataProvenance.SIMULATED)
        rows.append({
            "variable": ROTOR_MASS_LABEL,
            "perturbation_pct": 10.0,
            "delta_power_w": heavier_state.net_electrical_power_w - base_state.net_electrical_power_w,
            "delta_power_pct": _pct_change(base_state.net_electrical_power_w, heavier_state.net_electrical_power_w),
            "delta_efficiency_pct_pts": (heavier_state.overall_efficiency - base_state.overall_efficiency) * 100,
            "delta_margin_per_s": net_operating_margin_per_s(heavier_state, config.economics, config.steam_supply) - base_margin,
            "delta_shaft_stress_pct": _pct_change(base_state.shaft_stress_pa, heavier_state.shaft_stress_pa),
            "feasible": heavier_state.is_feasible,
        })
    except Exception as exc:
        rows.append({"variable": ROTOR_MASS_LABEL, "perturbation_pct": 10.0, "error": str(exc), "feasible": False})

    df = pd.DataFrame(rows)
    if "delta_power_pct" in df:
        df["rank_by_power_impact"] = df["delta_power_pct"].abs().rank(ascending=False, method="min")
        df = df.sort_values("rank_by_power_impact")
    return df


def _pct_change(base: float, new: float) -> float:
    if base == 0:
        return float("nan")
    return (new - base) / abs(base) * 100.0
