"""
optimisation/optimiser.py
============================
Central optimisation engine (section 16). Searches the steady-state
OPERATING POINT (steam conditions, condenser pressure, RPM, gear ratio,
cooling flow) that maximises a chosen objective (section 17), subject to
the full SafetyLimits envelope enforced via optimisation/constraints.py
and scored through optimisation/objectives.py.

Decision variables optimised here are the continuous *operating* choices
available on an already-built machine: inlet pressure/temperature, steam
mass flow, condenser pressure, shaft RPM, gear ratio, and cooling-water
flow. Discrete *architecture* choices (turbine stage count, rotor
diameter/mass, direct-drive vs geared) are design-time decisions explored
via parameter sweeps and the worked comparisons in examples/baseline_turbine.py,
rather than folded into one continuous search space.

Method: SciPy's `differential_evolution` (global, gradient-free, handles
the non-convex/non-smooth landscape created by hard constraint rejection)
for the global search, refined by a local `minimize` (Nelder-Mead, also
gradient-free since the pipeline is not differentiable end-to-end through
IAPWS-IF97) around the best global candidate.

A note on the default `maxiter`/`popsize`: each objective evaluation calls
IAPWS-IF97 dozens of times (~150-200 ms), so `differential_evolution`'s own
textbook defaults (maxiter=1000, popsize=15) would take the better part of
an hour per call. The defaults here are deliberately modest so that code
paths which call `optimise()` implicitly - e.g. `digital_twin/prediction.py`'s
recommendation flow - stay responsive; pass larger `maxiter`/`popsize`
explicitly (see `main.py --thorough`) for a publication-quality search.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
from scipy.optimize import OptimizeResult, differential_evolution, minimize

from core.configuration import PlantConfig
from core.engine import simulate
from core.state import ComponentHealth, DataProvenance, OperatingPoint, SystemState
from .objectives import ObjectiveMode, score

VAR_NAMES = [
    "inlet_pressure_pa",
    "inlet_temperature_k",
    "steam_mass_flow_kg_s",
    "condenser_pressure_pa",
    "shaft_rpm",
    "gear_ratio",
    "cooling_water_flow_kg_s",
]


@dataclass
class OptimisationResult:
    mode: ObjectiveMode
    best_operating_point: OperatingPoint
    best_state: SystemState
    best_score: float
    scipy_result: OptimizeResult
    history_best_scores: list = field(default_factory=list)


def default_bounds(config: PlantConfig) -> list[tuple[float, float]]:
    limits = config.limits
    supply = config.steam_supply
    condenser = config.condenser
    return [
        (limits.min_inlet_pressure_pa, min(limits.max_inlet_pressure_pa, supply.rated_pressure_pa)),
        (limits.min_inlet_temperature_k, min(limits.max_inlet_temperature_k, supply.rated_temperature_k)),
        (supply.min_mass_flow_kg_s, supply.max_mass_flow_kg_s),
        (limits.min_condenser_pressure_pa, limits.max_condenser_pressure_pa),
        (limits.min_rpm, limits.max_rpm),
        (limits.min_gear_ratio, limits.max_gear_ratio),
        (1.0, condenser.max_cooling_water_flow_kg_s),
    ]


def _vector_to_operating_point(x: np.ndarray, cooling_water_inlet_temp_k: float) -> OperatingPoint:
    return OperatingPoint(
        inlet_pressure_pa=float(x[0]),
        inlet_temperature_k=float(x[1]),
        steam_mass_flow_kg_s=float(x[2]),
        condenser_pressure_pa=float(x[3]),
        shaft_rpm=float(x[4]),
        gear_ratio=float(x[5]),
        cooling_water_flow_kg_s=float(x[6]),
        cooling_water_inlet_temp_k=cooling_water_inlet_temp_k,
    )


def optimise(
    config: PlantConfig,
    mode: ObjectiveMode = ObjectiveMode.MAX_NET_ENERGY,
    health: ComponentHealth | None = None,
    seed: int | None = None,
    maxiter: int = 10,
    popsize: int = 8,
    horizon_s: float = 3600.0,
) -> OptimisationResult:
    health = health or ComponentHealth()
    seed = config.economics.random_seed if seed is None else seed
    bounds = default_bounds(config)
    cw_temp = config.condenser.cooling_water_inlet_temp_k
    history: list[float] = []

    def negative_objective(x: np.ndarray) -> float:
        op = _vector_to_operating_point(x, cw_temp)
        try:
            state = simulate(config, op, health, provenance=DataProvenance.OPTIMISED)
        except Exception:
            return 1.0e12
        s = score(mode, state, config.economics, config.steam_supply, horizon_s)
        history.append(s)
        return -s

    de_result = differential_evolution(
        negative_objective,
        bounds,
        maxiter=maxiter,
        popsize=popsize,
        seed=seed,
        tol=1e-6,
        mutation=(0.4, 1.2),
        recombination=0.7,
        polish=False,
        updating="deferred",
    )

    # Local polish from the DE incumbent. Deliberately capped well below
    # SciPy's Nelder-Mead default budget (which for 7 dimensions runs into
    # the thousands of function evaluations) - each evaluation here costs
    # ~150-200 ms (IAPWS-IF97 property lookups dominate), and a short
    # local polish from an already-good global candidate converges fast.
    local_maxiter = max(30, 12 * len(bounds))
    local_result = minimize(
        negative_objective,
        de_result.x,
        method="Nelder-Mead",
        options={"xatol": 1e-3, "fatol": 1e-3, "maxiter": local_maxiter, "maxfev": local_maxiter},
    )

    best_x = local_result.x if local_result.fun <= de_result.fun else de_result.x
    best_op = _vector_to_operating_point(best_x, cw_temp)
    best_state = simulate(config, best_op, health, provenance=DataProvenance.OPTIMISED)
    best_score = score(mode, best_state, config.economics, config.steam_supply, horizon_s)

    if not best_state.is_feasible:
        best_state.notes.append(
            "OPTIMISER WARNING: best candidate found still violates constraints - "
            "REJECTED per safety policy. Returning it for diagnostic visibility only; "
            "do not act on this operating point."
        )

    return OptimisationResult(
        mode=mode,
        best_operating_point=best_op,
        best_state=best_state,
        best_score=best_score,
        scipy_result=de_result,
        history_best_scores=history,
    )
