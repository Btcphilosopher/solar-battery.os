"""
optimisation/parameter_sweep.py
==================================
1-D and 2-D parameter sweeps over an OperatingPoint field, returning a
tidy pandas.DataFrame - the backbone of the RPM sweep (section 7), the
steam-pressure sweep, the mass-flow sweep, and any Power-vs-X plot.
"""
from __future__ import annotations

import copy
from dataclasses import replace

import numpy as np
import pandas as pd

from core.configuration import PlantConfig
from core.engine import simulate
from core.state import ComponentHealth, DataProvenance, OperatingPoint


def sweep_1d(
    config: PlantConfig,
    base_point: OperatingPoint,
    field_name: str,
    values: np.ndarray,
    health: ComponentHealth | None = None,
) -> pd.DataFrame:
    health = health or ComponentHealth()
    rows = []
    for v in values:
        op = replace(base_point, **{field_name: float(v)})
        try:
            state = simulate(config, op, health, provenance=DataProvenance.SIMULATED)
            row = {
                field_name: v,
                "net_electrical_power_w": state.net_electrical_power_w,
                "overall_efficiency": state.overall_efficiency,
                "cycle_thermal_efficiency": state.cycle_thermal_efficiency,
                "shaft_torque_n_m": state.shaft_torque_n_m,
                "generator_rpm": state.generator_rpm,
                "mechanical_loss_w": state.mechanical_loss_w,
                "vibration_amplitude_m": state.vibration_amplitude_m,
                "critical_speed_margin_pct": state.critical_speed_margin_pct,
                "feasible": state.is_feasible,
                "violations": "; ".join(state.constraint_violations),
            }
        except Exception as exc:  # keep the sweep going even if one point fails
            row = {field_name: v, "net_electrical_power_w": np.nan, "error": str(exc), "feasible": False}
        rows.append(row)
    return pd.DataFrame(rows)


def sweep_2d(
    config: PlantConfig,
    base_point: OperatingPoint,
    field_x: str,
    values_x: np.ndarray,
    field_y: str,
    values_y: np.ndarray,
    health: ComponentHealth | None = None,
) -> pd.DataFrame:
    health = health or ComponentHealth()
    rows = []
    for vx in values_x:
        for vy in values_y:
            op = replace(base_point, **{field_x: float(vx), field_y: float(vy)})
            try:
                state = simulate(config, op, health, provenance=DataProvenance.SIMULATED)
                rows.append({
                    field_x: vx,
                    field_y: vy,
                    "net_electrical_power_w": state.net_electrical_power_w,
                    "overall_efficiency": state.overall_efficiency,
                    "feasible": state.is_feasible,
                })
            except Exception:
                rows.append({field_x: vx, field_y: vy, "net_electrical_power_w": np.nan, "feasible": False})
    return pd.DataFrame(rows)


def find_optimum_in_sweep(df: pd.DataFrame, value_col: str = "net_electrical_power_w") -> pd.Series:
    feasible = df[df.get("feasible", True) == True]  # noqa: E712
    pool = feasible if not feasible.empty else df
    return pool.loc[pool[value_col].idxmax()]
