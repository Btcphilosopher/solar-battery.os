"""
optimisation/objectives.py
=============================
The seven optimisation modes (section 17). Each objective is a function
``SystemState -> float`` where LARGER is better (the optimiser always
maximises; minimisation targets are negated internally so every mode
shares one convention).
"""
from __future__ import annotations

from enum import Enum

from core.configuration import EconomicConfig, SteamSupplyConfig
from core.state import SystemState
from economics.revenue import net_operating_margin_per_s


class ObjectiveMode(str, Enum):
    MAX_POWER = "MAX_POWER"
    MAX_EFFICIENCY = "MAX_EFFICIENCY"
    MIN_STEAM_CONSUMPTION = "MIN_STEAM_CONSUMPTION"
    MAX_NET_ENERGY = "MAX_NET_ENERGY"
    MIN_OPERATING_COST = "MIN_OPERATING_COST"
    MAX_ECONOMIC_RETURN = "MAX_ECONOMIC_RETURN"
    BALANCED_OPTIMUM = "BALANCED_OPTIMUM"


def specific_steam_consumption_kg_per_kwh(state: SystemState) -> float:
    """SSC: kg of steam per kWh electrical delivered - lower is better."""
    if state.net_electrical_power_w <= 0:
        return float("inf")
    kwh_per_s = state.net_electrical_power_w / 3.6e6
    return state.operating_point.steam_mass_flow_kg_s / kwh_per_s


def score(
    mode: ObjectiveMode,
    state: SystemState,
    economics: EconomicConfig,
    steam_supply: SteamSupplyConfig,
    horizon_s: float = 3600.0,
) -> float:
    if not state.is_feasible:
        # Heavily penalise infeasible points but keep the score finite and
        # ranked by how bad the state is, so gradient-free optimisers still
        # get useful search signal instead of a flat -inf plateau.
        penalty = -1.0e12 - 1.0e6 * len(state.constraint_violations)
        return penalty

    if mode == ObjectiveMode.MAX_POWER:
        return state.net_electrical_power_w

    if mode == ObjectiveMode.MAX_EFFICIENCY:
        return state.overall_efficiency

    if mode == ObjectiveMode.MIN_STEAM_CONSUMPTION:
        ssc = specific_steam_consumption_kg_per_kwh(state)
        return -ssc if ssc != float("inf") else -1e12

    if mode == ObjectiveMode.MAX_NET_ENERGY:
        return state.net_electrical_power_w * horizon_s  # J over the horizon

    if mode == ObjectiveMode.MIN_OPERATING_COST:
        margin = net_operating_margin_per_s(state, economics, steam_supply)
        # cost = revenue - margin; minimising cost == maximising -cost
        revenue_per_s = state.net_electrical_power_w * economics.electricity_price_per_wh / 3600.0
        cost_per_s = revenue_per_s - margin
        return -cost_per_s

    if mode == ObjectiveMode.MAX_ECONOMIC_RETURN:
        return net_operating_margin_per_s(state, economics, steam_supply)

    if mode == ObjectiveMode.BALANCED_OPTIMUM:
        # Weighted composite of normalised power, efficiency and economic
        # margin - weights are an explicit, documented engineering choice,
        # not a hidden default.
        power_term = state.net_electrical_power_w / 1e7  # normalise to ~O(1) for a ~10 MW-class unit
        efficiency_term = state.overall_efficiency
        margin_term = net_operating_margin_per_s(state, economics, steam_supply) / 100.0
        return 0.5 * power_term + 0.3 * efficiency_term + 0.2 * margin_term

    raise ValueError(f"Unknown objective mode: {mode}")
