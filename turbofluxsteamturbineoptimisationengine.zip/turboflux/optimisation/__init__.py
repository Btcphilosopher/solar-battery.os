"""Optimisation engine: objectives, constraints, sweeps, sensitivity, Pareto, Monte Carlo."""
