"""
optimisation/constraints.py
=============================
Section 27: every optimisation candidate is checked against the
configured SafetyLimits. A candidate that violates ANY of these is
REJECTED - never relaxed to "increase power".

``check_constraints`` returns a list of human-readable violation strings
(empty list == feasible). It is used both by core/engine.py (to stamp
every SystemState with its feasibility) and by optimisation/optimiser.py
(to penalise/reject candidates during search).
"""
from __future__ import annotations

from core.configuration import PlantConfig
from core.state import OperatingPoint, SystemState


def check_constraints(
    config: PlantConfig,
    operating_point: OperatingPoint,
    state: SystemState,
    exhaust_wetness_fraction: float,
    shaft_within_allowable: bool,
) -> list[str]:
    limits = config.limits
    v: list[str] = []

    if not (limits.min_rpm <= operating_point.shaft_rpm <= limits.max_rpm):
        v.append(f"RPM {operating_point.shaft_rpm:.0f} outside allowed range [{limits.min_rpm:.0f}, {limits.max_rpm:.0f}]")

    if state.critical_speed_margin_pct < limits.critical_speed_margin_pct:
        v.append(
            f"Critical speed margin {state.critical_speed_margin_pct:.1f}% below required "
            f"{limits.critical_speed_margin_pct:.1f}% (nearest critical {state.nearest_critical_speed_rpm:.0f} rpm)"
        )

    if state.vibration_amplitude_m > limits.max_vibration_amplitude_m:
        v.append(
            f"Vibration amplitude {state.vibration_amplitude_m*1e6:.1f} um exceeds limit "
            f"{limits.max_vibration_amplitude_m*1e6:.1f} um"
        )

    if not shaft_within_allowable or state.shaft_stress_pa > limits.max_shaft_stress_pa:
        v.append(
            f"Shaft shear stress {state.shaft_stress_pa/1e6:.1f} MPa exceeds allowable "
            f"{limits.max_shaft_stress_pa/1e6:.1f} MPa"
        )

    if not (limits.min_inlet_pressure_pa <= operating_point.inlet_pressure_pa <= limits.max_inlet_pressure_pa):
        v.append(
            f"Inlet pressure {operating_point.inlet_pressure_pa/1e6:.2f} MPa outside allowed range "
            f"[{limits.min_inlet_pressure_pa/1e6:.2f}, {limits.max_inlet_pressure_pa/1e6:.2f}] MPa"
        )

    if not (limits.min_inlet_temperature_k <= operating_point.inlet_temperature_k <= limits.max_inlet_temperature_k):
        v.append(
            f"Inlet temperature {operating_point.inlet_temperature_k:.1f} K outside allowed range "
            f"[{limits.min_inlet_temperature_k:.1f}, {limits.max_inlet_temperature_k:.1f}] K"
        )

    if exhaust_wetness_fraction > limits.max_exhaust_wetness_fraction:
        v.append(
            f"Exhaust wetness {exhaust_wetness_fraction*100:.1f}% exceeds erosion limit "
            f"{limits.max_exhaust_wetness_fraction*100:.1f}%"
        )

    # The physically meaningful figure is the ACHIEVED condenser pressure
    # (solved from the cooling-water heat balance and the value that
    # actually drove the turbine expansion), not the requested/initial-
    # guess value on the operating point - see core/engine.py.
    if not (limits.min_condenser_pressure_pa <= state.achieved_condenser_pressure_pa <= limits.max_condenser_pressure_pa):
        v.append(
            f"Achieved condenser pressure {state.achieved_condenser_pressure_pa:.0f} Pa outside allowed range "
            f"[{limits.min_condenser_pressure_pa:.0f}, {limits.max_condenser_pressure_pa:.0f}] Pa"
        )

    generator_load_fraction = state.net_electrical_power_w / config.generator.rated_electrical_power_w if config.generator.rated_electrical_power_w > 0 else 0.0
    if generator_load_fraction > limits.max_generator_load_fraction:
        v.append(
            f"Generator load fraction {generator_load_fraction:.3f} exceeds allowed overload "
            f"{limits.max_generator_load_fraction:.3f}"
        )

    if not (limits.min_gear_ratio <= operating_point.gear_ratio <= limits.max_gear_ratio):
        v.append(
            f"Gear ratio {operating_point.gear_ratio:.3f} outside allowed range "
            f"[{limits.min_gear_ratio:.3f}, {limits.max_gear_ratio:.3f}]"
        )

    if operating_point.steam_mass_flow_kg_s > config.steam_supply.max_mass_flow_kg_s:
        v.append(
            f"Steam mass flow {operating_point.steam_mass_flow_kg_s:.2f} kg/s exceeds boiler capacity "
            f"{config.steam_supply.max_mass_flow_kg_s:.2f} kg/s"
        )
    if operating_point.steam_mass_flow_kg_s < config.steam_supply.min_mass_flow_kg_s:
        v.append(
            f"Steam mass flow {operating_point.steam_mass_flow_kg_s:.2f} kg/s below minimum stable flow "
            f"{config.steam_supply.min_mass_flow_kg_s:.2f} kg/s"
        )

    if abs(state.energy_balance_residual_w) > max(1.0, 1e-3 * max(state.net_electrical_power_w, 1.0)):
        v.append(f"Energy balance residual {state.energy_balance_residual_w:.1f} W exceeds tolerance - result rejected as unphysical")

    return v
