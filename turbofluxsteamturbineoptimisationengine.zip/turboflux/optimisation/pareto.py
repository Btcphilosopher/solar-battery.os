"""
optimisation/pareto.py
=========================
Multi-objective Pareto-frontier analysis (sections 17/23): sample the
operating envelope, evaluate two or more competing objectives per sample
(e.g. net electrical power vs specific steam consumption, or power vs
economic margin), and extract the non-dominated set.

Uses Latin-hypercube-flavoured uniform random sampling (via NumPy's
Generator with a configurable seed - deterministic and reproducible) plus
a standard O(n^2) non-dominated sort, which is more than fast enough for
the sample sizes used in a reference build (hundreds to a few thousand
points).
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from core.configuration import PlantConfig
from core.engine import simulate
from core.state import ComponentHealth, DataProvenance, OperatingPoint
from economics.revenue import net_operating_margin_per_s
from .objectives import specific_steam_consumption_kg_per_kwh
from .optimiser import default_bounds


def sample_operating_points(config: PlantConfig, n_samples: int, seed: int) -> list[OperatingPoint]:
    rng = np.random.default_rng(seed)
    bounds = default_bounds(config)
    cw_temp = config.condenser.cooling_water_inlet_temp_k
    samples = rng.uniform(low=[b[0] for b in bounds], high=[b[1] for b in bounds], size=(n_samples, len(bounds)))
    points = []
    for row in samples:
        points.append(OperatingPoint(
            inlet_pressure_pa=row[0],
            inlet_temperature_k=row[1],
            steam_mass_flow_kg_s=row[2],
            condenser_pressure_pa=row[3],
            shaft_rpm=row[4],
            gear_ratio=row[5],
            cooling_water_flow_kg_s=row[6],
            cooling_water_inlet_temp_k=cw_temp,
        ))
    return points


def evaluate_objectives(
    config: PlantConfig, points: list[OperatingPoint], health: ComponentHealth | None = None
) -> pd.DataFrame:
    health = health or ComponentHealth()
    rows = []
    for op in points:
        try:
            state = simulate(config, op, health, provenance=DataProvenance.SIMULATED)
            rows.append({
                "net_electrical_power_w": state.net_electrical_power_w,
                "overall_efficiency": state.overall_efficiency,
                "specific_steam_consumption_kg_per_kwh": specific_steam_consumption_kg_per_kwh(state),
                "net_operating_margin_per_s": net_operating_margin_per_s(state, config.economics, config.steam_supply),
                "feasible": state.is_feasible,
                **op.as_dict(),
            })
        except Exception:
            continue
    return pd.DataFrame(rows)


def non_dominated_mask(df: pd.DataFrame, maximise_cols: list[str], minimise_cols: list[str]) -> np.ndarray:
    """Standard O(n^2) Pareto dominance filter. A point i is dominated if
    some point j is >= on every maximise column, <= on every minimise
    column, and strictly better on at least one."""
    values_max = df[maximise_cols].to_numpy()
    values_min = df[minimise_cols].to_numpy() if minimise_cols else np.empty((len(df), 0))
    n = len(df)
    dominated = np.zeros(n, dtype=bool)
    for i in range(n):
        if dominated[i]:
            continue
        for j in range(n):
            if i == j or dominated[i]:
                continue
            ge_max = np.all(values_max[j] >= values_max[i])
            le_min = np.all(values_min[j] <= values_min[i]) if values_min.shape[1] else True
            strictly_better = np.any(values_max[j] > values_max[i]) or (
                values_min.shape[1] and np.any(values_min[j] < values_min[i])
            )
            if ge_max and le_min and strictly_better:
                dominated[i] = True
                break
    return ~dominated


def pareto_frontier(
    config: PlantConfig,
    n_samples: int = 400,
    seed: int | None = None,
    maximise_cols: list[str] | None = None,
    minimise_cols: list[str] | None = None,
    health: ComponentHealth | None = None,
) -> pd.DataFrame:
    seed = config.economics.random_seed if seed is None else seed
    maximise_cols = maximise_cols or ["net_electrical_power_w", "overall_efficiency"]
    minimise_cols = minimise_cols or []

    points = sample_operating_points(config, n_samples, seed)
    df = evaluate_objectives(config, points, health)
    feasible_df = df[df["feasible"]].reset_index(drop=True)
    if feasible_df.empty:
        return feasible_df.assign(is_pareto_optimal=[])

    mask = non_dominated_mask(feasible_df, maximise_cols, minimise_cols)
    feasible_df["is_pareto_optimal"] = mask
    return feasible_df
