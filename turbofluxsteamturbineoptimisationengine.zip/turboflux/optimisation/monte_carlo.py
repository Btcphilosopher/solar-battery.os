"""
optimisation/monte_carlo.py
==============================
Uncertainty propagation: sample uncertain inputs (steam conditions,
component health/degradation) from configured distributions with a
deterministic seed, propagate through the full simulation, and summarise
the resulting distribution of net electrical power / efficiency.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from core.configuration import PlantConfig
from core.engine import simulate
from core.state import ComponentHealth, DataProvenance, OperatingPoint


@dataclass(frozen=True)
class UncertaintySpec:
    """Relative (fractional) standard deviation applied multiplicatively
    to each field, e.g. 0.02 = 2% 1-sigma noise."""

    inlet_pressure_rel_std: float = 0.01
    inlet_temperature_rel_std: float = 0.005
    steam_mass_flow_rel_std: float = 0.02
    turbine_efficiency_rel_std: float = 0.015
    bearing_friction_rel_std: float = 0.05


def run_monte_carlo(
    config: PlantConfig,
    base_point: OperatingPoint,
    n_trials: int = 500,
    seed: int | None = None,
    uncertainty: UncertaintySpec | None = None,
) -> pd.DataFrame:
    seed = config.economics.random_seed if seed is None else seed
    uncertainty = uncertainty or UncertaintySpec()
    rng = np.random.default_rng(seed)

    rows = []
    for _ in range(n_trials):
        p = base_point.inlet_pressure_pa * (1 + rng.normal(0, uncertainty.inlet_pressure_rel_std))
        t = base_point.inlet_temperature_k * (1 + rng.normal(0, uncertainty.inlet_temperature_rel_std))
        mdot = base_point.steam_mass_flow_kg_s * (1 + rng.normal(0, uncertainty.steam_mass_flow_rel_std))
        turb_eff_factor = max(0.5, 1 + rng.normal(0, uncertainty.turbine_efficiency_rel_std))
        bearing_factor = max(0.5, 1 + rng.normal(0, uncertainty.bearing_friction_rel_std))

        op = OperatingPoint(
            inlet_pressure_pa=max(p, 1e5),
            inlet_temperature_k=max(t, 373.15),
            steam_mass_flow_kg_s=max(mdot, 0.1),
            condenser_pressure_pa=base_point.condenser_pressure_pa,
            shaft_rpm=base_point.shaft_rpm,
            gear_ratio=base_point.gear_ratio,
            stage_pressure_ratios=base_point.stage_pressure_ratios,
            cooling_water_flow_kg_s=base_point.cooling_water_flow_kg_s,
            cooling_water_inlet_temp_k=base_point.cooling_water_inlet_temp_k,
        )
        health = ComponentHealth(turbine_efficiency_factor=turb_eff_factor, bearing_friction_factor=bearing_factor)

        try:
            state = simulate(config, op, health, provenance=DataProvenance.SIMULATED)
            rows.append({
                "net_electrical_power_w": state.net_electrical_power_w,
                "overall_efficiency": state.overall_efficiency,
                "feasible": state.is_feasible,
            })
        except Exception:
            rows.append({"net_electrical_power_w": np.nan, "overall_efficiency": np.nan, "feasible": False})

    return pd.DataFrame(rows)


def summarise(mc_df: pd.DataFrame) -> dict:
    feasible = mc_df[mc_df["feasible"]]
    power = feasible["net_electrical_power_w"].dropna()
    return {
        "n_trials": len(mc_df),
        "n_feasible": len(feasible),
        "feasibility_rate_pct": 100.0 * len(feasible) / len(mc_df) if len(mc_df) else 0.0,
        "power_mean_w": power.mean() if not power.empty else float("nan"),
        "power_std_w": power.std() if not power.empty else float("nan"),
        "power_p05_w": power.quantile(0.05) if not power.empty else float("nan"),
        "power_p50_w": power.quantile(0.50) if not power.empty else float("nan"),
        "power_p95_w": power.quantile(0.95) if not power.empty else float("nan"),
    }
