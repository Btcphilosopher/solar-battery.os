/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// --- DATA CONTRACT: SENSORS & TELEMETRY ---

export type SensorQuality = 'GOOD' | 'BAD' | 'SUSPECT' | 'DRIFT';

export interface TelemetryPacket {
  timestamp: string;      // ISO 8601 string
  asset_id: string;       // e.g., 'GEOTHERMAL_WELL_01', 'ORC_TURBINE_A'
  sensor_id: string;      // e.g., 'TEMP_PROD_WELL_01'
  measurement: string;    // 'temperature' | 'pressure' | 'flow' | 'power' | etc.
  value: number;
  unit: string;           // e.g., 'C', 'bar', 'm3/h', 'kW', 'RPM', etc.
  quality: SensorQuality;
  location: string;       // e.g., 'Data-Centre Site A', 'Geothermal Wellhead'
  source: string;         // 'RUST_INGEST_AGENT_V1.4'
  sequence_number: number;
}

// --- DATA VALIDATION ERROR SCHEMA ---

export interface ValidationError {
  error_type: 'MISSING_DATA' | 'DUPLICATE_DATA' | 'INVALID_TIMESTAMP' | 'SENSOR_DRIFT' | 'OUTLIER' | 'IMPOSSIBLE_VALUE' | 'UNIT_MISMATCH' | 'COMM_ERROR';
  sensor_id: string;
  timestamp: string;
  message: string;
  severity: 'WARNING' | 'CRITICAL';
  payload: any;
}

// --- THERMODYNAMIC STATE SCHEMA (Python Twin) ---

export type EnergyArchitecture = 'ORC' | 'STEAM' | 'HEAT_PUMP' | 'DIRECT_HEAT';

export interface ThermodynamicState {
  architecture: EnergyArchitecture;
  geothermalBrineTemp: number; // °C
  geothermalMassFlow: number;  // kg/s
  dcWasteHeatTemp: number;     // °C
  dcCoolingLoad: number;       // MW_thermal
  heatPumpCOP: number;         // Coefficient of Performance
  orcTurbineEfficiency: number;// decimal (e.g. 0.82)
  exchangerApproachTemp: number;// °C
  
  // Calculated outputs
  netPowerOutputMW: number;     // MW_electrical
  heatRecoveredMW: number;     // MW_thermal
  districtHeatDeliveryMW: number;// MW_thermal
  condenserHeatRejectionMW: number;// MW_thermal
  geothermalExergyEfficiency: number; // %
  carnotEfficiencyLimit: number; // %
  overallSystemEfficiency: number; // %
  
  // Calculation provenance
  model_version: string;       // e.g. 'PY_THERMO_TWIN_V2.1'
  calculation_timestamp: string;
}

// --- ECONOMIC SCENARIO SCHEMA (R Economics) ---

export type PriceScenarioName = 'BASE_CASE' | 'HIGH_GROWTH' | 'LOW_GROWTH' | 'HIGH_PRICE' | 'LOW_PRICE' | 'VOLATILE_PRICE' | 'NEGATIVE_PRICE';

export interface EconomicIndicators {
  capexMillionUSD: number;
  opexMillionUSD: number;
  annualRevenueMillionUSD: number;
  annualOperatingCostMillionUSD: number;
  netNPVMillionUSD: number;
  irrPercent: number;
  paybackPeriodYears: number;
  carbonCreditsEarnedUSD: number;
  lcoe_usd_mwh: number;        // Levelized Cost of Electricity
  lcoh_usd_mwh: number;        // Levelized Cost of Heat
  calculated_by: string;       // 'R_ECON_ENGINE_V3.0'
}

export interface Scenario {
  id: string;
  name: string;
  description: string;
  architecture: EnergyArchitecture;
  priceScenario: PriceScenarioName;
  dcLoadMW: number;
  geothermalResourceMW: number;
  parameters: {
    electricityPriceBase: number; // USD/MWh
    heatPriceBase: number;        // USD/MWh
    carbonTaxRate: number;        // USD/tonne CO2
    capitalCostFactor: number;    // Multiplier
  };
  economics: EconomicIndicators;
  riskScore: number;            // 0-100 scale
}

// --- MONTE CARLO RESULTS ---

export interface PercentileResult {
  percentile: string; // 'P5' | 'P10' | 'P25' | 'P50' | 'P75' | 'P90' | 'P95'
  npvMillionUSD: number;
  irrPercent: number;
  paybackYears: number;
}

export interface MonteCarloSimulation {
  trialsRun: number;
  timestamp: string;
  percentiles: PercentileResult[];
  historgramData: { npvBin: number; frequency: number }[];
  parameterSensitivities: { parameter: string; sensitivityIndex: number }[]; // correlation
}

// --- LINEAGE PROVENANCE TRACKER ---

export interface ProvenanceNode {
  metric_name: string;
  raw_value: number;
  unit: string;
  source_sensors: string[];
  calculation_version: string;
  timestamp: string;
  model_version: string;
  mathematical_formula: string;
  input_datasets: string[];
}

// --- AUDIT LOGGER ---

export interface AuditLogEntry {
  timestamp: string;
  operator: string;
  role: 'OPERATOR_READ' | 'OPERATOR_CONTROL' | 'SYSTEM_PROCESS';
  action: string;
  details: string;
  integrity_hash: string;
}
