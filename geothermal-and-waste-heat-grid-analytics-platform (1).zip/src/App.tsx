/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import TelemetryView from './components/TelemetryView';
import ThermoTwinView from './components/ThermoTwinView';
import EconomicsView from './components/EconomicsView';
import LineageExplorer from './components/LineageExplorer';
import AiCopilotView from './components/AiCopilotView';
import { TelemetryPacket, ValidationError, Scenario, ThermodynamicState, PercentileResult } from './types';
import { Activity, ShieldCheck, Database, FileSpreadsheet, Lock } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('telemetry');
  const [securityRole, setSecurityRole] = useState<'OPERATOR_READ' | 'OPERATOR_CONTROL'>('OPERATOR_READ');
  
  // Real-time Ingestion State
  const [telemetry, setTelemetry] = useState<TelemetryPacket[]>([]);
  const [validationErrors, setValidationErrors] = useState<ValidationError[]>([]);
  const [latestSequence, setLatestSequence] = useState<number>(1000);
  const [telemetryOnline, setTelemetryOnline] = useState<boolean>(true);

  // Scenario & Economic State
  const [scenarios, setScenarios] = useState<Scenario[]>([]);
  const [selectedScenario, setSelectedScenario] = useState<Scenario | null>(null);
  const [mcPercentiles, setMcPercentiles] = useState<PercentileResult[] | null>(null);

  // Physical State (from Twin)
  const [thermoState, setThermoState] = useState<ThermodynamicState | null>(null);

  // Lineage focus state
  const [lineageFocusMetric, setLineageFocusMetric] = useState<string>('NET_POWER_GENERATED');

  // 1. Poll Live Telemetry (Ingestion Layer)
  useEffect(() => {
    const fetchTelemetry = async () => {
      try {
        const response = await fetch('/api/telemetry/live');
        const data = await response.json();
        setTelemetry(data.telemetry);
        // Append any new validation warnings, capped at latest 30 logs for UI viewability
        if (data.validation_errors && data.validation_errors.length > 0) {
          setValidationErrors(prev => {
            const combined = [...data.validation_errors, ...prev];
            return combined.slice(0, 30);
          });
        }
        // Track the highest sequence
        const maxSeq = Math.max(...data.telemetry.map((p: TelemetryPacket) => p.sequence_number), latestSequence);
        setLatestSequence(maxSeq);
        setTelemetryOnline(true);
      } catch (err) {
        console.error('Failed to poll telemetry pipeline:', err);
        setTelemetryOnline(false);
      }
    };

    // Run immediately and then poll every 4 seconds
    fetchTelemetry();
    const interval = setInterval(fetchTelemetry, 4000);
    return () => clearInterval(interval);
  }, [latestSequence]);

  // 2. Load Scenarios on mount
  useEffect(() => {
    const fetchScenarios = async () => {
      try {
        const response = await fetch('/api/scenarios');
        const data = await response.json();
        setScenarios(data);
        if (data.length > 0 && !selectedScenario) {
          setSelectedScenario(data[0]);
        }
      } catch (err) {
        console.error('Failed to retrieve scenarios:', err);
      }
    };
    fetchScenarios();
  }, []);

  // Sync state computed from thermodynamic twin back into active scenario structure
  const handleThermodynamicUpdate = (state: ThermodynamicState) => {
    setThermoState(state);
    if (selectedScenario) {
      // Re-run scenario economic assessment based on the newly calculated physical twin variables
      const recomputeEcon = async () => {
        try {
          const response = await fetch('/api/python/thermodynamics', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              architecture: state.architecture,
              geothermalBrineTemp: state.geothermalBrineTemp,
              geothermalMassFlow: state.geothermalMassFlow,
              dcWasteHeatTemp: 60,
              dcCoolingLoad: state.dcCoolingLoad,
              efficiencyMultiplier: state.orcTurbineEfficiency / 0.85 // normalized
            })
          });
          const phyData = await response.json();
          
          // Compute R economics
          const responseEcon = await fetch('/api/r/monte-carlo', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              architecture: phyData.architecture,
              priceScenario: selectedScenario.priceScenario,
              dcLoadMW: phyData.dcCoolingLoad,
              geothermalResourceMW: phyData.geothermalBrineTemp,
              parameters: selectedScenario.parameters,
              trials: 100 // rapid run for base numbers
            })
          });
          const econData = await responseEcon.json();
          const basePercentiles = econData.percentiles;
          const medianP50 = basePercentiles.find((p: any) => p.percentile === 'P50');
          
          setSelectedScenario(prev => {
            if (!prev) return null;
            return {
              ...prev,
              architecture: phyData.architecture,
              economics: {
                ...prev.economics,
                netNPVMillionUSD: medianP50 ? medianP50.npvMillionUSD : prev.economics.netNPVMillionUSD,
                irrPercent: medianP50 ? medianP50.irrPercent : prev.economics.irrPercent,
                paybackPeriodYears: medianP50 ? medianP50.paybackYears : prev.economics.paybackPeriodYears
              }
            };
          });
        } catch (err) {
          console.error('Economic recalibration failed:', err);
        }
      };
      recomputeEcon();
    }
  };

  // Click handler to trace lineage
  const handleInspectLineage = (metric: string) => {
    setLineageFocusMetric(metric);
    setActiveTab('lineage');
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-gray-200 flex flex-col justify-between" id="app-viewport">
      
      {/* Platform Industrial Header */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        securityRole={securityRole}
        setSecurityRole={setSecurityRole}
        telemetryOnline={telemetryOnline}
        latestSequence={latestSequence}
      />

      {/* Main Operating Workspace */}
      <main className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8" id="operating-workspace">
        {activeTab === 'telemetry' && (
          <TelemetryView
            telemetry={telemetry}
            validationErrors={validationErrors}
            securityRole={securityRole}
            onInspectLineage={handleInspectLineage}
          />
        )}

        {activeTab === 'thermotwin' && (
          <ThermoTwinView
            onStateUpdate={handleThermodynamicUpdate}
            securityRole={securityRole}
          />
        )}

        {activeTab === 'economics' && selectedScenario && (
          <EconomicsView
            scenarios={scenarios}
            selectedScenario={selectedScenario}
            onSelectScenario={setSelectedScenario}
            onRunMonteCarloComplete={setMcPercentiles}
            securityRole={securityRole}
          />
        )}

        {activeTab === 'lineage' && (
          <LineageExplorer
            initialMetric={lineageFocusMetric}
          />
        )}

        {activeTab === 'copilot' && selectedScenario && (
          <AiCopilotView
            thermoState={thermoState}
            selectedScenario={selectedScenario}
            mcPercentiles={mcPercentiles}
          />
        )}
      </main>

      {/* Industrial Status Footer */}
      <footer className="bg-[#111111] border-t border-white/10 py-4 px-8 text-center text-xs text-gray-400 font-sans flex justify-between items-center" id="app-footer">
        <div className="flex items-center space-x-2">
          <Database className="h-4 w-4 text-teal-400" />
          <span className="font-mono">LEDGER STATUS: PRIMARY AUTHORITY SYNCHRONIZED</span>
        </div>
        <div className="flex items-center space-x-1.5 text-[11px]">
          <ShieldCheck className="h-4 w-4 text-teal-400" />
          <span>Role-Based Firewall Enforcement: Active</span>
        </div>
        <div className="font-mono text-[10px] text-gray-500">
          Platform build v3.0.4 • Antigravity Certified
        </div>
      </footer>

    </div>
  );
}
