/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ThermodynamicState, EnergyArchitecture } from '../types';
import { HelpCircle, RefreshCw, Layers, Sliders, Shield, Zap, Flame, Award, HelpCircle as HelpIcon } from 'lucide-react';

interface ThermoTwinViewProps {
  onStateUpdate: (state: ThermodynamicState) => void;
  securityRole: 'OPERATOR_READ' | 'OPERATOR_CONTROL';
}

export default function ThermoTwinView({
  onStateUpdate,
  securityRole
}: ThermoTwinViewProps) {
  const [architecture, setArchitecture] = useState<EnergyArchitecture>('ORC');
  const [wellTemp, setWellTemp] = useState<number>(130);
  const [wellFlow, setWellFlow] = useState<number>(140);
  const [dcCoolingLoad, setDcCoolingLoad] = useState<number>(12);
  const [efficiencyMultiplier, setEfficiencyMultiplier] = useState<number>(1.0);
  
  const [loading, setLoading] = useState<boolean>(false);
  const [thermoState, setThermoState] = useState<ThermodynamicState | null>(null);

  // Trigger calculation
  const calculateState = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/python/thermodynamics', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          architecture,
          geothermalBrineTemp: wellTemp,
          geothermalMassFlow: wellFlow,
          dcWasteHeatTemp: 60,
          dcCoolingLoad,
          efficiencyMultiplier
        })
      });
      const data = await response.json();
      setThermoState(data);
      onStateUpdate(data);
    } catch (err) {
      console.error('Failed to run thermodynamics:', err);
    } finally {
      setLoading(false);
    }
  };

  // Run on mount or option change
  useEffect(() => {
    calculateState();
  }, [architecture, wellTemp, wellFlow, dcCoolingLoad, efficiencyMultiplier]);

  const archSpecs = {
    ORC: {
      label: 'Organic Rankine Cycle (ORC)',
      desc: 'Optimized for low-to-medium geothermal temperatures. Uses an organic working fluid with high vapor pressure. Incorporates server waste heat for fluid preheating, boosting net mechanical turbine efficiency.',
      tempWarning: wellTemp < 95 ? 'Performance severely restricted below 95°C' : null
    },
    STEAM: {
      label: 'Steam Flash Turbine',
      desc: 'High-temperature cycle. Flashes high-pressure geothermal brine to steam, driving direct turbines. Requires brine temperature >130°C to operate efficiently; performance collapses at lower temperatures.',
      tempWarning: wellTemp < 130 ? 'CRITICAL: Brine temperature too low for steam flash. Turbine will choke/damage!' : null
    },
    HEAT_PUMP: {
      label: 'Industrial Heat Pump Booster',
      desc: 'Consumes electrical power to run massive industrial scroll compressors, upgrading low-grade data centre waste heat (60°C) and geothermal brine into high-temperature (85°C+) metropolitan district heating.',
      tempWarning: null
    },
    DIRECT_HEAT: {
      label: 'Direct Contact Exchanger Grid',
      desc: 'No electrical turbine step. Brine and server coolant loops exchange directly with the metropolitan heating main through high-efficiency plates. Excellent thermal efficiency, zero electrical output.',
      tempWarning: null
    }
  };

  return (
    <div className="space-y-6" id="thermotwin-view-root">
      {/* Intro section */}
      <div className="bg-[#111111] border border-white/10 rounded-xl p-6 shadow-sm">
        <span className="text-[10px] font-bold uppercase tracking-widest text-teal-400 font-mono">Thermodynamic Simulation Layer</span>
        <h2 className="text-xl font-bold text-white sm:text-2xl mt-1">Python Thermodynamic Digital Twin</h2>
        <p className="mt-2 text-sm text-gray-400 font-sans">
          The digital twin replicates physical plant fluid dynamics, mass flows, exergy states, and heat balances based on steady-state chemical engineering models. Adjust live system configurations below to find operational optimization regimes.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Controls Column */}
        <div className="bg-[#0f0f0f] border border-white/10 rounded-xl p-6 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center space-x-2 border-b border-white/5 pb-3 mb-4">
              <Sliders className="h-4.5 w-4.5 text-teal-400" />
              <h3 className="text-sm font-bold text-gray-200 uppercase tracking-wider font-mono">Process Variables</h3>
            </div>

            {/* Architecture Selector */}
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-gray-400 mb-1.5 font-mono">Energy System Architecture</label>
                <div className="grid grid-cols-2 gap-2" id="architecture-buttons">
                  {(['ORC', 'STEAM', 'HEAT_PUMP', 'DIRECT_HEAT'] as EnergyArchitecture[]).map((arch) => (
                    <button
                      key={arch}
                      id={`btn-arch-${arch}`}
                      disabled={securityRole === 'OPERATOR_READ' && architecture !== arch}
                      onClick={() => setArchitecture(arch)}
                      className={`px-3 py-2 rounded text-xs font-bold border transition-colors ${
                        architecture === arch
                          ? 'bg-teal-500 text-black border-teal-500'
                          : securityRole === 'OPERATOR_READ'
                            ? 'bg-white/5 text-gray-500 border-white/5 cursor-not-allowed'
                            : 'bg-white/5 text-gray-300 border-white/10 hover:bg-white/10'
                      }`}
                    >
                      {arch}
                    </button>
                  ))}
                </div>
                {securityRole === 'OPERATOR_READ' && (
                  <p className="text-[9px] text-gray-500 font-mono mt-1">Control clearance needed to change loops.</p>
                )}
              </div>

              {/* Slider: Geothermal Temp */}
              <div>
                <div className="flex justify-between text-xs font-medium mb-1">
                  <span className="text-gray-300">Geothermal Brine Temp</span>
                  <span className="font-mono font-bold text-white">{wellTemp} °C</span>
                </div>
                <input
                  type="range"
                  min="80"
                  max="180"
                  id="well-temp-slider"
                  value={wellTemp}
                  disabled={securityRole === 'OPERATOR_READ'}
                  onChange={(e) => setWellTemp(Number(e.target.value))}
                  className="w-full h-1.5 bg-white/10 rounded appearance-none cursor-pointer accent-teal-500 disabled:opacity-50"
                />
                <div className="flex justify-between text-[10px] text-gray-500 mt-0.5">
                  <span>80°C (Low)</span>
                  <span>180°C (High)</span>
                </div>
              </div>

              {/* Slider: Geothermal flow */}
              <div>
                <div className="flex justify-between text-xs font-medium mb-1">
                  <span className="text-gray-300">Geothermal mass flow</span>
                  <span className="font-mono font-bold text-white">{wellFlow} kg/s</span>
                </div>
                <input
                  type="range"
                  min="50"
                  max="300"
                  id="well-flow-slider"
                  value={wellFlow}
                  disabled={securityRole === 'OPERATOR_READ'}
                  onChange={(e) => setWellFlow(Number(e.target.value))}
                  className="w-full h-1.5 bg-white/10 rounded appearance-none cursor-pointer accent-teal-500 disabled:opacity-50"
                />
                <div className="flex justify-between text-[10px] text-gray-500 mt-0.5">
                  <span>50 kg/s</span>
                  <span>300 kg/s</span>
                </div>
              </div>

              {/* Slider: Compute cooling load */}
              <div>
                <div className="flex justify-between text-xs font-medium mb-1">
                  <span className="text-gray-300">Data Centre Compute Load</span>
                  <span className="font-mono font-bold text-white">{dcCoolingLoad} MWth</span>
                </div>
                <input
                  type="range"
                  min="5"
                  max="45"
                  id="dc-cooling-slider"
                  value={dcCoolingLoad}
                  disabled={securityRole === 'OPERATOR_READ'}
                  onChange={(e) => setDcCoolingLoad(Number(e.target.value))}
                  className="w-full h-1.5 bg-white/10 rounded appearance-none cursor-pointer accent-teal-500 disabled:opacity-50"
                />
                <div className="flex justify-between text-[10px] text-gray-500 mt-0.5">
                  <span>5 MW</span>
                  <span>45 MW</span>
                </div>
              </div>

              {/* Turbine / Compressor Efficiency Modifier */}
              <div>
                <div className="flex justify-between text-xs font-medium mb-1">
                  <span className="text-gray-300">Equipment Efficiency Coefficient</span>
                  <span className="font-mono font-bold text-white">{(efficiencyMultiplier * 100).toFixed(0)} %</span>
                </div>
                <input
                  type="range"
                  min="0.80"
                  max="1.20"
                  step="0.05"
                  id="efficiency-slider"
                  value={efficiencyMultiplier}
                  disabled={securityRole === 'OPERATOR_READ'}
                  onChange={(e) => setEfficiencyMultiplier(Number(e.target.value))}
                  className="w-full h-1.5 bg-white/10 rounded appearance-none cursor-pointer accent-teal-500 disabled:opacity-50"
                />
                <div className="flex justify-between text-[10px] text-gray-500 mt-0.5">
                  <span>80% (Fouled)</span>
                  <span>120% (Ideal)</span>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-white/5 text-xs text-gray-400 flex items-center justify-between">
            <span className="flex items-center"><Layers className="h-3.5 w-3.5 text-teal-500/50 mr-1" /> Core Version 2.1</span>
            {loading && <span className="text-teal-400 animate-spin"><RefreshCw className="h-4 w-4" /></span>}
          </div>
        </div>

        {/* Dashboard Results column */}
        <div className="lg:col-span-2 space-y-6">
          {/* Active architecture technical briefing */}
          <div className="bg-[#111111] border border-white/10 rounded-xl p-5 shadow-sm text-left">
            <h4 className="text-xs font-bold text-gray-200 uppercase tracking-wider font-mono">System Configuration Briefing</h4>
            <h5 className="text-sm font-bold text-teal-400 mt-1">{archSpecs[architecture].label}</h5>
            <p className="text-xs text-gray-300 mt-2 leading-relaxed">{archSpecs[architecture].desc}</p>
            {archSpecs[architecture].tempWarning && (
              <div className="mt-3 bg-rose-950/30 border border-rose-500/20 text-rose-400 px-3 py-2 rounded text-xs font-mono font-bold flex items-center">
                <Shield className="h-4 w-4 text-rose-500 mr-1.5 flex-shrink-0" />
                {archSpecs[architecture].tempWarning}
              </div>
            )}
          </div>

          {thermoState ? (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6" id="thermo-results-cards">
              
              {/* Card 1: Net Power */}
              <div className="bg-[#0f0f0f] border border-white/10 rounded-xl p-5 shadow-sm relative overflow-hidden flex flex-col justify-between h-[150px]">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-gray-400 block font-mono">Net Power Generated</span>
                  <span className="text-2xl font-bold text-white mt-2 block font-mono">
                    {thermoState.netPowerOutputMW} <span className="text-xs font-normal text-teal-400">MWe</span>
                  </span>
                </div>
                <div className="text-[11px] text-gray-400 flex items-center mt-3 pt-3 border-t border-white/5 font-mono">
                  <Zap className="h-3.5 w-3.5 text-teal-400 mr-1" />
                  {thermoState.netPowerOutputMW < 0 ? 'Consuming from Grid' : 'Feeding Grid'}
                </div>
              </div>

              {/* Card 2: District Heat */}
              <div className="bg-[#0f0f0f] border border-white/10 rounded-xl p-5 shadow-sm relative overflow-hidden flex flex-col justify-between h-[150px]">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-gray-400 block font-mono">District Heating Output</span>
                  <span className="text-2xl font-bold text-white mt-2 block font-mono">
                    {thermoState.districtHeatDeliveryMW} <span className="text-xs font-normal text-teal-400">MWth</span>
                  </span>
                </div>
                <div className="text-[11px] text-gray-400 flex items-center mt-3 pt-3 border-t border-white/5 font-mono">
                  <Flame className="h-3.5 w-3.5 text-teal-400 mr-1" />
                  Grid delivery capacity
                </div>
              </div>

              {/* Card 3: Exergy Efficiency */}
              <div className="bg-[#0f0f0f] border border-white/10 rounded-xl p-5 shadow-sm relative overflow-hidden flex flex-col justify-between h-[150px]">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-gray-400 block font-mono">Geothermal Exergy Efficiency</span>
                  <span className="text-2xl font-bold text-white mt-2 block font-mono">
                    {thermoState.geothermalExergyEfficiency} <span className="text-xs font-normal text-teal-400">%</span>
                  </span>
                </div>
                <div className="text-[11px] text-gray-400 flex items-center mt-3 pt-3 border-t border-white/5 font-mono">
                  <Award className="h-3.5 w-3.5 text-teal-400 mr-1" />
                  Carnot limit: {thermoState.carnotEfficiencyLimit}%
                </div>
              </div>

              {/* Additional thermodynamic breakdown panel */}
              <div className="sm:col-span-3 bg-[#0f0f0f] border border-white/10 rounded-xl p-6 shadow-sm">
                <h4 className="text-xs font-bold text-teal-400 uppercase tracking-wider mb-4 font-mono">Thermodynamic Steady-State Heat Balance</h4>
                
                <div className="space-y-4 font-mono text-xs">
                  {/* Row 1 */}
                  <div className="flex justify-between items-center py-2 border-b border-white/5">
                    <span className="text-gray-400">Calculated Carnot Efficiency Limit:</span>
                    <span className="font-bold text-white">{thermoState.carnotEfficiencyLimit} %</span>
                  </div>
                  {/* Row 2 */}
                  <div className="flex justify-between items-center py-2 border-b border-white/5">
                    <span className="text-gray-400">Data Centre Heat Recovered (Exchanger load):</span>
                    <span className="font-bold text-white">{thermoState.heatRecoveredMW} MW_thermal</span>
                  </div>
                  {/* Row 3 */}
                  <div className="flex justify-between items-center py-2 border-b border-white/5">
                    <span className="text-gray-400">Condenser Heat Rejection (Heat sink load):</span>
                    <span className="font-bold text-white">{thermoState.condenserHeatRejectionMW} MW_thermal</span>
                  </div>
                  {/* Row 4 */}
                  <div className="flex justify-between items-center py-2 border-b border-white/5">
                    <span className="text-gray-400">Overall Plant First-Law Efficiency:</span>
                    <span className="font-bold text-teal-400">{thermoState.overallSystemEfficiency} %</span>
                  </div>
                  {/* Provenance Row */}
                  <div className="flex justify-between items-center py-2 text-[10px] text-gray-500">
                    <span>Calculation Engine: {thermoState.model_version}</span>
                    <span>TS: {thermoState.calculation_timestamp.substring(11, 19)} UTC</span>
                  </div>
                </div>

              </div>

            </div>
          ) : (
            <div className="h-64 bg-white/5 border border-dashed border-white/10 rounded-xl flex items-center justify-center">
              <span className="text-gray-400 font-mono text-xs">No active thermodynamic model simulation. Adjust variables to run.</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
