/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import Markdown from 'react-markdown';
import { ThermodynamicState, Scenario, PercentileResult } from '../types';
import { Brain, FileText, Send, Sparkles, RefreshCw, MessageSquare, ShieldAlert, Cpu } from 'lucide-react';

interface AiCopilotViewProps {
  thermoState: ThermodynamicState | null;
  selectedScenario: Scenario;
  mcPercentiles: PercentileResult[] | null;
}

export default function AiCopilotView({
  thermoState,
  selectedScenario,
  mcPercentiles
}: AiCopilotViewProps) {
  const [loadingBrief, setLoadingBrief] = useState<boolean>(false);
  const [brief, setBrief] = useState<string>('');
  
  const [loadingReport, setLoadingReport] = useState<boolean>(false);
  const [report, setReport] = useState<string>('');
  
  const [chatInput, setChatInput] = useState<string>('');
  const [chatHistory, setChatHistory] = useState<{ role: 'operator' | 'copilot'; text: string }[]>([]);
  const [loadingChat, setLoadingChat] = useState<boolean>(false);

  // Generate initial operational dispatch brief
  const generateBrief = async () => {
    if (!thermoState) return;
    setLoadingBrief(true);
    try {
      const response = await fetch('/api/copilot/recommend', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          thermodynamicState: thermoState,
          economics: selectedScenario.economics,
          priceScenario: selectedScenario.priceScenario
        })
      });
      const data = await response.json();
      setBrief(data.recommendation);
    } catch (err) {
      console.error('Failed to compile co-pilot recommendation:', err);
    } finally {
      setLoadingBrief(false);
    }
  };

  // Compile Executive Technical Feasibility Report
  const compileReport = async () => {
    setLoadingReport(true);
    try {
      const response = await fetch('/api/copilot/report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          scenario: selectedScenario,
          mcPercentiles: mcPercentiles
        })
      });
      const data = await response.json();
      setReport(data.report);
    } catch (err) {
      console.error('Failed to generate audit report:', err);
    } finally {
      setLoadingReport(false);
    }
  };

  // Trigger brief generation on tab load/state change
  useEffect(() => {
    if (thermoState) {
      generateBrief();
    }
  }, [selectedScenario, thermoState]);

  // Handle custom operator chat consult
  const sendOperatorMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || loadingChat || !thermoState) return;
    
    const userMsg = chatInput;
    setChatInput('');
    setChatHistory(prev => [...prev, { role: 'operator', text: userMsg }]);
    setLoadingChat(true);

    try {
      // Build context for Gemini question answering
      const contextPrompt = `
You are the AI Energy Grid Optimization Co-Pilot.
The operator is asking a technical thermodynamic or economic engineering question.
Refer to this active system configuration:
- Active Case: ${selectedScenario.name}
- System Architecture: ${thermoState.architecture}
- Geothermal Temperature: ${thermoState.geothermalBrineTemp}°C
- Net Power Generation: ${thermoState.netPowerOutputMW} MWe
- District Heat Output: ${thermoState.districtHeatDeliveryMW} MWth
- First-Law efficiency: ${thermoState.overallSystemEfficiency}%
- Exergy efficiency: ${thermoState.geothermalExergyEfficiency}%
- Base case project NPV: $${selectedScenario.economics.netNPVMillionUSD}M

Operator Question: "${userMsg}"

Provide a professional, direct, mathematically sound engineering answer in 1-2 paragraphs. Keep formulas explicit and maintain high technical accuracy.
`;

      const response = await fetch('/api/copilot/recommend', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          thermodynamicState: thermoState,
          economics: selectedScenario.economics,
          priceScenario: selectedScenario.priceScenario,
          prompt: contextPrompt // Passing the specialized chat context inside payload
        })
      });
      const data = await response.json();
      setChatHistory(prev => [...prev, { role: 'copilot', text: data.recommendation }]);
    } catch (err) {
      console.error('Co-pilot consultation failed:', err);
      setChatHistory(prev => [...prev, { role: 'copilot', text: 'Error compiling consultation: pipeline connection timed out.' }]);
    } finally {
      setLoadingChat(false);
    }
  };

  return (
    <div className="space-y-6" id="ai-copilot-root">
      {/* Platform Title Intro */}
      <div className="bg-[#111111] border border-white/10 rounded-xl p-6 shadow-sm">
        <span className="text-[10px] font-bold uppercase tracking-widest text-teal-400 font-mono">Decision Support Layer</span>
        <h2 className="text-xl font-bold text-white sm:text-2xl mt-1">AI Optimization & Decision Co-Pilot</h2>
        <p className="mt-2 text-sm text-gray-400">
          Powered by Gemini 3.7. Analyzes live R economic risk indicators and Python steady-state thermodynamic exergy values to recommend grid dispatch parameters and generate comprehensive, audit-grade technical feasibility reports.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column: Brief & Chat */}
        <div className="lg:col-span-2 space-y-6">
          {/* Dispatch brief container */}
          <div className="bg-[#0f0f0f] border border-white/10 rounded-xl p-6 shadow-sm flex flex-col justify-between min-h-[380px]">
            <div>
              <div className="flex justify-between items-center border-b border-white/5 pb-3 mb-4">
                <h3 className="text-sm font-bold text-gray-200 uppercase tracking-wider flex items-center font-mono">
                  <Sparkles className="h-4.5 w-4.5 text-teal-400 mr-2" />
                  Grid Dispatch Operational Brief
                </h3>
                <button 
                  id="btn-regenerate-brief"
                  onClick={generateBrief}
                  disabled={loadingBrief || !thermoState}
                  className="text-xs font-mono text-teal-400 hover:text-teal-300 flex items-center space-x-1 bg-white/5 border border-white/10 rounded px-2.5 py-1 transition-colors"
                >
                  <RefreshCw className={`h-3.5 w-3.5 ${loadingBrief ? 'animate-spin' : ''}`} />
                  <span>Update Brief</span>
                </button>
              </div>

              {loadingBrief ? (
                <div className="py-24 text-center text-gray-500 space-y-3 font-mono">
                  <RefreshCw className="h-8 w-8 animate-spin mx-auto text-teal-400" />
                  <p className="text-xs">Querying Gemini 3.7 Optimization Engine...</p>
                </div>
              ) : brief ? (
                <div className="prose prose-sm max-w-none text-gray-300 text-xs leading-relaxed text-left space-y-4">
                  <div className="markdown-body font-sans">
                    <Markdown>{brief}</Markdown>
                  </div>
                </div>
              ) : (
                <div className="py-24 text-center text-gray-500 font-mono">
                  <Cpu className="h-8 w-8 mx-auto text-gray-600 mb-2" />
                  <p className="text-xs">Select a scenario to trigger technical grid-dispatch evaluation.</p>
                </div>
              )}
            </div>

            <div className="border-t border-white/5 pt-3 mt-4 text-[10px] text-gray-500 font-mono">
              COMPILER ASSIGNMENT: GEMINI-3.7-FLASH • TEMPERATURE 0.25 • EXERGY BALANCED
            </div>
          </div>

          {/* Operator chat console */}
          <div className="bg-[#0f0f0f] border border-white/10 rounded-xl p-6 shadow-sm flex flex-col justify-between min-h-[340px]">
            <div>
              <div className="border-b border-white/5 pb-3 mb-4">
                <h3 className="text-sm font-bold text-gray-200 uppercase tracking-wider flex items-center font-mono">
                  <MessageSquare className="h-4.5 w-4.5 text-teal-400 mr-2" />
                  Interactive Operator consultation
                </h3>
              </div>

              {/* Message History */}
              <div className="space-y-4 max-h-[220px] overflow-y-auto mb-4 p-2 bg-black/20 border border-white/5 rounded-lg" id="chat-history-container">
                {chatHistory.length === 0 ? (
                  <div className="py-12 text-center text-gray-500 text-xs font-mono">
                    <Brain className="h-8 w-8 mx-auto text-gray-600 mb-2" />
                    Consult the co-pilot directly regarding thermal stress, exergy ratios, or OPEX variations.
                  </div>
                ) : (
                  chatHistory.map((msg, idx) => (
                    <div 
                      key={idx} 
                      id={`chat-msg-${idx}`}
                      className={`flex ${msg.role === 'operator' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div className={`p-3 rounded-lg max-w-[85%] text-xs text-left shadow-sm ${
                        msg.role === 'operator' 
                          ? 'bg-[#111111] text-white border border-white/10' 
                          : 'bg-teal-950/20 border border-teal-500/20 text-gray-200'
                      }`}>
                        <div className="font-bold text-[9px] uppercase text-teal-400 mb-1 font-mono">
                          {msg.role === 'operator' ? 'Tom (Operator)' : 'AI CO-PILOT'}
                        </div>
                        <div className="prose prose-sm leading-relaxed">
                          <div className="markdown-body font-sans">
                            <Markdown>{msg.text}</Markdown>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))
                )}
                {loadingChat && (
                  <div className="flex justify-start">
                    <div className="p-3 bg-[#111111] border border-white/10 rounded-lg text-xs flex items-center space-x-2">
                      <RefreshCw className="h-3.5 w-3.5 animate-spin text-teal-400" />
                      <span className="text-gray-400 font-mono text-[10px]">Processing thermal exergy balance...</span>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Chat Input */}
            <form onSubmit={sendOperatorMessage} className="flex gap-2" id="chat-input-form">
              <input
                type="text"
                id="chat-input-field"
                placeholder="Ask about ORC cooling fluid properties or geothermal thermal stress risk..."
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                className="flex-1 bg-white/5 border border-white/10 rounded-lg px-4 py-2 text-xs text-white focus:outline-none focus:ring-1 focus:ring-teal-400 focus:border-teal-400 placeholder-gray-500"
              />
              <button
                type="submit"
                id="btn-send-chat"
                disabled={loadingChat || !chatInput.trim()}
                className="bg-teal-600 hover:bg-teal-500 text-white p-2.5 rounded-lg flex items-center justify-center transition-colors disabled:opacity-50 border border-teal-500/30"
              >
                <Send className="h-4 w-4" />
              </button>
            </form>
          </div>
        </div>

        {/* Right Column: Feasibility report compiler */}
        <div className="bg-[#0f0f0f] border border-white/10 rounded-xl p-6 shadow-sm flex flex-col justify-between min-h-[740px]">
          <div>
            <div className="flex items-center space-x-2 border-b border-white/5 pb-3 mb-4">
              <FileText className="h-4.5 w-4.5 text-teal-400" />
              <h3 className="text-sm font-bold text-gray-200 uppercase tracking-wider font-mono">Formal Board Report</h3>
            </div>

            <p className="text-xs text-gray-400 leading-normal mb-6 font-sans">
              Compiles active scenario variables and R Monte Carlo percentiles (P5, P50, P95) into a detailed, boardroom-ready Integrated Energy Feasibility and Technical Risk Audit report.
            </p>

            <button
              id="btn-compile-board-report"
              onClick={compileReport}
              disabled={loadingReport}
              className="w-full inline-flex items-center justify-center px-4 py-2.5 bg-teal-600 hover:bg-teal-500 border border-teal-500/30 text-white rounded-lg text-xs font-bold transition-colors shadow font-mono"
            >
              <FileText className="h-4 w-4 mr-2" />
              {loadingReport ? 'Compiling Report...' : 'Compile Executive Feasibility Report'}
            </button>

            {loadingReport ? (
              <div className="py-24 text-center text-gray-500 space-y-3 font-mono">
                <RefreshCw className="h-8 w-8 animate-spin mx-auto text-teal-400" />
                <p className="text-xs">Compiling financial projections and exergy flow diagrams...</p>
              </div>
            ) : report ? (
              <div className="mt-6 p-4 bg-[#111111] rounded-lg border border-white/5 max-h-[460px] overflow-y-auto text-left">
                <div className="prose prose-sm max-w-none text-gray-300 text-xs leading-relaxed font-sans space-y-3">
                  <div className="markdown-body font-sans">
                    <Markdown>{report}</Markdown>
                  </div>
                </div>
              </div>
            ) : (
              <div className="py-32 text-center text-gray-500 font-mono">
                <Cpu className="h-10 w-10 mx-auto text-gray-700 mb-2" />
                <p className="text-xs">Click compile to construct formal feasibility documentation.</p>
              </div>
            )}
          </div>

          <div className="border-t border-white/5 pt-3 mt-6 text-[10px] text-gray-500 font-mono">
            AUTHORITATIVE OUTPUT • CERTIFIED VERSION 3.0
          </div>
        </div>

      </div>
    </div>
  );
}
