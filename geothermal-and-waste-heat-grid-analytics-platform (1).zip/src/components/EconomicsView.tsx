/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Scenario, PercentileResult, PriceScenarioName, EnergyArchitecture } from '../types';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, Cell
} from 'recharts';
import { 
  PiggyBank, ArrowRight, TrendingUp, AlertTriangle, ShieldCheck, 
  Database, RefreshCw, BarChart2, DollarSign, Percent 
} from 'lucide-react';

interface EconomicsViewProps {
  scenarios: Scenario[];
  onSelectScenario: (scenario: Scenario) => void;
  selectedScenario: Scenario;
  onRunMonteCarloComplete: (percentiles: PercentileResult[]) => void;
  securityRole: 'OPERATOR_READ' | 'OPERATOR_CONTROL';
}

export default function EconomicsView({
  scenarios,
  onSelectScenario,
  selectedScenario,
  onRunMonteCarloComplete,
  securityRole
}: EconomicsViewProps) {
  const [mcLoading, setMcLoading] = useState<boolean>(false);
  const [mcTrials, setMcTrials] = useState<number>(3000);
  const [mcResults, setMcResults] = useState<{
    trialsRun: number;
    percentiles: PercentileResult[];
    histogramData: { npvBin: number; frequency: number }[];
    parameterSensitivities: { parameter: string; sensitivityIndex: number }[];
  } | null>(null);

  // Run Monte Carlo on selected scenario
  const runSimulation = async () => {
    setMcLoading(true);
    try {
      const response = await fetch('/api/r/monte-carlo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          architecture: selectedScenario.architecture,
          priceScenario: selectedScenario.priceScenario,
          dcLoadMW: selectedScenario.dcLoadMW,
          geothermalResourceMW: selectedScenario.geothermalResourceMW,
          parameters: selectedScenario.parameters,
          trials: mcTrials
        })
      });
      const data = await response.json();
      setMcResults(data);
      onRunMonteCarloComplete(data.percentiles);
    } catch (err) {
      console.error('Monte Carlo Simulation run failed:', err);
    } finally {
      setMcLoading(false);
    }
  };

  // Trigger when scenario changes
  useEffect(() => {
    runSimulation();
  }, [selectedScenario]);

  // Convert percentiles to cumulative distribution curve coordinates
  const getCdfData = () => {
    if (!mcResults) return [];
    // Map percentiles to coordinates
    const pMap: { [key: string]: number } = {
      'P5': 0.05,
      'P10': 0.10,
      'P25': 0.25,
      'P50': 0.50,
      'P75': 0.75,
      'P90': 0.90,
      'P95': 0.95
    };
    return mcResults.percentiles.map(p => ({
      name: p.percentile,
      npv: p.npvMillionUSD,
      irr: p.irrPercent,
      probability: pMap[p.percentile] * 100
    })).sort((a, b) => a.npv - b.npv);
  };

  return (
    <div className="space-y-6" id="economics-view-root">
      {/* Introduction */}
      <div className="bg-[#111111] border border-white/10 rounded-xl p-6 shadow-sm">
        <span className="text-[10px] font-bold uppercase tracking-widest text-teal-400 font-mono">Statistical Analysis Layer</span>
        <h2 className="text-xl font-bold text-white sm:text-2xl mt-1">R Statistics & Economic Risk Engine</h2>
        <p className="mt-2 text-sm text-gray-400">
          The R economic engine calculates Levelized Cost of Energy (LCOE & LCOH), Capex/Opex amortization schedules, and carbon displacement credits. It performs thousands of randomized Monte Carlo trials across pricing indices and resource capacities to compute project value-at-risk percentiles.
        </p>
      </div>

      {/* Comparative Architecture Grid / Scenario Table */}
      <div className="bg-[#0f0f0f] border border-white/10 rounded-xl shadow-sm overflow-hidden" id="scenarios-table-box">
        <div className="px-6 py-5 border-b border-white/10 flex justify-between items-center bg-[#111111]">
          <div>
            <h3 className="text-md font-bold text-white">Stored Grid Architecture Scenarios</h3>
            <p className="text-xs text-gray-400 mt-1">Authorized project cases synchronized from database ledgers.</p>
          </div>
          <span className="text-xs text-gray-500 font-mono">DB Synchronized</span>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-white/5">
            <thead className="bg-[#111111]">
              <tr className="font-mono text-[10px] text-gray-400 uppercase tracking-wider">
                <th className="px-6 py-3 text-left">Scenario Name</th>
                <th className="px-6 py-3 text-left">Architecture</th>
                <th className="px-6 py-3 text-center">Price Profile</th>
                <th className="px-6 py-3 text-right">CAPEX</th>
                <th className="px-6 py-3 text-right">LCOE</th>
                <th className="px-6 py-3 text-right">LCOH</th>
                <th className="px-6 py-3 text-right">20-Yr NPV</th>
                <th className="px-6 py-3 text-right">IRR</th>
                <th className="px-6 py-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 text-sm">
              {scenarios.map((sc) => {
                const isSelected = sc.id === selectedScenario.id;
                return (
                  <tr 
                    key={sc.id} 
                    id={`row-scenario-${sc.id}`}
                    onClick={() => onSelectScenario(sc)}
                    className={`cursor-pointer transition-colors ${isSelected ? 'bg-teal-950/20 hover:bg-teal-950/30 font-medium' : 'hover:bg-white/5 bg-[#0f0f0f]'}`}
                  >
                    <td className="px-6 py-4">
                      <p className="text-white text-sm font-semibold">{sc.name}</p>
                      <p className="text-xs opacity-50 mt-0.5 line-clamp-1">{sc.description}</p>
                    </td>
                    <td className="px-6 py-4">
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-white/5 border border-white/10 font-mono text-teal-400">
                        {sc.architecture}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-center">
                      <span className="text-xs text-gray-300 font-mono uppercase">{sc.priceScenario.replace(/_/g, ' ')}</span>
                    </td>
                    <td className="px-6 py-4 text-right font-mono text-white">${sc.economics.capexMillionUSD}M</td>
                    <td className="px-6 py-4 text-right font-mono text-white">${sc.economics.lcoe_usd_mwh}/MWh</td>
                    <td className="px-6 py-4 text-right font-mono text-white">${sc.economics.lcoh_usd_mwh}/MWh</td>
                    <td className="px-6 py-4 text-right font-mono font-bold text-white">${sc.economics.netNPVMillionUSD}M</td>
                    <td className="px-6 py-4 text-right font-mono text-teal-400 font-bold">{sc.economics.irrPercent}%</td>
                    <td className="px-6 py-4 text-center">
                      {isSelected ? (
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-bold bg-teal-500/10 text-teal-400 border border-teal-500/25">ACTIVE</span>
                      ) : (
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-normal text-gray-500 font-mono">SELECT</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Grid: Monte Carlo Probability CDF & Parameter Sensitivities */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Probability Density Chart */}
        <div className="bg-[#0f0f0f] border border-white/10 rounded-xl p-6 shadow-sm flex flex-col justify-between min-h-[460px]">
          <div>
            <div className="flex justify-between items-center border-b border-white/5 pb-3 mb-4">
              <h3 className="text-sm font-bold text-gray-200 uppercase tracking-wider flex items-center font-mono">
                <BarChart2 className="h-4.5 w-4.5 mr-2 text-teal-400" />
                NPV Risk Distribution Curve (CDF)
              </h3>
              <button 
                id="btn-re-run-mc"
                onClick={runSimulation}
                disabled={mcLoading}
                className="p-1.5 hover:bg-white/10 rounded text-gray-400 hover:text-white flex items-center text-xs space-x-1 border border-white/10 bg-white/5 font-mono"
              >
                <RefreshCw className={`h-3.5 w-3.5 ${mcLoading ? 'animate-spin text-teal-400' : ''}`} />
                <span>Simulate</span>
              </button>
            </div>

            <p className="text-xs text-gray-400 leading-normal mb-4">
              This cumulative probability distribution details the chance that the actual project NPV will fall below a certain threshold. High-slope shifts indicate low volatility regime options.
            </p>

            {/* Chart */}
            <div className="h-64" id="cdf-chart-container">
              {mcResults ? (
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={getCdfData()} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <defs>
                      <linearGradient id="colorNpv" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#14b8a6" stopOpacity={0.2}/>
                        <stop offset="95%" stopColor="#14b8a6" stopOpacity={0.01}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="rgba(255,255,255,0.05)" />
                    <XAxis 
                      dataKey="npv" 
                      tick={{ fill: '#9ca3af', fontSize: 10, fontFamily: 'monospace' }} 
                      label={{ value: 'NPV (Million USD)', position: 'insideBottom', offset: -5, fill: '#9ca3af', fontSize: 10 }} 
                    />
                    <YAxis 
                      tick={{ fill: '#9ca3af', fontSize: 10, fontFamily: 'monospace' }} 
                      label={{ value: 'Cumulative Prob (%)', angle: -90, position: 'insideLeft', offset: 10, fill: '#9ca3af', fontSize: 10 }} 
                    />
                    <Tooltip 
                      content={({ active, payload }) => {
                        if (active && payload && payload.length) {
                          const data = payload[0].payload;
                          return (
                            <div className="bg-slate-950 border border-slate-800 p-3 rounded text-white font-mono text-[11px] text-left">
                              <p className="font-bold text-teal-400 font-mono">Percentile: {data.name}</p>
                              <p className="mt-1 font-mono">NPV: ${data.npv.toFixed(2)}M</p>
                              <p className="font-mono">IRR: {data.irr.toFixed(1)}%</p>
                              <p className="text-gray-400 mt-1 font-mono">Cumulative Prob: {data.probability}%</p>
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                    <Area type="monotone" dataKey="probability" stroke="#14b8a6" strokeWidth={2} fillOpacity={1} fill="url(#colorNpv)" />
                  </AreaChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-full flex items-center justify-center text-gray-500 font-mono text-xs">
                  Running simulation...
                </div>
              )}
            </div>
          </div>

          {/* Percentiles indicators */}
          {mcResults && (
            <div className="grid grid-cols-5 gap-2 border-t border-white/5 pt-4 mt-4 font-mono text-[10px] text-center" id="percentiles-legend">
              {[
                { label: 'P5 (Downside)', key: 'P5', color: 'text-rose-400 font-bold font-mono' },
                { label: 'P25', key: 'P25', color: 'text-gray-400 font-mono' },
                { label: 'P50 (Median)', key: 'P50', color: 'text-teal-400 font-bold font-mono' },
                { label: 'P75', key: 'P75', color: 'text-gray-400 font-mono' },
                { label: 'P95 (Upside)', key: 'P95', color: 'text-teal-400 font-bold font-mono' }
              ].map((p) => {
                const val = mcResults.percentiles.find(item => item.percentile === p.key);
                return (
                  <div key={p.key} className="bg-[#111111] border border-white/5 p-2 rounded">
                    <span className="block text-gray-500 text-[9px] uppercase tracking-wider">{p.label}</span>
                    <span className={`block mt-1 ${p.color}`}>
                      ${val ? val.npvMillionUSD : '0'}M
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Tornado Sensitivity Chart */}
        <div className="bg-[#0f0f0f] border border-white/10 rounded-xl p-6 shadow-sm flex flex-col justify-between min-h-[460px]">
          <div>
            <div className="border-b border-white/5 pb-3 mb-4">
              <h3 className="text-sm font-bold text-gray-200 uppercase tracking-wider flex items-center font-mono">
                <TrendingUp className="h-4.5 w-4.5 mr-2 text-teal-400" />
                NPV Parameter Sensitivity (Tornado Index)
              </h3>
            </div>

            <p className="text-xs text-gray-400 leading-normal mb-4 font-sans">
              Calculates the Pearson correlation coefficient between input variable fluctuations and final NPV. High positive numbers represent key drivers, negative numbers depict risks.
            </p>

            <div className="h-64" id="sensitivity-chart-container">
              {mcResults ? (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={mcResults.parameterSensitivities}
                    layout="vertical"
                    margin={{ top: 10, right: 10, left: 30, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="rgba(255,255,255,0.05)" />
                    <XAxis type="number" tick={{ fill: '#9ca3af', fontSize: 10, fontFamily: 'monospace' }} domain={[-1.0, 1.0]} />
                    <YAxis dataKey="parameter" type="category" tick={{ fill: '#9ca3af', fontSize: 10 }} width={120} />
                    <Tooltip 
                      content={({ active, payload }) => {
                        if (active && payload && payload.length) {
                          const data = payload[0].payload;
                          return (
                            <div className="bg-slate-950 border border-slate-800 p-2.5 rounded text-white font-mono text-[10px] text-left">
                              <p className="font-bold">{data.parameter}</p>
                              <p className="mt-1">Correlation: {data.sensitivityIndex.toFixed(2)}</p>
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                    <Bar dataKey="sensitivityIndex" radius={[0, 4, 4, 0]}>
                      {mcResults.parameterSensitivities.map((entry, index) => (
                        <Cell 
                          key={`cell-${index}`} 
                          fill={entry.sensitivityIndex > 0 ? '#14b8a6' : '#f43f5e'} 
                        />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-full flex items-center justify-center text-gray-500 font-mono text-xs">
                  Calculating parameter dependencies...
                </div>
              )}
            </div>
          </div>

          <div className="border-t border-white/5 pt-4 text-xs text-gray-400 leading-normal font-sans">
            <strong>Risk Minimization Directive:</strong> For scenarios with highly negative LCOE dependencies, optimize long-term power purchase agreements (PPA) to decouple volatile spot-market exposures.
          </div>
        </div>

      </div>
    </div>
  );
}
