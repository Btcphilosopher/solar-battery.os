/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { ProvenanceNode } from '../types';
import { Database, ShieldCheck, Cpu, ArrowRight, Layers, FileSpreadsheet, RefreshCw, Server, Settings } from 'lucide-react';

interface LineageExplorerProps {
  initialMetric?: string;
}

export default function LineageExplorer({
  initialMetric = 'NET_POWER_GENERATED'
}: LineageExplorerProps) {
  const [selectedMetric, setSelectedMetric] = useState<string>(initialMetric);
  const [provenance, setProvenance] = useState<ProvenanceNode | null>(null);
  const [loading, setLoading] = useState<boolean>(false);

  useEffect(() => {
    // If initialMetric prop changes from outside, update selection
    setSelectedMetric(initialMetric);
  }, [initialMetric]);

  useEffect(() => {
    const fetchLineage = async () => {
      setLoading(true);
      try {
        const res = await fetch(`/api/lineage/${selectedMetric}`);
        const data = await res.json();
        setProvenance(data);
      } catch (err) {
        console.error('Failed to retrieve data lineage:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchLineage();
  }, [selectedMetric]);

  const metrics = [
    { id: 'NET_POWER_GENERATED', label: 'Net Electrical Generation (MWe)' },
    { id: 'MW_THERMAL_RECOVERED', label: 'Data Centre Heat Recovered (MWth)' },
    { id: 'GEOTHERMAL_HEAT_MW', label: 'Raw Geothermal Thermal Power (MWth)' }
  ];

  return (
    <div className="space-y-6" id="lineage-explorer-root">
      {/* Intro section */}
      <div className="bg-[#111111] border border-white/10 rounded-xl p-6 shadow-sm">
        <span className="text-[10px] font-bold uppercase tracking-widest text-teal-400 font-mono">Traceability & Data Lineage Layer</span>
        <h2 className="text-xl font-bold text-white sm:text-2xl mt-1">Audit-Grade Data Lineage (Provenance Explorer)</h2>
        <p className="mt-2 text-sm text-gray-400">
          Industrial data accountability requirement. Trace any calculated economic multiplier or plant indicator back through mathematical equations, system models, database ledger logs, and original physical high-frequency sensor readings.
        </p>
      </div>

      {/* Metric Selector Tabs */}
      <div className="flex border-b border-white/10 overflow-x-auto" id="lineage-tabs">
        {metrics.map((m) => (
          <button
            key={m.id}
            id={`tab-lineage-${m.id}`}
            onClick={() => setSelectedMetric(m.id)}
            className={`px-4 py-3 whitespace-nowrap text-sm font-semibold transition-colors border-b-2 -mb-[2px] ${
              selectedMetric === m.id
                ? 'border-teal-400 text-teal-400'
                : 'border-transparent text-gray-400 hover:text-white hover:border-white/20'
            }`}
          >
            {m.label}
          </button>
        ))}
      </div>

      {loading && (
        <div className="h-64 flex items-center justify-center text-teal-400">
          <RefreshCw className="h-8 w-8 animate-spin" />
        </div>
      )}

      {!loading && provenance && (
        <div className="space-y-6">
          {/* Main Visual flow representation of the DAG */}
          <div className="bg-[#0f0f0f] border border-white/10 rounded-xl p-6 text-gray-100 shadow-xl relative overflow-hidden" id="lineage-dag-canvas">
            <h3 className="text-xs font-mono font-bold tracking-widest text-gray-400 uppercase mb-6">
              AUDIT PROVENANCE PATH FOR Metric: <span className="text-teal-400 font-mono">{provenance.metric_name}</span>
            </h3>

            {/* FLOW DIAGRAM STEPS */}
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4 relative">
              
              {/* Step 1: Raw Sensors */}
              <div className="bg-[#111111] border border-white/5 p-4 rounded-lg flex flex-col justify-between h-[200px] z-10 hover:border-teal-500/20 transition-colors">
                <div>
                  <div className="flex items-center space-x-1.5 text-gray-400 mb-2">
                    <Cpu className="h-4 w-4 text-teal-400" />
                    <span className="text-[10px] uppercase font-bold tracking-wider">1. Observation</span>
                  </div>
                  <h4 className="text-xs font-bold font-mono text-white">Raw Source Sensors</h4>
                  <ul className="mt-3 space-y-1 font-mono text-[9px] text-teal-400">
                    {provenance.source_sensors.map(s => (
                      <li key={s} className="bg-black/40 px-2 py-1 rounded border border-white/5">ID: {s}</li>
                    ))}
                  </ul>
                </div>
                <div className="text-[9px] text-gray-500 mt-2 font-mono">
                  Ingestion: {provenance.timestamp.substring(11, 19)}
                </div>
              </div>

              {/* Arrow */}
              <div className="hidden md:flex items-center justify-center">
                <ArrowRight className="h-5 w-5 text-gray-500" />
              </div>

              {/* Step 2: Rust Verification */}
              <div className="bg-[#111111] border border-white/5 p-4 rounded-lg flex flex-col justify-between h-[200px] z-10 hover:border-teal-500/20 transition-colors border-teal-500/10">
                <div>
                  <div className="flex items-center space-x-1.5 text-gray-400 mb-2">
                    <ShieldCheck className="h-4 w-4 text-teal-400" />
                    <span className="text-[10px] uppercase font-bold tracking-wider">2. Verification</span>
                  </div>
                  <h4 className="text-xs font-bold font-mono text-white">Rust Ingest Daemon</h4>
                  <p className="text-[10px] text-gray-400 mt-2 leading-relaxed">
                    Filters duplicates, performs physical boundary assertions, and labels signal quality flags on a bounded ring buffer.
                  </p>
                </div>
                <div className="text-[9px] text-teal-400 font-mono">
                  CONTRACT: RUST_INGEST_V1.4
                </div>
              </div>

              {/* Arrow */}
              <div className="hidden md:flex items-center justify-center">
                <ArrowRight className="h-5 w-5 text-gray-500" />
              </div>

              {/* Step 3: Model Calculations */}
              <div className="bg-[#111111] border border-white/5 p-4 rounded-lg flex flex-col justify-between h-[200px] z-10 hover:border-teal-500/20 transition-colors">
                <div>
                  <div className="flex items-center space-x-1.5 text-gray-400 mb-2">
                    <Settings className="h-4 w-4 text-teal-400" />
                    <span className="text-[10px] uppercase font-bold tracking-wider">3. Computation</span>
                  </div>
                  <h4 className="text-xs font-bold font-mono text-white">Calculated Output</h4>
                  <p className="text-[10px] text-gray-400 mt-2 leading-relaxed">
                    Executed by steady-state thermodynamic modeling libraries inside python wrappers.
                  </p>
                  <p className="text-[9px] text-amber-400 mt-2 font-mono bg-black/40 border border-white/5 p-1.5 rounded truncate">
                    {provenance.mathematical_formula}
                  </p>
                </div>
                <div className="text-[9px] text-gray-500 mt-2 font-mono">
                  Engine: {provenance.calculation_version}
                </div>
              </div>

              {/* Decorative wire background lines */}
              <div className="absolute top-[100px] left-0 right-0 h-0.5 bg-white/5 pointer-events-none hidden md:block" />
            </div>
          </div>

          {/* Deep Metadata Provenance Card (authoritative ledger details) */}
          <div className="bg-[#0f0f0f] border border-white/10 rounded-xl p-6 shadow-sm text-left">
            <h3 className="text-sm font-bold text-gray-200 uppercase tracking-wider mb-4 flex items-center font-mono">
              <Database className="h-4.5 w-4.5 mr-2 text-teal-400" />
              Database Authoritative Ledger Audit Trail (Strict Provenance Record)
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
              <div className="space-y-3 font-mono">
                <div className="flex justify-between py-1.5 border-b border-white/5">
                  <span className="text-gray-500">AUTHORITATIVE LEDGER KEY</span>
                  <span className="font-bold text-white">{provenance.metric_name}</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-white/5">
                  <span className="text-gray-500">CURRENT DERIVED VALUE</span>
                  <span className="font-bold text-teal-400 text-sm">{provenance.raw_value} {provenance.unit}</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-white/5">
                  <span className="text-gray-500">LEDGER STORAGE SECTOR TIMESTAMP</span>
                  <span className="font-bold text-white">{provenance.timestamp}</span>
                </div>
                <div className="flex justify-between py-1.5 border-b border-white/5">
                  <span className="text-gray-500">STEADY-STATE PHYSICAL MODEL</span>
                  <span className="font-bold text-white">{provenance.model_version}</span>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <span className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">MATHEMATICAL RESOLUTION FORMULA</span>
                  <div className="bg-[#111111] border border-white/5 p-3 rounded-lg font-mono text-xs text-gray-300 leading-normal">
                    {provenance.mathematical_formula}
                  </div>
                </div>

                <div>
                  <span className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">INPUT REFERENCE DATASETS</span>
                  <div className="flex flex-wrap gap-1.5">
                    {provenance.input_datasets.map((d, idx) => (
                      <span key={idx} className="inline-flex items-center px-2 py-1 rounded text-[10px] font-mono bg-white/5 text-gray-300 border border-white/10">
                        <FileSpreadsheet className="h-3 w-3 mr-1 text-gray-500" />
                        {d}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
