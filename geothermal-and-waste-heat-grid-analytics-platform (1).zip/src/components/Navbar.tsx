/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ShieldCheck, HardDrive, Database, RefreshCw, Cpu } from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  securityRole: 'OPERATOR_READ' | 'OPERATOR_CONTROL';
  setSecurityRole: (role: 'OPERATOR_READ' | 'OPERATOR_CONTROL') => void;
  telemetryOnline: boolean;
  latestSequence: number;
}

export default function Navbar({
  activeTab,
  setActiveTab,
  securityRole,
  setSecurityRole,
  telemetryOnline,
  latestSequence
}: NavbarProps) {
  return (
    <header className="bg-[#111111] text-gray-200 border-b border-white/10 sticky top-0 z-50 shadow-md" id="app-header">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Title */}
          <div className="flex items-center space-x-3">
            <div className="bg-teal-500 text-black px-2.5 py-1.5 rounded font-bold text-sm flex items-center justify-center">
              TC
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase tracking-widest text-teal-500 block">Integrated Energy Platform</span>
              <h1 className="text-lg font-bold tracking-tight text-white leading-tight">
                THERMO-CORE <span className="text-teal-500 font-mono text-xs opacity-80">// RUST_R_INTEGRATED</span>
              </h1>
            </div>
          </div>

          {/* Core Navigation tabs */}
          <nav className="hidden md:flex space-x-1" aria-label="Global">
            {[
              { id: 'telemetry', label: 'Rust Telemetry HMI' },
              { id: 'thermotwin', label: 'Python Digital Twin' },
              { id: 'economics', label: 'R Economics & MC' },
              { id: 'lineage', label: 'Data Lineage' },
              { id: 'copilot', label: 'AI Optimization' }
            ].map((tab) => (
              <button
                key={tab.id}
                id={`tab-nav-${tab.id}`}
                onClick={() => setActiveTab(tab.id)}
                className={`px-3 py-2 rounded text-xs font-mono uppercase tracking-wider transition-colors ${
                  activeTab === tab.id
                    ? 'bg-white/5 text-teal-400 border border-white/10'
                    : 'text-gray-400 hover:bg-white/5 hover:text-white'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </nav>

          {/* System Telemetry & Role Permissions Status Panel */}
          <div className="flex items-center space-x-4">
            {/* Telemetry Heartbeat */}
            <div className="hidden lg:flex items-center space-x-2 text-xs bg-black border border-white/10 px-3 py-1.5 rounded">
              <span className={`h-2.5 w-2.5 rounded-full ${telemetryOnline ? 'bg-teal-500 animate-pulse' : 'bg-rose-500'}`} />
              <span className="text-teal-400 font-mono">SEQ: #{latestSequence}</span>
            </div>

            {/* Role-Based Access Control Selection */}
            <div className="flex items-center space-x-1.5 bg-black border border-white/10 px-2 py-1 rounded">
              <ShieldCheck className="h-4 w-4 text-teal-400" />
              <select
                id="role-selector"
                value={securityRole}
                onChange={(e) => setSecurityRole(e.target.value as any)}
                className="bg-transparent text-xs text-gray-200 font-medium focus:outline-none cursor-pointer pr-1 border-none"
              >
                <option value="OPERATOR_READ" className="bg-[#111111] text-gray-100">READ ONLY</option>
                <option value="OPERATOR_CONTROL" className="bg-[#111111] text-gray-100">CONTROL CLEARANCE</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Subnavigation bar for mobile view */}
      <div className="md:hidden bg-black border-t border-white/10 flex overflow-x-auto py-2 px-4 space-x-2 scrollbar-none" id="mobile-tabs-container">
        {[
          { id: 'telemetry', label: 'Telemetry' },
          { id: 'thermotwin', label: 'Twin' },
          { id: 'economics', label: 'Economics' },
          { id: 'lineage', label: 'Lineage' },
          { id: 'copilot', label: 'AI Co-pilot' }
        ].map((tab) => (
          <button
            key={tab.id}
            id={`mobile-tab-nav-${tab.id}`}
            onClick={() => setActiveTab(tab.id)}
            className={`whitespace-nowrap px-3 py-1.5 rounded text-xs font-medium transition-colors ${
              activeTab === tab.id
                ? 'bg-white/10 text-teal-400 border border-white/10'
                : 'text-gray-400 hover:bg-white/5'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>
    </header>
  );
}
