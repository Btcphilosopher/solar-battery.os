/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { TelemetryPacket, ValidationError, SensorQuality } from '../types';
import { 
  Activity, 
  CheckCircle2, 
  AlertTriangle, 
  TrendingUp, 
  Thermometer, 
  Droplets, 
  Wind, 
  Gauge, 
  Zap, 
  ChevronRight,
  Info
} from 'lucide-react';

interface TelemetryViewProps {
  telemetry: TelemetryPacket[];
  validationErrors: ValidationError[];
  securityRole: 'OPERATOR_READ' | 'OPERATOR_CONTROL';
  onInspectLineage: (metric: string) => void;
}

export default function TelemetryView({
  telemetry,
  validationErrors,
  securityRole,
  onInspectLineage
}: TelemetryViewProps) {
  const [selectedSensor, setSelectedSensor] = useState<TelemetryPacket | null>(null);

  // Helper to get matching icon for sensor type
  const getSensorIcon = (measurement: string) => {
    switch (measurement) {
      case 'temperature': return <Thermometer className="h-4 w-4 text-rose-500" />;
      case 'flow': return <Droplets className="h-4 w-4 text-cyan-500" />;
      case 'humidity': return <Wind className="h-4 w-4 text-emerald-500" />;
      case 'pressure': return <Gauge className="h-4 w-4 text-amber-500" />;
      case 'power': return <Zap className="h-4 w-4 text-amber-400" />;
      default: return <Activity className="h-4 w-4 text-slate-400" />;
    }
  };

  const getQualityBadge = (quality: SensorQuality) => {
    switch (quality) {
      case 'GOOD':
        return <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-teal-950/40 text-teal-400 border border-teal-500/30 font-mono">GOOD</span>;
      case 'DRIFT':
        return <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-amber-950/40 text-amber-400 border border-amber-500/30 font-mono">DRIFT</span>;
      case 'SUSPECT':
        return <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-rose-950/40 text-rose-400 border border-rose-500/30 font-mono">SUSPECT</span>;
      default:
        return <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-white/5 text-gray-400 font-mono">UNKNOWN</span>;
    }
  };

  // Find specific key sensors for active diagram overlay
  const getSensorVal = (id: string, fallback: number) => {
    const s = telemetry.find(p => p.sensor_id === id);
    return s ? `${s.value} ${s.unit}` : `${fallback}`;
  };

  return (
    <div className="space-y-6" id="telemetry-view-root">
      {/* Overview Intro Banner */}
      <div className="bg-[#111111] border border-white/10 rounded-xl p-6 shadow-sm">
        <div className="md:flex md:items-center md:justify-between">
          <div className="flex-1 min-w-0">
            <span className="text-[10px] font-bold uppercase tracking-widest text-teal-400 font-mono">Telemetry Ingestion Layer</span>
            <h2 className="text-xl font-bold text-white sm:text-2xl sm:truncate mt-1">Rust Real-Time Verification Node</h2>
            <p className="mt-2 text-sm text-gray-400 max-w-3xl">
              Simulating the production Rust telemetry ingestion core. Validates high-frequency sensor streams (temperatures, pressure, turbine flow, exergy states) on a bounded queue, ensuring strict type-safety, sequence logging, and immediate filter-based anomaly detection before database persistence.
            </p>
          </div>
          <div className="mt-4 flex-shrink-0 md:mt-0 md:ml-4">
            <span className="inline-flex items-center px-3 py-1.5 rounded text-xs font-bold bg-teal-500/10 text-teal-400 border border-teal-500/25">
              <CheckCircle2 className="h-4 w-4 mr-1.5 text-teal-400 animate-pulse" /> Rust Daemon: Active
            </span>
          </div>
        </div>
      </div>

      {/* Grid: Mechanical Diagram & Detailed validation alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* SCADA Interactive loop flow diagram */}
        <div className="lg:col-span-2 bg-[#0f0f0f] border border-white/10 rounded-xl p-6 text-gray-200 shadow-lg relative overflow-hidden flex flex-col justify-between min-h-[460px]">
          <div className="absolute top-0 right-0 bg-[#111111] border-l border-b border-white/10 px-3 py-1.5 rounded-bl-lg text-[10px] font-mono text-teal-400 tracking-wider">
            SCADA LOOP INTERACTIVE FEEDS
          </div>

          <div>
            <h3 className="text-sm font-bold tracking-wider text-gray-300 uppercase mb-4 flex items-center font-mono">
              <Activity className="h-4.5 w-4.5 mr-2 text-teal-400 animate-pulse" />
              Integrated Hybrid Energy Process Loop
            </h3>

            {/* Industrial SVG loop overlay */}
            <div className="my-6 relative bg-[#0a0a0a] rounded p-4 border border-white/10 flex flex-col justify-center items-center min-h-[300px]">
              
              {/* Simplified Layout Schematic */}
              <div className="w-full max-w-lg grid grid-cols-3 gap-y-12 gap-x-6 text-center font-mono text-xs z-10">
                
                {/* Loop 1: Data Centre servers */}
                <div className="bg-[#111111] border border-white/5 rounded p-3 relative shadow">
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-blue-500/10 border border-blue-500/30 text-blue-400 px-1.5 py-0.2 rounded text-[9px] uppercase tracking-wider font-bold">Data Centre</div>
                  <p className="text-[10px] opacity-60 mt-1">Waste Recovery</p>
                  <p className="text-sm font-bold text-blue-400 mt-2">{getSensorVal('DC_TEMP_OUTLET', 62.4)}</p>
                  <p className="text-[10px] opacity-40 mt-1">{getSensorVal('DC_FLOW_COOLANT', 820.0)}</p>
                </div>

                {/* Exchange Point */}
                <div className="flex flex-col justify-center items-center">
                  <div className="h-10 w-10 rounded-full border border-dashed border-teal-500/50 flex items-center justify-center bg-black text-teal-400 animate-spin text-[10px] font-bold duration-10000">HX</div>
                  <span className="text-[9px] opacity-40 mt-1">Heat Exchanger</span>
                </div>

                {/* ORC Generator */}
                <div className="bg-[#111111] border border-white/5 rounded p-3 relative shadow">
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-amber-500/10 border border-amber-500/30 text-amber-400 px-1.5 py-0.2 rounded text-[9px] uppercase tracking-wider font-bold">ORC Turbine</div>
                  <p className="text-[10px] opacity-60 mt-1">Net Power</p>
                  <p className="text-sm font-bold text-amber-400 mt-2">{getSensorVal('ORC_GEN_POWER', 8240)}</p>
                  <p className="text-[10px] opacity-40 mt-1">{getSensorVal('ORC_ROTATION_RPM', 3600)}</p>
                </div>

                {/* Loop 2: Geothermal Well Production */}
                <div className="bg-[#111111] border border-white/5 rounded p-3 relative shadow">
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-red-500/10 border border-red-500/30 text-red-400 px-1.5 py-0.2 rounded text-[9px] uppercase tracking-wider font-bold">Production</div>
                  <p className="text-[10px] opacity-60 mt-1">Brine Feed</p>
                  <p className="text-sm font-bold text-red-400 mt-2">{getSensorVal('WELL_TEMP_PROD', 132.5)}</p>
                  <p className="text-[10px] opacity-40 mt-1">{getSensorVal('WELL_FLOW_PROD', 142.1)}</p>
                </div>

                {/* Heat Pump Booster */}
                <div className="bg-[#111111] border border-white/5 rounded p-3 flex flex-col justify-center items-center shadow">
                  <Zap className="h-5 w-5 text-teal-400 mb-1" />
                  <span className="text-[9px] opacity-60 uppercase tracking-wider">Heat Pump</span>
                  <p className="text-xs font-bold text-gray-200 mt-1">{getSensorVal('HP_COMPRESSOR_POWER', 1150)}</p>
                </div>

                {/* Geothermal Reinjection Well */}
                <div className="bg-[#111111] border border-white/5 rounded p-3 relative shadow">
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-white/5 border border-white/10 text-gray-400 px-1.5 py-0.2 rounded text-[9px] uppercase tracking-wider font-bold">Reinjection</div>
                  <p className="text-[10px] opacity-60 mt-1">Cooled Brine</p>
                  <p className="text-sm font-bold text-gray-300 mt-2">80.0 °C</p>
                  <p className="text-[10px] opacity-40 mt-1">142.1 m3/h</p>
                </div>

              </div>

              {/* Decorative industrial grid wires in SVG backgrounds */}
              <svg className="absolute inset-0 h-full w-full opacity-[0.03] pointer-events-none" xmlns="http://www.w3.org/2000/svg">
                <defs>
                  <pattern id="grid" width="24" height="24" patternUnits="userSpaceOnUse">
                    <path d="M 24 0 L 0 0 0 24" fill="none" stroke="rgb(20, 184, 166)" strokeWidth="0.5" />
                  </pattern>
                </defs>
                <rect width="100%" height="100%" fill="url(#grid)" />
              </svg>
            </div>
          </div>

          <div className="text-xs text-gray-400 font-sans border-t border-white/10 pt-4 flex justify-between items-center">
            <span>Click on sensor nodes below for lineage audits and historical sequence tracking.</span>
            <span className="text-teal-400 font-mono">Role: {securityRole}</span>
          </div>
        </div>

        {/* Live Rust Ingestion Anomaly Detection Logger */}
        <div className="bg-[#0f0f0f] border border-white/10 rounded-xl shadow-sm overflow-hidden flex flex-col justify-between min-h-[460px]">
          <div className="px-5 py-4 border-b border-white/5 bg-[#111111] flex items-center justify-between">
            <h3 className="text-sm font-bold text-gray-200 uppercase tracking-widest font-mono">Rust Pipeline Validation</h3>
            <span className="px-2 py-0.5 text-[10px] font-bold uppercase rounded bg-rose-500/10 border border-rose-500/20 text-rose-400 animate-pulse font-mono">Telemetry Audit</span>
          </div>

          {/* Scrolling validation alerts */}
          <div className="p-4 flex-1 overflow-y-auto space-y-3 font-mono text-[11px] max-h-[340px]" id="rust-logs-container">
            {validationErrors.length === 0 ? (
              <div className="h-full flex flex-col justify-center items-center text-gray-400 py-12">
                <CheckCircle2 className="h-8 w-8 text-teal-400 mb-2" />
                <p>No active anomalies detected.</p>
                <p className="text-[10px]">Data queue passing all bounds.</p>
              </div>
            ) : (
              validationErrors.map((err, i) => (
                <div 
                  key={i} 
                  id={`val-error-${err.sensor_id}-${i}`}
                  className={`p-3 rounded border text-left leading-relaxed ${
                    err.severity === 'CRITICAL' 
                      ? 'bg-rose-950/20 border-rose-500/30 text-rose-300' 
                      : 'bg-amber-950/20 border-amber-500/30 text-amber-300'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <span className="font-bold flex items-center">
                      <AlertTriangle className="h-3.5 w-3.5 mr-1 text-rose-400" />
                      {err.error_type}
                    </span>
                    <span className="text-[9px] opacity-50">{err.timestamp.substring(11, 19)}</span>
                  </div>
                  <p className="mt-1 text-gray-300 font-sans text-xs">{err.message}</p>
                  <div className="mt-1.5 pt-1.5 border-t border-white/5 text-[10px] opacity-50 flex justify-between">
                    <span>SENSOR ID: {err.sensor_id}</span>
                    <span className="font-bold uppercase text-[9px] bg-white/10 px-1 rounded">{err.severity}</span>
                  </div>
                </div>
              ))
            )}
          </div>

          <div className="p-4 border-t border-white/5 bg-[#111111] text-[10px] text-gray-400 leading-normal">
            <strong>Lineage Assertion:</strong> Outliers and duplicate sequence frames are dropped immediately to preserve mathematical model validity in Python/R databases.
          </div>
        </div>

      </div>

      {/* Sensor Ingestion Detail Table */}
      <div className="bg-[#0f0f0f] border border-white/10 rounded-xl shadow-sm overflow-hidden" id="sensor-table-container">
        <div className="px-6 py-5 border-b border-white/10 flex justify-between items-center flex-wrap gap-4 bg-[#111111]">
          <div>
            <h3 className="text-md font-bold text-white">High-Performance Physical Sensor Grid</h3>
            <p className="text-xs text-gray-400 mt-1">Displays current state validated by the Rust pipeline contract.</p>
          </div>
          <button 
            id="btn-trace-recovered-heat"
            onClick={() => onInspectLineage('MW_THERMAL_RECOVERED')}
            className="inline-flex items-center px-3 py-1.5 border border-white/10 text-xs font-semibold rounded text-gray-200 bg-white/5 hover:bg-white/10 transition-colors"
          >
            <Info className="h-3.5 w-3.5 mr-1 text-teal-400" /> Trace Recovered Heat Formula
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-white/5">
            <thead className="bg-[#111111]">
              <tr className="font-mono text-[11px] text-gray-400 uppercase tracking-wider">
                <th className="px-6 py-3 text-left">Sequence</th>
                <th className="px-6 py-3 text-left">Sensor ID</th>
                <th className="px-6 py-3 text-left">Asset / Location</th>
                <th className="px-6 py-3 text-left">Measurement</th>
                <th className="px-6 py-3 text-right">Raw Output</th>
                <th className="px-6 py-3 text-center">Quality State</th>
                <th className="px-6 py-3 text-right">Lineage</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 text-sm">
              {telemetry.map((p) => (
                <tr 
                  key={p.sensor_id} 
                  id={`sensor-row-${p.sensor_id}`}
                  className={`hover:bg-white/5 transition-colors ${selectedSensor?.sensor_id === p.sensor_id ? 'bg-teal-950/20' : ''}`}
                  onClick={() => setSelectedSensor(p)}
                >
                  <td className="px-6 py-3 font-mono text-xs opacity-50">#{p.sequence_number}</td>
                  <td className="px-6 py-3 font-mono font-bold text-teal-400 text-xs">{p.sensor_id}</td>
                  <td className="px-6 py-3 text-left">
                    <p className="text-white font-medium">{p.asset_id.replace(/_/g, ' ')}</p>
                    <p className="text-xs opacity-60 mt-0.5">{p.location}</p>
                  </td>
                  <td className="px-6 py-3">
                    <span className="flex items-center space-x-1.5 text-xs text-gray-300 font-medium">
                      {getSensorIcon(p.measurement)}
                      <span className="capitalize">{p.measurement}</span>
                    </span>
                  </td>
                  <td className="px-6 py-3 text-right font-mono font-bold text-white">
                    {p.value} <span className="text-xs font-normal opacity-50">{p.unit}</span>
                  </td>
                  <td className="px-6 py-3 text-center">
                    {getQualityBadge(p.quality)}
                  </td>
                  <td className="px-6 py-3 text-right">
                    <button
                      id={`btn-trace-${p.sensor_id}`}
                      onClick={(e) => {
                        e.stopPropagation();
                        onInspectLineage(p.sensor_id === 'ORC_GEN_POWER' ? 'NET_POWER_GENERATED' : 'GEOTHERMAL_HEAT_MW');
                      }}
                      className="inline-flex items-center text-xs font-bold text-teal-400 hover:text-teal-300 hover:underline"
                    >
                      Audit Trace <ChevronRight className="h-3 w-3 ml-0.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
