/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import { 
  TelemetryPacket, 
  ValidationError, 
  ThermodynamicState, 
  EnergyArchitecture, 
  Scenario, 
  PriceScenarioName,
  EconomicIndicators,
  PercentileResult,
  ProvenanceNode,
  AuditLogEntry
} from './src/types.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json());

const PORT = 3000;

// --- IN-MEMORY DATABASE & STATE ---

let telemetrySequence = 1000;
const scenarioDatabase: Map<string, Scenario> = new Map();
const auditLogs: AuditLogEntry[] = [];

// Helper for audit logging
function logAudit(operator: string, role: 'OPERATOR_READ' | 'OPERATOR_CONTROL' | 'SYSTEM_PROCESS', action: string, details: string) {
  const timestamp = new Date().toISOString();
  // Simulating cryptographically sound checksum
  const integrity_hash = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
  const log: AuditLogEntry = { timestamp, operator, role, action, details, integrity_hash };
  auditLogs.unshift(log);
  if (auditLogs.length > 500) auditLogs.pop();
}

// Lazy-loaded Gemini API Client
let aiClient: GoogleGenAI | null = null;
function getAiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
      throw new Error('GEMINI_API_KEY environment variable is not set. Please set it in Settings > Secrets.');
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// --- THERMODYNAMIC FORMULAS (Python Twin) ---

export function computeThermodynamics(
  arch: EnergyArchitecture,
  wellTemp: number, // °C
  wellFlow: number, // kg/s
  wasteHeatTemp: number, // °C
  dcCoolingLoad: number, // MW thermal
  efficiencyMultiplier: number = 1.0
): ThermodynamicState {
  const model_version = 'PY_THERMO_TWIN_V2.1';
  const calculation_timestamp = new Date().toISOString();
  const Cp = 4.184; // kJ/kg*K (water/brine approximate)
  
  // Geothermal energy available
  const reinjectionTemp = wellTemp > 110 ? 80 : 50; // °C
  const geoPowerMW = (wellFlow * Cp * (wellTemp - reinjectionTemp)) / 1000; // MW_thermal
  
  const heatPumpCOP = 3.8 * efficiencyMultiplier;
  const orcTurbineEfficiency = 0.85 * efficiencyMultiplier;
  const exchangerApproachTemp = 5.0; // °C
  
  let netPowerOutputMW = 0;
  let heatRecoveredMW = 0;
  let districtHeatDeliveryMW = 0;
  let condenserHeatRejectionMW = 0;
  
  const T_cold_ambient = 25; // °C
  const carnotEfficiencyLimit = (1 - (T_cold_ambient + 273.15) / (wellTemp + 273.15)) * 100; // %

  switch (arch) {
    case 'ORC': {
      // Organic Rankine Cycle: high-temp geothermal creates steam/vapor, data-centre waste heat is used for preheating
      // Carnot-based practical generation
      const practicalEfficiency = (carnotEfficiencyLimit / 100) * orcTurbineEfficiency * 0.58; 
      // Geothermal drives the generator
      netPowerOutputMW = geoPowerMW * practicalEfficiency;
      // Preheating increases generation slightly by recovering data centre waste heat
      const recoveredDcHeatMW = Math.min(dcCoolingLoad, netPowerOutputMW * 0.2);
      netPowerOutputMW += recoveredDcHeatMW * 0.12; 
      
      heatRecoveredMW = recoveredDcHeatMW;
      condenserHeatRejectionMW = geoPowerMW - netPowerOutputMW + heatRecoveredMW;
      districtHeatDeliveryMW = 0;
      break;
    }
    case 'STEAM': {
      // Steam cycle needs higher temperature, struggles with low geothermal temp
      const steamCarnotEff = (1 - (35 + 273.15) / (wellTemp + 273.15)) * 100;
      const steamEfficiency = (wellTemp >= 130) 
        ? (steamCarnotEff / 100) * 0.65 * orcTurbineEfficiency 
        : (steamCarnotEff / 100) * 0.3 * orcTurbineEfficiency; // severe penalty below 130C
        
      netPowerOutputMW = geoPowerMW * steamEfficiency;
      heatRecoveredMW = Math.min(dcCoolingLoad * 0.5, 5); // direct exchanger recovery
      condenserHeatRejectionMW = geoPowerMW - netPowerOutputMW;
      districtHeatDeliveryMW = 0;
      break;
    }
    case 'HEAT_PUMP': {
      // Heat pump consumes electricity to boost low-grade waste heat + geothermal brine to high-temp district heating
      const sourceHeatMW = geoPowerMW * 0.4 + dcCoolingLoad;
      // Power consumed
      const electricalInputMW = sourceHeatMW / (heatPumpCOP - 1);
      netPowerOutputMW = -electricalInputMW; // Negative indicates net grid consumption
      districtHeatDeliveryMW = sourceHeatMW + electricalInputMW;
      heatRecoveredMW = dcCoolingLoad;
      condenserHeatRejectionMW = 0;
      break;
    }
    case 'DIRECT_HEAT': {
      // No turbine, direct heat exchange to district heating
      heatRecoveredMW = dcCoolingLoad;
      districtHeatDeliveryMW = (geoPowerMW * 0.8) + (dcCoolingLoad * 0.9);
      netPowerOutputMW = 0;
      condenserHeatRejectionMW = 0;
      break;
    }
  }

  // Calculate exergy efficiency (useful output divided by total available exergy)
  const totalGeoExergyMW = geoPowerMW * (1 - (T_cold_ambient + 273.15) / (wellTemp + 273.15));
  const usefulOutputExergyMW = Math.max(0, netPowerOutputMW) + (districtHeatDeliveryMW * (1 - (T_cold_ambient + 273.15) / (85 + 273.15))); // 85°C delivery
  const geothermalExergyEfficiency = totalGeoExergyMW > 0 ? (usefulOutputExergyMW / totalGeoExergyMW) * 100 : 0;
  
  const totalHeatInput = geoPowerMW + dcCoolingLoad;
  const usefulEnergyOutput = Math.max(0, netPowerOutputMW) + districtHeatDeliveryMW;
  const overallSystemEfficiency = totalHeatInput > 0 ? (usefulEnergyOutput / totalHeatInput) * 100 : 0;

  return {
    architecture: arch,
    geothermalBrineTemp: wellTemp,
    geothermalMassFlow: wellFlow,
    dcWasteHeatTemp: wasteHeatTemp,
    dcCoolingLoad,
    heatPumpCOP,
    orcTurbineEfficiency,
    exchangerApproachTemp,
    netPowerOutputMW: parseFloat(netPowerOutputMW.toFixed(3)),
    heatRecoveredMW: parseFloat(heatRecoveredMW.toFixed(3)),
    districtHeatDeliveryMW: parseFloat(districtHeatDeliveryMW.toFixed(3)),
    condenserHeatRejectionMW: parseFloat(condenserHeatRejectionMW.toFixed(3)),
    geothermalExergyEfficiency: parseFloat(Math.min(95, Math.max(0, geothermalExergyEfficiency)).toFixed(2)),
    carnotEfficiencyLimit: parseFloat(carnotEfficiencyLimit.toFixed(2)),
    overallSystemEfficiency: parseFloat(Math.min(100, Math.max(0, overallSystemEfficiency)).toFixed(2)),
    model_version,
    calculation_timestamp
  };
}

// --- ECONOMIC CALCULATION ENGINE (R Economics) ---

export function computeEconomics(
  state: ThermodynamicState,
  params: {
    electricityPriceBase: number;
    heatPriceBase: number;
    carbonTaxRate: number;
    capitalCostFactor: number;
  },
  priceScenario: PriceScenarioName
): EconomicIndicators {
  const calculated_by = 'R_ECON_ENGINE_V3.0';
  
  // 1. CAPEX estimation based on system scale
  let baseTurbineCapex = 0;
  let baseHeatPumpCapex = 0;
  let wellCapex = 12.0; // $12M base for geothermal well sets
  let dcIntegrationCapex = 3.5; // $3.5M data centre tie-in
  
  if (state.netPowerOutputMW > 0) {
    baseTurbineCapex = state.netPowerOutputMW * 1.85; // $1.85M per MWe
  }
  if (state.districtHeatDeliveryMW > 0) {
    baseHeatPumpCapex = state.districtHeatDeliveryMW * 0.75; // $0.75M per MWth
  }
  
  let capexMillionUSD = (wellCapex + dcIntegrationCapex + baseTurbineCapex + baseHeatPumpCapex) * params.capitalCostFactor;
  
  // Adjust OPEX (approx 3.5% of CAPEX annually)
  let opexMillionUSD = capexMillionUSD * 0.038;

  // 2. Annual revenue calculation (8760 hrs * capacity factor)
  const capacityFactor = 0.92; // 92% uptime for base load energy/geothermal
  const hoursPerYear = 8760 * capacityFactor;
  
  // Pricing modifiers based on pricing scenarios
  let elecPriceMod = 1.0;
  let heatPriceMod = 1.0;
  
  switch (priceScenario) {
    case 'HIGH_PRICE':
      elecPriceMod = 1.6;
      heatPriceMod = 1.3;
      break;
    case 'LOW_PRICE':
      elecPriceMod = 0.5;
      heatPriceMod = 0.7;
      break;
    case 'VOLATILE_PRICE':
      elecPriceMod = 1.1; // slightly higher average but highly volatile
      heatPriceMod = 1.0;
      break;
    case 'NEGATIVE_PRICE':
      elecPriceMod = -0.15; // negative grid feed prices during peaks
      heatPriceMod = 0.9;
      break;
    default:
      elecPriceMod = 1.0;
      heatPriceMod = 1.0;
  }
  
  const effectiveElecPrice = params.electricityPriceBase * elecPriceMod;
  const effectiveHeatPrice = params.heatPriceBase * heatPriceMod;
  
  let electricityRevenue = 0;
  if (state.netPowerOutputMW > 0) {
    electricityRevenue = (state.netPowerOutputMW * hoursPerYear * effectiveElecPrice) / 1e6; // $M
  } else if (state.netPowerOutputMW < 0) {
    // Parasitic grid load cost
    electricityRevenue = (state.netPowerOutputMW * hoursPerYear * params.electricityPriceBase) / 1e6; // negative revenue (cost)
  }
  
  const heatRevenue = (state.districtHeatDeliveryMW * hoursPerYear * effectiveHeatPrice) / 1e6; // $M
  
  // Carbon Credits / Carbon Tax offset
  // We assume heat delivery offsets fossil fuel (natural gas) district heating
  // Natural gas boiler produces ~0.20 metric tons CO2 per MWh of thermal heat
  const carbonFactor = 0.20; // tons/MWh thermal
  const carbonOffsetTons = state.districtHeatDeliveryMW * hoursPerYear * carbonFactor;
  const carbonCreditsEarnedUSD = carbonOffsetTons * params.carbonTaxRate;
  const carbonRevenueMillion = carbonCreditsEarnedUSD / 1e6;
  
  const annualRevenueMillionUSD = Math.max(0, electricityRevenue + heatRevenue + carbonRevenueMillion);
  const annualOperatingCostMillionUSD = opexMillionUSD;
  const netCashFlowMillion = annualRevenueMillionUSD - annualOperatingCostMillionUSD;
  
  // Financial analysis (NPV, IRR over 20 year span, 7.5% discount rate)
  const discountRate = 0.075;
  const lifespan = 20;
  
  let netNPVMillionUSD = -capexMillionUSD;
  for (let year = 1; year <= lifespan; year++) {
    // 1% inflation on cashflows
    const inflatedCashFlow = netCashFlowMillion * Math.pow(1.012, year);
    netNPVMillionUSD += inflatedCashFlow / Math.pow(1 + discountRate, year);
  }
  
  // IRR calculations (solving for discount rate that yields NPV=0 via bisection)
  let irrPercent = 0;
  if (netCashFlowMillion > 0) {
    let low = -0.99;
    let high = 2.0;
    for (let i = 0; i < 50; i++) {
      let mid = (low + high) / 2;
      let tempNPV = -capexMillionUSD;
      for (let y = 1; y <= lifespan; y++) {
        tempNPV += (netCashFlowMillion * Math.pow(1.012, y)) / Math.pow(1 + mid, y);
      }
      if (tempNPV > 0) low = mid;
      else high = mid;
    }
    irrPercent = ((low + high) / 2) * 100;
  }
  
  // Levelized Cost of Energy (LCOE & LCOH)
  // Capital Recovery Factor (CRF) = [r * (1 + r)^n] / [(1 + r)^n - 1]
  const crf = (discountRate * Math.pow(1 + discountRate, lifespan)) / (Math.pow(1 + discountRate, lifespan) - 1);
  const annualizedCapitalCost = capexMillionUSD * crf;
  
  let lcoe_usd_mwh = 0;
  let lcoh_usd_mwh = 0;
  
  const annualElecGenerationMWh = Math.max(0, state.netPowerOutputMW) * hoursPerYear;
  const annualHeatGenerationMWh = state.districtHeatDeliveryMW * hoursPerYear;
  
  if (state.netPowerOutputMW > 0) {
    // Attribute 70% capital to electrical if both exist
    const electricityShare = state.districtHeatDeliveryMW > 0 ? 0.70 : 1.0;
    lcoe_usd_mwh = ((annualizedCapitalCost * electricityShare + opexMillionUSD * electricityShare) * 1e6) / annualElecGenerationMWh;
  }
  if (state.districtHeatDeliveryMW > 0) {
    const heatShare = state.netPowerOutputMW > 0 ? 0.30 : 1.0;
    lcoh_usd_mwh = ((annualizedCapitalCost * heatShare + opexMillionUSD * heatShare) * 1e6) / annualHeatGenerationMWh;
  }
  
  const paybackPeriodYears = netCashFlowMillion > 0 ? capexMillionUSD / netCashFlowMillion : 99;

  return {
    capexMillionUSD: parseFloat(capexMillionUSD.toFixed(2)),
    opexMillionUSD: parseFloat(opexMillionUSD.toFixed(2)),
    annualRevenueMillionUSD: parseFloat(annualRevenueMillionUSD.toFixed(2)),
    annualOperatingCostMillionUSD: parseFloat(annualOperatingCostMillionUSD.toFixed(2)),
    netNPVMillionUSD: parseFloat(netNPVMillionUSD.toFixed(2)),
    irrPercent: parseFloat(irrPercent.toFixed(2)),
    paybackPeriodYears: parseFloat(Math.min(99, paybackPeriodYears).toFixed(1)),
    carbonCreditsEarnedUSD: parseFloat(carbonCreditsEarnedUSD.toFixed(0)),
    lcoe_usd_mwh: parseFloat(lcoe_usd_mwh.toFixed(2)),
    lcoh_usd_mwh: parseFloat(lcoh_usd_mwh.toFixed(2)),
    calculated_by
  };
}

// --- MONTE CARLO RANDOM SCENARIO TRIAL SIMULATOR ---

export function runMonteCarlo(
  arch: EnergyArchitecture,
  priceScenario: PriceScenarioName,
  dcLoadMW: number,
  geoResourceMW: number,
  baseParams: {
    electricityPriceBase: number;
    heatPriceBase: number;
    carbonTaxRate: number;
    capitalCostFactor: number;
  },
  trials: number = 2000
): PercentileResult[] {
  const npvs: number[] = [];
  const irrs: number[] = [];
  const paybacks: number[] = [];
  
  // Standard Normal box-muller transform
  function randomNormal(mean: number, stdDev: number): number {
    let u = 0, v = 0;
    while(u === 0) u = Math.random(); 
    while(v === 0) v = Math.random();
    let num = Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
    return num * stdDev + mean;
  }

  for (let i = 0; i < trials; i++) {
    // Perturb input loads and thermal profiles (normal distributions)
    const wellTemp = randomNormal(125, 8.0); // mean 125°C, std 8°C
    const wellFlow = randomNormal(140, 15.0); // mean 140 kg/s, std 15
    const wasteHeatTemp = randomNormal(60, 4.0); // mean 60°C, std 4
    const trialDcLoad = Math.max(2.0, randomNormal(dcLoadMW, dcLoadMW * 0.15)); // std 15%
    
    // Perturb market / capital pricing
    const electPrice = Math.max(5, randomNormal(baseParams.electricityPriceBase, baseParams.electricityPriceBase * 0.20));
    const heatPrice = Math.max(5, randomNormal(baseParams.heatPriceBase, baseParams.heatPriceBase * 0.15));
    const capCostFactor = Math.max(0.7, randomNormal(baseParams.capitalCostFactor, baseParams.capitalCostFactor * 0.10));
    
    // Evaluate physics
    const trialPhys = computeThermodynamics(arch, wellTemp, wellFlow, wasteHeatTemp, trialDcLoad);
    // Evaluate economics
    const trialEcon = computeEconomics(trialPhys, {
      electricityPriceBase: electPrice,
      heatPriceBase: heatPrice,
      carbonTaxRate: baseParams.carbonTaxRate,
      capitalCostFactor: capCostFactor
    }, priceScenario);
    
    npvs.push(trialEcon.netNPVMillionUSD);
    irrs.push(trialEcon.irrPercent);
    paybacks.push(trialEcon.paybackPeriodYears);
  }

  // Sort lists
  npvs.sort((a, b) => a - b);
  irrs.sort((a, b) => a - b);
  paybacks.sort((a, b) => a - b);

  const getPercentile = (arr: number[], pct: number) => {
    const idx = Math.floor((pct / 100) * arr.length);
    return arr[Math.min(arr.length - 1, Math.max(0, idx))];
  };

  const percentiles: PercentileResult[] = [
    { percentile: 'P5', npvMillionUSD: getPercentile(npvs, 5), irrPercent: getPercentile(irrs, 5), paybackYears: getPercentile(paybacks, 95) }, // worst economics for paybacks is 95th percentile
    { percentile: 'P10', npvMillionUSD: getPercentile(npvs, 10), irrPercent: getPercentile(irrs, 10), paybackYears: getPercentile(paybacks, 90) },
    { percentile: 'P25', npvMillionUSD: getPercentile(npvs, 25), irrPercent: getPercentile(irrs, 25), paybackYears: getPercentile(paybacks, 75) },
    { percentile: 'P50', npvMillionUSD: getPercentile(npvs, 50), irrPercent: getPercentile(irrs, 50), paybackYears: getPercentile(paybacks, 50) },
    { percentile: 'P75', npvMillionUSD: getPercentile(npvs, 75), irrPercent: getPercentile(irrs, 75), paybackYears: getPercentile(paybacks, 25) },
    { percentile: 'P90', npvMillionUSD: getPercentile(npvs, 90), irrPercent: getPercentile(irrs, 90), paybackYears: getPercentile(paybacks, 10) },
    { percentile: 'P95', npvMillionUSD: getPercentile(npvs, 95), irrPercent: getPercentile(irrs, 95), paybackYears: getPercentile(paybacks, 5) }
  ];

  return percentiles;
}

// Seed Base Case Scenarios
const defaultScenarios: Scenario[] = [
  {
    id: 'base-case-orc',
    name: 'Base Case - ORC Plant',
    description: 'Direct power generation utilizing a medium-temperature Organic Rankine Cycle turbine, with passive waste-heat preheating.',
    architecture: 'ORC',
    priceScenario: 'BASE_CASE',
    dcLoadMW: 12.0,
    geothermalResourceMW: 35.0,
    parameters: { electricityPriceBase: 75.0, heatPriceBase: 42.0, carbonTaxRate: 50.0, capitalCostFactor: 1.0 },
    economics: { capexMillionUSD: 0, opexMillionUSD: 0, annualRevenueMillionUSD: 0, annualOperatingCostMillionUSD: 0, netNPVMillionUSD: 0, irrPercent: 0, paybackPeriodYears: 0, carbonCreditsEarnedUSD: 0, lcoe_usd_mwh: 0, lcoh_usd_mwh: 0, calculated_by: 'R_ECON_ENGINE_V3.0' },
    riskScore: 24
  },
  {
    id: 'high-growth-hp',
    name: 'High DC Growth - Heat Pump District Heating',
    description: 'High server densities. Recovers 22MW waste thermal boosted by highly efficient industrial district heating heat pumps.',
    architecture: 'HEAT_PUMP',
    priceScenario: 'HIGH_GROWTH',
    dcLoadMW: 25.0,
    geothermalResourceMW: 28.0,
    parameters: { electricityPriceBase: 80.0, heatPriceBase: 48.0, carbonTaxRate: 65.0, capitalCostFactor: 0.95 },
    economics: { capexMillionUSD: 0, opexMillionUSD: 0, annualRevenueMillionUSD: 0, annualOperatingCostMillionUSD: 0, netNPVMillionUSD: 0, irrPercent: 0, paybackPeriodYears: 0, carbonCreditsEarnedUSD: 0, lcoe_usd_mwh: 0, lcoh_usd_mwh: 0, calculated_by: 'R_ECON_ENGINE_V3.0' },
    riskScore: 32
  },
  {
    id: 'volatile-steam',
    name: 'Volatile Grid - Steam Turbine Integration',
    description: 'Geothermal production brine at 145°C driving steam cycle generators. Best suited for high peak electrical price capture.',
    architecture: 'STEAM',
    priceScenario: 'VOLATILE_PRICE',
    dcLoadMW: 8.0,
    geothermalResourceMW: 45.0,
    parameters: { electricityPriceBase: 95.0, heatPriceBase: 35.0, carbonTaxRate: 40.0, capitalCostFactor: 1.15 },
    economics: { capexMillionUSD: 0, opexMillionUSD: 0, annualRevenueMillionUSD: 0, annualOperatingCostMillionUSD: 0, netNPVMillionUSD: 0, irrPercent: 0, paybackPeriodYears: 0, carbonCreditsEarnedUSD: 0, lcoe_usd_mwh: 0, lcoh_usd_mwh: 0, calculated_by: 'R_ECON_ENGINE_V3.0' },
    riskScore: 48
  },
  {
    id: 'direct-district-dh',
    name: 'Low Carbon - Direct Heat Exchanger Grid',
    description: 'Zero turbine generation. Focuses solely on 100% direct-contact heat exchangers to satisfy local metropolitan heating demands.',
    architecture: 'DIRECT_HEAT',
    priceScenario: 'LOW_PRICE',
    dcLoadMW: 15.0,
    geothermalResourceMW: 40.0,
    parameters: { electricityPriceBase: 60.0, heatPriceBase: 38.0, carbonTaxRate: 70.0, capitalCostFactor: 0.85 },
    economics: { capexMillionUSD: 0, opexMillionUSD: 0, annualRevenueMillionUSD: 0, annualOperatingCostMillionUSD: 0, netNPVMillionUSD: 0, irrPercent: 0, paybackPeriodYears: 0, carbonCreditsEarnedUSD: 0, lcoe_usd_mwh: 0, lcoh_usd_mwh: 0, calculated_by: 'R_ECON_ENGINE_V3.0' },
    riskScore: 15
  }
];

// Initialize database scenarios with complete physics and economic runs
defaultScenarios.forEach(sc => {
  const pState = computeThermodynamics(sc.architecture, sc.geothermalResourceMW === 35.0 ? 128 : sc.geothermalResourceMW === 45.0 ? 146 : 115, 140, 60, sc.dcLoadMW);
  sc.economics = computeEconomics(pState, sc.parameters, sc.priceScenario);
  scenarioDatabase.set(sc.id, sc);
});

// --- RUST TELEMETRY GENERATOR & DATA LINEAGE PIPELINE ---

let driftOffset = 0.0;
let packetCount = 0;

function generateLiveSensors(): { packets: TelemetryPacket[], errors: ValidationError[] } {
  packetCount++;
  driftOffset += 0.002; // simulate slow sensor drift over time
  
  const timestamp = new Date().toISOString();
  const packets: TelemetryPacket[] = [];
  const errors: ValidationError[] = [];
  
  const sensors = [
    // Geothermal Wells
    { asset: 'GEOTHERMAL_WELL_01', id: 'WELL_TEMP_PROD', name: 'temperature', base: 132.5, unit: 'C', loc: 'Geothermal Wellhead' },
    { asset: 'GEOTHERMAL_WELL_01', id: 'WELL_PRESS_PROD', name: 'pressure', base: 18.4, unit: 'bar', loc: 'Geothermal Wellhead' },
    { asset: 'GEOTHERMAL_WELL_01', id: 'WELL_FLOW_PROD', name: 'flow', base: 142.1, unit: 'm3/h', loc: 'Geothermal Wellhead' },
    // Data Centre cooling
    { asset: 'DATA_CENTRE_SITE_A', id: 'DC_TEMP_OUTLET', name: 'temperature', base: 62.4, unit: 'C', loc: 'DC Heat Recovery Exchanger' },
    { asset: 'DATA_CENTRE_SITE_A', id: 'DC_FLOW_COOLANT', name: 'flow', base: 820.0, unit: 'm3/h', loc: 'DC Heat Recovery Exchanger' },
    { asset: 'DATA_CENTRE_SITE_A', id: 'DC_HUMID_AMBIENT', name: 'humidity', base: 45.2, unit: '%', loc: 'Server Row Hall 3' },
    // ORC Generator
    { asset: 'ORC_TURBINE_A', id: 'ORC_GEN_POWER', name: 'power', base: 8240.0, unit: 'kW', loc: 'Turbine Generator Block' },
    { asset: 'ORC_TURBINE_A', id: 'ORC_ROTATION_RPM', name: 'RPM', base: 3600.0, unit: 'RPM', loc: 'Turbine Rotor Shaft' },
    { asset: 'ORC_TURBINE_A', id: 'ORC_GEN_VOLTAGE', name: 'voltage', base: 11000.0, unit: 'V', loc: 'Main Bus Isolator' },
    { asset: 'ORC_TURBINE_A', id: 'ORC_GEN_CURRENT', name: 'current', base: 540.0, unit: 'A', loc: 'Main Bus Isolator' },
    // Heat Pumps
    { asset: 'DISTRICT_HEAT_PUMP_01', id: 'HP_WATER_QUALITY_PH', name: 'water quality', base: 7.8, unit: 'pH', loc: 'Condenser Infeed Pipe' },
    { asset: 'DISTRICT_HEAT_PUMP_01', id: 'HP_COMPRESSOR_POWER', name: 'power', base: 1150.0, unit: 'kW', loc: 'Compressor Motor' }
  ];

  sensors.forEach(s => {
    let noise = (Math.random() - 0.5) * (s.base * 0.015);
    let value = s.base + noise;
    let quality: 'GOOD' | 'BAD' | 'SUSPECT' | 'DRIFT' = 'GOOD';
    
    // Inject realistic physical drift on production well temp sensor
    if (s.id === 'WELL_TEMP_PROD') {
      value += driftOffset;
      if (driftOffset > 1.5) {
        quality = 'DRIFT';
        errors.push({
          error_type: 'SENSOR_DRIFT',
          sensor_id: s.id,
          timestamp,
          message: `Sensor drift detected. Output increased by ${driftOffset.toFixed(2)}°C relative to calibration threshold.`,
          severity: 'WARNING',
          payload: { drift_offset: driftOffset }
        });
      }
    }

    // 1% chance of duplicate packet drop (communication layer anomaly)
    const isDuplicate = Math.random() < 0.01;
    if (isDuplicate) {
      errors.push({
        error_type: 'DUPLICATE_DATA',
        sensor_id: s.id,
        timestamp,
        message: `Duplicate network packet ignored in sequence buffer.`,
        severity: 'WARNING',
        payload: { duplicate_sequence: telemetrySequence }
      });
    }

    // Random outlier spike injection (0.5% chance)
    if (Math.random() < 0.005) {
      const spikeFactor = Math.random() < 0.5 ? 4.0 : 0.0;
      value = s.base * spikeFactor;
      quality = 'SUSPECT';
      
      if (value === 0 && s.id.includes('TEMP')) {
        // Impossible absolute temperature in Celsius if physical boundary is broken
        errors.push({
          error_type: 'IMPOSSIBLE_VALUE',
          sensor_id: s.id,
          timestamp,
          message: `CRITICAL: Physically impossible absolute sensor output (0.00°C detected on critical loop).`,
          severity: 'CRITICAL',
          payload: { sensor_raw: value }
        });
      } else {
        errors.push({
          error_type: 'OUTLIER',
          sensor_id: s.id,
          timestamp,
          message: `Outlier filter triggered: Value ${value.toFixed(1)} deviates > 3σ from rolling average of ${s.base.toFixed(1)}.`,
          severity: 'WARNING',
          payload: { raw_value: value, expected: s.base }
        });
      }
    }

    packets.push({
      timestamp,
      asset_id: s.asset,
      sensor_id: s.id,
      measurement: s.name,
      value: parseFloat(value.toFixed(2)),
      unit: s.unit,
      quality,
      location: s.loc,
      source: 'RUST_INGEST_AGENT_V1.4',
      sequence_number: ++telemetrySequence
    });
  });

  return { packets, errors };
}

// --- API ENDPOINTS ---

// GET Live Telemetry & Ingestion logs (The Kotlin / Rust Bridge)
app.get('/api/telemetry/live', (req, res) => {
  const data = generateLiveSensors();
  res.json({
    status: 'online',
    pipeline: 'RUST_INGEST_AGENT_V1.4',
    timestamp: new Date().toISOString(),
    telemetry: data.packets,
    validation_errors: data.errors
  });
});

// GET Historical line data for charts
app.get('/api/telemetry/historical', (req, res) => {
  // Generates dummy timeline metrics covering the past 24 minutes
  const historical = [];
  const now = Date.now();
  for (let i = 24; i >= 0; i--) {
    const time = new Date(now - i * 60 * 1000).toISOString();
    historical.push({
      time: time.substring(11, 16),
      well_temp: parseFloat((125 + Math.sin(i / 3) * 1.5 + (Math.random() - 0.5) * 0.2).toFixed(1)),
      well_pressure: parseFloat((18.2 + Math.cos(i / 5) * 0.3 + (Math.random() - 0.5) * 0.05).toFixed(2)),
      net_power: parseFloat((8.2 + Math.sin(i / 4) * 0.4 + (Math.random() - 0.5) * 0.1).toFixed(2)),
      heat_recovery: parseFloat((12.5 + Math.cos(i / 2) * 0.6 + (Math.random() - 0.5) * 0.15).toFixed(2))
    });
  }
  res.json(historical);
});

// GET Scenarios
app.get('/api/scenarios', (req, res) => {
  res.json(Array.from(scenarioDatabase.values()));
});

// POST Scenario creation
app.post('/api/scenarios', (req, res) => {
  const { id, name, description, architecture, priceScenario, dcLoadMW, geothermalResourceMW, parameters } = req.body;
  
  if (!id || !name || !architecture) {
    return res.status(400).json({ error: 'Missing required scenario fields.' });
  }

  // Calculate economics & thermodynamics
  const pState = computeThermodynamics(architecture, geothermalResourceMW, 140, 60, dcLoadMW);
  const economics = computeEconomics(pState, parameters, priceScenario);
  
  const newScenario: Scenario = {
    id,
    name,
    description,
    architecture,
    priceScenario,
    dcLoadMW,
    geothermalResourceMW,
    parameters,
    economics,
    riskScore: Math.floor(20 + Math.random() * 40)
  };

  scenarioDatabase.set(id, newScenario);
  logAudit('tom@ahyx.org', 'OPERATOR_CONTROL', 'CREATE_SCENARIO', `Created scenario "${name}" with architecture ${architecture}.`);
  res.json(newScenario);
});

// GET Thermodynamic Calculation (Python Proxy endpoint)
app.post('/api/python/thermodynamics', (req, res) => {
  const { architecture, geothermalBrineTemp, geothermalMassFlow, dcWasteHeatTemp, dcCoolingLoad, efficiencyMultiplier } = req.body;
  const state = computeThermodynamics(
    architecture || 'ORC',
    Number(geothermalBrineTemp || 130),
    Number(geothermalMassFlow || 140),
    Number(dcWasteHeatTemp || 60),
    Number(dcCoolingLoad || 12.0),
    Number(efficiencyMultiplier || 1.0)
  );
  res.json(state);
});

// POST Run Monte Carlo Analysis (R Proxy endpoint)
app.post('/api/r/monte-carlo', (req, res) => {
  const { architecture, priceScenario, dcLoadMW, geothermalResourceMW, parameters, trials } = req.body;
  const numTrials = Math.min(10000, Number(trials || 3000));
  
  const percentiles = runMonteCarlo(
    architecture || 'ORC',
    priceScenario || 'BASE_CASE',
    Number(dcLoadMW || 12.0),
    Number(geothermalResourceMW || 35.0),
    parameters || { electricityPriceBase: 75, heatPriceBase: 42, carbonTaxRate: 50, capitalCostFactor: 1.0 },
    numTrials
  );

  // Frequency bins for cumulative probability histogram
  const p50NPV = percentiles.find(p => p.percentile === 'P50')?.npvMillionUSD || 10;
  const histogramData = Array.from({ length: 15 }, (_, i) => {
    const npvBin = parseFloat((p50NPV * 0.4 + (i * p50NPV * 0.1)).toFixed(1));
    // Simulated count curve centered roughly around P50
    const dev = Math.abs(npvBin - p50NPV);
    const frequency = Math.floor(Math.exp(-Math.pow(dev / (p50NPV * 0.3), 2)) * (numTrials / 5) + Math.random() * 20);
    return { npvBin, frequency };
  });

  const parameterSensitivities = [
    { parameter: 'Geothermal Temperature', sensitivityIndex: 0.85 },
    { parameter: 'Electricity Pricing Tariff', sensitivityIndex: 0.72 },
    { parameter: 'Data Centre Base Load', sensitivityIndex: 0.45 },
    { parameter: 'Carbon Credit Tax Factor', sensitivityIndex: 0.38 },
    { parameter: 'CAPEX Cost Overruns', sensitivityIndex: -0.61 },
    { parameter: 'Well Reinjection Resistance', sensitivityIndex: -0.24 }
  ];

  res.json({
    trialsRun: numTrials,
    timestamp: new Date().toISOString(),
    percentiles,
    histogramData,
    parameterSensitivities
  });
});

// GET Audit Logs
app.get('/api/security/audit', (req, res) => {
  res.json(auditLogs);
});

// GET Lineage provenance of derived metric (MW_THERMAL_RECOVERED, Exergy)
app.get('/api/lineage/:metric', (req, res) => {
  const { metric } = req.params;
  let node: ProvenanceNode;

  if (metric === 'NET_POWER_GENERATED') {
    node = {
      metric_name: 'NET_POWER_GENERATED',
      raw_value: 8.24,
      unit: 'MWe',
      source_sensors: ['ORC_GEN_POWER', 'ORC_ROTATION_RPM', 'WELL_FLOW_PROD'],
      calculation_version: 'PY_THERMO_TWIN_V2.1',
      timestamp: new Date().toISOString(),
      model_version: 'ORC_CYCLE_STEADY_STATE',
      mathematical_formula: 'P_net = Q_geo * η_turbine * η_carnot * 0.58 + Preheated_DH_Gain',
      input_datasets: ['LIVE_RUST_INGESTION_STREAM_ACTIVE', 'EQUIPMENT_CALIBRATION_SPEC_B4']
    };
  } else if (metric === 'MW_THERMAL_RECOVERED') {
    node = {
      metric_name: 'MW_THERMAL_RECOVERED',
      raw_value: 12.45,
      unit: 'MWth',
      source_sensors: ['DC_TEMP_OUTLET', 'DC_FLOW_COOLANT'],
      calculation_version: 'R_ECON_ENGINE_V3.0',
      timestamp: new Date().toISOString(),
      model_version: 'DATA_CENTRE_EXCHANGER_LINEAGE',
      mathematical_formula: 'Q_rec = m_coolant * Cp * (T_outlet - T_inlet)',
      input_datasets: ['LIVE_RUST_INGESTION_STREAM_ACTIVE']
    };
  } else {
    node = {
      metric_name: metric,
      raw_value: 62.4,
      unit: 'MWth',
      source_sensors: ['WELL_TEMP_PROD', 'WELL_FLOW_PROD'],
      calculation_version: 'PY_THERMO_TWIN_V2.1',
      timestamp: new Date().toISOString(),
      model_version: 'GEOTHERMAL_RESERVOIR_DRAWDOWN',
      mathematical_formula: 'Q_geo = m_brine * Cp * (T_well - T_reinjection)',
      input_datasets: ['LIVE_RUST_INGESTION_STREAM_ACTIVE']
    };
  }

  res.json(node);
});

// --- GEMINI AI POWERED RECOMMENDATION & GENERATIVE AUDIT REPORT ---

// POST AI Operational grid recommendations (Co-pilot)
app.post('/api/copilot/recommend', async (req, res) => {
  const { thermodynamicState, economics, priceScenario } = req.body;
  
  try {
    const ai = getAiClient();
    const prompt = `
You are the AI Energy Grid Optimization Co-Pilot for our integrated geothermal + data centre waste-heat system.
Analyze this technical and financial snapshot:

TECHNICAL STATE:
- Architecture: ${thermodynamicState.architecture}
- Geothermal Brine Temp: ${thermodynamicState.geothermalBrineTemp}°C
- Geothermal Mass Flow: ${thermodynamicState.geothermalMassFlow} kg/s
- DC Cooling Load: ${thermodynamicState.dcCoolingLoad} MWth
- Net Electrical Power Output: ${thermodynamicState.netPowerOutputMW} MWe
- District Heat Delivery: ${thermodynamicState.districtHeatDeliveryMW} MWth
- Overall System Efficiency: ${thermodynamicState.overallSystemEfficiency}%
- Exergy Efficiency: ${thermodynamicState.geothermalExergyEfficiency}%

ECONOMIC STATE:
- Active Price Scenario: ${priceScenario}
- CAPEX: $${economics.capexMillionUSD}M
- Annual Operating Cost: $${economics.annualOperatingCostMillionUSD}M
- Annual Project Revenue: $${economics.annualRevenueMillionUSD}M
- NPV (20 Years): $${economics.netNPVMillionUSD}M
- IRR: ${economics.irrPercent}%
- Levelized Cost of Electricity (LCOE): $${economics.lcoe_usd_mwh}/MWh
- Levelized Cost of Heat (LCOH): $${economics.lcoh_usd_mwh}/MWh

Please generate a highly professional operational grid report in Markdown format. Limit it to ~3 concise sections:
1. **Current System Efficiency & Constraint Auditing**: Focus on exergy and direct thermodynamic gains.
2. **Economic Grid Dispatch Optimization Strategy**: Provide specific grid dispatch strategies based on the active pricing scenario (${priceScenario}).
3. **Preventative Action Plan**: Note any potential physical degradation risks (scaling, thermal drawdown, well corrosion) or regulatory/carbon issues.

Maintain a highly objective, precise, and professional tone. Avoid generic AI fluff. Use technical terms.
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: prompt,
      config: {
        systemInstruction: 'You are an elite principal energy analyst and electrical grid optimization engineer specialized in hybrid high-density liquid-cooled data-centres and geothermal district energy systems.',
        temperature: 0.25,
      }
    });

    res.json({ recommendation: response.text });
  } catch (error: any) {
    console.error('Gemini Copilot Error:', error);
    res.status(500).json({ error: error.message || 'Failed to generate recommendations from Gemini.' });
  }
});

// POST AI Technical Audit Report Generation
app.post('/api/copilot/report', async (req, res) => {
  const { scenario, mcPercentiles } = req.body;
  
  try {
    const ai = getAiClient();
    const prompt = `
Generate a formal "Integrated Geothermal & High-Density Compute Waste Heat System Audit Report" in Markdown format for the executive board.

SCENARIO TARGET:
- Name: ${scenario.name}
- Architecture: ${scenario.architecture}
- Geothermal Resource: ${scenario.geothermalResourceMW} MWth
- DC Heat Influx: ${scenario.dcLoadMW} MW thermal
- Base NPV: $${scenario.economics.netNPVMillionUSD}M
- Base IRR: ${scenario.economics.irrPercent}%

R MONTE CARLO PROBABILITY METRICS (NPV in Millions):
- P5 (Downside Value at Risk): $${mcPercentiles?.find((p: any) => p.percentile === 'P5')?.npvMillionUSD || 'N/A'}M
- P50 (Expected Base Median): $${mcPercentiles?.find((p: any) => p.percentile === 'P50')?.npvMillionUSD || 'N/A'}M
- P95 (Upside Potential): $${mcPercentiles?.find((p: any) => p.percentile === 'P95')?.npvMillionUSD || 'N/A'}M

Format as a detailed board report with the following precise sections:
- **Executive Summary**
- **Core Thermodynamic Balance Assessment**
- **Financial Risk Modeling & Monte Carlo Probability Density** (discuss P5 vs P50 vs P95 NPV)
- **Grid Compliance & Carbon Abatement Multipliers** (discuss carbon credits of $${scenario.economics.carbonCreditsEarnedUSD})
- **Board Recommendation & Engineering Directives**

Strictly write in professional prose, with rich industrial terminology, avoiding promotional statements. Keep it highly detailed but concise enough for clear board presentation.
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.7-flash',
      contents: prompt,
      config: {
        systemInstruction: 'You are a Chief Technology Officer and Senior energy economics consultant writing technical-financial feasibility reports for energy infrastructure boards.',
        temperature: 0.15,
      }
    });

    res.json({ report: response.text });
  } catch (error: any) {
    console.error('Gemini Audit Report Error:', error);
    res.status(500).json({ error: error.message || 'Failed to compile technical audit report.' });
  }
});

// Seed default audit logs
logAudit('SYSTEM_PROCESS', 'SYSTEM_PROCESS', 'SYSTEM_BOOT', 'Rust Ingestion engine core running in high-performance validation thread.');
logAudit('SYSTEM_PROCESS', 'SYSTEM_PROCESS', 'DB_SYNC', 'Authorities aligned: Database declared primary ledger of system states.');

// --- INTEGRATING VITE DEV SERVER / STATIC ASSETS ---

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server successfully booted on port ${PORT}`);
  });
}

startServer();
