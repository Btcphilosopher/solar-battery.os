"""
examples/example_scenario.py
===============================

Fully reproducible example (spec section 19): build a 500 MW combined-cycle
LNG plant, optimise its dispatch against a 1,000,000 kg (1,000 t) LNG
inventory and a 400 MW demand over a 24-hour horizon, and print the full
report. No numerical results are hard-coded here -- everything is
calculated by the model at run time.

Run with::

    python examples/example_scenario.py
"""

from __future__ import annotations

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import CycleMode, EconomicConfig, OptimisationMode  # noqa: E402
from models.plant import LNGPlant, build_plant  # noqa: E402
from optimisation.optimiser import optimise_plant  # noqa: E402
from reporting.reports import format_report  # noqa: E402


def main() -> None:
    plant: LNGPlant = build_plant(
        name="Example-500MW-CCGT",
        rated_power_MW=500,
        minimum_stable_load=0.35,
        generator_efficiency=0.98,
        cycle_mode=CycleMode.COMBINED_CYCLE,
    )

    economics = EconomicConfig(
        electricity_price_per_MWh=80.0,
        lng_price_per_tonne=450.0,
        carbon_price_per_tonne_CO2=80.0,
    )

    lng_available_kg = 1_000_000  # 1,000 tonnes
    demand_MW = 400
    time_horizon_hours = 24

    result = optimise_plant(
        lng_available_kg=lng_available_kg,
        demand_MW=demand_MW,
        time_horizon_hours=time_horizon_hours,
        plant=plant,
        ambient_temperature=15.0,
        ambient_pressure=101.325,
        economics=economics,
        mode=OptimisationMode.BALANCED,
        timestep_seconds=60.0,
    )

    print(format_report(result, plant, economics, lng_available_kg))
    print()
    print("Raw result dict (spec section 9 return shape):")
    for k, v in result.as_dict().items():
        print(f"  {k}: {v}")


if __name__ == "__main__":
    main()
