"""
dashboard.py
=============

Streamlit optimisation dashboard.

Run with::

    streamlit run dashboard.py
"""

from __future__ import annotations

import streamlit as st

from config import AmbientConditions, CycleMode, EconomicConfig, OptimisationMode
from models.lng import LNGComposition
from models.plant import build_plant
from optimisation.optimiser import optimise_plant
from reporting import plots
from thermodynamics import properties as props

st.set_page_config(page_title="LNG Generator Optimisation Engine", layout="wide")

st.title("⚡ LNG Generator Optimisation Engine")
st.caption(
    "Physics-based dispatch optimisation for an LNG-fuelled power plant. "
    "All figures are engineering approximations for planning purposes -- see README for assumptions."
)

with st.sidebar:
    st.header("LNG")
    lng_tonnes = st.number_input("LNG available (tonnes)", min_value=0.0, value=100.0, step=10.0)
    st.subheader("Composition (mole fractions)")
    methane = st.slider("Methane", 0.80, 1.0, 0.925, 0.005)
    ethane = st.slider("Ethane", 0.0, 0.15, 0.055, 0.005)
    propane = st.slider("Propane", 0.0, 0.10, 0.015, 0.005)
    nitrogen = max(0.0, 1.0 - methane - ethane - propane)
    st.caption(f"Nitrogen (balance): {nitrogen:.3f}")

    st.header("Generator")
    capacity = st.number_input("Rated capacity (MW, gas turbine gross)", min_value=1.0, value=500.0, step=10.0)
    min_stable = st.slider("Minimum stable load (%)", 10, 80, 35) / 100.0
    cycle = st.selectbox("Cycle", ["combined", "simple"], index=0)
    ramp_up = st.number_input("Ramp-up rate (MW/min)", min_value=0.1, value=round(0.08 * capacity, 1))
    ramp_down = st.number_input("Ramp-down rate (MW/min)", min_value=0.1, value=round(0.10 * capacity, 1))

    st.header("Ambient")
    ambient_temp = st.slider("Ambient temperature (°C)", -20, 50, 15)
    ambient_pressure = st.number_input("Ambient pressure (kPa)", min_value=80.0, value=101.325)
    ambient_humidity = st.slider("Relative humidity (%)", 0, 100, 60) / 100.0
    elevation = st.number_input("Elevation (m)", value=0.0, step=100.0)

    st.header("Market")
    electricity_price = st.number_input("Electricity price (£/MWh)", min_value=0.0, value=80.0)
    lng_price = st.number_input("LNG price (£/tonne)", min_value=0.0, value=450.0)
    carbon_price = st.number_input("Carbon price (£/tCO2)", min_value=0.0, value=80.0)

    st.header("Simulation")
    demand = st.number_input("Demand (MW)", min_value=0.0, value=400.0, step=10.0)
    hours = st.number_input("Duration (hours)", min_value=0.5, value=24.0, step=1.0)
    mode = st.selectbox(
        "Optimisation mode",
        [m.value for m in OptimisationMode],
        index=[m.value for m in OptimisationMode].index("balanced"),
    )
    run = st.button("Run optimisation", type="primary")

if run:
    plant = build_plant(
        rated_power_MW=capacity,
        minimum_stable_load=min_stable,
        ramp_up_MW_per_min=ramp_up,
        ramp_down_MW_per_min=ramp_down,
        cycle_mode=CycleMode.COMBINED_CYCLE if cycle == "combined" else CycleMode.SIMPLE_CYCLE,
        composition=LNGComposition(methane_frac=methane, ethane_frac=ethane, propane_frac=propane, nitrogen_frac=nitrogen),
    )
    economics = EconomicConfig(
        electricity_price_per_MWh=electricity_price,
        lng_price_per_tonne=lng_price,
        carbon_price_per_tonne_CO2=carbon_price,
    )
    ambient = AmbientConditions(
        temperature_C=ambient_temp, pressure_kPa=ambient_pressure,
        relative_humidity=ambient_humidity, elevation_m=elevation,
    )

    with st.spinner("Optimising dispatch..."):
        result = optimise_plant(
            lng_available_kg=props.tonnes_to_kg(lng_tonnes),
            demand_MW=demand,
            time_horizon_hours=hours,
            plant=plant,
            ambient_temperature=ambient.temperature_C,
            ambient_pressure=ambient.pressure_kPa,
            ambient_humidity=ambient.relative_humidity,
            ambient_elevation_m=ambient.elevation_m,
            economics=economics,
            mode=OptimisationMode(mode),
            timestep_seconds=60.0,
        )

    st.subheader("PRIMARY RESULT")
    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric("OPTIMAL GENERATION", f"{result.optimal_output_MW:,.0f} MW")
    c2.metric("TOTAL ELECTRICITY", f"{result.total_MWh:,.0f} MWh")
    c3.metric("LNG CONSUMED", f"{props.kg_to_tonnes(result.lng_consumed_kg):,.1f} t")
    c4.metric("EFFICIENCY", f"{result.electrical_efficiency*100:,.1f} %")
    c5.metric("COST", f"£{result.cost_per_MWh:,.0f}/MWh")

    c6, c7, c8, c9 = st.columns(4)
    c6.metric("HEAT RATE", f"{result.heat_rate:,.2f} MMBtu/MWh")
    c7.metric("CO2", f"{props.kg_to_tonnes(result.co2_kg):,.1f} t")
    c8.metric("MARGINAL COST", f"£{result.marginal_cost_per_MWh:,.2f}/MWh")
    c9.metric("OPERATING MARGIN", f"£{result.operating_margin:,.0f}")

    if result.ran_out_of_fuel:
        st.warning("⚠️ LNG inventory was exhausted before the end of the time horizon.")

    st.subheader("Charts")
    tab1, tab2, tab3 = st.tabs(["Time series", "Efficiency & cost curves", "Energy flow"])

    with tab1:
        df = result.simulation.dataframe
        col1, col2 = st.columns(2)
        col1.line_chart(df.set_index("time_hours")[["demand_MW", "net_MW"]])
        col2.line_chart(df.set_index("time_hours")[["cumulative_net_MWh"]])
        col1.line_chart(df.set_index("time_hours")[["lng_remaining_kg"]])
        col2.line_chart(df.set_index("time_hours")[["electrical_efficiency"]])

    with tab2:
        col1, col2 = st.columns(2)
        with col1:
            fig = plots.plot_efficiency_vs_load(plant, ambient)
            st.pyplot(fig)
            fig2 = plots.plot_heat_rate_curve(plant, ambient)
            st.pyplot(fig2)
        with col2:
            fig3 = plots.plot_cost_vs_load(plant, ambient, economics)
            st.pyplot(fig3)
            fig4 = plots.plot_co2_vs_load(plant, ambient)
            st.pyplot(fig4)

    with tab3:
        best_pt = plant.operating_point(result.optimal_output_MW, ambient)
        fig5 = plots.plot_energy_flow_sankey(best_pt)
        st.pyplot(fig5)

    with st.expander("Full result table (raw simulation output)"):
        st.dataframe(result.simulation.dataframe)
else:
    st.info("Set your plant and market assumptions in the sidebar, then click **Run optimisation**.")
