import os

import pytest

from config import AmbientConditions, CycleMode, EconomicConfig, OptimisationMode
from models.plant import build_plant
from optimisation.optimiser import optimise_plant
from reporting import plots
from reporting.reports import format_report


@pytest.fixture
def plant():
    return build_plant(rated_power_MW=150.0, minimum_stable_load=0.35, cycle_mode=CycleMode.COMBINED_CYCLE)


@pytest.fixture
def ambient():
    return AmbientConditions()


@pytest.fixture
def result(plant):
    return optimise_plant(
        lng_available_kg=300_000.0, demand_MW=120.0, time_horizon_hours=4.0, plant=plant,
        economics=EconomicConfig(), mode=OptimisationMode.BALANCED, timestep_seconds=60.0,
    )


def test_format_report_contains_key_sections(result, plant):
    text = format_report(result, plant, EconomicConfig(), 300_000.0)
    for heading in ["LNG FUEL", "ELECTRICAL OUTPUT", "EFFICIENCY", "HEAT", "EMISSIONS", "ECONOMICS"]:
        assert heading in text


def test_all_plots_render_without_error(plant, ambient, result, tmp_path):
    economics = EconomicConfig()
    plots.plot_efficiency_vs_load(plant, ambient, str(tmp_path / "a.png"))
    plots.plot_lng_consumption_vs_output(plant, ambient, str(tmp_path / "b.png"))
    plots.plot_heat_rate_curve(plant, ambient, str(tmp_path / "c.png"))
    plots.plot_cost_vs_load(plant, ambient, economics, str(tmp_path / "d.png"))
    plots.plot_co2_vs_load(plant, ambient, str(tmp_path / "e.png"))
    plots.plot_output_vs_time(result.simulation, str(tmp_path / "f.png"))
    plots.plot_lng_consumption_vs_time(result.simulation, str(tmp_path / "g.png"))
    plots.plot_cumulative_mwh(result.simulation, str(tmp_path / "h.png"))
    plots.plot_lng_remaining(result.simulation, 300_000.0, str(tmp_path / "i.png"))
    plots.plot_dispatch_schedule(result.simulation, str(tmp_path / "j.png"))
    best_pt = plant.operating_point(result.optimal_output_MW, ambient)
    plots.plot_energy_flow_sankey(best_pt, str(tmp_path / "k.png"))

    for fname in "abcdefghijk":
        assert os.path.exists(tmp_path / f"{fname}.png")
        assert os.path.getsize(tmp_path / f"{fname}.png") > 0
