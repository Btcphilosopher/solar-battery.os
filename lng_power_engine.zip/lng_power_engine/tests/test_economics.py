import pytest

from config import AmbientConditions, CycleMode, EconomicConfig
from economics.costs import evaluate_operating_point, lng_price_per_MWh_th
from models.lng import LNGComposition
from models.plant import build_plant


@pytest.fixture
def plant():
    return build_plant(rated_power_MW=100.0, minimum_stable_load=0.3, cycle_mode=CycleMode.COMBINED_CYCLE)


@pytest.fixture
def ambient():
    return AmbientConditions()


def test_lng_price_per_mwh_th_from_tonne_price():
    comp = LNGComposition()
    econ = EconomicConfig(lng_price_per_tonne=450.0, lng_price_per_MWh_th=None)
    price = lng_price_per_MWh_th(econ, comp)
    assert price > 0


def test_lng_price_per_mwh_th_direct_override():
    comp = LNGComposition()
    econ = EconomicConfig(lng_price_per_tonne=None, lng_price_per_MWh_th=25.0)
    assert lng_price_per_MWh_th(econ, comp) == 25.0


def test_economic_config_requires_a_price():
    with pytest.raises(AssertionError):
        EconomicConfig(lng_price_per_tonne=None, lng_price_per_MWh_th=None)


def test_evaluate_operating_point_positive_costs(plant, ambient):
    econ = EconomicConfig()
    pt = plant.operating_point(70.0, ambient)
    result = evaluate_operating_point(pt, econ, plant.composition)
    assert result.fuel_cost_per_MWh > 0
    assert result.total_generation_cost_per_MWh > 0
    assert result.marginal_generation_cost_per_MWh > 0


def test_dispatch_recommendation_true_when_price_above_marginal_cost(plant, ambient):
    pt = plant.operating_point(70.0, ambient)
    cheap_lng = EconomicConfig(electricity_price_per_MWh=500.0, lng_price_per_tonne=100.0)
    result = evaluate_operating_point(pt, cheap_lng, plant.composition)
    assert result.dispatch_recommended


def test_dispatch_recommendation_false_when_price_below_marginal_cost(plant, ambient):
    pt = plant.operating_point(70.0, ambient)
    expensive_lng = EconomicConfig(electricity_price_per_MWh=1.0, lng_price_per_tonne=2000.0)
    result = evaluate_operating_point(pt, expensive_lng, plant.composition)
    assert not result.dispatch_recommended


def test_zero_output_point_has_zero_revenue(plant, ambient):
    econ = EconomicConfig()
    pt = plant.operating_point(0.0, ambient)
    result = evaluate_operating_point(pt, econ, plant.composition)
    assert result.gross_revenue == 0.0
    assert not result.dispatch_recommended
