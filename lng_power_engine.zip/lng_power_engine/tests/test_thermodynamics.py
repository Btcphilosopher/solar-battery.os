import math

import pytest

from thermodynamics import combustion as combustion_chem
from thermodynamics import properties as props
from thermodynamics.efficiency import (
    EfficiencyCurve,
    default_generator_curve,
    default_simple_cycle_gt_curve,
    heat_rate_MMBtu_per_MWh,
    electrical_efficiency_from_heat_rate_MMBtu_per_MWh,
)


# ---------------------------------------------------------------------------
# Unit conversions
# ---------------------------------------------------------------------------

def test_kg_tonnes_roundtrip():
    assert props.kg_to_tonnes(1000.0) == pytest.approx(1.0)
    assert props.tonnes_to_kg(1.0) == pytest.approx(1000.0)


def test_m3_kg_roundtrip():
    mass = props.m3_to_kg(10.0, 450.0)
    assert mass == pytest.approx(4500.0)
    assert props.kg_to_m3(mass, 450.0) == pytest.approx(10.0)


def test_mj_mwh_conversion_exact():
    assert props.mwh_to_mj(1.0) == pytest.approx(3600.0)
    assert props.mj_to_mwh(3600.0) == pytest.approx(1.0)


def test_mj_mmbtu_conversion():
    assert props.mmbtu_to_mj(1.0) == pytest.approx(1055.05585262)
    assert props.mj_to_mmbtu(1055.05585262) == pytest.approx(1.0)


def test_mwh_mmbtu_conversion_matches_known_constant():
    # 1 MWh ~= 3.412142 MMBtu
    assert props.mwh_to_mmbtu(1.0) == pytest.approx(3.412142, rel=1e-5)


def test_gj_mj_roundtrip():
    assert props.mj_to_gj(props.gj_to_mj(5.0)) == pytest.approx(5.0)


def test_zero_and_negative_inputs_raise_or_zero():
    assert props.kg_to_tonnes(0.0) == 0.0
    with pytest.raises(AssertionError):
        props.m3_to_kg(1.0, 0.0)
    with pytest.raises(AssertionError):
        props.m3_to_kg(1.0, -5.0)


# ---------------------------------------------------------------------------
# Ambient derating
# ---------------------------------------------------------------------------

def test_ambient_derate_factor_iso_conditions_is_near_unity():
    factor = props.ambient_derate_factor(15.0, 101.325, 0.60, 0.0)
    assert factor == pytest.approx(1.0, abs=0.02)


def test_ambient_derate_factor_hot_day_reduces_output():
    cold = props.ambient_derate_factor(10.0, 101.325, 0.6, 0.0)
    hot = props.ambient_derate_factor(40.0, 101.325, 0.6, 0.0)
    assert hot < cold, "hotter ambient air should derate turbine output"


def test_ambient_derate_factor_elevation_reduces_output():
    sea_level = props.ambient_derate_factor(15.0, 101.325, 0.6, elevation_m=0.0)
    high = props.ambient_derate_factor(15.0, 101.325, 0.6, elevation_m=2000.0)
    assert high < sea_level


# ---------------------------------------------------------------------------
# Combustion chemistry
# ---------------------------------------------------------------------------

def test_stoichiometric_air_pure_methane_matches_known_ratio():
    # Pure methane stoichiometric AFR is a well-known reference value ~17.2 kg air/kg fuel
    comp = {"methane": 1.0, "ethane": 0.0, "propane": 0.0, "nitrogen": 0.0}
    afr = combustion_chem.stoichiometric_air_kg_per_kg_fuel(comp)
    assert afr == pytest.approx(17.2, rel=0.03)


def test_co2_per_kg_methane_matches_known_ratio():
    # Complete combustion of 1 kg CH4 produces ~2.75 kg CO2
    comp = {"methane": 1.0, "ethane": 0.0, "propane": 0.0, "nitrogen": 0.0}
    co2 = combustion_chem.co2_kg_per_kg_fuel(comp)
    assert co2 == pytest.approx(2.75, rel=0.02)


def test_combust_energy_conservation():
    comp = {"methane": 0.9, "ethane": 0.06, "propane": 0.03, "nitrogen": 0.01}
    result = combustion_chem.combust(fuel_kg=1000.0, mole_fractions=comp, lhv_MJ_per_kg=49.0,
                                      excess_air_ratio=0.15, combustion_efficiency=1.0)
    assert result.exhaust_gas_kg == pytest.approx(result.fuel_kg + result.actual_air_kg)
    assert result.energy_released_MJ == pytest.approx(1000.0 * 49.0)


def test_combust_excess_air_increases_air_and_exhaust_mass():
    comp = {"methane": 1.0, "ethane": 0.0, "propane": 0.0, "nitrogen": 0.0}
    low = combustion_chem.combust(1000.0, comp, 50.0, excess_air_ratio=0.05, combustion_efficiency=0.995)
    high = combustion_chem.combust(1000.0, comp, 50.0, excess_air_ratio=0.30, combustion_efficiency=0.995)
    assert high.actual_air_kg > low.actual_air_kg
    assert high.exhaust_gas_kg > low.exhaust_gas_kg


def test_combust_zero_fuel_is_zero_everywhere():
    comp = {"methane": 1.0, "ethane": 0.0, "propane": 0.0, "nitrogen": 0.0}
    result = combustion_chem.combust(0.0, comp, 50.0)
    assert result.energy_released_MJ == 0.0
    assert result.co2_kg == 0.0


def test_combust_invalid_inputs_raise():
    comp = {"methane": 1.0, "ethane": 0.0, "propane": 0.0, "nitrogen": 0.0}
    with pytest.raises(AssertionError):
        combustion_chem.combust(-1.0, comp, 50.0)
    with pytest.raises(AssertionError):
        combustion_chem.combust(1.0, comp, 50.0, combustion_efficiency=1.5)
    with pytest.raises(AssertionError):
        combustion_chem.combust(1.0, comp, lhv_MJ_per_kg=0.0)


# ---------------------------------------------------------------------------
# Efficiency curves
# ---------------------------------------------------------------------------

def test_efficiency_curve_below_min_stable_is_zero():
    curve = default_simple_cycle_gt_curve(min_stable_load=0.2)
    assert curve(0.0) == 0.0
    assert curve(0.1) == 0.0


def test_efficiency_curve_within_physical_bounds():
    curve = default_simple_cycle_gt_curve(min_stable_load=0.2)
    for lf in [0.2, 0.4, 0.6, 0.8, 1.0]:
        eff = curve(lf)
        assert 0.0 < eff < 1.0


def test_efficiency_curve_rejects_bad_points():
    with pytest.raises(AssertionError):
        EfficiencyCurve(points=[(0.2, 1.2), (0.5, 0.3)])  # efficiency > 1
    with pytest.raises(AssertionError):
        EfficiencyCurve(points=[(0.2, 0.3), (0.2, 0.4)])  # duplicate load points


def test_heat_rate_roundtrip():
    eff = 0.45
    hr = heat_rate_MMBtu_per_MWh(eff)
    eff_back = electrical_efficiency_from_heat_rate_MMBtu_per_MWh(hr)
    assert eff_back == pytest.approx(eff, rel=1e-9)


def test_heat_rate_invalid_efficiency_raises():
    with pytest.raises(AssertionError):
        heat_rate_MMBtu_per_MWh(0.0)
    with pytest.raises(AssertionError):
        heat_rate_MMBtu_per_MWh(1.0)
