"""
tests/test_regression.py
===========================

Regression / golden-value tests: pin a fixed plant configuration + scenario
and assert the key outputs stay within a tight tolerance of the values
recorded at the time this test was written. If a deliberate model change
shifts these numbers, update the golden values here consciously (not
silently) and note why in the commit message.
"""

import pytest

from config import AmbientConditions, CycleMode, EconomicConfig, OptimisationMode, SimulationConfig
from models.lng import LNGInventory
from models.plant import build_plant
from optimisation.optimiser import optimise_plant
from simulation.simulation import run_simulation


@pytest.fixture
def golden_plant():
    return build_plant(
        name="golden-500MW-CCGT",
        rated_power_MW=500.0,
        minimum_stable_load=0.35,
        generator_efficiency=0.98,
        cycle_mode=CycleMode.COMBINED_CYCLE,
    )


@pytest.fixture
def golden_ambient():
    return AmbientConditions(temperature_C=15.0, pressure_kPa=101.325, relative_humidity=0.60, elevation_m=0.0)


def test_golden_operating_point_at_485MW(golden_plant, golden_ambient):
    # Golden values captured for this exact model configuration; a
    # deliberate model change may shift these -- update consciously.
    pt = golden_plant.operating_point(500.0 * 0.97, golden_ambient)
    assert pt.electrical_efficiency == pytest.approx(0.5140, abs=0.003)
    assert pt.heat_rate_MMBtu_per_MWh == pytest.approx(6.638, abs=0.05)
    assert pt.lng_kg_per_MWh == pytest.approx(142.30, abs=1.0)


def test_golden_net_capacity_and_minimum_stable(golden_plant, golden_ambient):
    assert golden_plant.net_capacity_MW(golden_ambient) == pytest.approx(691.7, rel=0.01)
    assert golden_plant.net_minimum_stable_MW(golden_ambient) == pytest.approx(285.7, rel=0.01)


def test_golden_simulation_24h_400MW_100kt(golden_plant, golden_ambient):
    inv = LNGInventory(composition=golden_plant.composition, mass_kg=100_000_000.0)  # 100,000 t, effectively unlimited
    sim_config = SimulationConfig(timestep_seconds=60.0, time_horizon_hours=24.0)
    result = run_simulation(golden_plant, inv, 400.0, sim_config, golden_ambient)
    assert result.total_net_MWh == pytest.approx(9511.5, rel=0.01)
    assert result.average_electrical_efficiency == pytest.approx(0.4909, abs=0.003)


def test_golden_optimise_plant_balanced_100kt(golden_plant, golden_ambient):
    economics = EconomicConfig(electricity_price_per_MWh=80.0, lng_price_per_tonne=450.0, carbon_price_per_tonne_CO2=80.0)
    result = optimise_plant(
        lng_available_kg=100_000_000.0,
        demand_MW=400.0,
        time_horizon_hours=24.0,
        plant=golden_plant,
        ambient_temperature=golden_ambient.temperature_C,
        ambient_pressure=golden_ambient.pressure_kPa,
        economics=economics,
        mode=OptimisationMode.BALANCED,
        timestep_seconds=60.0,
    )
    assert result.total_MWh > 9000.0
    assert 0.0 < result.electrical_efficiency < 0.62
