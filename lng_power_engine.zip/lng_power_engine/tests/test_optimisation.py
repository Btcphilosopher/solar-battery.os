import pytest

from config import AmbientConditions, CycleMode, EconomicConfig, OptimisationMode
from models.plant import build_plant
from optimisation.benchmark import run_benchmark
from optimisation.optimiser import optimise_plant
from optimisation.scenario import Scenario, run_scenarios


@pytest.fixture
def plant():
    return build_plant(rated_power_MW=150.0, minimum_stable_load=0.35, cycle_mode=CycleMode.COMBINED_CYCLE)


@pytest.fixture
def ambient():
    return AmbientConditions()


@pytest.fixture
def economics():
    return EconomicConfig(electricity_price_per_MWh=90.0, lng_price_per_tonne=450.0, carbon_price_per_tonne_CO2=80.0)


def test_optimise_plant_max_mwh_respects_demand_cap(plant, economics):
    result = optimise_plant(
        lng_available_kg=500_000.0, demand_MW=120.0, time_horizon_hours=6.0, plant=plant,
        economics=economics, mode=OptimisationMode.MAX_MWH, timestep_seconds=60.0,
    )
    assert result.optimal_output_MW <= 120.0 + 1e-3
    assert result.total_MWh > 0
    assert not result.ran_out_of_fuel


def test_optimise_plant_max_efficiency_finds_sensible_point(plant, economics):
    result = optimise_plant(
        lng_available_kg=500_000.0, demand_MW=150.0, time_horizon_hours=6.0, plant=plant,
        economics=economics, mode=OptimisationMode.MAX_EFFICIENCY, timestep_seconds=60.0,
    )
    assert 0.0 < result.electrical_efficiency < 1.0


def test_optimise_plant_min_fuel_beats_naive_full_output(plant, economics):
    naive = optimise_plant(
        lng_available_kg=500_000.0, demand_MW=150.0, time_horizon_hours=6.0, plant=plant,
        economics=economics, mode=OptimisationMode.MAX_MWH, timestep_seconds=60.0,
    )
    min_fuel = optimise_plant(
        lng_available_kg=500_000.0, demand_MW=150.0, time_horizon_hours=6.0, plant=plant,
        economics=economics, mode=OptimisationMode.MIN_FUEL, timestep_seconds=60.0,
    )
    naive_fuel_per_mwh = naive.lng_consumed_kg / naive.total_MWh
    opt_fuel_per_mwh = min_fuel.lng_consumed_kg / min_fuel.total_MWh
    assert opt_fuel_per_mwh <= naive_fuel_per_mwh + 1e-6


def test_optimise_plant_fuel_constrained_scenario_stays_within_inventory(plant, economics):
    result = optimise_plant(
        lng_available_kg=5_000.0, demand_MW=150.0, time_horizon_hours=24.0, plant=plant,
        economics=economics, mode=OptimisationMode.MAX_MWH, timestep_seconds=60.0,
    )
    assert result.lng_consumed_kg <= 5_000.0 + 1e-3
    assert result.lng_remaining_kg >= -1e-3


def test_optimise_plant_zero_lng_produces_nothing(plant, economics):
    result = optimise_plant(
        lng_available_kg=0.0, demand_MW=100.0, time_horizon_hours=2.0, plant=plant,
        economics=economics, mode=OptimisationMode.BALANCED, timestep_seconds=60.0,
    )
    assert result.total_MWh == pytest.approx(0.0, abs=1e-6)


def test_optimise_plant_balanced_mode_runs(plant, economics):
    result = optimise_plant(
        lng_available_kg=500_000.0, demand_MW=150.0, time_horizon_hours=6.0, plant=plant,
        economics=economics, mode=OptimisationMode.BALANCED, timestep_seconds=60.0,
    )
    assert result.total_MWh > 0


def test_optimise_plant_max_profit_mode_runs(plant, economics):
    result = optimise_plant(
        lng_available_kg=500_000.0, demand_MW=150.0, time_horizon_hours=6.0, plant=plant,
        economics=economics, mode=OptimisationMode.MAX_PROFIT, timestep_seconds=60.0,
    )
    assert result.total_MWh >= 0


def test_benchmark_optimised_never_worse_than_naive_on_mwh(plant, economics, ambient):
    b = run_benchmark(
        plant=plant, lng_available_kg=5_000.0, demand_MW=150.0, time_horizon_hours=24.0,
        ambient=ambient, economics=economics, timestep_seconds=60.0, optimisation_mode=OptimisationMode.MAX_MWH,
    )
    assert b.optimised_MWh >= b.naive_MWh - 1e-6


def test_scenario_runner_returns_dataframe_with_all_scenarios(plant, economics):
    scenarios = [
        Scenario(name="s1", lng_tonnes=50, demand_MW=100, duration_hours=4),
        Scenario(name="s2", lng_tonnes=20, demand_MW=100, duration_hours=4),
    ]
    df = run_scenarios(scenarios, plant, economics, timestep_seconds=60.0)
    assert len(df) == 2
    assert set(df["scenario"]) == {"s1", "s2"}
    assert (df["total_MWh"] >= 0).all()
