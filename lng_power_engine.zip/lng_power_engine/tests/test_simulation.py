import pytest

from config import AmbientConditions, CycleMode, SimulationConfig
from models.lng import LNGInventory
from models.plant import build_plant
from optimisation.dispatch import UnitState, build_dispatch_trajectory, constant_demand_profile
from simulation.simulation import run_simulation
from simulation.timestep import run_timestep


@pytest.fixture
def plant():
    return build_plant(rated_power_MW=100.0, minimum_stable_load=0.3, ramp_up_MW_per_min=5.0,
                        ramp_down_MW_per_min=5.0, startup_time_min=5.0, shutdown_time_min=2.0,
                        cycle_mode=CycleMode.SIMPLE_CYCLE)


@pytest.fixture
def ambient():
    return AmbientConditions()


def test_dispatch_never_exceeds_ramp_rate(plant, ambient):
    demand = constant_demand_profile(90.0, 60)
    traj = build_dispatch_trajectory(plant, ambient, demand, timestep_seconds=60.0)
    max_step = plant.ramp.ramp_up_MW_per_min * 1.0  # 1 minute steps
    # The one exception is the STARTING -> RUNNING transition, where the
    # unit is expected to jump directly to minimum stable load (per spec
    # section 7: "0 MW -> startup -> minimum stable output -> ramp -> ...").
    # Every other consecutive step, while RUNNING, must respect the ramp rate.
    for a, b in zip(traj, traj[1:]):
        if a.state == UnitState.RUNNING and b.state == UnitState.RUNNING:
            assert b.target_MW - a.target_MW <= max_step + 1e-6


def test_dispatch_starts_from_zero_not_instant_jump(plant, ambient):
    demand = constant_demand_profile(90.0, 30)
    traj = build_dispatch_trajectory(plant, ambient, demand, timestep_seconds=60.0)
    assert traj[0].target_MW == 0.0
    assert traj[0].state == UnitState.OFF  # demand arrives at t=0, unit begins starting from next step
    assert traj[1].state == UnitState.STARTING
    assert traj[1].target_MW == 0.0
    # unit must not be at full output soon after
    assert traj[2].target_MW < 90.0


def test_dispatch_reaches_demand_eventually(plant, ambient):
    demand = constant_demand_profile(70.0, 60)
    traj = build_dispatch_trajectory(plant, ambient, demand, timestep_seconds=60.0)
    assert traj[-1].target_MW == pytest.approx(70.0, rel=1e-3)


def test_dispatch_shuts_down_when_demand_drops_to_zero(plant, ambient):
    demand = [80.0] * 20 + [0.0] * 20
    traj = build_dispatch_trajectory(plant, ambient, demand, timestep_seconds=60.0)
    assert traj[-1].state in (UnitState.OFF, UnitState.STOPPING)
    assert traj[-1].target_MW == pytest.approx(0.0, abs=1e-6)


def test_timestep_consumes_lng_and_updates_inventory(plant, ambient):
    inv = LNGInventory(composition=plant.composition, mass_kg=100_000.0)
    result = run_timestep(plant, 70.0, ambient, inv, timestep_seconds=60.0)
    assert result.lng_consumed_kg > 0
    assert inv.mass_kg == pytest.approx(100_000.0 - result.lng_consumed_kg)
    assert result.lng_remaining_kg == pytest.approx(inv.mass_kg)


def test_timestep_fuel_exhaustion_scales_down_output(plant, ambient):
    inv = LNGInventory(composition=plant.composition, mass_kg=1.0)  # tiny inventory
    result = run_timestep(plant, 70.0, ambient, inv, timestep_seconds=60.0)
    assert result.fuel_limited
    assert inv.mass_kg == pytest.approx(0.0, abs=1e-6)


def test_run_simulation_basic_energy_and_fuel_accounting(plant, ambient):
    inv = LNGInventory(composition=plant.composition, mass_kg=200_000.0)
    sim_config = SimulationConfig(timestep_seconds=60.0, time_horizon_hours=2.0)
    result = run_simulation(plant, inv, 70.0, sim_config, ambient)
    assert result.total_net_MWh > 0
    assert result.total_lng_consumed_kg > 0
    assert result.lng_remaining_kg == pytest.approx(200_000.0 - result.total_lng_consumed_kg, rel=1e-6)
    assert 0.0 < result.average_electrical_efficiency < 1.0
    assert not result.ran_out_of_fuel


def test_run_simulation_runs_out_of_fuel_flag(plant, ambient):
    inv = LNGInventory(composition=plant.composition, mass_kg=50.0)  # far too little
    sim_config = SimulationConfig(timestep_seconds=60.0, time_horizon_hours=2.0)
    result = run_simulation(plant, inv, 90.0, sim_config, ambient)
    assert result.ran_out_of_fuel
    assert result.lng_remaining_kg == pytest.approx(0.0, abs=1e-3)


def test_run_simulation_demand_series_length_mismatch_raises(plant, ambient):
    inv = LNGInventory(composition=plant.composition, mass_kg=100_000.0)
    sim_config = SimulationConfig(timestep_seconds=60.0, time_horizon_hours=1.0)
    with pytest.raises(AssertionError):
        run_simulation(plant, inv, [50.0, 60.0], sim_config, ambient)  # too short


def test_run_simulation_zero_demand_produces_nothing(plant, ambient):
    inv = LNGInventory(composition=plant.composition, mass_kg=100_000.0)
    sim_config = SimulationConfig(timestep_seconds=60.0, time_horizon_hours=1.0)
    result = run_simulation(plant, inv, 0.0, sim_config, ambient)
    assert result.total_net_MWh == pytest.approx(0.0)
    assert result.total_lng_consumed_kg == pytest.approx(0.0)


def test_cumulative_columns_are_monotonically_nondecreasing(plant, ambient):
    inv = LNGInventory(composition=plant.composition, mass_kg=200_000.0)
    sim_config = SimulationConfig(timestep_seconds=60.0, time_horizon_hours=1.0)
    result = run_simulation(plant, inv, 60.0, sim_config, ambient)
    df = result.dataframe
    assert (df["cumulative_net_MWh"].diff().dropna() >= -1e-9).all()
    assert (df["cumulative_lng_consumed_kg"].diff().dropna() >= -1e-9).all()
