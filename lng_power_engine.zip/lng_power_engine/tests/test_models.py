import pytest

from config import AmbientConditions, CycleMode, RampConfig
from models.combustion import CombustionModel
from models.generator import Generator
from models.heat_recovery import HeatRecoverySystem
from models.lng import LNGComposition, LNGInventory
from models.plant import LNGPlant, build_plant
from models.turbine import GasTurbine


# ---------------------------------------------------------------------------
# LNG composition & inventory
# ---------------------------------------------------------------------------

def test_default_composition_sums_to_one():
    comp = LNGComposition()
    total = comp.methane_frac + comp.ethane_frac + comp.propane_frac + comp.nitrogen_frac
    assert total == pytest.approx(1.0)


def test_composition_rejects_bad_sum():
    with pytest.raises(AssertionError):
        LNGComposition(methane_frac=0.9, ethane_frac=0.2, propane_frac=0.0, nitrogen_frac=0.0)


def test_composition_lhv_between_pure_component_bounds():
    comp = LNGComposition(methane_frac=0.9, ethane_frac=0.06, propane_frac=0.03, nitrogen_frac=0.01)
    assert 46.0 < comp.lhv_MJ_per_kg < 50.5


def test_composition_lhv_override():
    comp = LNGComposition(lhv_MJ_per_kg_override=48.5)
    assert comp.lhv_MJ_per_kg == 48.5


def test_lng_inventory_from_mass():
    inv = LNGInventory(mass_kg=1000.0, density_kg_per_m3=450.0)
    assert inv.volume_m3 == pytest.approx(1000.0 / 450.0)


def test_lng_inventory_from_volume():
    inv = LNGInventory(volume_m3=10.0, density_kg_per_m3=450.0)
    assert inv.mass_kg == pytest.approx(4500.0)


def test_lng_inventory_requires_mass_or_volume():
    with pytest.raises(ValueError):
        LNGInventory()


def test_lng_inventory_chemical_energy_conversions():
    inv = LNGInventory(mass_kg=1000.0)
    mj = inv.chemical_energy_MJ
    assert inv.chemical_energy_MWh == pytest.approx(mj / 3600.0)
    assert inv.chemical_energy_GJ == pytest.approx(mj / 1000.0)
    assert inv.chemical_energy_MMBtu == pytest.approx(mj / 1055.05585262)


def test_lng_inventory_consume_reduces_mass_and_returns_energy():
    inv = LNGInventory(mass_kg=1000.0)
    lhv = inv.composition.lhv_MJ_per_kg
    energy = inv.consume(200.0)
    assert inv.mass_kg == pytest.approx(800.0)
    assert energy == pytest.approx(200.0 * lhv)


def test_lng_inventory_consume_more_than_available_raises():
    inv = LNGInventory(mass_kg=100.0)
    with pytest.raises(ValueError):
        inv.consume(200.0)


def test_lng_inventory_consume_negative_raises():
    inv = LNGInventory(mass_kg=100.0)
    with pytest.raises(AssertionError):
        inv.consume(-10.0)


# ---------------------------------------------------------------------------
# Generator & Turbine
# ---------------------------------------------------------------------------

def test_generator_efficiency_in_bounds():
    gen = Generator(rated_capacity_MVA=100.0)
    for lf in [0.2, 0.5, 0.8, 1.0]:
        assert 0.9 < gen.efficiency(lf) < 1.0


def test_generator_output_scales_with_mechanical_power():
    gen = Generator(rated_capacity_MVA=100.0)
    out_low = gen.electrical_output_MW(10.0, 0.2)
    out_high = gen.electrical_output_MW(50.0, 0.8)
    assert out_high > out_low


def test_turbine_derated_capacity_positive():
    ramp = RampConfig(minimum_output_MW=50, maximum_output_MW=200, ramp_up_MW_per_min=10,
                       ramp_down_MW_per_min=10, minimum_stable_load=0.25)
    gt = GasTurbine(rated_power_MW=200.0, ramp=ramp)
    ambient = AmbientConditions(temperature_C=25.0)
    assert gt.derated_capacity_MW(ambient) > 0


def test_ramp_config_rejects_invalid():
    with pytest.raises(AssertionError):
        RampConfig(minimum_output_MW=10, maximum_output_MW=0, ramp_up_MW_per_min=1,
                   ramp_down_MW_per_min=1, minimum_stable_load=0.3)
    with pytest.raises(AssertionError):
        RampConfig(minimum_output_MW=10, maximum_output_MW=100, ramp_up_MW_per_min=1,
                   ramp_down_MW_per_min=1, minimum_stable_load=1.5)


# ---------------------------------------------------------------------------
# Plant operating point / energy conservation / boundary conditions
# ---------------------------------------------------------------------------

@pytest.fixture
def simple_plant():
    return build_plant(rated_power_MW=200.0, minimum_stable_load=0.3, cycle_mode=CycleMode.SIMPLE_CYCLE)


@pytest.fixture
def combined_plant():
    return build_plant(rated_power_MW=200.0, minimum_stable_load=0.3, cycle_mode=CycleMode.COMBINED_CYCLE)


@pytest.fixture
def ambient_iso():
    return AmbientConditions()


def test_zero_demand_gives_zero_point(simple_plant, ambient_iso):
    pt = simple_plant.operating_point(0.0, ambient_iso)
    assert pt.net_electrical_MW == 0.0
    assert pt.fuel_flow_kg_per_hr == 0.0


def test_output_never_exceeds_capacity(simple_plant, ambient_iso):
    capacity = simple_plant.net_capacity_MW(ambient_iso)
    pt = simple_plant.operating_point(capacity * 10, ambient_iso)  # absurd overrequest
    assert pt.net_electrical_MW <= capacity + 1e-6


def test_output_respects_minimum_stable_load(simple_plant, ambient_iso):
    tiny_request = 1e-3
    pt = simple_plant.operating_point(tiny_request, ambient_iso)
    min_stable = simple_plant.net_minimum_stable_MW(ambient_iso)
    assert pt.net_electrical_MW == pytest.approx(min_stable, rel=1e-6)


def test_efficiency_within_physical_bounds(simple_plant, combined_plant, ambient_iso):
    for plant in (simple_plant, combined_plant):
        pt = plant.operating_point(plant.rated_capacity_MW(ambient_iso) * 0.7, ambient_iso)
        assert 0.0 < pt.electrical_efficiency < 1.0
        assert 0.0 < pt.gross_electrical_efficiency < 1.0
        assert pt.fuel_flow_kg_per_hr >= 0.0


def test_combined_cycle_more_efficient_than_simple_cycle(simple_plant, combined_plant, ambient_iso):
    mw = 150.0
    pt_simple = simple_plant.operating_point(mw, ambient_iso)
    pt_combined = combined_plant.operating_point(mw, ambient_iso)
    assert pt_combined.electrical_efficiency > pt_simple.electrical_efficiency


def test_energy_conservation_across_load_range(combined_plant, ambient_iso):
    capacity = combined_plant.net_capacity_MW(ambient_iso)
    min_stable = combined_plant.net_minimum_stable_MW(ambient_iso)
    for frac in [0.0, 0.25, 0.5, 0.75, 1.0]:
        mw = min_stable + frac * (capacity - min_stable)
        pt = combined_plant.operating_point(mw, ambient_iso)
        total_out = pt.net_electrical_MW + pt.auxiliary_load_MW + pt.process_heat_MW + pt.waste_heat_MW
        assert total_out == pytest.approx(pt.fuel_energy_rate_MW, rel=1e-6, abs=1e-6)


def test_hot_ambient_reduces_capacity(simple_plant):
    cold = AmbientConditions(temperature_C=10.0)
    hot = AmbientConditions(temperature_C=40.0)
    assert simple_plant.rated_capacity_MW(hot) < simple_plant.rated_capacity_MW(cold)


def test_negative_target_treated_as_zero(simple_plant, ambient_iso):
    pt = simple_plant.operating_point(-50.0, ambient_iso)
    assert pt.net_electrical_MW == 0.0


def test_co2_emissions_scale_with_fuel_flow(simple_plant, ambient_iso):
    pt_low = simple_plant.operating_point(80.0, ambient_iso)
    pt_high = simple_plant.operating_point(140.0, ambient_iso)
    assert pt_high.co2_kg_per_hr > pt_low.co2_kg_per_hr


def test_heat_recovery_disabled_means_zero_recoverable(simple_plant, ambient_iso):
    pt = simple_plant.operating_point(150.0, ambient_iso)
    assert pt.recoverable_heat_MW == 0.0


def test_heat_recovery_enabled_recovers_some_heat(combined_plant, ambient_iso):
    pt = combined_plant.operating_point(150.0, ambient_iso)
    assert pt.recoverable_heat_MW > 0.0
    assert pt.steam_electrical_MW > 0.0


def test_extreme_ambient_conditions_still_physical(simple_plant):
    hot_humid_low = AmbientConditions(temperature_C=45.0, pressure_kPa=95.0, relative_humidity=0.95, elevation_m=1500.0)
    pt = simple_plant.operating_point(50.0, hot_humid_low)
    assert 0.0 <= pt.electrical_efficiency < 1.0
    assert pt.net_electrical_MW >= 0.0
