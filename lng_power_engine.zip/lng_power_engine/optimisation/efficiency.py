"""
optimisation/efficiency.py
=============================

Part-load efficiency exploration helpers: sampling the plant's efficiency
and fuel-consumption curves across its operating range, and locating the
best-efficiency operating point with SciPy.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd
from scipy.optimize import minimize_scalar

from config import AmbientConditions
from models.plant import LNGPlant


@dataclass
class EfficiencyProfile:
    dataframe: pd.DataFrame
    best_efficiency_MW: float
    best_efficiency: float


def sample_efficiency_curve(plant: LNGPlant, ambient: AmbientConditions, n_points: int = 41) -> EfficiencyProfile:
    """Sample net electrical output, efficiency, heat rate and LNG
    consumption across the plant's full feasible operating range.
    """
    capacity_MW = plant.net_capacity_MW(ambient)
    min_stable_MW = plant.net_minimum_stable_MW(ambient)

    loads = np.linspace(min_stable_MW, capacity_MW, n_points)
    rows = []
    for mw in loads:
        pt = plant.operating_point(float(mw), ambient)
        rows.append(
            {
                "net_MW": pt.net_electrical_MW,
                "load_fraction": pt.load_fraction,
                "electrical_efficiency": pt.electrical_efficiency,
                "heat_rate_MMBtu_per_MWh": pt.heat_rate_MMBtu_per_MWh,
                "lng_kg_per_MWh": pt.lng_kg_per_MWh,
                "fuel_flow_kg_per_hr": pt.fuel_flow_kg_per_hr,
                "co2_kg_per_hr": pt.co2_kg_per_hr,
                "waste_heat_MW": pt.waste_heat_MW,
                "recoverable_heat_MW": pt.recoverable_heat_MW,
            }
        )
    df = pd.DataFrame(rows)

    def neg_eff(mw: float) -> float:
        return -plant.operating_point(float(mw), ambient).electrical_efficiency

    result = minimize_scalar(neg_eff, bounds=(min_stable_MW, capacity_MW), method="bounded", options={"xatol": 1e-3})
    best_MW = float(result.x)
    best_eff = -float(result.fun)

    return EfficiencyProfile(dataframe=df, best_efficiency_MW=best_MW, best_efficiency=best_eff)
