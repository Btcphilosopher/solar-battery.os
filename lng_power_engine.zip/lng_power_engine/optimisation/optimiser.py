"""
optimisation/optimiser.py
============================

Top-level optimisation engine: ``optimise_plant`` searches over feasible
constant dispatch setpoints (bounded by minimum stable load and the lower
of rated capacity / demand) and, for each candidate, runs a *genuine
time-dependent simulation* (ramp/start-up limited dispatch, part-load
efficiency, fuel draw-down, heat recovery, emissions, economics) via
``simulation.simulation.run_simulation``. SciPy's bounded scalar minimiser
drives the search, so the result reflects real plant dynamics rather than
a single steady-state efficiency lookup.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from scipy.optimize import minimize_scalar

from config import (
    AmbientConditions,
    EconomicConfig,
    OptimisationMode,
    OptimisationWeights,
    SimulationConfig,
)
from economics.costs import evaluate_simulation
from models.lng import LNGInventory
from models.plant import LNGPlant
from simulation.simulation import SimulationResult, run_simulation


@dataclass
class OptimisationResult:
    # --- required by spec ---
    optimal_output_MW: float
    total_MWh: float
    lng_consumed_kg: float
    electrical_efficiency: float
    heat_rate: float
    waste_heat_MWh: float
    recoverable_heat_MWh: float
    co2_kg: float
    cost_per_MWh: float

    # --- extended reporting ---
    lng_remaining_kg: float
    total_gross_MWh: float
    lng_kg_per_MWh: float
    marginal_cost_per_MWh: float
    gross_revenue: float
    operating_margin: float
    ran_out_of_fuel: bool
    optimisation_mode: OptimisationMode
    simulation: SimulationResult
    score_evaluations: int

    def as_dict(self) -> dict:
        return {
            "optimal_output_MW": self.optimal_output_MW,
            "total_MWh": self.total_MWh,
            "lng_consumed_kg": self.lng_consumed_kg,
            "electrical_efficiency": self.electrical_efficiency,
            "heat_rate": self.heat_rate,
            "waste_heat_MWh": self.waste_heat_MWh,
            "recoverable_heat_MWh": self.recoverable_heat_MWh,
            "co2_kg": self.co2_kg,
            "cost_per_MWh": self.cost_per_MWh,
        }


def _fresh_inventory(template: LNGInventory, mass_kg: float) -> LNGInventory:
    return LNGInventory(
        composition=template.composition,
        mass_kg=mass_kg,
        density_kg_per_m3=template.density_kg_per_m3,
        temperature_K=template.temperature_K,
        pressure_kPa=template.pressure_kPa,
        price_per_tonne=template.price_per_tonne,
    )


def _score(
    mode: OptimisationMode,
    result: SimulationResult,
    econ: "object",
    weights: OptimisationWeights,
    normalisers: dict,
) -> float:
    """Higher is better, for every mode."""
    if result.total_net_MWh <= 1e-9:
        return -1e18

    if mode == OptimisationMode.MAX_MWH:
        return result.total_net_MWh
    if mode == OptimisationMode.MAX_EFFICIENCY:
        return result.average_electrical_efficiency
    if mode == OptimisationMode.MIN_FUEL:
        fuel_per_mwh = result.total_lng_consumed_kg / result.total_net_MWh
        return -fuel_per_mwh
    if mode == OptimisationMode.MIN_COST:
        return -econ.cost_per_MWh
    if mode == OptimisationMode.MAX_PROFIT:
        return econ.operating_margin
    if mode == OptimisationMode.BALANCED:
        w = weights.normalised()
        mwh_n = result.total_net_MWh / max(normalisers["mwh"], 1e-9)
        eff_n = result.average_electrical_efficiency / max(normalisers["efficiency"], 1e-9)
        fuel_per_mwh = result.total_lng_consumed_kg / result.total_net_MWh
        fuel_n = 1.0 - min(fuel_per_mwh / max(normalisers["fuel_per_mwh"], 1e-9), 2.0) / 2.0
        cost_n = 1.0 - min(econ.cost_per_MWh / max(normalisers["cost_per_mwh"], 1e-9), 2.0) / 2.0
        co2_per_mwh = result.total_co2_kg / result.total_net_MWh
        co2_n = 1.0 - min(co2_per_mwh / max(normalisers["co2_per_mwh"], 1e-9), 2.0) / 2.0
        return (
            w.mwh * mwh_n + w.efficiency * eff_n + w.fuel_consumption * fuel_n
            + w.operating_cost * cost_n + w.emissions * co2_n
        )
    raise ValueError(f"Unknown optimisation mode: {mode}")


def optimise_plant(
    lng_available_kg: float,
    demand_MW: float,
    time_horizon_hours: float,
    plant: LNGPlant,
    ambient_temperature: float = 15.0,
    ambient_pressure: float = 101.325,
    ambient_humidity: float = 0.60,
    ambient_elevation_m: float = 0.0,
    economics: Optional[EconomicConfig] = None,
    mode: OptimisationMode = OptimisationMode.BALANCED,
    weights: Optional[OptimisationWeights] = None,
    timestep_seconds: float = 60.0,
    lng_composition_reference: Optional[LNGInventory] = None,
) -> OptimisationResult:
    """Find the physically- and economically-optimal constant dispatch
    setpoint for this plant given a fuel inventory, a demand cap and a
    time horizon, then return the full simulated outcome.

    The search variable is a single constant target net-MW setpoint,
    bounded to [minimum_stable_MW, min(rated_capacity_MW, demand_MW)]; the
    unit still has to start up and ramp to reach it, and may be fuel
    limited before the horizon ends -- all handled by the underlying
    time-stepped simulation, not assumed away.
    """
    assert lng_available_kg >= 0
    assert demand_MW >= 0
    assert time_horizon_hours > 0

    economics = economics or EconomicConfig()
    weights = weights or OptimisationWeights()
    ambient = AmbientConditions(
        temperature_C=ambient_temperature,
        pressure_kPa=ambient_pressure,
        relative_humidity=ambient_humidity,
        elevation_m=ambient_elevation_m,
    )
    sim_config = SimulationConfig(timestep_seconds=timestep_seconds, time_horizon_hours=time_horizon_hours)

    template_inventory = lng_composition_reference or LNGInventory(
        composition=plant.composition, mass_kg=lng_available_kg
    )

    capacity_MW = plant.net_capacity_MW(ambient)
    min_stable_MW = plant.net_minimum_stable_MW(ambient)
    upper_bound_MW = min(capacity_MW, max(demand_MW, min_stable_MW))
    upper_bound_MW = max(upper_bound_MW, min_stable_MW)

    cache: dict = {}
    eval_count = [0]

    def evaluate(setpoint_MW: float) -> SimulationResult:
        key = round(setpoint_MW, 4)
        if key in cache:
            return cache[key]
        inv = _fresh_inventory(template_inventory, lng_available_kg)
        result = run_simulation(plant, inv, setpoint_MW, sim_config, ambient)
        cache[key] = result
        eval_count[0] += 1
        return result

    # Coarse grid to establish BALANCED-mode normalisers and to seed a
    # robust global search (the objective can have flat/kinked regions
    # from ramp saturation and fuel exhaustion, so we don't rely on Brent
    # alone finding the global optimum from an arbitrary bracket).
    import numpy as np

    grid = np.linspace(min_stable_MW, upper_bound_MW, 9)
    grid_results = [(mw, evaluate(float(mw))) for mw in grid]
    grid_econ = [
        (mw, res, evaluate_simulation(res, economics, plant.composition))
        for mw, res in grid_results
    ]

    mwh_vals = [r.total_net_MWh for _, r, _ in grid_econ if r.total_net_MWh > 0]
    eff_vals = [r.average_electrical_efficiency for _, r, _ in grid_econ if r.total_net_MWh > 0]
    fuel_vals = [r.total_lng_consumed_kg / r.total_net_MWh for _, r, _ in grid_econ if r.total_net_MWh > 0]
    cost_vals = [e.cost_per_MWh for _, r, e in grid_econ if r.total_net_MWh > 0]
    co2_vals = [r.total_co2_kg / r.total_net_MWh for _, r, _ in grid_econ if r.total_net_MWh > 0]

    normalisers = {
        "mwh": max(mwh_vals) if mwh_vals else 1.0,
        "efficiency": max(eff_vals) if eff_vals else 1.0,
        "fuel_per_mwh": min(fuel_vals) if fuel_vals else 1.0,
        "cost_per_mwh": min(cost_vals) if cost_vals else 1.0,
        "co2_per_mwh": min(co2_vals) if co2_vals else 1.0,
    }

    def neg_score(setpoint_MW: float) -> float:
        result = evaluate(float(setpoint_MW))
        econ = evaluate_simulation(result, economics, plant.composition)
        return -_score(mode, result, econ, weights, normalisers)

    # Fine local search around the best grid point.
    best_grid_mw = min(grid, key=lambda mw: neg_score(float(mw)))
    idx = list(grid).index(best_grid_mw)
    lo = grid[max(idx - 1, 0)]
    hi = grid[min(idx + 1, len(grid) - 1)]
    if hi - lo < 1e-6:
        best_MW = float(best_grid_mw)
    else:
        opt = minimize_scalar(neg_score, bounds=(float(lo), float(hi)), method="bounded", options={"xatol": 1e-2})
        best_MW = float(opt.x)
        if neg_score(best_MW) > neg_score(float(best_grid_mw)):
            best_MW = float(best_grid_mw)

    final_result = evaluate(best_MW)
    final_econ = evaluate_simulation(final_result, economics, plant.composition)

    return OptimisationResult(
        optimal_output_MW=best_MW,
        total_MWh=final_result.total_net_MWh,
        lng_consumed_kg=final_result.total_lng_consumed_kg,
        electrical_efficiency=final_result.average_electrical_efficiency,
        heat_rate=final_result.average_heat_rate_MMBtu_per_MWh,
        waste_heat_MWh=final_result.total_waste_heat_MWh,
        recoverable_heat_MWh=final_result.total_recoverable_heat_MWh,
        co2_kg=final_result.total_co2_kg,
        cost_per_MWh=final_econ.cost_per_MWh,
        lng_remaining_kg=final_result.lng_remaining_kg,
        total_gross_MWh=final_result.total_gross_MWh,
        lng_kg_per_MWh=(
            final_result.total_lng_consumed_kg / final_result.total_net_MWh
            if final_result.total_net_MWh > 0 else float("inf")
        ),
        marginal_cost_per_MWh=final_econ.marginal_cost_per_MWh,
        gross_revenue=final_econ.gross_revenue,
        operating_margin=final_econ.operating_margin,
        ran_out_of_fuel=final_result.ran_out_of_fuel,
        optimisation_mode=mode,
        simulation=final_result,
        score_evaluations=eval_count[0],
    )
