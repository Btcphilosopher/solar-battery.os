"""
optimisation/dispatch.py
==========================

Ramp-rate- and start-up/shut-down-aware dispatch: turns a *desired* demand
profile into a *physically achievable* target-output trajectory.

The unit cannot jump from 0 MW to full output. The state machine below
enforces:

    OFF -> STARTING (zero output, duration = startup_time_min)
         -> RUNNING at minimum_stable_load
         -> ramp toward demand at +-ramp rate, clipped to [min stable, capacity]
         -> STOPPING (ramp down to 0, then zero output for shutdown_time_min)
         -> OFF

This is deliberately conservative/simple: no useful electricity is credited
during startup or shutdown holds, consistent with typical gas-turbine
practice where synchronisation and warm-up precede loading.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import List, Sequence

import numpy as np

from config import AmbientConditions
from models.plant import LNGPlant


class UnitState(str, Enum):
    OFF = "off"
    STARTING = "starting"
    RUNNING = "running"
    STOPPING = "stopping"


@dataclass
class DispatchStep:
    time_hours: float
    demand_MW: float
    target_MW: float  # ramp-feasible achievable target for this step
    state: UnitState


def build_dispatch_trajectory(
    plant: LNGPlant,
    ambient: AmbientConditions,
    demand_MW: Sequence[float],
    timestep_seconds: float,
    initial_state: UnitState = UnitState.OFF,
) -> List[DispatchStep]:
    """Convert a demand profile into a ramp/startup/shutdown-feasible
    target output trajectory.

    ``demand_MW`` may be a scalar-like sequence (e.g. constant demand
    repeated) or a genuinely time-varying profile, one value per timestep.
    """
    ramp = plant.ramp
    capacity_MW = plant.net_capacity_MW(ambient)
    min_stable_MW = plant.net_minimum_stable_MW(ambient)

    dt_min = timestep_seconds / 60.0
    steps: List[DispatchStep] = []

    state = initial_state
    current_MW = 0.0
    state_timer_min = 0.0  # time remaining in STARTING/STOPPING hold

    for i, demand in enumerate(demand_MW):
        t_hours = i * timestep_seconds / 3600.0
        demand = max(0.0, float(demand))

        # ``recorded_state`` is the state that actually governs THIS step's
        # target output; ``state`` may be advanced at the end of this
        # iteration to take effect from the NEXT step onward. Keeping these
        # separate avoids mislabelling a still-zero-output startup step as
        # "running" just because its timer happened to expire this step.
        recorded_state = state

        if state == UnitState.OFF:
            target = 0.0
            if demand > 0:
                state = UnitState.STARTING
                state_timer_min = ramp.startup_time_min

        elif state == UnitState.STARTING:
            target = 0.0
            state_timer_min -= dt_min
            if state_timer_min <= 0:
                # Startup complete: jump directly to minimum stable output,
                # effective from the next timestep (per spec section 7).
                state = UnitState.RUNNING
                current_MW = min_stable_MW

        elif state == UnitState.RUNNING:
            if demand <= 1e-9:
                state = UnitState.STOPPING
                state_timer_min = ramp.shutdown_time_min
                target = current_MW
            else:
                desired = min(max(demand, min_stable_MW), capacity_MW)
                max_step_up = ramp.ramp_up_MW_per_min * dt_min
                max_step_down = ramp.ramp_down_MW_per_min * dt_min
                delta = desired - current_MW
                if delta > 0:
                    current_MW = current_MW + min(delta, max_step_up)
                else:
                    current_MW = current_MW + max(delta, -max_step_down)
                current_MW = min(max(current_MW, min_stable_MW), capacity_MW)
                target = current_MW

        elif state == UnitState.STOPPING:
            # ramp down toward zero at the max ramp-down rate, then hold at
            # zero for the remainder of shutdown_time_min
            max_step_down = ramp.ramp_down_MW_per_min * dt_min
            current_MW = max(0.0, current_MW - max_step_down)
            target = current_MW
            if current_MW <= 1e-9:
                state_timer_min -= dt_min
                if state_timer_min <= 0:
                    state = UnitState.OFF
                    current_MW = 0.0
            # a fresh demand during stopping restarts once fully off; for
            # simplicity we do not interrupt a shutdown in progress
        else:
            target = 0.0

        steps.append(DispatchStep(time_hours=t_hours, demand_MW=demand, target_MW=target, state=recorded_state))

    return steps


def constant_demand_profile(demand_MW: float, n_steps: int) -> np.ndarray:
    return np.full(n_steps, float(demand_MW))
