"""
optimisation/benchmark.py
============================

Naive vs optimised dispatch benchmark (spec section 18).

Naive operation: the unit simply targets whatever output is requested
(``demand_MW``) at every timestep, subject only to the *physical*
constraints it cannot avoid (ramp rate, minimum stable load, startup/
shutdown, fuel availability) -- i.e. no attempt is made to pick a better
operating point.

Optimised operation: ``optimise_plant`` searches (bounded by the same
demand cap and the same physical constraints) for the dispatch setpoint
that performs best against the chosen objective -- by default MAX_MWH,
which best demonstrates the core insight that running flat-out to match
demand is not always what extracts the most electrical energy from a
finite LNG inventory (a lower, more efficient setpoint can outlast fuel
exhaustion and deliver more total MWh).
"""

from __future__ import annotations

from dataclasses import dataclass

from config import AmbientConditions, EconomicConfig, OptimisationMode, SimulationConfig
from economics.costs import evaluate_simulation
from models.lng import LNGInventory
from models.plant import LNGPlant
from optimisation.optimiser import optimise_plant
from simulation.simulation import run_simulation


@dataclass
class BenchmarkResult:
    naive_MWh: float
    optimised_MWh: float
    naive_lng_consumed_kg: float
    optimised_lng_consumed_kg: float
    fuel_saved_kg: float
    fuel_saving_pct: float
    naive_efficiency: float
    optimised_efficiency: float
    efficiency_improvement_pp: float  # percentage points
    naive_cost_per_MWh: float
    optimised_cost_per_MWh: float
    cost_reduction_pct: float
    naive_co2_kg: float
    optimised_co2_kg: float
    co2_reduction_pct: float
    mwh_improvement_pct: float


def run_benchmark(
    plant: LNGPlant,
    lng_available_kg: float,
    demand_MW: float,
    time_horizon_hours: float,
    ambient: AmbientConditions,
    economics: EconomicConfig,
    timestep_seconds: float = 60.0,
    optimisation_mode: OptimisationMode = OptimisationMode.MAX_MWH,
) -> BenchmarkResult:
    sim_config = SimulationConfig(timestep_seconds=timestep_seconds, time_horizon_hours=time_horizon_hours)

    naive_inventory = LNGInventory(composition=plant.composition, mass_kg=lng_available_kg)
    naive_result = run_simulation(plant, naive_inventory, demand_MW, sim_config, ambient)
    naive_econ = evaluate_simulation(naive_result, economics, plant.composition)

    opt_result = optimise_plant(
        lng_available_kg=lng_available_kg,
        demand_MW=demand_MW,
        time_horizon_hours=time_horizon_hours,
        plant=plant,
        ambient_temperature=ambient.temperature_C,
        ambient_pressure=ambient.pressure_kPa,
        ambient_humidity=ambient.relative_humidity,
        ambient_elevation_m=ambient.elevation_m,
        economics=economics,
        mode=optimisation_mode,
        timestep_seconds=timestep_seconds,
    )

    fuel_saved_kg = naive_result.total_lng_consumed_kg - opt_result.lng_consumed_kg
    fuel_saving_pct = (
        100.0 * fuel_saved_kg / naive_result.total_lng_consumed_kg
        if naive_result.total_lng_consumed_kg > 0 else 0.0
    )
    mwh_improvement_pct = (
        100.0 * (opt_result.total_MWh - naive_result.total_net_MWh) / naive_result.total_net_MWh
        if naive_result.total_net_MWh > 0 else 0.0
    )
    cost_reduction_pct = (
        100.0 * (naive_econ.cost_per_MWh - opt_result.cost_per_MWh) / naive_econ.cost_per_MWh
        if naive_econ.cost_per_MWh not in (0.0, float("inf")) else 0.0
    )
    co2_reduction_pct = (
        100.0 * (naive_result.total_co2_kg - opt_result.co2_kg) / naive_result.total_co2_kg
        if naive_result.total_co2_kg > 0 else 0.0
    )

    return BenchmarkResult(
        naive_MWh=naive_result.total_net_MWh,
        optimised_MWh=opt_result.total_MWh,
        naive_lng_consumed_kg=naive_result.total_lng_consumed_kg,
        optimised_lng_consumed_kg=opt_result.lng_consumed_kg,
        fuel_saved_kg=fuel_saved_kg,
        fuel_saving_pct=fuel_saving_pct,
        naive_efficiency=naive_result.average_electrical_efficiency,
        optimised_efficiency=opt_result.electrical_efficiency,
        efficiency_improvement_pp=(opt_result.electrical_efficiency - naive_result.average_electrical_efficiency) * 100,
        naive_cost_per_MWh=naive_econ.cost_per_MWh,
        optimised_cost_per_MWh=opt_result.cost_per_MWh,
        cost_reduction_pct=cost_reduction_pct,
        naive_co2_kg=naive_result.total_co2_kg,
        optimised_co2_kg=opt_result.co2_kg,
        co2_reduction_pct=co2_reduction_pct,
        mwh_improvement_pct=mwh_improvement_pct,
    )


def format_benchmark_report(b: BenchmarkResult) -> str:
    lines = [
        "=" * 60,
        "  NAIVE vs OPTIMISED DISPATCH BENCHMARK",
        "=" * 60,
        f"  Naive MWh                 : {b.naive_MWh:,.2f} MWh",
        f"  Optimised MWh              : {b.optimised_MWh:,.2f} MWh  ({b.mwh_improvement_pct:+.2f}%)",
        "",
        f"  Naive LNG consumption      : {b.naive_lng_consumed_kg:,.1f} kg",
        f"  Optimised LNG consumption  : {b.optimised_lng_consumed_kg:,.1f} kg",
        f"  Fuel saved                 : {b.fuel_saved_kg:,.1f} kg  ({b.fuel_saving_pct:+.2f}%)",
        "",
        f"  Naive efficiency           : {b.naive_efficiency*100:,.2f} %",
        f"  Optimised efficiency       : {b.optimised_efficiency*100:,.2f} %",
        f"  Efficiency improvement     : {b.efficiency_improvement_pp:+.2f} percentage points",
        "",
        f"  Naive cost per MWh         : £{b.naive_cost_per_MWh:,.2f}",
        f"  Optimised cost per MWh     : £{b.optimised_cost_per_MWh:,.2f}",
        f"  Cost reduction             : {b.cost_reduction_pct:+.2f}%",
        "",
        f"  Naive CO2                  : {b.naive_co2_kg:,.1f} kg",
        f"  Optimised CO2              : {b.optimised_co2_kg:,.1f} kg",
        f"  CO2 reduction              : {b.co2_reduction_pct:+.2f}%",
        "=" * 60,
    ]
    return "\n".join(lines)
