"""Dispatch, part-load efficiency search and top-level optimisation engine."""
