"""
optimisation/scenario.py
===========================

Scenario runner: execute several ``optimise_plant`` scenarios in one go and
collect the results into a tidy pandas DataFrame for comparison.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional

import pandas as pd

from config import EconomicConfig, OptimisationMode, OptimisationWeights
from models.plant import LNGPlant
from optimisation.optimiser import OptimisationResult, optimise_plant
from thermodynamics import properties as props


@dataclass
class Scenario:
    name: str
    lng_tonnes: float
    demand_MW: float
    duration_hours: float
    ambient_temperature_C: float = 15.0
    ambient_pressure_kPa: float = 101.325
    ambient_humidity: float = 0.60
    mode: OptimisationMode = OptimisationMode.BALANCED


def run_scenarios(
    scenarios: List[Scenario],
    plant: LNGPlant,
    economics: Optional[EconomicConfig] = None,
    weights: Optional[OptimisationWeights] = None,
    timestep_seconds: float = 60.0,
) -> pd.DataFrame:
    economics = economics or EconomicConfig()
    rows = []
    results: List[OptimisationResult] = []
    for sc in scenarios:
        result = optimise_plant(
            lng_available_kg=props.tonnes_to_kg(sc.lng_tonnes),
            demand_MW=sc.demand_MW,
            time_horizon_hours=sc.duration_hours,
            plant=plant,
            ambient_temperature=sc.ambient_temperature_C,
            ambient_pressure=sc.ambient_pressure_kPa,
            ambient_humidity=sc.ambient_humidity,
            economics=economics,
            mode=sc.mode,
            weights=weights,
            timestep_seconds=timestep_seconds,
        )
        results.append(result)
        rows.append(
            {
                "scenario": sc.name,
                "mode": sc.mode.value,
                "lng_tonnes": sc.lng_tonnes,
                "demand_MW": sc.demand_MW,
                "duration_hours": sc.duration_hours,
                "ambient_temperature_C": sc.ambient_temperature_C,
                "optimal_output_MW": result.optimal_output_MW,
                "total_MWh": result.total_MWh,
                "lng_consumed_kg": result.lng_consumed_kg,
                "lng_remaining_kg": result.lng_remaining_kg,
                "electrical_efficiency_pct": result.electrical_efficiency * 100,
                "heat_rate_MMBtu_per_MWh": result.heat_rate,
                "lng_kg_per_MWh": result.lng_kg_per_MWh,
                "waste_heat_MWh": result.waste_heat_MWh,
                "recoverable_heat_MWh": result.recoverable_heat_MWh,
                "co2_kg": result.co2_kg,
                "co2_kg_per_MWh": result.co2_kg / result.total_MWh if result.total_MWh > 0 else float("nan"),
                "cost_per_MWh": result.cost_per_MWh,
                "gross_revenue": result.gross_revenue,
                "operating_margin": result.operating_margin,
                "ran_out_of_fuel": result.ran_out_of_fuel,
            }
        )
    df = pd.DataFrame(rows)
    df.attrs["results"] = results
    return df
