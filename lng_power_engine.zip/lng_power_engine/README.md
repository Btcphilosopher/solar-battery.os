# LNG Generator Optimisation Engine

A production-quality Python simulation and optimisation engine for an
LNG-fuelled power generator. It answers one question:

> **Given a quantity of LNG, generator characteristics, ambient conditions
> and electricity demand, what is the physically and economically optimal
> way to turn as much of that LNG's available energy into useful
> electricity as possible, as quickly as the plant can safely and
> realistically operate?**

It is a genuine **time-dependent** optimisation engine, not a single
`LNG × fixed_efficiency = MWh` calculation: plant operating point affects
part-load efficiency, which affects fuel consumption, which affects how
long a finite LNG inventory lasts, which affects total MWh delivered —
and the optimiser searches over that whole coupled system.

---

## 1. How the model works

```
LNG inventory (kg or m3)
        |
        v
  Combustion model  --------->  CO2, exhaust flow, exhaust temperature
        |  (fuel energy released)
        v
  Gas turbine (Brayton) -----> shaft mechanical power  [part-load efficiency curve]
        |                              |
        v                              v
  Exhaust heat                    Generator  ----> GT electrical output  [efficiency curve]
        |
        v
  HRSG (optional) ----> steam ----> Steam turbine ----> Generator ----> bonus electricity
        |                                                    (combined-cycle mode only)
        v
  Stack loss (unrecovered)

  All electrical output - auxiliary/parasitic load = NET electrical output
```

Everything downstream of "combustion model" is resolved by
`models.plant.LNGPlant`, the central physics engine (see
`models/plant.py`). Given a **gas-turbine load fraction** (0-1), it
performs a deterministic forward pass through combustion → turbine →
generator → (HRSG → steam turbine → generator), producing a fully
energy-balanced `PlantOperatingPoint`. To answer "what load fraction do I
need to hit a *target net MW*", it inverts that forward pass with a
bounded root-find (`scipy.optimize.brentq`), because in combined-cycle
mode net output is a mildly nonlinear function of load fraction (the
steam bottoming cycle adds a load-dependent bonus on top of the gas
turbine's own output).

On top of that per-instant physics, three more layers make the model
genuinely dynamic:

* **`simulation/`** steps through time (default 1-minute steps),
  drawing down a finite LNG inventory, tracking cumulative MWh/fuel/CO2,
  and scaling operation down (or tripping the unit) if fuel runs out
  mid-step.
* **`optimisation/dispatch.py`** turns a *desired* demand profile into a
  *physically achievable* target trajectory: the unit cannot jump from
  0 MW to full output — it must start up, reach minimum stable load, then
  ramp, exactly as real gas turbines do.
* **`optimisation/optimiser.py`** (`optimise_plant`) searches over
  candidate dispatch setpoints and picks the one that performs best
  against a configurable objective (MAX_MWH, MAX_EFFICIENCY, MIN_FUEL,
  MIN_COST, MAX_PROFIT, BALANCED) — each candidate is evaluated by running
  the **full** time-stepped simulation, so ramp limits, fuel exhaustion
  and part-load efficiency all genuinely shape the answer.

---

## 2. Assumptions (what's first-principles vs. approximation vs. configurable)

The codebase deliberately separates three tiers everywhere (see the
module docstrings for the specifics in each file):

1. **First-principles calculations** — unit conversions
   (`thermodynamics/properties.py`), stoichiometric combustion chemistry
   from balanced reactions (`thermodynamics/combustion.py`), energy and
   mass conservation.
2. **Engineering approximations** — widely-cited rules of thumb standing
   in for vendor performance curves: the part-load efficiency curve
   shapes, the ambient derating formula, the lumped exhaust specific
   heat, the auxiliary load fraction, the HRSG/steam-cycle efficiencies.
   These are realistic and internally consistent, but are *not* a
   substitute for OEM heat-balance data.
3. **User-configurable assumptions** — everything in `config.py`: plant
   ratings, ramp rates, LNG composition and price, electricity/carbon
   prices, optimisation weights, ambient design point.

## 3. Key equations

**LNG chemical energy**: `chemical_energy_MJ = mass_kg × LHV_MJ_per_kg`,
with `LHV` computed as the mass-fraction-weighted average of per-component
reference LHVs (methane/ethane/propane; nitrogen is inert and contributes
zero).

**Stoichiometric combustion** (per mole of fuel mixture):

```
CH4  + 2   O2 -> CO2 + 2 H2O
C2H6 + 3.5 O2 -> 2 CO2 + 3 H2O
C3H8 + 5   O2 -> 3 CO2 + 4 H2O
```

giving stoichiometric air-fuel ratio and kg CO2 per kg fuel from a direct
carbon/oxygen mass balance (`thermodynamics/combustion.py`).

**Combustor exit temperature** (lumped-capacitance approximation):
`T_exit = T_ambient + (fuel_kg × LHV × η_comb × 1000) / (exhaust_kg × cp_exhaust)`.

**Ambient derating** (`thermodynamics/properties.py`):
`derate_factor ≈ (1 − 0.006·ΔT) × (P_site / P_ISO) × humidity_term`, clipped
to a physically sensible range — i.e. roughly −0.6%/°C above the 15°C ISO
reference, plus a density-driven pressure/elevation term.

**Fuel required for a target gross electrical output** at load fraction
`f`:

```
fuel_energy_rate_MW = gross_target_MW / (η_combustion(f) × η_turbine(f) × η_generator(f))
```

**Combined-cycle bonus**: the gas turbine's exhaust heat
(`fuel_energy_rate × η_combustion × (1 − η_turbine)`) is split by the HRSG
into recovered/unrecovered heat; the recovered fraction drives a steam
turbine + generator to add electrical output *for the same fuel input* —
this is why `net_capacity_MW` for a combined-cycle plant is materially
higher than the gas turbine's own nameplate rating.

**Heat rate**: `heat_rate_MMBtu_per_MWh = 3.412142 / electrical_efficiency`
(3.412142 = MMBtu per MWh, exact).

**Energy conservation**, checked by assertion on every resolved operating
point:

```
fuel_energy_rate_MW ≈ net_electrical_MW + auxiliary_load_MW + process_heat_MW + waste_heat_MW
```

where `waste_heat_MW` sums combustion loss, generator loss(es), stack
loss and steam-cycle thermal/generator loss — see the docstring at the
top of `models/plant.py` for the full term-by-term derivation.

---

## 4. Installation

```bash
python3.12 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

Dependencies: `numpy`, `scipy`, `pandas`, `matplotlib`, `pytest`,
`streamlit` (dashboard only).

## 5. How to run it

```bash
# Run the full test suite
pytest -q

# CLI
python main.py simulate  --capacity 500 --lng-tonnes 100 --demand 400 --hours 24
python main.py optimise  --capacity 500 --lng-tonnes 100 --demand 400 --hours 24 --mode balanced --plots-dir out/
python main.py benchmark --capacity 500 --lng-tonnes 100 --demand 400 --hours 24 --mode max_mwh
python main.py scenario  --capacity 500 --scenarios-file examples/scenarios_example.json --output-csv out/scenarios.csv

# Reproducible worked example (spec section 19)
python examples/example_scenario.py

# Streamlit dashboard
streamlit run dashboard.py
```

Run `python main.py <command> --help` for the full argument list of each
subcommand (plant ratings, ramp rates, ambient conditions, prices,
timestep, optimisation mode).

## 6. Changing plant parameters

The quickest path is `models.plant.build_plant(...)`, a factory that
builds a fully configured `LNGPlant` from a handful of headline numbers
(`rated_power_MW`, `minimum_stable_load`, `generator_efficiency`, ramp
rates, `cycle_mode`, `auxiliary_load_fraction`, LNG `composition`). For
finer control, construct the pieces directly:

```python
from config import RampConfig, CycleMode
from models.turbine import GasTurbine
from models.generator import Generator
from models.heat_recovery import HeatRecoverySystem
from models.plant import LNGPlant
from thermodynamics.efficiency import EfficiencyCurve

ramp = RampConfig(
    minimum_output_MW=175, maximum_output_MW=500,
    ramp_up_MW_per_min=40, ramp_down_MW_per_min=50,
    minimum_stable_load=0.35, startup_time_min=12, shutdown_time_min=6,
)
gt = GasTurbine(
    rated_power_MW=500, ramp=ramp,
    efficiency_curve=EfficiencyCurve(points=[(0.35, 0.30), (0.6, 0.37), (0.8, 0.40), (1.0, 0.39)]),
)
plant = LNGPlant(name="my-plant", gas_turbine=gt, generator=Generator(rated_capacity_MVA=560),
                  heat_recovery=HeatRecoverySystem(enabled=True, hrsg_efficiency=0.80),
                  cycle_mode=CycleMode.COMBINED_CYCLE)
```

LNG composition, ambient design point, economic assumptions and
optimisation weights are all separate config objects
(`models.lng.LNGComposition`, `config.AmbientConditions`,
`config.EconomicConfig`, `config.OptimisationWeights`) — pass your own
values rather than editing library code.

## 7. How optimisation works

`optimisation.optimiser.optimise_plant(...)` searches over a single
constant dispatch **setpoint** (a target net MW held for the whole
horizon), bounded to `[net_minimum_stable_MW, min(net_capacity_MW,
demand_MW)]`. Each candidate is evaluated by running the *full*
time-stepped simulation (`simulation.simulation.run_simulation`) — so the
candidate still has to start up, ramp, and may run out of fuel before the
horizon ends. A coarse 9-point grid establishes robust bounds/normalisers
(the objective can be flat or kinked from ramp/fuel saturation), then
`scipy.optimize.minimize_scalar` (bounded Brent) refines locally around
the best grid point.

Six objective modes (`config.OptimisationMode`):

| Mode | Objective |
|---|---|
| `MAX_MWH` | maximise total net MWh delivered |
| `MAX_EFFICIENCY` | maximise energy-weighted average electrical efficiency |
| `MIN_FUEL` | minimise kg LNG per MWh delivered |
| `MIN_COST` | minimise £/MWh total generation cost |
| `MAX_PROFIT` | maximise revenue − (fuel + carbon + maintenance + auxiliary + startup) cost |
| `BALANCED` | weighted combination of the above five (`config.OptimisationWeights`), each min-max normalised against the same 9-point grid |

**Why a lower setpoint can beat "just match demand":** when LNG is the
binding constraint, `total_MWh ≈ efficiency(load) × fuel_available_energy`
— so running at the plant's efficiency sweet spot rather than flat-out at
100% load can *increase* total energy delivered from the same fuel stock,
even though instantaneous MW is lower. `optimisation/benchmark.py`
demonstrates this directly: a simple-cycle 500 MW plant asked to match
~100% load with 300 t of fuel over 24 h delivers **+2.3% more MWh** (and a
0.8-point efficiency gain) if the optimiser is allowed to dispatch it at
~90% load instead — see `run_benchmark` / `python main.py benchmark`.

## 8. How to interpret the results

`OptimisationResult` (and the CLI report) surfaces, among others:

* **`optimal_output_MW`** — the dispatch setpoint the optimiser chose (not
  necessarily equal to `demand_MW` — see above).
* **`total_MWh` / `lng_consumed_kg` / `lng_remaining_kg`** — the physical
  outcome over the full horizon, honouring ramp limits, minimum stable
  load and fuel exhaustion.
* **`electrical_efficiency` / `heat_rate` / `lng_kg_per_MWh`** —
  energy-weighted averages over the run, *not* the instantaneous value at
  the chosen setpoint (they include start-up and any part-load ramp
  transients).
* **`waste_heat_MWh` / `recoverable_heat_MWh`** — everything that did not
  become electricity, split into "recoverable if a heat-recovery system
  is fitted/enabled" and the rest (combustion, generator, stack losses).
* **`cost_per_MWh` vs `marginal_cost_per_MWh`** — the former is total
  cost / total MWh (average); the latter is the fuel+carbon+maintenance
  cost of *one more* MWh at the final operating point's efficiency — use
  it, compared against the electricity price, for a dispatch/no-dispatch
  decision (`economics.costs.evaluate_operating_point().dispatch_recommended`).
* **`ran_out_of_fuel`** — `True` means the LNG inventory hit zero before
  the time horizon ended; the unit then sat idle for the remainder.

## 9. Where the model is simplified

Documented explicitly so results aren't over-trusted:

* **Combustion is stoichiometry + a lumped-capacitance temperature
  estimate**, not CFD or chemical kinetics — no flame temperature
  dissociation, no NOx chemistry, no radiative heat transfer.
* **Part-load efficiency curves are representative shapes**, not a
  specific vendor's heat-balance data. They are fully overridable via
  `EfficiencyCurve`.
* **The efficiency-vs-load-fraction curve is assumed ambient-independent.**
  Ambient conditions derate the plant's *MW capacity* (via
  `ambient_derate_factor`), which shifts a fixed absolute demand to a
  different point on the (unchanged) efficiency curve — but the curve's
  own shape does not degrade with temperature the way a real machine's
  heat rate typically does on a very hot day. This can make a hot-day
  run at a fixed MW demand appear *more* efficient than a cold-day run at
  the same MW, purely because it represents a higher load fraction of a
  smaller derated capacity — a known limitation, not a claim that heat
  and efficiency are independent in reality.
* **Auxiliary/parasitic load is a flat fraction of gross output**, not
  its own part-load curve.
* **Dispatch optimisation searches a single constant setpoint per run**,
  not an arbitrary time-varying profile — a genuine multi-period
  optimal-control formulation (e.g. dynamic programming or an MILP over
  the full horizon) would do better against a time-varying demand or
  price signal; the current design still captures the core "ramp/startup/
  fuel-exhaustion-aware" dynamics because each candidate is evaluated
  through the real timestep simulation.
* **If requested demand is below minimum stable load**, the unit either
  sits off or runs at its floor (minimum stable load) and oversupplies —
  there's no multi-unit fleet or grid-balancing logic to absorb the
  excess; that's out of scope for a single-unit model.
* **CO2 accounting covers combustion-stage carbon balance only** — no
  upstream (liquefaction, shipping, boil-off) lifecycle emissions.
* **Startup/shutdown produce zero electrical output** and consume no
  fuel in this model (a simplification — real units draw auxiliary power
  and some fuel during warm-up); `startup_cost` in `EconomicConfig` is a
  configurable lump-sum proxy for this.

## 10. Extending toward higher-fidelity thermodynamics

The module boundaries are deliberately drawn so a higher-fidelity engine
can be swapped in without touching the optimisation/simulation/economics
layers:

* Replace `thermodynamics/combustion.py`'s stoichiometry with a real
  chemical equilibrium solver (e.g. Cantera) for accurate flame
  temperature, NOx and unburned-fuel estimates.
* Replace the representative `EfficiencyCurve` control points with
  digitised OEM performance-curve data (or a full compressor/turbine
  map), still exposed through the same `EfficiencyCurve.__call__(load_fraction)`
  interface.
* Replace `models/turbine.py`'s lumped exhaust-temperature estimate with
  a proper Brayton-cycle calculation (pressure ratio, isentropic +
  polytropic efficiencies) using `CoolProp` or `scipy`-based gas property
  tables for real (non-ideal) combustion-gas thermophysical properties.
* Replace `models/heat_recovery.py`'s single HRSG efficiency number with
  a pinch-point HRSG model and a multi-pressure steam Rankine cycle
  (e.g. via `CoolProp`'s IAPWS-97 steam tables).
* Extend `optimisation/optimiser.py` from single-setpoint search to a
  proper multi-period optimal control formulation (dynamic programming,
  or an MILP/NLP built with `scipy.optimize.linprog` /
  `Pyomo`) for genuinely time-varying demand or price signals.

---

## Project layout

```
lng_power_engine/
├── main.py                  # CLI: simulate / optimise / benchmark / scenario
├── dashboard.py              # Streamlit dashboard
├── config.py                 # Typed configuration (ambient, ramp, economics, weights, sim)
├── models/
│   ├── lng.py                 # LNGComposition, LNGInventory
│   ├── combustion.py          # CombustionModel (wraps thermodynamics/combustion.py)
│   ├── turbine.py             # GasTurbine (capacity, derating, efficiency, ramp)
│   ├── generator.py           # Generator (shaft -> electrical)
│   ├── heat_recovery.py       # HRSG + steam bottoming cycle
│   └── plant.py               # LNGPlant: the central physics engine
├── thermodynamics/
│   ├── properties.py          # Unit conversions, ambient derating
│   ├── combustion.py          # Stoichiometric combustion chemistry
│   └── efficiency.py          # Part-load efficiency curves, heat-rate helpers
├── optimisation/
│   ├── dispatch.py            # Ramp/startup/shutdown-aware dispatch trajectory
│   ├── efficiency.py          # Efficiency-curve sampling & best-efficiency search
│   ├── optimiser.py           # optimise_plant(): top-level optimisation engine
│   ├── benchmark.py           # Naive vs optimised dispatch benchmark
│   └── scenario.py            # Multi-scenario runner -> pandas DataFrame
├── simulation/
│   ├── timestep.py            # Single-timestep physics + fuel draw-down
│   └── simulation.py          # Full time-stepped simulation -> DataFrame + totals
├── economics/
│   └── costs.py                # Fuel/carbon/maintenance cost, revenue, margin, dispatch rec.
├── reporting/
│   ├── reports.py             # Text report generation
│   └── plots.py                # Matplotlib charts incl. energy-flow breakdown
├── examples/
│   ├── example_scenario.py    # Reproducible worked example (spec section 19)
│   └── scenarios_example.json # Sample scenario set for `main.py scenario`
├── tests/                      # pytest suite (unit, integration, regression)
└── requirements.txt
```

## Testing

```bash
pytest -q          # 80+ tests: unit conversions, combustion, efficiency curves,
                    # generator/turbine/plant physics, ramp constraints, fuel
                    # consumption, emissions, heat recovery, optimisation modes,
                    # energy conservation, boundary/invalid/extreme inputs,
                    # and pinned regression values for a reference plant config.
```
