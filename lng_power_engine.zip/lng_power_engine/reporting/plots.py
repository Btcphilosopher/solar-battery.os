"""
reporting/plots.py
=====================

Publication-quality Matplotlib plots for efficiency curves, simulation
time series and an energy-flow Sankey diagram (via ``matplotlib.sankey``,
no extra dependency required).
"""

from __future__ import annotations

import os
from typing import Optional

import matplotlib
matplotlib.use("Agg")  # headless-safe backend for CLI/server use
import matplotlib.pyplot as plt

from config import AmbientConditions
from models.plant import LNGPlant
from optimisation.efficiency import sample_efficiency_curve
from simulation.simulation import SimulationResult

plt.rcParams.update(
    {
        "figure.facecolor": "white",
        "axes.facecolor": "white",
        "axes.grid": True,
        "grid.alpha": 0.3,
        "font.size": 10,
        "axes.titlesize": 12,
        "axes.titleweight": "bold",
        "figure.dpi": 120,
    }
)


def _savefig(fig, out_path: Optional[str]):
    if out_path:
        os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
        fig.savefig(out_path, bbox_inches="tight")
    return fig


def plot_efficiency_vs_load(plant: LNGPlant, ambient: AmbientConditions, out_path: Optional[str] = None):
    profile = sample_efficiency_curve(plant, ambient)
    df = profile.dataframe
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.plot(df["load_fraction"] * 100, df["electrical_efficiency"] * 100, color="#1b6ca8", lw=2.2)
    best_row = df.loc[df["electrical_efficiency"].idxmax()]
    ax.axvline(best_row["load_fraction"] * 100, color="#e0673d", ls="--", lw=1.2,
               label=f"Best efficiency ≈ {profile.best_efficiency*100:.1f}% @ {best_row['load_fraction']*100:.0f}% load")
    ax.set_xlabel("Load (% of net capacity)")
    ax.set_ylabel("Electrical efficiency (%)")
    ax.set_title("Electrical Efficiency vs Load")
    ax.legend()
    return _savefig(fig, out_path)


def plot_lng_consumption_vs_output(plant: LNGPlant, ambient: AmbientConditions, out_path: Optional[str] = None):
    profile = sample_efficiency_curve(plant, ambient)
    df = profile.dataframe
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.plot(df["net_MW"], df["lng_kg_per_MWh"], color="#2e8b57", lw=2.2)
    ax.set_xlabel("Net electrical output (MW)")
    ax.set_ylabel("LNG consumption (kg/MWh)")
    ax.set_title("LNG Consumption vs Electrical Output")
    return _savefig(fig, out_path)


def plot_heat_rate_curve(plant: LNGPlant, ambient: AmbientConditions, out_path: Optional[str] = None):
    profile = sample_efficiency_curve(plant, ambient)
    df = profile.dataframe
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.plot(df["net_MW"], df["heat_rate_MMBtu_per_MWh"], color="#8e44ad", lw=2.2)
    ax.set_xlabel("Net electrical output (MW)")
    ax.set_ylabel("Heat rate (MMBtu/MWh)")
    ax.set_title("Heat Rate Curve")
    return _savefig(fig, out_path)


def plot_cost_vs_load(plant: LNGPlant, ambient: AmbientConditions, economics, out_path: Optional[str] = None):
    from economics.costs import evaluate_operating_point

    profile = sample_efficiency_curve(plant, ambient)
    loads = profile.dataframe["net_MW"]
    costs = []
    for mw in loads:
        pt = plant.operating_point(float(mw), ambient)
        econ = evaluate_operating_point(pt, economics, plant.composition)
        costs.append(econ.total_generation_cost_per_MWh)
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.plot(loads, costs, color="#c0392b", lw=2.2)
    ax.set_xlabel("Net electrical output (MW)")
    ax.set_ylabel("Generation cost (£/MWh)")
    ax.set_title("Cost per MWh vs Load")
    return _savefig(fig, out_path)


def plot_co2_vs_load(plant: LNGPlant, ambient: AmbientConditions, out_path: Optional[str] = None):
    profile = sample_efficiency_curve(plant, ambient)
    df = profile.dataframe
    co2_per_mwh = df["co2_kg_per_hr"] / df["net_MW"]
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.plot(df["net_MW"], co2_per_mwh, color="#34495e", lw=2.2)
    ax.set_xlabel("Net electrical output (MW)")
    ax.set_ylabel("CO2 intensity (kg/MWh)")
    ax.set_title("CO2 Intensity vs Load")
    return _savefig(fig, out_path)


def plot_output_vs_time(result: SimulationResult, out_path: Optional[str] = None):
    df = result.dataframe
    fig, ax = plt.subplots(figsize=(9, 4.5))
    ax.plot(df["time_hours"], df["demand_MW"], color="#95a5a6", lw=1.4, ls="--", label="Demand")
    ax.plot(df["time_hours"], df["net_MW"], color="#1b6ca8", lw=2.0, label="Net output (achieved)")
    ax.set_xlabel("Time (hours)")
    ax.set_ylabel("Power (MW)")
    ax.set_title("MW Output vs Time")
    ax.legend()
    return _savefig(fig, out_path)


def plot_lng_consumption_vs_time(result: SimulationResult, out_path: Optional[str] = None):
    df = result.dataframe
    fig, ax = plt.subplots(figsize=(9, 4.5))
    ax.plot(df["time_hours"], df["fuel_flow_kg_per_hr"], color="#2e8b57", lw=2.0)
    ax.set_xlabel("Time (hours)")
    ax.set_ylabel("LNG flow (kg/hr)")
    ax.set_title("LNG Consumption Rate vs Time")
    return _savefig(fig, out_path)


def plot_cumulative_mwh(result: SimulationResult, out_path: Optional[str] = None):
    df = result.dataframe
    fig, ax = plt.subplots(figsize=(9, 4.5))
    ax.plot(df["time_hours"], df["cumulative_net_MWh"], color="#1b6ca8", lw=2.2)
    ax.fill_between(df["time_hours"], df["cumulative_net_MWh"], alpha=0.15, color="#1b6ca8")
    ax.set_xlabel("Time (hours)")
    ax.set_ylabel("Cumulative net MWh")
    ax.set_title("Cumulative Electrical Energy Generated")
    return _savefig(fig, out_path)


def plot_lng_remaining(result: SimulationResult, lng_available_kg: float, out_path: Optional[str] = None):
    df = result.dataframe
    fig, ax = plt.subplots(figsize=(9, 4.5))
    ax.plot(df["time_hours"], df["lng_remaining_kg"], color="#e0673d", lw=2.2)
    ax.axhline(0, color="black", lw=0.8)
    ax.set_xlabel("Time (hours)")
    ax.set_ylabel("LNG remaining (kg)")
    ax.set_title("LNG Inventory Remaining")
    return _savefig(fig, out_path)


def plot_dispatch_schedule(result: SimulationResult, out_path: Optional[str] = None):
    df = result.dataframe
    states = df["unit_state"].unique().tolist()
    colours = {"off": "#bdc3c7", "starting": "#f1c40f", "running": "#27ae60", "stopping": "#e67e22"}
    fig, ax = plt.subplots(figsize=(9, 3.2))
    for state in states:
        mask = df["unit_state"] == state
        ax.scatter(df.loc[mask, "time_hours"], df.loc[mask, "net_MW"], s=6,
                   color=colours.get(state, "#333333"), label=state)
    ax.set_xlabel("Time (hours)")
    ax.set_ylabel("Net MW")
    ax.set_title("Dispatch Schedule (state-coloured)")
    ax.legend(markerscale=3)
    return _savefig(fig, out_path)


def plot_energy_flow_sankey(operating_point, out_path: Optional[str] = None):
    """Sankey-style energy-flow breakdown for a single operating point.

    Rendered as a sequence of horizontal stacked-flow bars (fuel energy ->
    combustion/shaft -> electrical/generator loss -> exhaust heat ->
    recovered/stack loss -> steam electrical/steam losses). This is more
    legible than a fully-connected matplotlib Sankey diagram at these flow
    magnitudes, while still conveying the same energy-flow structure.
    """
    p = operating_point
    fuel = max(p.fuel_energy_rate_MW, 1e-9)

    stages = [
        ("LNG fuel energy", [
            ("Shaft mechanical", p.shaft_mechanical_MW, "#2e8b57"),
            ("Combustion loss", p.combustion_loss_MW, "#b0b0b0"),
        ]),
        ("Shaft mechanical", [
            ("GT electrical", p.gt_gross_electrical_MW, "#1b6ca8"),
            ("Generator loss", p.generator_loss_gt_MW, "#b0b0b0"),
        ]),
    ]
    if p.turbine_thermal_loss_MW > 1e-9:
        stages.append((
            "GT exhaust heat", [
                ("Recoverable (HRSG)", p.recoverable_heat_MW, "#e0673d"),
                ("Stack loss", p.unrecovered_exhaust_MW, "#b0b0b0"),
            ]
        ))
    if p.recoverable_heat_MW > 1e-9:
        stages.append((
            "Recovered heat", [
                ("Steam electrical", p.steam_electrical_MW, "#8e44ad"),
                ("Steam losses", p.steam_thermal_loss_MW + p.steam_generator_loss_MW, "#b0b0b0"),
            ]
        ))

    n = len(stages)
    fig, axes = plt.subplots(n, 1, figsize=(9, 1.1 * n + 1.2))
    if n == 1:
        axes = [axes]
    fig.suptitle(f"LNG Energy Flow Breakdown  (fuel input = {fuel:,.1f} MW)", fontweight="bold")

    for ax, (source_label, parts) in zip(axes, stages):
        left = 0.0
        for label, value, colour in parts:
            width = value / fuel * 100
            ax.barh(0, width, left=left, color=colour, edgecolor="white", height=0.6)
            if width > 3:
                ax.text(left + width / 2, 0, f"{label}\n{value:,.1f} MW", ha="center", va="center",
                        fontsize=8, color="white" if colour != "#b0b0b0" else "black")
            left += width
        ax.set_xlim(0, 100)
        ax.set_yticks([])
        ax.set_ylabel(source_label, rotation=0, ha="right", va="center", fontsize=9)
        ax.set_xlabel("% of fuel energy input" if ax is axes[-1] else "")
        for spine in ("top", "right", "left"):
            ax.spines[spine].set_visible(False)

    fig.tight_layout(rect=[0, 0, 1, 0.94])
    return _savefig(fig, out_path)
