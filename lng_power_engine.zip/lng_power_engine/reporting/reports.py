"""
reporting/reports.py
======================

Text report generation for optimisation/simulation results, per the
"Report" section of the spec (LNG consumed, remaining, energy input,
gross/net generation, MWh, MW, efficiency, heat rate, kg/MWh and
MMBtu/MWh, waste heat, recoverable heat, CO2, cost per MWh, marginal cost).
"""

from __future__ import annotations

from config import EconomicConfig
from economics.costs import evaluate_simulation
from models.plant import LNGPlant
from optimisation.optimiser import OptimisationResult
from thermodynamics import properties as props


def format_report(
    result: OptimisationResult,
    plant: LNGPlant,
    economics: EconomicConfig,
    lng_available_kg: float,
) -> str:
    sim = result.simulation
    econ = evaluate_simulation(sim, economics, plant.composition)
    composition = plant.composition

    fuel_energy_MWh_th = props.mj_to_mwh(result.lng_consumed_kg * composition.lhv_MJ_per_kg)
    fuel_energy_MMBtu = props.mwh_to_mmbtu(fuel_energy_MWh_th)
    lng_kg_per_mmbtu_out = (
        result.lng_consumed_kg / props.mwh_to_mmbtu(result.total_MWh) if result.total_MWh > 0 else float("inf")
    )

    avg_MW = result.total_MWh / (sim.dataframe["time_hours"].iloc[-1] + sim.dataframe["time_hours"].diff().median()) \
        if len(sim.dataframe) else 0.0
    peak_MW = float(sim.dataframe["net_MW"].max()) if len(sim.dataframe) else 0.0

    lines = []
    a = lines.append
    a("=" * 72)
    a(f"  LNG GENERATOR OPTIMISATION REPORT -- plant '{plant.name}'")
    a(f"  Optimisation mode: {result.optimisation_mode.value}")
    a("=" * 72)
    a("")
    a("-- LNG FUEL --")
    a(f"  LNG available (start)        : {lng_available_kg:,.1f} kg  ({props.kg_to_tonnes(lng_available_kg):,.2f} t)")
    a(f"  LNG consumed                 : {result.lng_consumed_kg:,.1f} kg  ({props.kg_to_tonnes(result.lng_consumed_kg):,.2f} t)")
    a(f"  LNG remaining                : {result.lng_remaining_kg:,.1f} kg  ({props.kg_to_tonnes(result.lng_remaining_kg):,.2f} t)")
    a(f"  LNG energy input             : {fuel_energy_MWh_th:,.2f} MWh(th)  ({fuel_energy_MMBtu:,.1f} MMBtu)")
    a(f"  Ran out of fuel before end?  : {result.ran_out_of_fuel}")
    a("")
    a("-- ELECTRICAL OUTPUT --")
    a(f"  Optimal setpoint (target)    : {result.optimal_output_MW:,.2f} MW")
    a(f"  Peak net output achieved     : {peak_MW:,.2f} MW")
    a(f"  Average net output           : {avg_MW:,.2f} MW")
    a(f"  Gross electrical generation  : {result.total_gross_MWh:,.2f} MWh")
    a(f"  Net electrical generation    : {result.total_MWh:,.2f} MWh")
    a("")
    a("-- EFFICIENCY --")
    a(f"  Electrical efficiency (avg)  : {result.electrical_efficiency * 100:,.2f} %")
    a(f"  Heat rate                    : {result.heat_rate:,.2f} MMBtu/MWh")
    a(f"  LNG consumption              : {result.lng_kg_per_MWh:,.2f} kg/MWh")
    a(f"  LNG consumption (energy)     : {lng_kg_per_mmbtu_out:,.4f} kg/MMBtu(out)")
    a("")
    a("-- HEAT --")
    a(f"  Waste heat                   : {result.waste_heat_MWh:,.2f} MWh")
    a(f"  Recoverable heat             : {result.recoverable_heat_MWh:,.2f} MWh")
    a("")
    a("-- EMISSIONS (approximate, combustion CO2 only) --")
    a(f"  CO2 emitted                  : {result.co2_kg:,.1f} kg  ({props.kg_to_tonnes(result.co2_kg):,.3f} t)")
    if result.total_MWh > 0:
        a(f"  CO2 intensity                : {result.co2_kg / result.total_MWh:,.2f} kg/MWh"
          f"  ({props.kg_to_tonnes(result.co2_kg) / result.total_MWh:,.4f} t/MWh)")
    a("")
    a("-- ECONOMICS --")
    a(f"  Fuel cost                    : £{econ.total_fuel_cost:,.0f}")
    a(f"  Carbon cost                  : £{econ.total_carbon_cost:,.0f}")
    a(f"  Maintenance cost              : £{econ.total_maintenance_cost:,.0f}")
    a(f"  Auxiliary electricity cost    : £{econ.total_auxiliary_cost:,.0f}")
    a(f"  Total operating cost         : £{econ.total_cost:,.0f}")
    a(f"  Cost per MWh                 : £{result.cost_per_MWh:,.2f} /MWh")
    a(f"  Marginal cost of next MWh    : £{result.marginal_cost_per_MWh:,.2f} /MWh")
    a(f"  Gross revenue                : £{result.gross_revenue:,.0f}")
    a(f"  Operating margin             : £{result.operating_margin:,.0f}")
    a("=" * 72)
    return "\n".join(lines)
