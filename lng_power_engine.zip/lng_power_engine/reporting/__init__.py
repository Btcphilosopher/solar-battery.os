"""Human-readable reports and publication-quality plots."""
