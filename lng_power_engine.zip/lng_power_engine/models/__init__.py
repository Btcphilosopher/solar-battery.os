"""Physical asset models: LNG fuel, combustion, turbine, generator, heat recovery, plant."""
