"""
models/lng.py
==============

Configurable LNG fuel composition and inventory.

Composition-derived properties (LHV, HHV, molar mass) are computed from
per-component reference values using a mass-weighted mixing rule -- this is
a standard engineering approximation for light-hydrocarbon mixtures and is
good to a fraction of a percent for typical pipeline-quality LNG. You can
also override the mixture LHV/HHV directly (e.g. from a certificate of
quality) via ``lhv_MJ_per_kg_override`` / ``hhv_MJ_per_kg_override``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from thermodynamics import combustion as combustion_chem
from thermodynamics import properties as props

# Reference (first-principles / NIST-adjacent) heating values, MJ/kg, of the
# pure components at standard conditions. These are widely published
# reference values, not measured for a specific site.
_COMPONENT_LHV_MJ_PER_KG = {"methane": 50.00, "ethane": 47.50, "propane": 46.35, "nitrogen": 0.0}
_COMPONENT_HHV_MJ_PER_KG = {"methane": 55.50, "ethane": 51.90, "propane": 50.35, "nitrogen": 0.0}


@dataclass
class LNGComposition:
    """LNG composition by mole fraction. Defaults are a typical pipeline-spec LNG."""

    methane_frac: float = 0.925
    ethane_frac: float = 0.055
    propane_frac: float = 0.015
    nitrogen_frac: float = 0.005
    lhv_MJ_per_kg_override: Optional[float] = None
    hhv_MJ_per_kg_override: Optional[float] = None

    def __post_init__(self) -> None:
        total = self.methane_frac + self.ethane_frac + self.propane_frac + self.nitrogen_frac
        assert abs(total - 1.0) < 1e-6, f"composition mole fractions must sum to 1.0 (got {total})"
        for name, val in self.as_dict().items():
            assert 0.0 <= val <= 1.0, f"{name} fraction must be within [0, 1]"

    def as_dict(self) -> dict:
        return {
            "methane": self.methane_frac,
            "ethane": self.ethane_frac,
            "propane": self.propane_frac,
            "nitrogen": self.nitrogen_frac,
        }

    @property
    def molar_mass_g_per_mol(self) -> float:
        return combustion_chem.mixture_molar_mass_g_per_mol(self.as_dict())

    @property
    def lhv_MJ_per_kg(self) -> float:
        if self.lhv_MJ_per_kg_override is not None:
            return self.lhv_MJ_per_kg_override
        return self._mass_weighted(_COMPONENT_LHV_MJ_PER_KG)

    @property
    def hhv_MJ_per_kg(self) -> float:
        if self.hhv_MJ_per_kg_override is not None:
            return self.hhv_MJ_per_kg_override
        return self._mass_weighted(_COMPONENT_HHV_MJ_PER_KG)

    def _mass_weighted(self, component_values: dict) -> float:
        """Mole-fraction -> mass-fraction weighted average of a per-kg property."""
        comp = self.as_dict()
        m_mix = self.molar_mass_g_per_mol
        total = 0.0
        for name, x_i in comp.items():
            m_i = combustion_chem.MOLAR_MASS[name]
            mass_frac_i = (x_i * m_i) / m_mix
            total += mass_frac_i * component_values[name]
        return total

    def stoichiometric_air_kg_per_kg_fuel(self) -> float:
        return combustion_chem.stoichiometric_air_kg_per_kg_fuel(self.as_dict())

    def co2_kg_per_kg_fuel(self) -> float:
        return combustion_chem.co2_kg_per_kg_fuel(self.as_dict())


@dataclass
class LNGInventory:
    """A quantity of LNG in store, with physical and commercial properties.

    Provide exactly one of ``mass_kg`` or ``volume_m3`` to size the
    inventory; whichever is not given is derived using ``density_kg_per_m3``.
    """

    composition: LNGComposition = field(default_factory=LNGComposition)
    mass_kg: Optional[float] = None
    volume_m3: Optional[float] = None
    density_kg_per_m3: float = 450.0  # typical LNG density ~430-470 kg/m3
    temperature_K: float = 111.5      # ~ -161.6 degC, LNG at atmospheric pressure
    pressure_kPa: float = 101.325
    price_per_tonne: Optional[float] = None

    def __post_init__(self) -> None:
        assert self.density_kg_per_m3 > 0, "density_kg_per_m3 must be > 0"
        assert self.temperature_K > 0, "temperature_K must be > 0"
        assert self.pressure_kPa > 0, "pressure_kPa must be > 0"
        if self.mass_kg is None and self.volume_m3 is None:
            raise ValueError("Provide either mass_kg or volume_m3")
        if self.mass_kg is None:
            assert self.volume_m3 is not None and self.volume_m3 >= 0
            self.mass_kg = props.m3_to_kg(self.volume_m3, self.density_kg_per_m3)
        elif self.volume_m3 is None:
            assert self.mass_kg >= 0
            self.volume_m3 = props.kg_to_m3(self.mass_kg, self.density_kg_per_m3)
        assert self.mass_kg >= 0, "mass_kg must be >= 0"

    # -- energy content ----------------------------------------------------

    @property
    def chemical_energy_MJ(self) -> float:
        return self.mass_kg * self.composition.lhv_MJ_per_kg

    @property
    def chemical_energy_GJ(self) -> float:
        return props.mj_to_gj(self.chemical_energy_MJ)

    @property
    def chemical_energy_MWh(self) -> float:
        return props.mj_to_mwh(self.chemical_energy_MJ)

    @property
    def chemical_energy_MMBtu(self) -> float:
        return props.mj_to_mmbtu(self.chemical_energy_MJ)

    @property
    def mass_tonnes(self) -> float:
        return props.kg_to_tonnes(self.mass_kg)

    # -- commercial ----------------------------------------------------

    def total_value(self) -> float:
        assert self.price_per_tonne is not None, "price_per_tonne not set"
        return self.mass_tonnes * self.price_per_tonne

    # -- mutation ----------------------------------------------------

    def consume(self, mass_kg: float) -> float:
        """Remove ``mass_kg`` of LNG from inventory. Returns chemical energy (MJ)
        released. Raises if insufficient inventory."""
        assert mass_kg >= 0, "mass_kg to consume must be >= 0"
        if mass_kg > self.mass_kg + 1e-9:
            raise ValueError(
                f"Insufficient LNG in inventory: requested {mass_kg:.3f} kg, have {self.mass_kg:.3f} kg"
            )
        energy_MJ = mass_kg * self.composition.lhv_MJ_per_kg
        self.mass_kg = max(0.0, self.mass_kg - mass_kg)
        self.volume_m3 = props.kg_to_m3(self.mass_kg, self.density_kg_per_m3)
        return energy_MJ
