"""
models/heat_recovery.py
=========================

Heat Recovery Steam Generator (HRSG) + steam turbine "bottoming cycle",
used in combined-cycle mode (or as a standalone waste-heat-to-power/CHP
add-on to a simple-cycle plant).
"""

from __future__ import annotations

from dataclasses import dataclass, field

from thermodynamics.efficiency import EfficiencyCurve, default_combined_cycle_bottoming_curve


@dataclass
class HeatRecoverySystem:
    enabled: bool = True
    hrsg_efficiency: float = 0.78
    """Fraction of gas-turbine exhaust thermal energy captured as steam
    energy in the HRSG (stack losses account for the remainder)."""
    steam_turbine_efficiency_curve: EfficiencyCurve = field(default=None)  # type: ignore[assignment]
    steam_cycle_generator_efficiency: float = 0.98
    condensate_and_process_heat_fraction: float = 0.0
    """Optional: fraction of recovered heat diverted to useful process
    heat / district heating rather than electricity (CHP mode). 0 = pure
    power generation from the bottoming cycle."""

    def __post_init__(self) -> None:
        assert 0.0 <= self.hrsg_efficiency <= 1.0
        assert 0.0 <= self.condensate_and_process_heat_fraction <= 1.0
        assert 0.0 < self.steam_cycle_generator_efficiency <= 1.0
        if self.steam_turbine_efficiency_curve is None:
            self.steam_turbine_efficiency_curve = default_combined_cycle_bottoming_curve()

    def recover(self, exhaust_heat_MW: float, load_fraction: float) -> dict:
        """Split GT exhaust heat into recovered/unrecovered, and recovered
        heat further into process heat, steam-cycle electricity and steam
        thermal (condenser) loss.

        Returns a dict of MW flows: recoverable_heat, unrecovered_exhaust,
        process_heat, steam_electrical, steam_thermal_loss, steam_generator_loss.
        """
        if not self.enabled or exhaust_heat_MW <= 0:
            return {
                "recoverable_heat_MW": 0.0,
                "unrecovered_exhaust_MW": exhaust_heat_MW,
                "process_heat_MW": 0.0,
                "steam_electrical_MW": 0.0,
                "steam_thermal_loss_MW": 0.0,
                "steam_generator_loss_MW": 0.0,
            }

        recoverable_heat_MW = exhaust_heat_MW * self.hrsg_efficiency
        unrecovered_exhaust_MW = exhaust_heat_MW - recoverable_heat_MW

        process_heat_MW = recoverable_heat_MW * self.condensate_and_process_heat_fraction
        power_cycle_heat_MW = recoverable_heat_MW - process_heat_MW

        st_eff = self.steam_turbine_efficiency_curve(load_fraction)
        if st_eff <= 0:
            st_eff = self.steam_turbine_efficiency_curve.points[0][1]  # fall back to lowest defined point

        steam_shaft_MW = power_cycle_heat_MW * st_eff
        steam_thermal_loss_MW = power_cycle_heat_MW * (1.0 - st_eff)
        steam_electrical_MW = steam_shaft_MW * self.steam_cycle_generator_efficiency
        steam_generator_loss_MW = steam_shaft_MW * (1.0 - self.steam_cycle_generator_efficiency)

        return {
            "recoverable_heat_MW": recoverable_heat_MW,
            "unrecovered_exhaust_MW": unrecovered_exhaust_MW,
            "process_heat_MW": process_heat_MW,
            "steam_electrical_MW": steam_electrical_MW,
            "steam_thermal_loss_MW": steam_thermal_loss_MW,
            "steam_generator_loss_MW": steam_generator_loss_MW,
        }
