"""
models/generator.py
=====================

Electrical generator model: converts shaft mechanical power to electrical
power at the machine terminals, with a configurable part-load efficiency
curve (generators are usually much flatter than turbines, but still lose a
little efficiency at very low and very high load from fixed losses and I2R
losses respectively).
"""

from __future__ import annotations

from dataclasses import dataclass, field

from thermodynamics.efficiency import EfficiencyCurve, default_generator_curve


@dataclass
class Generator:
    rated_capacity_MVA: float
    power_factor: float = 0.9
    efficiency_curve: EfficiencyCurve = field(default=None)  # type: ignore[assignment]

    def __post_init__(self) -> None:
        assert self.rated_capacity_MVA > 0
        assert 0.0 < self.power_factor <= 1.0
        if self.efficiency_curve is None:
            self.efficiency_curve = default_generator_curve()

    @property
    def rated_power_MW(self) -> float:
        return self.rated_capacity_MVA * self.power_factor

    def efficiency(self, load_fraction: float) -> float:
        eff = self.efficiency_curve(load_fraction)
        return eff if eff > 0 else 0.95  # generator is available even near zero mechanical load

    def electrical_output_MW(self, mechanical_power_MW: float, load_fraction: float) -> float:
        assert mechanical_power_MW >= 0
        return mechanical_power_MW * self.efficiency(load_fraction)
