"""
models/combustion.py
======================

Thin, user-configurable wrapper around ``thermodynamics.combustion`` that
carries the operating assumptions (excess air, combustion efficiency) as
plant configuration rather than function arguments scattered everywhere.
"""

from __future__ import annotations

from dataclasses import dataclass

from models.lng import LNGComposition
from thermodynamics import combustion as combustion_chem
from thermodynamics.combustion import CombustionResult


@dataclass
class CombustionModel:
    excess_air_ratio: float = 0.15
    combustion_efficiency: float = 0.995
    exhaust_specific_heat_kJ_per_kgK: float = 1.15

    def __post_init__(self) -> None:
        assert self.excess_air_ratio >= 0.0
        assert 0.0 < self.combustion_efficiency <= 1.0
        assert self.exhaust_specific_heat_kJ_per_kgK > 0

    def combust(
        self,
        fuel_kg: float,
        composition: LNGComposition,
        ambient_temperature_C: float = 15.0,
    ) -> CombustionResult:
        return combustion_chem.combust(
            fuel_kg=fuel_kg,
            mole_fractions=composition.as_dict(),
            lhv_MJ_per_kg=composition.lhv_MJ_per_kg,
            excess_air_ratio=self.excess_air_ratio,
            combustion_efficiency=self.combustion_efficiency,
            ambient_temperature_C=ambient_temperature_C,
            exhaust_specific_heat_kJ_per_kgK=self.exhaust_specific_heat_kJ_per_kgK,
        )
