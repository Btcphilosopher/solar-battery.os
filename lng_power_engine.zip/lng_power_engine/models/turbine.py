"""
models/turbine.py
===================

Gas turbine model: rated capacity, ambient derating, part-load thermal
efficiency curve, and ramp/start-up characteristics.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from config import AmbientConditions, RampConfig
from thermodynamics import properties as props
from thermodynamics.efficiency import EfficiencyCurve, default_simple_cycle_gt_curve


@dataclass
class GasTurbine:
    rated_power_MW: float
    ramp: RampConfig
    efficiency_curve: EfficiencyCurve = field(default=None)  # type: ignore[assignment]
    exhaust_expansion_efficiency: float = 0.90
    """Fraction of the combustor-exit-to-ambient temperature drop that is
    achieved through the turbine expansion (engineering approximation used
    only to estimate the *turbine exhaust* temperature for heat-recovery
    sizing -- see ``estimate_exhaust_temperature``)."""

    def __post_init__(self) -> None:
        assert self.rated_power_MW > 0, "rated_power_MW must be > 0"
        if self.efficiency_curve is None:
            self.efficiency_curve = default_simple_cycle_gt_curve(self.ramp.minimum_stable_load)
        assert 0.0 < self.exhaust_expansion_efficiency <= 1.0

    def derated_capacity_MW(self, ambient: AmbientConditions) -> float:
        factor = props.ambient_derate_factor(
            temperature_C=ambient.temperature_C,
            pressure_kPa=ambient.pressure_kPa,
            relative_humidity=ambient.relative_humidity,
            elevation_m=ambient.elevation_m,
        )
        capacity = self.rated_power_MW * factor
        assert capacity > 0
        return capacity

    def thermal_efficiency(self, load_fraction: float) -> float:
        """Fuel-LHV-to-shaft-mechanical-energy efficiency at this load fraction."""
        eff = self.efficiency_curve(load_fraction)
        assert 0.0 <= eff < 1.0
        return eff

    def estimate_turbine_exhaust_temperature_C(
        self, combustor_exit_temperature_C: float, ambient_temperature_C: float
    ) -> float:
        """Approximate post-expansion exhaust temperature.

        Engineering approximation: models the turbine expansion as
        recovering ``exhaust_expansion_efficiency`` of the available
        temperature drop between combustor exit and ambient as shaft work,
        leaving the remainder in the exhaust stream. This keeps the model
        self-consistent for HRSG sizing without requiring a full Brayton
        cycle pressure-ratio calculation.
        """
        drop_available = combustor_exit_temperature_C - ambient_temperature_C
        residual_fraction = 1.0 - self.exhaust_expansion_efficiency * 0.35
        # only a portion of exhaust-side "efficiency" maps 1:1 to temperature drop;
        # 0.35 keeps typical GT exhaust temperatures in the realistic 450-620 degC band
        return ambient_temperature_C + drop_available * residual_fraction
