"""
models/plant.py
=================

Top-level plant model that composes fuel, combustion, gas turbine,
generator and (optionally) heat recovery + steam bottoming cycle into a
single "give me a target net electrical output, get back a fully
energy-balanced operating point" interface.

This is the central physics engine of the whole package: everything in
``optimisation/`` and ``simulation/`` calls ``LNGPlant.operating_point``.

Energy-flow decomposition (see README for the full derivation) -- every
term is in MW (i.e. rate, not energy) and the whole set satisfies
conservation of energy to numerical tolerance:

    fuel_energy_rate_MW
        = combustion_loss_MW
        + shaft_mechanical_MW

    shaft_mechanical_MW
        = generator_loss_gt_MW
        + gt_gross_electrical_MW

    turbine_thermal_loss_MW (= exhaust heat leaving the GT)
        = recoverable_heat_MW + unrecovered_exhaust_MW      (combined-cycle / CHP)
        = waste (all of it)                                  (simple-cycle, no HRSG)

    recoverable_heat_MW
        = process_heat_MW + steam_electrical_MW + steam_thermal_loss_MW + steam_generator_loss_MW

    gross_electrical_MW = gt_gross_electrical_MW + steam_electrical_MW
    net_electrical_MW   = gross_electrical_MW - auxiliary_load_MW
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from config import AmbientConditions, CycleMode, RampConfig
from models.combustion import CombustionModel
from models.generator import Generator
from models.heat_recovery import HeatRecoverySystem
from models.lng import LNGComposition
from models.turbine import GasTurbine
from thermodynamics import properties as props


@dataclass
class PlantOperatingPoint:
    """A fully resolved, energy-balanced instantaneous operating point."""

    requested_net_MW: float
    load_fraction: float

    fuel_flow_kg_per_hr: float
    fuel_energy_rate_MW: float

    combustion_loss_MW: float
    shaft_mechanical_MW: float
    generator_loss_gt_MW: float
    gt_gross_electrical_MW: float

    turbine_thermal_loss_MW: float
    recoverable_heat_MW: float
    unrecovered_exhaust_MW: float
    process_heat_MW: float
    steam_electrical_MW: float
    steam_thermal_loss_MW: float
    steam_generator_loss_MW: float

    gross_electrical_MW: float
    auxiliary_load_MW: float
    net_electrical_MW: float

    electrical_efficiency: float          # net electrical / fuel energy rate
    gross_electrical_efficiency: float    # gross electrical / fuel energy rate
    heat_rate_MMBtu_per_MWh: float
    lng_kg_per_MWh: float

    waste_heat_MW: float
    combustor_exit_temperature_C: float
    turbine_exhaust_temperature_C: float
    exhaust_gas_flow_kg_per_hr: float
    co2_kg_per_hr: float

    energy_balance_residual_MW: float


@dataclass
class LNGPlant:
    """A configurable LNG-fuelled power plant (simple or combined cycle)."""

    name: str
    gas_turbine: GasTurbine
    generator: Generator
    combustion: CombustionModel = field(default_factory=CombustionModel)
    heat_recovery: Optional[HeatRecoverySystem] = None
    cycle_mode: CycleMode = CycleMode.SIMPLE_CYCLE
    auxiliary_load_fraction: float = 0.03
    """Parasitic/house load as a fraction of gross electrical output
    (fans, pumps, compressors, controls). Engineering approximation:
    typically 2-5% for a gas-fired plant."""
    composition: LNGComposition = field(default_factory=LNGComposition)

    def __post_init__(self) -> None:
        assert 0.0 <= self.auxiliary_load_fraction < 0.5
        if self.cycle_mode == CycleMode.COMBINED_CYCLE and self.heat_recovery is None:
            self.heat_recovery = HeatRecoverySystem(enabled=True)
        if self.cycle_mode == CycleMode.SIMPLE_CYCLE and self.heat_recovery is None:
            self.heat_recovery = HeatRecoverySystem(enabled=False)

    @property
    def ramp(self) -> RampConfig:
        return self.gas_turbine.ramp

    def rated_capacity_MW(self, ambient: AmbientConditions) -> float:
        """Ambient-derated gross rating of the *gas turbine* alone (MW).

        This is the physical basis for ``load_fraction`` (the GT's own
        Brayton-cycle load fraction, which drives both its thermal
        efficiency and its exhaust energy). It is NOT the plant's overall
        net capacity in combined-cycle mode, where the steam bottoming
        cycle adds further electrical output on top of the gas turbine's
        own generation for the same fuel input -- see ``net_capacity_MW``.
        """
        return self.gas_turbine.derated_capacity_MW(ambient)

    def minimum_stable_MW(self, ambient: AmbientConditions) -> float:
        """GT-gross MW at minimum stable load fraction (see rated_capacity_MW)."""
        return self.rated_capacity_MW(ambient) * self.ramp.minimum_stable_load

    def net_output_at_load_fraction(self, load_fraction: float, ambient: AmbientConditions) -> float:
        """Net electrical output (MW) the whole plant delivers at a given GT
        load fraction -- the monotonic map used to invert a *target net MW*
        into the load fraction that produces it (see ``operating_point``)."""
        return self._forward_pass(load_fraction, ambient).net_electrical_MW

    def net_capacity_MW(self, ambient: AmbientConditions) -> float:
        """Plant net rated capacity (MW), i.e. net output at 100% GT load.
        For combined-cycle plants this exceeds ``rated_capacity_MW(ambient)
        * (1 - auxiliary_load_fraction)`` because the steam bottoming cycle
        adds output from the same fuel input."""
        return self.net_output_at_load_fraction(1.0, ambient)

    def net_minimum_stable_MW(self, ambient: AmbientConditions) -> float:
        """Net electrical output (MW) at the GT's minimum stable load fraction."""
        return self.net_output_at_load_fraction(self.ramp.minimum_stable_load, ambient)

    # ------------------------------------------------------------------
    def _forward_pass(self, load_fraction: float, ambient: AmbientConditions) -> PlantOperatingPoint:
        """Deterministic physics forward pass: GT load fraction -> fully
        energy-balanced operating point. This is the one place the actual
        thermodynamic chain (combustion -> turbine -> generator [->
        HRSG -> steam turbine -> generator]) is evaluated; everything else
        (``operating_point``) inverts this map to hit a target net MW.
        """
        capacity_MW = self.rated_capacity_MW(ambient)
        load_fraction = min(max(load_fraction, 0.0), 1.0)
        gross_target_MW = load_fraction * capacity_MW

        turbine_eff = self.gas_turbine.thermal_efficiency(load_fraction)
        generator_eff = self.generator.efficiency(load_fraction)
        combustion_eff = self.combustion.combustion_efficiency

        if turbine_eff <= 0.0 or gross_target_MW <= 0.0:
            return self._zero_point(ambient)

        # Fuel energy rate required to hit the GT's own gross electrical
        # target via combustion -> turbine -> generator.
        fuel_energy_rate_MW = gross_target_MW / (combustion_eff * turbine_eff * generator_eff)

        combustion_loss_MW = fuel_energy_rate_MW * (1.0 - combustion_eff)
        shaft_mechanical_MW = fuel_energy_rate_MW * combustion_eff * turbine_eff
        gt_gross_electrical_MW = shaft_mechanical_MW * generator_eff
        generator_loss_gt_MW = shaft_mechanical_MW * (1.0 - generator_eff)
        turbine_thermal_loss_MW = fuel_energy_rate_MW * combustion_eff * (1.0 - turbine_eff)

        hr = self.heat_recovery.recover(turbine_thermal_loss_MW, load_fraction) if self.heat_recovery else {
            "recoverable_heat_MW": 0.0, "unrecovered_exhaust_MW": turbine_thermal_loss_MW,
            "process_heat_MW": 0.0, "steam_electrical_MW": 0.0,
            "steam_thermal_loss_MW": 0.0, "steam_generator_loss_MW": 0.0,
        }

        gross_electrical_MW = gt_gross_electrical_MW + hr["steam_electrical_MW"]
        auxiliary_load_MW = gross_electrical_MW * self.auxiliary_load_fraction
        net_electrical_MW = gross_electrical_MW - auxiliary_load_MW

        waste_heat_MW = (
            combustion_loss_MW
            + generator_loss_gt_MW
            + hr["unrecovered_exhaust_MW"]
            + hr["steam_thermal_loss_MW"]
            + hr["steam_generator_loss_MW"]
        )

        # -- fuel mass flow & combustion side-effects --
        lhv = self.composition.lhv_MJ_per_kg
        fuel_flow_kg_per_hr = props.mw_to_mj_per_hour(fuel_energy_rate_MW) / lhv

        combustion_result = self.combustion.combust(
            fuel_kg=fuel_flow_kg_per_hr,  # treat as a "per hour" batch to get per-hour flows
            composition=self.composition,
            ambient_temperature_C=ambient.temperature_C,
        )
        turbine_exhaust_temperature_C = self.gas_turbine.estimate_turbine_exhaust_temperature_C(
            combustion_result.exhaust_temperature_C, ambient.temperature_C
        )

        electrical_efficiency = net_electrical_MW / fuel_energy_rate_MW if fuel_energy_rate_MW > 0 else 0.0
        gross_electrical_efficiency = gross_electrical_MW / fuel_energy_rate_MW if fuel_energy_rate_MW > 0 else 0.0

        from thermodynamics.efficiency import heat_rate_MMBtu_per_MWh
        heat_rate = heat_rate_MMBtu_per_MWh(electrical_efficiency) if electrical_efficiency > 0 else float("inf")
        lng_kg_per_MWh = fuel_flow_kg_per_hr / net_electrical_MW if net_electrical_MW > 0 else float("inf")

        balance_check = (
            fuel_energy_rate_MW
            - (net_electrical_MW + auxiliary_load_MW + hr["process_heat_MW"] + waste_heat_MW)
        )

        point = PlantOperatingPoint(
            requested_net_MW=net_electrical_MW,
            load_fraction=load_fraction,
            fuel_flow_kg_per_hr=fuel_flow_kg_per_hr,
            fuel_energy_rate_MW=fuel_energy_rate_MW,
            combustion_loss_MW=combustion_loss_MW,
            shaft_mechanical_MW=shaft_mechanical_MW,
            generator_loss_gt_MW=generator_loss_gt_MW,
            gt_gross_electrical_MW=gt_gross_electrical_MW,
            turbine_thermal_loss_MW=turbine_thermal_loss_MW,
            recoverable_heat_MW=hr["recoverable_heat_MW"],
            unrecovered_exhaust_MW=hr["unrecovered_exhaust_MW"],
            process_heat_MW=hr["process_heat_MW"],
            steam_electrical_MW=hr["steam_electrical_MW"],
            steam_thermal_loss_MW=hr["steam_thermal_loss_MW"],
            steam_generator_loss_MW=hr["steam_generator_loss_MW"],
            gross_electrical_MW=gross_electrical_MW,
            auxiliary_load_MW=auxiliary_load_MW,
            net_electrical_MW=net_electrical_MW,
            electrical_efficiency=electrical_efficiency,
            gross_electrical_efficiency=gross_electrical_efficiency,
            heat_rate_MMBtu_per_MWh=heat_rate,
            lng_kg_per_MWh=lng_kg_per_MWh,
            waste_heat_MW=waste_heat_MW,
            combustor_exit_temperature_C=combustion_result.exhaust_temperature_C,
            turbine_exhaust_temperature_C=turbine_exhaust_temperature_C,
            exhaust_gas_flow_kg_per_hr=combustion_result.exhaust_gas_kg,
            co2_kg_per_hr=combustion_result.co2_kg,
            energy_balance_residual_MW=balance_check,
        )
        self._check_energy_conservation(point)
        return point

    # ------------------------------------------------------------------
    def operating_point(self, target_net_MW: float, ambient: AmbientConditions) -> PlantOperatingPoint:
        """Resolve a fully energy-balanced operating point for a requested
        net electrical output.

        The requested output is clipped to [net_minimum_stable_MW,
        net_capacity_MW]; a request of ~0 returns an all-zero (shutdown)
        point. Internally this inverts ``_forward_pass`` (net MW is not a
        free physical input -- GT load fraction is) via a bounded root
        find, since in combined-cycle mode net output is a mildly
        nonlinear function of load fraction.
        """
        if target_net_MW <= 1e-9:
            return self._zero_point(ambient)

        net_cap = self.net_capacity_MW(ambient)
        net_min = self.net_minimum_stable_MW(ambient)
        clipped_net_MW = min(max(target_net_MW, net_min), net_cap)

        lo, hi = self.ramp.minimum_stable_load, 1.0

        def f(lf: float) -> float:
            return self.net_output_at_load_fraction(lf, ambient) - clipped_net_MW

        f_lo, f_hi = f(lo), f(hi)
        if abs(f_lo) < 1e-6:
            load_fraction = lo
        elif abs(f_hi) < 1e-6:
            load_fraction = hi
        elif f_lo > 0 or f_hi < 0:
            # Non-monotonic edge case (unusual efficiency curve shapes) --
            # fall back to whichever bound is closer to the target.
            load_fraction = lo if abs(f_lo) < abs(f_hi) else hi
        else:
            from scipy.optimize import brentq
            load_fraction = brentq(f, lo, hi, xtol=1e-6)

        point = self._forward_pass(load_fraction, ambient)
        point.requested_net_MW = target_net_MW
        self._check_within_capacity(point, net_cap)
        return point

    def _zero_point(self, ambient: AmbientConditions) -> PlantOperatingPoint:
        return PlantOperatingPoint(
            requested_net_MW=0.0, load_fraction=0.0, fuel_flow_kg_per_hr=0.0, fuel_energy_rate_MW=0.0,
            combustion_loss_MW=0.0, shaft_mechanical_MW=0.0, generator_loss_gt_MW=0.0, gt_gross_electrical_MW=0.0,
            turbine_thermal_loss_MW=0.0, recoverable_heat_MW=0.0, unrecovered_exhaust_MW=0.0, process_heat_MW=0.0,
            steam_electrical_MW=0.0, steam_thermal_loss_MW=0.0, steam_generator_loss_MW=0.0,
            gross_electrical_MW=0.0, auxiliary_load_MW=0.0, net_electrical_MW=0.0,
            electrical_efficiency=0.0, gross_electrical_efficiency=0.0, heat_rate_MMBtu_per_MWh=float("inf"),
            lng_kg_per_MWh=float("inf"), waste_heat_MW=0.0,
            combustor_exit_temperature_C=ambient.temperature_C, turbine_exhaust_temperature_C=ambient.temperature_C,
            exhaust_gas_flow_kg_per_hr=0.0, co2_kg_per_hr=0.0, energy_balance_residual_MW=0.0,
        )

    @staticmethod
    def _check_energy_conservation(point: PlantOperatingPoint) -> None:
        """Physical sanity checks that hold for ANY resolved operating
        point, independent of what target it was solved for."""
        assert point.fuel_flow_kg_per_hr >= -1e-9, "fuel flow must be >= 0"
        assert 0.0 <= point.electrical_efficiency < 1.0, "electrical efficiency out of physical range"
        assert 0.0 <= point.gross_electrical_efficiency < 1.0, "gross electrical efficiency out of physical range"
        assert 0.0 <= point.load_fraction <= 1.0 + 1e-9, "load fraction out of range"
        assert point.net_electrical_MW >= -1e-9, "net output must be >= 0"
        # Energy conservation: residual should be a small fraction of fuel input
        tol = max(1e-6, 1e-4 * max(point.fuel_energy_rate_MW, 1.0))
        assert abs(point.energy_balance_residual_MW) < tol, (
            f"energy balance residual too large: {point.energy_balance_residual_MW} MW "
            f"(fuel input {point.fuel_energy_rate_MW} MW)"
        )

    @staticmethod
    def _check_within_capacity(point: PlantOperatingPoint, net_capacity_MW: float) -> None:
        """Additional check only meaningful once a point has been solved
        against a specific target net MW (i.e. via ``operating_point``)."""
        assert point.net_electrical_MW <= net_capacity_MW + 1e-6, "net output exceeds rated capacity"

    # ------------------------------------------------------------------
    def best_efficiency_operating_point_MW(self, ambient: AmbientConditions) -> float:
        """Find the net-MW output that maximises net electrical efficiency,
        using SciPy's bounded scalar minimiser on -efficiency(load).
        """
        from scipy.optimize import minimize_scalar

        net_capacity_MW = self.net_capacity_MW(ambient)
        net_min_MW = self.net_minimum_stable_MW(ambient)

        def neg_eff(net_mw: float) -> float:
            pt = self.operating_point(net_mw, ambient)
            return -pt.electrical_efficiency

        result = minimize_scalar(
            neg_eff, bounds=(net_min_MW, net_capacity_MW), method="bounded",
            options={"xatol": 1e-3},
        )
        return float(result.x)


def build_plant(
    name: str = "LNG-CCGT-1",
    rated_power_MW: float = 500.0,
    minimum_stable_load: float = 0.35,
    generator_efficiency: float = 0.98,
    ramp_up_MW_per_min: Optional[float] = None,
    ramp_down_MW_per_min: Optional[float] = None,
    startup_time_min: float = 12.0,
    shutdown_time_min: float = 6.0,
    cycle_mode: CycleMode = CycleMode.COMBINED_CYCLE,
    auxiliary_load_fraction: float = 0.03,
    composition: Optional[LNGComposition] = None,
) -> "LNGPlant":
    """Convenience factory for a representative LNG power plant.

    ``generator_efficiency`` sets the flat (rated-load) point of the
    generator's efficiency curve; the curve shape around it is the default
    engineering-approximation shape from ``thermodynamics.efficiency``.
    Ramp rates default to a commonly-cited ~8%/min of rated capacity for a
    heavy-duty gas turbine if not supplied.
    """
    from thermodynamics.efficiency import EfficiencyCurve

    ramp_up = ramp_up_MW_per_min if ramp_up_MW_per_min is not None else 0.08 * rated_power_MW
    ramp_down = ramp_down_MW_per_min if ramp_down_MW_per_min is not None else 0.10 * rated_power_MW

    ramp = RampConfig(
        minimum_output_MW=minimum_stable_load * rated_power_MW,
        maximum_output_MW=rated_power_MW,
        ramp_up_MW_per_min=ramp_up,
        ramp_down_MW_per_min=ramp_down,
        minimum_stable_load=minimum_stable_load,
        startup_time_min=startup_time_min,
        shutdown_time_min=shutdown_time_min,
    )
    gt = GasTurbine(rated_power_MW=rated_power_MW, ramp=ramp)

    gen_curve = EfficiencyCurve(
        points=[
            (0.20, generator_efficiency - 0.020),
            (0.40, generator_efficiency - 0.005),
            (0.60, generator_efficiency + 0.002),
            (0.80, generator_efficiency + 0.005),
            (1.00, generator_efficiency),
        ],
        name="generator",
    )
    generator = Generator(rated_capacity_MVA=rated_power_MW / 0.9, power_factor=0.9, efficiency_curve=gen_curve)

    heat_recovery = HeatRecoverySystem(enabled=(cycle_mode == CycleMode.COMBINED_CYCLE))

    return LNGPlant(
        name=name,
        gas_turbine=gt,
        generator=generator,
        heat_recovery=heat_recovery,
        cycle_mode=cycle_mode,
        auxiliary_load_fraction=auxiliary_load_fraction,
        composition=composition or LNGComposition(),
    )
