"""
thermodynamics/properties.py
=============================

First-principles unit conversions plus one engineering-approximation
function for ambient derating of gas-turbine output.

All conversion factors here are first-principles (exact definitions or
CODATA/NIST-grade constants), clearly separated from the derating model
which is explicitly an engineering approximation.
"""

from __future__ import annotations

import math

# ---------------------------------------------------------------------------
# First-principles constants
# ---------------------------------------------------------------------------

KG_PER_TONNE = 1000.0
SECONDS_PER_HOUR = 3600.0
MJ_PER_MWH = 3600.0            # 1 MWh = 3600 MJ (exact, from kWh = 3.6 MJ)
MJ_PER_KWH = 3.6
MJ_PER_MMBTU = 1055.05585262   # 1 MMBtu (IT) = 1055.05585262 MJ (exact definition)
MMBTU_PER_MWH = MJ_PER_MWH / MJ_PER_MMBTU  # ≈ 3.412142

R_DRY_AIR_J_PER_KGK = 287.058  # specific gas constant, dry air
R_WATER_VAPOUR_J_PER_KGK = 461.495

STANDARD_PRESSURE_KPA = 101.325
STANDARD_TEMPERATURE_C = 15.0  # ISO condition for gas turbine ratings


# ---------------------------------------------------------------------------
# Unit conversions (first-principles / exact)
# ---------------------------------------------------------------------------

def kg_to_tonnes(kg: float) -> float:
    return kg / KG_PER_TONNE


def tonnes_to_kg(tonnes: float) -> float:
    return tonnes * KG_PER_TONNE


def m3_to_kg(volume_m3: float, density_kg_per_m3: float) -> float:
    assert density_kg_per_m3 > 0, "density must be > 0"
    return volume_m3 * density_kg_per_m3


def kg_to_m3(mass_kg: float, density_kg_per_m3: float) -> float:
    assert density_kg_per_m3 > 0, "density must be > 0"
    return mass_kg / density_kg_per_m3


def mj_to_gj(mj: float) -> float:
    return mj / 1000.0


def gj_to_mj(gj: float) -> float:
    return gj * 1000.0


def mj_to_mwh(mj: float) -> float:
    return mj / MJ_PER_MWH


def mwh_to_mj(mwh: float) -> float:
    return mwh * MJ_PER_MWH


def mj_to_mmbtu(mj: float) -> float:
    return mj / MJ_PER_MMBTU


def mmbtu_to_mj(mmbtu: float) -> float:
    return mmbtu * MJ_PER_MMBTU


def mwh_to_mmbtu(mwh: float) -> float:
    return mwh * MMBTU_PER_MWH


def mmbtu_to_mwh(mmbtu: float) -> float:
    return mmbtu / MMBTU_PER_MWH


def mw_to_mj_per_hour(mw: float) -> float:
    """Power (MW = MJ/s) integrated over one hour -> MJ."""
    return mw * SECONDS_PER_HOUR


def kj_to_mj(kj: float) -> float:
    return kj / 1000.0


# ---------------------------------------------------------------------------
# Engineering approximations: air properties & ambient derating
# ---------------------------------------------------------------------------

def saturation_vapour_pressure_kPa(temperature_C: float) -> float:
    """Magnus-Tetens approximation of water saturation vapour pressure.

    Engineering approximation, accurate to within ~0.1% over -20..50 degC.
    """
    return 0.61094 * math.exp((17.625 * temperature_C) / (temperature_C + 243.04))


def humid_air_density_kg_per_m3(
    temperature_C: float,
    pressure_kPa: float,
    relative_humidity: float,
) -> float:
    """Approximate moist-air density via ideal-gas mixing of dry air and water vapour.

    Engineering approximation (ideal gas law); adequate for turbine inlet air
    density estimates, not for high-precision psychrometrics.
    """
    t_k = temperature_C + 273.15
    p_sat = saturation_vapour_pressure_kPa(temperature_C)
    p_vapour = relative_humidity * p_sat
    p_dry = max(pressure_kPa - p_vapour, 0.0)
    rho_dry = (p_dry * 1000.0) / (R_DRY_AIR_J_PER_KGK * t_k)
    rho_vapour = (p_vapour * 1000.0) / (R_WATER_VAPOUR_J_PER_KGK * t_k)
    return rho_dry + rho_vapour


def barometric_pressure_kPa(elevation_m: float, sea_level_kPa: float = STANDARD_PRESSURE_KPA) -> float:
    """International barometric formula approximation (troposphere)."""
    return sea_level_kPa * (1 - 2.25577e-5 * elevation_m) ** 5.25588


def ambient_derate_factor(
    temperature_C: float,
    pressure_kPa: float,
    relative_humidity: float,
    elevation_m: float = 0.0,
    reference_temperature_C: float = STANDARD_TEMPERATURE_C,
    reference_pressure_kPa: float = STANDARD_PRESSURE_KPA,
) -> float:
    """Combined ambient derating factor applied to rated (ISO) turbine output.

    ENGINEERING APPROXIMATION -- not a manufacturer correction curve.
    Rules of thumb used (broadly consistent with published gas-turbine
    performance literature for heavy-duty industrial units):

    * Temperature: roughly -0.6%/degC above the ISO reference temperature
      (air density and mass flow through the compressor fall as inlet air
      warms). This is applied symmetrically below the reference too
      (colder air -> denser air -> more mass flow -> more output), clipped
      so the factor never exceeds a generous +15% at very cold conditions.
    * Pressure / elevation: output scales roughly with ambient air density,
      i.e. with absolute ambient pressure. If ``elevation_m`` is supplied
      and differs from what ``pressure_kPa`` alone implies, the elevation
      effect is folded in via the barometric formula so a caller does not
      have to compute site pressure by hand.
    * Humidity: a small negative effect on power output from lower air
      density of humid air is included (partial molar mass effect),
      typically << 1%.

    Returns a multiplicative factor to apply to rated ISO output.
    """
    # Effective ambient pressure: combine explicit pressure with elevation info.
    if elevation_m and abs(elevation_m) > 1e-6:
        site_pressure_kPa = min(pressure_kPa, barometric_pressure_kPa(elevation_m, reference_pressure_kPa))
    else:
        site_pressure_kPa = pressure_kPa

    temp_delta = temperature_C - reference_temperature_C
    temp_factor = 1.0 - 0.006 * temp_delta
    temp_factor = min(max(temp_factor, 0.5), 1.15)

    pressure_factor = site_pressure_kPa / reference_pressure_kPa
    pressure_factor = min(max(pressure_factor, 0.5), 1.05)

    rho_actual = humid_air_density_kg_per_m3(temperature_C, site_pressure_kPa, relative_humidity)
    rho_dry_reference = humid_air_density_kg_per_m3(reference_temperature_C, reference_pressure_kPa, 0.0)
    humidity_factor = 1.0 + 0.15 * ((rho_actual / rho_dry_reference) - (
        humid_air_density_kg_per_m3(temperature_C, site_pressure_kPa, 0.0) / rho_dry_reference
    ))
    humidity_factor = min(max(humidity_factor, 0.95), 1.02)

    combined = temp_factor * pressure_factor * humidity_factor
    return min(max(combined, 0.4), 1.20)
