"""
thermodynamics/combustion.py
=============================

Simplified but physically grounded stoichiometric combustion chemistry for
an LNG-like fuel mixture of methane, ethane, propane and inert nitrogen.

Reactions used (complete combustion, first-principles balanced equations):

    CH4  + 2   O2 -> CO2 + 2 H2O
    C2H6 + 3.5 O2 -> 2 CO2 + 3 H2O
    C3H8 + 5   O2 -> 3 CO2 + 4 H2O
    N2 (inert, does not react)

This module deliberately stops at stoichiometry, mixture molar mass,
air requirement, excess-air handling and a lumped-capacitance exhaust
temperature estimate. It is explicitly NOT a CFD or detailed chemical
kinetics model -- flame temperature, dissociation, NOx formation, and
radiative heat transfer are all out of scope.
"""

from __future__ import annotations

from dataclasses import dataclass

# ---------------------------------------------------------------------------
# First-principles molecular data
# ---------------------------------------------------------------------------

# Molar masses, g/mol (IUPAC standard atomic weights)
M_CH4 = 16.043
M_C2H6 = 30.070
M_C3H8 = 44.097
M_N2 = 28.014
M_O2 = 31.998
M_CO2 = 44.009
M_H2O = 18.015
M_AIR = 28.9647

O2_MOLE_FRACTION_IN_AIR = 0.2095

# Stoichiometric O2 moles required per mole of fuel species
O2_PER_MOLE = {"methane": 2.0, "ethane": 3.5, "propane": 5.0, "nitrogen": 0.0}
# Carbon atoms per molecule (for CO2 mass balance)
CARBON_ATOMS = {"methane": 1, "ethane": 2, "propane": 3, "nitrogen": 0}
MOLAR_MASS = {"methane": M_CH4, "ethane": M_C2H6, "propane": M_C3H8, "nitrogen": M_N2}


@dataclass
class CombustionResult:
    fuel_kg: float
    stoichiometric_air_kg: float
    excess_air_ratio: float
    actual_air_kg: float
    air_fuel_ratio: float          # actual air:fuel mass ratio
    exhaust_gas_kg: float
    energy_released_MJ: float
    combustion_efficiency: float
    exhaust_temperature_C: float
    co2_kg: float


def mixture_molar_mass_g_per_mol(mole_fractions: dict) -> float:
    """Mass-weighted molar mass of the fuel mixture, g/mol."""
    total = sum(mole_fractions.get(k, 0.0) * MOLAR_MASS[k] for k in MOLAR_MASS)
    assert total > 0, "mixture molar mass must be > 0"
    return total


def stoichiometric_air_kg_per_kg_fuel(mole_fractions: dict) -> float:
    """Mass of dry air required per kg of fuel for complete (stoichiometric)
    combustion, derived from first-principles balanced reactions.
    """
    m_mix = mixture_molar_mass_g_per_mol(mole_fractions)
    o2_moles_per_mole_fuel = sum(mole_fractions.get(k, 0.0) * O2_PER_MOLE[k] for k in O2_PER_MOLE)
    air_moles_per_mole_fuel = o2_moles_per_mole_fuel / O2_MOLE_FRACTION_IN_AIR
    air_mass_per_mole_fuel_g = air_moles_per_mole_fuel * M_AIR
    return air_mass_per_mole_fuel_g / m_mix  # g/g = kg air / kg fuel


def co2_kg_per_kg_fuel(mole_fractions: dict) -> float:
    """kg CO2 produced per kg fuel burned, from carbon mass balance."""
    m_mix = mixture_molar_mass_g_per_mol(mole_fractions)
    co2_g_per_mole_fuel = sum(mole_fractions.get(k, 0.0) * CARBON_ATOMS[k] * M_CO2 for k in CARBON_ATOMS)
    return co2_g_per_mole_fuel / m_mix


def combust(
    fuel_kg: float,
    mole_fractions: dict,
    lhv_MJ_per_kg: float,
    excess_air_ratio: float = 0.15,
    combustion_efficiency: float = 0.995,
    ambient_temperature_C: float = 15.0,
    exhaust_specific_heat_kJ_per_kgK: float = 1.15,
) -> CombustionResult:
    """Run a simplified combustion mass/energy balance for a batch of fuel.

    Parameters
    ----------
    fuel_kg : mass of LNG fuel burned in this batch/timestep
    mole_fractions : LNG composition (methane/ethane/propane/nitrogen mole fractions)
    lhv_MJ_per_kg : lower heating value of the fuel mixture
    excess_air_ratio : fractional excess over stoichiometric air (e.g. 0.15 = 15% excess)
    combustion_efficiency : fraction of chemical energy actually released as heat
    ambient_temperature_C : combustion air inlet temperature
    exhaust_specific_heat_kJ_per_kgK : lumped cp for combustion products,
        an engineering approximation (~1.10-1.20 kJ/kg.K is typical for
        turbine combustor exit gas composition at these temperatures)

    Notes
    -----
    The "exhaust_temperature_C" returned here is the *combustor exit*
    temperature estimate (energy released / (mass flow * cp)), i.e. before
    any expansion work is extracted by the turbine. See
    ``models/turbine.py`` for the post-expansion exhaust estimate used for
    heat-recovery calculations.
    """
    assert fuel_kg >= 0, "fuel_kg must be >= 0"
    assert excess_air_ratio >= 0, "excess_air_ratio must be >= 0"
    assert 0.0 < combustion_efficiency <= 1.0, "combustion_efficiency must be in (0, 1]"
    assert lhv_MJ_per_kg > 0, "lhv_MJ_per_kg must be > 0"

    stoich_air_kg_per_kg = stoichiometric_air_kg_per_kg_fuel(mole_fractions)
    stoichiometric_air_kg = stoich_air_kg_per_kg * fuel_kg
    actual_air_kg = stoichiometric_air_kg * (1.0 + excess_air_ratio)
    air_fuel_ratio = (actual_air_kg / fuel_kg) if fuel_kg > 0 else stoich_air_kg_per_kg * (1 + excess_air_ratio)

    energy_released_MJ = fuel_kg * lhv_MJ_per_kg * combustion_efficiency

    exhaust_gas_kg = fuel_kg + actual_air_kg  # mass conservation

    if exhaust_gas_kg > 0:
        delta_t = (energy_released_MJ * 1000.0) / (exhaust_gas_kg * exhaust_specific_heat_kJ_per_kgK)
    else:
        delta_t = 0.0
    exhaust_temperature_C = ambient_temperature_C + delta_t

    co2_kg = co2_kg_per_kg_fuel(mole_fractions) * fuel_kg

    return CombustionResult(
        fuel_kg=fuel_kg,
        stoichiometric_air_kg=stoichiometric_air_kg,
        excess_air_ratio=excess_air_ratio,
        actual_air_kg=actual_air_kg,
        air_fuel_ratio=air_fuel_ratio,
        exhaust_gas_kg=exhaust_gas_kg,
        energy_released_MJ=energy_released_MJ,
        combustion_efficiency=combustion_efficiency,
        exhaust_temperature_C=exhaust_temperature_C,
        co2_kg=co2_kg,
    )
