"""
thermodynamics/efficiency.py
==============================

Part-load efficiency curves and heat-rate helpers.

ENGINEERING APPROXIMATION: real gas turbines and combined-cycle plants do
not follow a single universal efficiency-vs-load curve -- it depends on the
specific machine, inlet guide vane control strategy, ambient conditions and
degradation state. The curves defined here are representative, smooth,
monotonic-ish shapes consistent with widely published part-load behaviour
(low efficiency at low load, a broad efficiency plateau around 70-90% load,
and a small efficiency give-back right at 100% load for many machines).
They are fully configurable: pass your own ``(load_fraction, efficiency)``
control points to ``EfficiencyCurve``.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence, Tuple

import numpy as np
from scipy.interpolate import PchipInterpolator

from . import properties as props


@dataclass
class EfficiencyCurve:
    """A monotone-shape-preserving interpolated part-load efficiency curve.

    ``points`` is a sequence of (load_fraction, efficiency) pairs, load
    fraction in [0, 1], efficiency in [0, 1). Uses SciPy's PCHIP
    interpolator (shape-preserving cubic Hermite) so the curve doesn't
    overshoot between control points, unlike a plain cubic spline.
    """

    points: Sequence[Tuple[float, float]]
    minimum_stable_load: float = 0.0
    name: str = "efficiency_curve"

    def __post_init__(self) -> None:
        pts = sorted(self.points, key=lambda p: p[0])
        loads = [p[0] for p in pts]
        effs = [p[1] for p in pts]
        assert loads[0] >= 0.0 and loads[-1] <= 1.0 + 1e-9, "load fractions must be within [0, 1]"
        for e in effs:
            assert 0.0 <= e < 1.0, f"efficiency {e} must be in [0, 1)"
        assert all(x < y for x, y in zip(loads, loads[1:])), "load fraction control points must be strictly increasing"
        self._loads = np.array(loads, dtype=float)
        self._effs = np.array(effs, dtype=float)
        self._interp = PchipInterpolator(self._loads, self._effs, extrapolate=False)

    def __call__(self, load_fraction: float) -> float:
        """Return efficiency at the given load fraction.

        Returns 0.0 ("unavailable") below the minimum stable load or at
        zero load, matching real turbine behaviour (a machine cannot run,
        and therefore has no defined electrical efficiency, below its
        minimum stable/synchronous load).
        """
        if load_fraction <= 0.0 or load_fraction < self.minimum_stable_load:
            return 0.0
        lf = min(max(load_fraction, self._loads[0]), self._loads[-1])
        value = float(self._interp(lf))
        return min(max(value, 0.0), 0.999)

    def as_arrays(self, n: int = 101) -> Tuple[np.ndarray, np.ndarray]:
        loads = np.linspace(self._loads[0], self._loads[-1], n)
        effs = np.array([self(l) for l in loads])
        return loads, effs


# ---------------------------------------------------------------------------
# Representative default curves (engineering approximations, overridable)
# ---------------------------------------------------------------------------

def default_simple_cycle_gt_curve(min_stable_load: float = 0.20) -> EfficiencyCurve:
    """Simple-cycle heavy-duty gas turbine: thermal (fuel-LHV -> shaft) efficiency."""
    return EfficiencyCurve(
        points=[
            (min_stable_load, 0.235),
            (0.40, 0.315),
            (0.60, 0.365),
            (0.80, 0.390),
            (0.90, 0.398),
            (1.00, 0.390),  # slight give-back at MCR, common for many machines
        ],
        minimum_stable_load=min_stable_load,
        name="simple_cycle_gas_turbine",
    )


def default_combined_cycle_bottoming_curve(min_stable_load: float = 0.20) -> EfficiencyCurve:
    """Steam-turbine bottoming-cycle efficiency (recovered exhaust heat -> shaft),
    i.e. fraction of the *recoverable* heat that becomes shaft work."""
    return EfficiencyCurve(
        points=[
            (min_stable_load, 0.22),
            (0.40, 0.28),
            (0.60, 0.32),
            (0.80, 0.345),
            (1.00, 0.35),
        ],
        minimum_stable_load=min_stable_load,
        name="steam_bottoming_cycle",
    )


def default_generator_curve(min_stable_load: float = 0.0) -> EfficiencyCurve:
    """Electrical generator (shaft -> electrical terminals) efficiency."""
    return EfficiencyCurve(
        points=[
            (0.20, 0.960),
            (0.40, 0.975),
            (0.60, 0.982),
            (0.80, 0.985),
            (1.00, 0.980),
        ],
        minimum_stable_load=min_stable_load,
        name="generator",
    )


def default_auxiliary_load_curve(min_stable_load: float = 0.0) -> EfficiencyCurve:
    """Auxiliary/parasitic load as a *fraction of gross output consumed*,
    expressed here (unusually) as (1 - aux_fraction) so it fits the same
    EfficiencyCurve machinery; see models/plant.py for direct use of the
    fraction form via ``auxiliary_load_fraction``.
    """
    return EfficiencyCurve(
        points=[
            (0.20, 0.94),
            (0.40, 0.95),
            (0.60, 0.96),
            (0.80, 0.965),
            (1.00, 0.965),
        ],
        minimum_stable_load=min_stable_load,
        name="auxiliary_availability",
    )


# ---------------------------------------------------------------------------
# Heat-rate helpers (first-principles conversion of an efficiency figure)
# ---------------------------------------------------------------------------

def heat_rate_kJ_per_kWh(electrical_efficiency: float) -> float:
    assert 0.0 < electrical_efficiency < 1.0, "electrical_efficiency must be in (0, 1)"
    return props.MJ_PER_KWH * 1000.0 / electrical_efficiency


def heat_rate_MMBtu_per_MWh(electrical_efficiency: float) -> float:
    assert 0.0 < electrical_efficiency < 1.0, "electrical_efficiency must be in (0, 1)"
    return props.MMBTU_PER_MWH / electrical_efficiency


def electrical_efficiency_from_heat_rate_MMBtu_per_MWh(heat_rate: float) -> float:
    assert heat_rate > 0
    eff = props.MMBTU_PER_MWH / heat_rate
    assert 0.0 < eff < 1.0, "resulting efficiency out of physical range - check heat_rate units"
    return eff
