"""Thermodynamic primitives: unit conversions, combustion chemistry, efficiency curves."""
