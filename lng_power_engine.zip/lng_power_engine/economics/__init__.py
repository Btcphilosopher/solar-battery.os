"""Economic model: fuel/operating/carbon costs, revenue, margins, dispatch economics."""
