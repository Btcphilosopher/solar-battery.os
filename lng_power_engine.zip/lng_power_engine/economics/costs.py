"""
economics/costs.py
====================

Economic evaluation: fuel cost, operating cost, carbon cost, revenue,
margin and a marginal-cost-based dispatch recommendation.
"""

from __future__ import annotations

from dataclasses import dataclass

from config import EconomicConfig
from models.lng import LNGComposition
from models.plant import PlantOperatingPoint
from thermodynamics import properties as props


@dataclass
class EconomicResult:
    fuel_cost_per_MWh: float
    maintenance_cost_per_MWh: float
    carbon_cost_per_MWh: float
    total_generation_cost_per_MWh: float
    marginal_generation_cost_per_MWh: float
    gross_revenue: float
    total_cost: float
    carbon_cost_total: float
    operating_margin: float
    dispatch_recommended: bool


def lng_price_per_MWh_th(economics: EconomicConfig, composition: LNGComposition, density_kg_per_m3: float = 450.0) -> float:
    """Resolve LNG price to £/MWh(thermal), from whichever price basis was given."""
    if economics.lng_price_per_MWh_th is not None:
        return economics.lng_price_per_MWh_th
    assert economics.lng_price_per_tonne is not None
    lhv_MJ_per_kg = composition.lhv_MJ_per_kg
    mwh_per_tonne = props.mj_to_mwh(lhv_MJ_per_kg * 1000.0)
    return economics.lng_price_per_tonne / mwh_per_tonne


def evaluate_operating_point(
    point: PlantOperatingPoint,
    economics: EconomicConfig,
    composition: LNGComposition,
    include_startup_cost: bool = False,
) -> EconomicResult:
    """Economic evaluation of a single (steady-state) operating point."""
    price_per_MWh_th = lng_price_per_MWh_th(economics, composition)
    fuel_energy_MWh = props.mj_to_mwh(point.fuel_energy_rate_MW * 3600.0)  # per hour of operation
    net_MWh = point.net_electrical_MW  # per hour

    if net_MWh <= 1e-9:
        return EconomicResult(
            fuel_cost_per_MWh=float("inf"), maintenance_cost_per_MWh=economics.maintenance_cost_per_MWh,
            carbon_cost_per_MWh=float("inf"), total_generation_cost_per_MWh=float("inf"),
            marginal_generation_cost_per_MWh=float("inf"), gross_revenue=0.0, total_cost=0.0,
            carbon_cost_total=0.0, operating_margin=0.0, dispatch_recommended=False,
        )

    fuel_cost_per_hour = fuel_energy_MWh * price_per_MWh_th
    fuel_cost_per_MWh = fuel_cost_per_hour / net_MWh

    carbon_cost_per_hour = props.kg_to_tonnes(point.co2_kg_per_hr) * economics.carbon_price_per_tonne_CO2
    carbon_cost_per_MWh = carbon_cost_per_hour / net_MWh

    maintenance_cost_per_MWh = economics.maintenance_cost_per_MWh

    aux_cost_per_hour = point.auxiliary_load_MW * economics.auxiliary_electricity_price_per_MWh
    aux_cost_per_MWh = aux_cost_per_hour / net_MWh

    total_generation_cost_per_MWh = (
        fuel_cost_per_MWh + carbon_cost_per_MWh + maintenance_cost_per_MWh + aux_cost_per_MWh
    )

    # Marginal cost: cost of the fuel to make one more MWh at *this* point's
    # efficiency (a first-order local approximation of dC/dMWh; ignores
    # second-order curvature of the efficiency curve away from this point).
    marginal_fuel_MWh_th_per_MWh_e = 1.0 / point.electrical_efficiency if point.electrical_efficiency > 0 else float("inf")
    marginal_generation_cost_per_MWh = (
        marginal_fuel_MWh_th_per_MWh_e * price_per_MWh_th + carbon_cost_per_MWh + maintenance_cost_per_MWh
    )

    total_cost_per_hour = total_generation_cost_per_MWh * net_MWh
    if include_startup_cost:
        total_cost_per_hour += economics.startup_cost

    gross_revenue_per_hour = net_MWh * economics.electricity_price_per_MWh
    operating_margin_per_hour = gross_revenue_per_hour - total_cost_per_hour

    dispatch_recommended = economics.electricity_price_per_MWh >= marginal_generation_cost_per_MWh

    return EconomicResult(
        fuel_cost_per_MWh=fuel_cost_per_MWh,
        maintenance_cost_per_MWh=maintenance_cost_per_MWh,
        carbon_cost_per_MWh=carbon_cost_per_MWh,
        total_generation_cost_per_MWh=total_generation_cost_per_MWh,
        marginal_generation_cost_per_MWh=marginal_generation_cost_per_MWh,
        gross_revenue=gross_revenue_per_hour,
        total_cost=total_cost_per_hour,
        carbon_cost_total=carbon_cost_per_hour,
        operating_margin=operating_margin_per_hour,
        dispatch_recommended=dispatch_recommended,
    )


@dataclass
class SimulationEconomics:
    total_fuel_cost: float
    total_carbon_cost: float
    total_maintenance_cost: float
    total_auxiliary_cost: float
    total_startup_cost: float
    total_cost: float
    gross_revenue: float
    operating_margin: float
    cost_per_MWh: float
    marginal_cost_per_MWh: float


def evaluate_simulation(
    result,  # simulation.simulation.SimulationResult (avoid import cycle)
    economics: EconomicConfig,
    composition: LNGComposition,
    n_starts: int = 1,
) -> SimulationEconomics:
    """Aggregate economics across a full simulation run."""
    price_per_MWh_th = lng_price_per_MWh_th(economics, composition)
    df = result.dataframe

    fuel_energy_MWh_th = props.mj_to_mwh(result.total_lng_consumed_kg * composition.lhv_MJ_per_kg)
    total_fuel_cost = fuel_energy_MWh_th * price_per_MWh_th
    total_carbon_cost = props.kg_to_tonnes(result.total_co2_kg) * economics.carbon_price_per_tonne_CO2
    total_maintenance_cost = result.total_net_MWh * economics.maintenance_cost_per_MWh
    total_aux_MWh = float((df["auxiliary_load_MW"] * (df["time_hours"].diff().fillna(df["time_hours"].iloc[0] if len(df) else 0))).sum()) if len(df) else 0.0
    total_auxiliary_cost = total_aux_MWh * economics.auxiliary_electricity_price_per_MWh
    total_startup_cost = n_starts * economics.startup_cost

    total_cost = total_fuel_cost + total_carbon_cost + total_maintenance_cost + total_auxiliary_cost + total_startup_cost
    gross_revenue = result.total_net_MWh * economics.electricity_price_per_MWh
    operating_margin = gross_revenue - total_cost
    cost_per_MWh = total_cost / result.total_net_MWh if result.total_net_MWh > 0 else float("inf")

    marginal_eff = result.average_electrical_efficiency if result.average_electrical_efficiency > 0 else None
    marginal_cost_per_MWh = (
        (price_per_MWh_th / marginal_eff) + (total_carbon_cost / result.total_net_MWh if result.total_net_MWh > 0 else 0.0) + economics.maintenance_cost_per_MWh
        if marginal_eff else float("inf")
    )

    return SimulationEconomics(
        total_fuel_cost=total_fuel_cost,
        total_carbon_cost=total_carbon_cost,
        total_maintenance_cost=total_maintenance_cost,
        total_auxiliary_cost=total_auxiliary_cost,
        total_startup_cost=total_startup_cost,
        total_cost=total_cost,
        gross_revenue=gross_revenue,
        operating_margin=operating_margin,
        cost_per_MWh=cost_per_MWh,
        marginal_cost_per_MWh=marginal_cost_per_MWh,
    )
