"""
simulation/simulation.py
==========================

Runs a full time-stepped simulation: demand profile -> ramp-feasible
dispatch trajectory -> per-timestep physics -> cumulative state (MWh, LNG
consumed/remaining, emissions) as a tidy pandas DataFrame plus summary
totals.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

import numpy as np
import pandas as pd

from config import AmbientConditions, SimulationConfig
from models.lng import LNGInventory
from models.plant import LNGPlant
from optimisation.dispatch import build_dispatch_trajectory
from simulation.timestep import run_timestep


@dataclass
class SimulationResult:
    dataframe: pd.DataFrame
    total_net_MWh: float
    total_gross_MWh: float
    total_lng_consumed_kg: float
    lng_remaining_kg: float
    total_co2_kg: float
    total_waste_heat_MWh: float
    total_recoverable_heat_MWh: float
    average_electrical_efficiency: float  # energy-weighted
    average_heat_rate_MMBtu_per_MWh: float
    ran_out_of_fuel: bool
    plant: LNGPlant


def run_simulation(
    plant: LNGPlant,
    lng_inventory: LNGInventory,
    demand_MW: Sequence[float] | float,
    sim_config: SimulationConfig,
    ambient: AmbientConditions,
) -> SimulationResult:
    """Run a full dynamic simulation over ``sim_config.time_horizon_hours``.

    ``demand_MW`` may be a single number (held constant) or a sequence with
    one value per timestep (length must equal ``sim_config.n_steps``).
    """
    n_steps = sim_config.n_steps
    if np.isscalar(demand_MW):
        demand_series = np.full(n_steps, float(demand_MW))
    else:
        demand_series = np.asarray(demand_MW, dtype=float)
        assert len(demand_series) == n_steps, (
            f"demand_MW series length ({len(demand_series)}) must equal n_steps ({n_steps})"
        )

    trajectory = build_dispatch_trajectory(
        plant, ambient, demand_series, sim_config.timestep_seconds
    )

    rows = []
    ran_out_of_fuel = False
    for step in trajectory:
        result = run_timestep(plant, step.target_MW, ambient, lng_inventory, sim_config.timestep_seconds)
        if result.fuel_limited and result.lng_remaining_kg <= 1e-6:
            ran_out_of_fuel = True
        op = result.operating_point
        rows.append(
            {
                "time_hours": step.time_hours,
                "unit_state": step.state.value,
                "demand_MW": step.demand_MW,
                "target_MW": step.target_MW,
                "net_MW": op.net_electrical_MW,
                "gross_MW": op.gross_electrical_MW,
                "load_fraction": op.load_fraction,
                "electrical_efficiency": op.electrical_efficiency,
                "heat_rate_MMBtu_per_MWh": op.heat_rate_MMBtu_per_MWh,
                "lng_kg_per_MWh": op.lng_kg_per_MWh,
                "fuel_flow_kg_per_hr": op.fuel_flow_kg_per_hr,
                "lng_consumed_kg": result.lng_consumed_kg,
                "lng_remaining_kg": result.lng_remaining_kg,
                "net_MWh": result.net_MWh,
                "gross_MWh": op.gross_electrical_MW * sim_config.timestep_seconds / 3600.0,
                "waste_heat_MW": op.waste_heat_MW,
                "recoverable_heat_MW": op.recoverable_heat_MW,
                "auxiliary_load_MW": op.auxiliary_load_MW,
                "exhaust_temperature_C": op.turbine_exhaust_temperature_C,
                "co2_kg": result.co2_kg,
                "fuel_limited": result.fuel_limited,
                "energy_balance_residual_MW": op.energy_balance_residual_MW,
            }
        )

    df = pd.DataFrame(rows)
    df["cumulative_net_MWh"] = df["net_MWh"].cumsum()
    df["cumulative_lng_consumed_kg"] = df["lng_consumed_kg"].cumsum()
    df["cumulative_co2_kg"] = df["co2_kg"].cumsum()

    total_net_MWh = float(df["net_MWh"].sum())
    total_gross_MWh = float(df["gross_MWh"].sum())
    total_lng_consumed_kg = float(df["lng_consumed_kg"].sum())
    total_co2_kg = float(df["co2_kg"].sum())
    hours_per_step = sim_config.timestep_seconds / 3600.0
    total_waste_heat_MWh = float((df["waste_heat_MW"] * hours_per_step).sum())
    total_recoverable_heat_MWh = float((df["recoverable_heat_MW"] * hours_per_step).sum())

    if total_lng_consumed_kg > 0:
        total_fuel_energy_MWh = sum(
            row.fuel_flow_kg_per_hr * hours_per_step * plant.composition.lhv_MJ_per_kg / 3600.0
            for row in df.itertuples()
        )
        average_electrical_efficiency = total_net_MWh / total_fuel_energy_MWh if total_fuel_energy_MWh > 0 else 0.0
    else:
        average_electrical_efficiency = 0.0

    from thermodynamics.efficiency import heat_rate_MMBtu_per_MWh
    average_heat_rate = (
        heat_rate_MMBtu_per_MWh(average_electrical_efficiency) if average_electrical_efficiency > 0 else float("inf")
    )

    return SimulationResult(
        dataframe=df,
        total_net_MWh=total_net_MWh,
        total_gross_MWh=total_gross_MWh,
        total_lng_consumed_kg=total_lng_consumed_kg,
        lng_remaining_kg=lng_inventory.mass_kg,
        total_co2_kg=total_co2_kg,
        total_waste_heat_MWh=total_waste_heat_MWh,
        total_recoverable_heat_MWh=total_recoverable_heat_MWh,
        average_electrical_efficiency=average_electrical_efficiency,
        average_heat_rate_MMBtu_per_MWh=average_heat_rate,
        ran_out_of_fuel=ran_out_of_fuel,
        plant=plant,
    )
