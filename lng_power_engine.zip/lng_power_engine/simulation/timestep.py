"""
simulation/timestep.py
========================

Single-timestep physics resolution: given a (ramp-feasible) target net MW
for this step, the plant model, ambient conditions and the remaining LNG
inventory, compute the actual achievable output (further clipped if LNG
runs out mid-step), fuel drawn, efficiency, heat flows and emissions, and
mutate the inventory.
"""

from __future__ import annotations

from dataclasses import dataclass

from config import AmbientConditions
from models.lng import LNGInventory
from models.plant import LNGPlant, PlantOperatingPoint
from thermodynamics import properties as props


@dataclass
class TimestepResult:
    timestep_seconds: float
    operating_point: PlantOperatingPoint
    net_MWh: float
    lng_consumed_kg: float
    lng_remaining_kg: float
    co2_kg: float
    fuel_limited: bool  # True if LNG inventory ran out during this step


def run_timestep(
    plant: LNGPlant,
    target_net_MW: float,
    ambient: AmbientConditions,
    lng_inventory: LNGInventory,
    timestep_seconds: float,
) -> TimestepResult:
    """Resolve and apply one simulation timestep.

    Mutates ``lng_inventory`` in place (consumes fuel). If the requested
    output would require more fuel than remains in inventory, output is
    scaled down proportionally to what the remaining LNG can sustain for
    this step (a simple but physically sound fuel-exhaustion model).
    """
    assert timestep_seconds > 0

    point = plant.operating_point(target_net_MW, ambient)
    hours = timestep_seconds / props.SECONDS_PER_HOUR
    lng_needed_kg = point.fuel_flow_kg_per_hr * hours

    fuel_limited = False
    available_kg = lng_inventory.mass_kg

    if lng_needed_kg <= available_kg + 1e-9:
        net_MWh = point.net_electrical_MW * hours
        co2_kg = point.co2_kg_per_hr * hours
    else:
        fuel_limited = True
        if available_kg <= 1e-9 or point.fuel_flow_kg_per_hr <= 1e-12:
            point = plant._zero_point(ambient)
            lng_needed_kg = 0.0
            net_MWh = 0.0
            co2_kg = 0.0
        else:
            scale = available_kg / lng_needed_kg
            scaled_net_MW = target_net_MW * scale
            min_stable_net_MW = plant.net_minimum_stable_MW(ambient)
            if scaled_net_MW >= min_stable_net_MW:
                # Remaining fuel can sustain a (lower) steady output for
                # the whole step.
                point = plant.operating_point(scaled_net_MW, ambient)
                lng_needed_kg = min(point.fuel_flow_kg_per_hr * hours, available_kg)
                net_MWh = point.net_electrical_MW * hours
                co2_kg = point.co2_kg_per_hr * hours
            else:
                # Not enough fuel to sustain even minimum stable load for
                # the full step: run at minimum stable load for the
                # fraction of the step the remaining fuel allows, then
                # the unit trips off for the remainder (fuel exhaustion).
                min_point = plant.operating_point(min_stable_net_MW, ambient)
                fuel_flow = min_point.fuel_flow_kg_per_hr
                active_hours = min(available_kg / fuel_flow, hours) if fuel_flow > 0 else 0.0
                lng_needed_kg = min(active_hours * fuel_flow, available_kg)
                net_MWh = min_point.net_electrical_MW * active_hours
                co2_kg = min_point.co2_kg_per_hr * active_hours
                point = min_point

    lng_inventory.consume(lng_needed_kg)

    return TimestepResult(
        timestep_seconds=timestep_seconds,
        operating_point=point,
        net_MWh=net_MWh,
        lng_consumed_kg=lng_needed_kg,
        lng_remaining_kg=lng_inventory.mass_kg,
        co2_kg=co2_kg,
        fuel_limited=fuel_limited,
    )
