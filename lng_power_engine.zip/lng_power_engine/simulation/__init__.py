"""Time-stepped simulation of plant operation, fuel draw-down and cumulative reporting."""
