#!/usr/bin/env python3
"""
main.py
========

Command-line interface for the LNG Generator Optimisation Engine.

Usage
-----
    python main.py simulate  --capacity 500 --lng-tonnes 100 --demand 400 --hours 24
    python main.py optimise  --capacity 500 --lng-tonnes 100 --demand 400 --hours 24 --mode balanced
    python main.py benchmark --capacity 500 --lng-tonnes 100 --demand 400 --hours 24
    python main.py scenario  --scenarios-file examples/scenarios.json

Run ``python main.py <command> --help`` for the full argument list of each
subcommand.
"""

from __future__ import annotations

import argparse
import json
import os
import sys

from config import (
    AmbientConditions,
    CycleMode,
    EconomicConfig,
    OptimisationMode,
    SimulationConfig,
)
from models.lng import LNGInventory
from models.plant import build_plant
from optimisation.benchmark import format_benchmark_report, run_benchmark
from optimisation.optimiser import optimise_plant
from optimisation.scenario import Scenario, run_scenarios
from reporting.reports import format_report
from simulation.simulation import run_simulation
from thermodynamics import properties as props


def _common_plant_args(p: argparse.ArgumentParser) -> None:
    p.add_argument("--capacity", type=float, default=500.0, help="Rated gross capacity, MW")
    p.add_argument("--min-stable-load", type=float, default=0.35, help="Minimum stable load, fraction of capacity")
    p.add_argument("--generator-efficiency", type=float, default=0.98)
    p.add_argument("--cycle", choices=["simple", "combined"], default="combined")
    p.add_argument("--aux-load-fraction", type=float, default=0.03)
    p.add_argument("--ramp-up", type=float, default=None, help="MW/min ramp-up rate (default: 8%% of capacity/min)")
    p.add_argument("--ramp-down", type=float, default=None, help="MW/min ramp-down rate (default: 10%% of capacity/min)")
    p.add_argument("--startup-min", type=float, default=12.0)
    p.add_argument("--shutdown-min", type=float, default=6.0)


def _common_ambient_args(p: argparse.ArgumentParser) -> None:
    p.add_argument("--ambient-temp", type=float, default=15.0, help="Ambient temperature, degC")
    p.add_argument("--ambient-pressure", type=float, default=101.325, help="Ambient pressure, kPa")
    p.add_argument("--ambient-humidity", type=float, default=0.60, help="Relative humidity, 0-1")
    p.add_argument("--elevation", type=float, default=0.0, help="Site elevation, m")


def _common_economic_args(p: argparse.ArgumentParser) -> None:
    p.add_argument("--electricity-price", type=float, default=80.0, help="£/MWh sold")
    p.add_argument("--lng-price-per-tonne", type=float, default=450.0, help="£/tonne")
    p.add_argument("--carbon-price", type=float, default=80.0, help="£/tonne CO2")
    p.add_argument("--maintenance-cost", type=float, default=3.5, help="£/MWh")
    p.add_argument("--startup-cost", type=float, default=5000.0, help="£ per cold start")


def _build_plant(args: argparse.Namespace):
    return build_plant(
        rated_power_MW=args.capacity,
        minimum_stable_load=args.min_stable_load,
        generator_efficiency=args.generator_efficiency,
        ramp_up_MW_per_min=args.ramp_up,
        ramp_down_MW_per_min=args.ramp_down,
        startup_time_min=args.startup_min,
        shutdown_time_min=args.shutdown_min,
        cycle_mode=CycleMode.COMBINED_CYCLE if args.cycle == "combined" else CycleMode.SIMPLE_CYCLE,
        auxiliary_load_fraction=args.aux_load_fraction,
    )


def _build_ambient(args: argparse.Namespace) -> AmbientConditions:
    return AmbientConditions(
        temperature_C=args.ambient_temp,
        pressure_kPa=args.ambient_pressure,
        relative_humidity=args.ambient_humidity,
        elevation_m=args.elevation,
    )


def _build_economics(args: argparse.Namespace) -> EconomicConfig:
    return EconomicConfig(
        electricity_price_per_MWh=args.electricity_price,
        lng_price_per_tonne=args.lng_price_per_tonne,
        carbon_price_per_tonne_CO2=args.carbon_price,
        maintenance_cost_per_MWh=args.maintenance_cost,
        startup_cost=args.startup_cost,
    )


def cmd_simulate(args: argparse.Namespace) -> None:
    plant = _build_plant(args)
    ambient = _build_ambient(args)
    inventory = LNGInventory(composition=plant.composition, mass_kg=props.tonnes_to_kg(args.lng_tonnes))
    sim_config = SimulationConfig(timestep_seconds=args.timestep, time_horizon_hours=args.hours)
    result = run_simulation(plant, inventory, args.demand, sim_config, ambient)

    print(f"Simulated {args.hours} h at demand {args.demand} MW, timestep {args.timestep}s")
    print(f"  Net MWh generated      : {result.total_net_MWh:,.2f}")
    print(f"  LNG consumed           : {result.total_lng_consumed_kg:,.1f} kg")
    print(f"  LNG remaining          : {result.lng_remaining_kg:,.1f} kg")
    print(f"  Average efficiency     : {result.average_electrical_efficiency*100:,.2f} %")
    print(f"  Average heat rate      : {result.average_heat_rate_MMBtu_per_MWh:,.2f} MMBtu/MWh")
    print(f"  CO2 emitted            : {result.total_co2_kg:,.1f} kg")
    print(f"  Ran out of fuel        : {result.ran_out_of_fuel}")

    if args.output_csv:
        result.dataframe.to_csv(args.output_csv, index=False)
        print(f"  Timeseries written to  : {args.output_csv}")

    if args.plots_dir:
        from reporting import plots
        os.makedirs(args.plots_dir, exist_ok=True)
        plots.plot_output_vs_time(result, os.path.join(args.plots_dir, "output_vs_time.png"))
        plots.plot_lng_consumption_vs_time(result, os.path.join(args.plots_dir, "lng_consumption_vs_time.png"))
        plots.plot_cumulative_mwh(result, os.path.join(args.plots_dir, "cumulative_mwh.png"))
        plots.plot_lng_remaining(result, props.tonnes_to_kg(args.lng_tonnes), os.path.join(args.plots_dir, "lng_remaining.png"))
        plots.plot_dispatch_schedule(result, os.path.join(args.plots_dir, "dispatch_schedule.png"))
        print(f"  Plots written to       : {args.plots_dir}/")


def cmd_optimise(args: argparse.Namespace) -> None:
    plant = _build_plant(args)
    economics = _build_economics(args)
    lng_available_kg = props.tonnes_to_kg(args.lng_tonnes)

    result = optimise_plant(
        lng_available_kg=lng_available_kg,
        demand_MW=args.demand,
        time_horizon_hours=args.hours,
        plant=plant,
        ambient_temperature=args.ambient_temp,
        ambient_pressure=args.ambient_pressure,
        ambient_humidity=args.ambient_humidity,
        ambient_elevation_m=args.elevation,
        economics=economics,
        mode=OptimisationMode(args.mode),
        timestep_seconds=args.timestep,
    )
    print(format_report(result, plant, economics, lng_available_kg))

    if args.plots_dir:
        from reporting import plots
        ambient = _build_ambient(args)
        os.makedirs(args.plots_dir, exist_ok=True)
        plots.plot_efficiency_vs_load(plant, ambient, os.path.join(args.plots_dir, "efficiency_vs_load.png"))
        plots.plot_lng_consumption_vs_output(plant, ambient, os.path.join(args.plots_dir, "lng_vs_output.png"))
        plots.plot_heat_rate_curve(plant, ambient, os.path.join(args.plots_dir, "heat_rate.png"))
        plots.plot_cost_vs_load(plant, ambient, economics, os.path.join(args.plots_dir, "cost_vs_load.png"))
        plots.plot_co2_vs_load(plant, ambient, os.path.join(args.plots_dir, "co2_vs_load.png"))
        plots.plot_output_vs_time(result.simulation, os.path.join(args.plots_dir, "output_vs_time.png"))
        plots.plot_cumulative_mwh(result.simulation, os.path.join(args.plots_dir, "cumulative_mwh.png"))
        best_pt = plant.operating_point(result.optimal_output_MW, ambient)
        plots.plot_energy_flow_sankey(best_pt, os.path.join(args.plots_dir, "energy_flow_sankey.png"))
        print(f"\nPlots written to {args.plots_dir}/")


def cmd_benchmark(args: argparse.Namespace) -> None:
    plant = _build_plant(args)
    ambient = _build_ambient(args)
    economics = _build_economics(args)
    lng_available_kg = props.tonnes_to_kg(args.lng_tonnes)

    b = run_benchmark(
        plant=plant,
        lng_available_kg=lng_available_kg,
        demand_MW=args.demand,
        time_horizon_hours=args.hours,
        ambient=ambient,
        economics=economics,
        timestep_seconds=args.timestep,
        optimisation_mode=OptimisationMode(args.mode),
    )
    print(format_benchmark_report(b))


def cmd_scenario(args: argparse.Namespace) -> None:
    plant = _build_plant(args)
    economics = _build_economics(args)

    if args.scenarios_file:
        with open(args.scenarios_file) as f:
            raw = json.load(f)
        scenarios = [
            Scenario(
                name=s.get("name", f"scenario_{i}"),
                lng_tonnes=s["lng_tonnes"],
                demand_MW=s["demand_MW"],
                duration_hours=s["duration_hours"],
                ambient_temperature_C=s.get("ambient_temperature_C", 15.0),
                mode=OptimisationMode(s.get("mode", "balanced")),
            )
            for i, s in enumerate(raw)
        ]
    else:
        # A small illustrative default scenario set.
        scenarios = [
            Scenario(name="baseload_cool", lng_tonnes=args.lng_tonnes, demand_MW=args.demand,
                      duration_hours=args.hours, ambient_temperature_C=10.0),
            Scenario(name="baseload_hot", lng_tonnes=args.lng_tonnes, demand_MW=args.demand,
                      duration_hours=args.hours, ambient_temperature_C=35.0),
            Scenario(name="low_demand", lng_tonnes=args.lng_tonnes, demand_MW=args.demand * 0.5,
                      duration_hours=args.hours),
            Scenario(name="fuel_constrained", lng_tonnes=args.lng_tonnes * 0.3, demand_MW=args.demand,
                      duration_hours=args.hours),
        ]

    df = run_scenarios(scenarios, plant, economics, timestep_seconds=args.timestep)
    with pd_option_context():
        print(df.drop(columns=[c for c in df.columns if False]).to_string(index=False))

    if args.output_csv:
        df.to_csv(args.output_csv, index=False)
        print(f"\nScenario comparison written to {args.output_csv}")


class pd_option_context:
    def __enter__(self):
        import pandas as pd
        self._ctx = pd.option_context("display.max_columns", None, "display.width", 200)
        self._ctx.__enter__()
        return self

    def __exit__(self, *exc):
        self._ctx.__exit__(*exc)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="LNG Generator Optimisation Engine")
    sub = parser.add_subparsers(dest="command", required=True)

    p_sim = sub.add_parser("simulate", help="Run a time-stepped simulation at a fixed demand")
    _common_plant_args(p_sim)
    _common_ambient_args(p_sim)
    p_sim.add_argument("--lng-tonnes", type=float, default=100.0)
    p_sim.add_argument("--demand", type=float, default=400.0)
    p_sim.add_argument("--hours", type=float, default=24.0)
    p_sim.add_argument("--timestep", type=float, default=60.0, help="seconds")
    p_sim.add_argument("--output-csv", type=str, default=None)
    p_sim.add_argument("--plots-dir", type=str, default=None)
    p_sim.set_defaults(func=cmd_simulate)

    p_opt = sub.add_parser("optimise", help="Find the optimal dispatch strategy")
    _common_plant_args(p_opt)
    _common_ambient_args(p_opt)
    _common_economic_args(p_opt)
    p_opt.add_argument("--lng-tonnes", type=float, default=100.0)
    p_opt.add_argument("--demand", type=float, default=400.0)
    p_opt.add_argument("--hours", type=float, default=24.0)
    p_opt.add_argument("--timestep", type=float, default=60.0)
    p_opt.add_argument("--mode", choices=[m.value for m in OptimisationMode], default="balanced")
    p_opt.add_argument("--plots-dir", type=str, default=None)
    p_opt.set_defaults(func=cmd_optimise)

    p_bench = sub.add_parser("benchmark", help="Compare naive vs optimised dispatch")
    _common_plant_args(p_bench)
    _common_ambient_args(p_bench)
    _common_economic_args(p_bench)
    p_bench.add_argument("--lng-tonnes", type=float, default=100.0)
    p_bench.add_argument("--demand", type=float, default=400.0)
    p_bench.add_argument("--hours", type=float, default=24.0)
    p_bench.add_argument("--timestep", type=float, default=60.0)
    p_bench.add_argument("--mode", choices=[m.value for m in OptimisationMode], default="max_mwh")
    p_bench.set_defaults(func=cmd_benchmark)

    p_scn = sub.add_parser("scenario", help="Run and compare multiple scenarios")
    _common_plant_args(p_scn)
    _common_economic_args(p_scn)
    p_scn.add_argument("--lng-tonnes", type=float, default=100.0)
    p_scn.add_argument("--demand", type=float, default=400.0)
    p_scn.add_argument("--hours", type=float, default=24.0)
    p_scn.add_argument("--timestep", type=float, default=60.0)
    p_scn.add_argument("--scenarios-file", type=str, default=None, help="JSON file with a list of scenario dicts")
    p_scn.add_argument("--output-csv", type=str, default=None)
    p_scn.set_defaults(func=cmd_scenario)

    return parser


def main(argv=None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    args.func(args)
    return 0


if __name__ == "__main__":
    sys.exit(main())
