"""
config.py
=========

Central configuration types for the LNG Generator Optimisation Engine.

Design note
-----------
Values in this module fall into three buckets, and the whole codebase tries
to keep that distinction visible (see README section "Accuracy and
engineering discipline"):

1. First-principles constants  -- e.g. molar masses, J/mol relations. These
   are physical facts and are not user-configurable.
2. Engineering approximations  -- e.g. the shape of a gas-turbine part-load
   efficiency curve, exhaust cp. These are widely-used rules of thumb, not
   vendor-specific performance curves. They are *defaults* and can be
   overridden.
3. User-configurable assumptions -- prices, plant ratings, ambient design
   point, weights used in optimisation, etc. These are expected to be
   supplied by the user for their specific plant/site/market.

All dataclasses below are validated in ``__post_init__`` with explicit
sanity-check assertions (see also thermodynamics/efficiency.py and
models/plant.py for further conservation-of-energy checks).
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Optional


class CycleMode(str, Enum):
    """Plant thermodynamic cycle configuration."""

    SIMPLE_CYCLE = "simple_cycle"
    COMBINED_CYCLE = "combined_cycle"


class OptimisationMode(str, Enum):
    """Objective the dispatch optimiser should pursue."""

    MAX_MWH = "max_mwh"
    MAX_EFFICIENCY = "max_efficiency"
    MIN_FUEL = "min_fuel"
    MIN_COST = "min_cost"
    MAX_PROFIT = "max_profit"
    BALANCED = "balanced"


@dataclass
class AmbientConditions:
    """Site ambient conditions used to derate turbine performance.

    Engineering approximation: the derating model in
    ``thermodynamics.properties.ambient_derate_factor`` is a simplified,
    widely-cited rule of thumb (roughly -0.5% to -0.8% output per +1 degC
    above ISO conditions, proportional derate with ambient pressure, small
    humidity correction). It is NOT a replacement for a manufacturer's
    correction curve.
    """

    temperature_C: float = 15.0
    pressure_kPa: float = 101.325
    relative_humidity: float = 0.60
    elevation_m: float = 0.0

    def __post_init__(self) -> None:
        assert -60.0 <= self.temperature_C <= 60.0, "temperature_C out of plausible range"
        assert 50.0 <= self.pressure_kPa <= 110.0, "pressure_kPa out of plausible range"
        assert 0.0 <= self.relative_humidity <= 1.0, "relative_humidity must be in [0, 1]"
        assert -500.0 <= self.elevation_m <= 6000.0, "elevation_m out of plausible range"


@dataclass
class RampConfig:
    """Ramp / start-up / shut-down characteristics of the generating unit."""

    minimum_output_MW: float
    maximum_output_MW: float
    ramp_up_MW_per_min: float
    ramp_down_MW_per_min: float
    minimum_stable_load: float  # fraction of maximum_output_MW, e.g. 0.35
    startup_time_min: float = 10.0
    shutdown_time_min: float = 5.0

    def __post_init__(self) -> None:
        assert self.maximum_output_MW > 0, "maximum_output_MW must be > 0"
        assert 0.0 <= self.minimum_stable_load < 1.0, "minimum_stable_load must be in [0, 1)"
        assert self.minimum_output_MW >= 0.0
        assert self.ramp_up_MW_per_min >= 0.0
        assert self.ramp_down_MW_per_min >= 0.0
        assert self.startup_time_min >= 0.0
        assert self.shutdown_time_min >= 0.0
        min_stable_MW = self.minimum_stable_load * self.maximum_output_MW
        assert min_stable_MW <= self.maximum_output_MW


@dataclass
class EconomicConfig:
    """Economic assumptions. All prices are user-configurable."""

    electricity_price_per_MWh: float = 80.0          # £/MWh sold
    lng_price_per_tonne: Optional[float] = 450.0       # £/tonne, optional
    lng_price_per_MWh_th: Optional[float] = None       # £/MWh thermal, optional alt input
    carbon_price_per_tonne_CO2: float = 80.0          # £/tCO2
    maintenance_cost_per_MWh: float = 3.5             # £/MWh generated
    startup_cost: float = 5000.0                       # £ per cold start
    auxiliary_electricity_price_per_MWh: float = 80.0  # £/MWh (cost of parasitic load)

    def __post_init__(self) -> None:
        assert self.electricity_price_per_MWh >= 0
        assert self.carbon_price_per_tonne_CO2 >= 0
        assert self.maintenance_cost_per_MWh >= 0
        assert self.startup_cost >= 0
        assert self.auxiliary_electricity_price_per_MWh >= 0
        assert (self.lng_price_per_tonne is not None) or (self.lng_price_per_MWh_th is not None), (
            "Provide at least one of lng_price_per_tonne or lng_price_per_MWh_th"
        )


@dataclass
class OptimisationWeights:
    """Weights used by OptimisationMode.BALANCED. Purely user-configurable."""

    mwh: float = 1.0
    efficiency: float = 1.0
    fuel_consumption: float = 1.0
    operating_cost: float = 1.0
    emissions: float = 1.0

    def normalised(self) -> "OptimisationWeights":
        total = self.mwh + self.efficiency + self.fuel_consumption + self.operating_cost + self.emissions
        if total <= 0:
            raise ValueError("At least one BALANCED weight must be > 0")
        return OptimisationWeights(
            mwh=self.mwh / total,
            efficiency=self.efficiency / total,
            fuel_consumption=self.fuel_consumption / total,
            operating_cost=self.operating_cost / total,
            emissions=self.emissions / total,
        )


@dataclass
class SimulationConfig:
    """Timestep simulation configuration."""

    timestep_seconds: float = 60.0  # default: 1 minute
    time_horizon_hours: float = 24.0

    VALID_TIMESTEPS_S = (1, 10, 60, 300, 900, 3600)

    def __post_init__(self) -> None:
        assert self.timestep_seconds > 0
        assert self.time_horizon_hours > 0

    @property
    def n_steps(self) -> int:
        return max(1, int(round(self.time_horizon_hours * 3600.0 / self.timestep_seconds)))
