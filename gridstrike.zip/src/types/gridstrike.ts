/**
 * GridStrike Core Type Definitions
 * Electricity Strike-Price Analytics & Optimisation Platform
 */

export type MarketRegion = 'GB_N2EX' | 'DE_EEX' | 'NORD_POOL' | 'US_PJM' | 'US_ERCOT';

export interface MarketInfo {
  id: MarketRegion;
  name: string;
  country: string;
  currency: 'GBP' | 'EUR' | 'USD';
  unit: '£/MWh' | '€/MWh' | '$/MWh';
  currentSpot: number;
  dayAheadAvg: number;
  impliedVol: number; // e.g. 0.34 for 34%
  carbonPrice: number; // e.g. €75/tCO2
  gasPrice: number; // e.g. p/therm or €/MWh
}

export interface PricePoint {
  timestamp: string;
  market: MarketRegion;
  nodeRegion: string;
  price: number;
  currency: string;
  unit: string;
  source: string;
  quality: 'HIGH' | 'MEDIUM' | 'ESTIMATED';
}

export interface ForwardCurvePoint {
  period: string; // e.g. '2026-Q4', '2027-01', '2027-02-15T00:00:00'
  date: string;
  tenor: 'HOURLY' | 'DAILY' | 'MONTHLY' | 'QUARTERLY' | 'ANNUAL';
  basePrice: number;
  peakPrice: number;
  offPeakPrice: number;
  scenarioPrice?: number;
}

export interface DerivationStep {
  label: string;
  formula: string;
  value: number;
  unit: string;
  explanation: string;
}

export interface StrikeDerivationResult {
  expectedMarketPrice: number;
  breakEvenStrike: number;
  fairValueStrike: number;
  riskAdjustedStrike: number;
  minViableStrike: number;
  maxAcceptableStrike: number;
  targetCommercialStrike: number;
  derivationSteps: DerivationStep[];
  timestamp: string;
}

export interface PpaInputs {
  assetType: 'SOLAR' | 'WIND_ONSHORE' | 'WIND_OFFSHORE';
  capacityMw: number;
  capexTotal: number; // in Millions
  opexPerMwh: number;
  degradationAnnualPct: number;
  contractDurationYears: number;
  targetIrrPct: number;
  debtRatioPct: number;
  interestRatePct: number;
  curtailmentPct: number;
  imbalanceCostPerMwh: number;
  captureFactor: number; // ratio vs market, e.g. 0.91
  expectedCapacityFactorPct: number;
}

export interface PpaResult {
  minPpaStrike: number;
  targetPpaStrike: number;
  riskAdjustedPpaStrike: number;
  capturePrice: number;
  expectedAnnualGenerationMwh: number;
  lcoePerMwh: number;
  irrAtTargetStrike: number;
  npvAtTargetStrike: number;
  dscrMin: number;
  breakdown: DerivationStep[];
}

export interface BatteryInputs {
  powerMw: number;
  capacityMwh: number;
  roundTripEfficiencyPct: number; // e.g. 85%
  degradationPerCyclePct: number;
  cyclingCostPerMwh: number;
  marketFeesPerMwh: number;
  expectedChargePrice: number;
  maxCyclesPerDay: number;
}

export interface BatteryResult {
  chargePrice: number;
  requiredSpread: number;
  minDischargePrice: number;
  maxAcceptableChargePrice: number;
  dailyRevenuePerMw: number;
  annualNetProfit: number;
  breakdown: DerivationStep[];
}

export interface ThermalInputs {
  plantType: 'CCGT' | 'PEAKER_OCGT' | 'COAL' | 'BIOMASS';
  heatRateGjPerMwh: number;
  efficiencyPct: number;
  fuelPriceGj: number;
  carbonIntensityTonPerMwh: number;
  carbonPriceTon: number;
  variableOpexPerMwh: number;
  startupCostPerMw: number;
  fixedOpexPerKwYear: number;
}

export interface ThermalResult {
  srmcPerMwh: number;
  lrmcPerMwh: number;
  minEconomicStrike: number;
  fuelCostComponent: number;
  carbonCostComponent: number;
  vomComponent: number;
  cleanSparkSpread: number;
  breakdown: DerivationStep[];
}

export interface OptionInputs {
  optionType: 'CALL' | 'PUT' | 'CAP' | 'FLOOR' | 'COLLAR' | 'SWAPTION';
  underlyingPrice: number;
  strikePrice: number;
  tenorMonths: number;
  riskFreeRatePct: number;
  historicalVolPct: number;
  impliedVolPct: number;
  jumpFrequencyPerYear: number;
  jumpMeanPct: number;
  jumpVolPct: number;
  meanReversionSpeed: number;
  capFloorLevel?: number;
}

export interface OptionResult {
  optionValue: number;
  delta: number;
  gamma: number;
  vega: number;
  theta: number;
  rho: number;
  blackScholesBenchmark: number;
  jumpDiffusionAdjustment: number;
  payoffStructure: { spot: number; payoff: number }[];
}

export interface MonteCarloInputs {
  numPaths: number;
  tenorDays: number;
  basePrice: number;
  meanReversionSpeed: number;
  longTermMeanPrice: number;
  volatilityPct: number;
  spikeFrequency: number;
  spikeIntensity: number;
  weatherVolatilityBonusPct: number;
  strikePriceToTest: number;
}

export interface MonteCarloResult {
  paths: number[][]; // sample 10 paths for visual
  percentiles: {
    day: number;
    p1: number;
    p5: number;
    p10: number;
    p50: number;
    p90: number;
    p95: number;
    p99: number;
    mean: number;
  }[];
  npvDistribution: number[];
  p1Npv: number;
  p5Npv: number;
  p10Npv: number;
  p50Npv: number;
  p90Npv: number;
  p95Npv: number;
  p99Npv: number;
  expectedProfitLoss: number;
  lossProbabilityPct: number;
}

export interface OptimiserInputs {
  assetCostPerMwh: number;
  expectedMarketPrice: number;
  volatilityPct: number;
  targetIrrPct: number;
  targetNpvMillion: number;
  maxDownsidePct: number;
  maxLossProbabilityPct: number;
  targetDscr: number;
  objective: 'MINIMISE_STRIKE' | 'MAXIMISE_NPV' | 'MAXIMISE_IRR' | 'MAXIMISE_BANKABILITY' | 'MAXIMISE_RISK_ADJUSTED_RETURN';
}

export interface OptimiserResult {
  optimalStrike: number;
  achievedIrrPct: number;
  achievedNpvMillion: number;
  achievedDownsideRiskPct: number;
  achievedLossProbPct: number;
  achievedDscr: number;
  tradeOffFrontier: {
    strike: number;
    npv: number;
    irr: number;
    lossProb: number;
    dscr: number;
    feasible: boolean;
  }[];
}

export interface RiskMetrics {
  var95: number;
  var99: number;
  cvar95: number;
  cvar99: number;
  expectedShortfall: number;
  basisRiskExposure: number;
  capturePriceRisk: number;
  volumeRiskPct: number;
  weatherRiskSensitivity: number;
}

export interface StressScenario {
  id: string;
  name: string;
  description: string;
  spotPriceDeltaPct: number;
  gasPriceDeltaPct: number;
  carbonPriceDeltaPct: number;
  windGenerationDeltaPct: number;
  solarGenerationDeltaPct: number;
  curtailmentPct: number;
  negativePriceFrequencyPct: number;
  resultingFairStrike: number;
  resultingNpvChangePct: number;
}

export interface ContractDetails {
  id: string;
  name: string;
  type: 'PPA' | 'CfD' | 'POWER_OPTION' | 'SWAP' | 'BATTERY_TOLLING' | 'CAPACITY_AGREEMENT';
  assetName: string;
  counterparty: string;
  capacityMw: number;
  volumeMwhAnnual: number;
  strikePrice: number;
  durationYears: number;
  settlementInterval: '15MIN' | '30MIN' | 'HOURLY';
  priceIndex: string;
  floorPrice?: number;
  capPrice?: number;
  collateralRequired: number;
  escalationPctAnnual: number;
  status: 'ACTIVE' | 'DRAFT' | 'OPTIMISING' | 'EXPIRED';
}

export interface AuditRecord {
  id: string;
  timestamp: string;
  market: MarketRegion;
  event: string;
  oldPrice: number;
  newPrice: number;
  oldStrike: number;
  newStrike: number;
  userSystem: string;
}

export interface CashFlowYear {
  year: number;
  generationMwh: number;
  marketRevenue: number;
  strikeSettlement: number;
  totalRevenue: number;
  opex: number;
  ebitda: number;
  debtService: number;
  freeCashFlow: number;
  dscr: number;
  cumNpv: number;
}
