/**
 * GridStrike Main Application View
 */

import React, { useState, useEffect } from 'react';
import { MarketRegion, MarketInfo, AuditRecord } from './types/gridstrike';
import { INITIAL_MARKETS, INITIAL_AUDIT_TRAIL } from './lib/mockData';
import { calculateStrikeDerivation } from './lib/strikeEngine';

import { Header } from './components/Header';
import { StrikeWorkbench } from './components/StrikeWorkbench';
import { ForwardCurveViewer } from './components/ForwardCurveViewer';
import { PpaCalculator } from './components/PpaCalculator';
import { BatteryCalculator } from './components/BatteryCalculator';
import { ThermalGenerator } from './components/ThermalGenerator';
import { OptionPricer } from './components/OptionPricer';
import { MonteCarloSimulator } from './components/MonteCarloSimulator';
import { StrikeOptimiser } from './components/StrikeOptimiser';
import { RiskStressLab } from './components/RiskStressLab';
import { RealtimeTicker } from './components/RealtimeTicker';
import { ContractCashflow } from './components/ContractCashflow';
import { CodeExplorer } from './components/CodeExplorer';
import { OpenApiModal } from './components/OpenApiModal';

export default function App() {
  const [activeMarket, setActiveMarket] = useState<MarketRegion>('GB_N2EX');
  const [activeTab, setActiveTab] = useState<string>('workbench');
  const [markets, setMarkets] = useState<Record<string, MarketInfo>>(INITIAL_MARKETS);
  const [auditTrail, setAuditTrail] = useState<AuditRecord[]>(INITIAL_AUDIT_TRAIL);
  const [isRealtimeActive, setIsRealtimeActive] = useState<boolean>(true);
  const [isOpenApiOpen, setIsOpenApiOpen] = useState<boolean>(false);

  // Real-time market tick simulator interval
  useEffect(() => {
    if (!isRealtimeActive) return;

    const interval = setInterval(() => {
      setMarkets((prev) => {
        const currentMkt = prev[activeMarket];
        if (!currentMkt) return prev;

        // Random price fluctuation between -0.8% and +1.2%
        const deltaPct = (Math.random() * 0.02 - 0.008);
        const newSpot = Math.max(10, currentMkt.currentSpot * (1 + deltaPct));

        const oldDerivation = calculateStrikeDerivation(currentMkt.currentSpot, currentMkt.impliedVol, 21.0, 0.91);
        const newDerivation = calculateStrikeDerivation(newSpot, currentMkt.impliedVol, 21.0, 0.91);

        const newAudit: AuditRecord = {
          id: `AUD-${Date.now().toString().slice(-4)}`,
          timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
          market: activeMarket,
          event: `Live Price Tick (${deltaPct >= 0 ? '+' : ''}${(deltaPct * 100).toFixed(2)}%)`,
          oldPrice: Math.round(currentMkt.currentSpot * 100) / 100,
          newPrice: Math.round(newSpot * 100) / 100,
          oldStrike: oldDerivation.fairValueStrike,
          newStrike: newDerivation.fairValueStrike,
          userSystem: 'REALTIME_RUST_SIMULATOR'
        };

        setAuditTrail((prevTrail) => [newAudit, ...prevTrail.slice(0, 15)]);

        return {
          ...prev,
          [activeMarket]: {
            ...currentMkt,
            currentSpot: Math.round(newSpot * 100) / 100
          }
        };
      });
    }, 5000);

    return () => clearInterval(interval);
  }, [isRealtimeActive, activeMarket]);

  const currentMarket = markets[activeMarket] || markets['GB_N2EX'];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-slate-950">
      {/* Header */}
      <Header
        activeMarket={activeMarket}
        markets={markets}
        onSelectMarket={setActiveMarket}
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        isRealtimeActive={isRealtimeActive}
        onToggleRealtime={() => setIsRealtimeActive(!isRealtimeActive)}
        onOpenApiDocs={() => setIsOpenApiOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'workbench' && <StrikeWorkbench market={currentMarket} />}
        {activeTab === 'forward-curve' && <ForwardCurveViewer market={currentMarket} />}
        {activeTab === 'ppa' && <PpaCalculator market={currentMarket} />}
        {activeTab === 'battery' && <BatteryCalculator market={currentMarket} />}
        {activeTab === 'thermal' && <ThermalGenerator market={currentMarket} />}
        {activeTab === 'option' && <OptionPricer market={currentMarket} />}
        {activeTab === 'monte-carlo' && <MonteCarloSimulator market={currentMarket} />}
        {activeTab === 'optimiser' && <StrikeOptimiser market={currentMarket} />}
        {activeTab === 'risk-stress' && <RiskStressLab market={currentMarket} />}
        {activeTab === 'contracts' && <ContractCashflow market={currentMarket} />}
        {activeTab === 'code-repo' && <CodeExplorer />}
      </main>

      {/* Realtime Live Ticker Bar */}
      <RealtimeTicker
        markets={markets}
        auditTrail={auditTrail}
        isRealtimeActive={isRealtimeActive}
      />

      {/* OpenAPI Modal */}
      <OpenApiModal isOpen={isOpenApiOpen} onClose={() => setIsOpenApiOpen(false)} />
    </div>
  );
}
