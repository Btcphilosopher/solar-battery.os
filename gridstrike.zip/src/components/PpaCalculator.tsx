/**
 * GridStrike Renewable PPA Strike & Capture Price Calculator
 */

import React, { useState } from 'react';
import { MarketInfo, PpaInputs, PpaResult } from '../types/gridstrike';
import { calculatePpaStrike } from '../lib/strikeEngine';
import { Sun, Wind, Layers, Calculator, ShieldAlert } from 'lucide-react';

interface PpaCalculatorProps {
  market: MarketInfo;
}

export const PpaCalculator: React.FC<PpaCalculatorProps> = ({ market }) => {
  const [inputs, setInputs] = useState<PpaInputs>({
    assetType: 'WIND_OFFSHORE',
    capacityMw: 120,
    capexTotal: 180, // Millions
    opexPerMwh: 18.5,
    degradationAnnualPct: 0.5,
    contractDurationYears: 15,
    targetIrrPct: 8.5,
    debtRatioPct: 70,
    interestRatePct: 5.5,
    curtailmentPct: 2.5,
    imbalanceCostPerMwh: 3.2,
    captureFactor: 0.91,
    expectedCapacityFactorPct: 45.0
  });

  const ppaResult: PpaResult = calculatePpaStrike(inputs, market.currentSpot);
  const curr = market.currency === 'GBP' ? '£' : market.currency === 'EUR' ? '€' : '$';

  const setPreset = (type: 'SOLAR' | 'WIND_ONSHORE' | 'WIND_OFFSHORE') => {
    if (type === 'SOLAR') {
      setInputs({
        assetType: 'SOLAR',
        capacityMw: 80,
        capexTotal: 55,
        opexPerMwh: 12.0,
        degradationAnnualPct: 0.5,
        contractDurationYears: 15,
        targetIrrPct: 8.0,
        debtRatioPct: 75,
        interestRatePct: 5.2,
        curtailmentPct: 4.0,
        imbalanceCostPerMwh: 2.8,
        captureFactor: 0.78, // Solar cannibalisation discount
        expectedCapacityFactorPct: 18.0
      });
    } else if (type === 'WIND_ONSHORE') {
      setInputs({
        assetType: 'WIND_ONSHORE',
        capacityMw: 60,
        capexTotal: 75,
        opexPerMwh: 16.0,
        degradationAnnualPct: 0.4,
        contractDurationYears: 15,
        targetIrrPct: 8.2,
        debtRatioPct: 70,
        interestRatePct: 5.5,
        curtailmentPct: 2.0,
        imbalanceCostPerMwh: 3.0,
        captureFactor: 0.88,
        expectedCapacityFactorPct: 34.0
      });
    } else {
      setInputs({
        assetType: 'WIND_OFFSHORE',
        capacityMw: 120,
        capexTotal: 180,
        opexPerMwh: 18.5,
        degradationAnnualPct: 0.5,
        contractDurationYears: 15,
        targetIrrPct: 8.5,
        debtRatioPct: 70,
        interestRatePct: 5.5,
        curtailmentPct: 2.5,
        imbalanceCostPerMwh: 3.2,
        captureFactor: 0.91,
        expectedCapacityFactorPct: 45.0
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Asset Presets */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <Layers className="w-5 h-5 text-amber-400" />
            <h2 className="text-xl font-bold text-white">Renewable PPA Strike & Capture Price Engine</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-xl">
            Solves for minimum, target, and risk-adjusted PPA strike prices while taking into account renewable capture cannibalisation and curtailment.
          </p>
        </div>

        {/* Preset Selector */}
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setPreset('SOLAR')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1 transition ${
              inputs.assetType === 'SOLAR'
                ? 'bg-amber-500 text-slate-950 font-bold'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <Sun className="w-3.5 h-3.5" />
            <span>Solar PV</span>
          </button>
          <button
            onClick={() => setPreset('WIND_ONSHORE')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1 transition ${
              inputs.assetType === 'WIND_ONSHORE'
                ? 'bg-amber-500 text-slate-950 font-bold'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <Wind className="w-3.5 h-3.5" />
            <span>Wind Onshore</span>
          </button>
          <button
            onClick={() => setPreset('WIND_OFFSHORE')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1 transition ${
              inputs.assetType === 'WIND_OFFSHORE'
                ? 'bg-amber-500 text-slate-950 font-bold'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <Wind className="w-3.5 h-3.5 text-sky-400" />
            <span>Wind Offshore</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Input Parameters Form */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <h3 className="text-sm font-bold text-white border-b border-slate-800 pb-2">PPA Project Parameters</h3>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] text-slate-400 block mb-1">Capacity (MW)</label>
              <input
                type="number"
                value={inputs.capacityMw}
                onChange={(e) => setInputs({ ...inputs, capacityMw: parseFloat(e.target.value) || 0 })}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-amber-400 font-mono focus:outline-none"
              />
            </div>

            <div>
              <label className="text-[11px] text-slate-400 block mb-1">Total CAPEX ({curr}M)</label>
              <input
                type="number"
                value={inputs.capexTotal}
                onChange={(e) => setInputs({ ...inputs, capexTotal: parseFloat(e.target.value) || 0 })}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-amber-400 font-mono focus:outline-none"
              />
            </div>

            <div>
              <label className="text-[11px] text-slate-400 block mb-1">Capacity Factor (%)</label>
              <input
                type="number"
                value={inputs.expectedCapacityFactorPct}
                onChange={(e) => setInputs({ ...inputs, expectedCapacityFactorPct: parseFloat(e.target.value) || 0 })}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-amber-400 font-mono focus:outline-none"
              />
            </div>

            <div>
              <label className="text-[11px] text-slate-400 block mb-1">Capture Factor Ratio</label>
              <input
                type="number"
                step="0.01"
                value={inputs.captureFactor}
                onChange={(e) => setInputs({ ...inputs, captureFactor: parseFloat(e.target.value) || 0 })}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-amber-400 font-mono focus:outline-none"
              />
            </div>

            <div>
              <label className="text-[11px] text-slate-400 block mb-1">OPEX ({curr}/MWh)</label>
              <input
                type="number"
                value={inputs.opexPerMwh}
                onChange={(e) => setInputs({ ...inputs, opexPerMwh: parseFloat(e.target.value) || 0 })}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-amber-400 font-mono focus:outline-none"
              />
            </div>

            <div>
              <label className="text-[11px] text-slate-400 block mb-1">Target Equity IRR (%)</label>
              <input
                type="number"
                value={inputs.targetIrrPct}
                onChange={(e) => setInputs({ ...inputs, targetIrrPct: parseFloat(e.target.value) || 0 })}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-amber-400 font-mono focus:outline-none"
              />
            </div>

            <div>
              <label className="text-[11px] text-slate-400 block mb-1">Curtailment Loss (%)</label>
              <input
                type="number"
                value={inputs.curtailmentPct}
                onChange={(e) => setInputs({ ...inputs, curtailmentPct: parseFloat(e.target.value) || 0 })}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-amber-400 font-mono focus:outline-none"
              />
            </div>

            <div>
              <label className="text-[11px] text-slate-400 block mb-1">Debt Financing Ratio (%)</label>
              <input
                type="number"
                value={inputs.debtRatioPct}
                onChange={(e) => setInputs({ ...inputs, debtRatioPct: parseFloat(e.target.value) || 0 })}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-amber-400 font-mono focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Output Valuation Cards */}
        <div className="lg:col-span-7 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl">
              <span className="text-[10px] font-mono text-slate-400 uppercase block">MINIMUM PPA STRIKE</span>
              <div className="text-2xl font-extrabold text-white font-mono mt-1">
                {curr}{ppaResult.minPpaStrike.toFixed(2)}
              </div>
              <p className="text-[11px] text-slate-400 mt-1">Covers LCOE ({curr}{ppaResult.lcoePerMwh}/MWh)</p>
            </div>

            <div className="bg-slate-900 border border-amber-500/40 rounded-2xl p-4 shadow-xl">
              <span className="text-[10px] font-mono text-amber-400 uppercase block">TARGET COMMERCIAL PPA STRIKE</span>
              <div className="text-2xl font-extrabold text-white font-mono mt-1">
                {curr}{ppaResult.targetPpaStrike.toFixed(2)}
              </div>
              <p className="text-[11px] text-amber-400/80 mt-1">Achieves {inputs.targetIrrPct}% Target Equity IRR</p>
            </div>

            <div className="bg-slate-900 border border-sky-500/40 rounded-2xl p-4 shadow-xl">
              <span className="text-[10px] font-mono text-sky-400 uppercase block">RISK-ADJUSTED STRIKE</span>
              <div className="text-2xl font-extrabold text-white font-mono mt-1">
                {curr}{ppaResult.riskAdjustedPpaStrike.toFixed(2)}
              </div>
              <p className="text-[11px] text-sky-400/80 mt-1">Includes volume & cannibalisation risk buffer</p>
            </div>
          </div>

          {/* Breakdown Steps */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
            <h4 className="text-sm font-bold text-white mb-3">PPA Mathematical Derivation</h4>
            <div className="space-y-2">
              {ppaResult.breakdown.map((step, i) => (
                <div key={i} className="bg-slate-950/60 p-3 rounded-xl border border-slate-800/80 flex justify-between items-center text-xs">
                  <div>
                    <span className="font-semibold text-slate-200 block">{step.label}</span>
                    <span className="text-slate-500 font-mono text-[10px]">{step.formula}</span>
                  </div>
                  <span className="font-mono font-bold text-emerald-400 text-sm">
                    {curr}{step.value.toFixed(2)} {step.unit.replace('£/MWh', '')}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
