/**
 * GridStrike Repository Source Code & Schema Explorer
 */

import React, { useState } from 'react';
import { RUST_CODE_FILES, R_CODE_FILES, SQL_SCHEMA_FILES } from '../lib/rustAndRCode';
import { Code, Terminal, Database, Copy, Check } from 'lucide-react';

export const CodeExplorer: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<'RUST' | 'R' | 'SQL'>('RUST');
  const [selectedFile, setSelectedFile] = useState<string>('rust/pricing/strike.rs');
  const [copied, setCopied] = useState<boolean>(false);

  const getFiles = () => {
    if (activeCategory === 'RUST') return RUST_CODE_FILES;
    if (activeCategory === 'R') return R_CODE_FILES;
    return SQL_SCHEMA_FILES;
  };

  const currentFiles = getFiles();
  const codeContent = currentFiles[selectedFile as keyof typeof currentFiles] || '// File not found';

  const handleCopy = () => {
    navigator.clipboard.writeText(codeContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <Code className="w-5 h-5 text-amber-400" />
            <h2 className="text-xl font-bold text-white">GridStrike Codebase & Schema Repository</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-xl">
            Inspect production Rust crates, R <code className="text-amber-400 font-mono">gridstrike.analytics</code> package scripts, and PostgreSQL DDL schemas.
          </p>
        </div>

        {/* Category Switcher */}
        <div className="flex items-center space-x-2">
          <button
            onClick={() => {
              setActiveCategory('RUST');
              setSelectedFile('rust/pricing/strike.rs');
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition ${
              activeCategory === 'RUST' ? 'bg-amber-500 text-slate-950 font-bold' : 'bg-slate-800 text-slate-300'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>Rust Engine</span>
          </button>

          <button
            onClick={() => {
              setActiveCategory('R');
              setSelectedFile('r/pricing/strike.R');
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition ${
              activeCategory === 'R' ? 'bg-amber-500 text-slate-950 font-bold' : 'bg-slate-800 text-slate-300'
            }`}
          >
            <Code className="w-3.5 h-3.5" />
            <span>R Analytics Package</span>
          </button>

          <button
            onClick={() => {
              setActiveCategory('SQL');
              setSelectedFile('sql/schema/01_tables.sql');
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center space-x-1.5 transition ${
              activeCategory === 'SQL' ? 'bg-amber-500 text-slate-950 font-bold' : 'bg-slate-800 text-slate-300'
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            <span>PostgreSQL Schema</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* File List Tree */}
        <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
          <h3 className="text-sm font-bold text-white border-b border-slate-800 pb-2">Repository Files</h3>
          <div className="space-y-1">
            {Object.keys(currentFiles).map((file) => (
              <button
                key={file}
                onClick={() => setSelectedFile(file)}
                className={`w-full text-left px-3 py-2 rounded-lg text-xs font-mono transition ${
                  selectedFile === file
                    ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30 font-bold'
                    : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                }`}
              >
                {file}
              </button>
            ))}
          </div>
        </div>

        {/* Code Display Window */}
        <div className="lg:col-span-8 bg-slate-950 border border-slate-800 rounded-2xl p-5 shadow-xl relative">
          <div className="flex justify-between items-center border-b border-slate-800 pb-3 mb-3">
            <span className="text-xs font-mono font-bold text-amber-400">{selectedFile}</span>
            <button
              onClick={handleCopy}
              className="flex items-center space-x-1 bg-slate-800 hover:bg-slate-700 text-slate-300 px-2.5 py-1 rounded text-xs transition"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied!' : 'Copy Code'}</span>
            </button>
          </div>

          <pre className="text-xs font-mono text-slate-300 overflow-x-auto p-4 bg-slate-900/80 rounded-xl max-h-[500px] leading-relaxed">
            <code>{codeContent}</code>
          </pre>
        </div>
      </div>
    </div>
  );
};
