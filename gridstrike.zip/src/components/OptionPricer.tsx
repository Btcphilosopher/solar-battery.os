/**
 * GridStrike Electricity Option Pricing & Volatility Engine
 */

import React, { useState } from 'react';
import { MarketInfo, OptionInputs, OptionResult } from '../types/gridstrike';
import { priceElectricityOption } from '../lib/strikeEngine';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts';
import { Activity, Sliders, Shield } from 'lucide-react';

interface OptionPricerProps {
  market: MarketInfo;
}

export const OptionPricer: React.FC<OptionPricerProps> = ({ market }) => {
  const [inputs, setInputs] = useState<OptionInputs>({
    optionType: 'CALL',
    underlyingPrice: market.currentSpot,
    strikePrice: Math.round(market.currentSpot * 1.05),
    tenorMonths: 6,
    riskFreeRatePct: 4.5,
    historicalVolPct: (market.impliedVol - 0.04) * 100,
    impliedVolPct: market.impliedVol * 100,
    jumpFrequencyPerYear: 2.5,
    jumpMeanPct: 35,
    jumpVolPct: 15,
    meanReversionSpeed: 3.5
  });

  const optionResult: OptionResult = priceElectricityOption(inputs);
  const curr = market.currency === 'GBP' ? '£' : market.currency === 'EUR' ? '€' : '$';

  return (
    <div className="space-y-6">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <Activity className="w-5 h-5 text-amber-400" />
            <h2 className="text-xl font-bold text-white">Power Option Pricing & Jump-Diffusion Engine</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-xl">
            Merton Jump-Diffusion model pricing electricity Calls, Puts, Caps, Floors, Collars and Swaptions to account for power price spike jump probability.
          </p>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-3 rounded-xl text-right font-mono text-xs">
          <span className="text-slate-400 block text-[10px]">OPTION VALUE</span>
          <span className="text-amber-400 font-bold text-xl">{curr}{optionResult.optionValue.toFixed(2)}/MWh</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <h3 className="text-sm font-bold text-white border-b border-slate-800 pb-2">Option Parameters</h3>

          <div>
            <label className="text-[11px] text-slate-400 block mb-1">Contract Structure</label>
            <select
              value={inputs.optionType}
              onChange={(e) => setInputs({ ...inputs, optionType: e.target.value as any })}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-amber-400 font-mono cursor-pointer"
            >
              <option value="CALL">Call Option (Cap Price)</option>
              <option value="PUT">Put Option (Floor Price)</option>
              <option value="CAP">Cap (Maximum Tariff Limit)</option>
              <option value="FLOOR">Floor (Minimum Revenue Guarantee)</option>
              <option value="COLLAR">Collar (Floor + Cap)</option>
              <option value="SWAPTION">Swaption (Option on PPA Swap)</option>
            </select>
          </div>

          <div>
            <label className="text-[11px] text-slate-400 block mb-1">Underlying Spot Price ({curr}/MWh)</label>
            <input
              type="number"
              value={inputs.underlyingPrice}
              onChange={(e) => setInputs({ ...inputs, underlyingPrice: parseFloat(e.target.value) || 0 })}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-amber-400 font-mono focus:outline-none"
            />
          </div>

          <div>
            <label className="text-[11px] text-slate-400 block mb-1">Strike Price ({curr}/MWh)</label>
            <input
              type="number"
              value={inputs.strikePrice}
              onChange={(e) => setInputs({ ...inputs, strikePrice: parseFloat(e.target.value) || 0 })}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-amber-400 font-mono focus:outline-none"
            />
          </div>

          <div>
            <label className="text-[11px] text-slate-400 block mb-1">Tenor (Months)</label>
            <input
              type="number"
              value={inputs.tenorMonths}
              onChange={(e) => setInputs({ ...inputs, tenorMonths: parseFloat(e.target.value) || 0 })}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-amber-400 font-mono focus:outline-none"
            />
          </div>

          <div>
            <label className="text-[11px] text-slate-400 block mb-1">Implied Volatility (%)</label>
            <input
              type="number"
              value={inputs.impliedVolPct}
              onChange={(e) => setInputs({ ...inputs, impliedVolPct: parseFloat(e.target.value) || 0 })}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-amber-400 font-mono focus:outline-none"
            />
          </div>

          <div>
            <label className="text-[11px] text-slate-400 block mb-1">Jump Frequency (Pikes/Year)</label>
            <input
              type="number"
              step="0.5"
              value={inputs.jumpFrequencyPerYear}
              onChange={(e) => setInputs({ ...inputs, jumpFrequencyPerYear: parseFloat(e.target.value) || 0 })}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-amber-400 font-mono focus:outline-none"
            />
          </div>
        </div>

        <div className="lg:col-span-8 space-y-6">
          {/* Greeks Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
            <div className="bg-slate-900 border border-slate-800 p-3 rounded-xl text-center">
              <span className="text-[10px] text-slate-400 block font-mono">DELTA (Δ)</span>
              <span className="text-sm font-bold font-mono text-emerald-400">{optionResult.delta.toFixed(3)}</span>
            </div>
            <div className="bg-slate-900 border border-slate-800 p-3 rounded-xl text-center">
              <span className="text-[10px] text-slate-400 block font-mono">GAMMA (Γ)</span>
              <span className="text-sm font-bold font-mono text-sky-400">{optionResult.gamma.toFixed(4)}</span>
            </div>
            <div className="bg-slate-900 border border-slate-800 p-3 rounded-xl text-center">
              <span className="text-[10px] text-slate-400 block font-mono">VEGA (ν)</span>
              <span className="text-sm font-bold font-mono text-amber-400">{optionResult.vega.toFixed(3)}</span>
            </div>
            <div className="bg-slate-900 border border-slate-800 p-3 rounded-xl text-center">
              <span className="text-[10px] text-slate-400 block font-mono">THETA (θ)</span>
              <span className="text-sm font-bold font-mono text-rose-400">{optionResult.theta.toFixed(3)}</span>
            </div>
            <div className="bg-slate-900 border border-slate-800 p-3 rounded-xl text-center">
              <span className="text-[10px] text-slate-400 block font-mono">JUMP PREMIUM</span>
              <span className="text-sm font-bold font-mono text-purple-400">+{curr}{optionResult.jumpDiffusionAdjustment.toFixed(2)}</span>
            </div>
          </div>

          {/* Payoff Chart */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
            <h3 className="text-sm font-bold text-white mb-4">Contract Payoff Diagram</h3>
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={optionResult.payoffStructure}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="spot" stroke="#94a3b8" fontSize={11} />
                  <YAxis stroke="#94a3b8" fontSize={11} />
                  <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#f8fafc' }} />
                  <Line type="monotone" dataKey="payoff" stroke="#f59e0b" strokeWidth={3} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
