/**
 * GridStrike Core Workbench Component
 * Calculates and visualises strike price derivations with full mathematical step breakdowns.
 */

import React, { useState, useEffect } from 'react';
import { StrikeDerivationResult, MarketInfo } from '../types/gridstrike';
import { calculateStrikeDerivation } from '../lib/strikeEngine';
import { ArrowRight, Info, CheckCircle2, DollarSign, Calculator, HelpCircle } from 'lucide-react';

interface StrikeWorkbenchProps {
  market: MarketInfo;
}

export const StrikeWorkbench: React.FC<StrikeWorkbenchProps> = ({ market }) => {
  const [expectedPrice, setExpectedPrice] = useState<number>(market.currentSpot);
  const [volatility, setVolatility] = useState<number>(market.impliedVol * 100);
  const [opex, setOpex] = useState<number>(21.0);
  const [captureFactor, setCaptureFactor] = useState<number>(0.91);
  const [debtService, setDebtService] = useState<number>(24.5);
  const [targetMargin, setTargetMargin] = useState<number>(12.0);

  const [result, setResult] = useState<StrikeDerivationResult | null>(null);

  useEffect(() => {
    setExpectedPrice(market.currentSpot);
    setVolatility(market.impliedVol * 100);
  }, [market]);

  useEffect(() => {
    const res = calculateStrikeDerivation(
      expectedPrice,
      volatility / 100,
      opex,
      captureFactor,
      debtService,
      targetMargin / 100
    );
    setResult(res);
  }, [expectedPrice, volatility, opex, captureFactor, debtService, targetMargin]);

  if (!result) return null;

  const unit = market.unit;
  const curr = market.currency === 'GBP' ? '£' : market.currency === 'EUR' ? '€' : '$';

  return (
    <div className="space-[#space] space-y-6">
      {/* Top Title & Core Concept Formula */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute -right-12 -top-12 w-64 h-64 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="bg-amber-500/10 text-amber-400 border border-amber-500/30 text-xs px-2.5 py-1 rounded-md font-mono font-bold uppercase tracking-wider">
                QUANTITATIVE MODEL
              </span>
              <h2 className="text-2xl font-bold text-white tracking-tight">Strike-Price Valuation Engine</h2>
            </div>
            <p className="text-slate-400 text-sm mt-1 max-w-2xl">
              Determine the economically rational strike price for energy contracts, power purchase agreements (PPAs), and hedge strategies under power-price distribution uncertainty.
            </p>
          </div>

          <div className="bg-slate-950/80 border border-slate-800 p-4 rounded-xl text-xs font-mono text-slate-300">
            <span className="text-amber-400 font-bold block mb-1">STRIKE PRICE EQUATION</span>
            <span>POWER PRICE + LOAD + VOLATILITY + OPTIONALITY + DEBT = <strong className="text-emerald-400">FAIR STRIKE</strong></span>
          </div>
        </div>
      </div>

      {/* Main Grid: Inputs vs Derivation Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Interactive Input Controls */}
        <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-5">
          <div className="flex items-center space-x-2 border-b border-slate-800 pb-3">
            <Calculator className="w-4 h-4 text-amber-400" />
            <h3 className="text-base font-bold text-white">Market & Asset Parameters</h3>
          </div>

          {/* Expected Electricity Price */}
          <div>
            <div className="flex justify-between text-xs font-medium text-slate-300 mb-1.5">
              <span>Expected Power Price</span>
              <span className="font-mono font-bold text-amber-400">{curr}{expectedPrice.toFixed(2)} / MWh</span>
            </div>
            <input
              type="range"
              min="20"
              max="250"
              step="0.5"
              value={expectedPrice}
              onChange={(e) => setExpectedPrice(parseFloat(e.target.value))}
              className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
            />
            <div className="flex justify-between text-[10px] text-slate-500 mt-1 font-mono">
              <span>{curr}20</span>
              <span>{curr}250</span>
            </div>
          </div>

          {/* Volatility */}
          <div>
            <div className="flex justify-between text-xs font-medium text-slate-300 mb-1.5">
              <span>Market Volatility (σ)</span>
              <span className="font-mono font-bold text-amber-400">{volatility.toFixed(1)}%</span>
            </div>
            <input
              type="range"
              min="10"
              max="100"
              step="1"
              value={volatility}
              onChange={(e) => setVolatility(parseFloat(e.target.value))}
              className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
            />
          </div>

          {/* Operating Cost */}
          <div>
            <div className="flex justify-between text-xs font-medium text-slate-300 mb-1.5">
              <span>Direct OPEX Cost</span>
              <span className="font-mono font-bold text-amber-400">{curr}{opex.toFixed(2)} / MWh</span>
            </div>
            <input
              type="range"
              min="5"
              max="80"
              step="0.5"
              value={opex}
              onChange={(e) => setOpex(parseFloat(e.target.value))}
              className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
            />
          </div>

          {/* Capture Factor */}
          <div>
            <div className="flex justify-between text-xs font-medium text-slate-300 mb-1.5">
              <span>Capture Factor (Cannibalisation)</span>
              <span className="font-mono font-bold text-amber-400">{captureFactor.toFixed(2)}x</span>
            </div>
            <input
              type="range"
              min="0.50"
              max="1.20"
              step="0.01"
              value={captureFactor}
              onChange={(e) => setCaptureFactor(parseFloat(e.target.value))}
              className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
            />
            <p className="text-[11px] text-slate-500 mt-1">
              Capture price = {curr}{(expectedPrice * captureFactor).toFixed(2)} / MWh
            </p>
          </div>

          {/* Debt Service Requirement */}
          <div>
            <div className="flex justify-between text-xs font-medium text-slate-300 mb-1.5">
              <span>Debt Service per MWh</span>
              <span className="font-mono font-bold text-amber-400">{curr}{debtService.toFixed(2)} / MWh</span>
            </div>
            <input
              type="range"
              min="0"
              max="60"
              step="0.5"
              value={debtService}
              onChange={(e) => setDebtService(parseFloat(e.target.value))}
              className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
            />
          </div>

          {/* Target Margin */}
          <div>
            <div className="flex justify-between text-xs font-medium text-slate-300 mb-1.5">
              <span>Target Equity Margin</span>
              <span className="font-mono font-bold text-amber-400">{targetMargin.toFixed(1)}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="35"
              step="0.5"
              value={targetMargin}
              onChange={(e) => setTargetMargin(parseFloat(e.target.value))}
              className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
            />
          </div>
        </div>

        {/* Right Column: Calculated Strike Cards Summary */}
        <div className="lg:col-span-8 space-y-6">
          {/* 6 Key Strike Metric Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {/* 1. Fair-Value Strike */}
            <div className="bg-gradient-to-b from-slate-900 to-slate-900/90 border border-emerald-500/40 rounded-2xl p-4 shadow-xl relative">
              <span className="text-[10px] font-mono font-bold text-emerald-400 uppercase tracking-wider block mb-1">
                PRIMARY FAIR VALUE
              </span>
              <div className="text-2xl font-extrabold text-white font-mono">
                {curr}{result.fairValueStrike.toFixed(2)}
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Fair strike compensating for volatility & profile capture.
              </p>
            </div>

            {/* 2. Risk-Adjusted Strike */}
            <div className="bg-slate-900 border border-sky-500/40 rounded-2xl p-4 shadow-xl">
              <span className="text-[10px] font-mono font-bold text-sky-400 uppercase tracking-wider block mb-1">
                RISK-ADJUSTED STRIKE
              </span>
              <div className="text-2xl font-extrabold text-white font-mono">
                {curr}{result.riskAdjustedStrike.toFixed(2)}
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Includes tail risk and volume cannibalisation buffer.
              </p>
            </div>

            {/* 3. Minimum Viable Strike */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl">
              <span className="text-[10px] font-mono font-bold text-amber-400 uppercase tracking-wider block mb-1">
                MINIMUM VIABLE (DSCR 1.0)
              </span>
              <div className="text-2xl font-extrabold text-white font-mono">
                {curr}{result.minViableStrike.toFixed(2)}
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Covers OPEX ({curr}{opex}) + Debt Service ({curr}{debtService}).
              </p>
            </div>

            {/* 4. Break-even Strike */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl">
              <span className="text-[10px] font-mono font-bold text-rose-400 uppercase tracking-wider block mb-1">
                BREAK-EVEN OPEX STRIKE
              </span>
              <div className="text-2xl font-extrabold text-white font-mono">
                {curr}{result.breakEvenStrike.toFixed(2)}
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Absolute minimum to cover operational cash outflows.
              </p>
            </div>

            {/* 5. Target Commercial Strike */}
            <div className="bg-slate-900 border border-purple-500/40 rounded-2xl p-4 shadow-xl">
              <span className="text-[10px] font-mono font-bold text-purple-400 uppercase tracking-wider block mb-1">
                TARGET COMMERCIAL
              </span>
              <div className="text-2xl font-extrabold text-white font-mono">
                {curr}{result.targetCommercialStrike.toFixed(2)}
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Achieves commercial equity return target of {targetMargin}%.
              </p>
            </div>

            {/* 6. Maximum Acceptable Offtaker Cap */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-xl">
              <span className="text-[10px] font-mono font-bold text-indigo-400 uppercase tracking-wider block mb-1">
                BUYER MAX ACCEPTABLE
              </span>
              <div className="text-2xl font-extrabold text-white font-mono">
                {curr}{result.maxAcceptableStrike.toFixed(2)}
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Maximum off-taker premium willing to pay above forward.
              </p>
            </div>
          </div>

          {/* Mathematical Step Derivation Breakdown */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-4">
              <div>
                <h3 className="text-lg font-bold text-white">Full Derivation Breakdown</h3>
                <p className="text-xs text-slate-400">Step-by-step mathematical logic used to compute strike prices.</p>
              </div>
              <span className="text-xs font-mono bg-slate-800 text-slate-300 px-3 py-1 rounded-full border border-slate-700">
                MODEL: DETERMINISTIC & VOLATILITY-ADJUSTED
              </span>
            </div>

            <div className="space-y-3">
              {result.derivationSteps.map((step, idx) => (
                <div
                  key={idx}
                  className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-4 hover:border-slate-700 transition"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center space-x-3">
                      <span className="w-6 h-6 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/30 font-mono font-bold text-xs flex items-center justify-center">
                        {idx + 1}
                      </span>
                      <div>
                        <h4 className="text-sm font-bold text-slate-200">{step.label}</h4>
                        <p className="text-xs text-slate-400 font-mono mt-0.5">{step.formula}</p>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="text-base font-bold font-mono text-emerald-400">
                        {curr}{step.value.toFixed(2)} {step.unit.replace('£/MWh', '').replace('€/MWh', '').replace('$/MWh', '')}
                      </span>
                    </div>
                  </div>
                  <p className="text-xs text-slate-500 mt-2 border-t border-slate-800/60 pt-2">
                    {step.explanation}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
