/**
 * GridStrike Top Navigation Header
 */

import React from 'react';
import { MarketRegion, MarketInfo } from '../types/gridstrike';
import { Zap, Activity, Code, BookOpen, RefreshCw, Layers } from 'lucide-react';

interface HeaderProps {
  activeMarket: MarketRegion;
  markets: Record<string, MarketInfo>;
  onSelectMarket: (m: MarketRegion) => void;
  activeTab: string;
  onSelectTab: (tab: string) => void;
  isRealtimeActive: boolean;
  onToggleRealtime: () => void;
  onOpenApiDocs: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeMarket,
  markets,
  onSelectMarket,
  activeTab,
  onSelectTab,
  isRealtimeActive,
  onToggleRealtime,
  onOpenApiDocs,
}) => {
  const currentMkt = markets[activeMarket] || markets['GB_N2EX'];

  const tabs = [
    { id: 'workbench', label: 'Strike Workbench', icon: Zap },
    { id: 'forward-curve', label: 'Forward Curves', icon: Activity },
    { id: 'ppa', label: 'Renewable PPA', icon: Layers },
    { id: 'battery', label: 'BESS Battery', icon: Zap },
    { id: 'thermal', label: 'Thermal SRMC', icon: Activity },
    { id: 'option', label: 'Option & Volatility', icon: Activity },
    { id: 'monte-carlo', label: 'Monte Carlo', icon: Activity },
    { id: 'optimiser', label: 'Strike Optimiser', icon: Zap },
    { id: 'risk-stress', label: 'Risk & Stress Lab', icon: Activity },
    { id: 'contracts', label: 'Contracts & Cash Flows', icon: BookOpen },
    { id: 'code-repo', label: 'Rust/R/SQL Engine', icon: Code },
  ];

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-slate-100 sticky top-0 z-40 shadow-xl">
      {/* Top Banner Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex flex-wrap items-center justify-between gap-4">
        {/* Brand Logo */}
        <div className="flex items-center space-x-3">
          <div className="bg-gradient-to-tr from-amber-500 to-orange-600 p-2.5 rounded-xl shadow-lg shadow-amber-500/20 flex items-center justify-center">
            <Zap className="w-6 h-6 text-slate-950 font-bold" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-xl font-extrabold tracking-tight bg-gradient-to-r from-white via-slate-200 to-amber-400 bg-clip-text text-transparent">
                GRIDSTRIKE
              </h1>
              <span className="text-xs bg-amber-500/10 text-amber-400 border border-amber-500/30 px-2 py-0.5 rounded-full font-mono font-semibold">
                RUST + R v1.4
              </span>
            </div>
            <p className="text-xs text-slate-400">Electricity Strike-Price Analytics & Optimisation</p>
          </div>
        </div>

        {/* Market Selector & Key Metrics */}
        <div className="flex items-center flex-wrap gap-3">
          {/* Market Dropdown */}
          <div className="flex items-center bg-slate-800/80 border border-slate-700/80 rounded-lg px-3 py-1.5 space-x-2">
            <span className="text-xs text-slate-400 font-medium">Market:</span>
            <select
              value={activeMarket}
              onChange={(e) => onSelectMarket(e.target.value as MarketRegion)}
              className="bg-transparent text-sm font-semibold text-amber-400 focus:outline-none cursor-pointer"
            >
              {Object.values(markets).map((m) => (
                <option key={m.id} value={m.id} className="bg-slate-900 text-slate-200">
                  {m.name} ({m.unit})
                </option>
              ))}
            </select>
          </div>

          {/* Quick Spot Display */}
          <div className="bg-slate-800/80 border border-slate-700/80 rounded-lg px-3 py-1.5 flex items-center space-x-3 text-xs font-mono">
            <div>
              <span className="text-slate-400 block text-[10px]">SPOT PRICE</span>
              <span className="text-emerald-400 font-bold text-sm">
                {currentMkt.currency === 'GBP' ? '£' : currentMkt.currency === 'EUR' ? '€' : '$'}
                {currentMkt.currentSpot.toFixed(2)}
              </span>
            </div>
            <div className="border-l border-slate-700 pl-3">
              <span className="text-slate-400 block text-[10px]">CARBON ETS</span>
              <span className="text-sky-400 font-semibold">
                €{currentMkt.carbonPrice.toFixed(2)}/t
              </span>
            </div>
            <div className="border-l border-slate-700 pl-3">
              <span className="text-slate-400 block text-[10px]">VOLATILITY</span>
              <span className="text-amber-400 font-semibold">
                {(currentMkt.impliedVol * 100).toFixed(0)}%
              </span>
            </div>
          </div>

          {/* Live Ticker Toggle */}
          <button
            onClick={onToggleRealtime}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              isRealtimeActive
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm shadow-emerald-500/10'
                : 'bg-slate-800 text-slate-400 border border-slate-700 hover:text-slate-200'
            }`}
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRealtimeActive ? 'animate-spin text-emerald-400' : ''}`} />
            <span>{isRealtimeActive ? 'LIVE TICKING' : 'PAUSED'}</span>
          </button>

          {/* OpenAPI Docs Modal Button */}
          <button
            onClick={onOpenApiDocs}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-amber-500/10 text-amber-400 border border-amber-500/30 hover:bg-amber-500/20 transition"
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>API Docs</span>
          </button>
        </div>
      </div>

      {/* Navigation Tab Bar */}
      <div className="bg-slate-950/60 border-t border-slate-800/80 overflow-x-auto scrollbar-none">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex space-x-1 py-1.5">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onSelectTab(tab.id)}
                className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-slate-950' : 'text-slate-400'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
