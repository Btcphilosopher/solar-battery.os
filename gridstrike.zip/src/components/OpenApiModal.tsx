/**
 * GridStrike OpenAPI 3.0 Documentation & REST Sandbox
 */

import React, { useState } from 'react';
import { BookOpen, X, Play, Copy, Check, Terminal } from 'lucide-react';

interface OpenApiModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const OpenApiModal: React.FC<OpenApiModalProps> = ({ isOpen, onClose }) => {
  const [activeEndpoint, setActiveEndpoint] = useState<string>('/api/pricing/strike');
  const [copied, setCopied] = useState<boolean>(false);
  const [apiResponse, setApiResponse] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(false);

  if (!isOpen) return null;

  const endpoints = [
    {
      path: '/api/pricing/strike',
      method: 'POST',
      summary: 'Calculate Comprehensive Strike Prices',
      payload: {
        expectedMarketPrice: 92.4,
        volatilityPct: 0.34,
        opexPerMwh: 21.0,
        captureFactor: 0.91,
        debtServiceMwh: 24.5
      }
    },
    {
      path: '/api/pricing/ppa',
      method: 'POST',
      summary: 'Calculate Renewable PPA Strike & LCOE',
      payload: {
        inputs: {
          assetType: 'WIND_OFFSHORE',
          capacityMw: 120,
          capexTotal: 180,
          opexPerMwh: 18.5,
          targetIrrPct: 8.5,
          captureFactor: 0.91,
          expectedCapacityFactorPct: 45.0
        },
        expectedMarketPrice: 92.4
      }
    },
    {
      path: '/api/pricing/battery',
      method: 'POST',
      summary: 'Calculate BESS Battery Storage Spread',
      payload: {
        inputs: {
          powerMw: 50,
          capacityMwh: 100,
          roundTripEfficiencyPct: 85,
          expectedChargePrice: 55.0
        }
      }
    },
    {
      path: '/api/simulation/monte-carlo',
      method: 'POST',
      summary: 'Run Monte Carlo Power Price Simulation',
      payload: {
        inputs: {
          numPaths: 1000,
          tenorDays: 30,
          basePrice: 92.4,
          volatilityPct: 34
        }
      }
    }
  ];

  const selected = endpoints.find((e) => e.path === activeEndpoint) || endpoints[0];

  const handleTestApi = async () => {
    setLoading(true);
    try {
      const res = await fetch(selected.path, {
        method: selected.method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(selected.payload)
      });
      const data = await res.json();
      setApiResponse(data);
    } catch (err: any) {
      setApiResponse({ error: err.message });
    } finally {
      setLoading(false);
    }
  };

  const curlCommand = `curl -X ${selected.method} "http://localhost:3000${selected.path}" \\\n  -H "Content-Type: application/json" \\\n  -d '${JSON.stringify(selected.payload, null, 2)}'`;

  const copyCurl = () => {
    navigator.clipboard.writeText(curlCommand);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-4xl shadow-2xl flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="flex justify-between items-center px-6 py-4 border-b border-slate-800">
          <div className="flex items-center space-x-2">
            <BookOpen className="w-5 h-5 text-amber-400" />
            <h2 className="text-lg font-bold text-white">GridStrike REST API Specification & Sandbox</h2>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white p-1 rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Endpoint Picker */}
          <div className="flex space-x-2 overflow-x-auto pb-2 border-b border-slate-800">
            {endpoints.map((ep) => (
              <button
                key={ep.path}
                onClick={() => {
                  setActiveEndpoint(ep.path);
                  setApiResponse(null);
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono whitespace-nowrap transition ${
                  activeEndpoint === ep.path
                    ? 'bg-amber-500 text-slate-950 font-bold'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                <span className="font-bold text-emerald-400 mr-1">{ep.method}</span>
                {ep.path}
              </button>
            ))}
          </div>

          <div>
            <h3 className="text-sm font-bold text-white">{selected.summary}</h3>
            <p className="text-xs text-slate-400 mt-0.5">Endpoint: <code className="text-amber-400 font-mono">{selected.path}</code></p>
          </div>

          {/* cURL Box */}
          <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl relative font-mono text-xs text-slate-300">
            <div className="flex justify-between items-center mb-2">
              <span className="text-[10px] text-slate-500 uppercase font-bold">cURL Command</span>
              <button onClick={copyCurl} className="text-slate-400 hover:text-white flex items-center space-x-1 text-[11px]">
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy cURL'}</span>
              </button>
            </div>
            <pre className="overflow-x-auto"><code>{curlCommand}</code></pre>
          </div>

          {/* Test Sandbox */}
          <div>
            <button
              onClick={handleTestApi}
              disabled={loading}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-xs flex items-center space-x-2 shadow-lg shadow-amber-500/20"
            >
              <Play className="w-4 h-4 fill-slate-950" />
              <span>{loading ? 'Executing API Request...' : 'Execute API Call'}</span>
            </button>

            {apiResponse && (
              <div className="mt-4 bg-slate-950 border border-slate-800 p-4 rounded-xl">
                <span className="text-[10px] font-mono text-emerald-400 uppercase font-bold block mb-2">HTTP 200 OK Response</span>
                <pre className="text-xs font-mono text-slate-300 overflow-x-auto max-h-60">
                  <code>{JSON.stringify(apiResponse, null, 2)}</code>
                </pre>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
