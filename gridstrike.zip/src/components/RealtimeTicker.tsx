/**
 * GridStrike Real-time Live Market Ticker & Audit History Log
 */

import React from 'react';
import { MarketInfo, AuditRecord } from '../types/gridstrike';
import { Activity, Clock, ShieldCheck, RefreshCw } from 'lucide-react';

interface RealtimeTickerProps {
  markets: Record<string, MarketInfo>;
  auditTrail: AuditRecord[];
  isRealtimeActive: boolean;
}

export const RealtimeTicker: React.FC<RealtimeTickerProps> = ({
  markets,
  auditTrail,
  isRealtimeActive,
}) => {
  return (
    <div className="bg-slate-900 border-t border-slate-800 p-4 text-xs">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Ticker Bar */}
        <div className="flex items-center space-x-4 overflow-x-auto w-full md:w-auto scrollbar-none">
          <div className="flex items-center space-x-1.5 text-amber-400 font-bold font-mono uppercase text-[11px] shrink-0">
            <RefreshCw className={`w-3.5 h-3.5 ${isRealtimeActive ? 'animate-spin text-emerald-400' : ''}`} />
            <span>LIVE POWER TICKER:</span>
          </div>

          {Object.values(markets).map((m) => (
            <div key={m.id} className="bg-slate-950 border border-slate-800 px-3 py-1 rounded-lg shrink-0 flex items-center space-x-2 font-mono">
              <span className="text-slate-400 font-bold">{m.id}:</span>
              <span className="text-emerald-400 font-bold">
                {m.currency === 'GBP' ? '£' : m.currency === 'EUR' ? '€' : '$'}
                {m.currentSpot.toFixed(2)}
              </span>
              <span className="text-slate-500 text-[10px]">({m.unit})</span>
            </div>
          ))}
        </div>

        {/* Latest Audit Record */}
        {auditTrail.length > 0 && (
          <div className="flex items-center space-x-2 text-slate-400 font-mono text-[11px] shrink-0 bg-slate-950 border border-slate-800 px-3 py-1 rounded-lg">
            <Clock className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-slate-500">AUDIT LOG:</span>
            <span className="text-slate-200">{auditTrail[0].event}</span>
            <span className="text-emerald-400 font-bold">
              {auditTrail[0].oldStrike} → {auditTrail[0].newStrike}
            </span>
          </div>
        )}
      </div>
    </div>
  );
};
