/**
 * GridStrike Monte Carlo Power Price Simulation Engine
 */

import React, { useState } from 'react';
import { MarketInfo, MonteCarloInputs, MonteCarloResult } from '../types/gridstrike';
import { runMonteCarloSimulation } from '../lib/strikeEngine';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts';
import { Activity, Play, Sliders, AlertTriangle } from 'lucide-react';

interface MonteCarloSimulatorProps {
  market: MarketInfo;
}

export const MonteCarloSimulator: React.FC<MonteCarloSimulatorProps> = ({ market }) => {
  const [inputs, setInputs] = useState<MonteCarloInputs>({
    numPaths: 2000,
    tenorDays: 30,
    basePrice: market.currentSpot,
    meanReversionSpeed: 3.5,
    longTermMeanPrice: Math.round(market.currentSpot * 0.95),
    volatilityPct: market.impliedVol * 100,
    spikeFrequency: 2.0,
    spikeIntensity: 45,
    weatherVolatilityBonusPct: 8.0,
    strikePriceToTest: Math.round(market.currentSpot * 0.92)
  });

  const mcResult: MonteCarloResult = runMonteCarloSimulation(inputs);
  const curr = market.currency === 'GBP' ? '£' : market.currency === 'EUR' ? '€' : '$';

  return (
    <div className="space-y-6">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <Activity className="w-5 h-5 text-amber-400" />
            <h2 className="text-xl font-bold text-white">Monte Carlo Price Path & Profit Simulator</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-xl">
            Simulates thousands of stochastic mean-reverting jump-diffusion power price paths to generate P1 to P99 quantile confidence bands and risk profiles.
          </p>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-3 rounded-xl text-right font-mono text-xs">
          <span className="text-slate-400 block text-[10px]">PROBABILITY OF LOSS</span>
          <span className={`font-bold text-lg ${mcResult.lossProbabilityPct < 15 ? 'text-emerald-400' : 'text-rose-400'}`}>
            {mcResult.lossProbabilityPct.toFixed(1)}%
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <h3 className="text-sm font-bold text-white border-b border-slate-800 pb-2">Simulation Parameters</h3>

          <div>
            <label className="text-[11px] text-slate-400 block mb-1">Simulated Paths</label>
            <input
              type="number"
              step="500"
              value={inputs.numPaths}
              onChange={(e) => setInputs({ ...inputs, numPaths: parseInt(e.target.value) || 1000 })}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-amber-400 font-mono focus:outline-none"
            />
          </div>

          <div>
            <label className="text-[11px] text-slate-400 block mb-1">Strike Price to Test ({curr}/MWh)</label>
            <input
              type="number"
              value={inputs.strikePriceToTest}
              onChange={(e) => setInputs({ ...inputs, strikePriceToTest: parseFloat(e.target.value) || 0 })}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-amber-400 font-mono focus:outline-none"
            />
          </div>

          <div>
            <label className="text-[11px] text-slate-400 block mb-1">Mean Reversion Speed (κ)</label>
            <input
              type="number"
              step="0.5"
              value={inputs.meanReversionSpeed}
              onChange={(e) => setInputs({ ...inputs, meanReversionSpeed: parseFloat(e.target.value) || 0 })}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-amber-400 font-mono focus:outline-none"
            />
          </div>

          <div>
            <label className="text-[11px] text-slate-400 block mb-1">Spike Intensity ({curr}/MWh)</label>
            <input
              type="number"
              value={inputs.spikeIntensity}
              onChange={(e) => setInputs({ ...inputs, spikeIntensity: parseFloat(e.target.value) || 0 })}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-amber-400 font-mono focus:outline-none"
            />
          </div>
        </div>

        <div className="lg:col-span-8 space-y-6">
          {/* Fan Chart */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
            <h3 className="text-sm font-bold text-white mb-4">Monte Carlo Quantile Fan Chart (P1–P99)</h3>
            <div className="h-72 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={mcResult.percentiles}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="day" stroke="#94a3b8" fontSize={11} label={{ value: 'Simulation Day', position: 'insideBottom', offset: -5 }} />
                  <YAxis stroke="#94a3b8" fontSize={11} />
                  <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#f8fafc' }} />
                  <Area type="monotone" dataKey="p99" stroke="#ef4444" fill="#ef4444" fillOpacity={0.1} name="P99 (Extreme High)" />
                  <Area type="monotone" dataKey="p90" stroke="#f59e0b" fill="#f59e0b" fillOpacity={0.15} name="P90 High" />
                  <Area type="monotone" dataKey="p50" stroke="#10b981" fill="#10b981" fillOpacity={0.25} name="P50 Median" />
                  <Area type="monotone" dataKey="p10" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.15} name="P10 Low" />
                  <Area type="monotone" dataKey="p1" stroke="#6366f1" fill="#6366f1" fillOpacity={0.1} name="P1 Extreme Low" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Key Percentiles Table */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-xl">
              <span className="text-[10px] text-slate-400 block font-mono">P50 MEDIAN PRICE</span>
              <span className="text-base font-bold font-mono text-emerald-400">{curr}{mcResult.p50Npv > 0 ? '+' : ''}{mcResult.p50Npv.toFixed(1)}</span>
            </div>
            <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-xl">
              <span className="text-[10px] text-slate-400 block font-mono">P10 DOWNSIDE</span>
              <span className="text-base font-bold font-mono text-amber-400">{curr}{mcResult.p10Npv.toFixed(1)}</span>
            </div>
            <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-xl">
              <span className="text-[10px] text-slate-400 block font-mono">P5 WORST CASE</span>
              <span className="text-base font-bold font-mono text-rose-400">{curr}{mcResult.p5Npv.toFixed(1)}</span>
            </div>
            <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-xl">
              <span className="text-[10px] text-slate-400 block font-mono">EXPECTED PnL</span>
              <span className="text-base font-bold font-mono text-sky-400">{curr}{mcResult.expectedProfitLoss.toFixed(1)}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
