/**
 * GridStrike Risk Engine & Stress Testing Laboratory
 */

import React, { useState } from 'react';
import { MarketInfo, RiskMetrics, StressScenario } from '../types/gridstrike';
import { calculateRiskMetrics, evaluateStressScenarios } from '../lib/strikeEngine';
import { ShieldAlert, AlertTriangle, TrendingDown, Activity } from 'lucide-react';

interface RiskStressLabProps {
  market: MarketInfo;
}

export const RiskStressLab: React.FC<RiskStressLabProps> = ({ market }) => {
  const [baseFairStrike, setBaseFairStrike] = useState<number>(84.0);

  const riskMetrics: RiskMetrics = calculateRiskMetrics(market.currentSpot, market.impliedVol * 100);
  const scenarios: StressScenario[] = evaluateStressScenarios(baseFairStrike);
  const curr = market.currency === 'GBP' ? '£' : market.currency === 'EUR' ? '€' : '$';

  return (
    <div className="space-y-6">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <ShieldAlert className="w-5 h-5 text-amber-400" />
            <h2 className="text-xl font-bold text-white">Risk Analytics & Stress Testing Laboratory</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-xl">
            Calculates Value at Risk (VaR), Conditional Value at Risk (CVaR), basis risk, and stress tests fair strike prices against extreme market shocks.
          </p>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-3 rounded-xl text-right font-mono text-xs">
          <span className="text-slate-400 block text-[10px]">CVaR 99% EXPECTED SHORTFALL</span>
          <span className="text-rose-400 font-bold text-lg">-{curr}{riskMetrics.cvar99.toFixed(2)}/MWh</span>
        </div>
      </div>

      {/* Key Risk Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-xl">
          <span className="text-[10px] font-mono text-slate-400 uppercase block">Value at Risk (VaR 95%)</span>
          <div className="text-2xl font-extrabold text-white font-mono mt-1">-{curr}{riskMetrics.var95.toFixed(2)}</div>
          <p className="text-xs text-slate-500 mt-1">1-day 95% confidence max loss</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-xl">
          <span className="text-[10px] font-mono text-slate-400 uppercase block">Value at Risk (VaR 99%)</span>
          <div className="text-2xl font-extrabold text-white font-mono mt-1">-{curr}{riskMetrics.var99.toFixed(2)}</div>
          <p className="text-xs text-slate-500 mt-1">1-day 99% confidence max loss</p>
        </div>

        <div className="bg-slate-900 border border-rose-500/40 p-4 rounded-2xl shadow-xl">
          <span className="text-[10px] font-mono text-rose-400 uppercase block">CVaR 95% (Expected Shortfall)</span>
          <div className="text-2xl font-extrabold text-white font-mono mt-1">-{curr}{riskMetrics.cvar95.toFixed(2)}</div>
          <p className="text-xs text-rose-400/80 mt-1">Tail loss beyond 95% VaR threshold</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-xl">
          <span className="text-[10px] font-mono text-amber-400 uppercase block">Basis Risk Exposure</span>
          <div className="text-2xl font-extrabold text-white font-mono mt-1">{curr}{riskMetrics.basisRiskExposure.toFixed(2)}</div>
          <p className="text-xs text-slate-500 mt-1">Nodal vs Hub price mismatch risk</p>
        </div>
      </div>

      {/* Stress Scenario Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-bold text-white flex items-center space-x-2">
            <AlertTriangle className="w-4 h-4 text-amber-400" />
            <span>Extreme Market Crisis Stress Test Matrix</span>
          </h3>
          <span className="text-xs font-mono text-slate-400">BASE STRIKE: {curr}{baseFairStrike.toFixed(2)}/MWh</span>
        </div>

        <div className="space-y-3">
          {scenarios.map((sc) => (
            <div key={sc.id} className="bg-slate-950/60 border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="max-w-md">
                <div className="flex items-center space-x-2">
                  <span className="text-xs font-mono font-bold bg-amber-500/10 text-amber-400 border border-amber-500/30 px-2 py-0.5 rounded">
                    {sc.id}
                  </span>
                  <h4 className="text-sm font-bold text-white">{sc.name}</h4>
                </div>
                <p className="text-xs text-slate-400 mt-1">{sc.description}</p>
              </div>

              <div className="flex items-center space-x-6 text-xs font-mono text-right">
                <div>
                  <span className="text-slate-500 block text-[10px]">SPOT DELTA</span>
                  <span className={`font-bold ${sc.spotPriceDeltaPct >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {sc.spotPriceDeltaPct >= 0 ? '+' : ''}{sc.spotPriceDeltaPct}%
                  </span>
                </div>

                <div>
                  <span className="text-slate-500 block text-[10px]">CURTAILMENT</span>
                  <span className="text-amber-400 font-bold">{sc.curtailmentPct}%</span>
                </div>

                <div>
                  <span className="text-slate-500 block text-[10px]">STRESSED FAIR STRIKE</span>
                  <span className="text-white font-bold text-sm">{curr}{sc.resultingFairStrike.toFixed(2)}</span>
                </div>

                <div>
                  <span className="text-slate-500 block text-[10px]">NPV IMPACT</span>
                  <span className={`font-bold text-sm ${sc.resultingNpvChangePct >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {sc.resultingNpvChangePct >= 0 ? '+' : ''}{sc.resultingNpvChangePct}%
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
