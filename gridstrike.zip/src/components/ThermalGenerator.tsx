/**
 * GridStrike Thermal Generator SRMC & Clean Spark Spread Engine
 */

import React, { useState } from 'react';
import { MarketInfo, ThermalInputs, ThermalResult } from '../types/gridstrike';
import { calculateThermalStrike } from '../lib/strikeEngine';
import { Flame, Activity, ShieldAlert } from 'lucide-react';

interface ThermalGeneratorProps {
  market: MarketInfo;
}

export const ThermalGenerator: React.FC<ThermalGeneratorProps> = ({ market }) => {
  const [inputs, setInputs] = useState<ThermalInputs>({
    plantType: 'CCGT',
    heatRateGjPerMwh: 2.1,
    efficiencyPct: 58.0,
    fuelPriceGj: market.gasPrice / 3.6, // Gas price in GJ equivalent approx
    carbonIntensityTonPerMwh: 0.38,
    carbonPriceTon: market.carbonPrice,
    variableOpexPerMwh: 4.5,
    startupCostPerMw: 18.0,
    fixedOpexPerKwYear: 28.0
  });

  const thermalResult: ThermalResult = calculateThermalStrike(inputs, market.currentSpot);
  const curr = market.currency === 'GBP' ? '£' : market.currency === 'EUR' ? '€' : '$';

  return (
    <div className="space-y-6">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <Flame className="w-5 h-5 text-amber-400" />
            <h2 className="text-xl font-bold text-white">Thermal Generator SRMC & Clean Spark/Dark Spread</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-xl">
            Calculates Short-Run Marginal Cost (SRMC), Long-Run Marginal Cost (LRMC), carbon compliance costs, and dispatch strike thresholds for thermal assets.
          </p>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-3 rounded-xl text-right font-mono text-xs">
          <span className="text-slate-400 block text-[10px]">CLEAN SPARK SPREAD</span>
          <span className={`font-bold text-lg ${thermalResult.cleanSparkSpread >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            {thermalResult.cleanSparkSpread >= 0 ? '+' : ''}{curr}{thermalResult.cleanSparkSpread.toFixed(2)}/MWh
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <h3 className="text-sm font-bold text-white border-b border-slate-800 pb-2">Thermal Plant Specification</h3>

          <div>
            <label className="text-[11px] text-slate-400 block mb-1">Fuel Price ({curr}/GJ)</label>
            <input
              type="number"
              value={inputs.fuelPriceGj}
              onChange={(e) => setInputs({ ...inputs, fuelPriceGj: parseFloat(e.target.value) || 0 })}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-amber-400 font-mono focus:outline-none"
            />
          </div>

          <div>
            <label className="text-[11px] text-slate-400 block mb-1">Heat Rate (GJ/MWh)</label>
            <input
              type="number"
              step="0.1"
              value={inputs.heatRateGjPerMwh}
              onChange={(e) => setInputs({ ...inputs, heatRateGjPerMwh: parseFloat(e.target.value) || 0 })}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-amber-400 font-mono focus:outline-none"
            />
          </div>

          <div>
            <label className="text-[11px] text-slate-400 block mb-1">Carbon Intensity (tCO2/MWh)</label>
            <input
              type="number"
              step="0.01"
              value={inputs.carbonIntensityTonPerMwh}
              onChange={(e) => setInputs({ ...inputs, carbonIntensityTonPerMwh: parseFloat(e.target.value) || 0 })}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-amber-400 font-mono focus:outline-none"
            />
          </div>

          <div>
            <label className="text-[11px] text-slate-400 block mb-1">Carbon ETS Price (€/tCO2)</label>
            <input
              type="number"
              value={inputs.carbonPriceTon}
              onChange={(e) => setInputs({ ...inputs, carbonPriceTon: parseFloat(e.target.value) || 0 })}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-amber-400 font-mono focus:outline-none"
            />
          </div>
        </div>

        <div className="lg:col-span-7 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
              <span className="text-[10px] font-mono text-slate-400 uppercase block">SHORT-RUN MARGINAL COST (SRMC)</span>
              <div className="text-2xl font-extrabold text-white font-mono mt-1">
                {curr}{thermalResult.srmcPerMwh.toFixed(2)}
              </div>
              <p className="text-xs text-slate-400 mt-1">In-the-money dispatch floor</p>
            </div>

            <div className="bg-slate-900 border border-amber-500/40 rounded-2xl p-5 shadow-xl">
              <span className="text-[10px] font-mono text-amber-400 uppercase block">LONG-RUN MARGINAL COST (LRMC)</span>
              <div className="text-2xl font-extrabold text-white font-mono mt-1">
                {curr}{thermalResult.lrmcPerMwh.toFixed(2)}
              </div>
              <p className="text-xs text-amber-400/80 mt-1">Full economic cost recovery</p>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
            <h4 className="text-sm font-bold text-white mb-3">Cost Component Breakdown</h4>
            <div className="space-y-2">
              {thermalResult.breakdown.map((step, i) => (
                <div key={i} className="bg-slate-950/60 p-3 rounded-xl border border-slate-800/80 flex justify-between items-center text-xs">
                  <div>
                    <span className="font-semibold text-slate-200 block">{step.label}</span>
                    <span className="text-slate-500 font-mono text-[10px]">{step.formula}</span>
                  </div>
                  <span className="font-mono font-bold text-emerald-400 text-sm">
                    {curr}{step.value.toFixed(2)} {step.unit.replace('£/MWh', '')}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
