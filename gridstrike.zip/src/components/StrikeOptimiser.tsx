/**
 * GridStrike Multi-Objective Strike Optimiser Solver
 */

import React, { useState } from 'react';
import { MarketInfo, OptimiserInputs, OptimiserResult } from '../types/gridstrike';
import { solveOptimalStrike } from '../lib/strikeEngine';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts';
import { Zap, Target, Sliders, CheckCircle2 } from 'lucide-react';

interface StrikeOptimiserProps {
  market: MarketInfo;
}

export const StrikeOptimiser: React.FC<StrikeOptimiserProps> = ({ market }) => {
  const [inputs, setInputs] = useState<OptimiserInputs>({
    assetCostPerMwh: 62.0,
    expectedMarketPrice: market.currentSpot,
    volatilityPct: market.impliedVol * 100,
    targetIrrPct: 8.5,
    targetNpvMillion: 12.0,
    maxDownsidePct: 15,
    maxLossProbabilityPct: 12,
    targetDscr: 1.35,
    objective: 'MINIMISE_STRIKE'
  });

  const optResult: OptimiserResult = solveOptimalStrike(inputs);
  const curr = market.currency === 'GBP' ? '£' : market.currency === 'EUR' ? '€' : '$';

  return (
    <div className="space-y-6">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <Target className="w-5 h-5 text-amber-400" />
            <h2 className="text-xl font-bold text-white">Multi-Objective Strike Optimiser Solver</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-xl">
            Finds optimal strike prices satisfying multi-variate constraints including target IRR, target NPV, maximum downside loss probability, and debt-service coverage ratio (DSCR).
          </p>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-3 rounded-xl text-right font-mono text-xs">
          <span className="text-slate-400 block text-[10px]">SOLVED OPTIMAL STRIKE</span>
          <span className="text-amber-400 font-bold text-2xl">{curr}{optResult.optimalStrike.toFixed(2)}/MWh</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <h3 className="text-sm font-bold text-white border-b border-slate-800 pb-2">Optimisation Objective & Constraints</h3>

          <div>
            <label className="text-[11px] text-slate-400 block mb-1">Primary Objective Function</label>
            <select
              value={inputs.objective}
              onChange={(e) => setInputs({ ...inputs, objective: e.target.value as any })}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-amber-400 font-mono cursor-pointer"
            >
              <option value="MINIMISE_STRIKE">MINIMISE STRIKE PRICE (Offtaker Competitive)</option>
              <option value="MAXIMISE_NPV">MAXIMISE PROJECT NPV</option>
              <option value="MAXIMISE_IRR">MAXIMISE EQUITY IRR</option>
              <option value="MAXIMISE_BANKABILITY">MAXIMISE BANKABILITY (DSCR)</option>
              <option value="MAXIMISE_RISK_ADJUSTED_RETURN">MAXIMISE SHARPE / RISK-ADJUSTED RETURN</option>
            </select>
          </div>

          <div>
            <label className="text-[11px] text-slate-400 block mb-1">Target Minimum IRR (%)</label>
            <input
              type="number"
              step="0.5"
              value={inputs.targetIrrPct}
              onChange={(e) => setInputs({ ...inputs, targetIrrPct: parseFloat(e.target.value) || 0 })}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-amber-400 font-mono focus:outline-none"
            />
          </div>

          <div>
            <label className="text-[11px] text-slate-400 block mb-1">Target Minimum NPV ({curr}M)</label>
            <input
              type="number"
              value={inputs.targetNpvMillion}
              onChange={(e) => setInputs({ ...inputs, targetNpvMillion: parseFloat(e.target.value) || 0 })}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-amber-400 font-mono focus:outline-none"
            />
          </div>

          <div>
            <label className="text-[11px] text-slate-400 block mb-1">Max Probability of Loss (%)</label>
            <input
              type="number"
              value={inputs.maxLossProbabilityPct}
              onChange={(e) => setInputs({ ...inputs, maxLossProbabilityPct: parseFloat(e.target.value) || 0 })}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-amber-400 font-mono focus:outline-none"
            />
          </div>

          <div>
            <label className="text-[11px] text-slate-400 block mb-1">Required Min DSCR Ratio</label>
            <input
              type="number"
              step="0.05"
              value={inputs.targetDscr}
              onChange={(e) => setInputs({ ...inputs, targetDscr: parseFloat(e.target.value) || 0 })}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-amber-400 font-mono focus:outline-none"
            />
          </div>
        </div>

        <div className="lg:col-span-8 space-y-6">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-xl">
              <span className="text-[10px] text-slate-400 block font-mono">ACHIEVED IRR</span>
              <span className="text-base font-bold font-mono text-emerald-400">{optResult.achievedIrrPct.toFixed(1)}%</span>
            </div>
            <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-xl">
              <span className="text-[10px] text-slate-400 block font-mono">ACHIEVED NPV</span>
              <span className="text-base font-bold font-mono text-amber-400">{curr}{optResult.achievedNpvMillion.toFixed(1)}M</span>
            </div>
            <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-xl">
              <span className="text-[10px] text-slate-400 block font-mono">ACHIEVED DSCR</span>
              <span className="text-base font-bold font-mono text-sky-400">{optResult.achievedDscr.toFixed(2)}x</span>
            </div>
            <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-xl">
              <span className="text-[10px] text-slate-400 block font-mono">LOSS PROBABILITY</span>
              <span className="text-base font-bold font-mono text-purple-400">{optResult.achievedLossProbPct.toFixed(1)}%</span>
            </div>
          </div>

          {/* Pareto Trade-off Frontier Chart */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
            <h3 className="text-sm font-bold text-white mb-4">Trade-off Frontier: NPV ({curr}M) vs Strike Price ({curr}/MWh)</h3>
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={optResult.tradeOffFrontier}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="strike" stroke="#94a3b8" fontSize={11} label={{ value: `Strike Price (${curr}/MWh)`, position: 'insideBottom', offset: -5 }} />
                  <YAxis stroke="#94a3b8" fontSize={11} label={{ value: `NPV (${curr}M)`, angle: -90, position: 'insideLeft' }} />
                  <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#f8fafc' }} />
                  <Line type="monotone" dataKey="npv" stroke="#f59e0b" strokeWidth={3} dot={{ r: 3 }} name={`Project NPV (${curr}M)`} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
