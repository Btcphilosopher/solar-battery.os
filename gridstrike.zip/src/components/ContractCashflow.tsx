/**
 * GridStrike Contract Management & 15-Year Financial Cash Flow Engine
 */

import React, { useState } from 'react';
import { MarketInfo, ContractDetails, CashFlowYear } from '../types/gridstrike';
import { INITIAL_CONTRACTS } from '../lib/mockData';
import { generate15YearCashFlow } from '../lib/strikeEngine';
import { BookOpen, FileText, DollarSign, Calendar, ShieldCheck } from 'lucide-react';

interface ContractCashflowProps {
  market: MarketInfo;
}

export const ContractCashflow: React.FC<ContractCashflowProps> = ({ market }) => {
  const [contracts] = useState<ContractDetails[]>(INITIAL_CONTRACTS);
  const [selectedContract, setSelectedContract] = useState<ContractDetails>(INITIAL_CONTRACTS[0]);

  const cashflows: CashFlowYear[] = generate15YearCashFlow(
    selectedContract.volumeMwhAnnual,
    selectedContract.strikePrice,
    18.5,
    selectedContract.capacityMw * 1.5
  );

  const curr = market.currency === 'GBP' ? '£' : market.currency === 'EUR' ? '€' : '$';

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <BookOpen className="w-5 h-5 text-amber-400" />
            <h2 className="text-xl font-bold text-white">Power Contract Engine & 15-Year Financial Schedule</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-xl">
            Contract directory for PPAs, CfDs, Options, Swaps, and Battery Tolling with 15-year cash flow projections and Debt Service Coverage Ratio (DSCR) monitoring.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Contract Directory List */}
        <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <h3 className="text-sm font-bold text-white border-b border-slate-800 pb-2">Active Contract Portfolio</h3>
          <div className="space-y-3">
            {contracts.map((c) => (
              <div
                key={c.id}
                onClick={() => setSelectedContract(c)}
                className={`p-3.5 rounded-xl border cursor-pointer transition ${
                  selectedContract.id === c.id
                    ? 'bg-amber-500/10 border-amber-500/50 text-white'
                    : 'bg-slate-950/60 border-slate-800/80 text-slate-300 hover:border-slate-700'
                }`}
              >
                <div className="flex justify-between items-start mb-1">
                  <span className="text-xs font-bold">{c.name}</span>
                  <span className="text-[10px] font-mono bg-slate-800 px-2 py-0.5 rounded text-amber-400 font-semibold">{c.type}</span>
                </div>
                <div className="flex justify-between text-[11px] text-slate-400 font-mono mt-2">
                  <span>Capacity: {c.capacityMw}MW</span>
                  <span className="text-emerald-400 font-bold">Strike: {curr}{c.strikePrice}/MWh</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Selected Contract Details & Cashflow Table */}
        <div className="lg:col-span-8 space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3 mb-4">
              <div>
                <h3 className="text-base font-bold text-white">{selectedContract.name} ({selectedContract.id})</h3>
                <p className="text-xs text-slate-400">Counterparty: {selectedContract.counterparty} | Duration: {selectedContract.durationYears} Years</p>
              </div>
              <span className="text-xs font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 px-3 py-1 rounded-full font-bold">
                {selectedContract.status}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
              <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                <span className="text-slate-500 block text-[10px]">ANNUAL VOLUME</span>
                <span className="text-white font-bold">{selectedContract.volumeMwhAnnual.toLocaleString()} MWh</span>
              </div>
              <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                <span className="text-slate-500 block text-[10px]">SETTLEMENT</span>
                <span className="text-amber-400 font-bold">{selectedContract.settlementInterval}</span>
              </div>
              <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                <span className="text-slate-500 block text-[10px]">INDEX</span>
                <span className="text-sky-400 font-bold">{selectedContract.priceIndex}</span>
              </div>
              <div className="bg-slate-950 p-2.5 rounded-lg border border-slate-800">
                <span className="text-slate-500 block text-[10px]">COLLATERAL</span>
                <span className="text-emerald-400 font-bold">{curr}{(selectedContract.collateralRequired / 1000000).toFixed(2)}M</span>
              </div>
            </div>
          </div>

          {/* 15-Year Financial Cashflow Schedule Table */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl overflow-x-auto">
            <h3 className="text-base font-bold text-white mb-4">15-Year Project Financial Schedule ({curr} Millions)</h3>
            <table className="w-full text-left text-xs text-slate-300 font-mono">
              <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
                <tr>
                  <th className="py-2.5 px-3">Year</th>
                  <th className="py-2.5 px-3">Gen (MWh)</th>
                  <th className="py-2.5 px-3">Market Rev</th>
                  <th className="py-2.5 px-3">Settlement</th>
                  <th className="py-2.5 px-3">Total Rev</th>
                  <th className="py-2.5 px-3">EBITDA</th>
                  <th className="py-2.5 px-3">Debt Service</th>
                  <th className="py-2.5 px-3">Free Cash Flow</th>
                  <th className="py-2.5 px-3">DSCR</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {cashflows.map((cf) => (
                  <tr key={cf.year} className="hover:bg-slate-800/40 transition">
                    <td className="py-2 px-3 font-bold text-amber-400">Yr {cf.year}</td>
                    <td className="py-2 px-3 text-slate-300">{cf.generationMwh.toLocaleString()}</td>
                    <td className="py-2 px-3 text-slate-400">{curr}{cf.marketRevenue.toFixed(2)}M</td>
                    <td className="py-2 px-3 text-sky-400">{curr}{cf.strikeSettlement.toFixed(2)}M</td>
                    <td className="py-2 px-3 text-emerald-400 font-bold">{curr}{cf.totalRevenue.toFixed(2)}M</td>
                    <td className="py-2 px-3 text-slate-200">{curr}{cf.ebitda.toFixed(2)}M</td>
                    <td className="py-2 px-3 text-rose-400">-{curr}{cf.debtService.toFixed(2)}M</td>
                    <td className="py-2 px-3 text-emerald-400 font-bold">{curr}{cf.freeCashFlow.toFixed(2)}M</td>
                    <td className="py-2 px-3 font-bold text-amber-400">{cf.dscr.toFixed(2)}x</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
