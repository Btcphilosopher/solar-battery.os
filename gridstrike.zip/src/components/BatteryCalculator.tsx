/**
 * GridStrike Battery Energy Storage System (BESS) Arbitrage Engine
 */

import React, { useState } from 'react';
import { MarketInfo, BatteryInputs, BatteryResult } from '../types/gridstrike';
import { calculateBatterySpread } from '../lib/strikeEngine';
import { Zap, BatteryCharging, ArrowUpRight, ArrowDownRight } from 'lucide-react';

interface BatteryCalculatorProps {
  market: MarketInfo;
}

export const BatteryCalculator: React.FC<BatteryCalculatorProps> = ({ market }) => {
  const [inputs, setInputs] = useState<BatteryInputs>({
    powerMw: 50,
    capacityMwh: 100, // 2 hour battery
    roundTripEfficiencyPct: 85,
    degradationPerCyclePct: 0.015,
    cyclingCostPerMwh: 12.0,
    marketFeesPerMwh: 2.5,
    expectedChargePrice: 55.0,
    maxCyclesPerDay: 1.5
  });

  const batteryResult: BatteryResult = calculateBatterySpread(inputs);
  const curr = market.currency === 'GBP' ? '£' : market.currency === 'EUR' ? '€' : '$';

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <BatteryCharging className="w-5 h-5 text-amber-400" />
            <h2 className="text-xl font-bold text-white">BESS Battery Storage Spread & Strike Calculator</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-xl">
            Calculates the required peak vs off-peak power price differential (spread) to justify charging and discharging BESS assets while accounting for round-trip efficiency (RTE) losses and cell degradation.
          </p>
        </div>

        <div className="bg-slate-950 border border-slate-800 p-3 rounded-xl text-right font-mono text-xs">
          <span className="text-slate-400 block text-[10px]">REQUIRED SPREAD</span>
          <span className="text-amber-400 font-bold text-lg">+{curr}{batteryResult.requiredSpread.toFixed(2)}/MWh</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Controls */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <h3 className="text-sm font-bold text-white border-b border-slate-800 pb-2">Battery Operating Parameters</h3>

          <div>
            <label className="text-[11px] text-slate-400 block mb-1">Expected Charging Price ({curr}/MWh)</label>
            <input
              type="number"
              value={inputs.expectedChargePrice}
              onChange={(e) => setInputs({ ...inputs, expectedChargePrice: parseFloat(e.target.value) || 0 })}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-amber-400 font-mono focus:outline-none"
            />
          </div>

          <div>
            <label className="text-[11px] text-slate-400 block mb-1">Round-Trip Efficiency RTE (%)</label>
            <input
              type="number"
              value={inputs.roundTripEfficiencyPct}
              onChange={(e) => setInputs({ ...inputs, roundTripEfficiencyPct: parseFloat(e.target.value) || 0 })}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-amber-400 font-mono focus:outline-none"
            />
          </div>

          <div>
            <label className="text-[11px] text-slate-400 block mb-1">Degradation & Cycling Wear Cost ({curr}/MWh)</label>
            <input
              type="number"
              value={inputs.cyclingCostPerMwh}
              onChange={(e) => setInputs({ ...inputs, cyclingCostPerMwh: parseFloat(e.target.value) || 0 })}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-amber-400 font-mono focus:outline-none"
            />
          </div>

          <div>
            <label className="text-[11px] text-slate-400 block mb-1">Market & Grid Trading Fees ({curr}/MWh)</label>
            <input
              type="number"
              value={inputs.marketFeesPerMwh}
              onChange={(e) => setInputs({ ...inputs, marketFeesPerMwh: parseFloat(e.target.value) || 0 })}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-amber-400 font-mono focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] text-slate-400 block mb-1">Power Rating (MW)</label>
              <input
                type="number"
                value={inputs.powerMw}
                onChange={(e) => setInputs({ ...inputs, powerMw: parseFloat(e.target.value) || 0 })}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-amber-400 font-mono focus:outline-none"
              />
            </div>
            <div>
              <label className="text-[11px] text-slate-400 block mb-1">Capacity (MWh)</label>
              <input
                type="number"
                value={inputs.capacityMwh}
                onChange={(e) => setInputs({ ...inputs, capacityMwh: parseFloat(e.target.value) || 0 })}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-amber-400 font-mono focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Results */}
        <div className="lg:col-span-7 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
              <span className="text-[10px] font-mono text-slate-400 uppercase flex items-center space-x-1">
                <ArrowDownRight className="w-3.5 h-3.5 text-emerald-400" />
                <span>MAX CHARGING PRICE</span>
              </span>
              <div className="text-2xl font-extrabold text-white font-mono mt-2">
                {curr}{batteryResult.chargePrice.toFixed(2)}
              </div>
              <p className="text-xs text-slate-400 mt-1">Maximum off-peak power draw cost</p>
            </div>

            <div className="bg-slate-900 border border-amber-500/40 rounded-2xl p-5 shadow-xl">
              <span className="text-[10px] font-mono text-amber-400 uppercase flex items-center space-x-1">
                <ArrowUpRight className="w-3.5 h-3.5 text-amber-400" />
                <span>MIN DISCHARGE STRIKE</span>
              </span>
              <div className="text-2xl font-extrabold text-white font-mono mt-2">
                {curr}{batteryResult.minDischargePrice.toFixed(2)}
              </div>
              <p className="text-xs text-amber-400/80 mt-1">Minimum peak export price threshold</p>
            </div>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
            <h4 className="text-sm font-bold text-white mb-3">Arbitrage Math Derivation</h4>
            <div className="space-y-2">
              {batteryResult.breakdown.map((step, i) => (
                <div key={i} className="bg-slate-950/60 p-3 rounded-xl border border-slate-800/80 flex justify-between items-center text-xs">
                  <div>
                    <span className="font-semibold text-slate-200 block">{step.label}</span>
                    <span className="text-slate-500 font-mono text-[10px]">{step.formula}</span>
                  </div>
                  <span className="font-mono font-bold text-emerald-400 text-sm">
                    {curr}{step.value.toFixed(2)} {step.unit.replace('£/MWh', '')}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
