/**
 * GridStrike Forward Electricity Curve Engine
 */

import React, { useState } from 'react';
import { MarketInfo, ForwardCurvePoint } from '../types/gridstrike';
import { generateForwardCurve } from '../lib/strikeEngine';
import {
  ResponsiveContainer,
  ComposedChart,
  Line,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';
import { Activity, Layers, Download, Sliders } from 'lucide-react';

interface ForwardCurveViewerProps {
  market: MarketInfo;
}

export const ForwardCurveViewer: React.FC<ForwardCurveViewerProps> = ({ market }) => {
  const [scenarioOffset, setScenarioOffset] = useState<number>(15.0);
  const [selectedTenor, setSelectedTenor] = useState<'QUARTERLY' | 'MONTHLY' | 'ANNUAL'>('QUARTERLY');

  const curveData: ForwardCurvePoint[] = generateForwardCurve(market.id, market.currentSpot, scenarioOffset);

  const curr = market.currency === 'GBP' ? '£' : market.currency === 'EUR' ? '€' : '$';

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <Activity className="w-5 h-5 text-amber-400" />
            <h2 className="text-xl font-bold text-white">Forward Electricity Curve Engine</h2>
          </div>
          <p className="text-xs text-slate-400 mt-1 max-w-xl">
            Interpolated forward power curves, peak/off-peak seasonal structures, and stress scenario curves for {market.name}.
          </p>
        </div>

        {/* Controls */}
        <div className="flex items-center space-x-3">
          <div className="bg-slate-950 border border-slate-800 rounded-lg p-2 flex items-center space-x-3">
            <span className="text-xs text-slate-400 font-medium">Scenario Offset:</span>
            <input
              type="range"
              min="-40"
              max="60"
              value={scenarioOffset}
              onChange={(e) => setScenarioOffset(parseFloat(e.target.value))}
              className="w-28 accent-amber-500"
            />
            <span className="text-xs font-mono font-bold text-amber-400">
              {scenarioOffset >= 0 ? `+${curr}${scenarioOffset}` : `-${curr}${Math.abs(scenarioOffset)}`}
            </span>
          </div>
        </div>
      </div>

      {/* Main Chart Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-base font-bold text-white flex items-center space-x-2">
            <span>2026–2030 Power Forward Curve Structure ({market.unit})</span>
          </h3>

          <div className="flex items-center space-x-2 text-xs font-mono">
            <span className="flex items-center space-x-1 text-amber-400">
              <span className="w-3 h-0.5 bg-amber-400 inline-block" />
              <span>Base Forward</span>
            </span>
            <span className="flex items-center space-x-1 text-sky-400">
              <span className="w-3 h-0.5 bg-sky-400 inline-block" />
              <span>Peak Power</span>
            </span>
            <span className="flex items-center space-x-1 text-purple-400">
              <span className="w-3 h-0.5 bg-purple-400 inline-block" />
              <span>Scenario Curve</span>
            </span>
          </div>
        </div>

        <div className="h-80 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={curveData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
              <XAxis dataKey="period" stroke="#94a3b8" fontSize={11} tickLine={false} />
              <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} domain={['auto', 'auto']} />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#0f172a',
                  borderColor: '#334155',
                  borderRadius: '0.75rem',
                  fontSize: '12px',
                  color: '#f8fafc'
                }}
                formatter={(value: any) => [`${curr}${value}/MWh`, 'Price']}
              />
              <Legend />
              <Bar dataKey="offPeakPrice" fill="#1e293b" name="Off-Peak Power" radius={[4, 4, 0, 0]} />
              <Line type="monotone" dataKey="basePrice" stroke="#f59e0b" strokeWidth={3} dot={{ r: 4 }} name="Base Price" />
              <Line type="monotone" dataKey="peakPrice" stroke="#38bdf8" strokeWidth={2} strokeDasharray="4 4" name="Peak Price" />
              <Line type="monotone" dataKey="scenarioPrice" stroke="#c084fc" strokeWidth={2} name="Stress Scenario" />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Forward Curve Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl overflow-x-auto">
        <h3 className="text-base font-bold text-white mb-4">Forward Period Breakdown Table</h3>
        <table className="w-full text-left text-xs text-slate-300 font-mono">
          <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] border-b border-slate-800">
            <tr>
              <th className="py-3 px-4">Period</th>
              <th className="py-3 px-4">Tenor</th>
              <th className="py-3 px-4">Base Price</th>
              <th className="py-3 px-4">Peak Price</th>
              <th className="py-3 px-4">Off-Peak Price</th>
              <th className="py-3 px-4">Scenario Price</th>
              <th className="py-3 px-4">Peak/Off-Peak Spread</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {curveData.map((pt) => (
              <tr key={pt.period} className="hover:bg-slate-800/40 transition">
                <td className="py-2.5 px-4 font-bold text-slate-200">{pt.period}</td>
                <td className="py-2.5 px-4 text-slate-400">{pt.tenor}</td>
                <td className="py-2.5 px-4 text-amber-400 font-bold">{curr}{pt.basePrice.toFixed(2)}</td>
                <td className="py-2.5 px-4 text-sky-400">{curr}{pt.peakPrice.toFixed(2)}</td>
                <td className="py-2.5 px-4 text-slate-400">{curr}{pt.offPeakPrice.toFixed(2)}</td>
                <td className="py-2.5 px-4 text-purple-400">{curr}{pt.scenarioPrice?.toFixed(2)}</td>
                <td className="py-2.5 px-4 text-emerald-400">+{curr}{(pt.peakPrice - pt.offPeakPrice).toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
