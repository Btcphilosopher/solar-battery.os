/**
 * GridStrike Embedded Source Code Repository
 * Contains full Rust source code, R gridstrike.analytics package modules, and SQL DDL scripts.
 */

export const RUST_CODE_FILES = {
  'rust/pricing/strike.rs': `// GridStrike Rust Engine: Strike Price Derivation Core
// Crate: gridstrike-pricing

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StrikeRequest {
    pub expected_market_price: f64,
    pub volatility_pct: f64,
    pub opex_per_mwh: f64,
    pub capture_factor: f64,
    pub debt_service_mwh: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StrikeResponse {
    pub break_even_strike: f64,
    pub fair_value_strike: f64,
    pub risk_adjusted_strike: f64,
    pub min_viable_strike: f64,
    pub max_acceptable_strike: f64,
    pub target_commercial_strike: f64,
}

pub fn calculate_strike(req: &StrikeRequest) -> StrikeResponse {
    let capture_price = req.expected_market_price * req.capture_factor;
    let break_even = req.opex_per_mwh;
    let min_viable = req.opex_per_mwh + req.debt_service_mwh;
    
    // Volatility risk adjustment
    let vol_buffer = req.expected_market_price * req.volatility_pct * 0.075;
    let fair_val = capture_price - vol_buffer;
    
    let capture_discount = req.expected_market_price - capture_price;
    let risk_adj = fair_val - (capture_discount * 0.25);
    
    let max_acc = req.expected_market_price * 1.08;
    let target_comm = min_viable * 1.12;

    StrikeResponse {
        break_even_strike: (break_even * 100.0).round() / 100.0,
        fair_value_strike: (fair_val * 100.0).round() / 100.0,
        risk_adjusted_strike: (risk_adj * 100.0).round() / 100.0,
        min_viable_strike: (min_viable * 100.0).round() / 100.0,
        max_acceptable_strike: (max_acc * 100.0).round() / 100.0,
        target_commercial_strike: (target_comm * 100.0).round() / 100.0,
    }
}`,

  'rust/market_data/ingest.rs': `// GridStrike Rust Engine: Market Data Ingestion & Normalization
// Crate: gridstrike-marketdata

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum Market {
    GbN2ex,
    DeEex,
    NordPool,
    UsPjm,
    UsErcot,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PricePoint {
    pub timestamp: DateTime<Utc>,
    pub market: Market,
    pub node_region: String,
    pub price: f64,
    pub currency: String,
    pub unit: String,
    pub quality: String,
}

pub async fn ingest_ticker(market: Market, raw_price: f64) -> Result<PricePoint, String> {
    // Normalisation rules: Convert to MWh standard
    Ok(PricePoint {
        timestamp: Utc::now(),
        market,
        node_region: "HUB_PRIMARY".to_string(),
        price: raw_price,
        currency: "GBP".to_string(),
        unit: "£/MWh".to_string(),
        quality: "HIGH".to_string(),
    })
}`,

  'rust/risk/var.rs': `// GridStrike Rust Engine: High-Performance Value at Risk (VaR) & CVaR
// Crate: gridstrike-risk

pub struct RiskCalculator;

impl RiskCalculator {
    pub fn compute_var_cvar(prices: &[f64], confidence: f64) -> (f64, f64) {
        let mut sorted = prices.to_vec();
        sorted.sort_by(|a, b| a.partial_cmp(b).unwrap());
        
        let index = ((1.0 - confidence) * sorted.len() as f64).floor() as usize;
        let var = sorted[index];
        
        let tail_slice = &sorted[0..index + 1];
        let cvar = tail_slice.iter().sum::<f64>() / tail_slice.len() as f64;
        
        (var.abs(), cvar.abs())
    }
}`
};

export const R_CODE_FILES = {
  'r/pricing/strike.R': `# R Package: gridstrike.analytics
# File: R/pricing_strike.R
# Valuation & Strike-Price Optimisation Functions

#' Calculate PPA Strike Price with Capture Price Adjustment
#'
#' @param capex Total capital expenditure
#' @param opex Operational expenditure per MWh
#' @param expected_gen Expected annual generation in MWh
#' @param capture_factor Ratio of capture price to market average
#' @param target_irr Target IRR fraction (e.g. 0.08)
#' @return List containing LCOE, min strike, and risk-adjusted strike
#' @export
calculate_ppastrike <- function(capex, opex, expected_gen, capture_factor, target_irr = 0.08) {
  crf <- (target_irr * (1 + target_irr)^15) / ((1 + target_irr)^15 - 1)
  annual_capex <- capex * crf
  lcoe <- (annual_capex / expected_gen) + opex
  
  min_strike <- lcoe / capture_factor
  risk_adj_strike <- min_strike * 1.12
  
  return(list(
    lcoe = round(lcoe, 2),
    min_ppa_strike = round(min_strike, 2),
    target_ppa_strike = round(min_strike * 1.15, 2),
    risk_adjusted_strike = round(risk_adj_strike, 2),
    confidence = 0.95,
    version = "1.4.0"
  ))
}`,

  'r/forecasting/curve.R': `# R Package: gridstrike.analytics
# File: R/forecasting_curve.R
# Forward Electricity Curve Construction & Interpolation

#' Build Forward Power Curve
#'
#' @param spot_price Current spot price
#' @param seasonality Monthly seasonal factors vector (12)
#' @param gas_price Natural gas spot price
#' @param carbon_price Carbon ETS price
#' @return Data frame of forward hourly and monthly electricity curves
#' @export
build_forward_curve <- function(spot_price, seasonality, gas_price, carbon_price) {
  months <- 1:24
  heat_rate <- 2.1 # GJ/MWh for CCGT
  carbon_intensity <- 0.38 # tCO2/MWh
  
  srmc <- (gas_price * heat_rate) + (carbon_price * carbon_intensity) + 5.0
  
  forward_prices <- sapply(months, function(m) {
    s_factor <- seasonality[(m - 1) %% 12 + 1]
    base <- max(srmc, spot_price * s_factor)
    return(base)
  })
  
  data.frame(
    month = months,
    forward_price = round(forward_prices, 2),
    srmc_floor = round(srmc, 2)
  )
}`,

  'r/monte_carlo/simulate.R': `# R Package: gridstrike.analytics
# File: R/monte_carlo_simulate.R
# Stochastic Power Price Path Simulation

#' Simulate Stochastic Electricity Price Paths (Mean Reversion + Jump Diffusion)
#'
#' @param n_paths Number of Monte Carlo paths
#' @param n_days Simulation horizon in days
#' @param S0 Initial spot price
#' @param kappa Mean reversion speed
#' @param theta Long term equilibrium price
#' @param sigma Volatility
#' @param lambda_jump Jump frequency per year
#' @return Matrix of price paths (n_days x n_paths)
#' @export
simulate_prices <- function(n_paths = 1000, n_days = 90, S0 = 92.0, kappa = 3.5, theta = 85.0, sigma = 0.34, lambda_jump = 2.0) {
  dt <- 1 / 365
  paths <- matrix(0, nrow = n_days + 1, ncol = n_paths)
  paths[1, ] <- S0
  
  for (p in 1:n_paths) {
    S <- S0
    for (d in 1:n_days) {
      dW <- rnorm(1, 0, sqrt(dt))
      drift <- kappa * (theta - S) * dt
      diffusion <- sigma * S * dW
      
      # Jump component
      jump <- 0
      if (runif(1) < lambda_jump * dt) {
        jump <- S * rnorm(1, 0.40, 0.15)
      }
      
      S <- max(1.0, S + drift + diffusion + jump)
      paths[d + 1, p] <- S
    }
  }
  
  return(paths)
}`
};

export const SQL_SCHEMA_FILES = {
  'sql/schema/01_tables.sql': `-- GridStrike PostgreSQL Database Schema
-- Standardised Market, Curve, Contract and Valuation Storage

CREATE TABLE IF NOT EXISTS markets (
    market_id VARCHAR(32) PRIMARY KEY,
    name VARCHAR(128) NOT NULL,
    country VARCHAR(64) NOT NULL,
    currency VARCHAR(8) NOT NULL,
    unit VARCHAR(16) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS prices (
    price_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    market_id VARCHAR(32) REFERENCES markets(market_id),
    node_region VARCHAR(64) NOT NULL,
    timestamp TIMESTAMP WITH TIME ZONE NOT NULL,
    price_value NUMERIC(12, 4) NOT NULL,
    source VARCHAR(64) NOT NULL,
    quality VARCHAR(16) NOT NULL
);

CREATE TABLE IF NOT EXISTS forward_curves (
    curve_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    market_id VARCHAR(32) REFERENCES markets(market_id),
    period_code VARCHAR(32) NOT NULL,
    base_price NUMERIC(12, 4) NOT NULL,
    peak_price NUMERIC(12, 4) NOT NULL,
    offpeak_price NUMERIC(12, 4) NOT NULL,
    calculated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS ppas (
    ppa_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    asset_name VARCHAR(128) NOT NULL,
    capacity_mw NUMERIC(10, 2) NOT NULL,
    capex_total NUMERIC(15, 2) NOT NULL,
    opex_mwh NUMERIC(10, 2) NOT NULL,
    capture_factor NUMERIC(6, 4) NOT NULL,
    target_strike NUMERIC(12, 4) NOT NULL,
    risk_adjusted_strike NUMERIC(12, 4) NOT NULL,
    status VARCHAR(32) NOT NULL
);

CREATE TABLE IF NOT EXISTS strike_results (
    result_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    market_id VARCHAR(32) REFERENCES markets(market_id),
    expected_price NUMERIC(12, 4) NOT NULL,
    break_even_strike NUMERIC(12, 4) NOT NULL,
    fair_value_strike NUMERIC(12, 4) NOT NULL,
    risk_adjusted_strike NUMERIC(12, 4) NOT NULL,
    min_viable_strike NUMERIC(12, 4) NOT NULL,
    target_commercial_strike NUMERIC(12, 4) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);`
};
