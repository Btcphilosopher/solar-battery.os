/**
 * GridStrike Mock Data & Initial Seed Data
 */

import { MarketInfo, ContractDetails, AuditRecord } from '../types/gridstrike';

export const INITIAL_MARKETS: Record<string, MarketInfo> = {
  GB_N2EX: {
    id: 'GB_N2EX',
    name: 'Great Britain (N2EX / EPEX)',
    country: 'United Kingdom',
    currency: 'GBP',
    unit: '£/MWh',
    currentSpot: 92.40,
    dayAheadAvg: 89.80,
    impliedVol: 0.34,
    carbonPrice: 76.50,
    gasPrice: 88.20
  },
  DE_EEX: {
    id: 'DE_EEX',
    name: 'Germany (EEX / EPEX Spot)',
    country: 'Germany',
    currency: 'EUR',
    unit: '€/MWh',
    currentSpot: 84.10,
    dayAheadAvg: 81.50,
    impliedVol: 0.38,
    carbonPrice: 72.00,
    gasPrice: 38.50
  },
  NORD_POOL: {
    id: 'NORD_POOL',
    name: 'Nord Pool (System Price)',
    country: 'Nordics',
    currency: 'EUR',
    unit: '€/MWh',
    currentSpot: 48.20,
    dayAheadAvg: 46.90,
    impliedVol: 0.28,
    carbonPrice: 72.00,
    gasPrice: 38.50
  },
  US_PJM: {
    id: 'US_PJM',
    name: 'US PJM West Hub',
    country: 'United States',
    currency: 'USD',
    unit: '$/MWh',
    currentSpot: 54.80,
    dayAheadAvg: 51.20,
    impliedVol: 0.42,
    carbonPrice: 14.00,
    gasPrice: 3.20
  },
  US_ERCOT: {
    id: 'US_ERCOT',
    name: 'US ERCOT North Hub',
    country: 'United States',
    currency: 'USD',
    unit: '$/MWh',
    currentSpot: 62.10,
    dayAheadAvg: 58.40,
    impliedVol: 0.58,
    carbonPrice: 0.00,
    gasPrice: 3.10
  }
};

export const INITIAL_CONTRACTS: ContractDetails[] = [
  {
    id: 'CTR-PPA-2026-001',
    name: 'Hornsea-3 Offshore Wind PPA',
    type: 'PPA',
    assetName: 'Hornsea Wind Farm',
    counterparty: 'Statkraft Trading UK',
    capacityMw: 120,
    volumeMwhAnnual: 480000,
    strikePrice: 84.50,
    durationYears: 15,
    settlementInterval: '30MIN',
    priceIndex: 'GB_N2EX_30M',
    floorPrice: 50.00,
    capPrice: 140.00,
    collateralRequired: 4500000,
    escalationPctAnnual: 2.0,
    status: 'ACTIVE'
  },
  {
    id: 'CTR-BESS-2026-004',
    name: 'Thames Grid BESS Tolling Agreement',
    type: 'BATTERY_TOLLING',
    assetName: 'Thames BESS 50MW/100MWh',
    counterparty: 'Centrica Energy',
    capacityMw: 50,
    volumeMwhAnnual: 73000,
    strikePrice: 38.00, // required spread
    durationYears: 10,
    settlementInterval: '15MIN',
    priceIndex: 'GB_N2EX_15M',
    floorPrice: 25.00,
    collateralRequired: 2200000,
    escalationPctAnnual: 1.5,
    status: 'ACTIVE'
  },
  {
    id: 'CTR-CFD-2026-009',
    name: 'Solway Firth Solar CfD Strike',
    type: 'CfD',
    assetName: 'Solway Solar Park 80MW',
    counterparty: 'LCCC (Low Carbon Contracts Company)',
    capacityMw: 80,
    volumeMwhAnnual: 88000,
    strikePrice: 78.20,
    durationYears: 15,
    settlementInterval: 'HOURLY',
    priceIndex: 'GB_N2EX_HOURLY',
    collateralRequired: 1800000,
    escalationPctAnnual: 2.5,
    status: 'OPTIMISING'
  },
  {
    id: 'CTR-OPT-2026-012',
    name: 'Peaker OCGT Call Option Cap',
    type: 'POWER_OPTION',
    assetName: 'Immingham Peaker Gas 100MW',
    counterparty: 'SSE Energy Markets',
    capacityMw: 100,
    volumeMwhAnnual: 150000,
    strikePrice: 120.00,
    durationYears: 3,
    settlementInterval: '30MIN',
    priceIndex: 'GB_N2EX_PEAK',
    capPrice: 300.00,
    collateralRequired: 3100000,
    escalationPctAnnual: 0.0,
    status: 'ACTIVE'
  }
];

export const INITIAL_AUDIT_TRAIL: AuditRecord[] = [
  {
    id: 'AUD-901',
    timestamp: '2026-08-14 04:18:22',
    market: 'GB_N2EX',
    event: 'Forward Curve Tick - Winter Peak Increase',
    oldPrice: 91.20,
    newPrice: 92.40,
    oldStrike: 86.70,
    newStrike: 87.80,
    userSystem: 'RUST_MARKET_FEED'
  },
  {
    id: 'AUD-900',
    timestamp: '2026-08-14 04:10:05',
    market: 'GB_N2EX',
    event: 'R Analytics Re-optimization Triggered',
    oldPrice: 89.50,
    newPrice: 91.20,
    oldStrike: 84.90,
    newStrike: 86.70,
    userSystem: 'R_OPTIMISER_DAEMON'
  },
  {
    id: 'AUD-899',
    timestamp: '2026-08-14 03:55:12',
    market: 'DE_EEX',
    event: 'EEX Day-ahead Spot Settlement',
    oldPrice: 82.30,
    newPrice: 84.10,
    oldStrike: 78.10,
    newStrike: 79.80,
    userSystem: 'EEX_FEED_INGEST'
  }
];
