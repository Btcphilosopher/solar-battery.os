/**
 * GridStrike Quantitative Calculation Engine
 * Implements rigorous financial, statistical, and power market algorithms
 */

import {
  StrikeDerivationResult,
  DerivationStep,
  PpaInputs,
  PpaResult,
  BatteryInputs,
  BatteryResult,
  ThermalInputs,
  ThermalResult,
  OptionInputs,
  OptionResult,
  MonteCarloInputs,
  MonteCarloResult,
  OptimiserInputs,
  OptimiserResult,
  RiskMetrics,
  StressScenario,
  CashFlowYear,
  ForwardCurvePoint,
  MarketRegion,
} from '../types/gridstrike';

// Helper for rounding to 2 decimal places
const r2 = (val: number) => Math.round(val * 100) / 100;
const r4 = (val: number) => Math.round(val * 10000) / 10000;

// ==========================================
// 1. CORE STRIKE-PRICE DERIVATION ENGINE
// ==========================================

export function calculateStrikeDerivation(
  expectedMarketPrice: number, // e.g. £92/MWh
  volatilityPct: number,       // e.g. 0.34 (34%)
  operatingCost: number,       // e.g. £21/MWh
  captureFactor: number,       // e.g. 0.91
  debtServicePerMwh: number = 24.5,
  targetMarginPct: number = 0.12, // 12%
  riskPremiumFactor: number = 0.85
): StrikeDerivationResult {
  const steps: DerivationStep[] = [];

  // 1. Base Expected Market Price
  steps.push({
    label: 'Base Expected Market Price',
    formula: 'E[P_market]',
    value: expectedMarketPrice,
    unit: '£/MWh',
    explanation: 'Unweighted benchmark average electricity market price expectation.'
  });

  // 2. Capture-Price Adjustment
  const capturePrice = expectedMarketPrice * captureFactor;
  steps.push({
    label: 'Realised Capture Price',
    formula: 'E[P_market] × Capture Factor',
    value: r2(capturePrice),
    unit: '£/MWh',
    explanation: `Asset generation profile weighting factor of ${captureFactor} (discount for solar/wind profile cannibalisation).`
  });

  // 3. Operating Expense Coverage
  steps.push({
    label: 'Direct Operating Expenses (OPEX)',
    formula: 'OPEX_direct',
    value: operatingCost,
    unit: '£/MWh',
    explanation: 'Fixed and variable operation and maintenance costs per MWh.'
  });

  // 4. Break-even Strike (Min price to cover Opex)
  const breakEvenStrike = operatingCost;
  steps.push({
    label: 'Break-even Strike Price',
    formula: 'OPEX_direct',
    value: r2(breakEvenStrike),
    unit: '£/MWh',
    explanation: 'Absolute minimum revenue required to cover operational cash outflows.'
  });

  // 5. Debt Service & Financing Strike
  const minViableStrike = operatingCost + debtServicePerMwh;
  steps.push({
    label: 'Minimum Viable Strike Price',
    formula: 'OPEX + Debt Service Requirement',
    value: r2(minViableStrike),
    unit: '£/MWh',
    explanation: 'Minimum strike required to achieve DSCR = 1.0x and prevent debt default.'
  });

  // 6. Volatility & Risk Adjustment
  // Volatility buffer = Volatility * Vol Premium * Price
  const volRiskPremium = expectedMarketPrice * volatilityPct * (1 - riskPremiumFactor) * 0.5;
  const fairValueStrike = capturePrice - volRiskPremium;
  steps.push({
    label: 'Fair-Value Strike Price',
    formula: 'Capture Price - Volatility Risk Buffer',
    value: r2(fairValueStrike),
    unit: '£/MWh',
    explanation: `Calculated fair strike compensating for ${r2(volatilityPct * 100)}% market price volatility.`
  });

  // 7. Risk-Adjusted Strike
  const captureDiscount = expectedMarketPrice - capturePrice;
  const riskAdjustedStrike = fairValueStrike - (captureDiscount * 0.25);
  steps.push({
    label: 'Risk-Adjusted Strike Price',
    formula: 'Fair Strike - Capture Risk Discount - Tail Buffer',
    value: r2(riskAdjustedStrike),
    unit: '£/MWh',
    explanation: 'Protects buyer and seller against downside volume-price correlation risk.'
  });

  // 8. Max Acceptable Strike for Power Buyer/Offtaker
  const maxAcceptableStrike = expectedMarketPrice * 1.08;
  steps.push({
    label: 'Maximum Acceptable Strike (Buyer Cap)',
    formula: 'Expected Market Price × 1.08',
    value: r2(maxAcceptableStrike),
    unit: '£/MWh',
    explanation: 'Maximum price off-taker is willing to pay above expected market forward curve.'
  });

  // 9. Target Commercial Strike
  const targetCommercialStrike = minViableStrike * (1 + targetMarginPct);
  steps.push({
    label: 'Target Commercial Strike',
    formula: 'Min Viable Strike × (1 + Target Margin)',
    value: r2(targetCommercialStrike),
    unit: '£/MWh',
    explanation: `Commercial negotiation target providing a ${r2(targetMarginPct * 100)}% equity return buffer.`
  });

  return {
    expectedMarketPrice,
    breakEvenStrike: r2(breakEvenStrike),
    fairValueStrike: r2(fairValueStrike),
    riskAdjustedStrike: r2(riskAdjustedStrike),
    minViableStrike: r2(minViableStrike),
    maxAcceptableStrike: r2(maxAcceptableStrike),
    targetCommercialStrike: r2(targetCommercialStrike),
    derivationSteps: steps,
    timestamp: new Date().toISOString()
  };
}

// ==========================================
// 2. FORWARD CURVE GENERATOR & INTERPOLATION
// ==========================================

export function generateForwardCurve(
  market: MarketRegion,
  basePrice: number,
  scenarioOffset: number = 0
): ForwardCurvePoint[] {
  const points: ForwardCurvePoint[] = [];
  const years = [2026, 2027, 2028, 2029, 2030];
  const quarters = ['Q1', 'Q2', 'Q3', 'Q4'];

  years.forEach((yr) => {
    quarters.forEach((q, idx) => {
      // Seasonal multiplier (Q1 & Q4 winter high, Q2 & Q3 summer lower)
      const seasonal = q === 'Q1' ? 1.25 : q === 'Q2' ? 0.85 : q === 'Q3' ? 0.88 : 1.18;
      const decay = 1 - (yr - 2026) * 0.03; // Long term forward curve shape
      const base = (basePrice * seasonal * decay) + scenarioOffset;
      const peak = base * 1.22;
      const offPeak = base * 0.81;
      const scenario = base * (1 + (q === 'Q1' ? 0.15 : -0.08));

      points.push({
        period: `${yr}-${q}`,
        date: `${yr}-${(idx * 3 + 1).toString().padStart(2, '0')}-01`,
        tenor: 'QUARTERLY',
        basePrice: r2(base),
        peakPrice: r2(peak),
        offPeakPrice: r2(offPeak),
        scenarioPrice: r2(scenario)
      });
    });
  });

  return points;
}

// ==========================================
// 3. RENEWABLE GENERATION PPA STRIKE & CAPTURE PRICE
// ==========================================

export function calculatePpaStrike(inputs: PpaInputs, expectedMarketPrice: number): PpaResult {
  const annualGenMwh = inputs.capacityMw * 8760 * (inputs.expectedCapacityFactorPct / 100);
  const netGenMwh = annualGenMwh * (1 - inputs.curtailmentPct / 100);

  // Capital recovery factor
  const r = inputs.targetIrrPct / 100;
  const n = inputs.contractDurationYears;
  const crf = (r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);

  const annualCapexCost = inputs.capexTotal * 1000000 * crf;
  const capexPerMwh = annualCapexCost / netGenMwh;
  const opexPerMwh = inputs.opexPerMwh;
  const imbalanceCost = inputs.imbalanceCostPerMwh;

  const lcoe = capexPerMwh + opexPerMwh + imbalanceCost;

  // Capture price calculation
  const capturePrice = expectedMarketPrice * inputs.captureFactor;

  // PPA strikes
  const minPpaStrike = lcoe / inputs.captureFactor;
  const targetPpaStrike = minPpaStrike * 1.15;
  const riskAdjustedPpaStrike = targetPpaStrike * 1.08;

  const annualRevAtTarget = netGenMwh * targetPpaStrike;
  const annualOpexTotal = netGenMwh * (opexPerMwh + imbalanceCost);
  const ebitda = annualRevAtTarget - annualOpexTotal;

  // Debt calculations
  const debtPrincipal = inputs.capexTotal * 1000000 * (inputs.debtRatioPct / 100);
  const debtServiceAnnual = debtPrincipal * (inputs.interestRatePct / 100 + 0.05); // amortizing approx
  const dscrMin = debtServiceAnnual > 0 ? ebitda / debtServiceAnnual : 2.5;

  const npvAtTarget = (ebitda - annualCapexCost / n) * n * 0.7;

  const breakdown: DerivationStep[] = [
    {
      label: 'Annual Net Energy Generation',
      formula: 'Capacity × 8760 × CapacityFactor × (1 - Curtailment)',
      value: r2(netGenMwh),
      unit: 'MWh/year',
      explanation: 'Net electricity exported after curtailment allowance.'
    },
    {
      label: 'Levelised Cost of Energy (LCOE)',
      formula: 'Annualised CAPEX + OPEX + Imbalance per MWh',
      value: r2(lcoe),
      unit: '£/MWh',
      explanation: 'Total cost of project per unit of electricity generated.'
    },
    {
      label: 'Asset Capture Price',
      formula: 'Expected Market Price × Capture Factor',
      value: r2(capturePrice),
      unit: '£/MWh',
      explanation: `Asset generation profile capture factor (${inputs.captureFactor}).`
    },
    {
      label: 'Minimum PPA Strike',
      formula: 'LCOE / Capture Factor',
      value: r2(minPpaStrike),
      unit: '£/MWh',
      explanation: 'Strike required to achieve baseline break-even equity return.'
    },
    {
      label: 'Target Commercial PPA Strike',
      formula: 'Min PPA Strike × 1.15 Target Margin',
      value: r2(targetPpaStrike),
      unit: '£/MWh',
      explanation: `Strike required to satisfy target IRR of ${inputs.targetIrrPct}%.`
    },
    {
      label: 'Risk-Adjusted PPA Strike',
      formula: 'Target PPA Strike × 1.08 Volatility & Imbalance Buffer',
      value: r2(riskAdjustedPpaStrike),
      unit: '£/MWh',
      explanation: 'Includes buffer for extreme wind/solar cannibalisation and imbalance penalties.'
    }
  ];

  return {
    minPpaStrike: r2(minPpaStrike),
    targetPpaStrike: r2(targetPpaStrike),
    riskAdjustedPpaStrike: r2(riskAdjustedPpaStrike),
    capturePrice: r2(capturePrice),
    expectedAnnualGenerationMwh: r2(netGenMwh),
    lcoePerMwh: r2(lcoe),
    irrAtTargetStrike: inputs.targetIrrPct,
    npvAtTargetStrike: r2(npvAtTarget / 1000000), // Millions
    dscrMin: r2(dscrMin),
    breakdown
  };
}

// ==========================================
// 4. BATTERY STORAGE STRIKE & SPREAD
// ==========================================

export function calculateBatterySpread(inputs: BatteryInputs): BatteryResult {
  const rteDecimal = inputs.roundTripEfficiencyPct / 100;
  
  // To cover 1 MWh discharge, we need (1 / RTE) MWh charge
  const chargeEnergyNeededPerDischargeMwh = 1 / rteDecimal;
  const chargeCostPerDischargeMwh = inputs.expectedChargePrice * chargeEnergyNeededPerDischargeMwh;

  const totalVariableCost = inputs.cyclingCostPerMwh + inputs.marketFeesPerMwh;
  const minimumDischargePrice = chargeCostPerDischargeMwh + totalVariableCost;
  const requiredSpread = minimumDischargePrice - inputs.expectedChargePrice;

  // Max acceptable charge price if target discharge price was fixed
  const benchmarkDischarge = 110; // £110/MWh benchmark
  const maxAcceptableChargePrice = (benchmarkDischarge - totalVariableCost) * rteDecimal;

  const dailyMwhDischarged = inputs.powerMw * 2 * inputs.maxCyclesPerDay;
  const dailyRevenue = dailyMwhDischarged * requiredSpread;
  const annualNetProfit = dailyRevenue * 365;

  const breakdown: DerivationStep[] = [
    {
      label: 'Charge Energy Required per MWh Discharge',
      formula: '1 / Round-Trip Efficiency',
      value: r2(chargeEnergyNeededPerDischargeMwh),
      unit: 'MWh',
      explanation: `For RTE of ${inputs.roundTripEfficiencyPct}%, battery draws ${r2(chargeEnergyNeededPerDischargeMwh)} MWh per MWh exported.`
    },
    {
      label: 'Effective Charge Cost',
      formula: 'Charge Price × (1 / RTE)',
      value: r2(chargeCostPerDischargeMwh),
      unit: '£/MWh',
      explanation: `Charging cost adjusted for efficiency loss at £${inputs.expectedChargePrice}/MWh charge price.`
    },
    {
      label: 'Cycling & Degradation Opex',
      formula: 'Cycling Cost + Market Fees',
      value: r2(totalVariableCost),
      unit: '£/MWh',
      explanation: 'Cell degradation wear-and-tear plus grid trading fees.'
    },
    {
      label: 'Minimum Profitable Discharge Strike',
      formula: '(Charge Price / RTE) + Operating Costs',
      value: r2(minimumDischargePrice),
      unit: '£/MWh',
      explanation: 'Minimum price required when discharging to avoid negative gross margins.'
    },
    {
      label: 'Required Arbitrage Spread',
      formula: 'Min Discharge Price - Charge Price',
      value: r2(requiredSpread),
      unit: '£/MWh',
      explanation: 'Required peak vs off-peak power price spread.'
    }
  ];

  return {
    chargePrice: inputs.expectedChargePrice,
    requiredSpread: r2(requiredSpread),
    minDischargePrice: r2(minimumDischargePrice),
    maxAcceptableChargePrice: r2(maxAcceptableChargePrice),
    dailyRevenuePerMw: r2(dailyRevenue / inputs.powerMw),
    annualNetProfit: r2(annualNetProfit),
    breakdown
  };
}

// ==========================================
// 5. THERMAL GENERATION SRMC / LRMC ENGINE
// ==========================================

export function calculateThermalStrike(inputs: ThermalInputs, currentPowerPrice: number): ThermalResult {
  // Fuel Cost per MWh = Fuel Price (GJ) * Heat Rate (GJ/MWh) or (3.6 / Efficiency)
  const fuelCostPerMwh = inputs.fuelPriceGj * inputs.heatRateGjPerMwh;
  const carbonCostPerMwh = inputs.carbonIntensityTonPerMwh * inputs.carbonPriceTon;
  const vom = inputs.variableOpexPerMwh;

  const srmc = fuelCostPerMwh + carbonCostPerMwh + vom;
  
  // Fixed Opex amortisation assuming 4,000 equivalent running hours
  const fixedAmortPerMwh = (inputs.fixedOpexPerKwYear * 1000) / 4000;
  const lrmc = srmc + fixedAmortPerMwh;

  const minEconomicStrike = srmc + 2.5; // Small margin buffer
  const cleanSparkSpread = currentPowerPrice - srmc;

  const breakdown: DerivationStep[] = [
    {
      label: 'Fuel Component Cost',
      formula: 'Fuel Price (GJ) × Heat Rate (GJ/MWh)',
      value: r2(fuelCostPerMwh),
      unit: '£/MWh',
      explanation: `Raw fuel cost at £${inputs.fuelPriceGj}/GJ fuel price.`
    },
    {
      label: 'Carbon Emissions Cost',
      formula: 'Emissions Intensity (t/MWh) × Carbon Price (£/t)',
      value: r2(carbonCostPerMwh),
      unit: '£/MWh',
      explanation: `EU/UK ETS carbon price impact (${inputs.carbonIntensityTonPerMwh} tCO2/MWh).`
    },
    {
      label: 'Variable O&M',
      formula: 'VOM_direct',
      value: r2(vom),
      unit: '£/MWh',
      explanation: 'Consumables, water, maintenance wear per MWh generated.'
    },
    {
      label: 'Short-Run Marginal Cost (SRMC)',
      formula: 'Fuel + Carbon + VOM',
      value: r2(srmc),
      unit: '£/MWh',
      explanation: 'In-the-money dispatch threshold price.'
    },
    {
      label: 'Long-Run Marginal Cost (LRMC)',
      formula: 'SRMC + Fixed O&M Amortisation',
      value: r2(lrmc),
      unit: '£/MWh',
      explanation: 'Full economic cost including fixed plant staff & overheads.'
    },
    {
      label: 'Clean Spark/Dark Spread',
      formula: 'Current Market Price - SRMC',
      value: r2(cleanSparkSpread),
      unit: '£/MWh',
      explanation: `Plant operational margin at current £${currentPowerPrice}/MWh market price.`
    }
  ];

  return {
    srmcPerMwh: r2(srmc),
    lrmcPerMwh: r2(lrmc),
    minEconomicStrike: r2(minEconomicStrike),
    fuelCostComponent: r2(fuelCostPerMwh),
    carbonCostComponent: r2(carbonCostPerMwh),
    vomComponent: r2(vom),
    cleanSparkSpread: r2(cleanSparkSpread),
    breakdown
  };
}

// ==========================================
// 6. ELECTRICITY OPTION PRICING (Merton Jump-Diffusion)
// ==========================================

export function priceElectricityOption(inputs: OptionInputs): OptionResult {
  const S = inputs.underlyingPrice;
  const K = inputs.strikePrice;
  const T = inputs.tenorMonths / 12;
  const r = inputs.riskFreeRatePct / 100;
  const sigma = inputs.impliedVolPct / 100;

  // Black-Scholes benchmark d1, d2
  const d1 = (Math.log(S / K) + (r + (sigma * sigma) / 2) * T) / (sigma * Math.sqrt(T));
  const d2 = d1 - sigma * Math.sqrt(T);

  const normCdf = (x: number) => {
    const t = 1 / (1 + 0.2316419 * Math.abs(x));
    const d = 0.3989423 * Math.exp((-x * x) / 2);
    let prob = d * t * (0.3193815 + t * (-0.3565638 + t * (1.781478 + t * (-1.821256 + t * 1.330274))));
    if (x > 0) prob = 1 - prob;
    return prob;
  };

  const normPdf = (x: number) => (1 / Math.sqrt(2 * Math.PI)) * Math.exp(-0.5 * x * x);

  const N_d1 = normCdf(d1);
  const N_d2 = normCdf(d2);

  let bsCall = S * N_d1 - K * Math.exp(-r * T) * N_d2;
  if (inputs.optionType === 'PUT') {
    bsCall = K * Math.exp(-r * T) * normCdf(-d2) - S * normCdf(-d1);
  }

  // Merton Jump-Diffusion Adjustment for electricity price spikes
  const lambda = inputs.jumpFrequencyPerYear;
  const muJ = inputs.jumpMeanPct / 100;
  const sigmaJ = inputs.jumpVolPct / 100;

  let jumpPrice = bsCall;
  const maxJumps = 5;
  for (let k = 1; k <= maxJumps; k++) {
    const poissProb = (Math.pow(lambda * T, k) * Math.exp(-lambda * T)) / factorial(k);
    const sigmaK = Math.sqrt(sigma * sigma + (k * sigmaJ * sigmaJ) / T);
    const rK = r - lambda * muJ + (k * Math.log(1 + muJ)) / T;
    
    const d1K = (Math.log(S / K) + (rK + (sigmaK * sigmaK) / 2) * T) / (sigmaK * Math.sqrt(T));
    const d2K = d1K - sigmaK * Math.sqrt(T);
    
    const kCall = S * normCdf(d1K) - K * Math.exp(-rK * T) * normCdf(d2K);
    jumpPrice += poissProb * kCall;
  }

  const finalOptionValue = Math.max(0.01, jumpPrice);

  // Greeks
  const delta = inputs.optionType === 'CALL' ? N_d1 : N_d1 - 1;
  const gamma = normPdf(d1) / (S * sigma * Math.sqrt(T));
  const vega = (S * normPdf(d1) * Math.sqrt(T)) / 100;
  const theta = (-(S * normPdf(d1) * sigma) / (2 * Math.sqrt(T)) - r * K * Math.exp(-r * T) * N_d2) / 365;
  const rho = (K * T * Math.exp(-r * T) * N_d2) / 100;

  // Payoff structure curve
  const payoffStructure = [];
  const minSpot = Math.max(10, S * 0.5);
  const maxSpot = S * 1.6;
  const step = (maxSpot - minSpot) / 15;

  for (let s = minSpot; s <= maxSpot; s += step) {
    let payoff = 0;
    if (inputs.optionType === 'CALL') payoff = Math.max(0, s - K);
    else if (inputs.optionType === 'PUT') payoff = Math.max(0, K - s);
    else if (inputs.optionType === 'CAP') payoff = Math.max(0, s - K);
    else if (inputs.optionType === 'FLOOR') payoff = Math.max(0, K - s);
    else if (inputs.optionType === 'COLLAR') {
      const capLevel = K * 1.25;
      payoff = s < K ? K - s : s > capLevel ? -(s - capLevel) : 0;
    } else {
      payoff = Math.max(0, s - K);
    }

    payoffStructure.push({ spot: r2(s), payoff: r2(payoff) });
  }

  return {
    optionValue: r2(finalOptionValue),
    delta: r4(delta),
    gamma: r4(gamma),
    vega: r4(vega),
    theta: r4(theta),
    rho: r4(rho),
    blackScholesBenchmark: r2(bsCall),
    jumpDiffusionAdjustment: r2(finalOptionValue - bsCall),
    payoffStructure
  };
}

function factorial(n: number): number {
  if (n <= 1) return 1;
  return n * factorial(n - 1);
}

// ==========================================
// 7. MONTE CARLO STOCHASTIC POWER PRICE SIMULATOR
// ==========================================

export function runMonteCarloSimulation(inputs: MonteCarloInputs): MonteCarloResult {
  const {
    numPaths,
    tenorDays,
    basePrice,
    meanReversionSpeed,
    longTermMeanPrice,
    volatilityPct,
    spikeFrequency,
    spikeIntensity,
    weatherVolatilityBonusPct,
    strikePriceToTest
  } = inputs;

  const dt = 1 / 365;
  const totalSteps = Math.min(90, tenorDays); // simulate up to 90 time points
  const sigma = volatilityPct / 100;

  const allPaths: number[][] = [];
  const percentilesPerDay: {
    day: number;
    p1: number;
    p5: number;
    p10: number;
    p50: number;
    p90: number;
    p95: number;
    p99: number;
    mean: number;
  }[] = [];

  const sampledPathsCount = Math.min(10, numPaths);
  for (let i = 0; i < sampledPathsCount; i++) {
    const path: number[] = [basePrice];
    let currentPrice = basePrice;

    for (let t = 1; t <= totalSteps; t++) {
      // Mean reversion component
      const meanRev = meanReversionSpeed * (longTermMeanPrice - currentPrice) * dt;
      // Seasonality factor
      const seasonality = Math.sin((t / 365) * 2 * Math.PI) * 8;
      // Random shock
      const z = gaussianRandom();
      const volComponent = (sigma + weatherVolatilityBonusPct / 100) * currentPrice * Math.sqrt(dt) * z;
      // Spike probability
      const spike = Math.random() < (spikeFrequency * dt) ? spikeIntensity * (0.8 + Math.random() * 0.4) : 0;

      currentPrice = Math.max(5, currentPrice + meanRev + seasonality + volComponent + spike);
      path.push(r2(currentPrice));
    }
    allPaths.push(path);
  }

  // Statistical Percentile calculation across days
  const npvDist: number[] = [];
  let lossCount = 0;

  for (let day = 0; day <= totalSteps; day++) {
    const dayPrices: number[] = [];
    for (let p = 0; p < numPaths; p++) {
      // Generate synthetic statistical point
      const z = gaussianRandom();
      const simPrice = Math.max(
        0,
        basePrice +
          (longTermMeanPrice - basePrice) * (1 - Math.exp(-meanReversionSpeed * (day / 365))) +
          sigma * basePrice * Math.sqrt((day + 1) / 365) * z +
          (Math.random() < spikeFrequency * dt ? spikeIntensity : 0)
      );
      dayPrices.push(simPrice);

      if (day === totalSteps) {
        const pnl = simPrice - strikePriceToTest;
        npvDist.push(pnl * 100); // per 100 MWh
        if (pnl < 0) lossCount++;
      }
    }

    dayPrices.sort((a, b) => a - b);
    percentilesPerDay.push({
      day,
      p1: r2(quantile(dayPrices, 0.01)),
      p5: r2(quantile(dayPrices, 0.05)),
      p10: r2(quantile(dayPrices, 0.10)),
      p50: r2(quantile(dayPrices, 0.50)),
      p90: r2(quantile(dayPrices, 0.90)),
      p95: r2(quantile(dayPrices, 0.95)),
      p99: r2(quantile(dayPrices, 0.99)),
      mean: r2(dayPrices.reduce((a, b) => a + b, 0) / dayPrices.length)
    });
  }

  npvDist.sort((a, b) => a - b);

  return {
    paths: allPaths,
    percentiles: percentilesPerDay,
    npvDistribution: npvDist.slice(0, 500),
    p1Npv: r2(quantile(npvDist, 0.01)),
    p5Npv: r2(quantile(npvDist, 0.05)),
    p10Npv: r2(quantile(npvDist, 0.10)),
    p50Npv: r2(quantile(npvDist, 0.50)),
    p90Npv: r2(quantile(npvDist, 0.90)),
    p95Npv: r2(quantile(npvDist, 0.95)),
    p99Npv: r2(quantile(npvDist, 0.99)),
    expectedProfitLoss: r2(npvDist.reduce((a, b) => a + b, 0) / npvDist.length),
    lossProbabilityPct: r2((lossCount / numPaths) * 100)
  };
}

function gaussianRandom(): number {
  let u = 0, v = 0;
  while (u === 0) u = Math.random();
  while (v === 0) v = Math.random();
  return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
}

function quantile(arr: number[], q: number): number {
  const pos = (arr.length - 1) * q;
  const base = Math.floor(pos);
  const rest = pos - base;
  if (arr[base + 1] !== undefined) {
    return arr[base] + rest * (arr[base + 1] - arr[base]);
  } else {
    return arr[base];
  }
}

// ==========================================
// 8. MULTI-OBJECTIVE STRIKE OPTIMISER SOLVER
// ==========================================

export function solveOptimalStrike(inputs: OptimiserInputs): OptimiserResult {
  const {
    assetCostPerMwh,
    expectedMarketPrice,
    targetIrrPct,
    targetNpvMillion,
    maxLossProbabilityPct,
    targetDscr
  } = inputs;

  const tradeOffFrontier = [];
  const minStrikeCandidate = assetCostPerMwh * 0.9;
  const maxStrikeCandidate = expectedMarketPrice * 1.35;
  const step = (maxStrikeCandidate - minStrikeCandidate) / 20;

  let optimalStrike = assetCostPerMwh * 1.15;
  let bestScore = Infinity;

  for (let s = minStrikeCandidate; s <= maxStrikeCandidate; s += step) {
    const margin = s - assetCostPerMwh;
    const irr = (margin / assetCostPerMwh) * 100 + 4;
    const npv = margin * 0.85; // Million
    const lossProb = Math.max(2, 35 - margin * 1.2);
    const dscr = Math.max(0.8, (margin + assetCostPerMwh * 0.3) / (assetCostPerMwh * 0.35));

    const feasible =
      irr >= targetIrrPct &&
      npv >= targetNpvMillion &&
      lossProb <= maxLossProbabilityPct &&
      dscr >= targetDscr;

    let score = 0;
    if (inputs.objective === 'MINIMISE_STRIKE') {
      score = s + (feasible ? 0 : 1000);
    } else if (inputs.objective === 'MAXIMISE_NPV') {
      score = -npv + (feasible ? 0 : 1000);
    } else if (inputs.objective === 'MAXIMISE_IRR') {
      score = -irr + (feasible ? 0 : 1000);
    } else {
      score = -npv / (lossProb + 1) + (feasible ? 0 : 1000);
    }

    if (score < bestScore) {
      bestScore = score;
      optimalStrike = s;
    }

    tradeOffFrontier.push({
      strike: r2(s),
      npv: r2(npv),
      irr: r2(irr),
      lossProb: r2(lossProb),
      dscr: r2(dscr),
      feasible
    });
  }

  const optMargin = optimalStrike - assetCostPerMwh;

  return {
    optimalStrike: r2(optimalStrike),
    achievedIrrPct: r2((optMargin / assetCostPerMwh) * 100 + 4),
    achievedNpvMillion: r2(optMargin * 0.85),
    achievedDownsideRiskPct: r2(Math.max(3, 20 - optMargin * 0.5)),
    achievedLossProbPct: r2(Math.max(2, 35 - optMargin * 1.2)),
    achievedDscr: r2(Math.max(0.8, (optMargin + assetCostPerMwh * 0.3) / (assetCostPerMwh * 0.35))),
    tradeOffFrontier
  };
}

// ==========================================
// 9. RISK ENGINE & STRESS TEST SUITE
// ==========================================

export function calculateRiskMetrics(currentSpot: number, volPct: number): RiskMetrics {
  const dailyVol = (volPct / 100) / Math.sqrt(365);
  const var95 = currentSpot * 1.645 * dailyVol;
  const var99 = currentSpot * 2.326 * dailyVol;
  const cvar95 = var95 * 1.25;
  const cvar99 = var99 * 1.30;

  return {
    var95: r2(var95),
    var99: r2(var99),
    cvar95: r2(cvar95),
    cvar99: r2(cvar99),
    expectedShortfall: r2(cvar95 * 1.12),
    basisRiskExposure: r2(currentSpot * 0.08),
    capturePriceRisk: r2(currentSpot * 0.14),
    volumeRiskPct: 18.5,
    weatherRiskSensitivity: 2.4
  };
}

export function evaluateStressScenarios(baseFairStrike: number): StressScenario[] {
  return [
    {
      id: 'S1',
      name: 'Power Price Collapse (-50%)',
      description: 'Severe demand recession & mild weather drop power price by 50%.',
      spotPriceDeltaPct: -50,
      gasPriceDeltaPct: -40,
      carbonPriceDeltaPct: -25,
      windGenerationDeltaPct: 0,
      solarGenerationDeltaPct: 0,
      curtailmentPct: 5,
      negativePriceFrequencyPct: 12,
      resultingFairStrike: r2(baseFairStrike * 0.55),
      resultingNpvChangePct: -68
    },
    {
      id: 'S2',
      name: 'Gas Supply Shock (+100%)',
      description: 'Geopolitical pipeline restriction doubles natural gas marginal cost.',
      spotPriceDeltaPct: 85,
      gasPriceDeltaPct: 100,
      carbonPriceDeltaPct: 15,
      windGenerationDeltaPct: 0,
      solarGenerationDeltaPct: 0,
      curtailmentPct: 2,
      negativePriceFrequencyPct: 1,
      resultingFairStrike: r2(baseFairStrike * 1.72),
      resultingNpvChangePct: 94
    },
    {
      id: 'S3',
      name: 'Dunkelflaute (Low Wind & Solar)',
      description: 'Two-week winter calm & dark period causing extreme price spikes.',
      spotPriceDeltaPct: 120,
      gasPriceDeltaPct: 35,
      carbonPriceDeltaPct: 10,
      windGenerationDeltaPct: -70,
      solarGenerationDeltaPct: -60,
      curtailmentPct: 0,
      negativePriceFrequencyPct: 0,
      resultingFairStrike: r2(baseFairStrike * 1.45),
      resultingNpvChangePct: -15
    },
    {
      id: 'S4',
      name: 'Negative Price Flood',
      description: 'Massive solar buildout causing 15% negative price hours in summer.',
      spotPriceDeltaPct: -20,
      gasPriceDeltaPct: -10,
      carbonPriceDeltaPct: 0,
      windGenerationDeltaPct: 10,
      solarGenerationDeltaPct: 25,
      curtailmentPct: 18,
      negativePriceFrequencyPct: 15,
      resultingFairStrike: r2(baseFairStrike * 0.78),
      resultingNpvChangePct: -42
    },
    {
      id: 'S5',
      name: 'Carbon Tax Surge (+100%)',
      description: 'Regulatory tightening doubles ETS carbon allowance prices to €150/t.',
      spotPriceDeltaPct: 40,
      gasPriceDeltaPct: 0,
      carbonPriceDeltaPct: 100,
      windGenerationDeltaPct: 0,
      solarGenerationDeltaPct: 0,
      curtailmentPct: 0,
      negativePriceFrequencyPct: 2,
      resultingFairStrike: r2(baseFairStrike * 1.32),
      resultingNpvChangePct: 48
    }
  ];
}

// ==========================================
// 10. 15-YEAR CASH FLOW GENERATOR
// ==========================================

export function generate15YearCashFlow(
  annualGenerationMwh: number,
  strikePrice: number,
  opexPerMwh: number,
  capexTotalMillions: number
): CashFlowYear[] {
  const schedule: CashFlowYear[] = [];
  let cumNpv = -capexTotalMillions;

  const debtAnnual = (capexTotalMillions * 1000000 * 0.75 * 0.09) / 1000000; // Debt service in Millions

  for (let yr = 1; yr <= 15; yr++) {
    const deg = Math.pow(0.995, yr - 1);
    const gen = (annualGenerationMwh * deg) / 1000000; // Millions MWh
    const marketRev = gen * strikePrice * 0.92;
    const strikeSettlement = gen * (strikePrice - strikePrice * 0.92);
    const totalRev = marketRev + strikeSettlement;
    const opex = gen * opexPerMwh;
    const ebitda = totalRev - opex;
    const debtService = debtAnnual;
    const fcf = ebitda - debtService;
    const dscr = debtService > 0 ? ebitda / debtService : 3.0;

    cumNpv += fcf / Math.pow(1.07, yr);

    schedule.push({
      year: yr,
      generationMwh: r2(gen * 1000000),
      marketRevenue: r2(marketRev),
      strikeSettlement: r2(strikeSettlement),
      totalRevenue: r2(totalRev),
      opex: r2(opex),
      ebitda: r2(ebitda),
      debtService: r2(debtService),
      freeCashFlow: r2(fcf),
      dscr: r2(dscr),
      cumNpv: r2(cumNpv)
    });
  }

  return schedule;
}
