/**
 * GridStrike Express API Server
 * Full-stack backend providing electricity strike price analytics, simulations, API docs & Code services.
 */

import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';

import {
  calculateStrikeDerivation,
  generateForwardCurve,
  calculatePpaStrike,
  calculateBatterySpread,
  calculateThermalStrike,
  priceElectricityOption,
  runMonteCarloSimulation,
  solveOptimalStrike,
  calculateRiskMetrics,
  evaluateStressScenarios,
} from './src/lib/strikeEngine.js';

import { INITIAL_MARKETS } from './src/lib/mockData.js';
import { RUST_CODE_FILES, R_CODE_FILES, SQL_SCHEMA_FILES } from './src/lib/rustAndRCode.js';

const app = express();
const PORT = 3000;

app.use(express.json());

// ==========================================
// API ROUTES
// ==========================================

// 1. Core Strike Price Derivation
app.post('/api/pricing/strike', (req: Request, res: Response) => {
  const { expectedMarketPrice, volatilityPct, opexPerMwh, captureFactor, debtServiceMwh, targetMarginPct } = req.body;
  
  const result = calculateStrikeDerivation(
    expectedMarketPrice || 92.4,
    volatilityPct || 0.34,
    opexPerMwh || 21.0,
    captureFactor || 0.91,
    debtServiceMwh || 24.5,
    targetMarginPct || 0.12
  );
  res.json(result);
});

// 2. Renewable PPA Strike
app.post('/api/pricing/ppa', (req: Request, res: Response) => {
  const ppaInputs = req.body.inputs || {
    assetType: 'WIND_OFFSHORE',
    capacityMw: 120,
    capexTotal: 180,
    opexPerMwh: 18.5,
    degradationAnnualPct: 0.5,
    contractDurationYears: 15,
    targetIrrPct: 8.5,
    debtRatioPct: 70,
    interestRatePct: 5.5,
    curtailmentPct: 2.5,
    imbalanceCostPerMwh: 3.2,
    captureFactor: 0.91,
    expectedCapacityFactorPct: 45.0
  };
  const marketPrice = req.body.expectedMarketPrice || 92.4;

  const result = calculatePpaStrike(ppaInputs, marketPrice);
  res.json(result);
});

// 3. Battery Arbitrage Spread & Strike
app.post('/api/pricing/battery', (req: Request, res: Response) => {
  const batteryInputs = req.body.inputs || {
    powerMw: 50,
    capacityMwh: 100,
    roundTripEfficiencyPct: 85,
    degradationPerCyclePct: 0.015,
    cyclingCostPerMwh: 12.0,
    marketFeesPerMwh: 2.5,
    expectedChargePrice: 55.0,
    maxCyclesPerDay: 1.5
  };

  const result = calculateBatterySpread(batteryInputs);
  res.json(result);
});

// 4. Thermal Generator SRMC/LRMC
app.post('/api/pricing/thermal', (req: Request, res: Response) => {
  const thermalInputs = req.body.inputs || {
    plantType: 'CCGT',
    heatRateGjPerMwh: 2.1,
    efficiencyPct: 58.0,
    fuelPriceGj: 28.5,
    carbonIntensityTonPerMwh: 0.38,
    carbonPriceTon: 76.5,
    variableOpexPerMwh: 4.5,
    startupCostPerMw: 18.0,
    fixedOpexPerKwYear: 28.0
  };
  const currentPrice = req.body.currentPowerPrice || 92.4;

  const result = calculateThermalStrike(thermalInputs, currentPrice);
  res.json(result);
});

// 5. Electricity Options Pricing
app.post('/api/pricing/option', (req: Request, res: Response) => {
  const optionInputs = req.body.inputs || {
    optionType: 'CALL',
    underlyingPrice: 92.4,
    strikePrice: 90.0,
    tenorMonths: 6,
    riskFreeRatePct: 4.5,
    historicalVolPct: 32,
    impliedVolPct: 34,
    jumpFrequencyPerYear: 2.5,
    jumpMeanPct: 35,
    jumpVolPct: 15,
    meanReversionSpeed: 3.5
  };

  const result = priceElectricityOption(optionInputs);
  res.json(result);
});

// 6. Monte Carlo Power Price Simulation
app.post('/api/simulation/monte-carlo', (req: Request, res: Response) => {
  const mcInputs = req.body.inputs || {
    numPaths: 1000,
    tenorDays: 30,
    basePrice: 92.4,
    meanReversionSpeed: 3.5,
    longTermMeanPrice: 88.0,
    volatilityPct: 34,
    spikeFrequency: 2.0,
    spikeIntensity: 45,
    weatherVolatilityBonusPct: 8.0,
    strikePriceToTest: 85.0
  };

  const result = runMonteCarloSimulation(mcInputs);
  res.json(result);
});

// 7. Multi-Objective Strike Optimisation
app.post('/api/optimisation/strike', (req: Request, res: Response) => {
  const optInputs = req.body.inputs || {
    assetCostPerMwh: 65.0,
    expectedMarketPrice: 92.4,
    volatilityPct: 34,
    targetIrrPct: 8.5,
    targetNpvMillion: 12.0,
    maxDownsidePct: 15,
    maxLossProbabilityPct: 12,
    targetDscr: 1.35,
    objective: 'MINIMISE_STRIKE'
  };

  const result = solveOptimalStrike(optInputs);
  res.json(result);
});

// 8. Markets & Forward Curves
app.get('/api/markets', (req: Request, res: Response) => {
  res.json(INITIAL_MARKETS);
});

app.get('/api/curves', (req: Request, res: Response) => {
  const market = (req.query.market as string) || 'GB_N2EX';
  const basePrice = INITIAL_MARKETS[market]?.currentSpot || 92.4;
  const curve = generateForwardCurve(market as any, basePrice);
  res.json(curve);
});

// 9. Risk & Stress Testing
app.get('/api/risk', (req: Request, res: Response) => {
  const spot = parseFloat(req.query.spot as string) || 92.4;
  const vol = parseFloat(req.query.vol as string) || 34;
  const metrics = calculateRiskMetrics(spot, vol);
  res.json(metrics);
});

app.post('/api/stress-test', (req: Request, res: Response) => {
  const fairStrike = req.body.baseFairStrike || 84.0;
  const scenarios = evaluateStressScenarios(fairStrike);
  res.json(scenarios);
});

// 10. Code & Schema Endpoints
app.get('/api/rust/code', (req: Request, res: Response) => {
  res.json(RUST_CODE_FILES);
});

app.get('/api/r/code', (req: Request, res: Response) => {
  res.json(R_CODE_FILES);
});

app.get('/api/sql/schema', (req: Request, res: Response) => {
  res.json(SQL_SCHEMA_FILES);
});

// 11. OpenAPI Specification
app.get('/api/openapi.json', (req: Request, res: Response) => {
  res.json({
    openapi: '3.0.0',
    info: {
      title: 'GridStrike Electricity Strike-Price Analytics API',
      version: '1.4.0',
      description: 'Production-grade API for electricity strike price calculation, PPA valuation, battery storage spread, option pricing, Monte Carlo simulation, and multi-objective optimisation.'
    },
    paths: {
      '/api/pricing/strike': {
        post: {
          summary: 'Calculate comprehensive strike prices (Break-even, Fair Value, Risk-Adjusted)',
          responses: { '200': { description: 'Derivation breakdown and calculated strike values' } }
        }
      },
      '/api/pricing/ppa': {
        post: {
          summary: 'Calculate renewable energy PPA strike price & capture factor',
          responses: { '200': { description: 'PPA strike prices and LCOE' } }
        }
      },
      '/api/pricing/battery': {
        post: {
          summary: 'Calculate battery energy storage system arbitrage spread & required discharge strike',
          responses: { '200': { description: 'Minimum discharge price & required spread' } }
        }
      },
      '/api/simulation/monte-carlo': {
        post: {
          summary: 'Run stochastic Monte Carlo power price simulation with percentile fan chart',
          responses: { '200': { description: 'Percentile paths P1..P99 and profit distribution' } }
        }
      },
      '/api/optimisation/strike': {
        post: {
          summary: 'Solve for multi-objective optimal strike price subject to IRR, NPV, DSCR',
          responses: { '200': { description: 'Optimal strike price and feasibility frontier' } }
        }
      }
    }
  });
});

// ==========================================
// VITE / STATIC SERVING PIPELINE
// ==========================================

async function start() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`GridStrike server running at http://localhost:${PORT}`);
  });
}

start();
