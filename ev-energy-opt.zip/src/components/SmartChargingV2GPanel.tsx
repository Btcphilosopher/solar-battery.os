/**
 * EV-ENERGY-OPT Smart Charging & Vehicle-to-Grid (V2G) Panel
 * Explores smart charging schedules, strike prices, V2G arbitrage, and solar home balance.
 */

import React, { useState } from 'react';
import { SimulationState } from '../types';
import { Zap, DollarSign, Sun, ArrowRight, ShieldCheck, Clock, Award, CheckCircle } from 'lucide-react';

interface SmartChargingV2GPanelProps {
  state: SimulationState;
}

export const SmartChargingV2GPanel: React.FC<SmartChargingV2GPanelProps> = ({ state }) => {
  const market = state.marketState;
  const chem = state.chemistry;

  // Option A vs Option B Economic Trade-off (Prompt Section 6)
  const optionAEnergyCost = 4.20;
  const optionADegradation = 0.90;
  const optionATotal = optionAEnergyCost + optionADegradation;

  const optionBEnergyCost = 3.10;
  const optionBDegradation = 0.65;
  const optionBTotal = optionBEnergyCost + optionBDegradation;

  return (
    <div className="space-y-6">
      {/* 1. Prompt Example Trade-Off Banner */}
      <div className="bg-[#111113] border border-[#1F2937] rounded-md p-5 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#1F2937]">
          <div>
            <h2 className="text-base font-semibold tracking-tighter text-[#E0E0E6] flex items-center gap-2">
              <Clock className="w-5 h-5 text-cyan-400" />
              SMART CHARGING & ECONOMIC DEGRADATION TRADE-OFF
            </h2>
            <p className="text-[10px] uppercase tracking-wider text-slate-400 font-mono mt-0.5">
              Co-optimizing electricity spot prices against battery electrochemical degradation cost
            </p>
          </div>
          <div className="text-xs font-mono bg-cyan-950/40 text-cyan-400 border border-cyan-800/60 px-3 py-1 rounded-sm font-bold">
            RECOMMENDATION: DELAY CHARGING TO 03:10
          </div>
        </div>

        {/* Option A vs Option B Comparison Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Option A: Immediate Charge */}
          <div className="bg-[#0A0A0B] border border-rose-900/40 rounded-sm p-4 space-y-3 relative">
            <div className="flex justify-between items-center border-b border-[#1F2937] pb-2">
              <span className="text-xs font-bold font-mono text-rose-400">OPTION A: IMMEDIATE CHARGE</span>
              <span className="text-[10px] font-mono text-slate-400">NOW (18:30)</span>
            </div>
            <div className="space-y-1.5 font-mono text-xs">
              <div className="flex justify-between text-slate-300">
                <span>Electricity Cost (Peak £0.31/kWh):</span>
                <span className="font-bold text-slate-100">£{optionAEnergyCost.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Battery Degradation Cost:</span>
                <span className="font-bold text-rose-400">+£{optionADegradation.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-100 font-bold border-t border-[#1F2937] pt-2 text-sm">
                <span>TOTAL COST:</span>
                <span className="text-rose-400">£{optionATotal.toFixed(2)}</span>
              </div>
            </div>
            <div className="text-[11px] text-rose-300 bg-rose-950/30 p-2 rounded-sm border border-rose-900/30">
              ❌ Unmanaged peak charging creates high thermal stress and costly electricity.
            </div>
          </div>

          {/* Option B: Delayed Smart Charge */}
          <div className="bg-[#0A0A0B] border border-cyan-500/50 rounded-sm p-4 space-y-3 relative shadow-[0_0_20px_rgba(34,211,238,0.08)]">
            <div className="flex justify-between items-center border-b border-[#1F2937] pb-2">
              <span className="text-xs font-bold font-mono text-cyan-400 flex items-center gap-1.5">
                <CheckCircle className="w-4 h-4 text-cyan-400" /> OPTION B: DELAYED SMART CHARGE
              </span>
              <span className="text-[10px] font-mono text-cyan-300 font-bold">OPTIMAL (03:10)</span>
            </div>
            <div className="space-y-1.5 font-mono text-xs">
              <div className="flex justify-between text-slate-300">
                <span>Electricity Cost (Off-Peak £0.14/kWh):</span>
                <span className="font-bold text-slate-100">£{optionBEnergyCost.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Battery Degradation Cost:</span>
                <span className="font-bold text-cyan-400">+£{optionBDegradation.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-100 font-bold border-t border-[#1F2937] pt-2 text-sm">
                <span>TOTAL COST:</span>
                <span className="text-cyan-400">£{optionBTotal.toFixed(2)} (SAVINGS £1.35)</span>
              </div>
            </div>
            <div className="text-[11px] text-cyan-300 bg-cyan-950/30 p-2 rounded-sm border border-cyan-800/40">
              ✅ Saves £1.35 (26% net reduction) while guaranteeing required 82% SOC by 07:30 departure.
            </div>
          </div>
        </div>
      </div>

      {/* 2. Strike Price Trigger Matrix (Prompt Section 14) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Charge Strike Price Card */}
        <div className="bg-[#111113] border border-[#1F2937] rounded-md p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-[#1F2937]">
            <h3 className="text-sm font-semibold text-[#E0E0E6] font-mono flex items-center gap-2">
              <Zap className="w-4 h-4 text-emerald-400" />
              CHARGE STRIKE PRICE THRESHOLD
            </h3>
            <span className="text-xs font-mono font-bold text-emerald-300">
              STRIKE: £{market.chargeStrikePrice.toFixed(2)}/kWh
            </span>
          </div>

          <div className="space-y-3 font-mono text-xs">
            <div className="p-3 bg-[#0A0A0B] border border-[#1F2937] rounded-sm space-y-1.5">
              <div className="flex justify-between">
                <span className="text-slate-400">Current Grid Spot Price:</span>
                <span className="text-slate-100 font-bold">£{market.spotPriceGbpKWh.toFixed(2)}/kWh</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Charge Strike Target:</span>
                <span className="text-emerald-400 font-bold">£{market.chargeStrikePrice.toFixed(2)}/kWh</span>
              </div>
              <div className="flex justify-between pt-1 border-t border-[#1F2937] text-slate-300">
                <span>Action Trigger:</span>
                <span className={market.spotPriceGbpKWh <= market.chargeStrikePrice ? 'text-emerald-400 font-bold' : 'text-amber-400 font-bold'}>
                  {market.spotPriceGbpKWh <= market.chargeStrikePrice ? '⚡ CHARGE EV NOW' : '⏳ WAIT FOR LOWER PRICE'}
                </span>
              </div>
            </div>
            <p className="text-[11px] text-slate-400">
              Charging is automatically executed whenever the spot market drops below the calculated charge strike price.
            </p>
          </div>
        </div>

        {/* Discharge Strike Price Card */}
        <div className="bg-[#111113] border border-[#1F2937] rounded-md p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-[#1F2937]">
            <h3 className="text-sm font-semibold text-[#E0E0E6] font-mono flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-purple-400" />
              DISCHARGE STRIKE PRICE (V2G / V2H)
            </h3>
            <span className="text-xs font-mono font-bold text-purple-300">
              STRIKE: £{market.dischargeStrikePrice.toFixed(2)}/kWh
            </span>
          </div>

          <div className="space-y-3 font-mono text-xs">
            <div className="p-3 bg-[#0A0A0B] border border-[#1F2937] rounded-sm space-y-1.5">
              <div className="flex justify-between">
                <span className="text-slate-400">Battery Discharge Cost:</span>
                <span className="text-slate-100 font-bold">£0.21/kWh</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Required V2G Discharge Strike:</span>
                <span className="text-purple-400 font-bold">£{market.dischargeStrikePrice.toFixed(2)}/kWh</span>
              </div>
              <div className="flex justify-between pt-1 border-t border-[#1F2937] text-slate-300">
                <span>V2G Action Trigger:</span>
                <span className={market.spotPriceGbpKWh >= market.dischargeStrikePrice ? 'text-purple-400 font-bold' : 'text-slate-400'}>
                  {market.spotPriceGbpKWh >= market.dischargeStrikePrice ? '💎 DISCHARGE V2G EXPORT' : 'HOLD V2G DISCHARGE'}
                </span>
              </div>
            </div>
            <p className="text-[11px] text-slate-400">
              V2G export is restricted unless grid spot price guarantees full recovery of battery degradation and conversion losses.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
