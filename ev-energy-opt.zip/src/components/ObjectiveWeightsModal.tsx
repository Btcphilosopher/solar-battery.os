/**
 * EV-ENERGY-OPT Configurable Multi-Objective Function Modal
 * Tunes weights α, β, γ, δ, ε (Prompt Section 16).
 */

import React from 'react';
import { ObjectiveCoefficients } from '../types';
import { Settings, X, Check, Sliders } from 'lucide-react';

interface ObjectiveWeightsModalProps {
  weights: ObjectiveCoefficients;
  onSave: (weights: ObjectiveCoefficients) => void;
  onClose: () => void;
}

export const ObjectiveWeightsModal: React.FC<ObjectiveWeightsModalProps> = ({
  weights,
  onSave,
  onClose,
}) => {
  const [local, setLocal] = React.useState<ObjectiveCoefficients>(weights);

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#111113] border border-[#1F2937] rounded-md max-w-lg w-full p-6 shadow-2xl space-y-5">
        <div className="flex items-center justify-between pb-3 border-b border-[#1F2937]">
          <div className="flex items-center gap-2 text-[#E0E0E6] font-bold font-mono text-xs tracking-wider uppercase">
            <Sliders className="w-4 h-4 text-cyan-400" />
            CONFIGURABLE OBJECTIVE FUNCTION WEIGHTS
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-200">
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-[11px] text-slate-400 font-mono">
          TOTAL OBJECTIVE = α·Cost + β·Degradation + γ·Thermal + δ·Grid - ε·V2G Revenue
        </p>

        <div className="space-y-3 font-mono text-xs">
          {/* α: Energy Cost */}
          <div className="space-y-1 bg-[#0A0A0B] p-3 rounded-sm border border-[#1F2937]">
            <div className="flex justify-between">
              <span className="text-slate-300">α (Energy Cost Weight):</span>
              <span className="text-cyan-400 font-bold">{local.alphaEnergyCost.toFixed(2)}</span>
            </div>
            <input
              type="range"
              min="0.0"
              max="2.0"
              step="0.05"
              value={local.alphaEnergyCost}
              onChange={(e) => setLocal({ ...local, alphaEnergyCost: Number(e.target.value) })}
              className="w-full accent-cyan-400 cursor-pointer"
            />
          </div>

          {/* β: Degradation Cost */}
          <div className="space-y-1 bg-[#0A0A0B] p-3 rounded-sm border border-[#1F2937]">
            <div className="flex justify-between">
              <span className="text-slate-300">β (Battery Degradation Weight):</span>
              <span className="text-rose-400 font-bold">{local.betaDegradation.toFixed(2)}</span>
            </div>
            <input
              type="range"
              min="0.0"
              max="3.0"
              step="0.1"
              value={local.betaDegradation}
              onChange={(e) => setLocal({ ...local, betaDegradation: Number(e.target.value) })}
              className="w-full accent-rose-400 cursor-pointer"
            />
          </div>

          {/* γ: Thermal Cost */}
          <div className="space-y-1 bg-[#0A0A0B] p-3 rounded-sm border border-[#1F2937]">
            <div className="flex justify-between">
              <span className="text-slate-300">γ (Thermal HVAC Weight):</span>
              <span className="text-amber-400 font-bold">{local.gammaThermal.toFixed(2)}</span>
            </div>
            <input
              type="range"
              min="0.0"
              max="2.0"
              step="0.1"
              value={local.gammaThermal}
              onChange={(e) => setLocal({ ...local, gammaThermal: Number(e.target.value) })}
              className="w-full accent-amber-400 cursor-pointer"
            />
          </div>

          {/* δ: Grid Stress */}
          <div className="space-y-1 bg-[#0A0A0B] p-3 rounded-sm border border-[#1F2937]">
            <div className="flex justify-between">
              <span className="text-slate-300">δ (Grid Congestion Penalty):</span>
              <span className="text-blue-400 font-bold">{local.deltaGridStress.toFixed(2)}</span>
            </div>
            <input
              type="range"
              min="0.0"
              max="2.0"
              step="0.1"
              value={local.deltaGridStress}
              onChange={(e) => setLocal({ ...local, deltaGridStress: Number(e.target.value) })}
              className="w-full accent-blue-400 cursor-pointer"
            />
          </div>

          {/* ε: V2G Market Revenue */}
          <div className="space-y-1 bg-[#0A0A0B] p-3 rounded-sm border border-[#1F2937]">
            <div className="flex justify-between">
              <span className="text-slate-300">ε (V2G Arbitrage Revenue Weight):</span>
              <span className="text-purple-400 font-bold">{local.epsilonV2GRevenue.toFixed(2)}</span>
            </div>
            <input
              type="range"
              min="0.0"
              max="2.0"
              step="0.1"
              value={local.epsilonV2GRevenue}
              onChange={(e) => setLocal({ ...local, epsilonV2GRevenue: Number(e.target.value) })}
              className="w-full accent-purple-400 cursor-pointer"
            />
          </div>
        </div>

        <div className="flex items-center justify-end gap-3 pt-3 border-t border-[#1F2937]">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-mono text-slate-400 hover:text-slate-200"
          >
            Cancel
          </button>
          <button
            onClick={() => {
              onSave(local);
              onClose();
            }}
            className="px-4 py-2 bg-cyan-500 hover:bg-cyan-400 text-black text-xs font-mono font-bold rounded-sm flex items-center gap-1.5 transition"
          >
            <Check className="w-4 h-4" /> Save Weights
          </button>
        </div>
      </div>
    </div>
  );
};
