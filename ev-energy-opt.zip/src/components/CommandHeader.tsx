/**
 * EV-ENERGY-OPT Top Command-Centre Telemetry Bar
 * Matches the specification in Prompt Section 26.
 */

import React from 'react';
import { SimulationState } from '../types';
import { Battery, Zap, Sun, Thermometer, ShieldCheck, DollarSign, Play, Pause, FastForward, RotateCcw, Settings } from 'lucide-react';

interface CommandHeaderProps {
  state: SimulationState;
  onTogglePlay: () => void;
  onSetSpeed: (speed: number) => void;
  onReset: () => void;
  onOpenWeightsModal: () => void;
}

export const CommandHeader: React.FC<CommandHeaderProps> = ({
  state,
  onTogglePlay,
  onSetSpeed,
  onReset,
  onOpenWeightsModal,
}) => {
  const latestDispatch = state.dispatchHistory[state.dispatchHistory.length - 1];
  const batteryPower = latestDispatch ? latestDispatch.batteryPowerKW : 0;
  const gridPower = latestDispatch ? latestDispatch.gridPowerKW : 0;
  const solarPower = latestDispatch ? latestDispatch.solarPowerKW : 0;
  const temp = latestDispatch ? latestDispatch.packTempC : state.currentTempC;
  const rec = latestDispatch ? latestDispatch.recommendationReason : 'Initializing Optimization Loop...';

  const formatMinToTime = (mins: number) => {
    const h = Math.floor(mins / 60) % 24;
    const m = Math.floor(mins % 60);
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
  };

  return (
    <header className="bg-[#111113] border-b border-[#1F2937] text-[#E0E0E6] px-4 py-3 shadow-lg">
      <div className="max-w-7xl mx-auto flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3">
        {/* Logo & Clock Controls */}
        <div className="flex items-center justify-between lg:justify-start gap-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-cyan-500 rounded-sm flex items-center justify-center font-bold text-black text-base shadow-[0_0_15px_rgba(34,211,238,0.2)]">
              Ω
            </div>
            <div>
              <h1 className="text-base font-semibold tracking-tighter text-[#E0E0E6] flex items-center gap-2">
                EV-ENERGY-OPT
                <span className="text-[10px] uppercase font-mono text-cyan-400 bg-cyan-950/40 border border-cyan-800/60 px-1.5 py-0.5 rounded-sm">
                  Production v2.4.1
                </span>
              </h1>
              <div className="flex items-center gap-2 text-[10px] uppercase font-mono text-slate-400">
                <span>SIM TIME:</span> <span className="text-cyan-400 font-bold">{formatMinToTime(state.currentTimeMinutes)}</span>
              </div>
            </div>
          </div>

          {/* Simulation Playback Controls */}
          <div className="flex items-center bg-[#0A0A0B] border border-[#1F2937] rounded-sm p-1 gap-1">
            <button
              onClick={onTogglePlay}
              className={`p-1.5 rounded-sm text-xs font-semibold flex items-center gap-1 transition ${
                state.isLiveRunning
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 hover:bg-cyan-500/30'
                  : 'bg-cyan-500 text-black font-bold hover:bg-cyan-400'
              }`}
              title={state.isLiveRunning ? 'Pause Engine' : 'Start Real-Time Engine'}
            >
              {state.isLiveRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              <span>{state.isLiveRunning ? 'PAUSE' : 'RUN'}</span>
            </button>

            <div className="flex items-center border-l border-[#1F2937] pl-1 gap-0.5">
              {[1, 10, 60].map((s) => (
                <button
                  key={s}
                  onClick={() => onSetSpeed(s)}
                  className={`px-1.5 py-1 text-[11px] font-mono rounded-sm ${
                    state.playbackSpeed === s
                      ? 'bg-[#1F2937] text-cyan-400 font-bold border border-cyan-500/40'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {s}x
                </button>
              ))}
            </div>

            <button
              onClick={onReset}
              className="p-1.5 text-slate-400 hover:text-rose-400 transition border-l border-[#1F2937] pl-1"
              title="Reset Simulation Scenario"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Live Telemetry Ticker Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2 font-mono text-xs">
          {/* SOC */}
          <div className="bg-[#0A0A0B] border border-[#1F2937] rounded-sm px-2 py-1 flex flex-col justify-center">
            <span className="text-[10px] uppercase opacity-40 flex items-center gap-1">
              <Battery className="w-3 h-3 text-emerald-400" /> SOC
            </span>
            <span className="text-sm font-bold text-emerald-400">{state.currentSocPct.toFixed(1)}%</span>
          </div>

          {/* SOH */}
          <div className="bg-[#0A0A0B] border border-[#1F2937] rounded-sm px-2 py-1 flex flex-col justify-center">
            <span className="text-[10px] uppercase opacity-40 flex items-center gap-1">
              <ShieldCheck className="w-3 h-3 text-cyan-400" /> SOH
            </span>
            <span className="text-sm font-bold text-cyan-400">{state.currentSohPct.toFixed(2)}%</span>
          </div>

          {/* BATTERY POWER */}
          <div className="bg-[#0A0A0B] border border-[#1F2937] rounded-sm px-2 py-1 flex flex-col justify-center">
            <span className="text-[10px] uppercase opacity-40 flex items-center gap-1">
              <Zap className="w-3 h-3 text-amber-400" /> BATTERY
            </span>
            <span className={`text-sm font-bold ${batteryPower >= 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
              {batteryPower >= 0 ? `+${batteryPower.toFixed(1)} kW` : `${batteryPower.toFixed(1)} kW`}
            </span>
          </div>

          {/* GRID POWER */}
          <div className="bg-[#0A0A0B] border border-[#1F2937] rounded-sm px-2 py-1 flex flex-col justify-center">
            <span className="text-[10px] uppercase opacity-40 flex items-center gap-1">
              <Zap className="w-3 h-3 text-blue-400" /> GRID
            </span>
            <span className={`text-sm font-bold ${gridPower >= 0 ? 'text-blue-400' : 'text-purple-400'}`}>
              {gridPower >= 0 ? `+${gridPower.toFixed(1)} kW` : `${gridPower.toFixed(1)} kW`}
            </span>
          </div>

          {/* SOLAR POWER */}
          <div className="bg-[#0A0A0B] border border-[#1F2937] rounded-sm px-2 py-1 flex flex-col justify-center">
            <span className="text-[10px] uppercase opacity-40 flex items-center gap-1">
              <Sun className="w-3 h-3 text-yellow-400" /> SOLAR
            </span>
            <span className="text-sm font-bold text-yellow-300">+{solarPower.toFixed(1)} kW</span>
          </div>

          {/* TEMP */}
          <div className="bg-[#0A0A0B] border border-[#1F2937] rounded-sm px-2 py-1 flex flex-col justify-center">
            <span className="text-[10px] uppercase opacity-40 flex items-center gap-1">
              <Thermometer className="w-3 h-3 text-rose-400" /> PACK TEMP
            </span>
            <span className="text-sm font-bold text-rose-300">{temp.toFixed(1)}°C</span>
          </div>

          {/* TODAY COST */}
          <div className="bg-[#0A0A0B] border border-[#1F2937] rounded-sm px-2 py-1 flex flex-col justify-center">
            <span className="text-[10px] uppercase opacity-40 flex items-center gap-1">
              <DollarSign className="w-3 h-3 text-emerald-400" /> NET COST
            </span>
            <span className="text-sm font-bold text-emerald-300">£{state.totalEnergyCostGbp.toFixed(2)}</span>
          </div>

          {/* V2G VALUE */}
          <div className="bg-[#0A0A0B] border border-[#1F2937] rounded-sm px-2 py-1 flex flex-col justify-center">
            <span className="text-[10px] uppercase opacity-40 flex items-center gap-1">
              <DollarSign className="w-3 h-3 text-purple-400" /> V2G REV
            </span>
            <span className="text-sm font-bold text-purple-300">£{state.totalV2GRevenueGbp.toFixed(2)}</span>
          </div>
        </div>

        {/* Objective Function & Recommendation */}
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenWeightsModal}
            className="px-2.5 py-1.5 bg-[#0A0A0B] hover:bg-[#1F2937] text-slate-300 rounded-sm border border-[#1F2937] text-xs flex items-center gap-1.5 transition"
            title="Configure Multi-Objective Weights (α, β, γ, δ, ε)"
          >
            <Settings className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline font-mono text-[11px] text-cyan-400">OBJECTIVE WTS</span>
          </button>
        </div>
      </div>

      {/* Recommendation Banner */}
      <div className="max-w-7xl mx-auto mt-2 bg-[#0A0A0B] border border-[#1F2937] rounded-sm px-4 py-2 flex flex-wrap items-center justify-between text-xs font-mono">
        <div className="flex items-center gap-2 text-slate-300">
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></span>
          <span className="text-cyan-400 font-bold uppercase tracking-wider text-[10px] opacity-70">OPTIMIZATION RECOMMENDATION:</span>
          <span className="text-[#E0E0E6] font-normal text-xs">{rec}</span>
        </div>
        <div className="text-[11px] text-slate-400 flex items-center gap-4">
          <span>SPOT: <strong className="text-cyan-400">£{state.marketState.spotPriceGbpKWh.toFixed(2)}/kWh</strong></span>
          <span>EST. DEG: <strong className="text-rose-300">£{state.totalDegradationCostGbp.toFixed(2)}</strong></span>
          <span>EFFICIENCY: <strong className="text-emerald-400">94.8%</strong></span>
        </div>
      </div>
    </header>
  );
};
