/**
 * EV-ENERGY-OPT Production Codebase & Architecture Explorer
 * Allows interactive inspection of Rust production engine modules and R scientific research scripts.
 */

import React, { useState } from 'react';
import { CODEBASE_FILES } from '../data/codebaseTree';
import { CodeFileNode } from '../types';
import { Folder, FileCode, Terminal, ShieldAlert, Cpu, CheckCircle2, Copy } from 'lucide-react';

export const CodebaseExplorer: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<CodeFileNode>(CODEBASE_FILES[0]);
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const layers = [
    { id: 'rust-core', label: 'Rust Engine Core' },
    { id: 'rust-battery', label: 'Rust Electrochemical Battery' },
    { id: 'rust-vehicle', label: 'Rust Vehicle Dynamics' },
    { id: 'rust-market', label: 'Rust Energy Market' },
    { id: 'rust-charging', label: 'Rust Charging & V2G' },
    { id: 'r-models', label: 'R Battery Models' },
    { id: 'r-analysis', label: 'R Monte Carlo Analysis' },
    { id: 'r-scenarios', label: 'R Scenario Validation' },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#111113] border border-[#1F2937] rounded-md p-5 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#1F2937]">
          <div>
            <h2 className="text-base font-semibold tracking-tighter text-[#E0E0E6] flex items-center gap-2">
              <Terminal className="w-5 h-5 text-cyan-400" />
              RUST PRODUCTION ENGINE & R RESEARCH CODEBASE ARCHITECTURE
            </h2>
            <p className="text-[10px] uppercase tracking-wider text-slate-400 font-mono mt-0.5">
              Strict separation between high-performance Rust execution engine and R quantitative research layer
            </p>
          </div>
          <div className="flex items-center gap-2 font-mono text-xs">
            <span className="bg-cyan-950/40 text-cyan-400 border border-cyan-800/60 px-2.5 py-1 rounded-sm font-bold">
              RUST CORE (SIMD/COMPUTE)
            </span>
            <span className="bg-blue-950/40 text-blue-300 border border-blue-800/60 px-2.5 py-1 rounded-sm font-bold">
              R STATISTICAL LAYER
            </span>
          </div>
        </div>

        {/* Code Explorer Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 mt-4">
          {/* File Tree Directory (4 Cols) */}
          <div className="lg:col-span-4 bg-[#0A0A0B] border border-[#1F2937] rounded-sm p-3 space-y-3 font-mono text-xs max-h-[500px] overflow-y-auto">
            <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5 pb-2 border-b border-[#1F2937]">
              <Folder className="w-3.5 h-3.5 text-cyan-400" /> ev_energy_opt/
            </div>

            <div className="space-y-3">
              {layers.map((layer) => {
                const layerFiles = CODEBASE_FILES.filter((f) => f.layer === layer.id);
                if (layerFiles.length === 0) return null;

                return (
                  <div key={layer.id} className="space-y-1">
                    <div className="text-[10px] text-slate-500 font-bold uppercase tracking-wider px-1">
                      {layer.label}
                    </div>
                    {layerFiles.map((file) => {
                      const isSelected = selectedFile.path === file.path;
                      return (
                        <div
                          key={file.path}
                          onClick={() => setSelectedFile(file)}
                          className={`flex items-center gap-2 px-2 py-1.5 rounded-sm cursor-pointer transition ${
                            isSelected
                              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold'
                              : 'text-slate-400 hover:text-slate-200 hover:bg-[#111113]'
                          }`}
                        >
                          <FileCode className={`w-3.5 h-3.5 ${file.language === 'rust' ? 'text-amber-400' : 'text-blue-400'}`} />
                          <span className="truncate">{file.path}</span>
                        </div>
                      );
                    })}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Code Viewer (8 Cols) */}
          <div className="lg:col-span-8 bg-[#0A0A0B] border border-[#1F2937] rounded-sm p-4 space-y-3 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center justify-between border-b border-[#1F2937] pb-2">
                <div>
                  <h3 className="text-xs font-bold font-mono text-slate-100 flex items-center gap-2">
                    <FileCode className={`w-4 h-4 ${selectedFile.language === 'rust' ? 'text-amber-400' : 'text-blue-400'}`} />
                    {selectedFile.path}
                  </h3>
                  <p className="text-[11px] text-slate-400 mt-0.5 font-mono">
                    {selectedFile.description}
                  </p>
                </div>

                <button
                  onClick={handleCopy}
                  className="px-2.5 py-1 bg-[#111113] hover:bg-[#1F2937] border border-[#1F2937] text-slate-300 text-xs font-mono rounded-sm flex items-center gap-1.5 transition"
                >
                  {copied ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'COPIED' : 'COPY'}</span>
                </button>
              </div>

              {/* Source Code Renderer */}
              <div className="bg-[#111113] border border-[#1F2937] rounded-sm p-3 font-mono text-xs text-slate-300 overflow-x-auto max-h-[380px] leading-relaxed">
                <pre>{selectedFile.code}</pre>
              </div>
            </div>

            {/* Units & Safety Check Bar */}
            <div className="pt-2 border-t border-[#1F2937] flex flex-wrap items-center justify-between text-[11px] font-mono text-slate-400">
              <div className="flex items-center gap-2">
                <ShieldAlert className="w-3.5 h-3.5 text-emerald-400" />
                <span>SAFETY ENVELOPE: <strong className="text-emerald-300">HARD BMS LIMITS ENFORCED</strong></span>
              </div>
              <div className="flex items-center gap-3">
                <span>UNITS: <strong className="text-cyan-400">V, A, kW, kWh, °C, £/kWh</strong></span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
