/**
 * EV-ENERGY-OPT Battery Electrochemistry & Thermal Optimization Panel
 * Explores LFP vs NMC chemistries, OCV curves, Arrhenius thermal aging, and degradation economics.
 */

import React from 'react';
import { BatteryChemistry, SimulationState } from '../types';
import { PRESET_CHEMISTRIES, calculateOCV, calculateInternalResistance } from '../physics/batteryEngine';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';
import { Battery, Thermometer, ShieldCheck, Flame, Cpu, ArrowRight } from 'lucide-react';

interface BatteryThermalPanelProps {
  state: SimulationState;
  onSelectChemistry: (chem: BatteryChemistry) => void;
}

export const BatteryThermalPanel: React.FC<BatteryThermalPanelProps> = ({ state, onSelectChemistry }) => {
  const currentChem = state.chemistry;

  // Generate OCV curve data points (0% to 100% SOC)
  const ocvCurveData = [];
  for (let soc = 1; soc <= 100; soc += 2) {
    const ocvNmc = calculateOCV(soc, PRESET_CHEMISTRIES.NMC);
    const ocvLfp = calculateOCV(soc, PRESET_CHEMISTRIES.LFP);
    const rIntNmc = calculateInternalResistance(soc, 25, PRESET_CHEMISTRIES.NMC) * 1000; // mΩ
    const rIntLfp = calculateInternalResistance(soc, 25, PRESET_CHEMISTRIES.LFP) * 1000; // mΩ

    ocvCurveData.push({
      soc,
      ocvNmc: Number(ocvNmc.toFixed(1)),
      ocvLfp: Number(ocvLfp.toFixed(1)),
      rIntNmc: Number(rIntNmc.toFixed(1)),
      rIntLfp: Number(rIntLfp.toFixed(1)),
    });
  }

  return (
    <div className="space-y-6">
      {/* Chemistry Selector Banner */}
      <div className="bg-[#111113] border border-[#1F2937] rounded-md p-5 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#1F2937]">
          <div>
            <h2 className="text-base font-semibold tracking-tighter text-[#E0E0E6] flex items-center gap-2">
              <Battery className="w-5 h-5 text-cyan-400" />
              ELECTROCHEMICAL CELL & PACK ARCHITECTURE
            </h2>
            <p className="text-[10px] uppercase tracking-wider text-slate-400 font-mono mt-0.5">
              Configurable cell chemistries with temperature-dependent internal resistance & degradation modeling
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-slate-400">ACTIVE CHEMISTRY:</span>
            <span className="text-xs font-mono font-bold px-2.5 py-1 rounded-sm bg-cyan-950/40 text-cyan-400 border border-cyan-800/60">
              {currentChem.name}
            </span>
          </div>
        </div>

        {/* Chemistry Selection Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {Object.values(PRESET_CHEMISTRIES).map((chem) => {
            const isSelected = chem.type === currentChem.type;
            return (
              <div
                key={chem.type}
                onClick={() => onSelectChemistry(chem)}
                className={`p-4 rounded-sm border cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-[#1F2937] border-cyan-500 shadow-[0_0_15px_rgba(34,211,238,0.1)]'
                    : 'bg-[#0A0A0B] border-[#1F2937] hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                    {chem.type === 'NMC' ? '🔋 NMC-811 (Nickel Manganese Cobalt)' : '🔋 LFP (Lithium Iron Phosphate)'}
                  </h3>
                  {isSelected && (
                    <span className="text-[10px] uppercase font-mono bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 px-2 py-0.5 rounded-sm font-bold">
                      ACTIVE
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-400 mb-3">
                  {chem.type === 'NMC'
                    ? 'High energy density (75 kWh), higher sensitivity to thermal degradation & high C-rate charging near 100% SOC.'
                    : 'Ultra-high cycle durability (5,500 cycles), flat voltage plateau, excellent thermal safety envelope & lower degradation penalty.'}
                </p>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
                  <div className="bg-[#0A0A0B] p-2 rounded-sm border border-[#1F2937]">
                    <span className="text-[10px] text-slate-500">NOMINAL V</span>
                    <div className="font-bold text-slate-200">{chem.nominalVoltage} V</div>
                  </div>
                  <div className="bg-[#0A0A0B] p-2 rounded-sm border border-[#1F2937]">
                    <span className="text-[10px] text-slate-500">CYCLE LIFE (80%)</span>
                    <div className="font-bold text-cyan-400">{chem.cycleLife80DOD} cycles</div>
                  </div>
                  <div className="bg-[#0A0A0B] p-2 rounded-sm border border-[#1F2937]">
                    <span className="text-[10px] text-slate-500">MAX FAST CHARGE</span>
                    <div className="font-bold text-amber-400">{chem.maxChargeCRate} C</div>
                  </div>
                  <div className="bg-[#0A0A0B] p-2 rounded-sm border border-[#1F2937]">
                    <span className="text-[10px] text-slate-500">DEG COST / %SOH</span>
                    <div className="font-bold text-rose-300">£{chem.degradationCostPerPctSoh}</div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* OCV & Internal Resistance Curves Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Open Circuit Voltage Curve */}
        <div className="bg-[#111113] border border-[#1F2937] rounded-md p-5 shadow-xl space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-[#1F2937]">
            <h3 className="text-sm font-semibold text-[#E0E0E6] font-mono flex items-center gap-2">
              <Cpu className="w-4 h-4 text-cyan-400" />
              OPEN CIRCUIT VOLTAGE (OCV) VS SOC
            </h3>
            <span className="text-xs text-slate-400 font-mono">PACK VOLTAGE (V)</span>
          </div>

          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={ocvCurveData} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1F2937" />
                <XAxis dataKey="soc" stroke="#4B5563" tick={{ fill: '#9CA3AF', fontSize: 11 }} label={{ value: 'SOC (%)', position: 'insideBottom', offset: -5, fill: '#4B5563', fontSize: 11 }} />
                <YAxis domain={['auto', 'auto']} stroke="#4B5563" tick={{ fill: '#9CA3AF', fontSize: 11 }} />
                <Tooltip contentStyle={{ backgroundColor: '#0A0A0B', borderColor: '#1F2937', borderRadius: '4px', color: '#E0E0E6', fontSize: '12px' }} />
                <Line type="monotone" dataKey="ocvNmc" name="NMC-811 OCV (V)" stroke="#fbbf24" strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="ocvLfp" name="LFP OCV (V)" stroke="#22D3EE" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Thermal & Degradation Economics */}
        <div className="bg-[#111113] border border-[#1F2937] rounded-md p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-[#1F2937]">
            <h3 className="text-sm font-semibold text-[#E0E0E6] font-mono flex items-center gap-2">
              <Thermometer className="w-4 h-4 text-rose-400" />
              THERMAL MANAGEMENT & ARRHENIUS AGING
            </h3>
            <span className="text-xs font-mono text-rose-300">Ea = {currentChem.arrheniusActivationEnergy} kJ/mol</span>
          </div>

          <div className="space-y-3 text-xs text-slate-300">
            <div className="p-3 bg-[#0A0A0B] border border-[#1F2937] rounded-sm space-y-2 font-mono">
              <div className="flex justify-between">
                <span className="text-slate-400">Heat Generation Formula:</span>
                <span className="text-amber-300">Q = I²·R_int + I·T·(dE/dT)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Thermal Capacity (C_th):</span>
                <span className="text-slate-200">{(currentChem.thermalMassJPerK / 1000).toFixed(0)} kJ/K</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Optimal Operating Envelope:</span>
                <span className="text-cyan-400">{currentChem.optimalTempRange[0]}°C to {currentChem.optimalTempRange[1]}°C</span>
              </div>
            </div>

            <div className="p-3 bg-rose-950/20 border border-rose-900/40 rounded-sm space-y-1 font-mono">
              <div className="text-rose-400 font-bold flex items-center gap-1.5">
                <Flame className="w-4 h-4" /> THERMAL DEGRADATION WARNING
              </div>
              <p className="text-[11px] text-slate-300">
                Operating above 35°C accelerates solid-electrolyte interphase (SEI) growth exponentially via Arrhenius kinetics, increasing battery aging cost by up to 340%.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
