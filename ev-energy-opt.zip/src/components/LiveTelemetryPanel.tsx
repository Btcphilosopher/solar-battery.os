/**
 * EV-ENERGY-OPT Live Telemetry & System Energy Flow Panel
 * Implements the energy flow network node diagram and 24-hour dispatch timeline chart.
 */

import React from 'react';
import { SimulationState } from '../types';
import {
  ResponsiveContainer,
  ComposedChart,
  Area,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
} from 'recharts';
import { Sun, Zap, Battery, Car, Activity, ShieldAlert, ArrowRight } from 'lucide-react';

interface LiveTelemetryPanelProps {
  state: SimulationState;
}

export const LiveTelemetryPanel: React.FC<LiveTelemetryPanelProps> = ({ state }) => {
  const history = state.dispatchHistory;
  const latest = history[history.length - 1] || {
    solarPowerKW: state.marketState.solarGenerationKW,
    gridPowerKW: 0,
    batteryPowerKW: 0,
    houseLoadKW: state.marketState.householdDemandKW,
    motorPowerKW: 0,
    regenPowerKW: 0,
    socPct: state.currentSocPct,
    spotPrice: state.marketState.spotPriceGbpKWh,
  };

  const chartData = history.map((d) => ({
    time: d.timestamp,
    batteryPower: d.batteryPowerKW,
    gridPower: d.gridPowerKW,
    solarPower: d.solarPowerKW,
    soc: d.socPct,
    price: d.spotPrice,
  }));

  return (
    <div className="space-y-6">
      {/* 1. Fundamental System Energy Flow Network Diagram */}
      <div className="bg-[#111113] border border-[#1F2937] rounded-md p-5 shadow-xl">
        <div className="flex items-center justify-between mb-4 pb-3 border-b border-[#1F2937]">
          <div>
            <h2 className="text-base font-semibold tracking-tighter text-[#E0E0E6] flex items-center gap-2">
              <Activity className="w-4 h-4 text-cyan-400" />
              SYSTEM ENERGY FLOW ARCHITECTURE
            </h2>
            <p className="text-[10px] uppercase tracking-wider text-slate-400 font-mono mt-0.5">
              Real-time multi-node power balance & conversion topology (Prompt Section 1)
            </p>
          </div>
          <div className="text-xs font-mono bg-[#0A0A0B] px-2.5 py-1 rounded-sm border border-[#1F2937] text-slate-300">
            NET BALANCE: <span className="text-emerald-400 font-bold">0.00 kW</span>
          </div>
        </div>

        {/* Node Flow Diagram */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 relative">
          {/* Node A: Grid & Solar Inputs */}
          <div className="space-y-3">
            <div className="bg-[#0A0A0B] border border-[#1F2937] rounded-sm p-3 relative overflow-hidden">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-blue-400 flex items-center gap-1.5 font-mono">
                  <Zap className="w-4 h-4" /> ELECTRICITY GRID
                </span>
                <span className="text-xs font-mono font-bold text-blue-300">
                  {latest.gridPowerKW >= 0 ? `+${latest.gridPowerKW.toFixed(1)} kW` : `${latest.gridPowerKW.toFixed(1)} kW (V2G)`}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-1 font-mono">
                Spot: £{state.marketState.spotPriceGbpKWh.toFixed(2)}/kWh
              </p>
            </div>

            <div className="bg-[#0A0A0B] border border-[#1F2937] rounded-sm p-3 relative">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-yellow-400 flex items-center gap-1.5 font-mono">
                  <Sun className="w-4 h-4" /> HOME SOLAR PV
                </span>
                <span className="text-xs font-mono font-bold text-yellow-300">
                  +{latest.solarPowerKW.toFixed(1)} kW
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-1 font-mono">
                Irradiance: {state.marketState.solarIrradianceWM2.toFixed(0)} W/m²
              </p>
            </div>
          </div>

          {/* Node B: Power Converter & Wallbox Charger */}
          <div className="flex flex-col justify-center">
            <div className="bg-[#0A0A0B] border border-[#1F2937] rounded-sm p-4 text-center space-y-2">
              <div className="text-[10px] uppercase font-mono tracking-widest text-amber-400 opacity-80">
                POWER CONVERTER & CHARGER
              </div>
              <div className="text-xl font-mono font-bold text-cyan-400">
                {Math.abs(latest.batteryPowerKW).toFixed(1)} kW
              </div>
              <div className="text-[10px] text-slate-400 font-mono uppercase bg-[#111113] border border-[#1F2937] px-2 py-0.5 rounded-sm inline-block">
                EFFICIENCY: 94.8%
              </div>
            </div>
          </div>

          {/* Node C: Central EV Battery Resource */}
          <div className="flex flex-col justify-center">
            <div className="bg-[#0A0A0B] border border-cyan-500/40 rounded-sm p-4 shadow-[0_0_20px_rgba(34,211,238,0.08)] space-y-2 relative">
              <div className="flex items-center justify-between border-b border-[#1F2937] pb-2">
                <span className="text-xs font-bold text-cyan-400 font-mono flex items-center gap-1.5">
                  <Battery className="w-4 h-4" /> EV BATTERY
                </span>
                <span className="text-xs font-mono font-bold text-slate-200">
                  SOH: {state.currentSohPct.toFixed(2)}%
                </span>
              </div>
              <div className="text-2xl font-mono font-extrabold text-cyan-400 text-center tracking-tight">
                {state.currentSocPct.toFixed(1)}% <span className="text-xs font-normal opacity-50">SOC</span>
              </div>
              <div className="w-full bg-[#1F2937] h-2 rounded-full overflow-hidden">
                <div
                  className="bg-cyan-500 h-full transition-all duration-300"
                  style={{ width: `${state.currentSocPct}%` }}
                />
              </div>
              <div className="flex justify-between text-[11px] font-mono text-slate-400">
                <span>Temp: {latest.packTempC?.toFixed(1) || state.currentTempC.toFixed(1)}°C</span>
                <span>Cap: {state.chemistry.capacityKWh} kWh ({state.chemistry.type})</span>
              </div>
            </div>
          </div>

          {/* Node D: Motor / Household Load / Regen */}
          <div className="space-y-3">
            <div className="bg-[#0A0A0B] border border-[#1F2937] rounded-sm p-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-purple-400 flex items-center gap-1.5 font-mono">
                  <Car className="w-4 h-4" /> MOTOR / DRIVETRAIN
                </span>
                <span className="text-xs font-mono font-bold text-purple-300">
                  {latest.motorPowerKW > 0 ? `+${latest.motorPowerKW.toFixed(1)} kW` : '0.0 kW'}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-1 font-mono">
                Kinetic Traction Demand
              </p>
            </div>

            <div className="bg-[#0A0A0B] border border-[#1F2937] rounded-sm p-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-cyan-400 flex items-center gap-1.5 font-mono">
                  <Activity className="w-4 h-4" /> REGEN BRAKING
                </span>
                <span className="text-xs font-mono font-bold text-emerald-400">
                  +{latest.regenPowerKW.toFixed(1)} kW
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-1 font-mono">
                Deceleration Energy Recovery
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* 2. 24-Hour Real-Time Power & Dispatch Timeline Chart */}
      <div className="bg-[#111113] border border-[#1F2937] rounded-md p-5 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-[#1F2937]">
          <div>
            <h3 className="text-sm font-semibold text-[#E0E0E6] font-mono flex items-center gap-2">
              <Activity className="w-4 h-4 text-cyan-400" />
              24-HOUR ENERGY DISPATCH & SPOT PRICE TRAJECTORY
            </h3>
            <p className="text-xs text-slate-400">
              Co-optimizing battery charge/discharge dispatch against market spot price & solar generation
            </p>
          </div>
          <div className="flex items-center gap-3 text-xs font-mono">
            <span className="flex items-center gap-1 text-amber-400">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400 inline-block" /> Battery kW
            </span>
            <span className="flex items-center gap-1 text-blue-400">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-400 inline-block" /> Grid kW
            </span>
            <span className="flex items-center gap-1 text-yellow-400">
              <span className="w-2.5 h-2.5 rounded-full bg-yellow-400 inline-block" /> Solar kW
            </span>
            <span className="flex items-center gap-1 text-cyan-400">
              <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 inline-block" /> SOC %
            </span>
          </div>
        </div>

        {history.length > 0 ? (
          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={chartData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1F2937" />
                <XAxis dataKey="time" stroke="#4B5563" tick={{ fill: '#9CA3AF', fontSize: 11 }} />
                <YAxis yAxisId="power" stroke="#4B5563" tick={{ fill: '#9CA3AF', fontSize: 11 }} label={{ value: 'Power (kW)', angle: -90, position: 'insideLeft', fill: '#9CA3AF', fontSize: 11 }} />
                <YAxis yAxisId="soc" orientation="right" domain={[0, 100]} stroke="#22D3EE" tick={{ fill: '#22D3EE', fontSize: 11 }} label={{ value: 'SOC (%)', angle: 90, position: 'insideRight', fill: '#22D3EE', fontSize: 11 }} />
                <Tooltip contentStyle={{ backgroundColor: '#0A0A0B', borderColor: '#1F2937', borderRadius: '4px', color: '#E0E0E6', fontSize: '12px' }} />
                <Legend />
                <Area yAxisId="power" type="monotone" dataKey="solarPower" name="Solar kW" fill="#f59e0b" stroke="#f59e0b" fillOpacity={0.15} />
                <Line yAxisId="power" type="monotone" dataKey="batteryPower" name="Battery kW" stroke="#fbbf24" strokeWidth={2} dot={false} />
                <Line yAxisId="power" type="monotone" dataKey="gridPower" name="Grid kW" stroke="#60a5fa" strokeWidth={2} dot={false} />
                <Line yAxisId="soc" type="monotone" dataKey="soc" name="SOC %" stroke="#22D3EE" strokeWidth={2.5} dot={false} />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        ) : (
          <div className="h-48 flex items-center justify-center text-slate-500 font-mono text-xs">
            Simulation history empty. Click 'RUN' in the header to start execution.
          </div>
        )}
      </div>
    </div>
  );
};
