/**
 * EV-ENERGY-OPT Vehicle Physics & Dynamics Panel
 * Interactive vehicle physics dynamics, tractive forces, and regenerative braking recovery simulator.
 */

import React, { useState } from 'react';
import { VehiclePhysicsConfig } from '../types';
import { DEFAULT_VEHICLE_CONFIG, calculateVehiclePower, DrivingConditions } from '../physics/vehicleEngine';
import { Car, Activity, Zap, Wind, Mountain, Gauge, RefreshCw } from 'lucide-react';

interface VehicleDynamicsPanelProps {
  config?: VehiclePhysicsConfig;
}

export const VehicleDynamicsPanel: React.FC<VehicleDynamicsPanelProps> = () => {
  const [vehicle, setVehicle] = useState<VehiclePhysicsConfig>(DEFAULT_VEHICLE_CONFIG);
  const [conditions, setConditions] = useState<DrivingConditions>({
    speedKmH: 90,
    accelerationMs2: 0.0,
    gradientPct: 2.0,
    ambientTempC: 15,
    headwindKmH: 10,
  });

  const breakdown = calculateVehiclePower(conditions, vehicle);

  return (
    <div className="space-y-6">
      {/* 1. Drive Cycle Physics Parameters Header */}
      <div className="bg-[#111113] border border-[#1F2937] rounded-md p-5 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#1F2937]">
          <div>
            <h2 className="text-base font-semibold tracking-tighter text-[#E0E0E6] flex items-center gap-2">
              <Car className="w-5 h-5 text-cyan-400" />
              VEHICLE DYNAMICS & PHYSICAL ENERGY DEMAND
            </h2>
            <p className="text-[10px] uppercase tracking-wider text-slate-400 font-mono mt-0.5">
              Energy demand emerges directly from vehicle physics rather than fixed kWh/km numbers
            </p>
          </div>
          <div className="text-xs font-mono bg-cyan-950/40 text-cyan-400 border border-cyan-800/60 px-3 py-1 rounded-sm font-bold">
            EFFICIENCY: {breakdown.efficiencyWhPerKm.toFixed(0)} Wh/km
          </div>
        </div>

        {/* Driving Sliders */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {/* Speed */}
          <div className="bg-[#0A0A0B] border border-[#1F2937] p-3 rounded-sm space-y-2 font-mono">
            <div className="flex justify-between text-xs">
              <span className="text-slate-400 flex items-center gap-1">
                <Gauge className="w-3.5 h-3.5 text-cyan-400" /> Speed
              </span>
              <span className="text-cyan-300 font-bold">{conditions.speedKmH} km/h</span>
            </div>
            <input
              type="range"
              min="0"
              max="160"
              value={conditions.speedKmH}
              onChange={(e) => setConditions({ ...conditions, speedKmH: Number(e.target.value) })}
              className="w-full accent-cyan-400 cursor-pointer"
            />
          </div>

          {/* Acceleration */}
          <div className="bg-[#0A0A0B] border border-[#1F2937] p-3 rounded-sm space-y-2 font-mono">
            <div className="flex justify-between text-xs">
              <span className="text-slate-400 flex items-center gap-1">
                <Zap className="w-3.5 h-3.5 text-amber-400" /> Accel / Decel
              </span>
              <span className={`font-bold ${conditions.accelerationMs2 < 0 ? 'text-emerald-400' : 'text-amber-300'}`}>
                {conditions.accelerationMs2 >= 0 ? `+${conditions.accelerationMs2.toFixed(1)}` : conditions.accelerationMs2.toFixed(1)} m/s²
              </span>
            </div>
            <input
              type="range"
              min="-3.5"
              max="3.5"
              step="0.1"
              value={conditions.accelerationMs2}
              onChange={(e) => setConditions({ ...conditions, accelerationMs2: Number(e.target.value) })}
              className="w-full accent-amber-400 cursor-pointer"
            />
          </div>

          {/* Gradient */}
          <div className="bg-[#0A0A0B] border border-[#1F2937] p-3 rounded-sm space-y-2 font-mono">
            <div className="flex justify-between text-xs">
              <span className="text-slate-400 flex items-center gap-1">
                <Mountain className="w-3.5 h-3.5 text-emerald-400" /> Gradient
              </span>
              <span className="text-emerald-300 font-bold">{conditions.gradientPct > 0 ? `+${conditions.gradientPct}%` : `${conditions.gradientPct}%`}</span>
            </div>
            <input
              type="range"
              min="-12"
              max="12"
              step="0.5"
              value={conditions.gradientPct}
              onChange={(e) => setConditions({ ...conditions, gradientPct: Number(e.target.value) })}
              className="w-full accent-emerald-400 cursor-pointer"
            />
          </div>

          {/* Headwind */}
          <div className="bg-[#0A0A0B] border border-[#1F2937] p-3 rounded-sm space-y-2 font-mono">
            <div className="flex justify-between text-xs">
              <span className="text-slate-400 flex items-center gap-1">
                <Wind className="w-3.5 h-3.5 text-blue-400" /> Headwind
              </span>
              <span className="text-blue-300 font-bold">{conditions.headwindKmH} km/h</span>
            </div>
            <input
              type="range"
              min="-30"
              max="50"
              value={conditions.headwindKmH}
              onChange={(e) => setConditions({ ...conditions, headwindKmH: Number(e.target.value) })}
              className="w-full accent-blue-400 cursor-pointer"
            />
          </div>

          {/* Ambient Temp */}
          <div className="bg-[#0A0A0B] border border-[#1F2937] p-3 rounded-sm space-y-2 font-mono">
            <div className="flex justify-between text-xs">
              <span className="text-slate-400 flex items-center gap-1">
                <Activity className="w-3.5 h-3.5 text-rose-400" /> Ambient Temp
              </span>
              <span className="text-rose-300 font-bold">{conditions.ambientTempC}°C</span>
            </div>
            <input
              type="range"
              min="-10"
              max="40"
              value={conditions.ambientTempC}
              onChange={(e) => setConditions({ ...conditions, ambientTempC: Number(e.target.value) })}
              className="w-full accent-rose-400 cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* 2. Tractive Forces Breakdown & Regenerative Recovery */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Forces Breakdown */}
        <div className="bg-[#111113] border border-[#1F2937] rounded-md p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-[#1F2937] font-mono">
            <h3 className="text-sm font-semibold text-[#E0E0E6] flex items-center gap-2">
              <Activity className="w-4 h-4 text-amber-400" />
              PHYSICAL POWER BREAKDOWN (kW)
            </h3>
            <span className="text-xs font-bold text-amber-300">
              TOTAL BATTERY DEMAND: {breakdown.totalBatteryDemandKW.toFixed(2)} kW
            </span>
          </div>

          <div className="space-y-3 font-mono text-xs">
            <div className="space-y-1">
              <div className="flex justify-between text-slate-300">
                <span>Aerodynamic Drag (0.5·ρ·Cd·A·v²):</span>
                <span className="text-cyan-400 font-bold">+{breakdown.aerodynamicPowerKW.toFixed(2)} kW</span>
              </div>
              <div className="w-full bg-[#1F2937] h-1.5 rounded-full overflow-hidden">
                <div className="bg-cyan-400 h-full" style={{ width: `${Math.min(100, (breakdown.aerodynamicPowerKW / Math.max(1, breakdown.totalBatteryDemandKW)) * 100)}%` }} />
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-slate-300">
                <span>Rolling Resistance (m·g·Crr·cosθ):</span>
                <span className="text-blue-400 font-bold">+{breakdown.rollingResistancePowerKW.toFixed(2)} kW</span>
              </div>
              <div className="w-full bg-[#1F2937] h-1.5 rounded-full overflow-hidden">
                <div className="bg-blue-400 h-full" style={{ width: `${Math.min(100, (breakdown.rollingResistancePowerKW / Math.max(1, breakdown.totalBatteryDemandKW)) * 100)}%` }} />
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-slate-300">
                <span>Elevation Gradient (m·g·sinθ):</span>
                <span className={breakdown.gradientPowerKW >= 0 ? 'text-emerald-400 font-bold' : 'text-purple-400 font-bold'}>
                  {breakdown.gradientPowerKW >= 0 ? `+${breakdown.gradientPowerKW.toFixed(2)} kW` : `${breakdown.gradientPowerKW.toFixed(2)} kW`}
                </span>
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between text-slate-300">
                <span>HVAC & Auxiliary Electrical Load:</span>
                <span className="text-rose-300 font-bold">+{(breakdown.hvacPowerKW + breakdown.auxPowerKW).toFixed(2)} kW</span>
              </div>
            </div>
          </div>
        </div>

        {/* Regenerative Recovery Panel */}
        <div className="bg-[#111113] border border-[#1F2937] rounded-md p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-[#1F2937] font-mono">
            <h3 className="text-sm font-semibold text-[#E0E0E6] flex items-center gap-2">
              <RefreshCw className="w-4 h-4 text-emerald-400" />
              REGENERATIVE BRAKING RECOVERY
            </h3>
            <span className="text-xs font-mono font-bold text-emerald-300">
              REGEN CAP: {vehicle.regenMaxPowerKW} kW
            </span>
          </div>

          <div className="space-y-3 font-mono text-xs">
            <div className="p-3 bg-[#0A0A0B] border border-[#1F2937] rounded-sm space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-400">Kinetic Regen Recovered:</span>
                <span className="text-emerald-400 font-bold text-sm">+{breakdown.regenRecoveredKW.toFixed(2)} kW</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Friction Brake Dissipation:</span>
                <span className="text-rose-400 font-bold">{breakdown.frictionBrakePowerKW.toFixed(2)} kW</span>
              </div>
            </div>

            <div className="p-3 bg-emerald-950/20 border border-emerald-900/40 rounded-sm text-emerald-300 text-[11px] leading-relaxed">
              💡 Kinetic energy deceleration flows through motor generator (efficiency 94.8%) to recharge the battery without exceeding C-rate or thermal pack limits.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
