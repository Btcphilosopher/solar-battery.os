/**
 * EV-ENERGY-OPT Monte Carlo Scientific Research Laboratory (R Integration)
 * Renders P10, P50, P90 percentile confidence fan charts across multi-year stochastic simulations.
 */

import React, { useState, useEffect } from 'react';
import { SimulationState } from '../types';
import { runMonteCarloSimulation, MonteCarloConfig } from '../physics/monteCarloEngine';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
} from 'recharts';
import { Database, Play, BarChart3, TrendingUp, ShieldCheck, Activity } from 'lucide-react';

interface MonteCarloPanelProps {
  state: SimulationState;
}

export const MonteCarloPanel: React.FC<MonteCarloPanelProps> = ({ state }) => {
  const [config, setConfig] = useState<MonteCarloConfig>({
    numIterations: 800,
    horizonMonths: 60, // 5 years
    priceVolatilityPct: 25,
    drivingDemandVariancePct: 20,
    strategy: 'DEGRADATION_AWARE_OPTIMAL',
    chemistry: state.chemistry,
  });

  const [simResults, setSimResults] = useState(() => runMonteCarloSimulation(config));
  const [isSimulating, setIsSimulating] = useState(false);

  const handleRunSimulation = () => {
    setIsSimulating(true);
    setTimeout(() => {
      setSimResults(runMonteCarloSimulation({ ...config, chemistry: state.chemistry }));
      setIsSimulating(false);
    }, 150);
  };

  useEffect(() => {
    handleRunSimulation();
  }, [state.chemistry.type]);

  // Transform percentiles data for Recharts AreaChart (P10, P50, P90 fan)
  const sohChartData = simResults.sohResult.timeAxisDays.map((days, idx) => ({
    days: (days / 365).toFixed(1) + 'y',
    p10: simResults.sohResult.percentiles.p10[idx],
    p50: simResults.sohResult.percentiles.p50[idx],
    p90: simResults.sohResult.percentiles.p90[idx],
    p90MinusP50: simResults.sohResult.percentiles.p90[idx] - simResults.sohResult.percentiles.p50[idx],
    p50MinusP10: simResults.sohResult.percentiles.p50[idx] - simResults.sohResult.percentiles.p10[idx],
  }));

  const costChartData = simResults.costResult.timeAxisDays.map((days, idx) => ({
    days: (days / 365).toFixed(1) + 'y',
    p10: simResults.costResult.percentiles.p10[idx],
    p50: simResults.costResult.percentiles.p50[idx],
    p90: simResults.costResult.percentiles.p90[idx],
  }));

  return (
    <div className="space-y-6">
      {/* 1. Research Controls Banner */}
      <div className="bg-[#111113] border border-[#1F2937] rounded-md p-5 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[#1F2937]">
          <div>
            <h2 className="text-base font-semibold tracking-tighter text-[#E0E0E6] flex items-center gap-2">
              <Database className="w-5 h-5 text-cyan-400" />
              R QUANTITATIVE RESEARCH & MONTE CARLO ANALYSIS
            </h2>
            <p className="text-[10px] uppercase tracking-wider text-slate-400 font-mono mt-0.5">
              Simulate 1,000s of possible futures: price volatility, weather shifts, battery degradation & driving variance
            </p>
          </div>
          <button
            onClick={handleRunSimulation}
            disabled={isSimulating}
            className="px-4 py-2 bg-cyan-500 hover:bg-cyan-400 text-[#0A0A0B] font-bold font-mono text-xs rounded-sm flex items-center gap-2 transition shadow-[0_0_15px_rgba(34,211,238,0.2)] cursor-pointer"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            {isSimulating ? 'RUNNING MONTE CARLO...' : 'EXECUTE R MONTE CARLO (1,000 SIMS)'}
          </button>
        </div>

        {/* Configuration Parameter Controls */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 font-mono text-xs">
          {/* Strategy Selector */}
          <div className="bg-[#0A0A0B] border border-[#1F2937] p-3 rounded-sm space-y-1.5">
            <span className="text-slate-400">DISPATCH STRATEGY</span>
            <select
              value={config.strategy}
              onChange={(e) => setConfig({ ...config, strategy: e.target.value as any })}
              className="w-full bg-[#111113] border border-[#1F2937] text-slate-200 rounded-sm px-2 py-1 focus:outline-none focus:border-cyan-500"
            >
              <option value="UNMANAGED">1. Unmanaged (Immediate Charge)</option>
              <option value="PRICE_ONLY">2. Price-Only (Ignore Degradation)</option>
              <option value="DEGRADATION_AWARE_OPTIMAL">3. EV-ENERGY-OPT (Co-Optimizer)</option>
            </select>
          </div>

          {/* Horizon Months */}
          <div className="bg-[#0A0A0B] border border-[#1F2937] p-3 rounded-sm space-y-1.5">
            <div className="flex justify-between">
              <span className="text-slate-400">TIME HORIZON</span>
              <span className="text-cyan-300 font-bold">{config.horizonMonths / 12} Years</span>
            </div>
            <input
              type="range"
              min="12"
              max="120"
              step="12"
              value={config.horizonMonths}
              onChange={(e) => setConfig({ ...config, horizonMonths: Number(e.target.value) })}
              className="w-full accent-cyan-400 cursor-pointer"
            />
          </div>

          {/* Price Volatility */}
          <div className="bg-[#0A0A0B] border border-[#1F2937] p-3 rounded-sm space-y-1.5">
            <div className="flex justify-between">
              <span className="text-slate-400">PRICE VOLATILITY (σ)</span>
              <span className="text-amber-300 font-bold">{config.priceVolatilityPct}%</span>
            </div>
            <input
              type="range"
              min="5"
              max="60"
              value={config.priceVolatilityPct}
              onChange={(e) => setConfig({ ...config, priceVolatilityPct: Number(e.target.value) })}
              className="w-full accent-amber-400 cursor-pointer"
            />
          </div>

          {/* Demand Variance */}
          <div className="bg-[#0A0A0B] border border-[#1F2937] p-3 rounded-sm space-y-1.5">
            <div className="flex justify-between">
              <span className="text-slate-400">DRIVER VARIANCE</span>
              <span className="text-purple-300 font-bold">±{config.drivingDemandVariancePct}%</span>
            </div>
            <input
              type="range"
              min="5"
              max="50"
              value={config.drivingDemandVariancePct}
              onChange={(e) => setConfig({ ...config, drivingDemandVariancePct: Number(e.target.value) })}
              className="w-full accent-purple-400 cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* 2. Percentile Fan Charts (P10, P50, P90) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* SOH Degradation Fan Chart */}
        <div className="bg-[#111113] border border-[#1F2937] rounded-md p-5 shadow-xl space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-[#1F2937] font-mono">
            <h3 className="text-sm font-semibold text-[#E0E0E6] flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              BATTERY SOH DEGRADATION FAN (P10 / P50 / P90)
            </h3>
            <span className="text-xs font-bold text-emerald-300">
              5Y LOSS (P50): -{simResults.sohResult.summaryStats.sohLoss5YearP50.toFixed(1)}%
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={sohChartData} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1F2937" />
                <XAxis dataKey="days" stroke="#4B5563" tick={{ fill: '#9CA3AF', fontSize: 11 }} />
                <YAxis domain={[60, 100]} stroke="#4B5563" tick={{ fill: '#9CA3AF', fontSize: 11 }} />
                <Tooltip contentStyle={{ backgroundColor: '#0A0A0B', borderColor: '#1F2937', borderRadius: '4px', color: '#E0E0E6', fontSize: '12px' }} />
                <Area type="monotone" dataKey="p90" name="P90 (Best)" stroke="#10b981" fill="#10b981" fillOpacity={0.15} />
                <Area type="monotone" dataKey="p50" name="P50 (Median)" stroke="#22d3ee" fill="#22d3ee" fillOpacity={0.25} />
                <Area type="monotone" dataKey="p10" name="P10 (Worst)" stroke="#f43f5e" fill="#f43f5e" fillOpacity={0.15} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Total Energy Cost Trajectory */}
        <div className="bg-[#111113] border border-[#1F2937] rounded-md p-5 shadow-xl space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-[#1F2937] font-mono">
            <h3 className="text-sm font-semibold text-[#E0E0E6] flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-cyan-400" />
              CUMULATIVE ENERGY COST TRAJECTORY (£)
            </h3>
            <span className="text-xs font-bold text-cyan-300">
              MEAN COST: £{simResults.costResult.summaryStats.meanCost.toFixed(0)}
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={costChartData} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1F2937" />
                <XAxis dataKey="days" stroke="#4B5563" tick={{ fill: '#9CA3AF', fontSize: 11 }} />
                <YAxis stroke="#4B5563" tick={{ fill: '#9CA3AF', fontSize: 11 }} />
                <Tooltip contentStyle={{ backgroundColor: '#0A0A0B', borderColor: '#1F2937', borderRadius: '4px', color: '#E0E0E6', fontSize: '12px' }} />
                <Area type="monotone" dataKey="p50" name="P50 Cost (£)" stroke="#22d3ee" fill="#22d3ee" fillOpacity={0.25} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
