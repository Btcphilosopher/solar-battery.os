/**
 * EV-ENERGY-OPT: Electric Vehicle Battery & Energy Optimisation Engine
 * Main Application & Continuous Physical Simulation Loop Container
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  BatteryChemistry,
  ElectricityMarketState,
  ObjectiveCoefficients,
  ScenarioDefinition,
  SimulationState,
  VehiclePhysicsConfig,
} from './types';
import { PRESET_CHEMISTRIES } from './physics/batteryEngine';
import { DEFAULT_VEHICLE_CONFIG } from './physics/vehicleEngine';
import { getCurrentMarketState } from './physics/marketEngine';
import { computeOptimalDispatch } from './physics/optimiserEngine';
import { PRESET_SCENARIOS } from './data/scenarios';

// Subcomponents
import { CommandHeader } from './components/CommandHeader';
import { LiveTelemetryPanel } from './components/LiveTelemetryPanel';
import { SmartChargingV2GPanel } from './components/SmartChargingV2GPanel';
import { BatteryThermalPanel } from './components/BatteryThermalPanel';
import { VehicleDynamicsPanel } from './components/VehicleDynamicsPanel';
import { MonteCarloPanel } from './components/MonteCarloPanel';
import { CodebaseExplorer } from './components/CodebaseExplorer';
import { ResearchLabPanel } from './components/ResearchLabPanel';
import { ObjectiveWeightsModal } from './components/ObjectiveWeightsModal';

import { Activity, Zap, Battery, Car, Database, Terminal, HelpCircle, Layers } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<
    'telemetry' | 'smart_charging' | 'battery_thermal' | 'vehicle_physics' | 'monte_carlo' | 'codebase' | 'research_q'
  >('telemetry');

  const [activeScenario, setActiveScenario] = useState<ScenarioDefinition>(PRESET_SCENARIOS[0]);
  const [weightsModalOpen, setWeightsModalOpen] = useState(false);

  // Default objective weights: α=1.0, β=1.2, γ=0.8, δ=0.5, ε=1.0
  const [weights, setWeights] = useState<ObjectiveCoefficients>({
    alphaEnergyCost: 1.0,
    betaDegradation: 1.2,
    gammaThermal: 0.8,
    deltaGridStress: 0.5,
    epsilonV2GRevenue: 1.0,
  });

  // Simulation State
  const [simState, setSimState] = useState<SimulationState>(() => {
    const sc = PRESET_SCENARIOS[0];
    const chem = PRESET_CHEMISTRIES[sc.chemistryType] || PRESET_CHEMISTRIES.NMC;
    const initialMarket = getCurrentMarketState(0, sc.solarKw, sc.gridSpotPrice);

    return {
      timeStepMinutes: 15,
      currentTimeMinutes: 0,
      isLiveRunning: true,
      playbackSpeed: 1,
      departureTimeMinutes: 450, // 07:30
      targetSocPct: sc.targetSocPct,
      chemistry: chem,
      vehicleConfig: DEFAULT_VEHICLE_CONFIG,
      marketState: initialMarket,
      weights: {
        alphaEnergyCost: 1.0,
        betaDegradation: 1.2,
        gammaThermal: 0.8,
        deltaGridStress: 0.5,
        epsilonV2GRevenue: 1.0,
      },
      currentSocPct: sc.initialSocPct,
      currentSohPct: 98.6,
      currentTempC: sc.ambientTempC,
      totalEnergyCostGbp: 0,
      totalDegradationCostGbp: 0,
      totalV2GRevenueGbp: 0,
      todayEfficiencyPct: 94.8,
      dispatchHistory: [],
    };
  });

  // Load predefined scenario
  const handleLoadScenario = (sc: ScenarioDefinition) => {
    setActiveScenario(sc);
    const chem = PRESET_CHEMISTRIES[sc.chemistryType] || PRESET_CHEMISTRIES.NMC;
    const market = getCurrentMarketState(0, sc.solarKw, sc.gridSpotPrice);

    const [depH, depM] = sc.departureTimeStr.split(':').map(Number);
    const depMins = depH * 60 + (depM || 0);

    setSimState({
      timeStepMinutes: 15,
      currentTimeMinutes: 0,
      isLiveRunning: false,
      playbackSpeed: 1,
      departureTimeMinutes: depMins,
      targetSocPct: sc.targetSocPct,
      chemistry: chem,
      vehicleConfig: DEFAULT_VEHICLE_CONFIG,
      marketState: market,
      weights,
      currentSocPct: sc.initialSocPct,
      currentSohPct: 98.6,
      currentTempC: sc.ambientTempC,
      totalEnergyCostGbp: 0,
      totalDegradationCostGbp: 0,
      totalV2GRevenueGbp: 0,
      todayEfficiencyPct: 94.8,
      dispatchHistory: [],
    });
  };

  // Run one timestep forward
  const stepSimulation = () => {
    setSimState((prev) => {
      const nextTimeMins = (prev.currentTimeMinutes + prev.timeStepMinutes) % 1440; // wrap 24h
      const hourFloat = nextTimeMins / 60;
      const marketState = getCurrentMarketState(hourFloat, activeScenario.solarKw, activeScenario.gridSpotPrice);

      const isDriving = hourFloat >= 8.0 && hourFloat <= 9.0; // Simulate 8am driving commute
      const vehicleDemandKW = isDriving ? 18.5 : 0;

      const decision = computeOptimalDispatch({
        timeStepMinutes: prev.timeStepMinutes,
        currentTimeMinutes: prev.currentTimeMinutes,
        departureTimeMinutes: prev.departureTimeMinutes,
        targetSocPct: prev.targetSocPct,
        currentSocPct: prev.currentSocPct,
        currentSohPct: prev.currentSohPct,
        currentTempC: prev.currentTempC,
        ambientTempC: activeScenario.ambientTempC,
        chemistry: prev.chemistry,
        vehicleConfig: prev.vehicleConfig,
        marketState,
        weights: prev.weights,
        isDriving,
        vehicleDemandKW,
      });

      const updatedHistory = [...prev.dispatchHistory, decision];
      if (updatedHistory.length > 96) updatedHistory.shift(); // Keep last 24 hours (96 x 15-min steps)

      return {
        ...prev,
        currentTimeMinutes: nextTimeMins,
        marketState,
        currentSocPct: decision.socPct,
        currentSohPct: decision.sohPct,
        currentTempC: decision.packTempC,
        totalEnergyCostGbp: prev.totalEnergyCostGbp + decision.energyCostStepGbp,
        totalDegradationCostGbp: prev.totalDegradationCostGbp + decision.degradationCostStepGbp,
        totalV2GRevenueGbp: prev.totalV2GRevenueGbp + decision.v2gRevenueStepGbp,
        dispatchHistory: updatedHistory,
      };
    });
  };

  // Continuous loop timer
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    if (simState.isLiveRunning) {
      const intervalMs = Math.max(100, 1000 / simState.playbackSpeed);
      timerRef.current = window.setInterval(stepSimulation, intervalMs);
    } else if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [simState.isLiveRunning, simState.playbackSpeed, activeScenario]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-emerald-500 selection:text-slate-950">
      {/* Top Command Telemetry Bar */}
      <CommandHeader
        state={simState}
        onTogglePlay={() => setSimState((p) => ({ ...p, isLiveRunning: !p.isLiveRunning }))}
        onSetSpeed={(speed) => setSimState((p) => ({ ...p, playbackSpeed: speed }))}
        onReset={() => handleLoadScenario(activeScenario)}
        onOpenWeightsModal={() => setWeightsModalOpen(true)}
      />

      {/* Main Container */}
      <main className="max-w-7xl mx-auto p-4 sm:p-6 space-y-6">
        {/* Scenario Selection Bar */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 flex flex-col md:flex-row md:items-center justify-between gap-3 shadow-lg">
          <div className="flex items-center gap-2 text-xs font-mono">
            <Layers className="w-4 h-4 text-emerald-400" />
            <span className="text-slate-400">ACTIVE SCENARIO:</span>
            <span className="font-bold text-slate-100">{activeScenario.name}</span>
          </div>

          <div className="flex flex-wrap items-center gap-1.5 font-mono text-xs">
            {PRESET_SCENARIOS.map((sc) => (
              <button
                key={sc.id}
                onClick={() => handleLoadScenario(sc)}
                className={`px-2.5 py-1 rounded text-[11px] transition ${
                  activeScenario.id === sc.id
                    ? 'bg-emerald-600 text-white font-bold shadow'
                    : 'bg-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-750'
                }`}
              >
                {sc.id === 'scenario_25_prompt' ? 'PROMPT SCENARIO 25' : sc.id.replace('scenario_', '').toUpperCase()}
              </button>
            ))}
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex items-center gap-2 overflow-x-auto border-b border-slate-800 pb-2 text-xs font-mono">
          <button
            onClick={() => setActiveTab('telemetry')}
            className={`px-3 py-2 rounded-lg flex items-center gap-2 transition whitespace-nowrap ${
              activeTab === 'telemetry'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <Activity className="w-4 h-4 text-emerald-400" /> SYSTEM ENERGY FLOW
          </button>

          <button
            onClick={() => setActiveTab('smart_charging')}
            className={`px-3 py-2 rounded-lg flex items-center gap-2 transition whitespace-nowrap ${
              activeTab === 'smart_charging'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <Zap className="w-4 h-4 text-amber-400" /> SMART CHARGING & V2G
          </button>

          <button
            onClick={() => setActiveTab('battery_thermal')}
            className={`px-3 py-2 rounded-lg flex items-center gap-2 transition whitespace-nowrap ${
              activeTab === 'battery_thermal'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <Battery className="w-4 h-4 text-cyan-400" /> BATTERY & THERMAL
          </button>

          <button
            onClick={() => setActiveTab('vehicle_physics')}
            className={`px-3 py-2 rounded-lg flex items-center gap-2 transition whitespace-nowrap ${
              activeTab === 'vehicle_physics'
                ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40 font-bold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <Car className="w-4 h-4 text-purple-400" /> VEHICLE DYNAMICS
          </button>

          <button
            onClick={() => setActiveTab('monte_carlo')}
            className={`px-3 py-2 rounded-lg flex items-center gap-2 transition whitespace-nowrap ${
              activeTab === 'monte_carlo'
                ? 'bg-blue-500/20 text-blue-300 border border-blue-500/40 font-bold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <Database className="w-4 h-4 text-blue-400" /> R MONTE CARLO LAB
          </button>

          <button
            onClick={() => setActiveTab('codebase')}
            className={`px-3 py-2 rounded-lg flex items-center gap-2 transition whitespace-nowrap ${
              activeTab === 'codebase'
                ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 font-bold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <Terminal className="w-4 h-4 text-rose-400" /> RUST / R CODEBASE
          </button>

          <button
            onClick={() => setActiveTab('research_q')}
            className={`px-3 py-2 rounded-lg flex items-center gap-2 transition whitespace-nowrap ${
              activeTab === 'research_q'
                ? 'bg-yellow-500/20 text-yellow-300 border border-yellow-500/40 font-bold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <HelpCircle className="w-4 h-4 text-yellow-400" /> RESEARCH QUESTIONS
          </button>
        </nav>

        {/* Tab View Content */}
        {activeTab === 'telemetry' && <LiveTelemetryPanel state={simState} />}
        {activeTab === 'smart_charging' && <SmartChargingV2GPanel state={simState} />}
        {activeTab === 'battery_thermal' && (
          <BatteryThermalPanel
            state={simState}
            onSelectChemistry={(chem) => setSimState((p) => ({ ...p, chemistry: chem }))}
          />
        )}
        {activeTab === 'vehicle_physics' && <VehicleDynamicsPanel config={simState.vehicleConfig} />}
        {activeTab === 'monte_carlo' && <MonteCarloPanel state={simState} />}
        {activeTab === 'codebase' && <CodebaseExplorer />}
        {activeTab === 'research_q' && <ResearchLabPanel state={simState} />}
      </main>

      {/* Multi-Objective Function Weights Modal */}
      {weightsModalOpen && (
        <ObjectiveWeightsModal
          weights={weights}
          onSave={(newW) => {
            setWeights(newW);
            setSimState((p) => ({ ...p, weights: newW }));
          }}
          onClose={() => setWeightsModalOpen(false)}
        />
      )}
    </div>
  );
}
