/**
 * EV-ENERGY-OPT Scenario Definitions
 * Preconfigured physical and market scenarios for evaluation and simulation.
 */

import { ScenarioDefinition } from '../types';

export const PRESET_SCENARIOS: ScenarioDefinition[] = [
  {
    id: 'scenario_25_prompt',
    name: 'Scenario 25 (Prompt Benchmark: 75kWh / Solar 6.8kW / Off-Peak £0.12)',
    description: '75 kWh battery at 42% SOC. High solar peak (6.8 kW), 1.9 kW house load, £0.29 day price with expected £0.12 night off-peak. Target 80% SOC by 07:30.',
    batteryCapacityKWh: 75.0,
    initialSocPct: 42.0,
    targetSocPct: 80.0,
    departureTimeStr: '07:30',
    solarKw: 6.8,
    houseKw: 1.9,
    gridSpotPrice: 0.29,
    nightSpotPrice: 0.12,
    ambientTempC: 18.0,
    chemistryType: 'NMC',
  },
  {
    id: 'scenario_v2g_arbitrage',
    name: 'V2G Market Arbitrage (Super Peak £0.45 / Off-Peak £0.09)',
    description: 'High price spread environment. EV battery discharges to grid during peak hours (£0.45/kWh) and recharges during overnight wind surplus (£0.09/kWh).',
    batteryCapacityKWh: 75.0,
    initialSocPct: 65.0,
    targetSocPct: 85.0,
    departureTimeStr: '08:00',
    solarKw: 4.2,
    houseKw: 2.1,
    gridSpotPrice: 0.45,
    nightSpotPrice: 0.09,
    ambientTempC: 22.0,
    chemistryType: 'NMC',
  },
  {
    id: 'scenario_lfp_durability',
    name: 'LFP Fleet Battery Longevity (5,500 Cycle Life)',
    description: 'Lithium Iron Phosphate (LFP) chemistry testing ultra-high cycle life with high V2H home discharge capability and low degradation penalty.',
    batteryCapacityKWh: 60.0,
    initialSocPct: 50.0,
    targetSocPct: 90.0,
    departureTimeStr: '07:00',
    solarKw: 5.5,
    houseKw: 1.5,
    gridSpotPrice: 0.28,
    nightSpotPrice: 0.11,
    ambientTempC: 25.0,
    chemistryType: 'LFP',
  },
  {
    id: 'scenario_winter_hvac',
    name: 'Winter Extreme Cold (-5°C Ambient / 6kW HVAC Load)',
    description: 'Sub-zero winter driving test. Cold battery internal resistance spike, cabin heat pump power demand, and pre-conditioning thermal optimization.',
    batteryCapacityKWh: 75.0,
    initialSocPct: 35.0,
    targetSocPct: 85.0,
    departureTimeStr: '07:15',
    solarKw: 0.5,
    houseKw: 3.8,
    gridSpotPrice: 0.34,
    nightSpotPrice: 0.15,
    ambientTempC: -5.0,
    chemistryType: 'NMC',
  },
];
