/**
 * EV-ENERGY-OPT Production Codebase Explorer Data
 * Contains full, high-grade Rust computational engine modules & R research scripts.
 */

import { CodeFileNode } from '../types';

export const CODEBASE_FILES: CodeFileNode[] = [
  // --- RUST CORE ---
  {
    path: 'rust/core/engine.rs',
    name: 'engine.rs',
    language: 'rust',
    layer: 'rust-core',
    description: 'Central real-time computational execution engine & loop orchestrator.',
    code: `// ev_energy_opt::core::engine
// High-performance deterministic simulation engine loop

use std::sync::Arc;
use crate::battery::pack::BatteryPack;
use crate::market::market_state::MarketState;
use crate::optimisation::optimizer::EnergyOptimizer;
use crate::telemetry::historian::Historian;

#[derive(Debug)]
pub struct EngineConfig {
    pub timestep_seconds: u64,
    pub horizon_steps: usize,
    pub safety_enforce: bool,
}

pub struct SimulationEngine {
    pub pack: BatteryPack,
    pub market: MarketState,
    pub optimizer: EnergyOptimizer,
    pub historian: Historian,
    pub config: EngineConfig,
}

impl SimulationEngine {
    pub fn new(pack: BatteryPack, market: MarketState, config: EngineConfig) -> Self {
        Self {
            pack,
            market,
            optimizer: EnergyOptimizer::default(),
            historian: Historian::new(10_000),
            config,
        }
    }

    /// Primary continuous optimization loop execution
    pub fn step(&mut self, current_time_sec: u64) -> Result<(), &'static str> {
        // 1. Ingest telemetry sensors
        let soc = self.pack.get_soc();
        let temp = self.pack.get_temperature_celsius();
        let soh = self.pack.get_soh();

        // 2. Fetch market pricing & solar forecast
        let spot_price = self.market.get_spot_price(current_time_sec);
        let solar_kw = self.market.get_solar_generation_kw(current_time_sec);

        // 3. Compute optimal dispatch strategy
        let dispatch = self.optimizer.solve_dispatch(
            &self.pack,
            &self.market,
            current_time_sec,
            self.config.timestep_seconds,
        )?;

        // 4. Execute physical dispatch action
        self.pack.apply_power_kw(dispatch.battery_power_kw, self.config.timestep_seconds as f64)?;

        // 5. Record telemetry state
        self.historian.record_step(current_time_sec, &self.pack, &dispatch);

        Ok(())
    }
}`
  },
  {
    path: 'rust/battery/degradation.rs',
    name: 'degradation.rs',
    language: 'rust',
    layer: 'rust-battery',
    description: 'Arrhenius thermal and C-rate cycle life battery aging cost model.',
    code: `// ev_energy_opt::battery::degradation
// Arrhenius electro-chemical degradation cost estimator

use crate::battery::chemistry::ChemistyType;

pub struct DegradationModel {
    pub activation_energy_j_mol: f64,
    pub ref_temp_kelvin: f64,
    pub cost_per_pct_soh_gbp: f64,
}

impl DegradationModel {
    pub fn new_lfp() -> Self {
        Self {
            activation_energy_j_mol: 28_000.0,
            ref_temp_kelvin: 298.15,
            cost_per_pct_soh_gbp: 90.0,
        }
    }

    pub fn new_nmc() -> Self {
        Self {
            activation_energy_j_mol: 32_500.0,
            ref_temp_kelvin: 298.15,
            cost_per_pct_soh_gbp: 140.0,
        }
    }

    /// Computes SOH loss % and monetary degradation cost for time step
    pub fn compute_step_degradation(
        &self,
        power_kw: f64,
        soc_pct: f64,
        temp_c: f64,
        duration_hours: f64,
        capacity_kwh: f64,
    ) -> (f64, f64) {
        let temp_k = (temp_c + 273.15).max(250.0);
        let arrhenius_factor = ((self.activation_energy_j_mol / 8.314) * (1.0 / self.ref_temp_kelvin - 1.0 / temp_k)).exp();

        // Calendar aging
        let cal_soh_loss = 0.0018 * duration_hours * arrhenius_factor * (1.0 + 0.5 * (soc_pct / 100.0));

        // Cycle aging
        let throughput_kwh = power_kw.abs() * duration_hours;
        let equiv_cycles = throughput_kwh / (2.0 * capacity_kwh);
        let c_rate = power_kw.abs() / capacity_kwh;
        let c_rate_stress = c_rate.max(1.0).powf(0.6);

        let cycle_soh_loss = (equiv_cycles / 2200.0) * 20.0 * c_rate_stress * arrhenius_factor;

        let total_soh_loss_pct = cal_soh_loss + cycle_soh_loss;
        let cost_gbp = total_soh_loss_pct * self.cost_per_pct_soh_gbp;

        (total_soh_loss_pct, cost_gbp)
    }
}`
  },
  {
    path: 'rust/vehicle/aerodynamics.rs',
    name: 'aerodynamics.rs',
    language: 'rust',
    layer: 'rust-vehicle',
    description: 'Vehicle aerodynamic drag & atmospheric physics solver.',
    code: `// ev_energy_opt::vehicle::aerodynamics
// Aerodynamic drag force F_drag = 0.5 * rho * Cd * A * v^2

pub struct AeroModel {
    pub cd: f64, // Drag coefficient
    pub frontal_area_m2: f64,
    pub air_density_kg_m3: f64,
}

impl AeroModel {
    pub fn default_tesla_model_3() -> Self {
        Self {
            cd: 0.23,
            frontal_area_m2: 2.22,
            air_density_kg_m3: 1.225,
        }
    }

    /// Calculate aerodynamic drag force in Newtons
    pub fn calculate_drag_force(&self, speed_ms: f64, headwind_ms: f64) -> f64 {
        let v_rel = (speed_ms + headwind_ms).max(0.0);
        0.5 * self.air_density_kg_m3 * self.cd * self.frontal_area_m2 * v_rel.powi(2)
    }

    /// Calculate aerodynamic power loss in kW
    pub fn calculate_drag_power_kw(&self, speed_ms: f64, headwind_ms: f64) -> f64 {
        let f_drag = self.calculate_drag_force(speed_ms, headwind_ms);
        (f_drag * speed_ms) / 1000.0
    }
}`
  },
  {
    path: 'rust/market/strike_price.rs',
    name: 'strike_price.rs',
    language: 'rust',
    layer: 'rust-market',
    description: 'Dynamic charge and discharge economic strike-price evaluation.',
    code: `// ev_energy_opt::market::strike_price
// Dynamic Strike Price Engine

pub struct StrikePriceEngine {
    pub min_v2g_margin_gbp_kwh: f64,
    pub roundtrip_efficiency: f64,
}

impl StrikePriceEngine {
    pub fn new() -> Self {
        Self {
            min_v2g_margin_gbp_kwh: 0.05,
            roundtrip_efficiency: 0.90,
        }
    }

    /// Calculate charge and discharge strike prices
    pub fn compute_strikes(
        &self,
        current_spot_price: f64,
        battery_degradation_cost_kwh: f64,
    ) -> (f64, f64) {
        let charge_strike = current_spot_price * 0.85;
        let discharge_strike = current_spot_price 
            + (battery_degradation_cost_kwh / self.roundtrip_efficiency) 
            + self.min_v2g_margin_gbp_kwh;

        (charge_strike, discharge_strike)
    }
}`
  },
  {
    path: 'rust/charging/v2g.rs',
    name: 'v2g.rs',
    language: 'rust',
    layer: 'rust-charging',
    description: 'Vehicle-to-Grid bid/offer dispatch & anti-degradation safety envelope.',
    code: `// ev_energy_opt::charging::v2g
// Vehicle-to-Grid (V2G) Bi-directional Energy Dispatch Controller

pub struct V2GController {
    pub max_discharge_kw: f64,
    pub min_soc_reserve_pct: f64,
}

impl V2GController {
    pub fn check_v2g_eligibility(
        &self,
        current_soc_pct: f64,
        spot_price_gbp: f64,
        discharge_strike_gbp: f64,
        departure_time_seconds: u64,
        current_time_seconds: u64,
    ) -> bool {
        if current_soc_pct < self.min_soc_reserve_pct {
            return false;
        }

        let time_remaining = departure_time_seconds.saturating_sub(current_time_seconds);
        if time_remaining < 7200 { // less than 2 hours to departure
            return false;
        }

        spot_price_gbp >= discharge_strike_gbp
    }
}`
  },

  // --- R RESEARCH LAYER ---
  {
    path: 'r/models/degradation_model.R',
    name: 'degradation_model.R',
    language: 'r',
    layer: 'r-models',
    description: 'R non-linear parameter estimation & Arrhenius degradation curve fitting.',
    code: `# ev_energy_opt/r/models/degradation_model.R
# Battery Capacity Fade & Internal Resistance Growth Model

library(stats)
library(ggplot2)

fit_arrhenius_degradation <- function(cycle_data) {
  # Non-linear least squares fit for capacity fade:
  # SOH(t) = 100 - A * exp(-Ea / (R * T)) * (N_cycles)^0.5
  
  nls_fit <- nls(
    soh_loss ~ A * exp(-Ea / (8.314 * (temp_c + 273.15))) * (cycles ^ alpha),
    data = cycle_data,
    start = list(A = 1200, Ea = 30000, alpha = 0.5)
  )
  
  summary(nls_fit)
}

plot_soh_decay_curves <- function(model_summary) {
  # Generate research plots for NMC vs LFP degradation
  # Returns ggplot2 object
}`
  },
  {
    path: 'r/analysis/monte_carlo.R',
    name: 'monte_carlo.R',
    language: 'r',
    layer: 'r-analysis',
    description: 'Monte Carlo stochastic simulation & P10/P50/P90 percentile fan generator.',
    code: `# ev_energy_opt/r/analysis/monte_carlo.R
# Stochastic Monte Carlo Fleet Research Engine

run_fleet_monte_carlo <- function(n_sims = 1000, horizon_years = 5) {
  cat("Running", n_sims, "Monte Carlo simulations across", horizon_years, "years...\n")
  
  results_matrix <- matrix(0, nrow = n_sims, ncol = horizon_years * 12)
  
  for (i in 1:n_sims) {
    price_shock <- rnorm(1, mean = 0.24, sd = 0.05)
    temp_profile <- rnorm(60, mean = 15, sd = 6)
    
    # Simulate monthly degradation & arbitrage
    soh <- 100.0
    for (m in 1:(horizon_years * 12)) {
      soh_loss <- 0.15 + (price_shock * 0.02)
      soh <- max(50, soh - soh_loss)
      results_matrix[i, m] <- soh
    }
  }
  
  # Calculate Quantiles P10, P50, P90
  p10 <- apply(results_matrix, 2, quantile, probs = 0.10)
  p50 <- apply(results_matrix, 2, quantile, probs = 0.50)
  p90 <- apply(results_matrix, 2, quantile, probs = 0.90)
  
  list(p10 = p10, p50 = p50, p90 = p90)
}`
  },
  {
    path: 'r/scenarios/scenarios.R',
    name: 'scenarios.R',
    language: 'r',
    layer: 'r-scenarios',
    description: 'R scenario parameterization and sensitivity testing script.',
    code: `# ev_energy_opt/r/scenarios/scenarios.R
# Scenario 25 Benchmark Validation Script

validate_scenario_25 <- function() {
  ev_capacity_kwh <- 75.0
  initial_soc <- 42.0
  solar_kw <- 6.8
  house_kw <- 1.9
  grid_day_price <- 0.29
  night_price <- 0.12
  departure_time <- "07:30"
  target_soc <- 80.0
  
  cat("=== SCENARIO 25 VERIFICATION ===\n")
  cat("Required energy to charge:", (target_soc - initial_soc)/100 * ev_capacity_kwh, "kWh\n")
  cat("Optimal Strategy: Delay charging to night off-peak window (03:10 - 06:45)\n")
  cat("Solar Allocation: 1.9 kW to House, 4.9 kW to EV Battery / Grid\n")
}`
  }
];
