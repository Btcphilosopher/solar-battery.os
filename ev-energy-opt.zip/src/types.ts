/**
 * EV-ENERGY-OPT: Electric Vehicle Battery & Energy Optimisation Platform
 * Core Data Structures and Physics Unit Types
 */

export type BatteryChemistryType = 'NMC' | 'LFP';

export interface BatteryChemistry {
  name: string;
  type: BatteryChemistryType;
  nominalVoltage: number; // V
  maxVoltage: number; // V
  minVoltage: number; // V
  capacityKWh: number; // kWh
  maxChargeCRate: number; // C
  maxDischargeCRate: number; // C
  internalResistanceOm: number; // Ohms
  thermalMassJPerK: number; // J/K
  cycleLife80DOD: number; // Cycles to 80% SOH
  calendarAgingRatePerYr: number; // % SOH per year at 25C
  degradationCostPerPctSoh: number; // £ / % SOH loss (e.g. £120 for 1% of £12k battery)
  arrheniusActivationEnergy: number; // kJ/mol for thermal aging
  optimalTempRange: [number, number]; // [min, max] °C
}

export interface PhysicalUnits {
  voltage: number; // V
  current: number; // A
  powerKW: number; // kW
  energyKWh: number; // kWh
  tempC: number; // °C
  speedKmH: number; // km/h
  accelerationMs2: number; // m/s²
  gradientPct: number; // %
  costGbp: number; // £
  priceGbpPerKWh: number; // £/kWh
}

export interface VehiclePhysicsConfig {
  massKg: number; // kg (vehicle + battery + load)
  dragCoefficient: number; // Cd
  frontalAreaM2: number; // A (m²)
  rollingResistanceCoeff: number; // Crr
  drivetrainEfficiency: number; // % (e.g. 0.94)
  motorEfficiencyPeak: number; // % (e.g. 0.96)
  regenMaxPowerKW: number; // kW
  auxiliaryLoadKW: number; // kW (electronics, lights)
  hvacTargetTempC: number; // °C
  cabinTempC: number; // °C
}

export interface ElectricityMarketState {
  spotPriceGbpKWh: number; // £/kWh
  forecastPrices: number[]; // Next 24 hours £/kWh
  chargeStrikePrice: number; // £/kWh
  dischargeStrikePrice: number; // £/kWh
  gridCarbonIntensityGPerKWh: number; // gCO2/kWh
  gridDemandMW: number; // MW
  solarIrradianceWM2: number; // W/m²
  solarGenerationKW: number; // kW
  householdDemandKW: number; // kW
}

export type OptimisationAction = 
  | 'HOLD' 
  | 'CHARGE_GRID' 
  | 'CHARGE_SOLAR' 
  | 'DISCHARGE_V2H' 
  | 'DISCHARGE_V2G' 
  | 'REGENERATE';

export interface ObjectiveCoefficients {
  alphaEnergyCost: number; // α: Electricity cost weight
  betaDegradation: number; // β: Battery degradation weight
  gammaThermal: number; // γ: Thermal HVAC cost weight
  deltaGridStress: number; // δ: Grid congestion weight
  epsilonV2GRevenue: number; // ε: V2G Market arbitrage revenue weight
}

export interface EnergyDispatchDecision {
  timestamp: string; // HH:MM
  action: OptimisationAction;
  batteryPowerKW: number; // + is charging, - is discharging
  gridPowerKW: number; // + is import, - is export
  solarPowerKW: number;
  houseLoadKW: number;
  motorPowerKW: number;
  regenPowerKW: number;
  socPct: number;
  sohPct: number;
  packTempC: number;
  spotPrice: number;
  energyCostStepGbp: number;
  degradationCostStepGbp: number;
  v2gRevenueStepGbp: number;
  netCostStepGbp: number;
  recommendationReason: string;
}

export interface SimulationState {
  timeStepMinutes: number;
  currentTimeMinutes: number;
  isLiveRunning: boolean;
  playbackSpeed: number; // 1x, 10x, 100x
  departureTimeMinutes: number; // e.g. 07:30 = 450 min
  targetSocPct: number; // e.g. 80%
  chemistry: BatteryChemistry;
  vehicleConfig: VehiclePhysicsConfig;
  marketState: ElectricityMarketState;
  weights: ObjectiveCoefficients;
  currentSocPct: number;
  currentSohPct: number;
  currentTempC: number;
  totalEnergyCostGbp: number;
  totalDegradationCostGbp: number;
  totalV2GRevenueGbp: number;
  todayEfficiencyPct: number;
  dispatchHistory: EnergyDispatchDecision[];
}

export interface MonteCarloResult {
  percentiles: {
    p10: number[];
    p50: number[];
    p90: number[];
  };
  timeAxisDays: number[];
  metricName: 'Total Cost (£)' | 'Battery SOH (%)' | 'Lifetime Energy (MWh)' | 'V2G Net Revenue (£)';
  summaryStats: {
    meanCost: number;
    stdDev: number;
    sohLoss5YearP50: number;
    sohLoss5YearP10: number;
    v2gProfitAnnualP50: number;
  };
}

export interface ScenarioDefinition {
  id: string;
  name: string;
  description: string;
  batteryCapacityKWh: number;
  initialSocPct: number;
  targetSocPct: number;
  departureTimeStr: string;
  solarKw: number;
  houseKw: number;
  gridSpotPrice: number;
  nightSpotPrice: number;
  ambientTempC: number;
  chemistryType: BatteryChemistryType;
}

export interface CodeFileNode {
  path: string;
  name: string;
  language: 'rust' | 'r' | 'toml' | 'markdown';
  layer: 'rust-core' | 'rust-battery' | 'rust-electrical' | 'rust-vehicle' | 'rust-charging' | 'rust-regeneration' | 'rust-energy' | 'rust-market' | 'rust-optimisation' | 'rust-telemetry' | 'r-models' | 'r-optimisation' | 'r-markets' | 'r-analysis' | 'r-scenarios';
  code: string;
  description: string;
}
