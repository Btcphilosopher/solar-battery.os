/**
 * EV-ENERGY-OPT Electrochemical Battery Physics & Degradation Engine
 * Implements physically meaningful battery equations for NMC and LFP chemistries.
 */

import { BatteryChemistry } from '../types';

export const PRESET_CHEMISTRIES: Record<string, BatteryChemistry> = {
  NMC: {
    name: 'Lithium Nickel Manganese Cobalt Oxide (NMC-811)',
    type: 'NMC',
    nominalVoltage: 350, // V pack nominal (96S)
    maxVoltage: 410, // V max
    minVoltage: 280, // V min cutoff
    capacityKWh: 75.0, // kWh
    maxChargeCRate: 2.5, // 2.5C fast charge (~187.5 kW)
    maxDischargeCRate: 4.0, // 4C peak discharge (~300 kW)
    internalResistanceOm: 0.035, // 35 mΩ pack resistance
    thermalMassJPerK: 450000, // 450 kJ/K thermal capacity
    cycleLife80DOD: 2200, // 2200 cycles to 80% SOH
    calendarAgingRatePerYr: 1.8, // 1.8% SOH/yr at 25°C
    degradationCostPerPctSoh: 140.0, // £140 per 1% SOH loss on £14,000 pack
    arrheniusActivationEnergy: 32.5, // kJ/mol
    optimalTempRange: [15, 32],
  },
  LFP: {
    name: 'Lithium Iron Phosphate (LFP / LiFePO4)',
    type: 'LFP',
    nominalVoltage: 320, // V pack nominal (100S)
    maxVoltage: 365, // V max
    minVoltage: 250, // V min cutoff
    capacityKWh: 60.0, // kWh
    maxChargeCRate: 1.8, // 1.8C fast charge (~108 kW)
    maxDischargeCRate: 3.5, // 3.5C discharge (~210 kW)
    internalResistanceOm: 0.042, // 42 mΩ pack resistance
    thermalMassJPerK: 520000, // 520 kJ/K high thermal mass
    cycleLife80DOD: 5500, // 5500 cycles to 80% SOH (Extremely durable)
    calendarAgingRatePerYr: 0.8, // 0.8% SOH/yr at 25°C
    degradationCostPerPctSoh: 90.0, // £90 per 1% SOH loss on £9,000 pack
    arrheniusActivationEnergy: 28.0, // kJ/mol lower thermal sensitivity
    optimalTempRange: [10, 40],
  },
};

/**
 * Calculates Open Circuit Voltage (OCV) as a function of SOC
 */
export function calculateOCV(socPct: number, chemistry: BatteryChemistry): number {
  const soc = Math.max(0.01, Math.min(0.99, socPct / 100));
  if (chemistry.type === 'LFP') {
    // LFP has a famously flat OCV plateau between 20% and 80%
    if (soc < 0.1) return chemistry.minVoltage + (soc / 0.1) * 20;
    if (soc > 0.9) return chemistry.nominalVoltage + 25 + ((soc - 0.9) / 0.1) * (chemistry.maxVoltage - (chemistry.nominalVoltage + 25));
    return chemistry.nominalVoltage + (soc - 0.5) * 8.0; // flat plateau
  } else {
    // NMC has a steeper linear slope
    return chemistry.minVoltage + soc * (chemistry.maxVoltage - chemistry.minVoltage);
  }
}

/**
 * Temperature-dependent internal resistance R_int(SOC, Temp)
 */
export function calculateInternalResistance(
  socPct: number,
  tempC: number,
  chemistry: BatteryChemistry
): number {
  const baseR = chemistry.internalResistanceOm;
  // Arrhenius factor for R_int (increases rapidly below 10°C)
  const tempK = tempC + 273.15;
  const refTempK = 298.15; // 25°C
  const tempFactor = Math.exp(1200 * (1 / tempK - 1 / refTempK));

  // Extreme SOC penalty
  let socFactor = 1.0;
  if (socPct < 15) socFactor += (15 - socPct) * 0.03;
  if (socPct > 90) socFactor += (socPct - 90) * 0.02;

  return baseR * tempFactor * socFactor;
}

/**
 * Calculates battery heat generation: Q_gen = I^2 * R + I * T * (dE/dT)
 */
export function calculateHeatGenerationW(
  currentA: number,
  socPct: number,
  tempC: number,
  chemistry: BatteryChemistry
): number {
  const rInt = calculateInternalResistance(socPct, tempC, chemistry);
  const jouleHeat = Math.pow(currentA, 2) * rInt;
  
  // Entropic heat coefficient dE/dT ~ -0.15 mV/K for NMC, -0.05 mV/K for LFP
  const dEdT = chemistry.type === 'NMC' ? -0.00015 : -0.00005;
  const tempK = tempC + 273.15;
  const entropicHeat = currentA * tempK * dEdT;

  return Math.max(0, jouleHeat + entropicHeat);
}

/**
 * Step thermal model: updates battery temperature over durationMinutes
 */
export function updateBatteryTemperature(
  currentTempC: number,
  ambientTempC: number,
  heatGenW: number,
  coolingPowerKW: number,
  durationMinutes: number,
  chemistry: BatteryChemistry
): { newTempC: number; coolingEnergyKWh: number } {
  const durationSec = durationMinutes * 60;
  const convectiveCoeff = 35.0; // W/K ambient heat exchange coefficient

  const netPowerW = heatGenW - coolingPowerKW * 1000 - convectiveCoeff * (currentTempC - ambientTempC);
  const deltaTemp = (netPowerW * durationSec) / chemistry.thermalMassJPerK;

  const newTempC = Math.max(-20, Math.min(75, currentTempC + deltaTemp));
  const coolingEnergyKWh = (coolingPowerKW * durationMinutes) / 60;

  return { newTempC, coolingEnergyKWh };
}

/**
 * Calculates physical degradation (% SOH loss) & economic cost (£) for a step
 */
export function calculateStepDegradation(
  powerKW: number, // + for charge, - for discharge
  currentSocPct: number,
  tempC: number,
  durationMinutes: number,
  chemistry: BatteryChemistry
): { sohLossPct: number; degradationCostGbp: number } {
  const durationHours = durationMinutes / 8760; // fraction of year
  const ocv = calculateOCV(currentSocPct, chemistry);
  const currentA = ocv > 0 ? (powerKW * 1000) / ocv : 0;
  const cRate = Math.abs(powerKW) / chemistry.capacityKWh;

  // 1. Arrhenius Thermal Factor
  const tempK = Math.max(253, tempC + 273.15); // limit lower bound for formula sanity
  const refTempK = 298.15; // 25°C
  const R = 8.314; // J/(mol·K)
  const thermalFactor = Math.exp((chemistry.arrheniusActivationEnergy * 1000 / R) * (1 / refTempK - 1 / tempK));

  // 2. Calendar Degradation (% SOH)
  const socExponent = chemistry.type === 'NMC' ? 0.8 : 0.4;
  const calendarSohLoss = chemistry.calendarAgingRatePerYr * durationHours * thermalFactor * (1 + socExponent * (currentSocPct / 100));

  // 3. Cycle Degradation (% SOH)
  let cycleSohLoss = 0;
  if (Math.abs(powerKW) > 0.1) {
    const throughputKWh = (Math.abs(powerKW) * durationMinutes) / 60;
    const equivalentCycles = throughputKWh / (2 * chemistry.capacityKWh);
    const cRateFactor = Math.pow(Math.max(1, cRate), 0.6);
    
    // Depth of Discharge stress factor (high SOC charging causes lithium plating)
    let dodStress = 1.0;
    if (powerKW > 0 && currentSocPct > 80) {
      dodStress += (currentSocPct - 80) * 0.08; // heavy degradation charging near 100%
    }

    cycleSohLoss = (equivalentCycles / chemistry.cycleLife80DOD) * 20.0 * cRateFactor * dodStress * Math.max(1, thermalFactor);
  }

  const sohLossPct = calendarSohLoss + cycleSohLoss;
  const degradationCostGbp = sohLossPct * chemistry.degradationCostPerPctSoh;

  return { sohLossPct, degradationCostGbp };
}
