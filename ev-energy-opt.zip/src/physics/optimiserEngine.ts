/**
 * EV-ENERGY-OPT Multi-Objective Optimization & Dispatch Engine
 * Formulates objective cost function and computes optimal energy routing under physical safety constraints.
 */

import {
  BatteryChemistry,
  ElectricityMarketState,
  EnergyDispatchDecision,
  ObjectiveCoefficients,
  OptimisationAction,
  VehiclePhysicsConfig,
} from '../types';
import { calculateOCV, calculateStepDegradation, updateBatteryTemperature } from './batteryEngine';

export interface OptimiserInput {
  timeStepMinutes: number; // e.g. 15 mins
  currentTimeMinutes: number; // 0..1439
  departureTimeMinutes: number; // e.g. 450 (07:30)
  targetSocPct: number; // e.g. 80%
  currentSocPct: number;
  currentSohPct: number;
  currentTempC: number;
  ambientTempC: number;
  chemistry: BatteryChemistry;
  vehicleConfig: VehiclePhysicsConfig;
  marketState: ElectricityMarketState;
  weights: ObjectiveCoefficients;
  isDriving: boolean;
  vehicleDemandKW: number;
}

/**
 * Calculates total objective cost function for a candidate power dispatch
 * Objective = α * EnergyCost + β * DegradationCost + γ * ThermalCost + δ * GridStress - ε * MarketRevenue
 */
export function evaluateCandidateDispatchCost(
  candidateBatteryPowerKW: number, // + for charge, - for discharge
  candidateGridPowerKW: number, // + for import, - for export
  candidateSolarKW: number,
  candidateHouseKW: number,
  input: OptimiserInput
): {
  totalObjectiveCost: number;
  energyCostGbp: number;
  degradationCostGbp: number;
  v2gRevenueGbp: number;
  isFeasible: boolean;
  violationReason?: string;
} {
  const {
    timeStepMinutes,
    currentSocPct,
    currentTempC,
    ambientTempC,
    chemistry,
    marketState,
    weights,
  } = input;

  const durationHours = timeStepMinutes / 60;
  const ocv = calculateOCV(currentSocPct, chemistry);

  // 1. HARD SAFETY CONSTRAINTS CHECK
  // Voltage & C-rate check
  const cRate = Math.abs(candidateBatteryPowerKW) / chemistry.capacityKWh;
  if (candidateBatteryPowerKW > 0 && cRate > chemistry.maxChargeCRate) {
    return { totalObjectiveCost: Infinity, energyCostGbp: 0, degradationCostGbp: 0, v2gRevenueGbp: 0, isFeasible: false, violationReason: 'Exceeds Max Charge C-Rate' };
  }
  if (candidateBatteryPowerKW < 0 && cRate > chemistry.maxDischargeCRate) {
    return { totalObjectiveCost: Infinity, energyCostGbp: 0, degradationCostGbp: 0, v2gRevenueGbp: 0, isFeasible: false, violationReason: 'Exceeds Max Discharge C-Rate' };
  }

  // SOC Boundary check
  const deltaSocPct = ((candidateBatteryPowerKW * durationHours) / chemistry.capacityKWh) * 100 * 0.94;
  const nextSoc = currentSocPct + deltaSocPct;
  if (nextSoc < 10.0 || nextSoc > 98.0) {
    return { totalObjectiveCost: Infinity, energyCostGbp: 0, degradationCostGbp: 0, v2gRevenueGbp: 0, isFeasible: false, violationReason: 'SOC Boundary Violation (10%-98%)' };
  }

  // Temperature safety cutoff
  if (currentTempC > 52.0 || currentTempC < -10.0) {
    return { totalObjectiveCost: Infinity, energyCostGbp: 0, degradationCostGbp: 0, v2gRevenueGbp: 0, isFeasible: false, violationReason: 'Thermal Safety Lockout' };
  }

  // 2. ECONOMIC COMPONENTS
  let energyCostGbp = 0;
  let v2gRevenueGbp = 0;

  if (candidateGridPowerKW > 0) {
    // Grid Import
    energyCostGbp = candidateGridPowerKW * durationHours * marketState.spotPriceGbpKWh;
  } else if (candidateGridPowerKW < 0) {
    // Grid Export (V2G / Solar Export)
    const exportPrice = marketState.spotPriceGbpKWh * 0.92; // 8% market fee
    v2gRevenueGbp = Math.abs(candidateGridPowerKW) * durationHours * exportPrice;
  }

  // 3. BATTERY DEGRADATION COST
  const degradation = calculateStepDegradation(
    candidateBatteryPowerKW,
    currentSocPct,
    currentTempC,
    timeStepMinutes,
    chemistry
  );
  const degradationCostGbp = degradation.degradationCostGbp;

  // 4. THERMAL HVAC COST
  const coolingKW = currentTempC > 35 ? 2.5 : 0;
  const thermalCostGbp = coolingKW * durationHours * marketState.spotPriceGbpKWh;

  // 5. GRID STRESS PENALTY
  const gridStressGbp = (candidateGridPowerKW > 7.0 ? 0.05 : 0.0) * durationHours;

  // 6. TOTAL OBJECTIVE FUNCTION EVALUATION
  const totalObjectiveCost =
    weights.alphaEnergyCost * energyCostGbp +
    weights.betaDegradation * degradationCostGbp +
    weights.gammaThermal * thermalCostGbp +
    weights.deltaGridStress * gridStressGbp -
    weights.epsilonV2GRevenue * v2gRevenueGbp;

  return {
    totalObjectiveCost,
    energyCostGbp,
    degradationCostGbp,
    v2gRevenueGbp,
    isFeasible: true,
  };
}

/**
 * Computes optimal dispatch decision for the current simulation step
 */
export function computeOptimalDispatch(input: OptimiserInput): EnergyDispatchDecision {
  const {
    currentTimeMinutes,
    departureTimeMinutes,
    targetSocPct,
    currentSocPct,
    currentSohPct,
    currentTempC,
    ambientTempC,
    chemistry,
    marketState,
    isDriving,
    vehicleDemandKW,
  } = input;

  const hoursToDeparture = (departureTimeMinutes - currentTimeMinutes) / 60;
  const socDeficitPct = Math.max(0, targetSocPct - currentSocPct);

  // If driving, vehicle demand dictates battery discharge or regen recovery
  if (isDriving) {
    const batteryPowerKW = vehicleDemandKW; // + for discharge demand, - for regen
    const action: OptimisationAction = vehicleDemandKW < 0 ? 'REGENERATE' : 'HOLD';
    const degradation = calculateStepDegradation(batteryPowerKW, currentSocPct, currentTempC, input.timeStepMinutes, chemistry);

    return {
      timestamp: formatTimeMinutes(currentTimeMinutes),
      action,
      batteryPowerKW: Number(batteryPowerKW.toFixed(2)),
      gridPowerKW: 0,
      solarPowerKW: 0,
      houseLoadKW: 0,
      motorPowerKW: Math.max(0, vehicleDemandKW),
      regenPowerKW: Math.max(0, -vehicleDemandKW),
      socPct: Number((currentSocPct - (batteryPowerKW * (input.timeStepMinutes / 60) / chemistry.capacityKWh) * 100).toFixed(2)),
      sohPct: Number((currentSohPct - degradation.sohLossPct).toFixed(4)),
      packTempC: Number(currentTempC.toFixed(1)),
      spotPrice: marketState.spotPriceGbpKWh,
      energyCostStepGbp: 0,
      degradationCostStepGbp: Number(degradation.degradationCostGbp.toFixed(4)),
      v2gRevenueStepGbp: 0,
      netCostStepGbp: Number(degradation.degradationCostGbp.toFixed(4)),
      recommendationReason: vehicleDemandKW < 0 ? 'Kinetic Energy Recovery (Regen)' : 'Vehicle Propulsion Driving',
    };
  }

  // Stationary optimization (Home / Charger)
  // Solar routing hierarchy: Solar -> House -> EV -> Grid
  const solarKW = marketState.solarGenerationKW;
  const houseKW = marketState.householdDemandKW;
  const solarSurplusKW = Math.max(0, solarKW - houseKW);

  // Urgent Charging Check: Must reach target SOC before departure
  const maxChargerKW = 7.4; // 7.4 kW home AC wallbox
  const hoursNeeded = (socDeficitPct / 100 * chemistry.capacityKWh) / (maxChargerKW * 0.92);

  let bestAction: OptimisationAction = 'HOLD';
  let bestBatteryPowerKW = 0;
  let bestGridPowerKW = 0;
  let lowestCost = Infinity;
  let bestReason = 'Hold battery (Awaiting lower overnight spot price)';

  // Mandatory charge if time buffer is tight
  if (hoursToDeparture > 0 && hoursToDeparture <= hoursNeeded * 1.05 && socDeficitPct > 1.0) {
    bestAction = 'CHARGE_GRID';
    bestBatteryPowerKW = maxChargerKW;
    bestGridPowerKW = Math.max(0, maxChargerKW + houseKW - solarKW);
    bestReason = `Urgent Departure Charge Target (${targetSocPct}% at ${formatTimeMinutes(departureTimeMinutes)})`;
  } else {
    // Evaluate candidate strategies:
    const candidates: Array<{
      action: OptimisationAction;
      batKW: number;
      gridKW: number;
      reason: string;
    }> = [
      { action: 'HOLD', batKW: 0, gridKW: Math.max(0, houseKW - solarKW), reason: 'Hold battery (Optimal economic threshold)' },
    ];

    // Candidate 1: Charge from Solar
    if (solarSurplusKW > 0.5) {
      const solarChargeKW = Math.min(maxChargerKW, solarSurplusKW);
      candidates.push({
        action: 'CHARGE_SOLAR',
        batKW: solarChargeKW,
        gridKW: 0,
        reason: 'Maximizing Solar Self-Consumption (Zero Carbon & Zero Cost)',
      });
    }

    // Candidate 2: Smart Charge from Grid (if spot price <= charge strike)
    if (marketState.spotPriceGbpKWh <= marketState.chargeStrikePrice) {
      candidates.push({
        action: 'CHARGE_GRID',
        batKW: maxChargerKW,
        gridKW: Math.max(0, maxChargerKW + houseKW - solarKW),
        reason: `Overnight Spot Price Trough (£${marketState.spotPriceGbpKWh.toFixed(2)}/kWh <= Strike £${marketState.chargeStrikePrice.toFixed(2)}/kWh)`,
      });
    }

    // Candidate 3: V2H Discharge (Power house load during peak price)
    if (marketState.spotPriceGbpKWh >= marketState.dischargeStrikePrice && currentSocPct > 35.0) {
      candidates.push({
        action: 'DISCHARGE_V2H',
        batKW: -houseKW,
        gridKW: 0,
        reason: `V2H Peak Shaving (£${marketState.spotPriceGbpKWh.toFixed(2)}/kWh >= Discharge Strike £${marketState.dischargeStrikePrice.toFixed(2)}/kWh)`,
      });
    }

    // Candidate 4: V2G Grid Export (Export at super peak)
    if (marketState.spotPriceGbpKWh >= marketState.dischargeStrikePrice + 0.08 && currentSocPct > 45.0) {
      const v2gExportKW = 6.0;
      candidates.push({
        action: 'DISCHARGE_V2G',
        batKW: -v2gExportKW,
        gridKW: -(v2gExportKW - Math.max(0, solarKW - houseKW)),
        reason: `V2G Energy Arbitrage Export (£${marketState.spotPriceGbpKWh.toFixed(2)}/kWh Super-Peak)`,
      });
    }

    for (const cand of candidates) {
      const evalRes = evaluateCandidateDispatchCost(cand.batKW, cand.gridKW, solarKW, houseKW, input);
      if (evalRes.isFeasible && evalRes.totalObjectiveCost < lowestCost) {
        lowestCost = evalRes.totalObjectiveCost;
        bestAction = cand.action;
        bestBatteryPowerKW = cand.batKW;
        bestGridPowerKW = cand.gridKW;
        bestReason = cand.reason;
      }
    }
  }

  // Calculate actual state step updates
  const durationHours = input.timeStepMinutes / 60;
  const deltaSoc = ((bestBatteryPowerKW * durationHours) / chemistry.capacityKWh) * 100 * 0.94;
  const nextSocPct = Math.max(5.0, Math.min(100.0, currentSocPct + deltaSoc));

  const degradation = calculateStepDegradation(bestBatteryPowerKW, currentSocPct, currentTempC, input.timeStepMinutes, chemistry);
  const nextSohPct = Math.max(50.0, currentSohPct - degradation.sohLossPct);

  // Update pack thermal state
  const ocv = calculateOCV(currentSocPct, chemistry);
  const currentA = ocv > 0 ? (bestBatteryPowerKW * 1000) / ocv : 0;
  const rInt = chemistry.internalResistanceOm;
  const heatW = Math.pow(currentA, 2) * rInt;
  const thermalRes = updateBatteryTemperature(currentTempC, ambientTempC, heatW, currentTempC > 35 ? 2.5 : 0, input.timeStepMinutes, chemistry);

  let stepEnergyCost = 0;
  let stepV2GRev = 0;
  if (bestGridPowerKW > 0) {
    stepEnergyCost = bestGridPowerKW * durationHours * marketState.spotPriceGbpKWh;
  } else if (bestGridPowerKW < 0) {
    stepV2GRev = Math.abs(bestGridPowerKW) * durationHours * (marketState.spotPriceGbpKWh * 0.92);
  }

  const netCostStep = stepEnergyCost + degradation.degradationCostGbp - stepV2GRev;

  return {
    timestamp: formatTimeMinutes(currentTimeMinutes),
    action: bestAction,
    batteryPowerKW: Number(bestBatteryPowerKW.toFixed(2)),
    gridPowerKW: Number(bestGridPowerKW.toFixed(2)),
    solarPowerKW: Number(solarKW.toFixed(2)),
    houseLoadKW: Number(houseKW.toFixed(2)),
    motorPowerKW: 0,
    regenPowerKW: 0,
    socPct: Number(nextSocPct.toFixed(2)),
    sohPct: Number(nextSohPct.toFixed(4)),
    packTempC: Number(thermalRes.newTempC.toFixed(1)),
    spotPrice: marketState.spotPriceGbpKWh,
    energyCostStepGbp: Number(stepEnergyCost.toFixed(4)),
    degradationCostStepGbp: Number(degradation.degradationCostGbp.toFixed(4)),
    v2gRevenueStepGbp: Number(stepV2GRev.toFixed(4)),
    netCostStepGbp: Number(netCostStep.toFixed(4)),
    recommendationReason: bestReason,
  };
}

function formatTimeMinutes(mins: number): string {
  const h = Math.floor(mins / 60) % 24;
  const m = Math.floor(mins % 60);
  return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
}
