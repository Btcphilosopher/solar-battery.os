/**
 * EV-ENERGY-OPT Electricity Market & Strike-Price Engine
 * Computes dynamic strike prices, spot price forecasts, grid carbon intensity, and solar curves.
 */

import { ElectricityMarketState } from '../types';

/**
 * Generates synthetic 24-hour spot price curve (£/kWh)
 */
export function generate24hPriceForecast(basePrice: number = 0.24): number[] {
  const prices: number[] = [];
  for (let hour = 0; hour < 24; hour++) {
    let multiplier = 1.0;
    if (hour >= 1 && hour <= 5) {
      // Overnight off-peak valley (e.g. £0.12 - £0.14)
      multiplier = 0.50 + Math.sin((hour - 1) / 4 * Math.PI) * 0.08;
    } else if (hour >= 7 && hour <= 9) {
      // Morning peak (e.g. £0.32)
      multiplier = 1.35;
    } else if (hour >= 11 && hour <= 15) {
      // Solar duck-curve midday drop (e.g. £0.16)
      multiplier = 0.70;
    } else if (hour >= 17 && hour <= 21) {
      // Evening super-peak demand (e.g. £0.38)
      multiplier = 1.55;
    } else {
      multiplier = 1.0;
    }
    // Add minor stochastic noise (+/- £0.02)
    const price = Math.max(0.04, basePrice * multiplier);
    prices.push(Number(price.toFixed(3)));
  }
  return prices;
}

/**
 * Generates solar generation curve (kW) for a given home PV array size (e.g. 6.8 kW peak)
 */
export function calculateSolarGenerationKW(hourFloat: number, peakSolarKW: number = 6.8): number {
  if (hourFloat < 6.0 || hourFloat > 20.0) return 0;
  // Sine curve centered at 13:00 (1 PM)
  const normTime = (hourFloat - 6.0) / 14.0;
  const sunElevation = Math.sin(normTime * Math.PI);
  return Math.max(0, peakSolarKW * Math.pow(sunElevation, 1.3));
}

/**
 * Generates typical UK/EU household demand profile (kW)
 */
export function calculateHouseholdDemandKW(hourFloat: number, baseDemandKW: number = 1.9): number {
  let factor = 0.5; // base night baseline
  if (hourFloat >= 6.5 && hourFloat <= 9.0) factor = 1.8; // morning routine
  else if (hourFloat > 9.0 && hourFloat < 17.0) factor = 0.9; // daytime quiet
  else if (hourFloat >= 17.0 && hourFloat <= 22.0) factor = 2.4; // evening cooking & HVAC peak
  else factor = 0.6; // night sleeping

  return baseDemandKW * factor;
}

/**
 * Calculates Strike Prices for automated charging and V2G discharging
 */
export function calculateStrikePrices(
  currentSpotPrice: number,
  batteryDegradationCostPerKWh: number,
  roundtripEfficiency: number = 0.90
): { chargeStrike: number; dischargeStrike: number } {
  // Charge Strike: Maximum price we are willing to pay for grid energy.
  // If spot price <= chargeStrike, charging is triggered.
  // Charge Strike = Average expected future price minus degradation offset.
  const chargeStrike = currentSpotPrice * 0.85;

  // Discharge Strike (V2G / V2H): Minimum price required to discharge into grid/house.
  // Discharge Strike = Spot price cost paid + (Degradation Cost / Roundtrip Efficiency) + Profit margin
  const dischargeStrike = currentSpotPrice + (batteryDegradationCostPerKWh / roundtripEfficiency) + 0.05;

  return {
    chargeStrike: Number(chargeStrike.toFixed(3)),
    dischargeStrike: Number(dischargeStrike.toFixed(3)),
  };
}

/**
 * Formulates current market state for the given hour float (0.0 to 24.0)
 */
export function getCurrentMarketState(
  hourFloat: number,
  peakSolarKW: number = 6.8,
  basePriceGbp: number = 0.24
): ElectricityMarketState {
  const forecastPrices = generate24hPriceForecast(basePriceGbp);
  const hourIdx = Math.floor(hourFloat) % 24;
  const spotPriceGbpKWh = forecastPrices[hourIdx];

  const solarGenerationKW = calculateSolarGenerationKW(hourFloat, peakSolarKW);
  const householdDemandKW = calculateHouseholdDemandKW(hourFloat);

  const { chargeStrike, dischargeStrike } = calculateStrikePrices(spotPriceGbpKWh, 0.025, 0.91);

  // Carbon intensity: high during evening fossil peaks, low during solar midday & wind night
  let gridCarbonIntensityGPerKWh = 160;
  if (hourFloat >= 11 && hourFloat <= 15) gridCarbonIntensityGPerKWh = 65; // High solar
  else if (hourFloat >= 17 && hourFloat <= 21) gridCarbonIntensityGPerKWh = 290; // Gas peakers

  return {
    spotPriceGbpKWh,
    forecastPrices,
    chargeStrikePrice: chargeStrike,
    dischargeStrikePrice: dischargeStrike,
    gridCarbonIntensityGPerKWh,
    gridDemandMW: 32000 + Math.sin((hourFloat - 7) / 12 * Math.PI) * 12000,
    solarIrradianceWM2: solarGenerationKW * 120,
    solarGenerationKW: Number(solarGenerationKW.toFixed(2)),
    householdDemandKW: Number(householdDemandKW.toFixed(2)),
  };
}
