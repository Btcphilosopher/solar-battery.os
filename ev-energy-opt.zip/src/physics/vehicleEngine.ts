/**
 * EV-ENERGY-OPT Vehicle Physics & Dynamics Engine
 * Calculates power demand and regenerative energy recovery directly from physical equations.
 */

import { VehiclePhysicsConfig } from '../types';

export const DEFAULT_VEHICLE_CONFIG: VehiclePhysicsConfig = {
  massKg: 1950, // 1950 kg EV (e.g. Model 3 / Ioniq 5 class)
  dragCoefficient: 0.23, // Cd (aerodynamic streamliner)
  frontalAreaM2: 2.25, // A (m²)
  rollingResistanceCoeff: 0.010, // Crr (low rolling resistance EV tyres)
  drivetrainEfficiency: 0.95, // Gearbox/differential efficiency
  motorEfficiencyPeak: 0.96, // PMSM motor peak efficiency
  regenMaxPowerKW: 75.0, // kW max regen capability
  auxiliaryLoadKW: 0.65, // Electronics, displays, pumps (650 W)
  hvacTargetTempC: 21.0, // °C comfortable cabin temperature
  cabinTempC: 28.0, // Initial cabin temp
};

export interface DrivingConditions {
  speedKmH: number; // km/h
  accelerationMs2: number; // m/s²
  gradientPct: number; // % slope (e.g. +3% uphill, -4% downhill)
  ambientTempC: number; // °C
  headwindKmH: number; // km/h
}

export interface VehiclePowerBreakdown {
  aerodynamicPowerKW: number;
  rollingResistancePowerKW: number;
  gradientPowerKW: number;
  accelerationPowerKW: number;
  tractivePowerKW: number;
  motorElectricalPowerKW: number;
  hvacPowerKW: number;
  auxPowerKW: number;
  totalBatteryDemandKW: number; // + for discharge demand, - for regen charging
  regenRecoveredKW: number;
  frictionBrakePowerKW: number;
  efficiencyWhPerKm: number;
}

/**
 * Calculates HVAC electrical power demand based on cabin thermal deficit
 */
export function calculateHVACPowerKW(cabinTempC: number, targetTempC: number, ambientTempC: number): number {
  const deltaTemp = Math.abs(cabinTempC - targetTempC);
  if (deltaTemp < 0.5) return 0.2; // minimal maintenance fan power

  // Heat pump COP ~ 3.2 for heating down to 0°C, COP ~ 2.8 for AC cooling
  const cop = ambientTempC < targetTempC ? 3.2 : 2.8;
  const thermalLossW = deltaTemp * 180.0; // 180 W/K cabin thermal conductivity
  const electricalPowerKW = (thermalLossW / cop) / 1000.0;

  return Math.max(0.2, Math.min(6.0, electricalPowerKW));
}

/**
 * Computes instantaneous vehicle power demand and regen breakdown
 */
export function calculateVehiclePower(
  conditions: DrivingConditions,
  config: VehiclePhysicsConfig = DEFAULT_VEHICLE_CONFIG
): VehiclePowerBreakdown {
  const { speedKmH, accelerationMs2, gradientPct, ambientTempC, headwindKmH } = conditions;
  const vRel = Math.max(0, (speedKmH + headwindKmH) * (1000 / 3600)); // m/s relative wind
  const vSpeed = Math.max(0, speedKmH * (1000 / 3600)); // m/s ground speed
  const g = 9.81; // m/s²
  const rhoAir = 1.225; // kg/m³ air density

  // 1. Aerodynamic Drag Force: F_drag = 0.5 * rho * Cd * A * vRel²
  const fDrag = 0.5 * rhoAir * config.dragCoefficient * config.frontalAreaM2 * Math.pow(vRel, 2);

  // 2. Rolling Resistance Force: F_roll = m * g * Crr * cos(theta)
  const slopeRad = Math.atan(gradientPct / 100);
  const fRoll = config.massKg * g * config.rollingResistanceCoeff * Math.cos(slopeRad);

  // 3. Gradient Force: F_grad = m * g * sin(theta)
  const fGrad = config.massKg * g * Math.sin(slopeRad);

  // 4. Inertial Acceleration Force: F_accel = m * a
  const fAccel = config.massKg * accelerationMs2;

  // Total Tractive Force at Wheels
  const fTotal = fDrag + fRoll + fGrad + fAccel;
  const tractivePowerKW = (fTotal * vSpeed) / 1000.0; // kW

  // Breakdown powers for UI physics rendering
  const aeroPowerKW = (fDrag * vSpeed) / 1000.0;
  const rollPowerKW = (fRoll * vSpeed) / 1000.0;
  const gradPowerKW = (fGrad * vSpeed) / 1000.0;
  const accelPowerKW = (fAccel * vSpeed) / 1000.0;

  let motorElectricalPowerKW = 0;
  let regenRecoveredKW = 0;
  let frictionBrakePowerKW = 0;

  if (tractivePowerKW >= 0) {
    // Propulsion Mode (Accelerating or Cruising)
    const combinedEfficiency = config.motorEfficiencyPeak * config.drivetrainEfficiency;
    motorElectricalPowerKW = tractivePowerKW / combinedEfficiency;
  } else {
    // Deceleration / Downhill Regenerative Braking Mode
    const rawKineticKW = Math.abs(tractivePowerKW);
    const regenEfficiency = config.motorEfficiencyPeak * config.drivetrainEfficiency * 0.90; // regen conversion
    const idealRegenKW = rawKineticKW * regenEfficiency;

    if (idealRegenKW <= config.regenMaxPowerKW) {
      regenRecoveredKW = idealRegenKW;
      frictionBrakePowerKW = 0;
    } else {
      // Exceeds max regen hardware limit -> mechanical friction brakes substitute remainder
      regenRecoveredKW = config.regenMaxPowerKW;
      frictionBrakePowerKW = rawKineticKW - (config.regenMaxPowerKW / regenEfficiency);
    }
    motorElectricalPowerKW = -regenRecoveredKW; // negative demand = battery charging
  }

  // Auxiliary and HVAC loads
  const hvacPowerKW = calculateHVACPowerKW(config.cabinTempC, config.hvacTargetTempC, ambientTempC);
  const auxPowerKW = config.auxiliaryLoadKW;

  const totalBatteryDemandKW = motorElectricalPowerKW + hvacPowerKW + auxPowerKW;

  // Efficiency in Wh/km (only valid when vehicle is moving)
  const efficiencyWhPerKm = speedKmH > 2.0 
    ? (totalBatteryDemandKW * 1000) / speedKmH 
    : 0;

  return {
    aerodynamicPowerKW: Math.max(0, aeroPowerKW),
    rollingResistancePowerKW: Math.max(0, rollPowerKW),
    gradientPowerKW: gradPowerKW,
    accelerationPowerKW: accelPowerKW,
    tractivePowerKW,
    motorElectricalPowerKW,
    hvacPowerKW,
    auxPowerKW,
    totalBatteryDemandKW,
    regenRecoveredKW,
    frictionBrakePowerKW,
    efficiencyWhPerKm: Math.max(0, efficiencyWhPerKm),
  };
}
