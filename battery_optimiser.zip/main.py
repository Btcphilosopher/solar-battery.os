"""
main.py — Battery Intelligence Engine Entry Point
==================================================
Wires every subsystem together and manages the full engine lifecycle:

  1. Initialise shared infrastructure (DataBus, Database, Cache, Settings)
  2. Create all monitors, optimisers, analytics, and learning modules
  3. Register the WebSocket subscriber with the DataBus
  4. Start all background coroutines as asyncio tasks
  5. Run the FastAPI/uvicorn server
  6. Graceful shutdown on SIGINT / SIGTERM

Usage::

    python main.py                  # Start with default config
    BIE_PORT=9000 python main.py    # Override API port
    BIE_DEBUG=true python main.py   # Enable verbose logging

The engine is designed to be self-contained:
  • All data flows through the DataBus (no direct cross-module calls)
  • Database handles persistence; Cache handles hot reads
  • Every module can fail independently without crashing the engine
"""

from __future__ import annotations

import asyncio
import signal
import sys
from typing import List

import uvicorn

from utils.config import CONFIG
from utils.data_bus import DataBus
from utils.logger import get_logger

# Storage
from storage.database import Database
from storage.cache import Cache
from storage.settings import Settings

# Monitoring
from monitoring.battery_monitor import BatteryMonitor
from monitoring.cpu_monitor import CPUMonitor
from monitoring.memory_monitor import MemoryMonitor
from monitoring.network_monitor import NetworkMonitor
from monitoring.process_monitor import ProcessMonitor

# Optimisation
from optimisation.battery_optimizer import BatteryOptimizer
from optimisation.cpu_optimizer import CPUOptimizer
from optimisation.memory_optimizer import MemoryOptimizer
from optimisation.network_optimizer import NetworkOptimizer
from optimisation.background_scheduler import BackgroundScheduler
from optimisation.thermal_manager import ThermalManager

# Analytics
from analytics.usage_analyser import UsageAnalyser
from analytics.prediction_engine import PredictionEngine
from analytics.anomaly_detector import AnomalyDetector
from analytics.battery_statistics import BatteryStatisticsEngine
from analytics.reporting import ReportingEngine

# Learning
from learning.habit_learning import HabitLearner
from learning.workload_prediction import WorkloadPredictor
from learning.recommendation_engine import RecommendationEngine

# API
from api.api_server import create_app
from api.websocket import manager as ws_manager, on_bus_update

log = get_logger(__name__)


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------

class BatteryIntelligenceEngine:
    """
    Top-level orchestrator for the Battery Intelligence Engine.

    Manages the full lifecycle: build → start → run → shutdown.
    """

    def __init__(self) -> None:
        self._tasks: List[asyncio.Task] = []
        self._running = False

        # --- Shared infrastructure ---
        self.bus = DataBus()
        self.db = Database(
            db_path=CONFIG.storage.db_path,
            fallback_path=CONFIG.storage.fallback_db_path,
        )
        self.cache = Cache(
            max_entries=CONFIG.storage.max_cache_entries,
            default_ttl=float(CONFIG.storage.cache_ttl_seconds),
        )
        self.settings = Settings()

        # --- Monitoring ---
        self.battery_monitor = BatteryMonitor(self.bus, self.db, CONFIG)
        self.cpu_monitor = CPUMonitor(self.bus, self.db, CONFIG)
        self.memory_monitor = MemoryMonitor(self.bus, self.db, CONFIG)
        self.network_monitor = NetworkMonitor(self.bus, self.db, CONFIG)
        self.process_monitor = ProcessMonitor(self.bus, self.db, CONFIG)
        self.thermal_manager = ThermalManager(self.bus, self.db, CONFIG)

        # --- Optimisation ---
        self.battery_optimizer = BatteryOptimizer(self.bus, self.settings, CONFIG)
        self.cpu_optimizer = CPUOptimizer(self.bus, self.settings, CONFIG)
        self.memory_optimizer = MemoryOptimizer(
            self.bus, self.settings, self.memory_monitor, CONFIG
        )
        self.network_optimizer = NetworkOptimizer(self.bus, self.settings, CONFIG)
        self.scheduler = BackgroundScheduler(self.bus, self.settings, CONFIG)

        # --- Analytics ---
        self.usage_analyser = UsageAnalyser(
            self.bus, self.db, self.process_monitor, CONFIG
        )
        self.prediction_engine = PredictionEngine(self.bus, self.db, CONFIG)
        self.anomaly_detector = AnomalyDetector(self.bus, self.db, CONFIG)
        self.stats_engine = BatteryStatisticsEngine(self.bus, self.db, CONFIG)
        self.reporter = ReportingEngine(self.bus, self.db)

        # --- Learning ---
        self.habit_learner = HabitLearner(self.bus, self.db, CONFIG)
        self.workload_predictor = WorkloadPredictor(
            self.bus, self.db, self.habit_learner, CONFIG
        )
        self.rec_engine = RecommendationEngine(
            self.bus, self.habit_learner, self.workload_predictor, CONFIG
        )

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def start(self) -> None:
        """Initialise all services and begin background processing."""
        log.info("=" * 60)
        log.info("  SOVEREIGN OS — BATTERY INTELLIGENCE ENGINE")
        log.info("=" * 60)
        log.info("Starting engine...")

        # Open persistent storage
        await self.db.connect()
        await self.settings.load()

        # Subscribe WebSocket manager to DataBus updates
        self.bus.subscribe(on_bus_update)

        # Register scheduled maintenance tasks with the scheduler
        # (default engine jobs registered in __init__ of BackgroundScheduler)

        # Launch background coroutines
        self._spawn_tasks()

        self._running = True
        log.info("Engine running.  API → http://%s:%d", CONFIG.api.host, CONFIG.api.port)

    async def stop(self) -> None:
        """Cancel all background tasks and close storage."""
        if not self._running:
            return
        log.info("Shutting down Battery Intelligence Engine...")
        self._running = False

        for task in self._tasks:
            task.cancel()
        if self._tasks:
            await asyncio.gather(*self._tasks, return_exceptions=True)
        self._tasks.clear()

        await self.db.close()
        log.info("Engine stopped cleanly.")

    # ------------------------------------------------------------------
    # Task spawning
    # ------------------------------------------------------------------

    def _spawn(self, coro, name: str) -> asyncio.Task:
        """Create a named asyncio task with a restart-on-crash wrapper."""
        async def _guarded():
            while True:
                try:
                    await coro()
                except asyncio.CancelledError:
                    break
                except Exception as exc:
                    log.error("Task %s crashed: %s — restarting in 5s", name, exc, exc_info=True)
                    await asyncio.sleep(5)
        task = asyncio.create_task(_guarded(), name=name)
        self._tasks.append(task)
        return task

    def _spawn_tasks(self) -> None:
        """Register all background coroutines as asyncio tasks."""
        # Monitors
        self._spawn(self.battery_monitor.start, "battery_monitor")
        self._spawn(self.cpu_monitor.start, "cpu_monitor")
        self._spawn(self.memory_monitor.start, "memory_monitor")
        self._spawn(self.network_monitor.start, "network_monitor")
        self._spawn(self.process_monitor.start, "process_monitor")
        self._spawn(self.thermal_manager.start, "thermal_manager")

        # Optimisers (conditionally)
        if CONFIG.enable_optimisation:
            self._spawn(self.battery_optimizer.start, "battery_optimizer")
            self._spawn(self.cpu_optimizer.start, "cpu_optimizer")
            self._spawn(self.memory_optimizer.start, "memory_optimizer")
            self._spawn(self.network_optimizer.start, "network_optimizer")
            self._spawn(self.scheduler.start, "background_scheduler")

        # Analytics
        self._spawn(self.prediction_engine.start, "prediction_engine")
        self._spawn(self.anomaly_detector.start, "anomaly_detector")
        self._spawn(self.stats_engine.start, "stats_engine")
        self._spawn(self.usage_analyser.start, "usage_analyser")

        # Learning (conditionally)
        if CONFIG.enable_learning:
            self._spawn(self.habit_learner.start, "habit_learner")
            self._spawn(self.workload_predictor.start, "workload_predictor")
            self._spawn(self.rec_engine.start, "recommendation_engine")

        # Periodic data purge (daily)
        async def _purge_loop():
            while True:
                await asyncio.sleep(
                    CONFIG.storage.cleanup_interval_hours * 3600
                )
                await self.db.purge_old_data(CONFIG.storage.data_retention_days)

        self._tasks.append(asyncio.create_task(_purge_loop(), name="data_purge"))

        log.info("Spawned %d background tasks.", len(self._tasks))

    # ------------------------------------------------------------------
    # FastAPI app
    # ------------------------------------------------------------------

    def build_app(self):
        """Build and return the FastAPI application with bound services."""
        return create_app({
            "data_bus": self.bus,
            "db": self.db,
            "settings": self.settings,
            "reporter": self.reporter,
            "recommendation_engine": self.rec_engine,
            "scheduler": self.scheduler,
        })


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

async def _main() -> None:
    engine = BatteryIntelligenceEngine()

    # Graceful shutdown on SIGINT / SIGTERM
    loop = asyncio.get_event_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(
            sig,
            lambda: asyncio.create_task(engine.stop()),
        )

    await engine.start()
    app = engine.build_app()

    cfg = uvicorn.Config(
        app=app,
        host=CONFIG.api.host,
        port=CONFIG.api.port,
        log_level="debug" if CONFIG.debug_mode else "warning",
        access_log=CONFIG.debug_mode,
        # Disable uvicorn's own signal handling — we manage it above
        use_colors=True,
    )
    server = uvicorn.Server(cfg)

    try:
        await server.serve()
    finally:
        await engine.stop()


if __name__ == "__main__":
    try:
        asyncio.run(_main())
    except KeyboardInterrupt:
        log.info("Keyboard interrupt — exiting.")
        sys.exit(0)
