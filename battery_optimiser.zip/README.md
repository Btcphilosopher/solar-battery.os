# Sovereign OS — Battery Intelligence Engine

A modular Python backend that continuously analyses OS activity and intelligently improves battery life without reducing the user experience.

---

## Architecture

```
battery_engine/
│
├── main.py                         ← Engine orchestrator + uvicorn entry point
│
├── utils/
│   ├── config.py                   ← Typed configuration (EngineConfig dataclasses)
│   ├── data_bus.py                 ← Central async pub/sub DataBus
│   ├── helpers.py                  ← EWMA, RollingStats, sysfs I/O, conversions
│   └── logger.py                   ← Rotating file + colour console logger
│
├── storage/
│   ├── database.py                 ← Async SQLite (aiosqlite) with WAL mode
│   ├── cache.py                    ← LRU + TTL in-memory cache
│   └── settings.py                 ← Persistent JSON settings
│
├── monitoring/                     ← Real-time polling loops
│   ├── battery_monitor.py          ← /sys/class/power_supply or psutil fallback
│   ├── cpu_monitor.py              ← cpufreq sysfs + psutil
│   ├── memory_monitor.py           ← /proc/meminfo + psutil
│   ├── network_monitor.py          ← psutil net_io_counters with rate derivation
│   └── process_monitor.py          ← Per-process energy estimation
│
├── optimisation/                   ← Rule-based recommendation engines
│   ├── battery_optimizer.py        ← Charging, temperature, profile, health checks
│   ├── cpu_optimizer.py            ← Governor, sustained load, idle window detection
│   ├── memory_optimizer.py         ← Pressure classification, swap, leak warnings
│   ├── network_optimizer.py        ← Background burst detection and batching advice
│   ├── background_scheduler.py     ← Constraint-based job scheduler (WorkManager-style)
│   └── thermal_manager.py          ← Multi-zone thermal monitoring and tiered alerts
│
├── analytics/
│   ├── usage_analyser.py           ← Hourly/daily drain profiles, app energy estimates
│   ├── prediction_engine.py        ← EWMA + numpy ridge regression battery life forecast
│   ├── anomaly_detector.py         ← Rolling z-score anomaly detection (5 metric streams)
│   ├── battery_statistics.py       ← Cycle counting, health scoring, efficiency metrics
│   └── reporting.py                ← On-demand structured reports for all subsystems
│
├── learning/
│   ├── habit_learning.py           ← Learns peak/sleep/charging hours from history
│   ├── workload_prediction.py      ← Cyclical-feature ridge regression drain predictor
│   └── recommendation_engine.py    ← Merges, enriches, and prioritises all recs
│
├── api/
│   ├── api_server.py               ← FastAPI factory with CORS + timing middleware
│   ├── routes.py                   ← 30+ REST endpoints for the Kotlin frontend
│   └── websocket.py                ← Real-time DataBus streaming to connected clients
│
└── tests/
    ├── conftest.py                 ← Async fixtures: in-memory DB, pre-seeded DataBus
    ├── test_utils.py               ← Config, EWMA, RollingStats, helpers, DataBus
    ├── test_storage.py             ← Cache LRU/TTL, Database CRUD, Settings persistence
    ├── test_monitoring.py          ← Monitors, optimisers, anomaly detection, statistics
    ├── test_api.py                 ← Full FastAPI integration tests (all endpoints)
    └── test_learning.py            ← Feature engineering, HabitLearner, RecommendationEngine
```

---

## Quick Start

### Install dependencies

```bash
pip install -r requirements.txt
```

### Run the engine

```bash
python main.py
```

The API starts at `http://127.0.0.1:8342`.  Interactive docs: `http://127.0.0.1:8342/docs`.

### Environment variables

| Variable | Default | Purpose |
|---|---|---|
| `BIE_HOST` | `127.0.0.1` | API bind address |
| `BIE_PORT` | `8342` | API port |
| `BIE_DB_PATH` | `/data/data/sovereign.os/battery_engine/battery.db` | SQLite path |
| `BIE_DEBUG` | `false` | Verbose logging |
| `BIE_LOG_DIR` | `/tmp/battery_engine_logs` | Log file directory |
| `BIE_LEARNING` | `true` | Enable ML habit learning |
| `BIE_OPT` | `true` | Enable optimisation recommendations |

---

## API Reference

### Battery

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/battery/status` | Current battery state |
| GET | `/api/v1/battery/health` | Health indicators and statistics |
| GET | `/api/v1/battery/prediction` | Life / charge time predictions |
| GET | `/api/v1/battery/history?hours=24` | Historical samples |
| GET | `/api/v1/battery/stats` | Cycle counts, efficiency, health score |

### System Monitors

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/cpu/status` | CPU usage, frequency, governor |
| GET | `/api/v1/cpu/history` | CPU history |
| GET | `/api/v1/memory/status` | RAM / swap / cache |
| GET | `/api/v1/network/status` | I/O rates, connection counts |
| GET | `/api/v1/thermal/status` | All thermal zone readings |
| GET | `/api/v1/processes` | Running processes (energy ranked) |
| GET | `/api/v1/processes/top?n=10` | Top N energy consumers |

### Intelligence

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/recommendations` | All prioritised recommendations |
| GET | `/api/v1/anomalies` | Recent anomaly events |
| GET | `/api/v1/habits` | Learned daily usage patterns |
| GET | `/api/v1/workload/prediction` | ML drain-rate forecast |

### Reports

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/reports/battery` | 24-hour battery summary |
| GET | `/api/v1/reports/cpu` | CPU usage report |
| GET | `/api/v1/reports/full` | Complete system report |

### Settings

| Method | Path | Description |
|---|---|---|
| GET | `/api/v1/settings` | All current settings |
| PUT | `/api/v1/settings/{key}` | Update a single setting |

### WebSocket

Connect to `ws://127.0.0.1:8342/ws` for real-time streaming. On connection, the server sends a full state snapshot then streams delta updates as JSON:

```json
{ "type": "update", "key": "battery", "ts": 1700000000.0, "data": { ... } }
```

---

## Data Flow

```
Android sysfs / psutil
        │
        ▼
   Monitors (async polling loops)
        │
        ▼
   DataBus.update(key, value)          ← single source of truth
        │
   ┌────┴─────┐
   │          │
   ▼          ▼
Optimisers  WebSocket manager          ← real-time push to Kotlin
   │
   ▼
Recommendation Engine
   │
   ▼
REST API (Kotlin polls)
        │
        ▼
   SQLite (persistence)
```

---

## Key Design Decisions

**DataBus** — all modules communicate through a central async pub/sub hub. No direct cross-module references. This makes every subsystem independently testable and restartable.

**Minimal CPU footprint** — the engine uses EWMA smoothing and RollingStats (O(1) memory, O(1) compute per sample) rather than storing raw history in RAM. Heavy computation is deferred to the executor thread pool.

**Android-first, desktop-compatible** — all monitors read from Android sysfs paths first (`/sys/class/power_supply/battery`, `/sys/class/thermal/thermal_zone*`, `/sys/devices/system/cpu`) with full psutil fallback for development on desktop Linux or macOS.

**Lightweight ML** — the workload predictor uses a pure-numpy closed-form Ridge Regression (no sklearn dependency). The habit learner uses histogram accumulation. Both persist to SQLite via JSON snapshots so they survive engine restarts.

**Never a net battery drain** — the engine's own polling intervals, caching, and computation are budgeted to consume < 1% CPU at steady state.

---

## Test Suite

```bash
# Install test dependencies
pip install -r requirements-dev.txt

# Run all 206 tests
pytest tests/

# Run with coverage
pytest tests/ --cov=. --cov-report=term-missing
```

### Test coverage

| Module | Tests | Coverage focus |
|---|---|---|
| `test_utils.py` | 54 | Config, EWMA, RollingStats, sysfs, DataBus |
| `test_storage.py` | 42 | Cache LRU/TTL, DB CRUD, Settings persistence |
| `test_monitoring.py` | 56 | Monitors, optimisers, anomaly detection, battery stats |
| `test_api.py` | 36 | All REST endpoints via httpx AsyncClient |
| `test_learning.py` | 18 | Feature vectors, HabitLearner, RecommendationEngine |

---

## Future Expansion

The architecture supports:

- **Adaptive battery profiles** — `BackgroundScheduler` constraints already model charging/idle/network requirements.
- **Travel mode / Gaming mode** — extend `StorageConfig.power_profile` with new profile keys; add profile-specific recommendation rules.
- **Ultra Power Saver mode** — already triggered at < 10% level; extend with app suspension logic in the Kotlin layer.
- **Wearable integration** — add a `wearable_monitor.py` following the same monitor pattern; publish to DataBus under `"wearable"`.
- **Federated learning** — the `ml_snapshots` table already serialises model weights; extend to share anonymised patterns across devices.

---

## Dependencies

| Package | Purpose |
|---|---|
| `fastapi` | REST API framework |
| `uvicorn` | ASGI server |
| `aiosqlite` | Async SQLite persistence |
| `psutil` | System metrics (CPU, memory, network, battery fallback) |
| `numpy` | Numerical prediction engine and ridge regression |
| `pydantic` | Request / response validation |
| `websockets` | WebSocket transport |
