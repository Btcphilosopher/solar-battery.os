# BatteryOpt architecture

This document explains how the pieces fit together and, more usefully, *why* each
one is shaped the way it is. The code is the specification; this is the map.

## The one loop

```
MEASURE -> ESTIMATE -> SIMULATE -> COMPARE -> OPTIMISE -> RECOMMEND -> MEASURE AGAIN
```

Every module in the package sits at exactly one station on that loop, and the
package layout follows it:

| Package | Station | Responsibility |
|---|---|---|
| `hardware`, `telemetry` | MEASURE | Adapters, frame validation, ingestion, virtual devices |
| `estimation` | ESTIMATE | EKF, coulomb counting, OCV anchoring, capacity, resistance, SOP |
| `models` | SIMULATE | Chemistry, topology, ECM, thermal, degradation, plant, surrogate |
| `scenario` | COMPARE | Candidate strategies and their simulated consequences |
| `optimisation` | OPTIMISE | Objective, constraints, methods, Pareto, MPC |
| `applications` | RECOMMEND | The nine questions operators actually ask |
| `persistence`, `api` | Record and serve | Immutable telemetry, reproducible runs, HTTP, dashboard |
| `research`, `validation` | Off-line | Sweeps, studies, analytical checks, cross-model comparison |

## Four decisions that shape everything else

### 1. The objective is priced in one currency

Every term in the objective — energy, degradation, thermal stress, efficiency
loss, unmet demand, grid-service value, comfort — is converted to money before it
is weighted. Weighted sums of incommensurable units produce numbers that cannot be
interrogated: nobody can say whether 0.3 is a lot. Money can be checked against
the tariff and the replacement cost of the pack, and the dashboard can show the
terms side by side as bars that mean something.

Application presets (`ev`, `grid_storage`, `consumer`, `industrial`, `lifetime`,
`balanced`) then set the weights, and swapping presets visibly changes the answer.

### 2. Hard constraints are not objective terms

A constraint expressed as a large penalty is a constraint the optimiser is allowed
to break for a large enough reward. In BatteryOpt hard constraints are:

* **defined** in `ConstraintSet`, derived from the chemistry's operating envelope;
* **projected** into the action space as `PowerBounds` before the search starts;
* **checked** afterwards against the *simulated consequences* of the plan;
* **repaired** by bisection — scale the plan down until its consequences are legal
  — or, if even resting violates them, refused with `SafetyViolation`.

They can only ever be tightened. `ConstraintSet(battery, max_temperature_c=90)`
raises rather than widening the envelope, because the envelope belongs to the
cells, not to the operator.

The commitment window matters here and is easy to get wrong: the recommendation is
checked against the consequences of *holding the first action for as long as the
caller might hold it*, not just for one step of the planner's grid.

### 3. Provenance travels with the number

Every quantity carries one of `MEASURED`, `ESTIMATED`, `PREDICTED`, `SIMULATED`,
`MODELLED`, `OPTIMISED`. Combining quantities takes the weakest (`trust_rank`), so
a figure computed from one measurement and one model is `MODELLED`, and it says
so — on the API response, on the dashboard, in the validation report.

The point is not bookkeeping. It is that a simulated state must never be able to
present itself as a measurement, and the only way to guarantee that is to make the
tag part of the value rather than part of the documentation.

### 4. Everything is reproducible or it did not happen

Each optimisation run stores a `RunFingerprint`: code version, model version,
optimiser version, schema version, plus canonical-JSON content hashes of the
inputs, the constraint set and the objective configuration. Canonical JSON rejects
NaN and infinity, so a fingerprint cannot silently be computed over garbage.

Raw telemetry is append-only, enforced in two places — a PostgreSQL trigger that
rejects `UPDATE` and `DELETE`, and the same rule in the in-memory repository — so
the two backends cannot diverge on the one property that matters most.

## The physical model

### Electrical

A first-order-plus-diffusion Thevenin equivalent circuit:

```
V = OCV(soc, hysteresis) - I*R0(T, soc, age) - sum_k V_rc,k
```

`R0` is a surface in temperature, state of charge and age, not a constant.
Hysteresis is an **explicit state**, not a function of current sign — this matters
enormously for LFP, where the OCV plateau is flat enough that a sign-switched
hysteresis model makes the EKF diverge. (It did. Fixing it took the LFP SOC error
from 6 % to 0.16 %.)

Power-to-current inversion is closed-form: solving `P = V(I)*I` for `I` is a
quadratic, and the round-trip is exact to machine precision. It is on the hot path
of every optimiser, so "close enough" is not close enough.

### Thermal

A lumped-capacity model integrated by exact zero-order hold:

```
T(t+dt) = T_inf + (T(t) - T_inf) * exp(-k*dt / C)
```

Not forward Euler. The optimiser evaluates candidates at step sizes from 1 second
to an hour, and an explicit integrator is unstable at the large end. The
`thermal_time_constant` validation check exists specifically to reject a
forward-Euler implementation: it passes the steady-state check and fails this one.

Cooling parasitic power follows the affinity law, `P ∝ u³`, which is why the
optimum fan speed is interior rather than at an extreme.

### Degradation

A semi-empirical stress-weighted power law, calendar and cycle:

```
fade = a_cal * ((t_eq + t0)^z_cal - t0^z_cal)
     + a_cyc * ((A_eq + A0)^z_cyc - A0^z_cyc)
```

The **formation offsets** `t0` and `A0` are the interesting part. Without them a
plain power law with `z < 1` has an infinite marginal rate at zero, so a brand-new
pack's first cycle appears to cost more than the next thousand combined, and the
optimiser rationally refuses to use it. With them, `fade(0) = 0` and the marginal
rate is finite — matching the real formation-then-settle behaviour.

Stress factors saturate rather than overflow (`MAX_STRESS = 1e6`), because an
optimiser probing an extreme is not a reason to raise `OverflowError`.

Cold charging gets a lithium-plating multiplier, applied to charge only, keyed off
each chemistry's own plating threshold — LTO and sodium-ion genuinely do not plate
where NMC does.

### Fidelity

`FAST` (surrogate response surface) → `STANDARD` (ECM) → `DETAILED` (ECM with
finer sub-stepping) → `RESEARCH` (PyBaMM, if installed). The surrogate is a pair
of smooth 2-D tables in `(soc, temperature)` plus closed-form reconstruction, and
its error is *quoted* in the validation report — 0.02–0.3 % RMS — because it is
part of the engine's error budget, not a detail.

## Estimation

The EKF's state is `[soc, v_rc..., hysteresis]` with Joseph-form covariance and
innovation-driven adaptive measurement noise. The adaptivity is not a refinement:
without it the filter reported NIS of 324 — that is, it was roughly eighteen times
more confident than it had any right to be, and would have handed the optimiser a
tight uncertainty band around a wrong number.

Estimators are fused with chi-square gating, and disagreement between them
inflates the reported variance rather than being averaged away.

State of Power is horizon-aware — the 1-second and 30-second capabilities are
different numbers — and it *names* the binding limit, because "42 kW" is much less
useful than "42 kW, limited by cell voltage."

## Optimisation

### Methods

| Method | Use |
|---|---|
| `enumeration` | Tiny action sets; the reference answer |
| `golden_section` | Smooth unimodal single-step problems |
| `scipy` | General bounded scalar/vector problems |
| `surrogate_sweep` | Vectorised, real-time path |
| `linear_programme` | Long horizons with linear costs (HiGHS) |
| `dynamic_programming` | Non-linear losses over a horizon; works in **charge space** |
| `mixed_integer` | Discrete commitments (CP-SAT; falls back loudly to LP) |
| `pareto` | The trade-off front, with named corners |
| `mpc` | Closed-loop receding horizon |

The DP works in charge space rather than power space and emits the power computed
at the *start-of-interval* state. Doing it the obvious way — plan in power, check
the voltage at the start SOC — produces plans the full-fidelity plant then
rejects, which is the worst kind of bug: the optimiser is confident and wrong.

`select_method` explains its choice, so the recommendation can say why it used
what it used.

### MPC

Receding horizon with a terminal energy value (without one, the controller empties
the battery just before the horizon every time), geometric step spacing, warm
starting, and a commitment window equal to the control period rather than the
planning horizon. On failure it falls back to rest and records that it did.

## Forecasting and uncertainty

Four statistical forecasters — persistence, seasonal-naive with level correction,
damped Holt, harmonic regression with ridge — each producing P10/P50/P90.

Band width comes from **backtested residual quantiles** where there is enough
history and from a documented prior width where there is not, and the forecast
records which of the two it used. Bands widen with the square root of lead time; a
band that is the same width twelve hours out is a decoration, not an interval.

The optional PyTorch layer models the *residual* of a statistical forecaster. It
can never be the whole forecaster, so removing torch degrades accuracy and nothing
else.

## Validation

`batteryopt.validation.analytical` checks the models against results that are true
by derivation, not against another simulator:

1. charge conservation, stated per step against that step's own capacity;
2. energy balance — delivered plus losses equals energy removed from the store;
3. OCV inversion round-trip, with tolerance in volts (the only honest claim on a
   flat plateau);
4. thermal steady state against `T_sink + Q/k`;
5. thermal time constant — `1 - 1/e` of the gap after one `tau`;
6. power↔current inversion round-trip;
7. degradation monotonicity and the sign of every stress factor;
8. surrogate accuracy against the exact ECM;
9. provenance discipline.

`cross_model.compare_with_pybamm` reports `NOT PERFORMED` when PyBaMM is absent —
never a pass — and when it does run, its summary says that agreement between two
models is not evidence of physical accuracy.

The test suite deliberately corrupts models to confirm each check notices: a 5 %
conductance error, a shifted OCV inverse, a temperature-blind calendar stress, a
biased coulomb count. A validation suite that cannot fail is decoration.

## What this is not

BatteryOpt is not a BMS. It does not measure, it does not protect, and it does not
actuate. It recommends, and the recommendation goes to a system that has its own
independent safety protection. Nothing in this repository has been connected to a
physical battery, and no number in it is a measurement.
