# API reference

## The one-call interface

```python
from batteryopt import optimise

result = optimise(
    battery_state,          # BatteryState -- required
    battery=None,           # Battery, or a battery_id already registered
    demand=None,            # W, a Demand, or a schedule
    mission=None,           # Mission (energy and departure time)
    tariff=None,            # Tariff or PriceCurve
    objective="balanced",   # preset name or ObjectiveConfig
    constraints=None,       # ConstraintSet -- defaults to the chemistry envelope
    horizon_s=3600.0,
    dt_s=60.0,
    method=None,            # None selects automatically and explains the choice
    ambient_c=None,
    solar_w=None,
    fidelity="STANDARD",
)
```

Returns a `Recommendation`:

| Field | Meaning |
|---|---|
| `power_w` | Recommended terminal power. Positive = discharge. |
| `current_a`, `cooling_fraction`, `heating_fraction` | The rest of the action |
| `action` | `CHARGE` / `DISCHARGE` / `HOLD` / `REST` |
| `reason` | Why, in one sentence |
| `limiting_constraint` | What bound the answer |
| `objective_terms` | Term-by-term contribution, in money |
| `alternatives` | What else was considered, and why it lost |
| `trajectory` | The simulated consequences of the plan |
| `predicted` | End SOC, peak temperature, energy, degradation, efficiency |
| `confidence` | Derived from estimator uncertainty and forecast width |
| `provenance` | Always `OPTIMISED` |
| `fingerprint` | Reproduces this run exactly |
| `digest` | Short hash of the fingerprint |

`result.summary()` gives one line. `result.why()` gives the term-by-term
breakdown. `result.as_dict()` gives everything, JSON-safe.

It raises `SafetyViolation` when no legal action exists, `InfeasibleProblem` when
the constraint set is empty, and `ConfigurationError` for a bad configuration —
never a fabricated recommendation.

## Engine interface

For repeated calls against the same battery, build the engine once:

```python
from batteryopt import Battery, OptimisationEngine, Tariff

engine = OptimisationEngine(battery, objective="grid_storage", tariff=tariff)
result = engine.optimise(state, demand=50_000.0, horizon_s=7200.0, dt_s=300.0)
front  = engine.pareto(state, horizon_s=7200.0)      # trade-off front
problem = engine.build_problem(state, horizon_s=7200.0, dt_s=300.0)
```

`engine.constraints`, `engine.economics`, `engine.scenarios` and `engine.plant`
are all reachable, and all of them are inspectable rather than hidden.

## Applications

```python
from batteryopt.applications import (
    SmartCharger, MissionPlanner, DischargePlanner, ThermalOptimiser,
    BalancingOptimiser, ArbitrageOptimiser, SolarOptimiser,
    GridServiceOptimiser, LifetimeOptimiser,
)

SmartCharger(engine).plan(state, target_soc=0.8, deadline_s=8*3600)
MissionPlanner(engine).plan(state, Mission(energy_wh=45_000, departure_s=6*3600))
DischargePlanner(engine).plan(state, load_w=30_000, horizon_s=4*3600)
ThermalOptimiser(engine).plan(state, power_w=120_000)
BalancingOptimiser(battery).plan(cell_socs)
ArbitrageOptimiser(engine).plan(state, tariff=tariff)
SolarOptimiser(engine).plan(state, tariff=tariff, solar_w=pv, load_w=load)
GridServiceOptimiser(engine).assess(state, contract)
LifetimeOptimiser(battery).simulate(policy)
```

Each returns a plan object with a `summary()`, an `as_dict()`, and — importantly —
a `reason`. A plan that cannot meet its goal says so in `warnings` rather than
quietly returning something smaller.

## HTTP service

```bash
batteryopt serve --port 8000
```

| Method | Path | Purpose |
|---|---|---|
| `GET` | `/health` | Liveness plus every version |
| `GET` | `/capabilities` | Which optional dependencies are active |
| `POST` | `/batteries` | Register a battery configuration |
| `GET` | `/batteries/{id}/state` | Present state, with provenance per field |
| `POST` | `/batteries/{id}/optimise` | A recommendation |
| `POST` | `/batteries/{id}/pareto` | The trade-off front |
| `POST` | `/batteries/{id}/telemetry` | Ingest a frame (append-only) |
| `GET` | `/batteries/{id}/twin` | Digital-twin snapshot |
| `GET` | `/batteries/{id}/dashboard` | The operations dashboard |
| `GET` | `/runs/{digest}` | Look up a past run by digest |

Status codes are meaningful: `409` for a safety refusal, `422` for a malformed
payload, `400` for an unknown chemistry, `404` for an unknown battery.

## Command line

```bash
batteryopt chemistries                    # what is registered
batteryopt describe --chemistry lfp -s 250 -p 4
batteryopt optimise --soc 0.63 --temperature 29 --demand 42000
batteryopt charge --soc 0.2 --target 0.8 --deadline 8h --ambient 0
batteryopt mission --soc 0.4 --energy 45000 --departure 6h
batteryopt arbitrage --soc 0.5 --horizon 24h
batteryopt lifetime                       # compare operating policies
batteryopt pareto --soc 0.5
batteryopt validate --chemistry nmc
batteryopt study charging|lifetime|mission|chemistry|temperature
batteryopt simulate --hours 24            # virtual battery, whole pipeline
batteryopt serve --port 8000
batteryopt capabilities
```

Add `--json` to any command for machine-readable output.

## Registering a chemistry

Nothing about a chemistry is hard-coded. Supply the parameters and it becomes a
first-class citizen — including in the validation suite and every study:

```python
from batteryopt import register_chemistry, ChemistryParameters

register_chemistry(ChemistryParameters(
    name="my_cell",
    ocv=...,             # OCVCurve: monotone SOC -> voltage
    resistance=...,      # ResistanceModel: R0(T, soc, age)
    thermal=...,         # ThermalProperties
    degradation=...,     # DegradationCoefficients
    envelope=...,        # OperatingEnvelope: the hard limits
))
```

`batteryopt validate --chemistry my_cell` then runs all nine analytical checks
against it. If the parameters are unphysical, they fail there rather than three
months into a deployment.

## Optional dependencies and their fallbacks

| Extra | Enables | Without it |
|---|---|---|
| `api` | FastAPI service, dashboard | Library and CLI only |
| `db` | PostgreSQL, Redis | In-memory repositories, same semantics |
| `physics` | PyBaMM `RESEARCH` fidelity, cross-model validation | Reports `NOT PERFORMED` |
| `solvers` | OR-Tools CP-SAT | `mixed_integer` falls back to LP, loudly |
| `ml` | PyTorch residual forecaster | Statistical forecasters only |
| `mqtt` | MQTT telemetry transport | Other transports |
| `accel` | Numba kernels | Pure NumPy |
| `frames` | Polars frames | NumPy arrays |

`batteryopt capabilities` prints the live state. No fallback is silent.
