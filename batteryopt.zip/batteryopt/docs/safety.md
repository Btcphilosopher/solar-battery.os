# Safety model

## What BatteryOpt is not

BatteryOpt is **not a battery management system**. It does not measure cells, it
does not open contactors, it does not protect anything. It produces
recommendations that are consumed by a system which has its own independent
protection, and that protection remains the authority. If a recommendation from
BatteryOpt and a limit in the BMS disagree, the BMS is right.

Nothing in this repository has been connected to a physical battery. Every number
it produces is a MODEL, SIMULATION or OPTIMISATION result. None of them is
evidence of physical performance.

## The property

> No optimiser, under any objective, at any state, can return a recommendation
> whose simulated consequences violate a hard constraint. Either the engine
> returns something legal, or it refuses. There is no third outcome.

This is a property of the *engine*, not of any individual method, and it is
enforced by construction rather than by each method being careful.

## How it is enforced

**Definition.** `ConstraintSet` derives hard constraints from the chemistry's
`OperatingEnvelope`: cell and pack voltage, current, power, temperature, the
charge temperature window, and the state-of-charge rails. Operator configuration
can *tighten* any of them. Attempting to widen one raises — the envelope belongs
to the cells.

**Projection.** Before any search begins, the constraints are projected forward
into the action space as `PowerBounds`: the feasible signed-power interval over
the next interval, with the tightest limit named. Optimisers search inside that
interval, so the common case never produces an illegal candidate at all.

**Checking.** Bounds are necessary but not sufficient, because they are evaluated
at the current state and a plan runs forward. So after a method returns, the plan
is simulated at full fidelity and the *resulting trajectory* is checked against
every hard constraint. This catches the case where each step is individually legal
and the sequence is not.

**Commitment window.** The check is performed against holding the first action for
the full commitment window — by default the whole horizon, and under MPC the
control period — not for one step of the planner's grid. A recommendation that is
legal for 60 seconds and illegal for 300 is not a legal recommendation if the
caller will hold it for 300.

**Repair.** If the trajectory violates something, the plan is scaled down by
bisection, with maximum cooling, until its simulated consequences are legal. Twelve
bisection steps are enough to land within 0.025 % of the largest legal scaling.

**Refusal.** Before bisecting, the engine tests the zero action. If *resting*
violates a hard constraint, no scaling can help and the engine raises
`SafetyViolation` naming the violated constraint. Over HTTP this is a `409`. It is
never a small number pretending to be a plan.

## How it is tested

`tests/test_constraints.py` runs the property as a parameterised test across every
optimisation method × seven adversarial states — empty and cold, empty, full and
hot, hot, cold, full, at the derate knee:

```python
def test_no_method_can_return_a_violating_recommendation(
    ev_battery, method, label, soc, temperature
):
    """For every optimisation method and every adversarial state, either the engine
    returns a recommendation whose *simulated consequences* satisfy every hard
    constraint, or it refuses. There is no third outcome."""
```

The same property is asserted through the public `optimise()` function and through
the HTTP API, because a guarantee that only holds on one code path is not a
guarantee. When this test was first written it failed 17 times; the commitment
window, bisection repair, held-first-action check and surrogate margins are what
those 17 failures bought.

Additional constraint tests assert that hard constraints cannot be downgraded to
soft, that operator overrides never widen the cell envelope, that the *hottest*
cell governs rather than the mean, that the charge temperature window applies only
while charging, and that a maximum-power objective — the most adversarial one
available — still cannot break a limit.

## Failure behaviour

| Situation | Behaviour |
|---|---|
| No legal action exists | `SafetyViolation`, naming the constraint (HTTP 409) |
| Constraint set is empty | `InfeasibleProblem` (HTTP 409) |
| A method crashes | Fall back to the next method, record that it happened |
| MPC solve fails | Apply rest, record `fell_back=True` |
| Optional solver missing | Fall back and log the substitution — never silently |
| Estimator diverges | Inflate variance, lower `confidence` on the recommendation |
| Forecast unavailable | Widen the band to the documented prior; do not fabricate a median |

Every degradation is visible in the output. A recommendation produced under a
fallback says so, and the confidence figure reflects it.

## Deploying this responsibly

* Treat every output as advisory. The consuming system must apply its own limits.
* Keep the constraint set *tighter* than the BMS's, never looser. The whole design
  assumes BatteryOpt is the inner, more conservative envelope.
* Validate against your own cells before trusting the degradation numbers. The
  shipped coefficients are calibrated against published cycle-life data, not
  against your pack, and `batteryopt validate` checks internal consistency — not
  physical accuracy.
* Log the `digest` of every run alongside whatever you did with it. It is the only
  way to reconstruct, later, why the system recommended what it recommended.
* Watch the `fell_back` and `confidence` fields. A controller that is quietly
  running on fallbacks is a controller that has stopped optimising.
