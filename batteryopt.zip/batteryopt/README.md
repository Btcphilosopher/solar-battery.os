# BatteryOpt

**Battery optimisation, simulation and decision engine.**

BatteryOpt answers one question:

> Given the battery's present physical state, its future mission, the surrounding
> energy system and its configured constraints, what operating strategy produces
> the greatest useful outcome at the lowest lifetime cost?

It is **not** a battery management system. It sits *above* an existing BMS, EMS or
battery controller and returns recommendations. It never replaces independent
safety protection, and nothing in it is a substitute for one.

```
MEASURE -> ESTIMATE -> SIMULATE -> COMPARE -> OPTIMISE -> RECOMMEND -> MEASURE AGAIN
```

---

## Install

```bash
pip install -e .              # core: NumPy, SciPy, Pydantic only
pip install -e ".[api]"       # + FastAPI service and dashboard
pip install -e ".[all]"       # + PyBaMM, OR-Tools, PyTorch, Postgres, Redis, MQTT
```

Python 3.11 or newer. Every optional dependency degrades gracefully: without
OR-Tools the mixed-integer method falls back to a linear programme *and says so*;
without PyBaMM cross-model validation reports `NOT PERFORMED` rather than passing;
without PyTorch the forecaster drops its residual layer and keeps its statistical
core. Run `batteryopt capabilities` to see what is active.

## Sixty seconds

```python
from batteryopt import Battery, Tariff, optimise

battery = Battery.build(chemistry="nmc", cells_series=96, cells_parallel=4)
state = battery.initial_state(soc=0.63, temperature_c=29.0)

result = optimise(
    battery_state=state,
    battery=battery,
    demand=42_000.0,                       # W the system would like
    objective="ev",
    tariff=Tariff.time_of_use(peak_price=0.42, off_peak_price=0.09),
)
print(result.summary())
print(result.why())                        # term-by-term, in money
```

Every recommendation carries: the action, the reason, the binding constraint, the
alternatives considered and why they lost, the predicted consequences, and a
digest that reproduces the run exactly.

Or from the command line:

```bash
batteryopt chemistries                     # what is registered
batteryopt describe --chemistry lfp -s 250 -p 4
batteryopt optimise --soc 0.63 --temperature 29 --demand 42000
batteryopt charge --soc 0.2 --target 0.8 --deadline 8h --ambient 0
batteryopt arbitrage --soc 0.5 --horizon 24h
batteryopt pareto --soc 0.5                # the trade-off front
batteryopt validate                        # analytical checks
batteryopt study charging                  # a prepared research sweep
batteryopt serve --port 8000               # HTTP service + dashboard
```

---

## What is in it

### Physical model

| Layer | What it does |
|---|---|
| **Chemistry** | OCV curve, resistance surface, thermal properties, degradation coefficients, operating envelope — all data, none hard-coded. Six ship: NMC, LFP, NCA, NCA-generic, sodium-ion, LTO. Register your own with `register_chemistry`. |
| **Topology** | Cell → module → pack → system, in series and parallel, with per-level derating. A single cell and a 400-cell string go through the same code path. |
| **Electrical** | Thevenin equivalent circuit: OCV(SOC) + R0(T, SOC, age) + diffusion RC branches, with voltage hysteresis carried as an explicit state. Power↔current inversion is closed-form. |
| **Thermal** | Lumped model integrated by exact zero-order-hold exponential, so it is stable at any step size. Controllable cooling with affinity-law parasitic power (P ∝ u³). |
| **Degradation** | Semi-empirical stress-weighted power law with formation offsets, so fade(0) = 0 and the marginal rate is finite. Lithium-plating penalty on cold charging. Rainflow cycle counting. |

Fidelity is selectable per call: `FAST` (surrogate) → `STANDARD` → `DETAILED` → `RESEARCH` (PyBaMM, if installed).

### Estimation

An Extended Kalman Filter over `[soc, v_rc..., hysteresis]` with Joseph-form
covariance and innovation-driven adaptive measurement noise, fused with coulomb
counting and OCV anchoring under chi-square gating. Capacity and resistance
estimators run alongside. Horizon-aware State of Power names the limit that binds.

Every quantity carries **provenance** — `MEASURED`, `ESTIMATED`, `PREDICTED`,
`SIMULATED`, `MODELLED` or `OPTIMISED` — and combining quantities takes the
weakest. A simulated state can never present itself as a measurement.

### Optimisation

The objective is priced in **one currency** — money — then weighted, so terms are
comparable rather than merely summed:

```
energy cost + degradation cost + thermal cost + efficiency loss
  + shortfall penalty + grid-service value + comfort
```

Application presets (`ev`, `grid_storage`, `consumer`, `industrial`, `lifetime`,
`balanced`) set the weights. Nine methods are available, selected automatically or
named explicitly:

`enumeration` · `golden_section` · `scipy` · `surrogate_sweep` · `linear_programme`
(HiGHS) · `dynamic_programming` (charge space) · `mixed_integer` (CP-SAT) ·
`pareto` · `mpc`

Model Predictive Control runs a receding horizon with a terminal energy value and
its own shorter commitment window.

### Safety

Hard constraints are **not** objective terms. They are defined, projected and
checked separately, they can only ever be tightened, and the engine either returns
a recommendation whose *simulated consequences* satisfy every one of them, or it
refuses with `SafetyViolation`. There is no third outcome — and it is tested as a
property across every method × every adversarial state:

```python
def test_no_method_can_return_a_violating_recommendation(...):
    """For every optimisation method and every adversarial state, either the engine
    returns a recommendation whose simulated consequences satisfy every hard
    constraint, or it refuses."""
```

### Applications

| Module | Question |
|---|---|
| `charging` | How should this charge be scheduled? |
| `mission` | What state of charge does the journey actually need? |
| `discharge` | How much of this load should the battery serve? |
| `thermal` | How hard should the cooling run? |
| `balancing` | Is balancing worth the energy it burns? |
| `arbitrage` | Charge, hold or discharge, at what power? |
| `solar` | Where should each watt of generation go? |
| `grid_services` | Is this service contract worth signing? |
| `lifetime` | Which operating policy delivers most over the whole life? |

### Forecasting and uncertainty

Persistence, seasonal-naive, damped Holt and harmonic regression, each producing a
**P10/P50/P90 band**, not a line. Bands come from backtested residual quantiles
where history exists and a documented prior width where it does not — and the
forecast records which. An optional PyTorch residual layer is a no-op without torch.

### Persistence and reproducibility

PostgreSQL schema with immutable raw telemetry (enforced by a trigger that rejects
`UPDATE` and `DELETE`, and mirrored in the in-memory repository) and fully
reproducible optimisation runs. Every run stores a `RunFingerprint`: code, model,
optimiser and schema versions plus canonical-JSON content hashes of the inputs,
constraints and objective. The same problem gives a bit-identical answer and the
same digest.

### Service and dashboard

A FastAPI application with per-process locking; safety refusals return HTTP 409,
not a fabricated recommendation. The bundled dashboard is deliberately industrial
and emphasises **why**: term-by-term contribution bars, the alternatives that were
considered and lost, the binding constraint, remaining useful life, the power
capability table, and a provenance footer on every figure.

---

## Examples

```bash
python examples/01_ev_fast_charge.py       # what fast charging costs, by temperature
python examples/02_grid_arbitrage.py       # day-ahead trading, closed-loop MPC
python examples/03_thermal_tradeoff.py     # cooling: energy spent vs life bought
python examples/04_solar_self_consumption.py
python examples/05_research_sweep.py       # reproducible parameter studies
python examples/06_safety_refusal.py       # the engine refusing, on purpose
```

## Testing

```bash
pytest -q                                  # 487 tests
batteryopt validate --chemistry nmc        # analytical checks
```

The analytical checks compare the models against results that are true by
*derivation* — charge conservation, energy balance, the exact thermal time
constant, closed-form power inversion, degradation monotonicity — not against
another simulator. Several tests corrupt a model deliberately to confirm the
corresponding check actually notices; a validation suite that cannot fail is
decoration.

## Vocabulary

Kept strict throughout, including in the dashboard:

| Term | Means |
|---|---|
| **MEASURED RESULT** | Came from a sensor on physical hardware. |
| **MODEL RESULT** | A direct evaluation of a model at a stated point. |
| **SIMULATION RESULT** | A model rolled forward over hypothetical inputs. |
| **OPTIMISATION RESULT** | A recommendation. Neither observed nor simulated. |

BatteryOpt has never been connected to a physical battery. Nothing it produces is
a measurement, and no number in this repository is evidence of physical
performance.

## Licence

Apache-2.0.
