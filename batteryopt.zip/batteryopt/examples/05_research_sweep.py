"""Example 5 -- Batch research mode: sweeps that are reproducible a year later.

The research layer exists so that a question about batteries can be answered the
way a question in any other engineering discipline is answered: state the design,
run it, record the design's digest alongside the results, and let someone else
re-run it and get the same numbers.

Four things are demonstrated:

* a **full-factorial sweep** over charging strategy and temperature;
* a **Monte Carlo** over mission energy and weather, producing a reliability
  statement rather than a point estimate;
* **one-at-a-time sensitivity**, which reports elasticities and admits in its own
  output that it cannot see interactions;
* **Morris screening**, which can.

Run:  python examples/05_research_sweep.py
"""

from __future__ import annotations

import numpy as np

from batteryopt import Battery, Tariff
from batteryopt.research.studies import (
    charging_strategy_study,
    chemistry_comparison_study,
    mission_reliability_study,
    temperature_policy_study,
)
from batteryopt.research.sweeps import monte_carlo, morris_screening, sensitivity


def main() -> None:
    battery = Battery.aged(
        Battery.build(
            chemistry="nmc",
            cells_series=96,
            cells_parallel=4,
            battery_id="demo-research",
            max_charge_power_w=150_000.0,
            max_discharge_power_w=250_000.0,
        ),
        years=2.0,
        equivalent_full_cycles=400.0,
    )
    tariff = Tariff.time_of_use(peak_price=0.42, off_peak_price=0.09, horizon_hours=48)

    # --- 1. Full factorial ---------------------------------------------------
    print("1. CHARGING STRATEGY AGAINST AMBIENT TEMPERATURE (full factorial)")
    study = charging_strategy_study(
        battery, temperatures_c=(0.0, 15.0, 30.0), rate_fractions=(1.0, 0.6, 0.35),
        tariff=tariff,
    )
    print(f"   {len(study.successes)}/{len(study)} runs succeeded, "
          f"design digest {study.digest[:16]}")
    print(f"   {'ambient':>8} {'rate':>6} {'minutes':>8} {'fade %':>9}")
    for e in study.successes:
        print(
            f"   {e.parameters['temperature_c']:7.0f}C {e.parameters['rate_fraction']:6.2f} "
            f"{e.outputs['duration_min']:8.1f} {e.outputs['degradation_pct']:9.4f}"
        )

    # --- 2. Lifetime against temperature ------------------------------------
    print("\n2. LIFETIME ENERGY AGAINST OPERATING TEMPERATURE")
    temps = temperature_policy_study(
        battery, temperatures_c=(-10.0, 0.0, 5.0, 15.0, 25.0, 35.0, 45.0)
    )
    energies = temps.column("lifetime_energy_mwh")
    best = int(np.argmax(energies))
    for e, mwh in zip(temps.successes, energies):
        bar = "#" * int(round(40 * mwh / max(energies)))
        print(f"   {e.parameters['temperature_c']:6.0f} C  {mwh:7.1f} MWh  {bar}")
    print(
        f"   optimum at {temps.successes[best].parameters['temperature_c']:.0f} C -- "
        "too cold plates lithium on charge, too hot spends calendar life"
    )

    # --- 3. Monte Carlo ------------------------------------------------------
    print("\n3. MISSION RELIABILITY (Monte Carlo over energy and weather)")
    mission = mission_reliability_study(battery, n=2000, seed=1)
    failed = mission.column("failed")
    margin = mission.column("margin_wh") / 1000.0
    print(f"   {len(mission.successes)} samples, seed {mission.seed}, "
          f"digest {mission.digest[:16]}")
    print(f"   failure rate      {failed.mean() * 100:5.1f} %")
    print(
        f"   margin P10/P50/P90  {np.quantile(margin, 0.1):6.1f} / "
        f"{np.quantile(margin, 0.5):6.1f} / {np.quantile(margin, 0.9):6.1f} kWh"
    )
    print("   (this is what turns 'charge to 80 %' into a reliability statement)")

    # Re-run and confirm it is bit-identical.
    again = mission_reliability_study(battery, n=2000, seed=1)
    identical = np.array_equal(mission.column("failed"), again.column("failed"))
    print(f"   re-run from the same seed is identical: {identical}")

    # --- 4. Sensitivity, and its limits -------------------------------------
    print("\n4. SENSITIVITY -- one-at-a-time, then Morris")

    def duty(params):
        """Lifetime energy under a duty described by four parameters."""
        from batteryopt.applications import LifetimeOptimiser, OperatingPolicy

        policy = OperatingPolicy(
            name="probe",
            cycles_per_year=float(params["cycles_per_year"]),
            depth_of_discharge=float(params["depth_of_discharge"]),
            c_rate=float(params["c_rate"]),
            temperature_c=float(params["temperature_c"]),
            mean_soc=0.55,
        )
        result = LifetimeOptimiser(battery).simulate(policy)
        return {"lifetime_energy_mwh": result.lifetime_energy_wh / 1e6}

    baseline = {
        "cycles_per_year": 300.0,
        "depth_of_discharge": 0.7,
        "c_rate": 0.5,
        "temperature_c": 25.0,
    }
    oat = sensitivity(duty, baseline, output_key="lifetime_energy_mwh")
    print("   elasticity of lifetime energy (fractional out per fractional in):")
    for key in oat["ranked"]:
        print(f"     {key:>20}  {oat['elasticities'][key]['elasticity']:+7.3f}")
    print(f"   caveat: {oat['caveat']}")

    morris = morris_screening(
        duty,
        {
            "cycles_per_year": (100.0, 500.0),
            "depth_of_discharge": (0.3, 0.95),
            "c_rate": (0.2, 1.5),
            "temperature_c": (10.0, 40.0),
        },
        output_key="lifetime_energy_mwh",
        trajectories=8,
        seed=3,
    )
    print("   Morris elementary effects (mu* = importance, sigma = interaction):")
    for key in morris["ranked"]:
        eff = morris["effects"][key]
        flag = "  <- effect depends on where you are" if eff["sigma"] > abs(eff["mu_star"]) else ""
        print(f"     {key:>20}  mu* {eff['mu_star']:9.3f}  sigma {eff['sigma']:9.3f}{flag}")

    # --- 5. Chemistry comparison --------------------------------------------
    print("\n5. CHEMISTRY COMPARISON, sized to the same 100 kWh at 400 V")
    chem = chemistry_comparison_study(cycles_per_year=300.0, depth_of_discharge=0.8)
    print(f"   {'chemistry':>14} {'cells':>6} {'kWh':>7} {'years':>7} {'MWh out':>9} {'/kWh':>7}")
    for e in sorted(chem.successes, key=lambda x: -x.outputs["lifetime_energy_mwh"]):
        o = e.outputs
        print(
            f"   {e.parameters['chemistry']:>14} {o['cells']:6.0f} {o['installed_kwh']:7.1f} "
            f"{o['lifetime_years']:7.1f} {o['lifetime_energy_mwh']:9.1f} {o['cost_per_kwh']:7.3f}"
        )
    print(
        "\n   The ranking is duty-dependent: this is a heavy 300-cycle-per-year duty,\n"
        "   where flatter degradation beats higher energy density. Light duty reverses it."
    )

    print(
        "\nEvery result above is a SIMULATION RESULT. The digests identify the design,\n"
        "not the results, so the same design re-run under a changed model produces the\n"
        "same digest and different numbers -- which is exactly what you want to see."
    )


if __name__ == "__main__":
    main()
