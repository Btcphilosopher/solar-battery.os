"""Example 1 -- EV charging: how much life does fast charging actually cost?

Runs one EV pack through the same 20 -> 80 % charge at three ambient
temperatures and three charge rates, and prices each outcome in the one currency
the objective function uses: money.

The point is not that fast charging is worse. It is *how much* worse, and how
sharply that changes with temperature -- which is what separates a
degradation-aware optimiser from a rule of thumb.

Run:  python examples/01_ev_fast_charge.py
"""

from __future__ import annotations

from batteryopt import Battery, Mission, Tariff
from batteryopt.applications import MissionPlanner, SmartCharger
from batteryopt.optimisation.engine import OptimisationEngine


def main() -> None:
    battery = Battery.aged(
        Battery.build(
            chemistry="nmc",
            cells_series=96,
            cells_parallel=4,
            battery_id="demo-ev",
            max_charge_power_w=150_000.0,
            max_discharge_power_w=250_000.0,
        ),
        years=2.0,
        equivalent_full_cycles=400.0,
    )
    tariff = Tariff.time_of_use(peak_price=0.42, off_peak_price=0.09, horizon_hours=48)
    engine = OptimisationEngine(battery, objective="ev", tariff=tariff)
    charger = SmartCharger(engine, dt_s=300.0)

    print(
        f"Battery: {battery.battery_id}  {battery.chemistry.name}  "
        f"{battery.nominal_energy_wh / 1000:.1f} kWh nameplate, "
        f"SOH {battery.soh_capacity * 100:.1f} %, "
        f"{battery.topology.cell_count} cells\n"
    )

    header = (
        f"{'ambient':>8} {'rate':>6} {'minutes':>8} {'kWh':>7} "
        f"{'cost':>7} {'life cost':>10} {'fade %':>8} {'peak T':>7} {'eff %':>6}"
    )
    print("CHARGING 20% -> 80%   (SIMULATION RESULT, not a measurement)")
    print(header)
    print("-" * len(header))

    for ambient in (0.0, 15.0, 30.0):
        for fraction, label in ((1.0, "max"), (0.6, "0.6x"), (0.35, "0.35x")):
            state = battery.initial_state(soc=0.2, temperature_c=ambient, ambient_c=ambient)
            saved = charger.rate_fractions
            charger.rate_fractions = (fraction,)
            try:
                plan = charger.plan(
                    state,
                    target_soc=0.8,
                    deadline_s=8 * 3600.0,
                    tariff=tariff,
                    ambient_c=ambient,
                    allow_precondition=False,
                )
            finally:
                charger.rate_fractions = saved
            life_cost = engine.economics.degradation_cost(plan.estimated_degradation)
            print(
                f"{ambient:7.0f}C {label:>6} {plan.duration_s / 60:8.1f} "
                f"{plan.energy_delivered_wh / 1000:7.2f} {plan.energy_cost:7.2f} "
                f"{life_cost:10.2f} {plan.estimated_degradation * 100:8.4f} "
                f"{plan.peak_temperature_c:7.1f} {plan.estimated_efficiency * 100:6.1f}"
            )

    print(
        "\nRead the 'life cost' column against 'cost': at 0 degC the wear from charging"
        "\nat full rate is worth more than the electricity, which is why the optimiser"
        "\nslows down when it has the time to."
    )

    # --- Mission planning: charge only what the journey needs -----------------
    print("\n\nMISSION PLANNING -- what state of charge does the trip actually need?")
    planner = MissionPlanner(engine)
    for ambient in (-5.0, 10.0, 25.0):
        state = battery.initial_state(soc=0.35, temperature_c=ambient, ambient_c=ambient)
        mission = Mission(
            energy_wh=38_000.0,
            departure_s=6 * 3600.0,
            required_reliability=0.95,
            reserve_soc=0.10,
        )
        plan = planner.plan(state, mission, ambient_c=ambient)
        print(f"  ambient {ambient:5.0f} C -> {plan.summary()}")
        for warning in plan.warnings:
            print(f"                  ! {warning}")
    print(
        "\nCold weather raises the requirement twice over: the journey costs more energy"
        "\nand the pack delivers less of what it holds."
    )


if __name__ == "__main__":
    main()
