"""Example 2 -- Grid storage: trading a day-ahead price curve, then closing the loop.

Two halves:

1. **Open loop.** Plan 24 hours of arbitrage against a day-ahead curve by dynamic
   programming, and read the numbers that decide whether to trade at all -- the
   break-even spread, the available spread, and the marginal value of a stored
   kilowatt-hour.
2. **Closed loop.** Hand the same battery to the model predictive controller and
   let it re-plan every control cycle against a plant that does not do what the
   planner assumed. This is the honest test: an open-loop schedule that looks
   profitable on paper is worth nothing if it falls apart on contact.

Run:  python examples/02_grid_arbitrage.py
"""

from __future__ import annotations

import numpy as np

from batteryopt import Battery, ModelPredictiveController, Tariff
from batteryopt.applications import ArbitrageOptimiser
from batteryopt.economics.prices import uk_style_day_ahead
from batteryopt.models.plant import BatteryPlant
from batteryopt.optimisation.engine import OptimisationEngine


def build() -> tuple[Battery, Tariff]:
    battery = Battery.aged(
        Battery.build(
            chemistry="lfp",
            cells_series=250,
            cells_parallel=4,
            battery_id="demo-bess",
            max_charge_power_w=400_000.0,
            max_discharge_power_w=400_000.0,
        ),
        years=1.0,
        equivalent_full_cycles=300.0,
    )
    curve = uk_style_day_ahead(seed=7, hours=48)
    return battery, Tariff(import_price=curve, export_price=curve, name="day-ahead")


def open_loop(battery: Battery, tariff: Tariff) -> None:
    engine = OptimisationEngine(battery, objective="grid_storage", tariff=tariff)
    optimiser = ArbitrageOptimiser(engine, horizon_s=24 * 3600.0, dt_s=1800.0)

    print("OPEN-LOOP ARBITRAGE PLAN   (OPTIMISATION RESULT)")
    print(f"  battery      {battery.nominal_energy_wh / 1000:.0f} kWh, "
          f"{battery.max_discharge_power_w / 1000:.0f} kW")

    for soc in (0.2, 0.5, 0.85):
        state = battery.initial_state(soc=soc, temperature_c=22.0, ambient_c=18.0)
        plan = optimiser.plan(state, tariff=tariff)
        schedule = [p / 1000.0 for p in plan.schedule_w[:12]]
        print(
            f"\n  starting SOC {soc * 100:.0f} %  ->  {plan.action.value} "
            f"at {plan.power_w / 1000:+.0f} kW"
        )
        print(
            f"    stored energy is worth        {plan.marginal_energy_value_per_kwh:6.3f} /kWh"
        )
        print(
            f"    a round trip needs a spread of{plan.break_even_spread_per_kwh:6.3f} /kWh"
        )
        print(
            f"    the market is offering        {plan.available_spread_per_kwh:6.3f} /kWh"
        )
        print(f"    expected revenue over 24 h    {plan.expected_revenue:6.2f}")
        print(
            "    next six hours, kW: "
            + " ".join(f"{p:+5.0f}" for p in schedule)
        )
        print(f"    {plan.reason}")

    print(
        "\n  Note that HOLD is a real answer, not a failure to decide: if the spread"
        "\n  cannot clear round-trip losses plus the wear the cycle costs, the correct"
        "\n  action is to do nothing."
    )


def closed_loop(battery: Battery, tariff: Tariff) -> None:
    engine = OptimisationEngine(battery, objective="grid_storage", tariff=tariff)
    controller = ModelPredictiveController(
        engine,
        horizon_s=6 * 3600.0,
        control_dt_s=900.0,
        planning_steps=32,
    )
    plant = BatteryPlant(battery)
    state = battery.initial_state(soc=0.5, temperature_c=22.0, ambient_c=18.0)

    cycles = 48  # 12 hours at a 15-minute control cycle
    history = controller.run(state, cycles=cycles, plant=plant, ambient_c=18.0)

    print("\n\nCLOSED-LOOP MPC   (SIMULATION RESULT -- plant is a model, not hardware)")
    summary = history.summary()
    print(
        f"  {summary['cycles']} control cycles, {summary['fallbacks']} fallbacks, "
        f"solve {summary['mean_solve_ms']:.1f} ms mean / "
        f"{summary['p95_solve_ms']:.1f} ms p95 / {summary['max_solve_ms']:.1f} ms max"
    )
    print(
        f"  SOC {history.soc[0] * 100:.0f} % -> {summary['final_soc'] * 100:.0f} % "
        f"(min {summary['min_soc'] * 100:.0f} %), "
        f"peak temperature {summary['max_temperature_c']:.1f} C"
    )

    # Did it actually buy low and sell high? Price the executed actions.
    powers = history.applied_power_w
    prices = np.array(
        [tariff.import_price.at(s.timestamp) for s in history.steps], dtype=float
    )
    charging = powers < -1_000.0
    discharging = powers > 1_000.0
    if charging.any():
        print(f"  charged  at a mean price of {prices[charging].mean() * 1000:6.1f} /MWh")
    if discharging.any():
        print(f"  discharged at a mean price of {prices[discharging].mean() * 1000:6.1f} /MWh")
    if charging.any() and discharging.any():
        captured = prices[discharging].mean() - prices[charging].mean()
        print(f"  captured spread            {captured * 1000:6.1f} /MWh")
        if captured <= 0:
            print("  (negative -- worth investigating, not worth shipping)")
    print(f"  idle cycles: {int((~charging & ~discharging).sum())} of {cycles}")

    limits = sorted(
        {
            s.recommendation.limiting_constraint
            for s in history.steps
            if s.recommendation.limiting_constraint
        }
    )
    print(f"  constraints that bound the answer at some point: {limits or ['none']}")


def main() -> None:
    battery, tariff = build()
    open_loop(battery, tariff)
    closed_loop(battery, tariff)


if __name__ == "__main__":
    main()
