"""Example 4 -- Solar plus battery: where should each watt of generation go?

Every watt-hour the array produces has four possible destinations -- the load, the
battery, the grid, or the ground (curtailed) -- and the right one depends on the
import price now, the export price now, the load and generation forecasts, and
what the battery will be worth later. This example schedules a day against a
synthetic PV and load profile and accounts for every watt-hour.

The two ratios worth reading are:

* **self-consumption** -- what fraction of generation was used on site rather than
  exported or thrown away;
* **self-sufficiency** -- what fraction of load was met without importing.

They move in opposite directions when the export price is high, which is the whole
reason the decision needs an optimiser rather than a rule.

Run:  python examples/04_solar_self_consumption.py
"""

from __future__ import annotations

import numpy as np

from batteryopt import Battery, Tariff
from batteryopt.applications import SolarOptimiser, synthetic_load_profile, synthetic_pv_profile
from batteryopt.optimisation.engine import OptimisationEngine


def main() -> None:
    battery = Battery.build(
        chemistry="lfp",
        cells_series=16,
        cells_parallel=1,
        battery_id="demo-home",
        max_charge_power_w=5_000.0,
        max_discharge_power_w=5_000.0,
    )
    print(
        f"Home battery: {battery.nominal_energy_wh / 1000:.1f} kWh, "
        f"{battery.max_discharge_power_w / 1000:.1f} kW\n"
    )

    dt_s = 1800.0
    n = 48
    solar = synthetic_pv_profile(peak_w=4_500.0, n=n, dt_s=dt_s, cloudiness=0.2, seed=5)
    load = synthetic_load_profile(base_w=350.0, peak_w=3_000.0, n=n, dt_s=dt_s, seed=5)

    print(
        f"Synthetic day: {np.trapezoid(solar, dx=dt_s) / 3.6e6:.1f} kWh generated, "
        f"{np.trapezoid(load, dx=dt_s) / 3.6e6:.1f} kWh consumed "
        "(SIMULATED inputs, not measurements)\n"
    )

    scenarios = {
        "generous export (0.15)": Tariff.time_of_use(
            peak_price=0.34, off_peak_price=0.09, export_price=0.15, horizon_hours=48
        ),
        "poor export (0.03)": Tariff.time_of_use(
            peak_price=0.34, off_peak_price=0.09, export_price=0.03, horizon_hours=48
        ),
    }

    for label, tariff in scenarios.items():
        engine = OptimisationEngine(battery, objective="consumer", tariff=tariff)
        optimiser = SolarOptimiser(engine)
        state = battery.initial_state(soc=0.35, temperature_c=20.0, ambient_c=18.0)
        plan = optimiser.plan(
            state,
            tariff=tariff,
            solar_w=solar,
            load_w=load,
            horizon_s=n * dt_s,
            dt_s=dt_s,
        )
        f = plan.flows
        print(f"--- {label} " + "-" * (52 - len(label)))
        print(f"  {plan.summary()}")
        print("  where the generation went:")
        print(f"    to load      {f.solar_to_load_wh / 1000:7.2f} kWh")
        print(f"    to battery   {f.solar_to_battery_wh / 1000:7.2f} kWh")
        print(f"    exported     {f.solar_to_grid_wh / 1000:7.2f} kWh")
        print(f"    curtailed    {f.solar_curtailed_wh / 1000:7.2f} kWh")
        print("  where the load came from:")
        print(f"    from solar   {f.solar_to_load_wh / 1000:7.2f} kWh")
        print(f"    from battery {f.battery_to_load_wh / 1000:7.2f} kWh")
        print(f"    imported     {f.grid_to_load_wh / 1000:7.2f} kWh")
        print(
            f"  economics: import {plan.grid_cost:.2f}, export {plan.export_revenue:.2f}, "
            f"wear {plan.degradation_cost:.2f}  ->  net {plan.net_cost:.2f} {plan.currency}"
        )
        print(
            "  marginal value of stored energy: "
            f"{plan.meta['marginal_energy_value_per_kwh']:.3f}/kWh"
        )
        print(f"  {plan.reason}\n")

    print(
        "When export pays well, exporting a surplus beats storing it and paying the\n"
        "round trip. When it pays badly, self-consumption wins. The battery's job\n"
        "changes with the tariff, and a fixed rule gets one of the two cases wrong."
    )


if __name__ == "__main__":
    main()
