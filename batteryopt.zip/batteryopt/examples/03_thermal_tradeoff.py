"""Example 3 -- Thermal: cooling costs energy and buys life. Which wins?

Cooling is the clearest case in the whole system where two costs are genuinely in
tension and neither is negligible. The fan draws real power, priced at the
prevailing tariff; running hot spends real capacity, priced at the amortised
replacement cost of the pack. Both are money, so they can be added, and the
optimum is wherever the sum is smallest -- which is almost never zero cooling and
almost never full cooling.

Parasitic power follows the affinity law (P proportional to u cubed), which is why
the last twenty per cent of fan speed is so expensive and why the optimum sits
where it does.

Run:  python examples/03_thermal_tradeoff.py
"""

from __future__ import annotations

from batteryopt import Battery, Tariff
from batteryopt.applications import ThermalOptimiser
from batteryopt.optimisation.engine import OptimisationEngine


def main() -> None:
    battery = Battery.aged(
        Battery.build(
            chemistry="nmc",
            cells_series=96,
            cells_parallel=4,
            battery_id="demo-thermal",
            max_charge_power_w=150_000.0,
            max_discharge_power_w=250_000.0,
        ),
        years=2.0,
        equivalent_full_cycles=400.0,
    )
    tariff = Tariff.time_of_use(peak_price=0.42, off_peak_price=0.09, horizon_hours=48)
    engine = OptimisationEngine(battery, objective="balanced", tariff=tariff)
    optimiser = ThermalOptimiser(engine)

    print("THE COOLING TRADE-OFF   (SIMULATION RESULT)")
    print(
        f"battery {battery.nominal_energy_wh / 1000:.0f} kWh, "
        f"thermal limit {battery.thermal_limits.t_max_c:.0f} C, "
        f"derate above {battery.thermal_limits.t_derate_c:.0f} C\n"
    )

    for ambient, power_kw in ((35.0, 120.0), (25.0, 120.0), (25.0, 40.0)):
        state = battery.initial_state(
            soc=0.6, temperature_c=ambient + 5.0, ambient_c=ambient
        )
        plan = optimiser.plan(
            state, power_w=power_kw * 1000.0, horizon_s=3600.0, dt_s=60.0
        )
        print(f"--- {power_kw:.0f} kW discharge, ambient {ambient:.0f} C " + "-" * 24)
        print(plan.table())
        best = plan.best
        if best is not None:
            print(
                f"  recommended cooling {plan.recommended_cooling * 100:.0f} % -> "
                f"{best.peak_temperature_c:.1f} C peak, "
                f"{best.parasitic_power_w:.0f} W parasitic, "
                f"total {best.total_cost:.3f} {plan.currency}/h"
            )
        print(f"  {plan.reason}\n")

    # --- Heating: the other end of the same trade-off ------------------------
    print("--- Too cold to charge " + "-" * 40)
    cold = battery.initial_state(soc=0.3, temperature_c=-8.0, ambient_c=-8.0)
    plan = optimiser.plan(cold, power_w=-60_000.0, horizon_s=3600.0, dt_s=60.0)
    print(
        f"  recommended heating {plan.recommended_heating * 100:.0f} %  "
        f"(cooling {plan.recommended_cooling * 100:.0f} %)"
    )
    print(f"  {plan.reason}")
    print(
        "\n  Charging a cold cell plates lithium metal on the anode: permanent, and\n"
        "  disproportionately damaging. Spending a few hundred watt-hours on the\n"
        "  heater first is very often the cheaper path -- and the optimiser can only\n"
        "  discover that if preconditioning is on the table as a candidate."
    )


if __name__ == "__main__":
    main()
