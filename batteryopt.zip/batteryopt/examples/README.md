# Examples

Every example runs on the core dependencies alone (NumPy, SciPy, Pydantic) and
takes seconds, not minutes. None of them touches hardware; every number they print
is a MODEL, SIMULATION or OPTIMISATION result.

| Script | What it shows |
|---|---|
| `01_ev_fast_charge.py` | What fast charging actually costs, priced in money, across three ambient temperatures and three rates. Then mission planning: the smallest charge that makes a journey safe. |
| `02_grid_arbitrage.py` | Day-ahead arbitrage by dynamic programming, including why `HOLD` is a real answer. Then the same battery under closed-loop MPC against a plant that does not do what the planner assumed. |
| `03_thermal_tradeoff.py` | Cooling power spent against battery life bought, both in money, with the affinity-law parasitic cost that puts the optimum in the interior. Then the cold case, where heating first is cheaper than charging cold. |
| `04_solar_self_consumption.py` | Where each watt-hour of generation should go, and how the answer flips when the export price changes. |
| `05_research_sweep.py` | Reproducible batch research: full factorial, Monte Carlo reliability, one-at-a-time elasticity and Morris screening, plus a like-for-like chemistry comparison. |
| `06_safety_refusal.py` | The engine refusing. Every method, every adversarial state, verified afterwards against the hard constraints. Deliberately dull to watch. |

Run them all:

```bash
for f in examples/0*.py; do echo "== $f"; python "$f"; done
```
