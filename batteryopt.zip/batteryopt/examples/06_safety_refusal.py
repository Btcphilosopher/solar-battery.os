"""Example 6 -- The engine refusing, on purpose.

The single most important property in BatteryOpt is negative: **no optimiser,
under any objective, at any state, can return a recommendation whose simulated
consequences violate a hard constraint.** Either the engine returns something
legal, or it refuses. There is no third outcome.

This example puts the battery in states where the tempting answer is illegal and
shows what comes back. It is deliberately unexciting to watch, which is the point.

Run:  python examples/06_safety_refusal.py
"""

from __future__ import annotations

from batteryopt import (
    Action,
    Battery,
    BatteryPlant,
    Constraint,
    ConstraintKind,
    ConstraintSet,
    InfeasibleProblem,
    SafetyViolation,
    Tariff,
    available_methods,
)
from batteryopt.optimisation.engine import OptimisationEngine
from batteryopt.optimisation.problem import Demand


ADVERSARIAL = [
    ("empty and cold", 0.03, -18.0),
    ("empty", 0.03, 25.0),
    ("full and hot", 0.99, 52.0),
    ("hot", 0.60, 51.0),
    ("cold", 0.60, -19.0),
    ("full", 0.99, 25.0),
    ("at the derate knee", 0.50, 41.0),
    # Above the cell's absolute temperature limit. Resting does not fix this, so
    # no scaling of any plan can make it legal and the engine has to refuse.
    ("over temperature", 0.60, 58.0),
]


def main() -> None:
    battery = Battery.build(
        chemistry="nmc",
        cells_series=96,
        cells_parallel=4,
        battery_id="demo-safety",
        max_charge_power_w=150_000.0,
        max_discharge_power_w=250_000.0,
    )
    tariff = Tariff.time_of_use(peak_price=0.42, off_peak_price=0.09, horizon_hours=48)

    limits = battery.thermal_limits
    print("HARD CONSTRAINTS ARE NOT OBJECTIVE TERMS")
    print(
        f"  voltage {battery.minimum_voltage:.0f}-{battery.maximum_voltage:.0f} V, "
        f"temperature {limits.t_min_c:.0f} to {limits.t_max_c:.0f} C, "
        f"charging only between {limits.t_min_charge_c:.0f} and "
        f"{limits.t_max_charge_c:.0f} C\n"
    )

    # A maximum-power objective is the most adversarial thing available: it wants
    # the largest legal number and has no reason of its own to stop.
    engine = OptimisationEngine(battery, objective="industrial", tariff=tariff)

    header = f"{'state':>20} {'method':>20} {'outcome':>12}   detail"
    print(header)
    print("-" * 96)

    refusals = 0
    recommendations = 0
    for label, soc, temperature in ADVERSARIAL:
        state = battery.initial_state(
            soc=soc, temperature_c=temperature, ambient_c=temperature
        )
        for method in available_methods():
            if method in {"pareto", "mpc"}:
                continue
            engine.method = method
            engine.commitment_window_s = 0.0
            try:
                result = engine.optimise_state(
                    state,
                    # Ask for everything the pack has, firmly, so nothing in the
                    # objective has a reason of its own to hold back.
                    demand=Demand(power_w=250_000.0, firm=True),
                    horizon_s=600.0,
                    dt_s=60.0,
                    ambient_c=temperature,
                )
            except (SafetyViolation, InfeasibleProblem) as exc:
                refusals += 1
                print(f"{label:>20} {method:>20} {'REFUSED':>12}   {exc}")
                continue
            recommendations += 1
            # Verify rather than trust: re-simulate independently of the engine
            # and re-check from scratch against a fresh constraint set.
            plant = BatteryPlant(battery)
            actions = [
                Action(
                    power_w=result.recommended_power_w,
                    cooling_fraction=result.cooling_requirement,
                )
            ] * 10
            trajectory = plant.simulate(state.as_simulated(), actions, 60.0)
            violations = ConstraintSet(battery).hard_violations(trajectory.states)
            verdict = "OK" if not violations else "*** VIOLATION ***"
            print(
                f"{label:>20} {method:>20} {verdict:>12}   "
                f"{result.recommended_power_w / 1000:+8.1f} kW via {result.method}, "
                f"bound by {result.limiting_constraint or 'nothing (interior)'}"
            )
            if violations:
                raise SystemExit(f"safety property broken: {violations}")

    print(
        f"\n{recommendations} recommendations, every one of them legal; "
        f"{refusals} refusals.\n"
        "No recommendation violated a hard constraint, which is the property the\n"
        "test suite asserts across every method and every adversarial state."
    )

    # --- Operator limits can tighten, never widen ---------------------------
    print("\nOPERATOR LIMITS CAN ONLY EVER BE TIGHTENED")
    # Judged over half an hour rather than one minute: a state-of-charge rail
    # only binds the *power* once the interval is long enough to reach it.
    state = battery.initial_state(soc=0.68, temperature_c=25.0, ambient_c=25.0)

    default = ConstraintSet(battery)
    tight = ConstraintSet(battery, soc_reserve=0.30, soc_ceiling=0.70)
    print(
        "  An operator reserve is *soft* by default: a mission may legitimately eat\n"
        "  into it, but the optimiser has to be told to. So it appears in the soft\n"
        "  bounds and not in the hard ones -- which is the distinction that matters."
    )
    for name, cs in (("cell envelope only", default), ("reserve 30 %, ceiling 70 %", tight)):
        hard = cs.bounds(state, 1800.0)
        soft = cs.bounds(state, 1800.0, include_soft=True)
        print(
            f"  {name:<26} hard {hard.min_power_w / 1000:+7.0f} .. "
            f"{hard.max_power_w / 1000:+7.0f} kW   "
            f"soft {soft.min_power_w / 1000:+7.0f} .. {soft.max_power_w / 1000:+7.0f} kW "
            f"(by {soft.discharge_limiting})"
        )

    # Asking for a wider voltage window than the cells have does not widen it.
    original = default.get("terminal_voltage")
    default.add(
        Constraint(
            name="terminal_voltage",
            quantity="voltage_v",
            kind=ConstraintKind.HARD,
            unit="V",
            lower=original.lower - 100.0,
            upper=original.upper + 100.0,
            source="a well-meaning but wrong configuration",
        )
    )
    updated = default.get("terminal_voltage")
    print(
        f"\n  asked for {original.lower - 100:.0f}-{original.upper + 100:.0f} V, "
        f"got {updated.lower:.0f}-{updated.upper:.0f} V "
        "-- the envelope belongs to the cells, not the operator"
    )

    # And a hard constraint cannot be quietly demoted to a soft one.
    try:
        default.add(
            Constraint(
                name="terminal_voltage",
                quantity="voltage_v",
                kind=ConstraintKind.SOFT,
                unit="V",
                lower=updated.lower,
                upper=updated.upper,
                source="an attempt to make the limit negotiable",
            )
        )
    except SafetyViolation as exc:
        print(f"  downgrading it to soft -> SafetyViolation: {exc}")

    # A battery configured with an impossible envelope is clamped at build time.
    reckless = Battery.build(
        chemistry="nmc",
        cells_series=96,
        cells_parallel=4,
        envelope_overrides={"v_max_cell": 4.9, "t_max_c": 200.0, "max_charge_c_rate": 99.0},
    )
    chem = reckless.chemistry.envelope
    print(
        f"  requested 4.9 V / 200 C / 99 C-rate -> got "
        f"{reckless.envelope.v_max_cell:.2f} V / {reckless.envelope.t_max_c:.0f} C / "
        f"{reckless.envelope.max_charge_c_rate:.1f} C-rate "
        f"(chemistry allows {chem.v_max_cell:.2f} V / {chem.t_max_c:.0f} C / "
        f"{chem.max_charge_c_rate:.1f})"
    )


if __name__ == "__main__":
    main()
