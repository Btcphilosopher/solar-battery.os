"""Forecasting: point accuracy, band calibration and the ML opt-out."""

from __future__ import annotations

import numpy as np
import pytest

from batteryopt.core.provenance import Provenance
from batteryopt.forecasting.base import Forecast, ensemble
from batteryopt.forecasting.domain import (
    LoadForecaster,
    MissionEnergyForecaster,
    PriceForecaster,
    SolarForecaster,
    TemperatureForecaster,
)
from batteryopt.forecasting.learned import ResidualLearner, torch_available
from batteryopt.forecasting.statistical import (
    ExponentialSmoothingForecaster,
    HarmonicRegressionForecaster,
    PersistenceForecaster,
    SeasonalNaiveForecaster,
    non_negative,
)

DT = 1800.0


def _daily_signal(days: float = 7.0, noise: float = 60.0, seed: int = 0):
    rng = np.random.default_rng(seed)
    times = np.arange(0.0, days * 86400.0, DT)
    hod = (times / 3600.0) % 24.0
    values = (
        900.0
        + 600.0 * np.exp(-0.5 * ((hod - 7.5) / 1.2) ** 2)
        + 1400.0 * np.exp(-0.5 * ((hod - 18.5) / 1.9) ** 2)
        + rng.normal(0.0, noise, times.size)
    )
    return times, values


def _truth(times: np.ndarray) -> np.ndarray:
    hod = (times / 3600.0) % 24.0
    return (
        900.0
        + 600.0 * np.exp(-0.5 * ((hod - 7.5) / 1.2) ** 2)
        + 1400.0 * np.exp(-0.5 * ((hod - 18.5) / 1.9) ** 2)
    )


# --- forecast container ----------------------------------------------------


def test_forecast_quantiles_are_ordered_even_if_supplied_crossed():
    times = np.array([0.0, 60.0])
    forecast = Forecast(
        times_s=times,
        p50=np.array([1.0, 1.0]),
        p10=np.array([2.0, 2.0]),  # deliberately crossed
        p90=np.array([0.0, 0.0]),
    )
    assert np.all(forecast.p10 <= forecast.p50)
    assert np.all(forecast.p50 <= forecast.p90)


def test_forecasts_are_tagged_predicted():
    times, values = _daily_signal(days=3)
    forecast = PersistenceForecaster().fit(times, values).predict(3600.0, DT)
    assert forecast.provenance is Provenance.PREDICTED


def test_forecast_integrates_to_energy():
    times = np.arange(0.0, 3600.0 * 4, 3600.0)
    forecast = Forecast(
        times_s=times,
        p50=np.full(times.size, 1000.0),
        p10=np.full(times.size, 900.0),
        p90=np.full(times.size, 1100.0),
        unit="W",
    )
    assert forecast.total() == pytest.approx(3000.0)


# --- statistical methods ---------------------------------------------------


def test_harmonic_regression_beats_persistence_on_a_daily_signal():
    times, values = _daily_signal()
    horizon = 86400.0
    grid = times[-1] + np.arange(int(horizon / DT) + 1) * DT
    truth = _truth(grid)

    harmonic = HarmonicRegressionForecaster().fit(times, values).predict(
        horizon, DT, origin_s=times[-1]
    )
    persistence = PersistenceForecaster().fit(times, values).predict(
        horizon, DT, origin_s=times[-1]
    )
    assert np.mean(np.abs(harmonic.p50 - truth)) < np.mean(
        np.abs(persistence.p50 - truth)
    )


def test_seasonal_naive_reproduces_the_daily_shape():
    times, values = _daily_signal(noise=10.0)
    forecast = SeasonalNaiveForecaster().fit(times, values).predict(
        86400.0, DT, origin_s=times[-1]
    )
    truth = _truth(forecast.times_s)
    assert np.corrcoef(forecast.p50, truth)[0, 1] > 0.9


def test_damped_trend_does_not_run_away():
    times = np.arange(0.0, 40 * DT, DT)
    values = 100.0 + 5.0 * np.arange(times.size)
    forecast = ExponentialSmoothingForecaster().fit(times, values).predict(
        86400.0, DT, origin_s=times[-1]
    )
    # Undamped extrapolation would reach ~340 above the last value.
    assert forecast.p50[-1] < values[-1] + 120.0


def test_bands_widen_with_lead_time():
    times, values = _daily_signal()
    forecast = HarmonicRegressionForecaster().fit(times, values).predict(
        86400.0, DT, origin_s=times[-1]
    )
    width = forecast.p90 - forecast.p10
    assert width[-1] > width[0]


def test_backtested_bands_are_used_when_history_allows():
    times, values = _daily_signal()
    forecast = HarmonicRegressionForecaster().fit(times, values).predict(7200.0, DT)
    assert forecast.uncertainty_method == "backtest"


def test_non_negative_clips_the_whole_band():
    forecast = Forecast(
        times_s=np.array([0.0, 1.0]),
        p50=np.array([10.0, -5.0]),
        p10=np.array([-20.0, -30.0]),
        p90=np.array([30.0, 5.0]),
    )
    clipped = non_negative(forecast)
    assert np.all(clipped.p10 >= 0.0)
    assert np.all(clipped.p50 >= 0.0)


# --- ensembling ------------------------------------------------------------


def test_disagreeing_members_widen_the_ensemble_band():
    times = np.linspace(0.0, 10.0, 11)
    def make(offset: float) -> Forecast:
        return Forecast(
            times_s=times,
            p50=np.full(11, 100.0 + offset),
            p10=np.full(11, 90.0 + offset),
            p90=np.full(11, 110.0 + offset),
        )

    agree = ensemble([make(0.0), make(0.0)])
    disagree = ensemble([make(-20.0), make(20.0)])
    assert (disagree.p90 - disagree.p10).mean() > (agree.p90 - agree.p10).mean()


# --- domain forecasters ----------------------------------------------------


def test_load_forecast_is_accurate_and_calibrated():
    times, values = _daily_signal()
    forecast = LoadForecaster().fit(times, values).predict(86400.0, DT, origin_s=times[-1])
    truth = _truth(forecast.times_s)
    assert np.mean(np.abs(forecast.p50 - truth)) < 0.2 * values.std()
    coverage = float(np.mean((truth >= forecast.p10) & (truth <= forecast.p90)))
    assert coverage > 0.6, f"P10-P90 covered only {coverage:.0%} of the truth"
    assert np.all(forecast.p10 >= 0.0)


def test_solar_forecast_is_zero_at_night_and_bounded_by_clear_sky():
    forecaster = SolarForecaster(capacity_w=5000.0)
    times = np.arange(0.0, 5 * 86400.0, DT)
    rng = np.random.default_rng(1)
    generation = forecaster.clear_sky(times) * np.clip(
        0.75 + 0.2 * rng.standard_normal(times.size), 0.0, 1.0
    )
    forecast = forecaster.fit(times, generation).predict(86400.0, DT, origin_s=times[-1])
    envelope = forecaster.clear_sky(forecast.times_s)
    assert np.all(forecast.p50 >= -1e-9)
    assert np.all(forecast.p50 <= envelope + 1e-6)
    assert np.all(forecast.p90 <= envelope + 1e-6)
    night = envelope < 1e-9
    assert np.all(forecast.p50[night] == pytest.approx(0.0))


def test_price_forecast_may_go_negative():
    rng = np.random.default_rng(2)
    times = np.arange(0.0, 5 * 86400.0, DT)
    hod = (times / 3600.0) % 24.0
    prices = 0.05 + 0.08 * np.sin(2 * np.pi * (hod - 8) / 24) + rng.normal(0, 0.01, times.size)
    forecast = PriceForecaster().fit(times, prices).predict(86400.0, DT, origin_s=times[-1])
    assert forecast.p10.min() < forecast.p50.min()
    assert "heteroscedastic" in forecast.uncertainty_method


def test_price_forecast_converts_to_a_price_curve():
    rng = np.random.default_rng(3)
    times = np.arange(0.0, 4 * 86400.0, DT)
    prices = 0.10 + 0.03 * np.sin(times / 43200.0) + rng.normal(0, 0.005, times.size)
    forecaster = PriceForecaster().fit(times, prices)
    forecast = forecaster.predict(86400.0, DT, origin_s=times[-1])
    curve = forecaster.to_price_curve(forecast)
    assert curve.prices.size == forecast.p50.size


def test_temperature_forecast_is_smooth():
    rng = np.random.default_rng(4)
    times = np.arange(0.0, 5 * 86400.0, DT)
    hod = (times / 3600.0) % 24.0
    temps = 12.0 + 8.0 * np.sin(2 * np.pi * (hod - 9) / 24) + rng.normal(0, 0.4, times.size)
    forecast = TemperatureForecaster().fit(times, temps).predict(
        86400.0, DT, origin_s=times[-1]
    )
    assert np.max(np.abs(np.diff(forecast.p50))) < 4.0
    assert forecast.unit == "degC"


def test_mission_energy_learns_from_completed_journeys():
    forecaster = MissionEnergyForecaster(default_wh_per_km=200.0)
    for distance, energy in [(50, 8000), (120, 19000), (30, 4800), (200, 32000),
                             (80, 12800), (65, 10400)]:
        forecaster.observe_mission(distance_km=distance, energy_wh=energy, ambient_c=20.0)
    assert forecaster.wh_per_km == pytest.approx(160.0, rel=0.05)
    warm = forecaster.estimate(distance_km=100.0, ambient_c=20.0)
    cold = forecaster.estimate(distance_km=100.0, ambient_c=-5.0)
    assert cold.p50 > warm.p50
    assert warm.p10 < warm.p50 < warm.p90


# --- the ML opt-out --------------------------------------------------------


def test_the_learned_layer_is_optional_and_transparent():
    """Without PyTorch the residual is zero and the baseline stands unchanged."""
    times, values = _daily_signal()
    baseline = HarmonicRegressionForecaster()
    learner = ResidualLearner(HarmonicRegressionForecaster())
    baseline.fit(times, values)
    learner.fit(times, values)
    plain = baseline.predict(7200.0, DT, origin_s=times[-1])
    layered = learner.predict(7200.0, DT, origin_s=times[-1])
    if not torch_available():
        assert not learner.trained
        np.testing.assert_allclose(plain.p50, layered.p50)
    else:  # pragma: no cover - only when torch is installed
        assert layered.p50.shape == plain.p50.shape


def test_the_learned_layer_reports_whether_it_helps():
    times, values = _daily_signal()
    learner = ResidualLearner(HarmonicRegressionForecaster())
    verdict = learner.improves_on_baseline(times, values)
    assert "baseline_mae" in verdict
    assert isinstance(verdict["improves"], bool)
    if not torch_available():
        assert verdict["improves"] is False
