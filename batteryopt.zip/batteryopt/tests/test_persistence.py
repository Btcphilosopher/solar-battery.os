"""Persistence: immutability, reproducibility and caching."""

from __future__ import annotations

import time

import pytest

from batteryopt.core.exceptions import ImmutabilityError
from batteryopt.models.battery import Battery
from batteryopt.optimisation.engine import OptimisationEngine
from batteryopt.persistence.cache import LocalCache, open_cache, versioned_key
from batteryopt.persistence.repository import (
    InMemoryRepository,
    PostgresRepository,
    Repository,
    open_repository,
)
from batteryopt.telemetry.schema import TelemetryFrame
from batteryopt.telemetry.validation import TelemetryValidator


def _frame(k: int = 0) -> TelemetryFrame:
    return TelemetryFrame(
        battery_id="b1", timestamp=float(k), voltage_v=350.0, current_a=10.0,
        temperature_c=25.0, sequence=k,
    )


def test_the_in_memory_repository_satisfies_the_protocol():
    assert isinstance(InMemoryRepository(), Repository)


def test_raw_telemetry_cannot_be_deleted():
    repository = InMemoryRepository()
    record = repository.append_telemetry(_frame())
    with pytest.raises(ImmutabilityError, match="append-only"):
        repository.delete_telemetry(record.id)


def test_raw_telemetry_cannot_be_modified():
    repository = InMemoryRepository()
    record = repository.append_telemetry(_frame())
    with pytest.raises(ImmutabilityError):
        repository.update_telemetry(record.id, voltage_v=0.0)


def test_stored_telemetry_records_are_frozen():
    repository = InMemoryRepository()
    record = repository.append_telemetry(_frame())
    with pytest.raises((AttributeError, TypeError)):
        record.accepted = False  # type: ignore[misc]


def test_validation_outcomes_are_stored_beside_the_raw_frame(ev_battery: Battery):
    repository = InMemoryRepository()
    validator = TelemetryValidator(ev_battery)
    bad = TelemetryFrame(
        battery_id="b1", timestamp=0.0, voltage_v=9999.0, current_a=0.0, temperature_c=25.0
    )
    result = validator.validate(bad)
    record = repository.append_telemetry(bad, result)
    assert not record.accepted
    assert record.issues
    # The rejected frame is still there: it is evidence of what the sensor said.
    assert len(repository.recent_telemetry("b1")) == 1


def test_the_repository_is_bounded():
    repository = InMemoryRepository(max_telemetry=50)
    for k in range(120):
        repository.append_telemetry(_frame(k))
    assert repository.stats()["telemetry"] == 50
    assert repository.evicted_telemetry == 70


def test_optimisation_runs_are_reproducible_by_digest(ev_battery: Battery):
    repository = InMemoryRepository()
    engine = OptimisationEngine(ev_battery, objective="balanced")
    state = ev_battery.initial_state(soc=0.55, temperature_c=25.0)
    first = engine.optimise_state(state, demand=25_000.0, horizon_s=600.0, dt_s=60.0)
    record = repository.append_recommendation(first, battery_id="b1")

    assert repository.find_run(record.digest) is not None
    assert record.model_version
    assert record.code_version
    assert record.optimiser_version

    second = engine.optimise_state(state, demand=25_000.0, horizon_s=600.0, dt_s=60.0)
    assert second.fingerprint.digest == record.digest


def test_latest_state_and_recommendation_are_retrievable(ev_battery: Battery):
    repository = InMemoryRepository()
    engine = OptimisationEngine(ev_battery, objective="balanced")
    state = ev_battery.initial_state(soc=0.5, temperature_c=25.0)
    repository.append_state(state, battery_id="b1")
    recommendation = engine.optimise_state(state, demand=10_000.0)
    repository.append_recommendation(recommendation, battery_id="b1")
    assert repository.latest_state("b1").soc == pytest.approx(0.5)
    assert repository.latest_recommendation("b1") is not None
    assert repository.latest_state("other") is None


def test_open_repository_falls_back_to_memory():
    assert isinstance(open_repository(None), InMemoryRepository)


def test_the_schema_declares_immutable_telemetry():
    sql = PostgresRepository.schema_sql()
    assert "telemetry_immutable" in sql
    assert "BEFORE UPDATE OR DELETE ON telemetry" in sql
    assert "append-only" in sql
    # Reproducibility fields required by section 26.
    for column in ("model_version", "configuration_version", "inputs", "constraints",
                   "objective", "result", "digest"):
        assert column in sql


def test_the_schema_covers_every_required_table():
    sql = PostgresRepository.schema_sql()
    for table in (
        "batteries", "cells", "modules", "packs", "telemetry", "state_estimates",
        "health_estimates", "charging_sessions", "discharging_sessions",
        "thermal_events", "degradation_events", "optimisation_runs",
        "recommendations", "scenarios", "maintenance",
    ):
        assert f"CREATE TABLE IF NOT EXISTS {table}" in sql, table


# --- cache -----------------------------------------------------------------


def test_the_local_cache_evicts_least_recently_used():
    cache = LocalCache(max_items=2)
    cache.set("a", 1)
    cache.set("b", 2)
    cache.get("a")          # touch a, so b is now least recently used
    cache.set("c", 3)
    assert cache.get("b") is None
    assert cache.get("a") == 1


def test_cache_entries_expire():
    cache = LocalCache(default_ttl_s=0.01)
    cache.set("k", "v")
    time.sleep(0.02)
    assert cache.get("k") is None


def test_cache_keys_carry_the_model_version():
    from batteryopt.core.versioning import MODEL_VERSION

    assert MODEL_VERSION in versioned_key("surrogate", "abc")


def test_open_cache_falls_back_without_redis():
    assert isinstance(open_cache(None), LocalCache)
    assert isinstance(open_cache("redis://localhost:1/0"), LocalCache)


def test_cache_statistics_are_reported():
    cache = LocalCache()
    cache.set("k", 1)
    cache.get("k")
    cache.get("missing")
    stats = cache.stats()
    assert stats["hits"] == 1
    assert stats["misses"] == 1
    assert stats["hit_rate"] == pytest.approx(0.5)
