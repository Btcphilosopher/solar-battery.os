"""Numerical stability, reproducibility under repetition, and concurrency."""

from __future__ import annotations

import concurrent.futures
import threading

import numpy as np
import pytest

from batteryopt.core.numerics import (
    clamp,
    crowding_distance,
    golden_section,
    invert_monotone,
    normalise_weights,
    pareto_mask,
    safe_div,
    soft_min,
)
from batteryopt.core.provenance import Provenance, Quantiles, Quantity
from batteryopt.core.versioning import RunFingerprint, canonical_json, content_hash
from batteryopt.models.battery import Battery
from batteryopt.models.plant import Action, BatteryPlant
from batteryopt.optimisation.constraints import ConstraintSet
from batteryopt.optimisation.engine import OptimisationEngine


# --- numerics --------------------------------------------------------------


def test_clamp_handles_an_inverted_interval():
    assert clamp(5.0, 10.0, 0.0) == 10.0


def test_safe_div_does_not_explode():
    assert safe_div(1.0, 0.0) == 0.0
    assert safe_div(1.0, 0.0, default=99.0) == 99.0


def test_monotone_inversion_saturates_outside_the_bracket():
    f = lambda x: x**2  # noqa: E731
    assert invert_monotone(f, -1.0, 0.0, 2.0) == 0.0
    assert invert_monotone(f, 100.0, 0.0, 2.0) == 2.0
    assert invert_monotone(f, 2.0, 0.0, 2.0) == pytest.approx(2.0**0.5, abs=1e-6)


def test_monotone_inversion_handles_a_decreasing_function():
    f = lambda x: 10.0 - x  # noqa: E731
    assert invert_monotone(f, 4.0, 0.0, 10.0) == pytest.approx(6.0, abs=1e-6)


def test_golden_section_finds_a_minimum():
    x, value = golden_section(lambda v: (v - 3.0) ** 2, 0.0, 10.0)
    assert x == pytest.approx(3.0, abs=1e-4)
    assert value == pytest.approx(0.0, abs=1e-6)


def test_soft_min_is_never_below_the_true_minimum_by_much():
    values = [1.0, 2.0, 3.0]
    assert soft_min(values) <= min(values)
    assert soft_min(values) > min(values) - 0.2


def test_pareto_mask_finds_the_non_dominated_set():
    costs = np.array([[1.0, 5.0], [2.0, 2.0], [5.0, 1.0], [3.0, 3.0], [6.0, 6.0]])
    mask = pareto_mask(costs)
    assert mask.tolist() == [True, True, True, False, False]


def test_crowding_distance_marks_the_extremes_as_infinite():
    costs = np.array([[0.0, 1.0], [0.5, 0.5], [1.0, 0.0]])
    distances = crowding_distance(costs)
    assert np.isinf(distances[0]) and np.isinf(distances[2])
    assert np.isfinite(distances[1])


def test_weights_normalise_and_survive_an_all_zero_case():
    assert normalise_weights({"a": 1.0, "b": 3.0}) == {"a": 0.25, "b": 0.75}
    assert normalise_weights({"a": 0.0, "b": 0.0}) == {"a": 0.0, "b": 0.0}


# --- provenance ------------------------------------------------------------


def test_derived_values_inherit_the_weakest_provenance():
    assert Provenance.MEASURED.combine(Provenance.SIMULATED) is Provenance.SIMULATED
    assert Provenance.ESTIMATED.combine(Provenance.MEASURED) is Provenance.ESTIMATED


def test_quantiles_must_be_ordered():
    with pytest.raises(ValueError):
        Quantiles(p10=2.0, p50=1.0, p90=3.0)


def test_quantile_scaling_survives_a_negative_factor():
    scaled = Quantiles(1.0, 2.0, 3.0).scaled(-1.0)
    assert scaled.p10 <= scaled.p50 <= scaled.p90


def test_confidence_falls_with_a_wider_band():
    tight = Quantity(1.0, "W", Provenance.PREDICTED, quantiles=Quantiles(0.95, 1.0, 1.05))
    wide = Quantity(1.0, "W", Provenance.PREDICTED, quantiles=Quantiles(0.2, 1.0, 1.8))
    assert tight.confidence > wide.confidence


def test_measured_beats_simulated_on_confidence():
    measured = Quantity(1.0, "V", Provenance.MEASURED)
    simulated = Quantity(1.0, "V", Provenance.SIMULATED)
    assert measured.confidence > simulated.confidence


# --- fingerprints ----------------------------------------------------------


def test_canonical_json_is_order_independent():
    assert canonical_json({"b": 1, "a": 2}) == canonical_json({"a": 2, "b": 1})


def test_canonical_json_refuses_non_finite_numbers():
    """NaN does not round-trip through strict JSON, so it must not be hashed."""
    with pytest.raises(ValueError):
        canonical_json({"x": float("nan")})


def test_content_hash_is_stable_and_sensitive():
    assert content_hash({"a": 1}) == content_hash({"a": 1})
    assert content_hash({"a": 1}) != content_hash({"a": 2})


def test_fingerprints_ignore_the_runtime_but_not_the_inputs():
    a = RunFingerprint.build(inputs={"x": 1}, constraints={}, objective={})
    b = RunFingerprint.build(inputs={"x": 1}, constraints={}, objective={})
    c = RunFingerprint.build(inputs={"x": 2}, constraints={}, objective={})
    assert a.matches(b)
    assert not a.matches(c)


# --- numerical stability of the models -------------------------------------


def test_long_simulations_stay_finite(ev_battery: Battery):
    """A quarter of a million steps: drift and instability have time to show."""
    plant = BatteryPlant(ev_battery, track_states=False)
    state = ev_battery.initial_state(soc=0.5, temperature_c=25.0)
    for k in range(250_000):
        power = 30_000.0 if (k // 500) % 2 == 0 else -25_000.0
        state = plant.step(state, Action(power_w=power), 10.0).state
        if k % 25_000 == 0:
            assert np.isfinite(state.soc)
            assert np.isfinite(state.voltage_v)
            assert np.isfinite(state.temperature_c)
    assert 0.0 <= state.soc <= 1.0
    assert state.degradation.capacity_fade >= 0.0
    assert -50.0 < state.temperature_c < 100.0


@pytest.mark.parametrize("dt", [0.1, 1.0, 60.0, 600.0, 3600.0])
def test_the_plant_is_stable_at_any_step_size(ev_battery: Battery, dt: float):
    plant = BatteryPlant(ev_battery, track_states=False)
    state = ev_battery.initial_state(soc=0.5, temperature_c=25.0)
    for _ in range(50):
        state = plant.step(state, Action(power_w=40_000.0), dt).state
        assert np.isfinite(state.temperature_c)
        assert 0.0 <= state.soc <= 1.0


def test_extreme_inputs_do_not_produce_nonsense(ev_battery: Battery):
    plant = BatteryPlant(ev_battery, track_states=False)
    for soc in (0.0, 1.0):
        for temperature in (-40.0, 80.0):
            state = ev_battery.initial_state(soc=soc, temperature_c=temperature)
            for power in (-1e8, 0.0, 1e8):
                result = plant.step(state, Action(power_w=power), 60.0)
                assert np.isfinite(result.state.voltage_v)
                assert np.isfinite(result.state.soc)


def test_repeated_optimisation_is_bit_identical(ev_battery: Battery):
    engine = OptimisationEngine(ev_battery, objective="ev")
    state = ev_battery.initial_state(soc=0.62, temperature_c=27.0)
    answers = {
        engine.optimise_state(state, demand=35_000.0, horizon_s=600.0, dt_s=60.0)
        .recommended_power_w
        for _ in range(5)
    }
    assert len(answers) == 1


# --- concurrency -----------------------------------------------------------


def test_concurrent_optimisations_on_separate_engines_agree(ev_battery: Battery):
    """Each thread gets its own engine, as a real service would."""
    state = ev_battery.initial_state(soc=0.6, temperature_c=25.0)

    def solve(_seed: int) -> float:
        engine = OptimisationEngine(ev_battery, objective="balanced")
        return engine.optimise_state(
            state, demand=30_000.0, horizon_s=600.0, dt_s=60.0
        ).recommended_power_w

    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        results = list(pool.map(solve, range(16)))
    assert len(set(round(r, 6) for r in results)) == 1


def test_concurrent_constraint_checks_are_safe(ev_battery: Battery):
    constraints = ConstraintSet(ev_battery)
    states = [
        ev_battery.initial_state(soc=soc, temperature_c=25.0)
        for soc in np.linspace(0.05, 0.95, 32)
    ]

    def check(state):
        return len(constraints.check_state(state))

    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        counts = list(pool.map(check, states))
    assert all(c == 0 for c in counts)


def test_the_service_serialises_access_to_a_shared_twin(ev_battery: Battery):
    """The estimator is stateful; interleaved updates would corrupt it."""
    from batteryopt.api.state import ServiceState

    service = ServiceState()
    managed = service.register(ev_battery, objective="balanced", initial_soc=0.5)
    errors: list[Exception] = []

    def work(index: int) -> None:
        try:
            with service.lock:
                managed.engine.optimise_state(
                    managed.twin.state, demand=20_000.0, horizon_s=300.0, dt_s=60.0
                )
        except Exception as exc:  # noqa: BLE001
            errors.append(exc)

    threads = [threading.Thread(target=work, args=(k,)) for k in range(8)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()
    assert not errors


def test_concurrent_telemetry_ingestion_is_consistent(ev_battery: Battery):
    from batteryopt.api.state import ServiceState
    from batteryopt.telemetry.schema import TelemetryFrame

    service = ServiceState()
    managed = service.register(ev_battery, objective="balanced", initial_soc=0.5)

    def ingest(k: int) -> None:
        with service.lock:
            managed.pipeline.ingest(
                TelemetryFrame(
                    battery_id=ev_battery.battery_id,
                    timestamp=float(k),
                    voltage_v=350.0,
                    current_a=20.0,
                    temperature_c=25.0,
                )
            )

    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        list(pool.map(ingest, range(50)))
    assert managed.pipeline.stats.frames_in == 50
