"""Degradation model: signs, monotonicity, calibration and marginal rates."""

from __future__ import annotations

import numpy as np
import pytest

from batteryopt.models.battery import Battery
from batteryopt.models.degradation import DegradationModel, RainflowCounter
from batteryopt.models.state import DegradationState


@pytest.fixture
def model(ev_battery: Battery) -> DegradationModel:
    return ev_battery.degradation


def test_fade_starts_at_zero(model: DegradationModel):
    """The formation offsets must not make a new battery start already aged."""
    assert model.fade(0.0, 0.0) == pytest.approx(0.0, abs=1e-15)
    assert model.growth(0.0, 0.0) == pytest.approx(0.0, abs=1e-15)


def test_fade_is_monotone_in_both_mechanisms(model: DegradationModel):
    times = np.linspace(0, 25, 100)
    assert np.all(np.diff([model.fade(t, 0.0) for t in times]) >= 0)
    cycles = np.linspace(0, 6000, 100)
    assert np.all(np.diff([model.fade(0.0, a) for a in cycles]) >= 0)


def test_marginal_damage_per_cycle_declines_with_age(model: DegradationModel):
    """Sub-linear ageing: the hundredth cycle costs more than the thousandth."""
    early = model.fade(0.0, 101.0) - model.fade(0.0, 100.0)
    late = model.fade(0.0, 3001.0) - model.fade(0.0, 3000.0)
    assert early > late > 0
    # ...but not by an absurd factor, which is what an unoffset power law gives.
    assert early / late < 8.0


def test_calendar_stress_signs(model: DegradationModel):
    warm = model.calendar_stress(soc=0.5, temperature_c=25.0)
    assert model.calendar_stress(soc=0.5, temperature_c=45.0) > warm
    assert model.calendar_stress(soc=0.95, temperature_c=25.0) > warm
    assert model.calendar_stress(soc=0.5, temperature_c=5.0) < warm


def test_deep_low_soc_carries_an_extra_penalty(model: DegradationModel, ev_battery):
    """A correction near empty, on top of the monotone SOC trend.

    Calendar ageing genuinely falls with state of charge, so sitting at 1 % is
    *still* gentler than sitting at 15 % -- asserting otherwise would be
    asserting something false. What the model adds is a correction near empty
    for anode-potential excursions, and the honest test is that the correction
    exists: the stress at very low SOC is above what the bare exponential trend
    alone would give.
    """
    import math

    coefficients = ev_battery.chemistry.degradation
    soc = 0.5 * coefficients.low_soc_threshold
    trend_only = math.exp(coefficients.soc_stress_gain * (soc - coefficients.soc_stress_ref))
    assert model.calendar_stress(soc=soc, temperature_c=25.0) > trend_only
    # And the correction must vanish above the threshold.
    above = coefficients.low_soc_threshold + 0.05
    trend_above = math.exp(
        coefficients.soc_stress_gain * (above - coefficients.soc_stress_ref)
    )
    assert model.calendar_stress(soc=above, temperature_c=25.0) == pytest.approx(trend_above)


def test_cycle_stress_signs(model: DegradationModel):
    base = model.cycle_stress(c_rate=0.5, temperature_c=25.0, dod=0.5, charging=False)
    assert model.cycle_stress(c_rate=2.0, temperature_c=25.0, dod=0.5, charging=False) > base
    assert model.cycle_stress(c_rate=0.5, temperature_c=25.0, dod=0.9, charging=False) > base
    assert model.cycle_stress(c_rate=0.5, temperature_c=45.0, dod=0.5, charging=False) > base
    assert model.cycle_stress(c_rate=0.5, temperature_c=25.0, dod=0.5, charging=True) > base


def test_plating_applies_only_to_cold_charging(any_battery: Battery):
    model = any_battery.degradation
    threshold = any_battery.chemistry.degradation.plating_threshold_c
    assert model.plating_multiplier(
        temperature_c=threshold - 15.0, c_rate=1.0, charging=True
    ) > 1.0
    assert model.plating_multiplier(
        temperature_c=threshold - 15.0, c_rate=1.0, charging=False
    ) == 1.0
    assert model.plating_multiplier(
        temperature_c=threshold + 15.0, c_rate=1.0, charging=True
    ) == 1.0


def test_plating_penalty_is_bounded(any_battery: Battery):
    """An unbounded penalty makes the optimiser refuse to charge at all."""
    model = any_battery.degradation
    cap = any_battery.chemistry.degradation.plating_max_multiplier
    assert model.plating_multiplier(temperature_c=-60.0, c_rate=10.0, charging=True) <= cap


def test_cold_fast_charging_is_the_worst_case(ev_battery: Battery):
    model = ev_battery.degradation
    cold_fast = model.cycle_stress(c_rate=2.0, temperature_c=-5.0, dod=0.6, charging=True)
    warm_fast = model.cycle_stress(c_rate=2.0, temperature_c=25.0, dod=0.6, charging=True)
    warm_slow = model.cycle_stress(c_rate=0.3, temperature_c=25.0, dod=0.6, charging=True)
    assert cold_fast > warm_fast > warm_slow


def test_step_accumulates_and_reports_its_stresses(ev_battery: Battery):
    model = ev_battery.degradation
    state = DegradationState()
    new_state, increment = model.step(
        state,
        dt=3600.0,
        soc=0.9,
        temperature_c=40.0,
        current_a=200.0,
        nameplate_capacity_ah=ev_battery.nameplate_capacity_ah,
        dod=0.6,
    )
    assert new_state.capacity_fade > 0
    assert new_state.t_eq_years > 0
    assert new_state.a_eq_efc > 0
    assert increment.calendar_stress > 1.0
    assert increment.throughput_ah == pytest.approx(200.0)


def test_marginal_rate_agrees_with_a_finite_difference(ev_battery: Battery):
    model = ev_battery.degradation
    state = DegradationState(t_eq_years=2.0, a_eq_efc=400.0)
    state = DegradationState(
        t_eq_years=2.0, a_eq_efc=400.0, capacity_fade=model.fade(2.0, 400.0)
    )
    rate = model.marginal_fade_rate(
        state, soc=0.6, temperature_c=30.0, current_a=150.0,
        nameplate_capacity_ah=ev_battery.nameplate_capacity_ah, dod=0.6,
    )
    dt = 10.0
    _, increment = model.step(
        state, dt=dt, soc=0.6, temperature_c=30.0, current_a=150.0,
        nameplate_capacity_ah=ev_battery.nameplate_capacity_ah, dod=0.6,
    )
    assert rate * dt == pytest.approx(increment.capacity_fade, rel=1e-4)


def test_remaining_life_shortens_under_harsher_duty(ev_battery: Battery):
    model = ev_battery.degradation
    state = ev_battery.degradation_state
    gentle = model.remaining_useful_life(
        state, soc=0.5, temperature_c=20.0, mean_current_a=30.0,
        nameplate_capacity_ah=ev_battery.nameplate_capacity_ah,
    )
    harsh = model.remaining_useful_life(
        state, soc=0.9, temperature_c=40.0, mean_current_a=200.0,
        nameplate_capacity_ah=ev_battery.nameplate_capacity_ah,
    )
    assert harsh.remaining_years < gentle.remaining_years
    assert harsh.quantiles_years.p10 <= harsh.remaining_years <= harsh.quantiles_years.p90


def test_confidence_falls_outside_the_fitted_envelope(ev_battery: Battery):
    model = ev_battery.degradation
    inside = model.confidence(soc=0.5, temperature_c=25.0, c_rate=0.5)
    assert model.confidence(soc=0.5, temperature_c=60.0, c_rate=0.5) < inside
    assert model.confidence(soc=0.5, temperature_c=25.0, c_rate=5.0) < inside
    assert model.confidence(soc=0.99, temperature_c=25.0, c_rate=0.5) < inside


def test_aged_batteries_land_in_the_expected_range():
    """Sanity-check the calibration against published fleet behaviour."""
    base = Battery.build(chemistry="nmc", cells_series=96, cells_parallel=4)
    eight_years = Battery.aged(base, years=8, equivalent_full_cycles=1200)
    assert 0.75 < eight_years.soh_capacity < 0.88
    one_year = Battery.aged(base, years=1, equivalent_full_cycles=150)
    assert 0.94 < one_year.soh_capacity < 0.99


def test_hot_storage_at_high_soc_is_measurably_worse():
    base = Battery.build(chemistry="nmc", cells_series=96, cells_parallel=4)
    cool = Battery.aged(base, years=5, equivalent_full_cycles=0, mean_soc=0.5,
                        mean_temperature_c=20.0)
    hot = Battery.aged(base, years=5, equivalent_full_cycles=0, mean_soc=0.9,
                       mean_temperature_c=40.0)
    assert hot.soh_capacity < cool.soh_capacity - 0.05


# --- rainflow --------------------------------------------------------------


def test_rainflow_counts_a_simple_sequence():
    counter = RainflowCounter()
    for value in (0.5, 0.9, 0.4, 0.7, 0.2, 0.8, 0.3):
        counter.update(value)
    counter.close()
    assert counter.cycles
    assert counter.equivalent_full_cycles > 0
    assert 0.0 < counter.mean_dod() <= 1.0


def test_rainflow_weights_deep_cycles_more_heavily():
    """One 80 % swing must not look like four 20 % swings."""
    deep = RainflowCounter()
    for value in (0.1, 0.9, 0.1):
        deep.update(value)
    deep.close()
    shallow = RainflowCounter()
    for value in (0.5, 0.7, 0.5, 0.7, 0.5, 0.7, 0.5, 0.7, 0.5):
        shallow.update(value)
    shallow.close()
    assert deep.mean_dod() > shallow.mean_dod()


def test_rainflow_ignores_a_flat_trace():
    counter = RainflowCounter()
    for _ in range(50):
        counter.update(0.5)
    counter.close()
    assert counter.equivalent_full_cycles == pytest.approx(0.0, abs=1e-12)


def test_projection_is_monotone_decreasing(ev_battery: Battery):
    model = ev_battery.degradation
    projection = model.project(
        ev_battery.degradation_state,
        years=np.linspace(0, 15, 40),
        soc=0.6,
        temperature_c=28.0,
        mean_current_a=60.0,
        nameplate_capacity_ah=ev_battery.nameplate_capacity_ah,
    )
    assert np.all(np.diff(projection["soh_capacity"]) <= 1e-12)
    assert np.all(np.diff(projection["resistance_growth"]) >= -1e-12)
