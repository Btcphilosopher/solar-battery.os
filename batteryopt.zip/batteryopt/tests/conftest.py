"""Shared fixtures.

Batteries used by tests are deliberately *aged* rather than brand new. A pack
at beginning of life sits at the steep end of the ageing power law, where the
marginal cost of a cycle is several times the mid-life value, and a test suite
built entirely on new packs would never exercise the regime the optimiser
actually operates in.
"""

from __future__ import annotations

import numpy as np
import pytest

from batteryopt.economics.prices import Tariff, uk_style_day_ahead
from batteryopt.models.battery import Battery
from batteryopt.optimisation.constraints import ConstraintSet
from batteryopt.optimisation.engine import OptimisationEngine

CHEMISTRIES = ["nmc", "lfp", "nca", "sodium_ion", "lto", "lithium_ion_generic"]


@pytest.fixture(scope="session")
def ev_battery() -> Battery:
    """An 84 kWh automotive pack, two years old with 400 cycles on it."""
    return Battery.aged(
        Battery.build(
            chemistry="nmc",
            cells_series=96,
            cells_parallel=4,
            battery_id="ev-test",
            max_charge_power_w=110_000.0,
            max_discharge_power_w=250_000.0,
        ),
        years=2.0,
        equivalent_full_cycles=400.0,
    )


@pytest.fixture(scope="session")
def grid_battery() -> Battery:
    """A large LFP stationary pack."""
    return Battery.aged(
        Battery.build(
            chemistry="lfp",
            cells_series=250,
            cells_parallel=4,
            battery_id="bess-test",
            max_charge_power_w=400_000.0,
            max_discharge_power_w=400_000.0,
        ),
        years=1.0,
        equivalent_full_cycles=300.0,
    )


@pytest.fixture(scope="session")
def small_battery() -> Battery:
    """A consumer-scale cell, to catch scale-dependent bugs."""
    return Battery.build(
        chemistry="lithium_ion_generic",
        cells_series=4,
        cells_parallel=1,
        battery_id="consumer-test",
    )


@pytest.fixture(params=CHEMISTRIES)
def any_battery(request: pytest.FixtureRequest) -> Battery:
    """One battery per registered chemistry, sized sensibly for each."""
    sizes = {
        "nmc": (96, 4),
        "lfp": (250, 2),
        "nca": (100, 3),
        "sodium_ion": (200, 2),
        "lto": (150, 3),
        "lithium_ion_generic": (13, 2),
    }
    series, parallel = sizes[request.param]
    return Battery.aged(
        Battery.build(
            chemistry=request.param,
            cells_series=series,
            cells_parallel=parallel,
            battery_id=f"{request.param}-test",
        ),
        years=1.5,
        equivalent_full_cycles=300.0,
    )


@pytest.fixture
def tou_tariff() -> Tariff:
    return Tariff.time_of_use(
        peak_price=0.42, off_peak_price=0.09, export_price=0.15, horizon_hours=72
    )


@pytest.fixture
def day_ahead_tariff() -> Tariff:
    curve = uk_style_day_ahead(seed=3, hours=48)
    return Tariff(import_price=curve, export_price=curve, name="test day-ahead")


@pytest.fixture
def ev_engine(ev_battery: Battery, tou_tariff: Tariff) -> OptimisationEngine:
    return OptimisationEngine(ev_battery, objective="ev", tariff=tou_tariff)


@pytest.fixture
def grid_engine(grid_battery: Battery, day_ahead_tariff: Tariff) -> OptimisationEngine:
    return OptimisationEngine(grid_battery, objective="grid_storage", tariff=day_ahead_tariff)


@pytest.fixture
def constraints(ev_battery: Battery) -> ConstraintSet:
    return ConstraintSet(ev_battery, soc_reserve=0.1, soc_ceiling=0.95)


@pytest.fixture
def rng() -> np.random.Generator:
    return np.random.default_rng(20260818)
