"""The HTTP service and the dashboard."""

from __future__ import annotations

import pytest

fastapi = pytest.importorskip("fastapi")
from fastapi.testclient import TestClient  # noqa: E402

from batteryopt.api.app import create_app, seed_demo  # noqa: E402
from batteryopt.api.state import ServiceState  # noqa: E402


@pytest.fixture(scope="module")
def client() -> TestClient:
    service = ServiceState()
    seed_demo(service)
    return TestClient(create_app(service))


def test_health_reports_versions(client: TestClient):
    payload = client.get("/health").json()
    assert payload["status"] == "ok"
    assert "code" in payload["versions"]
    assert "demo-ev" in payload["batteries"]


def test_capabilities_lists_optional_dependencies(client: TestClient):
    payload = client.get("/capabilities").json()
    assert "pybamm" in payload["optional_dependencies"]
    assert "nmc" in payload["chemistries"]
    assert "ev" in payload["objectives"]
    for entry in payload["optional_dependencies"].values():
        if not entry["available"]:
            assert entry["fallback_in_use"]


def test_state_carries_provenance(client: TestClient):
    payload = client.get("/batteries/demo-ev/state").json()
    assert payload["provenance"]["soc"] == "ESTIMATED"
    assert payload["provenance"]["voltage_v"] == "MEASURED"


def test_optimise_returns_the_specified_fields(client: TestClient):
    payload = client.post(
        "/batteries/demo-ev/optimise",
        json={"demand_w": 40_000.0, "horizon_s": 600.0, "dt_s": 60.0},
    ).json()
    for key in (
        "recommended_power_w", "recommended_charge_rate_w", "recommended_discharge_rate_w",
        "cooling_requirement", "target_soc", "estimated_efficiency",
        "estimated_degradation", "estimated_cost", "confidence", "limiting_constraint",
    ):
        assert key in payload


def test_telemetry_is_accepted_and_bad_frames_are_rejected(client: TestClient):
    before = client.get("/batteries/demo-ev/telemetry/stats").json()["pipeline"]
    good = client.post(
        "/batteries/demo-ev/telemetry",
        json={"timestamp": 1e7, "voltage_v": 360.0, "current_a": 80.0, "temperature_c": 26.0},
    )
    assert good.status_code == 200
    bad = client.post(
        "/batteries/demo-ev/telemetry",
        json={"timestamp": 1e7 + 1, "voltage_v": 9999.0, "current_a": 80.0,
              "temperature_c": 26.0},
    ).json()
    assert bad["rejected"] > before["frames_rejected"]


def test_a_malformed_payload_is_a_422(client: TestClient):
    response = client.post("/batteries/demo-ev/telemetry", json={"voltage_v": "banana"})
    assert response.status_code == 422


def test_an_unknown_battery_is_a_404(client: TestClient):
    assert client.get("/batteries/nope/state").status_code == 404
    assert client.post("/batteries/nope/optimise", json={}).status_code == 404


def test_registering_a_battery(client: TestClient):
    response = client.post(
        "/batteries",
        json={
            "battery_id": "bess-api",
            "chemistry": "lfp",
            "cells_series": 250,
            "cells_parallel": 4,
            "objective": "grid_storage",
            "import_price_per_kwh": 0.12,
            "export_price_per_kwh": 0.05,
        },
    )
    assert response.status_code == 201
    assert response.json()["battery"]["chemistry"] == "lfp"
    assert "bess-api" in client.get("/health").json()["batteries"]
    assert client.delete("/batteries/bess-api").json()["removed"]


def test_registering_an_unknown_chemistry_is_a_400(client: TestClient):
    response = client.post(
        "/batteries", json={"battery_id": "x", "chemistry": "unobtanium"}
    )
    assert response.status_code == 400


def test_pareto_endpoint_returns_named_roles(client: TestClient):
    payload = client.get("/batteries/demo-ev/pareto?horizon_s=600&dt_s=120").json()
    assert payload["points"]
    assert "balanced" in payload["roles"]


def test_the_twin_snapshot_is_complete(client: TestClient):
    payload = client.get("/batteries/demo-ev/twin").json()
    assert set(payload) == {"state", "diagnostics", "life", "history", "battery"}


def test_the_dashboard_renders_and_explains_itself(client: TestClient):
    response = client.get("/dashboard/demo-ev")
    assert response.status_code == 200
    body = response.text
    assert "BATTERYOPT" in body
    assert "WHY THIS OPERATING POINT" in body
    assert "ALTERNATIVES CONSIDERED" in body
    # Provenance discipline must be visible on the page itself.
    assert "not measurements" in body
    assert "<script" not in body.lower()  # self-contained, no external requests


def test_the_dashboard_404s_for_an_unknown_battery(client: TestClient):
    assert client.get("/dashboard/nope").status_code == 404


def test_the_index_redirects_to_the_first_battery(client: TestClient):
    assert client.get("/").status_code == 200


def test_a_run_can_be_looked_up_by_digest(client: TestClient):
    recommendation = client.post(
        "/batteries/demo-ev/optimise", json={"demand_w": 20_000.0}
    ).json()
    digest = recommendation["fingerprint"]["digest"]
    # The demo service persists through the pipeline, so a direct optimise call
    # may not be stored; either way the endpoint must answer coherently.
    response = client.get(f"/runs/{digest}")
    assert response.status_code in (200, 404)
