"""Chemistry parameter sets: structure, physics and configurability."""

from __future__ import annotations

import numpy as np
import pytest

from batteryopt.core.exceptions import ChemistryNotFound, ConfigurationError
from batteryopt.models.chemistry import (
    REGISTRY,
    ChemistryParameters,
    OCVCurve,
    available_chemistries,
    get_chemistry,
    register_chemistry,
)
from batteryopt.models.topology import Topology


def test_builtin_chemistries_load():
    names = available_chemistries()
    assert {"nmc", "lfp", "nca", "sodium_ion", "lto"}.issubset(set(names))


def test_unknown_chemistry_names_the_alternatives():
    with pytest.raises(ChemistryNotFound) as exc:
        get_chemistry("unobtanium")
    assert "nmc" in str(exc.value)


@pytest.mark.parametrize("name", available_chemistries())
def test_ocv_is_monotone_and_inside_the_envelope(name):
    chem = get_chemistry(name)
    grid = np.linspace(0.0, 1.0, 201)
    voltages = np.asarray(chem.ocv.voltage_at(grid), dtype=float)
    assert np.all(np.diff(voltages) >= -1e-9), "OCV must be non-decreasing in SOC"
    assert voltages.min() >= chem.envelope.v_min_cell - 1e-6
    assert voltages.max() <= chem.envelope.v_max_cell + 1e-6


@pytest.mark.parametrize("name", available_chemistries())
def test_resistance_rises_as_temperature_falls(name):
    chem = get_chemistry(name)
    cold = chem.resistance.r0(temperature_c=-10.0, soc=0.5)
    warm = chem.resistance.r0(temperature_c=25.0, soc=0.5)
    hot = chem.resistance.r0(temperature_c=45.0, soc=0.5)
    assert cold > warm > hot


@pytest.mark.parametrize("name", available_chemistries())
def test_resistance_rises_at_both_soc_extremes(name):
    chem = get_chemistry(name)
    mid = chem.resistance.r0(temperature_c=25.0, soc=0.5)
    assert chem.resistance.r0(temperature_c=25.0, soc=0.02) > mid
    assert chem.resistance.r0(temperature_c=25.0, soc=0.98) > mid


def test_lfp_plateau_is_flatter_than_nmc():
    """The property that makes LFP hard to estimate, asserted rather than assumed."""
    lfp = get_chemistry("lfp").ocv.slope_at(0.5)
    nmc = get_chemistry("nmc").ocv.slope_at(0.5)
    assert lfp < 0.25 * nmc


def test_ocv_curve_rejects_decreasing_voltage():
    with pytest.raises(ValueError):
        OCVCurve(soc=[0.0, 0.5, 1.0], voltage=[3.0, 3.5, 3.2])


def test_ocv_curve_rejects_unsorted_soc():
    with pytest.raises(ValueError):
        OCVCurve(soc=[0.0, 0.5, 0.4], voltage=[3.0, 3.5, 3.6])


def test_envelope_must_contain_the_ocv_curve():
    base = get_chemistry("nmc").model_dump()
    base["name"] = "broken"
    base["envelope"]["v_max_cell"] = 3.5  # below the top of the OCV curve
    with pytest.raises(ValueError, match="never reach 100"):
        ChemistryParameters.model_validate(base)


def test_custom_chemistry_can_be_registered_and_used():
    payload = get_chemistry("nmc").model_dump()
    payload["name"] = "test-custom"
    payload["nominal_capacity_ah"] = 25.0
    chem = ChemistryParameters.model_validate(payload)
    register_chemistry(chem, overwrite=True)
    assert "test-custom" in available_chemistries()
    topology = Topology.build(chemistry="test-custom", cells_series=10, cells_parallel=2)
    assert topology.capacity_ah == pytest.approx(25.0 * 2 * 0.97)


def test_registering_a_duplicate_needs_overwrite():
    chem = get_chemistry("nmc")
    with pytest.raises(ConfigurationError, match="already registered"):
        register_chemistry(chem)


@pytest.mark.parametrize("name", available_chemistries())
def test_energy_integral_beats_the_naive_product(name):
    """Energy is the OCV integral, not nominal voltage times amp-hours."""
    chem = get_chemistry(name)
    integrated = chem.energy_wh_cell()
    naive = chem.nominal_voltage_cell * chem.nominal_capacity_ah
    assert integrated > 0
    # They should be close but not identical; identical would mean the integral
    # is not actually being taken.
    assert 0.75 < integrated / naive < 1.15
    assert integrated != pytest.approx(naive, rel=1e-9)


@pytest.mark.parametrize("name", available_chemistries())
def test_degradation_coefficients_hit_their_anchor(name):
    """20 % fade at the chemistry's rated cycle life, from cycling alone."""
    chem = get_chemistry(name)
    deg = chem.degradation
    a0 = deg.formation_efc
    anchor = ((0.20 / deg.a_cycle) + a0**deg.z_cycle) ** (1.0 / deg.z_cycle) - a0
    assert 1_500 < anchor < 25_000, f"{name}: implied cycle life {anchor:.0f} EFC"


def test_registry_isolation_helper():
    REGISTRY.clear_user_entries()
    assert "nmc" in available_chemistries()
