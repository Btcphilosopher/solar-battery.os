"""The application layer: charging, missions, discharge, thermal, balancing,
arbitrage, solar, grid services and lifetime."""

from __future__ import annotations

import numpy as np
import pytest

from batteryopt.applications.arbitrage import ArbitrageAction, ArbitrageOptimiser
from batteryopt.applications.balancing import BalancingOptimiser
from batteryopt.applications.charging import SmartCharger
from batteryopt.applications.discharge import DischargePlanner
from batteryopt.applications.grid_services import (
    GridServiceOptimiser,
    ServiceContract,
    ServiceType,
    typical_contracts,
)
from batteryopt.applications.lifetime import LifetimeOptimiser, standard_policies
from batteryopt.applications.mission import (
    MissionPlanner,
    temperature_energy_factor,
)
from batteryopt.applications.solar import (
    SolarOptimiser,
    synthetic_load_profile,
    synthetic_pv_profile,
)
from batteryopt.applications.thermal import ThermalOptimiser
from batteryopt.core.provenance import Quantiles
from batteryopt.economics.prices import Tariff
from batteryopt.estimation.imbalance import ImbalanceReport
from batteryopt.models.battery import Battery
from batteryopt.optimisation.engine import OptimisationEngine
from batteryopt.optimisation.problem import Mission


# --- charging --------------------------------------------------------------


def test_slower_charging_costs_less_life(ev_engine: OptimisationEngine, tou_tariff: Tariff):
    charger = SmartCharger(ev_engine)
    state = ev_engine.battery.initial_state(soc=0.3, temperature_c=25.0)
    plans = charger.compare_rates(
        state, target_soc=0.8, deadline_s=4 * 3600.0, tariff=tou_tariff, ambient_c=25.0
    )
    by_label = {p.label: p for p in plans}
    assert by_label["SLOW"].estimated_degradation < by_label["FAST"].estimated_degradation
    assert by_label["SLOW"].duration_s > by_label["FAST"].duration_s


def test_charging_reports_when_the_deadline_cannot_be_met(ev_engine: OptimisationEngine):
    charger = SmartCharger(ev_engine)
    state = ev_engine.battery.initial_state(soc=0.1, temperature_c=25.0)
    plan = charger.plan(state, target_soc=0.95, deadline_s=120.0)
    assert not plan.feasible
    assert "NOT reachable" in plan.reason


def test_no_charge_needed_is_reported_cleanly(ev_engine: OptimisationEngine):
    charger = SmartCharger(ev_engine)
    state = ev_engine.battery.initial_state(soc=0.85, temperature_c=25.0)
    plan = charger.plan(state, target_soc=0.8, deadline_s=3600.0)
    assert plan.energy_delivered_wh == 0.0
    assert plan.mean_power_w == 0.0


def test_charging_delays_into_the_cheap_window(ev_engine: OptimisationEngine):
    """Do not assume maximum charging speed is optimal."""
    tariff = Tariff.time_of_use(
        peak_price=0.60, off_peak_price=0.05, peak_start_hour=0, peak_end_hour=4,
        horizon_hours=48,
    )
    charger = SmartCharger(ev_engine, dt_s=900.0)
    state = ev_engine.battery.initial_state(soc=0.4, temperature_c=25.0)
    plan = charger.plan(
        state, target_soc=0.75, deadline_s=10 * 3600.0, tariff=tariff, ambient_c=20.0
    )
    assert plan.start_s > 0.0, "charging should wait for the cheap window"


def test_minimum_duration_scales_with_the_energy_required(ev_engine: OptimisationEngine):
    charger = SmartCharger(ev_engine)
    state = ev_engine.battery.initial_state(soc=0.2, temperature_c=25.0)
    short = charger.minimum_duration_s(state, 0.4)
    long = charger.minimum_duration_s(state, 0.9)
    assert long > short > 0


# --- mission ---------------------------------------------------------------


def test_cold_weather_raises_the_mission_requirement():
    assert temperature_energy_factor(-10.0) > temperature_energy_factor(5.0)
    assert temperature_energy_factor(5.0) > temperature_energy_factor(20.0)
    assert temperature_energy_factor(20.0) == pytest.approx(1.0)
    assert temperature_energy_factor(35.0) > 1.0


def test_mission_plan_charges_only_what_is_needed(ev_engine: OptimisationEngine):
    planner = MissionPlanner(ev_engine)
    battery = ev_engine.battery
    state = battery.initial_state(soc=0.5, temperature_c=20.0)
    mission = Mission(
        energy_wh=20_000.0,
        departure_s=8 * 3600.0,
        quantiles=Quantiles(18_000.0, 20_000.0, 23_000.0),
        required_reliability=0.9,
        reserve_soc=0.1,
        ambient_c=20.0,
    )
    plan = planner.plan(state, mission, ambient_c=20.0)
    # It needs some charge but nowhere near full: charging to 100 % "to be safe"
    # is the single most common way to destroy an EV pack.
    assert plan.recommended_target_soc < 0.95


def test_a_bigger_mission_needs_a_higher_target(ev_engine: OptimisationEngine):
    planner = MissionPlanner(ev_engine)
    battery = ev_engine.battery
    state = battery.initial_state(soc=0.4, temperature_c=20.0)
    small = planner.plan(
        state, Mission(energy_wh=10_000.0, departure_s=8 * 3600.0, ambient_c=20.0)
    )
    large = planner.plan(
        state, Mission(energy_wh=45_000.0, departure_s=8 * 3600.0, ambient_c=20.0)
    )
    assert large.recommended_target_soc > small.recommended_target_soc


def test_higher_reliability_demands_more_charge(ev_engine: OptimisationEngine):
    planner = MissionPlanner(ev_engine)
    state = ev_engine.battery.initial_state(soc=0.4, temperature_c=20.0)
    quantiles = Quantiles(30_000.0, 36_000.0, 45_000.0)
    cautious = planner.plan(
        state,
        Mission(energy_wh=36_000.0, departure_s=8 * 3600.0, quantiles=quantiles,
                required_reliability=0.9, ambient_c=20.0),
    )
    relaxed = planner.plan(
        state,
        Mission(energy_wh=36_000.0, departure_s=8 * 3600.0, quantiles=quantiles,
                required_reliability=0.5, ambient_c=20.0),
    )
    assert cautious.recommended_target_soc > relaxed.recommended_target_soc
    assert cautious.shortfall_risk <= relaxed.shortfall_risk


def test_mission_report_renders(ev_engine: OptimisationEngine):
    planner = MissionPlanner(ev_engine)
    state = ev_engine.battery.initial_state(soc=0.6, temperature_c=10.0)
    plan = planner.plan(
        state, Mission(energy_wh=30_000.0, departure_s=6 * 3600.0, ambient_c=5.0),
        ambient_c=5.0,
    )
    report = planner.report(plan, state)
    assert "BATTERYOPT" in report
    assert "Recommended target" in report


# --- discharge -------------------------------------------------------------


def test_discharge_serves_a_firm_load_when_it_can(ev_engine: OptimisationEngine):
    planner = DischargePlanner(ev_engine)
    state = ev_engine.battery.initial_state(soc=0.7, temperature_c=25.0)
    plan = planner.plan(state, load_w=40_000.0, horizon_s=900.0, dt_s=60.0)
    # At least the load, and no residual. It may legitimately discharge *more*
    # than the load when export is worth more than storage -- which is a
    # decision, not a bug -- so the assertion is a floor, not an equality.
    assert plan.battery_power_w >= 40_000.0 * 0.95
    assert plan.fully_served


def test_discharge_reports_a_residual_it_cannot_cover(ev_engine: OptimisationEngine):
    planner = DischargePlanner(ev_engine)
    state = ev_engine.battery.initial_state(soc=0.06, temperature_c=25.0)
    plan = planner.plan(state, load_w=200_000.0, horizon_s=1800.0, dt_s=120.0)
    assert plan.residual_load_w > 0
    assert not plan.fully_served


def test_sustainable_power_respects_the_reserve(ev_engine: OptimisationEngine):
    planner = DischargePlanner(ev_engine)
    state = ev_engine.battery.initial_state(soc=0.5, temperature_c=25.0)
    generous = planner.sustainable_power(state, duration_s=3600.0, reserve_soc=0.05)
    strict = planner.sustainable_power(state, duration_s=3600.0, reserve_soc=0.4)
    assert generous > strict >= 0.0


# --- thermal ---------------------------------------------------------------


def test_thermal_plan_produces_a_priced_curve(ev_engine: OptimisationEngine):
    optimiser = ThermalOptimiser(ev_engine)
    state = ev_engine.battery.initial_state(soc=0.6, temperature_c=30.0, ambient_c=28.0)
    plan = optimiser.plan(state, power_w=60_000.0, horizon_s=1800.0, dt_s=120.0)
    assert len(plan.points) == len(optimiser.fractions)
    assert plan.best is not None
    assert "cooling" in plan.reason.lower()
    temperatures = [p.peak_temperature_c for p in plan.points]
    assert temperatures == sorted(temperatures, reverse=True)


def test_cooling_reduces_degradation_but_costs_energy(ev_engine: OptimisationEngine):
    optimiser = ThermalOptimiser(ev_engine)
    state = ev_engine.battery.initial_state(soc=0.6, temperature_c=35.0, ambient_c=33.0)
    plan = optimiser.plan(state, power_w=80_000.0, horizon_s=1800.0, dt_s=120.0)
    points = {p.cooling_fraction: p for p in plan.points}
    assert points[1.0].capacity_fade < points[0.0].capacity_fade
    assert points[1.0].parasitic_power_w > points[0.0].parasitic_power_w


def test_heating_is_recommended_when_too_cold_to_charge(ev_engine: OptimisationEngine):
    optimiser = ThermalOptimiser(ev_engine)
    cold = ev_engine.battery.initial_state(
        soc=0.4, temperature_c=ev_engine.battery.thermal_limits.t_min_charge_c - 4.0
    )
    assert optimiser.heating_requirement(cold) > 0.0
    warm = ev_engine.battery.initial_state(soc=0.4, temperature_c=25.0)
    assert optimiser.heating_requirement(warm) == 0.0


# --- balancing -------------------------------------------------------------


def _report(spread: float, confidence: float = 0.9) -> ImbalanceReport:
    return ImbalanceReport(
        voltage_spread_v=spread * 0.4,
        soc_spread=spread,
        resistance_spread=0.1,
        min_cell_soc=0.5 - spread / 2,
        max_cell_soc=0.5 + spread / 2,
        outlier_cells=(),
        capacity_loss_fraction=spread,
        balancing_charge_ah=spread * 60.0 * 96 / 2,
        confidence=confidence,
    )


def test_balancing_declines_a_trivial_spread(ev_battery: Battery):
    optimiser = BalancingOptimiser(ev_battery)
    plan = optimiser.plan(
        ev_battery.initial_state(soc=0.9, temperature_c=25.0), _report(0.002)
    )
    assert not plan.should_balance


def test_balancing_accepts_a_worthwhile_spread(ev_battery: Battery):
    optimiser = BalancingOptimiser(ev_battery)
    plan = optimiser.plan(
        ev_battery.initial_state(soc=0.9, temperature_c=25.0),
        _report(0.05),
        energy_value_per_kwh=0.30,
    )
    assert plan.should_balance
    assert plan.net_value > 0
    assert plan.duration_s > 0


def test_balancing_declines_when_it_cannot_tell_what_the_spread_is(ev_battery: Battery):
    optimiser = BalancingOptimiser(ev_battery)
    plan = optimiser.plan(
        ev_battery.initial_state(soc=0.9, temperature_c=25.0),
        _report(0.05, confidence=0.1),
    )
    assert not plan.should_balance
    assert "confident" in plan.reason


def test_balancing_advice_depends_on_where_the_curve_is_steep(ev_battery: Battery):
    optimiser = BalancingOptimiser(ev_battery)
    top = optimiser.best_window(ev_battery.initial_state(soc=0.92, temperature_c=25.0))
    assert "now" in top


# --- arbitrage -------------------------------------------------------------


def test_arbitrage_trades_a_wide_spread(grid_engine: OptimisationEngine, day_ahead_tariff):
    optimiser = ArbitrageOptimiser(grid_engine)
    state = grid_engine.battery.initial_state(soc=0.4, temperature_c=22.0)
    plan = optimiser.plan(state, tariff=day_ahead_tariff, horizon_s=24 * 3600.0, dt_s=1800.0)
    assert plan.worth_trading
    assert plan.cycles_planned > 0.2
    # The immediate action may well be HOLD -- waiting for a better moment is
    # exactly what a scheduler is for. What must be true is that the *schedule*
    # trades in both directions.
    schedule = np.asarray(plan.schedule_w)
    assert (schedule < -1000.0).any(), "the schedule never charges"
    assert (schedule > 1000.0).any(), "the schedule never discharges"
    assert plan.action in tuple(ArbitrageAction)


def test_arbitrage_reports_a_break_even_spread(grid_engine: OptimisationEngine):
    optimiser = ArbitrageOptimiser(grid_engine)
    state = grid_engine.battery.initial_state(soc=0.5, temperature_c=22.0)
    break_even = optimiser.break_even_spread(0.10, state=state)
    assert 0.0 < break_even < 0.10
    assert optimiser.wear_cost_per_kwh() > 0


def test_arbitrage_declines_a_spread_that_cannot_pay(grid_engine: OptimisationEngine):
    optimiser = ArbitrageOptimiser(grid_engine)
    state = grid_engine.battery.initial_state(soc=0.5, temperature_c=22.0)
    tariff = Tariff.time_of_use(
        peak_price=0.1005, off_peak_price=0.10, export_price=0.10, horizon_hours=48
    )
    plan = optimiser.plan(state, tariff=tariff, horizon_s=24 * 3600.0, dt_s=1800.0)
    assert not plan.worth_trading
    assert plan.cycles_planned < 0.5


def test_one_way_efficiency_comes_from_the_model(grid_engine: OptimisationEngine):
    optimiser = ArbitrageOptimiser(grid_engine)
    state = grid_engine.battery.initial_state(soc=0.5, temperature_c=22.0)
    efficiency = optimiser.one_way_efficiency(state)
    assert 0.9 < efficiency < 1.0


# --- solar -----------------------------------------------------------------


def test_solar_profiles_are_physical():
    pv = synthetic_pv_profile(peak_w=5000.0, n=96, dt_s=900.0)
    assert pv.min() >= 0.0
    assert pv.max() <= 5000.0
    assert pv[0] == pytest.approx(0.0)  # midnight
    load = synthetic_load_profile(base_w=400.0, peak_w=6000.0, n=96, dt_s=900.0)
    assert load.min() >= 0.0


def test_solar_prefers_self_consumption_on_a_wide_spread(grid_engine: OptimisationEngine):
    optimiser = SolarOptimiser(grid_engine)
    state = grid_engine.battery.initial_state(soc=0.4, temperature_c=22.0)
    tariff = Tariff.flat(0.30, 0.05)
    values = optimiser.destination_values(state, tariff, state.timestamp)
    assert values["load"] > values["grid"]


def test_solar_plan_accounts_for_every_watt_hour(grid_engine: OptimisationEngine):
    optimiser = SolarOptimiser(grid_engine)
    state = grid_engine.battery.initial_state(soc=0.4, temperature_c=22.0)
    n = 48
    pv = synthetic_pv_profile(peak_w=150_000.0, n=n, dt_s=1800.0)
    load = synthetic_load_profile(base_w=40_000.0, peak_w=180_000.0, n=n, dt_s=1800.0)
    plan = optimiser.plan(
        state,
        tariff=Tariff.flat(0.28, 0.06),
        solar_w=pv,
        load_w=load,
        horizon_s=n * 1800.0,
        dt_s=1800.0,
    )
    flows = plan.flows
    generated = float(np.sum(pv) * 1800.0 / 3600.0)
    assert flows.solar_total_wh == pytest.approx(generated, rel=0.02)
    assert 0.0 <= flows.self_consumption_ratio <= 1.0
    assert 0.0 <= flows.self_sufficiency_ratio <= 1.0


def test_a_battery_beats_no_battery_on_a_wide_spread(grid_engine: OptimisationEngine):
    optimiser = SolarOptimiser(grid_engine)
    state = grid_engine.battery.initial_state(soc=0.3, temperature_c=22.0)
    n = 48
    pv = synthetic_pv_profile(peak_w=200_000.0, n=n, dt_s=1800.0)
    load = synthetic_load_profile(base_w=50_000.0, peak_w=200_000.0, n=n, dt_s=1800.0)
    comparison = optimiser.compare_with_no_battery(
        state, tariff=Tariff.flat(0.30, 0.04), solar_w=pv, load_w=load,
        horizon_s=n * 1800.0, dt_s=1800.0,
    )
    assert comparison["with_battery_self_consumption"] >= comparison[
        "without_battery_self_consumption"
    ] - 1e-9


# --- grid services ---------------------------------------------------------


def test_grid_service_assessment_prices_degradation(grid_engine: OptimisationEngine):
    optimiser = GridServiceOptimiser(grid_engine)
    state = grid_engine.battery.initial_state(soc=0.6, temperature_c=22.0)
    contract = ServiceContract(
        service=ServiceType.FREQUENCY_RESPONSE,
        committed_power_w=100_000.0,
        availability_payment_per_kw_h=0.006,
        expected_utilisation=0.05,
        hours_per_year=8000.0,
        required_soc=0.55,
    )
    assessment = optimiser.assess(contract, state)
    assert assessment.annual_revenue > 0
    assert assessment.annual_degradation_cost > 0
    assert assessment.annual_opportunity_cost > 0


def test_a_service_the_battery_cannot_deliver_is_flagged(grid_engine: OptimisationEngine):
    optimiser = GridServiceOptimiser(grid_engine)
    empty = grid_engine.battery.initial_state(soc=0.02, temperature_c=22.0)
    contract = ServiceContract(
        service=ServiceType.RESERVE_CAPACITY,
        committed_power_w=10_000_000.0,
        max_duration_s=7200.0,
    )
    assessment = optimiser.assess(contract, empty)
    assert not assessment.deliverable
    assert assessment.limiting_constraint


def test_contracts_can_be_ranked(grid_engine: OptimisationEngine):
    optimiser = GridServiceOptimiser(grid_engine)
    state = grid_engine.battery.initial_state(soc=0.6, temperature_c=22.0)
    ranked = optimiser.rank(typical_contracts(150_000.0), state)
    assert len(ranked) == 3
    margins = [a.annual_margin for a in ranked if a.deliverable]
    assert margins == sorted(margins, reverse=True)
    assert "SERVICE" in GridServiceOptimiser.table(ranked)


def test_peak_shaving_finds_an_achievable_peak(grid_engine: OptimisationEngine):
    optimiser = GridServiceOptimiser(grid_engine)
    state = grid_engine.battery.initial_state(soc=0.8, temperature_c=22.0)
    load = np.concatenate(
        [np.full(20, 100_000.0), np.full(4, 350_000.0), np.full(20, 120_000.0)]
    )
    result = optimiser.peak_shaving_plan(
        state, load_w=load, dt_s=1800.0, demand_charge_per_kw=12.0
    )
    assert result["achievable_peak_w"] < result["original_peak_w"]
    assert result["demand_charge_saving"] > 0


# --- lifetime --------------------------------------------------------------


def test_the_optimised_policy_delivers_the_most_lifetime_energy(ev_battery: Battery):
    """The headline claim of section 20, asserted."""
    optimiser = LifetimeOptimiser(ev_battery)
    results = optimiser.compare(standard_policies(cycles_per_year=300.0))
    best = results[0]
    worst = results[-1]
    assert best.policy.name == "OPTIMISED"
    assert worst.policy.name == "AGGRESSIVE"
    assert best.lifetime_energy_wh > 1.5 * worst.lifetime_energy_wh
    assert best.lifetime_years > worst.lifetime_years
    assert best.cost_per_kwh_delivered < worst.cost_per_kwh_delivered


def test_state_of_health_falls_monotonically(ev_battery: Battery):
    optimiser = LifetimeOptimiser(ev_battery)
    result = optimiser.simulate(standard_policies()[1])
    trajectory = np.asarray(result.soh_trajectory)
    assert np.all(np.diff(trajectory) <= 1e-12)
    # The trajectory starts where the battery actually is, not at 100 %: these
    # fixtures are deliberately aged.
    assert trajectory[0] == pytest.approx(ev_battery.soh_capacity, abs=1e-9)


def test_annual_yield_falls_as_the_battery_ages(ev_battery: Battery):
    optimiser = LifetimeOptimiser(ev_battery)
    result = optimiser.simulate(standard_policies()[2])
    per_year = np.asarray(result.energy_per_year_wh)
    assert per_year[0] > per_year[-1]


def test_the_optimal_depth_of_discharge_is_interior(ev_battery: Battery):
    optimiser = LifetimeOptimiser(ev_battery)
    best, results = optimiser.optimal_depth_of_discharge(
        annual_energy_requirement_wh=30e6
    )
    assert 0.0 < best <= 1.0
    assert len(results) > 4


def test_the_optimal_temperature_is_not_at_an_extreme(ev_battery: Battery):
    """Too cold plates lithium on charge; too hot ages the calendar."""
    optimiser = LifetimeOptimiser(ev_battery)
    best, results = optimiser.optimal_temperature(
        standard_policies()[2], temperatures=(-5.0, 5.0, 15.0, 25.0, 35.0, 45.0)
    )
    assert best not in (-5.0, 45.0)
