"""Validation, research sweeps and the digital twin (specification sections 20, 27, 34).

Two distinct things are tested here, and it is worth keeping them apart:

* The analytical checks in :mod:`batteryopt.validation` verify the *models*
  against results that are true by derivation. This file verifies the *checks* --
  that they pass on a correct model, that they fail on a deliberately broken one,
  and that they never quietly report a model result as a measurement.
* The research layer (sweeps, studies, twin) is verified for reproducibility and
  for the scientific claims it makes about its own outputs.

A validation suite that cannot fail is decoration, so several tests here corrupt
a model on purpose and assert that the corresponding check notices.
"""

from __future__ import annotations

import math
from dataclasses import replace

import numpy as np
import pytest

from batteryopt.core.provenance import Provenance
from batteryopt.models.battery import Battery
from batteryopt.models.plant import Action, BatteryPlant
from batteryopt.research.studies import (
    charging_strategy_study,
    chemistry_comparison_study,
    mission_reliability_study,
    temperature_policy_study,
)
from batteryopt.research.sweeps import (
    monte_carlo,
    morris_screening,
    parameter_sweep,
    sensitivity,
)
from batteryopt.twin.twin import DigitalTwin
from batteryopt.validation import (
    DEFAULT_CHECKS,
    ValidationReport,
    check_charge_conservation,
    check_degradation_monotonicity,
    check_energy_balance,
    check_ocv_round_trip,
    check_power_inversion,
    check_provenance_discipline,
    check_surrogate_accuracy,
    check_thermal_steady_state,
    check_thermal_time_constant,
    compare_with_pybamm,
    validate_battery,
)


# ---------------------------------------------------------------------------
# The analytical checks pass on every supported configuration
# ---------------------------------------------------------------------------


def test_every_check_passes_for_every_chemistry(any_battery: Battery):
    """The headline claim: the models satisfy their own conservation laws."""
    report = validate_battery(any_battery)
    assert report.passed, report.summary()
    assert len(report.checks) == len(DEFAULT_CHECKS)


@pytest.mark.parametrize(
    "series,parallel",
    [(1, 1), (1, 8), (400, 1), (96, 4)],
    ids=["single-cell", "one-string-wide", "long-string", "automotive"],
)
def test_checks_pass_across_topologies(series: int, parallel: int):
    """Scale-dependent bugs hide in the extremes, so the extremes are tested.

    A single cell and a 400-cell string exercise entirely different code paths
    in the pack scaling; either can be broken while the automotive case works.
    """
    battery = Battery.build(
        chemistry="nmc",
        cells_series=series,
        cells_parallel=parallel,
        battery_id=f"{series}s{parallel}p",
    )
    report = validate_battery(battery)
    assert report.passed, report.summary()


def test_the_report_says_nothing_was_measured(ev_battery: Battery):
    """Section 34 is explicit: no output of this module is a measurement."""
    report = validate_battery(ev_battery)
    text = report.summary()
    assert "None is a measurement" in text
    assert all(c.result_kind in {"MODEL RESULT", "SIMULATION RESULT"} for c in report.checks)
    assert not any(c.result_kind == "MEASURED RESULT" for c in report.checks)


def test_the_report_serialises_for_the_record(ev_battery: Battery):
    payload = validate_battery(ev_battery).as_dict()
    assert payload["passed"] is True
    assert {c["name"] for c in payload["checks"]} == {
        c(ev_battery).name for c in DEFAULT_CHECKS
    }
    for check in payload["checks"]:
        assert set(check) >= {"name", "passed", "error", "tolerance", "result_kind"}


# ---------------------------------------------------------------------------
# The checks can fail -- verified by breaking the model on purpose
# ---------------------------------------------------------------------------


def test_charge_conservation_notices_a_broken_coulomb_count(ev_battery: Battery):
    """Introduce a 1 % error in the charge integration and confirm it is caught."""
    battery = Battery.build(chemistry="nmc", cells_series=96, cells_parallel=4)
    good = check_charge_conservation(battery)
    assert good.passed

    original = BatteryPlant.step

    def biased_step(self, state, action, dt, **kw):  # type: ignore[no-untyped-def]
        result = original(self, state, action, dt, **kw)
        # Move the state of charge by an amount the recorded current does not
        # account for: exactly the signature of a coulomb-counting error.
        return replace(result, state=replace(result.state, soc=result.state.soc - 1e-4))

    BatteryPlant.step = biased_step  # type: ignore[assignment]
    try:
        bad = check_charge_conservation(battery)
    finally:
        BatteryPlant.step = original  # type: ignore[assignment]
    assert not bad.passed, "a biased coulomb count slipped past the conservation check"
    assert bad.error > good.error


def test_thermal_steady_state_notices_a_wrong_conductance(ev_battery: Battery):
    good = check_thermal_steady_state(ev_battery)
    assert good.passed

    cls = type(ev_battery.thermal)
    original = cls.conductance
    cls.conductance = lambda self, cooling_fraction=0.0: original(self, cooling_fraction) * 1.05  # type: ignore[assignment]
    try:
        bad = check_thermal_steady_state(ev_battery)
    finally:
        cls.conductance = original  # type: ignore[assignment]
    assert not bad.passed, "a 5 % conductance error slipped past the steady-state check"


def test_time_constant_check_would_reject_forward_euler(ev_battery: Battery):
    """The exact-exponential update passes; a forward-Euler step of the same size does not.

    This is the check that justifies the exponential integrator, so it is worth
    demonstrating that it actually discriminates between the two.
    """
    exact = check_thermal_time_constant(ev_battery)
    assert exact.passed

    thermal = ev_battery.thermal
    sink, start = 20.0, 40.0
    tau = thermal.heat_capacity_j_k / thermal.conductance(0.0)
    euler = start + (-thermal.conductance(0.0) * (start - sink) / thermal.heat_capacity_j_k) * tau
    analytic = sink + (start - sink) * math.exp(-1.0)
    assert abs(euler - analytic) / abs(analytic - sink) > 0.3


def test_ocv_round_trip_notices_a_shifted_curve(ev_battery: Battery):
    good = check_ocv_round_trip(ev_battery)
    assert good.passed

    cls = type(ev_battery.chemistry.ocv)
    original = cls.soc_at
    cls.soc_at = lambda self, voltage: min(1.0, original(self, voltage) + 0.05)  # type: ignore[assignment]
    try:
        bad = check_ocv_round_trip(ev_battery)
    finally:
        cls.soc_at = original  # type: ignore[assignment]
    assert not bad.passed


def test_provenance_check_notices_a_mislabelled_state(ev_battery: Battery):
    """The provenance system is worthless if one path forgets to re-tag."""
    assert check_provenance_discipline(ev_battery).passed

    plant = BatteryPlant(ev_battery)
    state = ev_battery.initial_state(soc=0.5, temperature_c=25.0).as_simulated()
    trajectory = plant.simulate(state, [Action(power_w=1000.0)] * 3, 60.0)
    assert all(s.default_provenance is Provenance.SIMULATED for s in trajectory.states[1:])
    # And a state that lies about itself is detectable by the same rule.
    liar = replace(trajectory.states[-1], default_provenance=Provenance.MEASURED)
    assert liar.default_provenance is not Provenance.SIMULATED


def test_power_inversion_is_exact_not_merely_close(any_battery: Battery):
    check = check_power_inversion(any_battery, points=41)
    assert check.passed
    # The inversion is closed-form, so "passing" should mean machine precision,
    # not a generous tolerance being met.
    assert check.error < 1e-12


def test_degradation_monotonicity_reports_what_broke(ev_battery: Battery):
    good = check_degradation_monotonicity(ev_battery)
    assert good.passed
    assert "correctly signed" in good.detail

    cls = type(ev_battery.degradation)
    original = cls.calendar_stress
    # Make calendar stress blind to temperature: the check must notice.
    cls.calendar_stress = lambda self, soc, temperature_c: original(  # type: ignore[assignment]
        self, soc=soc, temperature_c=25.0
    )
    try:
        bad = check_degradation_monotonicity(ev_battery)
    finally:
        cls.calendar_stress = original  # type: ignore[assignment]
    assert not bad.passed
    assert "temperature" in bad.detail


def test_surrogate_accuracy_is_quoted_not_assumed(ev_battery: Battery):
    """The surrogate's error is part of the engine's error budget, so it is reported."""
    check = check_surrogate_accuracy(ev_battery)
    assert check.passed
    assert check.error > 0.0, "a surrogate with exactly zero error is not being measured"
    assert "rms" in check.detail


def test_a_check_that_raises_is_a_failure_not_a_crash(ev_battery: Battery):
    def exploding(battery: Battery):
        raise RuntimeError("deliberate")

    exploding.__name__ = "exploding_check"
    report = validate_battery(ev_battery, checks=[exploding])
    assert not report.passed
    assert "RuntimeError: deliberate" in report.checks[0].detail


def test_energy_balance_holds_for_charge_as_well_as_discharge(ev_battery: Battery):
    """Losses are dissipative in both directions; a sign error shows up on charge."""
    for c_rate in (0.2, -0.2):
        battery = ev_battery
        plant = BatteryPlant(battery)
        state = battery.initial_state(soc=0.55, temperature_c=25.0)
        power = c_rate * battery.capacity * battery.nominal_voltage
        trajectory = plant.simulate(state, [Action(power_w=power)] * 20, 60.0)
        assert trajectory.losses_wh() > 0.0, "losses must be positive in both directions"


def test_an_empty_report_is_not_a_pass():
    """Vacuous truth is the classic way a validation suite lies."""
    report = ValidationReport(battery_id="empty")
    assert report.passed is True  # all([]) is True by definition ...
    assert len(report.checks) == 0  # ... so the count is what a caller must check
    assert "0/0 passed" in report.summary()


# ---------------------------------------------------------------------------
# Cross-model comparison degrades honestly
# ---------------------------------------------------------------------------


def test_cross_model_reports_not_performed_without_pybamm(ev_battery: Battery):
    """Missing PyBaMM must read as NOT PERFORMED, never as a pass."""
    report = compare_with_pybamm(ev_battery)
    if not report.performed:
        assert report.passed is False
        assert "NOT PERFORMED" in report.summary()
        assert "pip install" in report.reason
    else:
        assert report.reference_model
        assert "not evidence of physical accuracy" in report.summary()


# ---------------------------------------------------------------------------
# Research sweeps: reproducible by construction
# ---------------------------------------------------------------------------


def test_a_parameter_sweep_covers_the_full_factorial():
    calls: list[dict] = []

    def run(params):
        calls.append(dict(params))
        return {"y": params["a"] * params["b"]}

    result = parameter_sweep(run, {"a": [1, 2, 3], "b": [10, 20]}, fixed={"c": 7})
    assert len(result) == 6
    assert len(result.successes) == 6
    assert all(c["c"] == 7 for c in calls)
    assert sorted(result.column("y").tolist()) == [10.0, 20.0, 20.0, 30.0, 40.0, 60.0]
    # The design order is deterministic, so experiment k is the same point on
    # every run -- which is what makes a sweep re-runnable a year later.
    assert [c["a"] for c in calls] == [1, 1, 2, 2, 3, 3]


def test_a_sweep_is_reproducible_from_its_seed():
    def run(params):
        return {"y": params["x"] ** 2}

    first = monte_carlo(run, {"x": lambda rng: float(rng.normal())}, n=40, seed=11)
    second = monte_carlo(run, {"x": lambda rng: float(rng.normal())}, n=40, seed=11)
    other = monte_carlo(run, {"x": lambda rng: float(rng.normal())}, n=40, seed=12)

    assert np.array_equal(first.column("y"), second.column("y"))
    assert first.digest == second.digest
    assert not np.array_equal(first.column("y"), other.column("y"))
    assert first.digest != other.digest


def test_a_failing_experiment_is_data_not_a_crash():
    def run(params):
        if params["x"] > 2:
            raise ValueError("no")
        return {"y": params["x"]}

    result = parameter_sweep(run, {"x": [1, 2, 3, 4]})
    assert len(result) == 4
    assert len(result.successes) == 2
    assert len(result.failures) == 2
    assert all("ValueError: no" in e.error for e in result.failures)
    # The summary is computed over the successes and does not go NaN.
    assert np.isfinite(result.summary()["y"]["mean"])


def test_sweep_digest_covers_the_design_not_the_results():
    """Two runs of the same design must agree even if the model changed underneath."""
    a = parameter_sweep(lambda p: {"y": p["x"]}, {"x": [1, 2]}, name="d")
    b = parameter_sweep(lambda p: {"y": p["x"] * 1000}, {"x": [1, 2]}, name="d")
    assert a.digest == b.digest
    assert not np.array_equal(a.column("y"), b.column("y"))


def test_sensitivity_reports_elasticity_and_ranks_it():
    def run(params):
        # y = x^2 * z: elasticity 2 in x, 1 in z, 0 in w.
        return {"y": params["x"] ** 2 * params["z"] + 0.0 * params["w"]}

    out = sensitivity(run, {"x": 3.0, "z": 5.0, "w": 2.0}, output_key="y")
    assert out["elasticities"]["x"]["elasticity"] == pytest.approx(2.0, abs=0.02)
    assert out["elasticities"]["z"]["elasticity"] == pytest.approx(1.0, abs=0.02)
    assert out["elasticities"]["w"]["elasticity"] == pytest.approx(0.0, abs=1e-9)
    assert out["ranked"][0] == "x"
    assert out["ranked"][-1] == "w"
    assert "cannot detect interactions" in out["caveat"]


def test_morris_screening_separates_interaction_from_importance():
    """A parameter in an interaction term must show a large sigma; a linear one must not."""

    def run(params):
        return {"y": 3.0 * params["linear"] + 5.0 * params["a"] * params["b"]}

    out = morris_screening(
        run,
        {"linear": (0.0, 1.0), "a": (0.0, 1.0), "b": (0.0, 1.0)},
        output_key="y",
        trajectories=12,
        seed=4,
    )
    effects = out["effects"]
    assert effects["linear"]["sigma"] == pytest.approx(0.0, abs=1e-9)
    assert effects["a"]["sigma"] > 0.5
    assert effects["b"]["sigma"] > 0.5
    assert out["ranked"][0] in {"a", "b", "linear"}


def test_morris_is_reproducible_from_its_seed():
    def run(params):
        return {"y": params["a"] * 2.0 + params["b"]}

    kw = dict(output_key="y", trajectories=6, seed=9)
    first = morris_screening(run, {"a": (0.0, 1.0), "b": (0.0, 1.0)}, **kw)
    second = morris_screening(run, {"a": (0.0, 1.0), "b": (0.0, 1.0)}, **kw)
    assert first["effects"] == second["effects"]


# ---------------------------------------------------------------------------
# The standard studies produce the physically expected shapes
# ---------------------------------------------------------------------------


def test_charging_study_shows_cold_fast_charging_is_worst(ev_battery: Battery, tou_tariff):
    result = charging_strategy_study(
        ev_battery,
        temperatures_c=(0.0, 25.0),
        rate_fractions=(1.0, 0.4),
        tariff=tou_tariff,
    )
    assert len(result.successes) == 4
    by_case = {
        (e.parameters["temperature_c"], e.parameters["rate_fraction"]): e.outputs
        for e in result.successes
    }
    cold_fast = by_case[(0.0, 1.0)]["degradation_pct"]
    warm_fast = by_case[(25.0, 1.0)]["degradation_pct"]
    cold_slow = by_case[(0.0, 0.4)]["degradation_pct"]
    assert cold_fast > warm_fast, "cold fast charging should cost more life than warm"
    assert cold_fast > cold_slow, "slowing down in the cold should cost less life"
    # And slowing down takes longer -- the trade-off is real, not free.
    assert by_case[(0.0, 0.4)]["duration_min"] >= by_case[(0.0, 1.0)]["duration_min"]


def test_temperature_policy_study_is_u_shaped(ev_battery: Battery):
    """Both sides of the temperature trade-off must be present.

    The sweep has to reach below freezing to see the cold side at all: for NMC
    the plating penalty only overtakes the falling calendar rate a little below
    zero, so a sweep starting at 5 degC finds its optimum at the left-hand edge
    and proves nothing. Above about 15 degC the calendar term dominates and
    lifetime energy falls monotonically, which is checked separately.
    """
    temperatures = (-10.0, 0.0, 5.0, 15.0, 25.0, 35.0, 45.0)
    result = temperature_policy_study(ev_battery, temperatures_c=temperatures)
    energies = result.column("lifetime_energy_mwh")
    assert np.all(np.isfinite(energies))
    assert energies.size == len(temperatures)

    best = int(np.argmax(energies))
    assert 0 < best < len(energies) - 1, (
        f"the optimum landed at an extreme ({energies.tolist()}), which means one "
        "side of the trade-off is missing"
    )
    assert -5.0 <= temperatures[best] <= 25.0

    # Above the optimum, hotter is strictly worse -- no local rebound.
    hot = energies[best:]
    assert np.all(np.diff(hot) < 0.0), hot.tolist()


def test_mission_reliability_study_reports_a_failure_rate(ev_battery: Battery):
    result = mission_reliability_study(ev_battery, n=200, seed=1)
    failures = result.column("failed")
    assert failures.size == 200
    assert set(np.unique(failures)) <= {0.0, 1.0}
    margins = result.column("margin_wh")
    # The failures must be exactly the negative-margin cases: the reliability
    # number has to be derived from the physics, not counted separately.
    assert np.array_equal(failures > 0.5, margins < 0.0)


def test_chemistry_comparison_sizes_like_for_like():
    result = chemistry_comparison_study(
        chemistries=("nmc", "lfp"), target_energy_kwh=100.0, target_voltage=400.0
    )
    installed = result.column("installed_kwh")
    assert np.all(installed > 80.0) and np.all(installed < 130.0), installed.tolist()
    lifetimes = {
        e.parameters["chemistry"]: e.outputs["lifetime_energy_mwh"] for e in result.successes
    }
    assert lifetimes["lfp"] > lifetimes["nmc"], (
        "under a heavy 300-cycle-per-year duty LFP should out-deliver NMC"
    )


# ---------------------------------------------------------------------------
# Digital twin
# ---------------------------------------------------------------------------


def test_the_twin_never_claims_to_be_measured(ev_battery: Battery):
    """The twin's state is an estimate, and it says so wherever it is printed."""
    twin = DigitalTwin(ev_battery)
    twin.assert_not_measured()
    assert twin.state.provenance_of("soc") is not Provenance.MEASURED
    described = twin.describe()
    assert "provenance=" in described
    assert "MEASURED" not in described
    payload = twin.snapshot().as_dict()
    assert payload["state"]
    assert payload["life"]


def test_the_twin_prediction_is_tagged_simulated(ev_battery: Battery):
    """A prediction is what *would* happen; nothing in it may be tagged measured."""
    twin = DigitalTwin(ev_battery)
    trajectory = twin.predict([Action(power_w=5_000.0)] * 10, 60.0)
    assert len(trajectory.states) == 11
    assert all(s.default_provenance is Provenance.SIMULATED for s in trajectory.states)
    # Predicting must not disturb the twin's own state.
    before = twin.state.soc
    twin.predict([Action(power_w=20_000.0)] * 5, 60.0)
    assert twin.state.soc == before


def test_the_twin_projects_a_life_with_a_band(ev_battery: Battery):
    life = DigitalTwin(ev_battery).project_life(horizon_years=25.0)
    assert 0.0 <= life.remaining_years <= 25.0
    assert life.quantiles_years.p10 <= life.quantiles_years.p50 <= life.quantiles_years.p90
    assert 0.0 <= life.confidence <= 1.0
    assert life.limiting_mechanism in {
        "calendar ageing",
        "cycle ageing",
        "already at end of life",
    }, life.limiting_mechanism
    # A resting twin ages by the calendar, not by cycling.
    assert life.limiting_mechanism == "calendar ageing"


def test_refreshing_the_twin_ages_the_battery_with_it(ev_battery: Battery):
    """The plant, surrogate and constraints must age together, not drift apart."""
    battery = Battery.build(chemistry="nmc", cells_series=96, cells_parallel=4)
    twin = DigitalTwin(battery)
    before = twin.battery.degradation_state.capacity_fade
    twin.refresh_battery()  # no capacity estimate yet: must be a no-op, not a crash
    assert twin.battery.degradation_state.capacity_fade == before
