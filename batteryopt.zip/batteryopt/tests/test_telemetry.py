"""Telemetry: validation, sources and the pipeline."""

from __future__ import annotations

import asyncio

import numpy as np
import pytest

from batteryopt.models.battery import Battery
from batteryopt.optimisation.engine import OptimisationEngine
from batteryopt.telemetry.pipeline import TelemetryPipeline
from batteryopt.telemetry.schema import TelemetryFrame
from batteryopt.telemetry.sources.network import QueueSource, RESTSource
from batteryopt.telemetry.sources.replay import CSVReplaySource, write_csv
from batteryopt.telemetry.sources.simulated import SimulatedSource, drive_cycle, storage_cycle
from batteryopt.telemetry.validation import TelemetryValidator
from batteryopt.twin.twin import DigitalTwin


def _frame(**kwargs) -> TelemetryFrame:
    base = dict(
        battery_id="test", timestamp=0.0, voltage_v=350.0, current_a=50.0, temperature_c=25.0
    )
    base.update(kwargs)
    return TelemetryFrame(**base)


# --- validation ------------------------------------------------------------


def test_a_good_frame_passes_untouched(ev_battery: Battery):
    validator = TelemetryValidator(ev_battery)
    result = validator.validate(_frame())
    assert result.accepted and not result.repaired


def test_an_impossible_voltage_is_rejected(ev_battery: Battery):
    validator = TelemetryValidator(ev_battery)
    result = validator.validate(_frame(voltage_v=4000.0))
    assert not result.accepted
    assert "plausible range" in result.reasons()[0]


def test_an_impossible_current_is_rejected(ev_battery: Battery):
    validator = TelemetryValidator(ev_battery)
    assert not validator.validate(_frame(current_a=1e6)).accepted


def test_a_nonsense_temperature_is_rejected(ev_battery: Battery):
    validator = TelemetryValidator(ev_battery)
    assert not validator.validate(_frame(temperature_c=500.0)).accepted


def test_a_dropped_field_is_held_briefly(ev_battery: Battery):
    validator = TelemetryValidator(ev_battery)
    validator.validate(_frame(timestamp=0.0))
    result = validator.validate(_frame(timestamp=1.0, voltage_v=None))
    assert result.accepted and result.repaired
    assert result.frame.voltage_v == pytest.approx(350.0)


def test_a_stale_hold_is_not_used(ev_battery: Battery):
    """Holding a value forever turns a dead sensor into an invisible one."""
    validator = TelemetryValidator(ev_battery, hold_seconds=2.0)
    validator.validate(_frame(timestamp=0.0))
    result = validator.validate(_frame(timestamp=100.0, voltage_v=None))
    assert not result.accepted


def test_time_going_backwards_is_rejected(ev_battery: Battery):
    validator = TelemetryValidator(ev_battery)
    validator.validate(_frame(timestamp=100.0))
    assert not validator.validate(_frame(timestamp=50.0)).accepted


def test_a_long_gap_is_warned_about_not_rejected(ev_battery: Battery):
    validator = TelemetryValidator(ev_battery)
    validator.validate(_frame(timestamp=0.0))
    result = validator.validate(_frame(timestamp=100_000.0))
    assert result.accepted
    assert any(issue.severity == "warn" for issue in result.issues)


def test_sequence_gaps_are_counted(ev_battery: Battery):
    validator = TelemetryValidator(ev_battery)
    validator.validate(_frame(timestamp=0.0, sequence=1))
    validator.validate(_frame(timestamp=1.0, sequence=5))
    assert validator.stats.sequence_gaps == 1


def test_a_partly_bad_cell_array_is_dropped_whole(ev_battery: Battery):
    """A half-trusted cell array corrupts the imbalance decomposition."""
    validator = TelemetryValidator(ev_battery)
    result = validator.validate(_frame(cell_voltages_v=[3.7, 3.7, 99.0, 3.7]))
    assert result.accepted and result.repaired
    assert result.frame.cell_voltages_v == []


def test_a_nonsense_reported_soc_is_dropped(ev_battery: Battery):
    validator = TelemetryValidator(ev_battery)
    result = validator.validate(_frame(reported_soc=1.7))
    assert result.accepted
    assert result.frame.reported_soc is None


def test_validation_stats_add_up(ev_battery: Battery):
    validator = TelemetryValidator(ev_battery)
    for k in range(10):
        validator.validate(_frame(timestamp=float(k)))
    validator.validate(_frame(timestamp=11.0, voltage_v=9999.0))
    stats = validator.stats
    assert stats.seen == 11
    assert stats.accepted == 10
    assert stats.rejected == 1
    assert stats.acceptance_rate == pytest.approx(10 / 11)


# --- simulated source ------------------------------------------------------


def test_the_simulated_source_produces_usable_frames(ev_battery: Battery):
    source = SimulatedSource(
        ev_battery, initial_soc=0.7, dt_s=1.0, duty_cycle=drive_cycle(peak_w=50_000.0),
        n_cell_sensors=8, seed=1,
    )
    frames = source.frames(100)
    assert len(frames) == 100
    assert all(f.complete for f in frames)
    assert len(frames[0].cell_voltages_v) == 8


def test_the_simulated_source_has_a_current_sensor_offset(ev_battery: Battery):
    """Without an offset, coulomb counting looks far better than it is."""
    source = SimulatedSource(ev_battery, current_offset_a=1.5, dt_s=1.0)
    assert source.current_offset_a == pytest.approx(1.5)
    frame = source.frames(1)[0]
    assert frame.current_a == pytest.approx(1.5, abs=3.0)


def test_dropouts_appear_as_sequence_gaps(ev_battery: Battery):
    source = SimulatedSource(ev_battery, dt_s=1.0, dropout_rate=0.3, seed=2)
    frames = source.frames(50)
    sequences = [f.sequence for f in frames]
    assert max(sequences) > len(frames)


def test_both_duty_cycles_move_the_battery(ev_battery: Battery):
    for profile in (drive_cycle(peak_w=40_000.0), storage_cycle(charge_w=30_000.0,
                                                                discharge_w=30_000.0)):
        source = SimulatedSource(ev_battery, initial_soc=0.6, dt_s=10.0, duty_cycle=profile)
        source.frames(200)
        assert source.state.soc != pytest.approx(0.6)


def test_the_async_interface_yields_frames(ev_battery: Battery):
    source = SimulatedSource(ev_battery, dt_s=1.0, max_frames=20)

    async def collect():
        return [frame async for frame in source]

    assert len(asyncio.run(collect())) == 20


# --- replay ----------------------------------------------------------------


def test_csv_round_trip_preserves_the_data(ev_battery: Battery, tmp_path):
    source = SimulatedSource(ev_battery, dt_s=1.0, n_cell_sensors=4, seed=3)
    frames = source.frames(50)
    path = tmp_path / "telemetry.csv"
    assert write_csv(path, frames) == 50
    replayed = list(CSVReplaySource(path, battery_id="test").rows())
    assert len(replayed) == 50
    assert replayed[0].voltage_v == pytest.approx(frames[0].voltage_v, rel=1e-9)
    assert len(replayed[0].cell_voltages_v) == 4


def test_replay_rejects_a_file_with_no_timestamp(tmp_path):
    from batteryopt.core.exceptions import TelemetryError

    path = tmp_path / "bad.csv"
    path.write_text("voltage,current\n350,10\n")
    with pytest.raises(TelemetryError, match="timestamp"):
        list(CSVReplaySource(path).rows())


def test_replay_maps_alternative_column_names(tmp_path):
    path = tmp_path / "alt.csv"
    path.write_text("time,pack_voltage,pack_current,cell_temp\n0,350,10,25\n1,349,11,25\n")
    frames = list(CSVReplaySource(path, battery_id="x").rows())
    assert len(frames) == 2
    assert frames[0].voltage_v == pytest.approx(350.0)
    assert frames[1].current_a == pytest.approx(11.0)


# --- queue sources ---------------------------------------------------------


def test_the_queue_drops_the_oldest_frame_when_full():
    """Backlog is worse than loss: optimising against stale state is useless."""

    async def scenario():
        source = QueueSource(maxsize=4)
        for k in range(10):
            source.submit_nowait(_frame(timestamp=float(k)))
        return source

    source = asyncio.run(scenario())
    assert source.dropped == 6
    assert source.backlog == 4


def test_the_rest_source_validates_its_payload():
    from batteryopt.core.exceptions import TelemetryError

    async def scenario():
        source = RESTSource()
        source.ingest({"battery_id": "x", "timestamp": 1.0, "voltage_v": 350.0})
        with pytest.raises(TelemetryError):
            source.ingest({"nonsense": True})
        return source

    source = asyncio.run(scenario())
    assert source.emitted == 1


# --- pipeline --------------------------------------------------------------


def test_the_pipeline_estimates_and_recommends(ev_battery: Battery, tou_tariff):
    source = SimulatedSource(
        ev_battery, initial_soc=0.75, dt_s=1.0, duty_cycle=drive_cycle(peak_w=45_000.0),
        n_cell_sensors=8, dropout_rate=0.01, seed=5,
    )
    twin = DigitalTwin(ev_battery, initial_soc=0.6, initial_temperature_c=25.0)
    engine = OptimisationEngine(ev_battery, objective="ev", tariff=tou_tariff)
    pipeline = TelemetryPipeline(
        twin, engine, optimise_interval_s=60.0, horizon_s=600.0, dt_s=60.0,
        demand=lambda _state: 30_000.0,
    )
    pipeline.run_sync(source.frames(400))
    assert pipeline.stats.frames_accepted > 350
    assert pipeline.stats.optimisations >= 5
    assert pipeline.latest_recommendation is not None
    assert abs(twin.state.soc - source.state.soc) < 0.05


def test_the_pipeline_keeps_ingesting_when_optimisation_fails(
    ev_battery: Battery, monkeypatch
):
    from batteryopt.core.exceptions import InfeasibleProblem

    source = SimulatedSource(ev_battery, dt_s=1.0, seed=6)
    twin = DigitalTwin(ev_battery, initial_soc=0.5)
    engine = OptimisationEngine(ev_battery, objective="balanced")
    monkeypatch.setattr(
        engine,
        "optimise_state",
        lambda *a, **k: (_ for _ in ()).throw(InfeasibleProblem("synthetic")),
    )
    pipeline = TelemetryPipeline(twin, engine, optimise_interval_s=10.0)
    pipeline.run_sync(source.frames(100))
    assert pipeline.stats.frames_accepted == 100
    assert pipeline.stats.optimisation_failures > 0
    assert pipeline.latest_recommendation is None


def test_the_pipeline_reports_its_health(ev_battery: Battery):
    source = SimulatedSource(ev_battery, dt_s=1.0, seed=7)
    twin = DigitalTwin(ev_battery, initial_soc=0.5)
    engine = OptimisationEngine(ev_battery, objective="balanced")
    pipeline = TelemetryPipeline(twin, engine, optimise_interval_s=30.0, horizon_s=300.0)
    pipeline.run_sync(source.frames(120))
    health = pipeline.health()
    assert health["telemetry_flowing"]
    assert health["acceptance_rate"] > 0.9
    assert health["safety_rejections"] == 0


def test_the_pipeline_persists_to_a_repository(ev_battery: Battery):
    from batteryopt.persistence.repository import InMemoryRepository

    repository = InMemoryRepository()
    source = SimulatedSource(ev_battery, dt_s=1.0, seed=8)
    twin = DigitalTwin(ev_battery, initial_soc=0.5)
    engine = OptimisationEngine(ev_battery, objective="balanced")
    pipeline = TelemetryPipeline(
        twin, engine, optimise_interval_s=20.0, repository=repository, horizon_s=300.0
    )
    pipeline.run_sync(source.frames(80))
    assert repository.stats()["telemetry"] == 80
    assert repository.stats()["states"] == 80
    assert repository.stats()["runs"] > 0


def test_running_a_source_asynchronously(ev_battery: Battery):
    source = SimulatedSource(ev_battery, dt_s=1.0, max_frames=60)
    twin = DigitalTwin(ev_battery, initial_soc=0.5)
    engine = OptimisationEngine(ev_battery, objective="balanced")
    pipeline = TelemetryPipeline(twin, engine, optimise_interval_s=30.0, horizon_s=300.0)
    stats = asyncio.run(pipeline.run(source, max_frames=40))
    assert stats.frames_accepted == 40
