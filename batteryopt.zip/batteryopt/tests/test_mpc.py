"""Model predictive control: closed loop, fallbacks and timing."""

from __future__ import annotations

import numpy as np
import pytest

from batteryopt.economics.prices import Tariff
from batteryopt.models.battery import Battery
from batteryopt.optimisation.engine import OptimisationEngine
from batteryopt.optimisation.mpc import ModelPredictiveController, geometric_steps


def test_geometric_steps_cover_the_horizon():
    steps = geometric_steps(horizon_s=86_400.0, first_dt_s=60.0)
    assert sum(steps) == pytest.approx(86_400.0)
    assert steps[0] == pytest.approx(60.0)
    assert steps[-1] > steps[0]
    assert len(steps) < 40  # the point is to avoid 1440 intervals


def test_mpc_runs_a_closed_loop(ev_battery: Battery, tou_tariff: Tariff):
    engine = OptimisationEngine(ev_battery, objective="ev", tariff=tou_tariff)
    controller = ModelPredictiveController(
        engine, horizon_s=1800.0, control_dt_s=300.0, planning_steps=6
    )
    state = ev_battery.initial_state(soc=0.6, temperature_c=25.0, ambient_c=22.0)
    history = controller.run(state, cycles=8, demand=25_000.0)
    assert len(history) == 8
    assert history.summary()["fallbacks"] == 0
    assert np.all(np.isfinite(history.applied_power_w))


def test_mpc_arbitrages_a_priced_day(grid_battery: Battery, day_ahead_tariff: Tariff):
    """The behaviour the whole scheduling stack exists to produce."""
    engine = OptimisationEngine(
        grid_battery, objective="grid_storage", tariff=day_ahead_tariff
    )
    controller = ModelPredictiveController(
        engine, horizon_s=12 * 3600.0, control_dt_s=1800.0, planning_steps=24
    )
    state = grid_battery.initial_state(soc=0.5, temperature_c=22.0, ambient_c=18.0)
    history = controller.run(state, cycles=24)
    applied = history.applied_power_w
    times = state.timestamp + np.arange(applied.size) * 1800.0
    prices = np.asarray(day_ahead_tariff.import_at(times))
    charging = applied < -1000.0
    discharging = applied > 1000.0
    assert charging.any() or discharging.any(), "the controller did nothing all day"
    if charging.any() and discharging.any():
        assert prices[charging].mean() < prices[discharging].mean()


def test_mpc_falls_back_to_rest_rather_than_failing(ev_battery: Battery, monkeypatch):
    from batteryopt.core.exceptions import InfeasibleProblem

    engine = OptimisationEngine(ev_battery, objective="balanced")

    def always_fails(_problem):
        raise InfeasibleProblem("synthetic failure")

    monkeypatch.setattr(engine, "optimise", always_fails)
    controller = ModelPredictiveController(engine, horizon_s=600.0, control_dt_s=60.0)
    step = controller.step(ev_battery.initial_state(soc=0.5, temperature_c=25.0))
    assert step.fell_back
    assert step.applied_power_w == pytest.approx(0.0)
    assert "rest" in step.note


def test_mpc_shortens_its_own_commitment_window(ev_battery: Battery):
    """Only a controller that genuinely re-plans may relax the guard."""
    engine = OptimisationEngine(ev_battery, objective="balanced")
    ModelPredictiveController(engine, horizon_s=3600.0, control_dt_s=120.0)
    assert engine.commitment_window_s == pytest.approx(120.0)


def test_mpc_records_solve_timing(ev_battery: Battery):
    engine = OptimisationEngine(ev_battery, objective="balanced")
    controller = ModelPredictiveController(
        engine, horizon_s=600.0, control_dt_s=120.0, planning_steps=5
    )
    controller.run(
        ev_battery.initial_state(soc=0.6, temperature_c=25.0), cycles=4, demand=20_000.0
    )
    summary = controller.history.summary()
    assert summary["mean_solve_ms"] > 0
    assert summary["max_solve_ms"] >= summary["mean_solve_ms"]


def test_mpc_keeps_the_pack_inside_its_limits(ev_battery: Battery):
    from batteryopt.optimisation.constraints import ConstraintSet

    engine = OptimisationEngine(ev_battery, objective="power")
    controller = ModelPredictiveController(
        engine, horizon_s=900.0, control_dt_s=60.0, planning_steps=8
    )
    state = ev_battery.initial_state(soc=0.85, temperature_c=35.0, ambient_c=35.0)
    controller.run(state, cycles=20, demand=250_000.0)
    constraints = ConstraintSet(ev_battery)
    states = [step.state for step in controller.history.steps]
    assert not constraints.hard_violations(states)
