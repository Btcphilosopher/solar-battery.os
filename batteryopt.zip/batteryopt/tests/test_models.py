"""Electrical, thermal and plant models."""

from __future__ import annotations

import math

import numpy as np
import pytest

from batteryopt.core.exceptions import NumericalInstability
from batteryopt.models.battery import Battery
from batteryopt.models.electrical import EquivalentCircuitModel
from batteryopt.models.fidelity import Fidelity, build_plant, effective_backend, profile_for
from batteryopt.models.plant import Action, BatteryPlant
from batteryopt.models.surrogate import build_surrogate, degradation_rate_array
from batteryopt.models.thermal import LumpedThermalModel
from batteryopt.models.topology import Topology


# --- topology --------------------------------------------------------------


def test_topology_scaling_is_consistent():
    topology = Topology.build(chemistry="nmc", cells_series=96, cells_parallel=4)
    assert topology.n_series == 96
    assert topology.n_parallel == 4
    assert topology.cell_count == 384
    # Series multiplies voltage, parallel multiplies capacity.
    assert topology.voltage_from_cell(3.7) == pytest.approx(96 * 3.7)
    assert topology.capacity_ah == pytest.approx(60.0 * 4 * 0.97)
    # Resistance goes as series over parallel.
    assert topology.resistance_from_cell(0.001) == pytest.approx(0.001 * 96 / 4)


def test_nested_topology_multiplies_through():
    flat = Topology.build(chemistry="nmc", cells_series=12, cells_parallel=2,
                          modules_series=8, modules_parallel=2)
    assert flat.n_series == 96
    assert flat.n_parallel == 4


def test_sized_topology_meets_its_target():
    topology = Topology.sized_for(
        chemistry="lfp", target_energy_kwh=200.0, target_voltage=800.0
    )
    assert topology.nominal_energy_wh >= 200_000.0
    assert topology.nominal_voltage == pytest.approx(800.0, rel=0.02)


# --- electrical ------------------------------------------------------------


def test_power_inversion_round_trips(any_battery: Battery):
    ecm = any_battery.electrical
    v_nom = any_battery.nominal_voltage
    for power in np.linspace(-0.8 * any_battery.maximum_charge_current * v_nom,
                             0.8 * any_battery.maximum_current * v_nom, 15):
        current = ecm.current_for_power(float(power), soc=0.5, temperature_c=25.0)
        recovered = ecm.power_for_current(current, soc=0.5, temperature_c=25.0)
        assert recovered == pytest.approx(float(power), rel=1e-9, abs=1e-6)


def test_discharge_lowers_and_charge_raises_terminal_voltage(ev_battery: Battery):
    ecm = ev_battery.electrical
    ocv = float(ecm.ocv(0.5))
    assert ecm.evaluate(soc=0.5, current_a=100.0, temperature_c=25.0).voltage_v < ocv
    assert ecm.evaluate(soc=0.5, current_a=-100.0, temperature_c=25.0).voltage_v > ocv


def test_losses_are_quadratic_in_current(ev_battery: Battery):
    ecm = ev_battery.electrical
    one = ecm.evaluate(soc=0.5, current_a=50.0, temperature_c=25.0).loss_w
    two = ecm.evaluate(soc=0.5, current_a=100.0, temperature_c=25.0).loss_w
    assert two == pytest.approx(4.0 * one, rel=1e-9)


def test_rc_branches_relax_towards_steady_state(ev_battery: Battery):
    ecm = ev_battery.electrical
    if ecm.n_rc == 0:
        pytest.skip("chemistry has no diffusion branches")
    steady = [r * 100.0 for r in ecm.rc_resistances()]
    voltages = (0.0,) * ecm.n_rc
    for _ in range(200):
        voltages = ecm.step_rc(voltages, 100.0, 60.0)
    for actual, expected in zip(voltages, steady):
        assert actual == pytest.approx(expected, rel=1e-3)


def test_hysteresis_persists_through_rest(ev_battery: Battery):
    """Hysteresis is a state, not a function of the instantaneous current."""
    ecm = ev_battery.electrical
    if ecm.hysteresis_magnitude_v <= 0:
        pytest.skip("chemistry declares no hysteresis")
    discharged = ecm.step_hysteresis(0.0, 200.0, 3600.0, capacity_ah=ev_battery.capacity)
    assert discharged < -0.5
    # At zero current the state must not snap back to zero.
    rested = ecm.step_hysteresis(discharged, 0.0, 3600.0, capacity_ah=ev_battery.capacity)
    assert rested == pytest.approx(discharged)


def test_ocv_reflects_the_hysteresis_state(ev_battery: Battery):
    ecm = ev_battery.electrical
    if ecm.hysteresis_magnitude_v <= 0:
        pytest.skip("chemistry declares no hysteresis")
    assert ecm.ocv(0.5, hysteresis=1.0) > ecm.ocv(0.5, hysteresis=0.0) > ecm.ocv(0.5, hysteresis=-1.0)


def test_voltage_limit_current_is_exact(ev_battery: Battery):
    ecm = ev_battery.electrical
    limit = ev_battery.minimum_voltage
    current = ecm.current_at_voltage_limit(
        limit, soc=0.4, temperature_c=25.0, charging=False
    )
    response = ecm.evaluate(soc=0.4, current_a=current, temperature_c=25.0)
    assert response.voltage_v == pytest.approx(limit, abs=1e-6)


# --- thermal ---------------------------------------------------------------


def test_thermal_equilibrium_matches_the_closed_form(ev_battery: Battery):
    thermal = ev_battery.thermal
    expected = 20.0 + 3000.0 / thermal.conductance(0.5)
    assert thermal.equilibrium_temperature(
        heat_generation_w=3000.0, sink_c=20.0, cooling_fraction=0.5
    ) == pytest.approx(expected)


def test_cooling_is_monotone_and_costs_more_than_linearly(ev_battery: Battery):
    thermal = ev_battery.thermal
    conductances = [thermal.conductance(f) for f in (0.0, 0.25, 0.5, 0.75, 1.0)]
    assert conductances == sorted(conductances)
    # Affinity law: doubling the effort costs more than double the power.
    assert thermal.parasitic_power(1.0) > 4.0 * thermal.parasitic_power(0.5)


def test_exponential_integration_is_stable_at_any_step(ev_battery: Battery):
    """Forward Euler would oscillate or diverge here; the exact update cannot."""
    thermal = ev_battery.thermal
    for dt in (1.0, 60.0, 600.0, 6000.0, 86_400.0):
        result = thermal.step(
            temperature_c=60.0, heat_generation_w=0.0, dt=dt, ambient_c=20.0,
            coolant_c=20.0, cooling_fraction=1.0,
        )
        assert 19.9 <= result.temperature_c <= 60.0


def test_time_to_limit_is_infinite_when_equilibrium_is_below_it(ev_battery: Battery):
    thermal = ev_battery.thermal
    assert math.isinf(
        thermal.time_to_limit_s(
            temperature_c=25.0, limit_c=55.0, heat_generation_w=100.0,
            sink_c=20.0, cooling_fraction=1.0,
        )
    )


def test_cooling_for_target_saturates_sensibly(ev_battery: Battery):
    thermal = ev_battery.thermal
    assert thermal.cooling_for_target(target_c=30.0, heat_generation_w=0.0, sink_c=20.0) == 0.0
    assert thermal.cooling_for_target(
        target_c=21.0, heat_generation_w=1e7, sink_c=20.0
    ) == 1.0


# --- plant -----------------------------------------------------------------


def test_plant_conserves_charge(any_battery: Battery):
    plant = BatteryPlant(any_battery)
    state = any_battery.initial_state(soc=0.8, temperature_c=25.0)
    current = 0.25 * any_battery.capacity
    trajectory = plant.simulate(state, [Action(current_a=current)] * 30, 60.0)
    moved = current * 30 * 60.0 / 3600.0
    capacities = np.array(
        [any_battery.nameplate_capacity_ah * s.soh_capacity for s in trajectory.states]
    )
    reconstructed = float(
        np.sum((trajectory.soc[:-1] - trajectory.soc[1:]) * capacities[:-1])
    )
    assert reconstructed == pytest.approx(moved, rel=1e-9)


def test_plant_saturates_at_the_soc_rails(ev_battery: Battery):
    plant = BatteryPlant(ev_battery)
    state = ev_battery.initial_state(soc=0.02, temperature_c=25.0)
    result = plant.step(state, Action(power_w=200_000.0), 600.0)
    assert result.curtailed
    assert result.limiting == "state_of_charge_empty"
    assert result.state.soc >= -1e-12


def test_plant_never_produces_a_non_finite_state(ev_battery: Battery):
    plant = BatteryPlant(ev_battery)
    state = ev_battery.initial_state(soc=0.5, temperature_c=25.0)
    for power in (0.0, 1e5, -1e5, 1e7, -1e7):
        result = plant.step(state, Action(power_w=power), 60.0)
        assert np.isfinite(result.state.voltage_v)
        assert np.isfinite(result.state.temperature_c)
        assert np.isfinite(result.state.soc)


def test_efficiency_falls_as_power_rises(ev_battery: Battery):
    plant = BatteryPlant(ev_battery)
    state = ev_battery.initial_state(soc=0.7, temperature_c=25.0)
    efficiencies = []
    for power in (10_000.0, 50_000.0, 120_000.0):
        trajectory = plant.simulate_constant_power(state, power, duration_s=600.0, dt=60.0)
        efficiencies.append(trajectory.mean_efficiency())
    assert efficiencies == sorted(efficiencies, reverse=True)


def test_simulated_trajectories_are_tagged_simulated(ev_battery: Battery):
    from batteryopt.core.provenance import Provenance

    plant = BatteryPlant(ev_battery)
    state = ev_battery.initial_state(soc=0.5, temperature_c=25.0)
    trajectory = plant.simulate(state, [Action(power_w=10_000.0)] * 5, 60.0)
    assert all(
        s.default_provenance is Provenance.SIMULATED for s in trajectory.states[1:]
    )


def test_variable_step_sizes_are_supported(ev_battery: Battery):
    plant = BatteryPlant(ev_battery)
    state = ev_battery.initial_state(soc=0.6, temperature_c=25.0)
    steps = [10.0, 30.0, 120.0, 600.0]
    trajectory = plant.simulate(state, [Action(power_w=20_000.0)] * len(steps), steps)
    assert trajectory.duration_s == pytest.approx(sum(steps))


# --- fidelity and surrogate ------------------------------------------------


@pytest.mark.parametrize("fidelity", list(Fidelity))
def test_every_fidelity_tier_builds_and_runs(ev_battery: Battery, fidelity):
    battery = Battery.build(chemistry="nmc", cells_series=96, cells_parallel=4)
    plant = build_plant(battery, fidelity)
    state = battery.initial_state(soc=0.5, temperature_c=25.0)
    trajectory = plant.simulate_constant_power(
        state, 20_000.0, duration_s=600.0, dt=profile_for(fidelity).time_step_s
    )
    assert trajectory.soc[-1] < trajectory.soc[0]


def test_high_fidelity_degrades_to_ecm_without_pybamm():
    assert effective_backend(Fidelity.RESEARCH) in ("ecm", "dfn")


def test_surrogate_matches_the_exact_model(any_battery: Battery):
    surface = build_surrogate(any_battery)
    report = surface.validate_against(any_battery, n_samples=200)
    for key, value in report.items():
        if key.endswith("_rms_rel_error"):
            assert value < 0.01, f"{key} = {value}"


def test_surrogate_knows_which_battery_it_is_for(ev_battery: Battery, grid_battery: Battery):
    surface = build_surrogate(ev_battery)
    assert surface.matches(ev_battery)
    assert not surface.matches(grid_battery)


def test_vectorised_degradation_matches_the_scalar_model(ev_battery: Battery):
    model = ev_battery.degradation
    soc = np.array([0.15, 0.5, 0.85])
    temperature = np.array([-5.0, 25.0, 45.0])
    current = np.array([-150.0, 0.0, 300.0])
    vector = degradation_rate_array(
        ev_battery, soc=soc, temperature_c=temperature, current_a=current
    )
    scalar = np.array(
        [
            model.marginal_fade_rate(
                ev_battery.degradation_state,
                soc=float(s),
                temperature_c=float(t),
                current_a=float(i),
                nameplate_capacity_ah=ev_battery.nameplate_capacity_ah,
            )
            for s, t, i in zip(soc, temperature, current)
        ]
    )
    np.testing.assert_allclose(vector, scalar, rtol=1e-12)
