"""Hard constraints.

The central property the specification demands (section 23) is tested here:

    **No optimiser can produce a recommendation that violates a configured hard
    constraint.**

It is tested adversarially -- every method, against states chosen specifically
to tempt each limit -- rather than on a happy path, because a safety property
that only holds on the happy path is not a safety property.
"""

from __future__ import annotations

import math

import numpy as np
import pytest

from batteryopt.core.exceptions import InfeasibleProblem, SafetyViolation
from batteryopt.models.battery import Battery
from batteryopt.models.plant import Action, BatteryPlant
from batteryopt.optimisation.constraints import (
    Constraint,
    ConstraintKind,
    ConstraintSet,
)
from batteryopt.optimisation.engine import METHODS, OptimisationEngine
from batteryopt.optimisation.problem import Demand

# States chosen to press against each limit in turn.
ADVERSARIAL_STATES = [
    ("nearly empty", 0.02, 25.0),
    ("nearly full", 0.98, 25.0),
    ("very cold", 0.50, -15.0),
    ("cold and empty", 0.05, -10.0),
    ("very hot", 0.50, 52.0),
    ("hot and full", 0.95, 48.0),
    ("mid", 0.50, 25.0),
]


def _states(battery: Battery):
    for label, soc, temperature in ADVERSARIAL_STATES:
        yield label, battery.initial_state(
            soc=soc, temperature_c=temperature, ambient_c=temperature
        )


# --- definition ------------------------------------------------------------


def test_hard_constraints_are_derived_from_the_envelope(ev_battery: Battery):
    constraints = ConstraintSet(ev_battery)
    names = {c.name for c in constraints.hard}
    assert {
        "terminal_voltage",
        "discharge_current",
        "cell_temperature",
        "charge_temperature_window",
        "state_of_charge",
    }.issubset(names)


def test_hard_constraints_can_only_be_tightened(ev_battery: Battery):
    constraints = ConstraintSet(ev_battery)
    original = constraints.get("terminal_voltage")
    constraints.add(
        Constraint(
            name="terminal_voltage",
            quantity="voltage_v",
            kind=ConstraintKind.HARD,
            unit="V",
            lower=original.lower - 100.0,
            upper=original.upper + 100.0,
            source="a well-meaning but wrong configuration",
        )
    )
    updated = constraints.get("terminal_voltage")
    assert updated.lower >= original.lower
    assert updated.upper <= original.upper


def test_a_hard_constraint_cannot_be_downgraded_to_soft(ev_battery: Battery):
    constraints = ConstraintSet(ev_battery)
    with pytest.raises(SafetyViolation, match="downgrade"):
        constraints.add(
            Constraint(
                name="terminal_voltage",
                quantity="voltage_v",
                kind=ConstraintKind.SOFT,
                unit="V",
            )
        )


def test_operator_overrides_never_widen_the_cell_envelope():
    battery = Battery.build(
        chemistry="nmc",
        cells_series=96,
        cells_parallel=4,
        envelope_overrides={"v_max_cell": 4.9, "t_max_c": 200.0, "max_charge_c_rate": 99.0},
    )
    chemistry = battery.chemistry.envelope
    assert battery.envelope.v_max_cell <= chemistry.v_max_cell
    assert battery.envelope.t_max_c <= chemistry.t_max_c
    assert battery.envelope.max_charge_c_rate <= chemistry.max_charge_c_rate


# --- bounds ----------------------------------------------------------------


def test_bounds_are_never_wider_than_the_ratings(any_battery: Battery):
    """Bounds must respect the current rating -- compared as *currents*.

    Dividing power by the rest voltage is not the same thing: under load the
    terminal voltage sags, so the same power corresponds to a larger current
    than the naive division suggests. The comparison has to go through the
    model's own power-to-current inversion.
    """
    constraints = ConstraintSet(any_battery)
    ecm = any_battery.electrical
    for label, state in _states(any_battery):
        bounds = constraints.bounds(state, 60.0)
        # The inversion must be evaluated at the *same* state the bound was
        # computed at -- including the aged resistance. Inverting an aged
        # battery's power through a beginning-of-life resistance overstates the
        # current by exactly the ageing factor, which looks like a bounds bug
        # and is not one.
        discharge_current = ecm.current_for_power(
            bounds.max_power_w,
            soc=state.soc,
            temperature_c=state.temperature_c,
            rc_voltages=state.rc_voltages,
            resistance_growth=state.degradation.resistance_growth,
            hysteresis=state.hysteresis,
        )
        charge_current = ecm.current_for_power(
            bounds.min_power_w,
            soc=state.soc,
            temperature_c=state.temperature_c,
            rc_voltages=state.rc_voltages,
            resistance_growth=state.degradation.resistance_growth,
            hysteresis=state.hysteresis,
        )
        assert discharge_current <= any_battery.maximum_current * 1.001, label
        assert -charge_current <= any_battery.maximum_charge_current * 1.001, label


def test_charging_is_forbidden_below_the_charge_temperature(ev_battery: Battery):
    constraints = ConstraintSet(ev_battery)
    cold = ev_battery.initial_state(
        soc=0.5,
        temperature_c=ev_battery.thermal_limits.t_min_charge_c - 5.0,
        ambient_c=-10.0,
    )
    bounds = constraints.bounds(cold, 60.0)
    assert bounds.min_power_w == pytest.approx(0.0, abs=1.0)
    assert "temperature" in bounds.charge_limiting


def test_discharging_is_forbidden_above_the_maximum_temperature(ev_battery: Battery):
    constraints = ConstraintSet(ev_battery)
    hot = ev_battery.initial_state(
        soc=0.5, temperature_c=ev_battery.thermal_limits.t_max_c + 2.0, ambient_c=50.0
    )
    bounds = constraints.bounds(hot, 60.0)
    assert bounds.max_power_w == pytest.approx(0.0, abs=1.0)


def test_soft_bounds_are_tighter_than_hard_bounds(ev_battery: Battery):
    constraints = ConstraintSet(ev_battery, soc_reserve=0.3, soc_ceiling=0.7)
    state = ev_battery.initial_state(soc=0.35, temperature_c=25.0)
    hard = constraints.bounds(state, 600.0, include_soft=False)
    soft = constraints.bounds(state, 600.0, include_soft=True)
    assert soft.max_power_w <= hard.max_power_w + 1e-6


def test_clamping_reports_the_binding_limit(ev_battery: Battery):
    constraints = ConstraintSet(ev_battery)
    state = ev_battery.initial_state(soc=0.5, temperature_c=25.0)
    bounds = constraints.bounds(state, 60.0)
    value, limiting = bounds.clamp(1e9)
    assert value == pytest.approx(bounds.max_power_w)
    assert limiting == bounds.discharge_limiting


# --- checking --------------------------------------------------------------


def test_violations_are_detected_in_a_state(ev_battery: Battery):
    constraints = ConstraintSet(ev_battery)
    bad = ev_battery.initial_state(soc=0.5, temperature_c=25.0).evolve(
        temperature_c=70.0, temperature_max_c=70.0, temperature_min_c=70.0
    )
    violations = constraints.check_state(bad)
    assert any(v.is_hard and v.constraint.name == "cell_temperature" for v in violations)


def test_the_hottest_cell_is_what_counts_not_the_mean(ev_battery: Battery):
    constraints = ConstraintSet(ev_battery)
    state = ev_battery.initial_state(soc=0.5, temperature_c=25.0).evolve(
        temperature_c=40.0, temperature_max_c=ev_battery.thermal_limits.t_max_c + 5.0
    )
    assert any(v.is_hard for v in constraints.check_state(state))


def test_the_charge_window_only_applies_while_charging(ev_battery: Battery):
    constraints = ConstraintSet(ev_battery)
    cold = ev_battery.initial_state(soc=0.5, temperature_c=-5.0, ambient_c=-5.0)
    discharging = cold.evolve(current_a=50.0)
    charging = cold.evolve(current_a=-50.0)
    assert not any(
        v.constraint.name == "charge_temperature_window"
        for v in constraints.check_state(discharging)
    )
    assert any(
        v.constraint.name == "charge_temperature_window"
        for v in constraints.check_state(charging)
    )


def test_assert_satisfied_raises_on_a_breach(ev_battery: Battery):
    constraints = ConstraintSet(ev_battery)
    bad = ev_battery.initial_state(soc=0.5, temperature_c=25.0).evolve(
        temperature_c=80.0, temperature_max_c=80.0
    )
    with pytest.raises(SafetyViolation):
        constraints.assert_satisfied([bad])


# --- THE SAFETY PROPERTY ---------------------------------------------------


@pytest.mark.parametrize("method", sorted(METHODS))
@pytest.mark.parametrize("label,soc,temperature", ADVERSARIAL_STATES)
def test_no_method_can_return_a_violating_recommendation(
    ev_battery: Battery, method: str, label: str, soc: float, temperature: float
):
    """The property the whole platform hangs on.

    For every optimisation method and every adversarial state, either the engine
    returns a recommendation whose *simulated consequences* satisfy every hard
    constraint, or it refuses. There is no third outcome.
    """
    engine = OptimisationEngine(ev_battery, objective="balanced", method=method)
    state = ev_battery.initial_state(
        soc=soc, temperature_c=temperature, ambient_c=temperature
    )
    try:
        recommendation = engine.optimise_state(
            state, demand=Demand(power_w=200_000.0, firm=True), horizon_s=600.0, dt_s=60.0
        )
    except (InfeasibleProblem, SafetyViolation):
        return  # refusing is a correct outcome

    # Re-simulate independently of the engine and re-check from scratch.
    plant = BatteryPlant(ev_battery)
    n = max(1, int(600.0 / 60.0))
    actions = [
        Action(
            power_w=recommendation.recommended_power_w,
            cooling_fraction=recommendation.cooling_requirement,
        )
    ] * n
    trajectory = plant.simulate(state.as_simulated(), actions, 60.0)
    violations = ConstraintSet(ev_battery).hard_violations(trajectory.states)
    assert not violations, (
        f"{method} at {label}: recommended "
        f"{recommendation.recommended_power_w / 1000:.1f} kW, which breaches "
        + "; ".join(str(v) for v in violations[:3])
    )


@pytest.mark.parametrize("label,soc,temperature", ADVERSARIAL_STATES)
def test_the_public_api_upholds_the_property_too(
    ev_battery: Battery, label: str, soc: float, temperature: float, tou_tariff
):
    from batteryopt import optimise

    state = ev_battery.initial_state(
        soc=soc, temperature_c=temperature, ambient_c=temperature
    )
    try:
        recommendation = optimise(
            battery_state=state,
            battery=ev_battery,
            demand=300_000.0,
            objective="power",
            tariff=tou_tariff,
            horizon_s=600.0,
            dt_s=60.0,
        )
    except (InfeasibleProblem, SafetyViolation):
        return
    plant = BatteryPlant(ev_battery)
    trajectory = plant.simulate(
        state.as_simulated(),
        [Action(power_w=recommendation.recommended_power_w,
                cooling_fraction=recommendation.cooling_requirement)] * 10,
        60.0,
    )
    assert not ConstraintSet(ev_battery).hard_violations(trajectory.states)


def test_a_maximum_power_objective_still_cannot_break_a_limit(ev_battery: Battery):
    """The objective with the strongest incentive to misbehave, checked directly."""
    engine = OptimisationEngine(ev_battery, objective="power")
    for label, state in _states(ev_battery):
        try:
            recommendation = engine.optimise_state(
                state, demand=1e6, horizon_s=900.0, dt_s=60.0
            )
        except (InfeasibleProblem, SafetyViolation):
            continue
        plant = BatteryPlant(ev_battery)
        trajectory = plant.simulate(
            state.as_simulated(),
            [Action(power_w=recommendation.recommended_power_w,
                    cooling_fraction=recommendation.cooling_requirement)] * 15,
            60.0,
        )
        assert not ConstraintSet(ev_battery).hard_violations(trajectory.states), label


def test_tightened_operator_limits_are_respected(ev_battery: Battery):
    """A limit the operator adds must bind as hard as one from the datasheet."""
    constraints = ConstraintSet(ev_battery)
    constraints.add(
        Constraint(
            name="site_power_cap",
            quantity="power_w",
            kind=ConstraintKind.HARD,
            unit="W",
            lower=-20_000.0,
            upper=25_000.0,
            source="grid connection agreement",
        )
    )
    engine = OptimisationEngine(ev_battery, objective="power", constraints=constraints)
    state = ev_battery.initial_state(soc=0.7, temperature_c=25.0)
    recommendation = engine.optimise_state(state, demand=1e6, horizon_s=600.0, dt_s=60.0)
    assert recommendation.recommended_power_w <= 25_000.0 + 1e-6


def test_an_empty_feasible_set_raises_rather_than_guessing(ev_battery: Battery):
    constraints = ConstraintSet(ev_battery)
    state = ev_battery.initial_state(soc=0.5, temperature_c=25.0)
    bounds = constraints.bounds(state, 60.0)
    broken = type(bounds)(
        min_power_w=100.0,
        max_power_w=-100.0,
        charge_limiting="test",
        discharge_limiting="test",
    )
    assert broken.is_empty
    with pytest.raises(InfeasibleProblem):
        broken.clamp(0.0)


def test_constraint_set_serialises_for_the_audit_trail(ev_battery: Battery):
    payload = ConstraintSet(ev_battery, soc_reserve=0.1).fingerprint_payload()
    assert payload["soc_reserve"] == 0.1
    assert any(c["name"] == "terminal_voltage" for c in payload["constraints"])


def test_the_held_action_check_survives_a_short_commitment_window(ev_battery: Battery):
    """The safety check must not be the thing that crashes.

    The held-action check deliberately builds a scenario over just the commitment
    window, which is *shorter* than the problem it is evaluated against. Code that
    assumes the two match raises a broadcasting error from inside the check whose
    entire purpose is to catch unsafe plans -- and an exception there is not a
    refusal, it is an outage.
    """
    engine = OptimisationEngine(ev_battery, objective="ev")
    state = ev_battery.initial_state(soc=0.65, temperature_c=25.0, ambient_c=25.0)
    for window_s, horizon_s, dt_s in ((900.0, 1800.0, 300.0), (60.0, 3600.0, 60.0)):
        engine.commitment_window_s = window_s
        recommendation = engine.optimise_state(
            state,
            demand=Demand(power_w=42_000.0, firm=True),
            horizon_s=horizon_s,
            dt_s=dt_s,
            ambient_c=25.0,
        )
        assert np.isfinite(recommendation.recommended_power_w)


def test_a_reused_engine_does_not_inherit_a_stale_commitment_window(ev_battery: Battery):
    """A short window set by one call must not silently narrow the next one's checks.

    The service holds one engine per battery across requests, so state that leaks
    between calls is a live hazard rather than a theoretical one.
    """
    engine = OptimisationEngine(ev_battery, objective="ev")
    state = ev_battery.initial_state(soc=0.65, temperature_c=25.0, ambient_c=25.0)
    engine.commitment_window_s = 60.0
    engine.optimise_state(state, demand=300.0, horizon_s=600.0, dt_s=60.0)
    # A later, longer problem still gets checked over a window it can represent.
    engine.commitment_window_s = 0.0
    later = engine.optimise_state(state, demand=300.0, horizon_s=7200.0, dt_s=600.0)
    assert engine.commitment_window_s == pytest.approx(7200.0)
    assert np.isfinite(later.recommended_power_w)
