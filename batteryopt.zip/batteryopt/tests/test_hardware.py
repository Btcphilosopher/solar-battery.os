"""Hardware abstraction and the virtual system."""

from __future__ import annotations

import numpy as np
import pytest

from batteryopt.hardware.interfaces import (
    BMSInterface,
    ChargerInterface,
    Command,
    DeviceStatus,
    EnergyMeterInterface,
    InverterInterface,
    OperatingLimits,
    PackInterface,
    ThermalSystemInterface,
    limits_from_recommendation,
)
from batteryopt.hardware.virtual import VirtualInverter, VirtualSystem
from batteryopt.models.battery import Battery
from batteryopt.optimisation.engine import OptimisationEngine


@pytest.fixture
def system(ev_battery: Battery) -> VirtualSystem:
    return VirtualSystem.build(
        ev_battery, initial_soc=0.5, initial_temperature_c=22.0, ambient_c=18.0,
        charger_power_w=120_000.0,
    )


def test_virtual_devices_satisfy_the_protocols(system: VirtualSystem):
    assert isinstance(system.bms, BMSInterface)
    assert isinstance(system.pack, PackInterface)
    assert isinstance(system.charger, ChargerInterface)
    assert isinstance(system.inverter, InverterInterface)
    assert isinstance(system.thermal, ThermalSystemInterface)
    assert isinstance(system.meter, EnergyMeterInterface)


def test_the_registry_describes_everything(system: VirtualSystem):
    described = system.describe()
    assert set(described) == {"bms", "pack", "charger", "inverter", "thermal", "meter"}
    assert all(info["status"] == "OK" for info in described.values())


def test_commands_are_advisory_by_default():
    command = Command(quantity="power_w", value=1000.0, unit="W")
    assert command.advisory is True


def test_charging_ramps_rather_than_stepping(system: VirtualSystem):
    system.apply(power_w=-100_000.0)
    powers = []
    for _ in range(6):
        system.tick(1.0)
        powers.append(system.charger.actual_power_w())
    assert powers[0] > powers[-1]  # ramping down towards the negative setpoint
    assert powers == sorted(powers, reverse=True)


def test_the_thermal_actuator_lags_its_command(system: VirtualSystem):
    system.apply(power_w=0.0, cooling=1.0)
    system.tick(1.0)
    assert 0.0 < system.thermal.cooling < 1.0
    for _ in range(200):
        system.tick(1.0)
    assert system.thermal.cooling == pytest.approx(1.0, abs=0.01)


def test_the_bms_soc_drifts_away_from_the_truth(system: VirtualSystem):
    """Which is precisely why independent state estimation exists."""
    start = abs(system.bms.read_measurement().reported_soc - system.pack.state.soc)
    system.apply(power_w=40_000.0)
    for _ in range(600):
        system.tick(10.0)
    end = abs(system.bms.read_measurement().reported_soc - system.pack.state.soc)
    assert end > start


def test_the_bms_intersects_advisory_limits_with_its_own(system: VirtualSystem, ev_battery):
    generous = OperatingLimits(
        max_charge_current_a=99_999.0,
        max_discharge_current_a=99_999.0,
        max_voltage_v=9_999.0,
        reason="a wildly optimistic advisory",
    )
    assert system.bms.apply_limits(generous)
    applied = system.bms.limits
    assert applied.max_charge_current_a <= ev_battery.maximum_charge_current
    assert applied.max_discharge_current_a <= ev_battery.maximum_current
    assert applied.max_voltage_v <= ev_battery.maximum_voltage


def test_a_recommendation_becomes_a_ceiling_not_a_setpoint(ev_battery: Battery):
    engine = OptimisationEngine(ev_battery, objective="balanced")
    recommendation = engine.optimise_state(
        ev_battery.initial_state(soc=0.6, temperature_c=25.0), demand=30_000.0
    )
    limits = limits_from_recommendation(recommendation, ev_battery)
    assert limits.max_discharge_power_w == pytest.approx(
        max(0.0, recommendation.recommended_power_w)
    )
    assert limits.target_soc == pytest.approx(recommendation.target_soc)


def test_open_contactors_stop_the_power(system: VirtualSystem):
    system.pack.open_contactors()
    system.apply(power_w=50_000.0)
    before = system.pack.state.soc
    for _ in range(20):
        system.tick(10.0)
    assert system.pack.state.soc == pytest.approx(before)


def test_injected_faults_show_in_the_device_status(system: VirtualSystem):
    assert system.bms.info().status is DeviceStatus.OK
    system.bms.inject_fault("cell_overvoltage")
    assert system.bms.info().status is DeviceStatus.FAULT
    assert "cell_overvoltage" in system.bms.active_faults()
    system.bms.clear_faults()
    assert system.bms.info().status is DeviceStatus.OK


def test_the_inverter_is_worst_at_part_load():
    inverter = VirtualInverter(rated_power_w=250_000.0)
    efficiencies = {
        load: inverter.efficiency_at(load * 250_000.0)
        for load in (0.02, 0.05, 0.2, 0.5, 1.0)
    }
    assert efficiencies[0.02] < efficiencies[0.05] < efficiencies[0.2]
    assert efficiencies[0.5] > efficiencies[1.0]
    assert efficiencies[0.5] < 1.0


def test_the_meter_accumulates_import_and_export(system: VirtualSystem):
    system.apply(power_w=-50_000.0)
    for _ in range(60):
        system.tick(10.0)
    assert system.meter.cumulative_import_wh() > 0
    system.apply(power_w=50_000.0)
    for _ in range(60):
        system.tick(10.0)
    assert system.meter.cumulative_export_wh() > 0


def test_the_virtual_system_drives_the_estimator(ev_battery: Battery, system: VirtualSystem):
    """End to end with no BatteryOpt-supplied telemetry: the hardware speaks."""
    from batteryopt.twin.twin import DigitalTwin

    twin = DigitalTwin(ev_battery, initial_soc=0.4, initial_temperature_c=22.0)
    system.apply(power_w=30_000.0, cooling=0.3)
    for _ in range(600):
        system.tick(1.0)
        twin.ingest(system.measurement(), 1.0)
    assert abs(twin.state.soc - system.pack.state.soc) < 0.05
    # The twin should beat the BMS's own drifting counter.
    bms_error = abs(system.bms.read_measurement().reported_soc - system.pack.state.soc)
    assert abs(twin.state.soc - system.pack.state.soc) < bms_error
