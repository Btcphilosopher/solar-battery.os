"""State estimation: SOC, SOH, SOP, imbalance and fusion."""

from __future__ import annotations

import numpy as np
import pytest

from batteryopt.estimation.base import Estimate, Measurement
from batteryopt.estimation.coulomb import CoulombCounter
from batteryopt.estimation.ekf import ExtendedKalmanSOC
from batteryopt.estimation.fusion import fuse
from batteryopt.estimation.imbalance import ImbalanceEstimator
from batteryopt.estimation.ocv import OCVEstimator
from batteryopt.estimation.pipeline import StateEstimator
from batteryopt.estimation.soh import CapacityEstimator, ResistanceEstimator
from batteryopt.estimation.sop import PowerCapabilityEstimator
from batteryopt.models.battery import Battery
from batteryopt.models.plant import Action, BatteryPlant


def _run(battery: Battery, estimator, *, steps=1080, dt=10.0, initial_soc=0.8,
         guess=0.65, seed=0, temperature=25.0):
    """Drive a virtual battery and feed the estimator noisy telemetry."""
    rng = np.random.default_rng(seed)
    plant = BatteryPlant(battery, track_states=False)
    state = battery.initial_state(soc=initial_soc, temperature_c=temperature)
    last = None
    for k in range(steps):
        power = 0.35 * battery.nominal_voltage * battery.nameplate_capacity_ah * float(
            np.sin(k / 90.0) > 0
        )
        state = plant.step(state, Action(power_w=power), dt).state
        measurement = Measurement(
            timestamp=state.timestamp,
            voltage_v=state.voltage_v + rng.normal(0.0, 0.02),
            current_a=state.current_a + rng.normal(0.0, 0.3),
            temperature_c=state.temperature_c,
            voltage_sigma_v=0.02,
        )
        last = estimator.update(measurement, dt)
    return state, last


# --- coulomb counting ------------------------------------------------------


def test_coulomb_counting_drifts_and_says_so(ev_battery: Battery):
    counter = CoulombCounter(capacity_ah=ev_battery.capacity, initial_soc=0.5)
    start_variance = counter.update(
        Measurement(timestamp=0.0, voltage_v=350.0, current_a=100.0, temperature_c=25.0), 1.0
    ).variance
    for k in range(3600):
        counter.update(
            Measurement(timestamp=float(k), voltage_v=350.0, current_a=100.0,
                        temperature_c=25.0),
            1.0,
        )
    assert counter.soc < 0.5
    assert counter.update(
        Measurement(timestamp=3601.0, voltage_v=350.0, current_a=0.0, temperature_c=25.0), 1.0
    ).variance > start_variance


def test_coulomb_counter_can_be_re_anchored(ev_battery: Battery):
    counter = CoulombCounter(capacity_ah=ev_battery.capacity, initial_soc=0.5)
    counter.anchor(0.8, 1e-6)
    assert counter.soc == pytest.approx(0.8)
    assert counter.update(
        Measurement(timestamp=1.0, voltage_v=350.0, current_a=0.0, temperature_c=25.0), 1.0
    ).variance < 1e-4


# --- OCV -------------------------------------------------------------------


def test_ocv_estimator_declines_while_the_pack_is_loaded(ev_battery: Battery):
    estimator = OCVEstimator(ev_battery.electrical)
    estimate = estimator.update(
        Measurement(timestamp=0.0, voltage_v=350.0, current_a=100.0, temperature_c=25.0), 60.0
    )
    assert not estimate.valid
    assert "rested" in (estimate.reason or "")


def test_ocv_estimator_works_after_a_long_rest(ev_battery: Battery):
    estimator = OCVEstimator(ev_battery.electrical)
    voltage = float(ev_battery.electrical.ocv(0.6))
    estimate = None
    for k in range(200):
        estimate = estimator.update(
            Measurement(timestamp=float(k * 60), voltage_v=voltage, current_a=0.0,
                        temperature_c=25.0),
            60.0,
        )
    assert estimate.valid
    assert estimate.value == pytest.approx(0.6, abs=0.02)


def test_ocv_estimator_declines_on_a_flat_plateau():
    """LFP mid-range: the honest answer is "I cannot tell"."""
    battery = Battery.build(chemistry="lfp", cells_series=250, cells_parallel=2)
    estimator = OCVEstimator(battery.electrical, min_slope_v_per_soc=0.15)
    voltage = float(battery.electrical.ocv(0.5))
    estimate = None
    for k in range(400):
        estimate = estimator.update(
            Measurement(timestamp=float(k * 60), voltage_v=voltage, current_a=0.0,
                        temperature_c=25.0),
            60.0,
        )
    assert not estimate.valid
    assert "slope" in (estimate.reason or "")


# --- EKF -------------------------------------------------------------------


def test_ekf_converges_from_a_bad_initial_guess(any_battery: Battery):
    # The filter is told the battery's resistance growth, exactly as the
    # pipeline tells it. Without that it is running a beginning-of-life
    # resistance against an aged pack, and on a flat chemistry that model error
    # turns straight into an SOC bias -- which is a real failure mode, but it is
    # the SOH estimator's job to fix, not the filter's.
    ekf = ExtendedKalmanSOC(
        any_battery.electrical,
        capacity_ah=any_battery.capacity,
        initial_soc=0.65,
        resistance_growth=any_battery.degradation_state.resistance_growth,
    )
    truth, estimate = _run(any_battery, ekf, initial_soc=0.80)
    assert abs(estimate.value - truth.soc) < 0.02


def test_ekf_reports_a_credible_uncertainty(ev_battery: Battery):
    """A filter that is confidently wrong is worse than one that is uncertain."""
    ekf = ExtendedKalmanSOC(
        ev_battery.electrical,
        capacity_ah=ev_battery.capacity,
        initial_soc=0.65,
        resistance_growth=ev_battery.degradation_state.resistance_growth,
    )
    truth, estimate = _run(ev_battery, ekf, initial_soc=0.80)
    error = abs(estimate.value - truth.soc)
    assert error <= 6.0 * max(estimate.stddev, 1e-4)


def test_ekf_stays_statistically_consistent(ev_battery: Battery):
    ekf = ExtendedKalmanSOC(
        ev_battery.electrical,
        capacity_ah=ev_battery.capacity,
        initial_soc=0.7,
        resistance_growth=ev_battery.degradation_state.resistance_growth,
    )
    _run(ev_battery, ekf, initial_soc=0.75)
    assert 0.02 < ekf.consistency() < 8.0


def test_ekf_models_hysteresis_where_the_chemistry_declares_it(ev_battery: Battery):
    ekf = ExtendedKalmanSOC(
        ev_battery.electrical,
        capacity_ah=ev_battery.capacity,
        initial_soc=0.8,
        resistance_growth=ev_battery.degradation_state.resistance_growth,
    )
    if not ekf.models_hysteresis:
        pytest.skip("chemistry declares no hysteresis")
    _run(ev_battery, ekf, initial_soc=0.8)
    assert abs(ekf.hysteresis) > 0.1


def test_ekf_covariance_stays_positive_definite(ev_battery: Battery):
    ekf = ExtendedKalmanSOC(
        ev_battery.electrical, capacity_ah=ev_battery.capacity, initial_soc=0.5
    )
    _run(ev_battery, ekf, steps=2000, initial_soc=0.6)
    assert ekf.soc_variance > 0


def test_ekf_beats_coulomb_counting_when_the_sensor_has_an_offset(ev_battery: Battery):
    """The point of running a filter at all."""
    rng = np.random.default_rng(11)
    plant = BatteryPlant(ev_battery, track_states=False)
    state = ev_battery.initial_state(soc=0.8, temperature_c=25.0)
    ekf = ExtendedKalmanSOC(
        ev_battery.electrical,
        capacity_ah=ev_battery.capacity,
        initial_soc=0.8,
        resistance_growth=ev_battery.degradation_state.resistance_growth,
    )
    counter = CoulombCounter(capacity_ah=ev_battery.capacity, initial_soc=0.8)
    offset = 2.0
    ekf_estimate = counter_estimate = None
    # Kept away from the state-of-charge rails: at an empty pack both estimators
    # are pinned at zero and the comparison measures nothing.
    for k in range(2000):
        power = 0.12 * ev_battery.nominal_voltage * ev_battery.nameplate_capacity_ah * float(
            np.sin(k / 120.0) > 0
        )
        state = plant.step(state, Action(power_w=power), 10.0).state
        measurement = Measurement(
            timestamp=state.timestamp,
            voltage_v=state.voltage_v + rng.normal(0.0, 0.02),
            current_a=state.current_a + offset + rng.normal(0.0, 0.3),
            temperature_c=state.temperature_c,
            voltage_sigma_v=0.02,
        )
        ekf_estimate = ekf.update(measurement, 10.0)
        counter_estimate = counter.update(measurement, 10.0)
    assert 0.05 < state.soc < 0.95, "the comparison needs an interior state of charge"
    assert abs(ekf_estimate.value - state.soc) < abs(counter_estimate.value - state.soc)


# --- SOH -------------------------------------------------------------------


def test_capacity_estimator_ignores_early_segments(ev_battery: Battery):
    estimator = CapacityEstimator(nameplate_ah=ev_battery.nameplate_capacity_ah)
    measurement = Measurement(timestamp=0.0, voltage_v=350.0, current_a=100.0,
                              temperature_c=25.0)
    estimator.update(measurement, 60.0, soc=0.9, soc_variance=1e-8)
    estimator.update(measurement, 60.0, soc=0.4, soc_variance=1e-8)
    assert estimator.segments_accepted == 0  # still inside the warm-up


def test_capacity_estimator_converges_towards_the_truth(ev_battery: Battery):
    estimator = CapacityEstimator(
        nameplate_ah=ev_battery.nameplate_capacity_ah,
        initial_capacity_ah=ev_battery.nameplate_capacity_ah,
        warmup_s=0.0,
    )
    true_capacity = ev_battery.capacity
    soc = 0.9
    timestamp = 0.0
    # Each leg must move the state of charge by more than the estimator's
    # minimum swing, or no segment ever closes and the test measures nothing.
    for _ in range(30):
        for direction in (1.0, -1.0):
            current = direction * 60.0
            for _ in range(80):
                soc -= current * 60.0 / 3600.0 / true_capacity
                timestamp += 60.0
                estimator.update(
                    Measurement(timestamp=timestamp, voltage_v=350.0, current_a=current,
                                temperature_c=25.0),
                    60.0,
                    soc=soc,
                    soc_variance=1e-8,
                )
    assert estimator.segments_accepted > 0
    assert estimator.capacity_ah == pytest.approx(true_capacity, rel=0.05)


def test_resistance_estimator_needs_real_current_steps(ev_battery: Battery):
    estimator = ResistanceEstimator(
        ev_battery.chemistry,
        reference_ohm=ev_battery.electrical.resistance(soc=0.5, temperature_c=25.0),
    )
    estimate = estimator.update(
        Measurement(timestamp=0.0, voltage_v=350.0, current_a=0.0, temperature_c=25.0), 1.0
    )
    assert not estimate.valid


def test_resistance_estimator_recovers_a_known_growth(ev_battery: Battery):
    reference = ev_battery.electrical.resistance(soc=0.5, temperature_c=25.0)
    estimator = ResistanceEstimator(
        ev_battery.chemistry, reference_ohm=reference, forgetting=0.9
    )
    growth = 0.4
    actual = reference * (1.0 + growth)
    ocv = 350.0
    estimate = None
    for k in range(60):
        for current in (0.0, 100.0):
            estimate = estimator.update(
                Measurement(
                    timestamp=float(k * 2 + (current > 0)),
                    voltage_v=ocv - current * actual,
                    current_a=current,
                    temperature_c=25.0,
                    voltage_sigma_v=0.005,
                ),
                1.0,
            )
    assert estimate.valid
    assert estimate.value == pytest.approx(growth, abs=0.08)


# --- SOP -------------------------------------------------------------------


def test_power_capability_falls_with_horizon(ev_battery: Battery):
    estimator = PowerCapabilityEstimator(ev_battery)
    state = ev_battery.initial_state(soc=0.5, temperature_c=25.0)
    short = estimator.estimate(state, horizon_s=10.0).discharge_w
    medium = estimator.estimate(state, horizon_s=600.0).discharge_w
    long = estimator.estimate(state, horizon_s=3600.0).discharge_w
    assert short >= medium >= long


def test_power_capability_names_the_binding_limit(ev_battery: Battery):
    estimator = PowerCapabilityEstimator(ev_battery)
    empty = ev_battery.initial_state(soc=0.06, temperature_c=25.0)
    capability = estimator.estimate(empty, horizon_s=1800.0)
    assert capability.discharge_limiting in ("state_of_charge", "voltage")


def test_charging_is_inhibited_when_too_cold(ev_battery: Battery):
    estimator = PowerCapabilityEstimator(ev_battery)
    cold = ev_battery.initial_state(
        soc=0.5, temperature_c=ev_battery.thermal_limits.t_min_charge_c - 5.0
    )
    capability = estimator.estimate(cold, horizon_s=60.0)
    assert capability.charge_w == pytest.approx(0.0, abs=1.0)


def test_capability_never_exceeds_the_pulse_rating(ev_battery: Battery):
    estimator = PowerCapabilityEstimator(ev_battery)
    state = ev_battery.initial_state(soc=0.9, temperature_c=25.0)
    capability = estimator.estimate(state, horizon_s=5.0)
    assert capability.discharge_w <= ev_battery.pulse_discharge_current * ev_battery.maximum_voltage


# --- imbalance -------------------------------------------------------------


def test_imbalance_needs_cell_data(ev_battery: Battery):
    estimator = ImbalanceEstimator(ev_battery.chemistry, cell_capacity_ah=60.0)
    assert not estimator.update(
        Measurement(timestamp=0.0, voltage_v=350.0, current_a=0.0, temperature_c=25.0), 1.0
    ).valid


def test_imbalance_detects_a_spread(ev_battery: Battery):
    estimator = ImbalanceEstimator(ev_battery.chemistry, cell_capacity_ah=60.0)
    base = 3.7
    cells = tuple(base + 0.01 * k for k in range(8))
    for k in range(20):
        estimator.update(
            Measurement(timestamp=float(k), voltage_v=350.0, current_a=0.0,
                        temperature_c=25.0, cell_voltages_v=cells),
            1.0,
        )
    report = estimator.report()
    assert report.voltage_spread_v == pytest.approx(0.07, abs=1e-6)
    assert report.soc_spread > 0


def test_imbalance_confidence_is_low_without_current_variation(ev_battery: Battery):
    """Resistance spread and SOC spread are indistinguishable at rest."""
    estimator = ImbalanceEstimator(ev_battery.chemistry, cell_capacity_ah=60.0)
    cells = tuple(3.7 + 0.005 * k for k in range(8))
    for k in range(50):
        estimator.update(
            Measurement(timestamp=float(k), voltage_v=350.0, current_a=0.0,
                        temperature_c=25.0, cell_voltages_v=cells),
            1.0,
        )
    assert estimator.report().confidence < 0.5


# --- fusion ----------------------------------------------------------------


def test_fusion_prefers_the_more_precise_estimate():
    result = fuse(
        [
            Estimate(0.50, 1e-6, source="precise"),
            Estimate(0.60, 1e-2, source="vague"),
        ]
    )
    assert result.value == pytest.approx(0.50, abs=1e-3)
    assert result.weights["precise"] > 0.99


def test_fusion_gates_out_an_outlier():
    result = fuse(
        [
            Estimate(0.50, 1e-6, source="ekf"),
            Estimate(0.95, 1e-6, source="broken"),
        ],
        priority=("ekf",),
    )
    assert "broken" in result.outliers
    assert result.value == pytest.approx(0.50)


def test_fusion_inflates_variance_when_estimators_disagree():
    agree = fuse([Estimate(0.5, 1e-4, source="a"), Estimate(0.5, 1e-4, source="b")])
    disagree = fuse([Estimate(0.5, 1e-4, source="a"), Estimate(0.52, 1e-4, source="b")])
    assert disagree.variance > agree.variance
    assert disagree.agreement < agree.agreement


def test_fusion_records_unavailable_estimators():
    result = fuse(
        [Estimate(0.5, 1e-4, source="ok"), Estimate.unavailable("ocv", "pack not rested")]
    )
    assert "ocv" in result.unavailable
    assert result.value == pytest.approx(0.5)


def test_fusion_of_nothing_is_not_a_number():
    result = fuse([Estimate.unavailable("a", "no"), Estimate.unavailable("b", "no")])
    assert np.isnan(result.value)


# --- pipeline --------------------------------------------------------------


def test_pipeline_estimates_state_and_tags_provenance(ev_battery: Battery):
    from batteryopt.core.provenance import Provenance

    estimator = StateEstimator(ev_battery, initial_soc=0.7, initial_temperature_c=25.0)
    truth, _ = _run(ev_battery, estimator, steps=900, initial_soc=0.8)
    state = estimator.state
    assert abs(state.soc - truth.soc) < 0.03
    assert state.provenance_of("soc") is Provenance.ESTIMATED
    assert state.provenance_of("voltage_v") is Provenance.MEASURED


def test_pipeline_exposes_its_diagnostics(ev_battery: Battery):
    estimator = StateEstimator(ev_battery, initial_soc=0.7)
    _run(ev_battery, estimator, steps=400, initial_soc=0.75)
    diagnostics = estimator.diagnostics
    assert diagnostics.frames == 400
    assert diagnostics.soc_fusion is not None
    assert diagnostics.capability is not None
    assert set(diagnostics.soc_estimates) == {"ekf", "coulomb", "ocv"}
