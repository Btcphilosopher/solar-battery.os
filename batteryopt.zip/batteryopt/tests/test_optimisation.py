"""Objective, scenario engine, methods, the engine and reproducibility."""

from __future__ import annotations

import numpy as np
import pytest

from batteryopt.core.exceptions import InfeasibleProblem, OptimisationError
from batteryopt.economics.engine import EconomicConfig, EconomicEngine
from batteryopt.economics.prices import PriceCurve, Tariff
from batteryopt.models.battery import Battery
from batteryopt.optimisation.constraints import ConstraintSet
from batteryopt.optimisation.engine import METHODS, OptimisationEngine, select_method
from batteryopt.optimisation.objective import (
    Objective,
    Outcome,
    available_presets,
    pareto_matrix,
    preset,
)
from batteryopt.optimisation.problem import Demand, Mission, OptimisationProblem
from batteryopt.scenario.engine import ScenarioEngine
from batteryopt.scenario.strategies import archetypes, cooling_sweep, power_sweep


def _outcome(**kwargs) -> Outcome:
    base = dict(
        energy_discharged_wh=20_000.0,
        losses_wh=500.0,
        auxiliary_wh=50.0,
        capacity_fade=2e-5,
        peak_temperature_c=30.0,
        mean_temperature_c=28.0,
        duration_s=1800.0,
        start_soc=0.6,
        end_soc=0.4,
        equivalent_full_cycles=0.12,
        mean_efficiency=0.97,
    )
    base.update(kwargs)
    return Outcome(**base)


# --- economics -------------------------------------------------------------


def test_degradation_cost_scales_with_replacement_value(ev_battery: Battery):
    cheap = EconomicEngine(ev_battery, EconomicConfig(replacement_cost_per_kwh=80.0))
    dear = EconomicEngine(ev_battery, EconomicConfig(replacement_cost_per_kwh=300.0))
    assert dear.degradation_cost(0.001) > cheap.degradation_cost(0.001)


def test_discounting_reduces_deferred_replacement_cost(ev_battery: Battery):
    econ = EconomicEngine(ev_battery, EconomicConfig(discount_rate=0.08))
    assert econ.degradation_cost(0.01, remaining_years=10.0) < econ.degradation_cost(0.01)


def test_residual_value_reduces_the_amortised_cost(ev_battery: Battery):
    with_residual = EconomicEngine(ev_battery, EconomicConfig(residual_value_fraction=0.5))
    without = EconomicEngine(ev_battery, EconomicConfig(residual_value_fraction=0.0))
    assert with_residual.replacement_cost < without.replacement_cost


def test_cost_per_kwh_delivered_includes_the_battery_life_spent(ev_battery: Battery):
    econ = EconomicEngine(ev_battery)
    breakdown = econ.price_outcome(
        energy_discharged_wh=10_000.0,
        energy_charged_wh=11_000.0,
        losses_wh=400.0,
        auxiliary_wh=80.0,
        capacity_fade=1e-4,
        start_soc=0.7,
        end_soc=0.5,
    )
    assert breakdown.degradation_cost > 0
    assert econ.cost_per_kwh_delivered(breakdown, 10_000.0) > 0


def test_price_curve_lookup_and_spread():
    curve = PriceCurve.from_pairs([(0.0, 0.10), (3600.0, 0.30), (7200.0, 0.05)])
    assert curve.at(0.0) == pytest.approx(0.10)
    assert curve.at(5000.0) == pytest.approx(0.30)
    assert curve.at(-100.0) == pytest.approx(0.10)  # clamps rather than extrapolating
    assert curve.spread == pytest.approx(0.25)


def test_time_of_use_tariff_has_a_peak(tou_tariff: Tariff):
    assert tou_tariff.import_at(17 * 3600.0) > tou_tariff.import_at(3 * 3600.0)


# --- objective -------------------------------------------------------------


def test_every_preset_loads_and_scores(ev_battery: Battery):
    for name in available_presets():
        objective = Objective(ev_battery, preset(name))
        value = objective.evaluate(_outcome())
        assert np.isfinite(value.total)
        assert value.weighted_terms


def test_shortfall_dominates_for_the_ev_preset(ev_battery: Battery, tou_tariff: Tariff):
    objective = Objective(ev_battery, preset("ev"), tariff=tou_tariff)
    served = objective.evaluate(_outcome(shortfall_wh=0.0))
    short = objective.evaluate(_outcome(shortfall_wh=5_000.0))
    assert short.total < served.total


def test_the_lifetime_preset_punishes_degradation_hardest(ev_battery: Battery):
    gentle = _outcome(capacity_fade=1e-5)
    harsh = _outcome(capacity_fade=1e-4)
    lifetime_gap = (
        Objective(ev_battery, preset("lifetime")).evaluate(gentle).total
        - Objective(ev_battery, preset("lifetime")).evaluate(harsh).total
    )
    power_gap = (
        Objective(ev_battery, preset("power")).evaluate(gentle).total
        - Objective(ev_battery, preset("power")).evaluate(harsh).total
    )
    assert lifetime_gap > power_gap


def test_thermal_term_penalises_sustained_heat(ev_battery: Battery):
    objective = Objective(ev_battery, preset("consumer"))
    cool = objective.evaluate(_outcome(mean_temperature_c=25.0, peak_temperature_c=28.0))
    hot = objective.evaluate(_outcome(mean_temperature_c=45.0, peak_temperature_c=50.0))
    assert hot.total < cool.total


def test_objective_explains_its_dominant_term(ev_battery: Battery):
    value = Objective(ev_battery, preset("balanced")).evaluate(_outcome())
    assert value.dominant_term in value.weighted_terms
    assert "total" in value.explain()


def test_pareto_costs_are_unweighted(ev_battery: Battery):
    """The front is a property of the physics, not of anyone's weights."""
    outcome = _outcome()
    a = Objective(ev_battery, preset("ev")).evaluate(outcome)
    b = Objective(ev_battery, preset("lifetime")).evaluate(outcome)
    assert a.pareto_costs == b.pareto_costs
    assert pareto_matrix([a, b]).shape == (2, len(a.pareto_costs))


# --- scenario engine -------------------------------------------------------


def _problem(battery: Battery, **kwargs) -> OptimisationProblem:
    defaults = dict(
        state=battery.initial_state(soc=0.6, temperature_c=25.0, ambient_c=22.0),
        constraints=ConstraintSet(battery),
        objective=Objective(battery, preset("balanced")),
        horizon_s=900.0,
        dt_s=60.0,
    )
    defaults.update(kwargs)
    return OptimisationProblem(**defaults)


def test_scenario_engine_ranks_and_keeps_the_infeasible(ev_battery: Battery):
    problem = _problem(ev_battery, demand=Demand(power_w=40_000.0, firm=True))
    engine = ScenarioEngine(ev_battery)
    results = engine.compare(problem, archetypes(problem))
    assert results
    assert results[0].feasible
    scores = [r.score for r in results if r.feasible]
    assert scores == sorted(scores, reverse=True)


def test_shortfall_is_computed_against_a_firm_demand(ev_battery: Battery):
    problem = _problem(ev_battery, demand=Demand(power_w=60_000.0, firm=True))
    engine = ScenarioEngine(ev_battery)
    from batteryopt.scenario.strategies import constant_power

    lazy = engine.evaluate(problem, constant_power(problem, 10_000.0, label="lazy"))
    assert lazy.outcome.shortfall_wh > 0


def test_a_flexible_demand_incurs_no_shortfall(ev_battery: Battery):
    problem = _problem(ev_battery, demand=Demand(power_w=60_000.0, firm=False))
    engine = ScenarioEngine(ev_battery)
    from batteryopt.scenario.strategies import constant_power

    lazy = engine.evaluate(problem, constant_power(problem, 10_000.0, label="lazy"))
    assert lazy.outcome.shortfall_wh == 0.0


def test_cooling_sweep_finds_an_interior_optimum(ev_battery: Battery):
    """Neither extreme should win: that is the whole point of section 9."""
    problem = _problem(
        ev_battery,
        state=ev_battery.initial_state(soc=0.6, temperature_c=22.0, ambient_c=20.0),
        horizon_s=3600.0,
        dt_s=180.0,
        demand=Demand(power_w=30_000.0, firm=False),
    )
    engine = ScenarioEngine(ev_battery)
    results = engine.compare(problem, cooling_sweep(problem, 30_000.0))
    best = max((r for r in results if r.feasible), key=lambda r: r.score)
    assert 0.0 < best.scenario.first_cooling < 1.0


def test_power_sweep_respects_the_bounds(ev_battery: Battery):
    problem = _problem(ev_battery)
    bounds = problem.constraints.bounds(problem.state, problem.dt_s)
    for scenario in power_sweep(problem, n=11):
        assert bounds.min_power_w - 1e-6 <= scenario.first_power_w <= bounds.max_power_w + 1e-6


# --- methods ---------------------------------------------------------------


@pytest.mark.parametrize("method", sorted(METHODS))
def test_every_method_produces_a_usable_plan(ev_battery: Battery, method: str):
    engine = OptimisationEngine(ev_battery, objective="balanced", method=method)
    state = ev_battery.initial_state(soc=0.6, temperature_c=25.0)
    recommendation = engine.optimise_state(
        state, demand=30_000.0, horizon_s=900.0, dt_s=60.0
    )
    assert np.isfinite(recommendation.recommended_power_w)
    assert 0.0 <= recommendation.cooling_requirement <= 1.0
    assert 0.0 <= recommendation.confidence <= 1.0
    assert recommendation.plan_power_w


def test_methods_broadly_agree_on_a_simple_problem(ev_battery: Battery):
    """Different algorithms, same physics: they should land in the same place."""
    state = ev_battery.initial_state(soc=0.6, temperature_c=25.0)
    answers = {}
    for method in ("enumeration", "golden_section", "surrogate_sweep"):
        engine = OptimisationEngine(ev_battery, objective="balanced", method=method)
        answers[method] = engine.optimise_state(
            state, demand=40_000.0, horizon_s=900.0, dt_s=60.0
        ).recommended_power_w
    values = list(answers.values())
    assert max(values) - min(values) < 0.1 * max(abs(v) for v in values), answers


def test_method_selection_explains_itself(ev_battery: Battery, day_ahead_tariff: Tariff):
    engine = OptimisationEngine(ev_battery, objective="grid_storage", tariff=day_ahead_tariff)
    scheduling = engine.build_problem(
        ev_battery.initial_state(soc=0.5, temperature_c=25.0),
        horizon_s=12 * 3600.0,
        dt_s=1800.0,
    )
    choice = select_method(scheduling)
    assert choice.primary == "dynamic_programming"
    assert "scheduling" in choice.reason

    immediate = engine.build_problem(
        ev_battery.initial_state(soc=0.5, temperature_c=25.0), horizon_s=60.0, dt_s=60.0
    )
    assert select_method(immediate).primary == "golden_section"


def test_an_unknown_method_is_rejected(ev_battery: Battery):
    engine = OptimisationEngine(ev_battery, method="not_a_method")
    with pytest.raises((OptimisationError, InfeasibleProblem)):
        engine._method("not_a_method")


def test_linear_programme_charges_low_and_discharges_high(
    grid_battery: Battery, day_ahead_tariff: Tariff
):
    from batteryopt.optimisation.methods.linear_program import LinearProgramMethod

    engine = OptimisationEngine(
        grid_battery, objective="grid_storage", tariff=day_ahead_tariff
    )
    problem = engine.build_problem(
        grid_battery.initial_state(soc=0.5, temperature_c=22.0),
        horizon_s=24 * 3600.0,
        dt_s=1800.0,
    )
    result = LinearProgramMethod().solve(problem)
    schedule = np.asarray(result.power_w)
    times = problem.state.timestamp + np.arange(schedule.size) * problem.dt_s
    prices = np.asarray(day_ahead_tariff.import_at(times))
    charging = schedule < -1.0
    discharging = schedule > 1.0
    if charging.any() and discharging.any():
        assert prices[charging].mean() < prices[discharging].mean()
    assert result.diagnostics["simultaneous_charge_discharge_wh"] == pytest.approx(0.0, abs=1.0)


def test_dynamic_programming_prices_non_linear_losses(
    grid_battery: Battery, day_ahead_tariff: Tariff
):
    from batteryopt.optimisation.methods.dynamic_programming import DynamicProgrammingMethod

    engine = OptimisationEngine(
        grid_battery, objective="grid_storage", tariff=day_ahead_tariff
    )
    problem = engine.build_problem(
        grid_battery.initial_state(soc=0.5, temperature_c=22.0),
        horizon_s=12 * 3600.0,
        dt_s=1800.0,
    )
    result = DynamicProgrammingMethod().solve(problem)
    assert result.diagnostics["transitions"] > 10_000
    assert len(result.power_w) == problem.n_steps


def test_mixed_integer_falls_back_loudly_without_ortools(ev_battery: Battery):
    from batteryopt.core.optional import have
    from batteryopt.optimisation.methods.mixed_integer import MixedIntegerMethod

    engine = OptimisationEngine(ev_battery, objective="balanced")
    problem = engine.build_problem(
        ev_battery.initial_state(soc=0.5, temperature_c=25.0), horizon_s=1800.0, dt_s=300.0
    )
    result = MixedIntegerMethod().solve(problem)
    if have("ortools"):
        assert result.diagnostics["integrality"] == "enforced"
    else:
        assert result.diagnostics["integrality"] == "relaxed"
        assert "OR-Tools" in result.diagnostics["note"]
        assert not result.converged


def test_pareto_front_names_its_corners(ev_battery: Battery):
    engine = OptimisationEngine(ev_battery, objective="balanced")
    problem = engine.build_problem(
        ev_battery.initial_state(soc=0.6, temperature_c=25.0), horizon_s=900.0, dt_s=180.0
    )
    front = engine.pareto(problem, power_points=13)
    assert len(front) >= 3
    assert front.balanced is not None
    assert "maximum efficiency" in front.roles


def test_pareto_points_are_mutually_non_dominated(ev_battery: Battery):
    engine = OptimisationEngine(ev_battery, objective="balanced")
    problem = engine.build_problem(
        ev_battery.initial_state(soc=0.6, temperature_c=25.0), horizon_s=900.0, dt_s=180.0
    )
    front = engine.pareto(problem, power_points=13)
    costs = np.array([p.costs for p in front.points])
    for i in range(costs.shape[0]):
        for j in range(costs.shape[0]):
            if i == j:
                continue
            dominates = np.all(costs[j] <= costs[i]) and np.any(costs[j] < costs[i])
            assert not dominates, "front contains a dominated point"


# --- engine ----------------------------------------------------------------


def test_recommendation_has_the_specified_shape(ev_battery: Battery, tou_tariff: Tariff):
    engine = OptimisationEngine(ev_battery, objective="ev", tariff=tou_tariff)
    recommendation = engine.optimise_state(
        ev_battery.initial_state(soc=0.63, temperature_c=29.0),
        demand=42_000.0,
        horizon_s=900.0,
        dt_s=60.0,
    )
    payload = recommendation.as_dict()
    for key in (
        "recommended_power_w",
        "recommended_charge_rate_w",
        "recommended_discharge_rate_w",
        "cooling_requirement",
        "target_soc",
        "estimated_efficiency",
        "estimated_degradation",
        "estimated_cost",
        "confidence",
        "limiting_constraint",
    ):
        assert key in payload


def test_recommendations_are_tagged_optimised(ev_battery: Battery):
    from batteryopt.core.provenance import Provenance

    engine = OptimisationEngine(ev_battery, objective="balanced")
    recommendation = engine.optimise_state(
        ev_battery.initial_state(soc=0.5, temperature_c=25.0), demand=20_000.0
    )
    quantities = recommendation.as_quantities()
    assert quantities["recommended_power"].provenance is Provenance.OPTIMISED
    assert quantities["estimated_degradation"].provenance is Provenance.SIMULATED


def test_the_same_problem_gives_the_same_answer(ev_battery: Battery, tou_tariff: Tariff):
    """Reproducibility, checked by digest and by value."""
    engine = OptimisationEngine(ev_battery, objective="ev", tariff=tou_tariff)
    state = ev_battery.initial_state(soc=0.55, temperature_c=27.0)
    first = engine.optimise_state(state, demand=35_000.0, horizon_s=900.0, dt_s=60.0)
    second = engine.optimise_state(state, demand=35_000.0, horizon_s=900.0, dt_s=60.0)
    assert first.fingerprint.digest == second.fingerprint.digest
    assert first.recommended_power_w == pytest.approx(second.recommended_power_w)


def test_different_inputs_give_different_digests(ev_battery: Battery):
    engine = OptimisationEngine(ev_battery, objective="balanced")
    a = engine.optimise_state(
        ev_battery.initial_state(soc=0.5, temperature_c=25.0), demand=20_000.0
    )
    b = engine.optimise_state(
        ev_battery.initial_state(soc=0.6, temperature_c=25.0), demand=20_000.0
    )
    assert a.fingerprint.digest != b.fingerprint.digest


def test_the_objective_changes_the_answer(ev_battery: Battery, tou_tariff: Tariff):
    state = ev_battery.initial_state(soc=0.7, temperature_c=30.0)
    powers = {}
    for name in ("power", "lifetime"):
        engine = OptimisationEngine(ev_battery, objective=name, tariff=tou_tariff)
        powers[name] = engine.optimise_state(
            state, demand=Demand(power_w=150_000.0, firm=False), horizon_s=900.0, dt_s=60.0
        ).recommended_power_w
    assert powers["power"] > powers["lifetime"]


def test_the_engine_reports_what_bound_the_answer(ev_battery: Battery):
    engine = OptimisationEngine(ev_battery, objective="power")
    recommendation = engine.optimise_state(
        ev_battery.initial_state(soc=0.9, temperature_c=25.0),
        demand=Demand(power_w=1e6, firm=True),
        horizon_s=600.0,
        dt_s=60.0,
    )
    assert recommendation.limiting_constraint


def test_alternatives_span_the_range_not_just_the_optimum(ev_battery: Battery):
    engine = OptimisationEngine(ev_battery, objective="balanced", method="surrogate_sweep")
    recommendation = engine.optimise_state(
        ev_battery.initial_state(soc=0.6, temperature_c=25.0),
        demand=Demand(power_w=40_000.0, firm=False),
        horizon_s=900.0,
        dt_s=60.0,
    )
    powers = [a["power_w"] for a in recommendation.alternatives if "power_w" in a]
    assert len(powers) >= 4
    assert max(powers) - min(powers) > 20_000.0


def test_mission_planning_energy_respects_reliability():
    from batteryopt.core.provenance import Quantiles

    mission = Mission(
        energy_wh=50_000.0,
        departure_s=3600.0,
        quantiles=Quantiles(45_000.0, 50_000.0, 58_000.0),
        required_reliability=0.9,
    )
    assert mission.planning_energy_wh() == pytest.approx(58_000.0)
    relaxed = Mission(
        energy_wh=50_000.0,
        departure_s=3600.0,
        quantiles=Quantiles(45_000.0, 50_000.0, 58_000.0),
        required_reliability=0.5,
    )
    assert relaxed.planning_energy_wh() == pytest.approx(50_000.0)


# ---------------------------------------------------------------------------
# Local surplus is priced as surplus, not as an import
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("method", ["dynamic_programming", "linear_program"])
def test_charging_from_a_local_surplus_is_not_priced_at_the_import_tariff(
    grid_battery: Battery, method: str
):
    """A watt-hour of local generation costs the export revenue forgone, not the import price.

    Priced at the import tariff, an optimiser exports free generation at the
    (poor) export rate and then buys grid energy at the off-peak rate to refill
    the battery -- which is exactly backwards, and is not visible in any single
    number the recommendation reports. The test that catches it has to look at
    *when* the battery charges relative to when the surplus exists.
    """
    n = 24
    dt_s = 1800.0
    # A surplus in the middle of the window only, and a flat tariff so that no
    # price arbitrage can explain the answer -- only the surplus can.
    solar = np.zeros(n)
    solar[8:14] = 300_000.0
    demand = np.full(n, 20_000.0)
    tariff = Tariff.flat(0.20, 0.02)

    engine = OptimisationEngine(
        grid_battery, objective="grid_storage", tariff=tariff, method=method
    )
    state = grid_battery.initial_state(soc=0.3, temperature_c=22.0, ambient_c=20.0)
    result = engine.optimise_state(
        state,
        demand=Demand(power_w=tuple(demand), firm=False),
        solar_w=solar,
        horizon_s=n * dt_s,
        dt_s=dt_s,
        ambient_c=20.0,
    )
    schedule = np.asarray(result.plan_power_w, dtype=float)
    assert schedule.size == n

    charging = np.clip(-schedule, 0.0, None)
    assert charging.sum() > 0.0, "the battery should absorb a surplus it can store for free"

    surplus_charge = charging[8:14].sum()
    other_charge = charging[:8].sum() + charging[14:].sum()
    assert surplus_charge > other_charge, (
        f"{method} charged {other_charge / 1000:.0f} kW outside the surplus window and only "
        f"{surplus_charge / 1000:.0f} kW inside it; charging is being priced at the import "
        "tariff regardless of whether the energy is free"
    )


def test_a_poor_export_price_shifts_generation_into_the_battery(grid_battery: Battery):
    """The battery's job changes with the tariff, and the flows must show it.

    With a generous export price, exporting a surplus beats paying the round trip
    to store it. With a poor one, storing wins. A scheduler that returns the same
    plan for both is not optimising, whatever its objective value says.
    """
    from batteryopt.applications import SolarOptimiser

    n = 48
    dt_s = 1800.0
    solar = np.zeros(n)
    solar[16:30] = 250_000.0
    load = np.full(n, 30_000.0)
    load[36:42] = 120_000.0  # an evening peak, after the sun has gone

    stored = {}
    for label, export_price in (("generous", 0.15), ("poor", 0.02)):
        tariff = Tariff.flat(0.20, export_price)
        engine = OptimisationEngine(grid_battery, objective="grid_storage", tariff=tariff)
        state = grid_battery.initial_state(soc=0.3, temperature_c=22.0, ambient_c=20.0)
        plan = SolarOptimiser(engine).plan(
            state, tariff=tariff, solar_w=solar, load_w=load, horizon_s=n * dt_s, dt_s=dt_s
        )
        stored[label] = plan.flows.solar_to_battery_wh

    assert stored["poor"] > stored["generous"], (
        f"stored {stored['poor'] / 1000:.1f} kWh of generation when export paid 0.02 and "
        f"{stored['generous'] / 1000:.1f} kWh when it paid 0.15; the tariff is not reaching "
        "the decision"
    )


@pytest.mark.parametrize(
    "method",
    ["enumeration", "golden_section", "scipy", "surrogate_sweep",
     "dynamic_programming", "linear_program", "mixed_integer"],
)
def test_a_firm_load_is_served_and_a_flexible_one_is_not(ev_battery: Battery, method: str):
    """Firmness has to change the answer, in every method.

    A full battery under a flat-ish tariff has an economic reason to hold: energy
    kept is worth the average import price, which beats selling it at the current
    one. That reasoning is correct for a *flexible* load and wrong for a firm one,
    where not serving it has to cost something. A method with no shortfall term
    answers "rest" to "serve 250 kW, firmly" -- economically defensible, and
    operationally useless.
    """
    tariff = Tariff.time_of_use(peak_price=0.42, off_peak_price=0.09, horizon_hours=48)
    state = ev_battery.initial_state(soc=0.95, temperature_c=25.0, ambient_c=25.0)

    answers = {}
    for firm in (True, False):
        engine = OptimisationEngine(
            ev_battery, objective="industrial", tariff=tariff, method=method
        )
        engine.commitment_window_s = 0.0
        result = engine.optimise_state(
            state,
            demand=Demand(power_w=200_000.0, firm=firm),
            horizon_s=600.0,
            dt_s=60.0,
            ambient_c=25.0,
        )
        answers[firm] = result.recommended_power_w

    assert answers[True] > 10_000.0, (
        f"{method} left a firm 200 kW load unserved, recommending "
        f"{answers[True] / 1000:.1f} kW"
    )
    assert answers[True] > answers[False], (
        f"{method} treats a firm load the same as a flexible one: "
        f"{answers[True] / 1000:.1f} kW vs {answers[False] / 1000:.1f} kW"
    )
