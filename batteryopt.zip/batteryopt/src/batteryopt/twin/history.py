"""Bounded state history with cheap statistics.

The optimiser needs recent history for three things: rainflow depth-of-
discharge counting, mean-condition statistics that drive the ageing
projection, and the "what has this battery actually been doing" context that
turns a recommendation into an explanation. A fixed-capacity ring buffer of
compact records gives all three without unbounded memory growth in a process
that is expected to run for months.

Long-term history lives in PostgreSQL (see :mod:`batteryopt.persistence`);
this is the in-memory working set.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from typing import Iterable, Iterator

import numpy as np

from ..core.numerics import EPS
from ..core.units import SECONDS_PER_HOUR
from ..models.degradation import RainflowCounter
from ..models.state import BatteryState


@dataclass(frozen=True, slots=True)
class HistoryRecord:
    """A compact snapshot: the fields history actually needs, nothing more."""

    timestamp: float
    soc: float
    voltage_v: float
    current_a: float
    power_w: float
    temperature_c: float
    soh_capacity: float
    capacity_fade: float

    @classmethod
    def from_state(cls, state: BatteryState) -> "HistoryRecord":
        return cls(
            timestamp=state.timestamp,
            soc=state.soc,
            voltage_v=state.voltage_v,
            current_a=state.current_a,
            power_w=state.power_w,
            temperature_c=state.temperature_c,
            soh_capacity=state.soh_capacity,
            capacity_fade=state.degradation.capacity_fade,
        )


class StateHistory:
    """Ring buffer of :class:`HistoryRecord` with streaming statistics."""

    __slots__ = ("_records", "_rainflow", "_soc_sum", "_temp_sum", "_dt_sum", "_last_ts")

    def __init__(self, capacity: int = 20_000) -> None:
        self._records: deque[HistoryRecord] = deque(maxlen=capacity)
        self._rainflow = RainflowCounter()
        self._soc_sum = 0.0
        self._temp_sum = 0.0
        self._dt_sum = 0.0
        self._last_ts: float | None = None

    def append(self, state: BatteryState) -> None:
        record = HistoryRecord.from_state(state)
        self._records.append(record)
        self._rainflow.update(record.soc)
        if self._last_ts is not None:
            dt = max(0.0, record.timestamp - self._last_ts)
            # Time-weighted running means: an hour at 40 degC must not count
            # the same as one telemetry frame at 40 degC.
            self._soc_sum += record.soc * dt
            self._temp_sum += record.temperature_c * dt
            self._dt_sum += dt
        self._last_ts = record.timestamp

    def extend(self, states: Iterable[BatteryState]) -> None:
        for state in states:
            self.append(state)

    def __len__(self) -> int:
        return len(self._records)

    def __iter__(self) -> Iterator[HistoryRecord]:
        return iter(self._records)

    @property
    def latest(self) -> HistoryRecord | None:
        return self._records[-1] if self._records else None

    def since(self, timestamp: float) -> list[HistoryRecord]:
        return [r for r in self._records if r.timestamp >= timestamp]

    def window(self, seconds: float) -> list[HistoryRecord]:
        if not self._records:
            return []
        cutoff = self._records[-1].timestamp - seconds
        return self.since(cutoff)

    # -- statistics ---------------------------------------------------------

    @property
    def mean_soc(self) -> float:
        return self._soc_sum / self._dt_sum if self._dt_sum > EPS else (
            self._records[-1].soc if self._records else 0.5
        )

    @property
    def mean_temperature_c(self) -> float:
        return self._temp_sum / self._dt_sum if self._dt_sum > EPS else (
            self._records[-1].temperature_c if self._records else 25.0
        )

    @property
    def mean_dod(self) -> float:
        """Throughput-weighted mean depth of discharge, from rainflow counting."""
        return self._rainflow.mean_dod()

    @property
    def equivalent_full_cycles(self) -> float:
        return self._rainflow.equivalent_full_cycles

    def dod_histogram(self, bins: int = 10) -> dict[str, list[float]]:
        return self._rainflow.histogram(bins)

    def mean_current_a(self, seconds: float = 3600.0) -> float:
        """Mean absolute current over the recent window, A."""
        recent = self.window(seconds)
        if not recent:
            return 0.0
        return float(np.mean([abs(r.current_a) for r in recent]))

    def energy_wh(self, seconds: float | None = None) -> tuple[float, float]:
        """(discharged, charged) energy in Wh over the window."""
        records = list(self._records) if seconds is None else self.window(seconds)
        if len(records) < 2:
            return 0.0, 0.0
        t = np.array([r.timestamp for r in records])
        p = np.array([r.power_w for r in records])
        dt = np.diff(t)
        mid = 0.5 * (p[:-1] + p[1:])
        out = float(np.sum(np.clip(mid, 0.0, None) * dt) / SECONDS_PER_HOUR)
        into = float(np.sum(np.clip(-mid, 0.0, None) * dt) / SECONDS_PER_HOUR)
        return out, into

    def as_arrays(self) -> dict[str, np.ndarray]:
        """Columnar view, for plotting and for handing to Polars."""
        if not self._records:
            return {k: np.empty(0) for k in (
                "timestamp", "soc", "voltage_v", "current_a", "power_w",
                "temperature_c", "soh_capacity", "capacity_fade",
            )}
        recs = list(self._records)
        return {
            "timestamp": np.array([r.timestamp for r in recs]),
            "soc": np.array([r.soc for r in recs]),
            "voltage_v": np.array([r.voltage_v for r in recs]),
            "current_a": np.array([r.current_a for r in recs]),
            "power_w": np.array([r.power_w for r in recs]),
            "temperature_c": np.array([r.temperature_c for r in recs]),
            "soh_capacity": np.array([r.soh_capacity for r in recs]),
            "capacity_fade": np.array([r.capacity_fade for r in recs]),
        }

    def to_frame(self):  # pragma: no cover - optional dependency
        """Return a Polars DataFrame when Polars is installed, else a dict."""
        from ..core.optional import try_import

        pl = try_import("polars")
        data = self.as_arrays()
        return pl.DataFrame({k: v.tolist() for k, v in data.items()}) if pl else data

    def summary(self) -> dict[str, float]:
        out, into = self.energy_wh()
        return {
            "records": float(len(self._records)),
            "mean_soc": self.mean_soc,
            "mean_temperature_c": self.mean_temperature_c,
            "mean_dod": self.mean_dod,
            "equivalent_full_cycles": self.equivalent_full_cycles,
            "energy_discharged_wh": out,
            "energy_charged_wh": into,
            "round_trip_efficiency": out / into if into > EPS else 0.0,
        }


__all__ = ["StateHistory", "HistoryRecord"]
