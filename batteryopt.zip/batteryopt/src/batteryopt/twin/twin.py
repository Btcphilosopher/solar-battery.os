"""The digital battery model (specification section 14).

.. code-block:: text

    PHYSICAL BATTERY
            |
        TELEMETRY
            |
    +-------v--------+
    |  DIGITAL TWIN  |   estimation -> state -> history
    +-------+--------+
            |
      FUTURE SCENARIOS

The twin owns the authoritative present state, the recent history and the
plant model used to project forward. Everything downstream -- scenario
generation, optimisation, MPC -- reads the twin rather than re-deriving state,
which is what keeps one consistent picture of the battery across the platform.

The twin never *acts*. It answers questions.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Sequence

from ..core.clock import Clock, WallClock
from ..core.provenance import Provenance
from ..estimation.base import Measurement
from ..estimation.pipeline import EstimationDiagnostics, StateEstimator
from ..models.battery import Battery
from ..models.degradation import LifeEstimate
from ..models.fidelity import Fidelity, build_plant
from ..models.plant import Action, BatteryPlant, Trajectory
from ..models.state import BatteryState
from ..models.surrogate import ResponseSurface, SurrogateCache
from .history import StateHistory


@dataclass(slots=True)
class TwinSnapshot:
    """A complete, serialisable picture of the battery at one instant."""

    state: BatteryState
    diagnostics: EstimationDiagnostics
    life: LifeEstimate | None
    history: dict[str, float]
    battery: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "state": self.state.as_dict(),
            "diagnostics": self.diagnostics.as_dict(),
            "life": self.life.as_dict() if self.life else None,
            "history": self.history,
            "battery": self.battery,
        }


class DigitalTwin:
    """Continuously updated model of one physical battery."""

    def __init__(
        self,
        battery: Battery,
        *,
        initial_soc: float = 0.5,
        initial_temperature_c: float = 25.0,
        fidelity: Fidelity | str = Fidelity.STANDARD,
        history_capacity: int = 20_000,
        clock: Clock | None = None,
        surrogate_cache: SurrogateCache | None = None,
    ) -> None:
        self.battery = battery
        self.clock = clock or WallClock()
        self.estimator = StateEstimator(
            battery,
            initial_soc=initial_soc,
            initial_temperature_c=initial_temperature_c,
        )
        self.history = StateHistory(capacity=history_capacity)
        self.fidelity = Fidelity(fidelity)
        self.plant: BatteryPlant = build_plant(battery, self.fidelity)
        self._surrogates = surrogate_cache or SurrogateCache()
        self._state = self.estimator.state
        self.history.append(self._state)

    # -- present ------------------------------------------------------------

    @property
    def state(self) -> BatteryState:
        """Authoritative present state (provenance ``ESTIMATED``)."""
        return self._state

    @property
    def diagnostics(self) -> EstimationDiagnostics:
        return self.estimator.diagnostics

    @property
    def surrogate(self) -> ResponseSurface:
        """Cached response surface for the present battery configuration."""
        return self._surrogates.get(self.battery)

    def ingest(self, measurement: Measurement, dt: float | None = None) -> BatteryState:
        """Consume one telemetry frame and advance the twin."""
        self._state = self.estimator.update(measurement, dt)
        self.history.append(self._state)
        return self._state

    def ingest_many(self, measurements: Sequence[Measurement]) -> BatteryState:
        for m in measurements:
            self.ingest(m)
        return self._state

    def set_state(self, state: BatteryState) -> None:
        """Force the twin's state. Used by simulation harnesses and tests."""
        self._state = state
        self.history.append(state)

    # -- future -------------------------------------------------------------

    def predict(
        self,
        actions: Sequence[Action],
        dts: Sequence[float] | float,
        *,
        ambient_c: Sequence[float] | float | None = None,
    ) -> Trajectory:
        """Roll the twin forward under a proposed action sequence.

        The returned trajectory is tagged ``SIMULATED`` throughout. It is a
        prediction of what would happen, never a record of what did.
        """
        return self.plant.simulate(
            self._state.as_simulated(),
            actions,
            dts,
            ambient_c=ambient_c,
            dod_hint=self.history.mean_dod or None,
        )

    def project_life(self, *, horizon_years: float = 25.0) -> LifeEstimate:
        """Remaining-useful-life projection at the recently observed duty cycle."""
        return self.battery.degradation.remaining_useful_life(
            self._state.degradation,
            soc=self.history.mean_soc,
            temperature_c=self.history.mean_temperature_c,
            mean_current_a=self.history.mean_current_a(seconds=86400.0),
            nameplate_capacity_ah=self.battery.nameplate_capacity_ah,
            dod=self.history.mean_dod or None,
            horizon_years=horizon_years,
        )

    # -- reporting ----------------------------------------------------------

    def snapshot(self) -> TwinSnapshot:
        return TwinSnapshot(
            state=self._state,
            diagnostics=self.estimator.diagnostics,
            life=self.project_life(),
            history=self.history.summary(),
            battery=self.battery.describe(),
        )

    def refresh_battery(self) -> None:
        """Fold the estimated SOH back into the battery configuration.

        Called periodically (not every frame) so that the plant, the surrogate
        and the constraint set all age together with the physical battery
        instead of drifting apart from it.
        """
        diagnostics = self.estimator.diagnostics
        if diagnostics.capacity is None:
            return
        nameplate = self.battery.nameplate_capacity_ah
        fade = max(0.0, 1.0 - diagnostics.capacity.value / nameplate) if nameplate > 0 else 0.0
        growth = (
            diagnostics.resistance.value
            if diagnostics.resistance and diagnostics.resistance.valid
            else self.battery.degradation_state.resistance_growth
        )
        from dataclasses import replace as _replace

        self.battery.degradation_state = _replace(
            self.battery.degradation_state,
            capacity_fade=fade,
            resistance_growth=growth,
        )
        self.plant = build_plant(self.battery, self.fidelity)

    def describe(self) -> str:
        s = self._state
        return (
            f"twin[{self.battery.battery_id}] {s.summary()} "
            f"| provenance={s.default_provenance.value}"
        )

    def assert_not_measured(self) -> None:
        """Guard used by reporting code: the twin's SOC is never a measurement."""
        assert self._state.provenance_of("soc") is not Provenance.MEASURED


__all__ = ["DigitalTwin", "TwinSnapshot"]
