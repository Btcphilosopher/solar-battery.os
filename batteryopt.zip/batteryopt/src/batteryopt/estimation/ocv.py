"""Open-circuit-voltage inversion: exact at rest, silent otherwise.

Two conditions must both hold for an OCV reading to mean anything:

1. the pack has been at rest long enough for the diffusion overpotentials to
   decay -- typically several times the longest RC time constant;
2. the OCV curve has usable slope at the resulting voltage.

Condition 2 is what makes LFP hard. On the plateau, ``dOCV/dSOC`` is around
0.09 V per unit SOC at pack-cell level; with 10 mV of sensor noise that is a
one-sigma SOC uncertainty of over 10 %. The estimator reports that honestly
by propagating the slope into its variance, and marks itself invalid when the
slope is too flat to be informative, rather than handing the fusion layer a
confident number that happens to be meaningless.
"""

from __future__ import annotations

from typing import Any

from ..core.numerics import EPS
from ..models.electrical import EquivalentCircuitModel
from .base import Estimate, Measurement


class OCVEstimator:
    """SOC from terminal voltage, valid only at rest."""

    name = "ocv"

    __slots__ = (
        "ecm",
        "rest_current_a",
        "rest_seconds_required",
        "min_slope_v_per_soc",
        "_rest_time",
        "_last_estimate",
    )

    def __init__(
        self,
        ecm: EquivalentCircuitModel,
        *,
        rest_current_a: float = 1.0,
        rest_seconds_required: float | None = None,
        min_slope_v_per_soc: float = 0.05,
    ) -> None:
        self.ecm = ecm
        self.rest_current_a = rest_current_a
        #: Default to three times the longest diffusion time constant, which
        #: leaves under 5 % of the overpotential undecayed.
        taus = ecm.rc_time_constants
        self.rest_seconds_required = (
            rest_seconds_required if rest_seconds_required is not None
            else (3.0 * max(taus) if taus else 300.0)
        )
        self.min_slope_v_per_soc = min_slope_v_per_soc
        self._rest_time = 0.0
        self._last_estimate = Estimate.unavailable(self.name, "no reading yet")

    @property
    def rest_seconds(self) -> float:
        return self._rest_time

    def update(self, measurement: Measurement, dt: float) -> Estimate:
        if abs(measurement.current_a) <= self.rest_current_a:
            self._rest_time += max(dt, 0.0)
        else:
            self._rest_time = 0.0

        if self._rest_time < self.rest_seconds_required:
            self._last_estimate = Estimate.unavailable(
                self.name,
                f"pack not rested ({self._rest_time:.0f}s of "
                f"{self.rest_seconds_required:.0f}s required)",
            )
            return self._last_estimate

        n_series = self.ecm.topology.n_series
        v_cell = measurement.voltage_v / n_series
        curve = self.ecm.chemistry.ocv
        soc = curve.soc_at(v_cell)
        slope = curve.slope_at(soc)

        if abs(slope) < self.min_slope_v_per_soc:
            self._last_estimate = Estimate.unavailable(
                self.name,
                f"OCV slope {slope:.3f} V/SOC is below the informative threshold "
                f"{self.min_slope_v_per_soc:.3f}; voltage carries no SOC information here",
            )
            return self._last_estimate

        # Propagate voltage noise through the inverse curve.
        sigma_v_cell = measurement.voltage_sigma_v / max(n_series**0.5, 1.0)
        sigma_soc = sigma_v_cell / max(abs(slope), EPS)
        self._last_estimate = Estimate(
            value=soc,
            variance=max(sigma_soc**2, 1e-8),
            source=self.name,
            meta={"slope_v_per_soc": slope, "rest_seconds": self._rest_time},
        )
        return self._last_estimate

    def reset(self, **kwargs: Any) -> None:
        self._rest_time = 0.0
        self._last_estimate = Estimate.unavailable(self.name, "reset")


__all__ = ["OCVEstimator"]
