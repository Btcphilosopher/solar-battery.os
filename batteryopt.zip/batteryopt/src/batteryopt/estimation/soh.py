"""State-of-health estimation: capacity and internal resistance.

Two independent quantities, two independent methods, because they degrade for
different reasons and on different timescales.

**Capacity** is estimated from the identity that closes every charge/discharge
segment:

.. code-block:: text

    Q = integral(I dt) / (soc_start - soc_end)

The trick is knowing ``soc_start`` and ``soc_end`` well enough for the
denominator to mean anything. The estimator therefore only accepts a segment
when both endpoints carry low SOC variance (typically an OCV fix at rest) and
the SOC swing is large enough that the ratio is well conditioned. Accepted
segments feed a recursive least-squares filter with a forgetting factor, so
capacity tracks slow fade without being whipped around by one noisy segment.

Two guards stop a single early segment from capturing the estimate, which is
the classic way this method fails in the field:

* a **warm-up period** during which no segment is opened, because a filter
  that is still converging reports a small covariance while carrying a large
  error, and a segment anchored on that error is worse than no segment at all;
* a **floor on the per-segment observation variance**, so that no single
  segment can claim better than a few percent accuracy however confident the
  endpoint SOC estimates were. Capacity is inferred from a ratio of two
  uncertain quantities; treating one measurement of it as near-exact is not
  supportable.

**Resistance** is estimated from current steps: a step of ``dI`` produces an
immediate voltage step of ``-dI * R0`` before diffusion has time to respond.
Sampling within a fraction of the shortest RC time constant isolates ``R0``
cleanly. Estimates are normalised to a reference temperature through the
chemistry's Arrhenius term before being filtered, otherwise a cold morning
looks exactly like a decade of ageing.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ..core.numerics import EPS
from ..core.units import SECONDS_PER_HOUR
from ..models.chemistry import ChemistryParameters
from .base import Estimate, Measurement


@dataclass(slots=True)
class _Segment:
    """An accumulating charge-integration segment between two SOC fixes."""

    soc_start: float
    soc_start_variance: float
    charge_ah: float = 0.0
    duration_s: float = 0.0


class CapacityEstimator:
    """Recursive least-squares capacity estimation from anchored segments."""

    name = "capacity"

    __slots__ = (
        "nameplate_ah",
        "_capacity",
        "_variance",
        "forgetting",
        "min_swing",
        "max_endpoint_variance",
        "_segment",
        "_accepted",
        "_rejected",
        "coulombic_efficiency",
        "warmup_s",
        "min_observation_sigma_fraction",
        "_elapsed",
    )

    def __init__(
        self,
        *,
        nameplate_ah: float,
        initial_capacity_ah: float | None = None,
        initial_variance: float | None = None,
        forgetting: float = 0.97,
        min_swing: float = 0.25,
        max_endpoint_variance: float = 4e-4,
        coulombic_efficiency: float = 0.995,
        warmup_s: float = 1800.0,
        min_observation_sigma_fraction: float = 0.03,
    ) -> None:
        self.nameplate_ah = nameplate_ah
        self._capacity = initial_capacity_ah if initial_capacity_ah is not None else nameplate_ah
        self._variance = (
            initial_variance if initial_variance is not None else (0.05 * nameplate_ah) ** 2
        )
        self.forgetting = forgetting
        #: Minimum SOC swing before a segment is usable. Below about 25 % the
        #: endpoint uncertainty dominates and the estimate is noise.
        self.min_swing = min_swing
        #: Endpoint SOC variance above which a fix is not trusted to anchor a
        #: segment (4e-4 is a 2 % standard deviation).
        self.max_endpoint_variance = max_endpoint_variance
        self.coulombic_efficiency = coulombic_efficiency
        #: No segment is opened before this much data has been seen.
        self.warmup_s = warmup_s
        #: Floor on the per-segment observation standard deviation, as a
        #: fraction of nameplate capacity.
        self.min_observation_sigma_fraction = min_observation_sigma_fraction
        self._elapsed = 0.0
        self._segment: _Segment | None = None
        self._accepted = 0
        self._rejected = 0

    @property
    def capacity_ah(self) -> float:
        return self._capacity

    @property
    def soh(self) -> float:
        return self._capacity / self.nameplate_ah if self.nameplate_ah > EPS else 0.0

    @property
    def segments_accepted(self) -> int:
        return self._accepted

    @property
    def segments_rejected(self) -> int:
        return self._rejected

    def update(
        self, measurement: Measurement, dt: float, *, soc: float, soc_variance: float
    ) -> Estimate:
        """Integrate current and close a segment whenever a good fix arrives."""
        self._elapsed += dt
        ah = measurement.current_a * dt / SECONDS_PER_HOUR
        if measurement.current_a < 0.0:
            ah *= self.coulombic_efficiency

        good_fix = soc_variance <= self.max_endpoint_variance and self._elapsed >= self.warmup_s
        if self._segment is None:
            if good_fix:
                self._segment = _Segment(soc_start=soc, soc_start_variance=soc_variance)
            return self._estimate()

        self._segment.charge_ah += ah
        self._segment.duration_s += dt

        if good_fix:
            swing = self._segment.soc_start - soc
            if abs(swing) >= self.min_swing:
                observed = self._segment.charge_ah / swing
                if observed > 0.2 * self.nameplate_ah and observed < 1.5 * self.nameplate_ah:
                    # Variance of the ratio, first-order propagation.
                    var_swing = self._segment.soc_start_variance + soc_variance
                    floor = (self.min_observation_sigma_fraction * self.nameplate_ah) ** 2
                    obs_var = max((observed**2) * var_swing / max(swing**2, EPS), floor)
                    self._absorb(observed, obs_var)
                    self._accepted += 1
                else:
                    self._rejected += 1
                self._segment = _Segment(soc_start=soc, soc_start_variance=soc_variance)
            elif abs(swing) < 0.02 and self._segment.duration_s > 3600.0:
                # Restart: the pack went nowhere for an hour, so the segment
                # will never accumulate a usable swing.
                self._segment = _Segment(soc_start=soc, soc_start_variance=soc_variance)
        return self._estimate()

    def _absorb(self, observed_ah: float, observed_variance: float) -> None:
        """Kalman-style scalar update with an exponential forgetting factor."""
        prior_var = self._variance / max(self.forgetting, EPS)
        gain = prior_var / max(prior_var + observed_variance, EPS)
        self._capacity += gain * (observed_ah - self._capacity)
        self._variance = max((1.0 - gain) * prior_var, 1e-6)

    def _estimate(self) -> Estimate:
        return Estimate(
            value=self._capacity,
            variance=self._variance,
            source=self.name,
            meta={
                "soh": self.soh,
                "segments_accepted": self._accepted,
                "segments_rejected": self._rejected,
                "segment_open": self._segment is not None,
            },
        )

    def reset(self, **kwargs: Any) -> None:
        self._capacity = float(kwargs.get("capacity_ah", self.nameplate_ah))
        self._variance = float(kwargs.get("variance", (0.05 * self.nameplate_ah) ** 2))
        self._segment = None
        self._accepted = 0
        self._rejected = 0
        self._elapsed = 0.0


class ResistanceEstimator:
    """Series-resistance estimation from current steps, temperature-normalised."""

    name = "resistance"

    __slots__ = (
        "chemistry",
        "n_series",
        "reference_ohm",
        "_growth",
        "_variance",
        "forgetting",
        "min_step_a",
        "_prev",
        "_samples",
    )

    def __init__(
        self,
        chemistry: ChemistryParameters,
        *,
        reference_ohm: float,
        n_series: int = 1,
        initial_growth: float = 0.0,
        initial_variance: float = 0.04,
        forgetting: float = 0.99,
        min_step_a: float = 5.0,
    ) -> None:
        self.chemistry = chemistry
        self.n_series = n_series
        #: System resistance at reference temperature and beginning of life.
        self.reference_ohm = reference_ohm
        self._growth = initial_growth
        self._variance = initial_variance
        self.forgetting = forgetting
        #: Minimum current step worth using. Small steps have a poor
        #: signal-to-noise ratio and bias the estimate towards sensor noise.
        self.min_step_a = min_step_a
        self._prev: tuple[float, float, float] | None = None  # (v, i, t)
        self._samples = 0

    @property
    def resistance_growth(self) -> float:
        """Fractional increase over beginning-of-life resistance."""
        return self._growth

    @property
    def samples(self) -> int:
        return self._samples

    def update(self, measurement: Measurement, dt: float) -> Estimate:
        v, i, temp = measurement.voltage_v, measurement.current_a, measurement.temperature_c
        prev = self._prev
        self._prev = (v, i, temp)
        if prev is None:
            return self._estimate()

        v0, i0, temp0 = prev
        di = i - i0
        if abs(di) < self.min_step_a:
            return self._estimate()
        # Only the sample immediately after the step isolates R0; later samples
        # include diffusion. dt must be short relative to the fastest RC branch.
        taus = self.chemistry.resistance.rc_pairs
        fastest_tau = min((tau for _, tau in taus), default=30.0)
        if dt > 0.25 * fastest_tau:
            return self._estimate()

        observed = -(v - v0) / di
        if observed <= 0.0:
            return self._estimate()

        # Normalise out temperature before comparing against reference.
        t_mean = 0.5 * (temp + temp0)
        factor = float(self.chemistry.resistance.temperature_factor(t_mean))
        normalised = observed / max(factor, EPS)
        observed_growth = normalised / max(self.reference_ohm, EPS) - 1.0

        sigma_v = measurement.voltage_sigma_v * (2.0**0.5)
        obs_var = max((sigma_v / (abs(di) * max(self.reference_ohm, EPS))) ** 2, 1e-4)
        prior_var = self._variance / max(self.forgetting, EPS)
        gain = prior_var / max(prior_var + obs_var, EPS)
        self._growth += gain * (observed_growth - self._growth)
        self._growth = max(self._growth, -0.5)
        self._variance = max((1.0 - gain) * prior_var, 1e-6)
        self._samples += 1
        return self._estimate()

    def _estimate(self) -> Estimate:
        return Estimate(
            value=self._growth,
            variance=self._variance,
            valid=self._samples > 0,
            source=self.name,
            reason=None if self._samples else "no usable current steps observed yet",
            meta={"samples": self._samples, "reference_ohm": self.reference_ohm},
        )

    def reset(self, **kwargs: Any) -> None:
        self._growth = float(kwargs.get("growth", 0.0))
        self._variance = float(kwargs.get("variance", 0.04))
        self._prev = None
        self._samples = 0


__all__ = ["CapacityEstimator", "ResistanceEstimator"]
