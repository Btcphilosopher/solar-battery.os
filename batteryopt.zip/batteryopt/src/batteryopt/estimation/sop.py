"""State of power: how much the battery can actually do, and what stops it.

"Maximum power" is meaningless without a duration. A pack that can deliver
250 kW for ten seconds may only sustain 90 kW for ten minutes, because the
diffusion overpotential keeps growing and the cells keep heating. The SOP
estimator therefore takes an explicit horizon and returns the power that can
be held for *that* horizon, together with the constraint that binds -- which
is the single most useful diagnostic the whole engine produces, because it
tells an operator what to fix.

Five limits are evaluated and the tightest wins:

============  =========================================================
Limit         How it is computed
============  =========================================================
voltage       Bisection on the end-of-horizon terminal voltage, which
              includes RC relaxation and the SOC moved during the
              horizon. This is what makes the answer duration-dependent.
current       Continuous C-rate for long horizons, pulse rating for
              horizons within the pulse window.
state of      Charge available above ``soc_min`` (or headroom below
charge        ``soc_max``) divided by the horizon.
temperature   Largest heat generation whose exponential temperature
              trajectory stays below the limit for the whole horizon.
system        Inverter, contactor or grid-connection power ceiling.
============  =========================================================

The result is used directly by the optimiser as a bound, and by the dashboard
as the "limiting constraint" line.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from ..core.numerics import EPS, clamp
from ..core.provenance import Provenance, Quantity
from ..core.units import SECONDS_PER_HOUR
from ..models.battery import Battery
from ..models.state import BatteryState


@dataclass(frozen=True, slots=True)
class PowerCapability:
    """Power capability over a stated horizon, with the binding constraint."""

    horizon_s: float
    #: Maximum sustainable discharge power, W (positive).
    discharge_w: float
    #: Maximum sustainable charge power magnitude, W (positive).
    charge_w: float
    discharge_limiting: str
    charge_limiting: str
    #: All evaluated limits, for explanation. Keys are constraint names.
    discharge_limits_w: dict[str, float]
    charge_limits_w: dict[str, float]
    #: Energy that can be delivered over the horizon at ``discharge_w``, Wh.
    discharge_energy_wh: float
    charge_energy_wh: float

    def as_quantities(self) -> dict[str, Quantity]:
        return {
            "power_limit_discharge_w": Quantity(
                self.discharge_w, "W", Provenance.ESTIMATED, source="sop"
            ),
            "power_limit_charge_w": Quantity(
                -self.charge_w, "W", Provenance.ESTIMATED, source="sop"
            ),
        }

    def as_dict(self) -> dict[str, object]:
        return {
            "horizon_s": self.horizon_s,
            "discharge_w": self.discharge_w,
            "charge_w": self.charge_w,
            "discharge_limiting": self.discharge_limiting,
            "charge_limiting": self.charge_limiting,
            "discharge_limits_w": self.discharge_limits_w,
            "charge_limits_w": self.charge_limits_w,
            "discharge_energy_wh": self.discharge_energy_wh,
            "charge_energy_wh": self.charge_energy_wh,
        }


class PowerCapabilityEstimator:
    """Horizon-aware SOP estimator."""

    name = "sop"

    __slots__ = ("battery",)

    def __init__(self, battery: Battery) -> None:
        self.battery = battery

    # -- helpers ------------------------------------------------------------

    def _voltage_limited_current(
        self, state: BatteryState, horizon_s: float, *, charging: bool
    ) -> float:
        """Current magnitude at which the voltage limit is hit at horizon end.

        Bisection on a monotone function: raising the discharge current lowers
        the end-of-horizon voltage, both directly through IR and indirectly by
        emptying the pack. Bisection cannot diverge, which matters because this
        runs inside the optimiser's inner bound computation.
        """
        battery = self.battery
        ecm = battery.electrical
        growth = state.degradation.resistance_growth
        capacity_ah = max(battery.nameplate_capacity_ah * state.soh_capacity, EPS)
        limit_v = battery.minimum_voltage if not charging else battery.maximum_voltage

        rc_r = ecm.rc_resistances(growth)
        taus = ecm.rc_time_constants
        decay = [math.exp(-horizon_s / max(t, EPS)) for t in taus]

        def end_voltage(magnitude: float) -> float:
            i = magnitude if not charging else -magnitude
            d_soc = ecm.soc_delta(i, horizon_s, capacity_ah=capacity_ah)
            soc_end = clamp(state.soc + d_soc, 0.0, 1.0)
            hyst = ecm.step_hysteresis(
                state.hysteresis, i, horizon_s, capacity_ah=capacity_ah
            )
            ocv = float(ecm.ocv(soc_end, hysteresis=hyst))
            r0 = ecm.resistance(
                soc=soc_end,
                temperature_c=state.temperature_c,
                resistance_growth=growth,
                charging=charging,
            )
            v_rc = 0.0
            existing = state.rc_voltages if state.rc_voltages else (0.0,) * len(rc_r)
            for v0, r, d in zip(existing, rc_r, decay):
                v_rc += v0 * d + i * r * (1.0 - d)
            return ocv - i * r0 - v_rc

        hi = 20.0 * max(battery.maximum_current, battery.maximum_charge_current)
        if charging:
            if end_voltage(0.0) >= limit_v:
                return 0.0
            if end_voltage(hi) <= limit_v:
                return hi
        else:
            if end_voltage(0.0) <= limit_v:
                return 0.0
            if end_voltage(hi) >= limit_v:
                return hi

        lo, high = 0.0, hi
        for _ in range(60):
            mid = 0.5 * (lo + high)
            v = end_voltage(mid)
            over = (v < limit_v) if not charging else (v > limit_v)
            if over:
                high = mid
            else:
                lo = mid
        return 0.5 * (lo + high)

    def _thermal_limited_power(
        self, state: BatteryState, horizon_s: float, *, charging: bool
    ) -> float:
        """Power whose heat keeps the pack under its temperature limit.

        Solves for the heat generation whose exponential trajectory just
        touches the limit at the end of the horizon, then converts that heat
        into a power through ``P ~ V * sqrt(Q / R)``.
        """
        battery = self.battery
        thermal = battery.thermal
        limits = battery.thermal_limits
        limit_c = limits.t_max_charge_c if charging else limits.t_max_c
        if state.temperature_c >= limit_c:
            return 0.0

        # Full cooling is assumed available; the thermal optimiser decides
        # whether to actually use it, but SOP reports what is achievable.
        k = thermal.conductance(1.0)
        sink = state.coolant_c
        tau = thermal.heat_capacity_j_k / max(k, EPS)
        decay = math.exp(-horizon_s / max(tau, EPS))
        # T_end = sink + Q/k + (T0 - sink - Q/k) * decay  <=  limit
        denom = (1.0 - decay) / max(k, EPS)
        if denom <= EPS:
            return math.inf
        q_max = (limit_c - sink - (state.temperature_c - sink) * decay) / denom
        if q_max <= 0.0:
            return 0.0

        r0 = battery.electrical.resistance(
            soc=state.soc,
            temperature_c=state.temperature_c,
            resistance_growth=state.degradation.resistance_growth,
            charging=charging,
        )
        if r0 <= EPS:
            return math.inf
        current = math.sqrt(max(q_max, 0.0) / r0)
        v = float(battery.electrical.ocv(state.soc, hysteresis=state.hysteresis))
        # Terminal power is not monotone in current: past the matched-impedance
        # point (I = OCV / 2R) more current delivers *less* power, and beyond
        # I = OCV / R the terminal voltage collapses to zero. A thermal budget
        # that permits more current than that does not constrain power at all,
        # so cap at the electrical maximum instead of reporting a spurious zero.
        current = min(current, v / (2.0 * r0))
        return max(0.0, (v - current * r0) * current)

    # -- main entry point ---------------------------------------------------

    def estimate(
        self,
        state: BatteryState,
        *,
        horizon_s: float = 10.0,
        soc_min: float | None = None,
        soc_max: float | None = None,
    ) -> PowerCapability:
        """Compute the power capability over ``horizon_s`` seconds."""
        battery = self.battery
        envelope = battery.envelope
        ecm = battery.electrical
        capacity_ah = max(battery.nameplate_capacity_ah * state.soh_capacity, EPS)
        soc_lo = envelope.soc_min if soc_min is None else soc_min
        soc_hi = envelope.soc_max if soc_max is None else soc_max
        hours = horizon_s / SECONDS_PER_HOUR

        pulse_window = envelope.pulse_duration_s
        use_pulse = horizon_s <= pulse_window

        def limits_for(charging: bool) -> tuple[dict[str, float], float, str]:
            # --- current rating --------------------------------------------
            if charging:
                i_rating = (
                    battery.pulse_charge_current if use_pulse else battery.maximum_charge_current
                )
            else:
                i_rating = (
                    battery.pulse_discharge_current if use_pulse else battery.maximum_current
                )

            # --- state of charge --------------------------------------------
            if charging:
                headroom_ah = max(0.0, soc_hi - state.soc) * capacity_ah
            else:
                headroom_ah = max(0.0, state.soc - soc_lo) * capacity_ah
            i_soc = headroom_ah / hours if hours > EPS else math.inf

            # --- voltage ------------------------------------------------------
            i_voltage = self._voltage_limited_current(state, horizon_s, charging=charging)

            # --- convert currents to powers ------------------------------------
            def power_of(magnitude: float) -> float:
                i = -magnitude if charging else magnitude
                resp = ecm.evaluate(
                    soc=state.soc,
                    current_a=i,
                    temperature_c=state.temperature_c,
                    rc_voltages=state.rc_voltages,
                    resistance_growth=state.degradation.resistance_growth,
                    hysteresis=state.hysteresis,
                )
                return abs(resp.power_w)

            candidates: dict[str, float] = {
                "current_rating": power_of(min(i_rating, 1e9)),
                "state_of_charge": power_of(min(i_soc, 1e9)) if math.isfinite(i_soc) else math.inf,
                "voltage": power_of(i_voltage),
                "temperature": self._thermal_limited_power(
                    state, horizon_s, charging=charging
                ),
            }

            # --- temperature gate: charging may be forbidden outright ---------
            limits = battery.thermal_limits
            if charging and state.temperature_c < limits.t_min_charge_c:
                candidates["temperature_charge_inhibit"] = 0.0
            if not charging and state.temperature_c < limits.t_min_c:
                candidates["temperature_below_minimum"] = 0.0
            if state.temperature_c >= limits.t_max_c:
                candidates["temperature_over_maximum"] = 0.0

            # --- system-level power ceiling ------------------------------------
            ceiling = battery.max_charge_power_w if charging else battery.max_discharge_power_w
            if ceiling is not None:
                candidates["system_power_rating"] = abs(ceiling)

            binding = min(candidates, key=lambda k: candidates[k])
            return candidates, max(0.0, candidates[binding]), binding

        dis_limits, dis_power, dis_binding = limits_for(charging=False)
        chg_limits, chg_power, chg_binding = limits_for(charging=True)

        return PowerCapability(
            horizon_s=horizon_s,
            discharge_w=dis_power,
            charge_w=chg_power,
            discharge_limiting=dis_binding,
            charge_limiting=chg_binding,
            discharge_limits_w={k: float(v) for k, v in dis_limits.items()},
            charge_limits_w={k: float(v) for k, v in chg_limits.items()},
            discharge_energy_wh=dis_power * hours,
            charge_energy_wh=chg_power * hours,
        )

    def energy_capability_wh(
        self, state: BatteryState, *, soc_min: float | None = None
    ) -> float:
        """Energy deliverable down to the configured floor, Wh."""
        floor = self.battery.envelope.soc_min if soc_min is None else soc_min
        return self.battery.energy_between(floor, state.soc)


__all__ = ["PowerCapabilityEstimator", "PowerCapability"]
