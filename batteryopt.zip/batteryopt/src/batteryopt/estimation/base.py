"""Estimator interfaces and the measurement record they consume.

Specification section 2 requires that multiple state-estimation methods can
coexist. That is not a nicety: coulomb counting is unbiased over minutes but
drifts over hours; OCV inversion is exact at rest but useless under load and
near-useless mid-plateau on LFP; a Kalman filter is good at both but only if
its model is right. Running them together and fusing by variance is how a
production system stays honest.

Every estimator therefore:

* consumes a :class:`Measurement` (raw, provenance ``MEASURED``),
* produces an :class:`Estimate` carrying a value, a variance and a validity
  flag, tagged ``ESTIMATED``,
* declares when it is *not* applicable rather than returning a confident wrong
  answer (``valid=False``).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

from ..core.provenance import Provenance, Quantity


@dataclass(frozen=True, slots=True)
class Measurement:
    """One synchronised set of sensor readings.

    All fields are what the sensors actually reported, before any inference.
    Optional fields are ``None`` when the corresponding sensor is absent,
    which is the normal case for cell-level data on a large pack.
    """

    timestamp: float
    voltage_v: float
    current_a: float
    temperature_c: float
    ambient_c: float | None = None
    coolant_c: float | None = None
    #: Per-cell voltages, when the BMS exposes them.
    cell_voltages_v: tuple[float, ...] = ()
    #: Per-module temperatures, when available.
    module_temperatures_c: tuple[float, ...] = ()
    #: Charge counter reported by the BMS, if it has one, in Ah.
    reported_charge_ah: float | None = None
    #: SOC reported by the BMS, if it has one, 0-1. Treated as an input to
    #: fusion, never as ground truth.
    reported_soc: float | None = None
    #: Sensor noise characteristics, if the hardware declares them.
    voltage_sigma_v: float = 0.01
    current_sigma_a: float = 0.5
    temperature_sigma_c: float = 0.5
    meta: dict[str, Any] = field(default_factory=dict)

    @property
    def cell_imbalance_v(self) -> float:
        """Max-minus-min cell voltage; 0.0 when cell data is unavailable."""
        if len(self.cell_voltages_v) < 2:
            return 0.0
        return max(self.cell_voltages_v) - min(self.cell_voltages_v)

    @property
    def temperature_spread_c(self) -> float:
        if len(self.module_temperatures_c) < 2:
            return 0.0
        return max(self.module_temperatures_c) - min(self.module_temperatures_c)

    def quantities(self) -> dict[str, Quantity]:
        return {
            "voltage_v": Quantity(
                self.voltage_v, "V", Provenance.MEASURED,
                stddev=self.voltage_sigma_v, timestamp=self.timestamp,
            ),
            "current_a": Quantity(
                self.current_a, "A", Provenance.MEASURED,
                stddev=self.current_sigma_a, timestamp=self.timestamp,
            ),
            "temperature_c": Quantity(
                self.temperature_c, "degC", Provenance.MEASURED,
                stddev=self.temperature_sigma_c, timestamp=self.timestamp,
            ),
        }


@dataclass(frozen=True, slots=True)
class Estimate:
    """One estimator's opinion about one scalar."""

    value: float
    variance: float
    valid: bool = True
    source: str = ""
    #: Why the estimator considers itself inapplicable, when ``valid`` is False.
    reason: str | None = None
    meta: dict[str, Any] = field(default_factory=dict)

    @property
    def stddev(self) -> float:
        return self.variance**0.5 if self.variance > 0 else 0.0

    @property
    def precision(self) -> float:
        """Inverse variance -- the natural fusion weight."""
        return 1.0 / self.variance if self.variance > 1e-15 else 0.0

    def as_quantity(self, unit: str, *, timestamp: float | None = None) -> Quantity:
        return Quantity(
            value=self.value,
            unit=unit,
            provenance=Provenance.ESTIMATED,
            stddev=self.stddev,
            source=self.source or None,
            timestamp=timestamp,
        )

    @classmethod
    def unavailable(cls, source: str, reason: str) -> "Estimate":
        return cls(value=float("nan"), variance=float("inf"), valid=False,
                   source=source, reason=reason)


@runtime_checkable
class Estimator(Protocol):
    """A component that maintains a running estimate of one quantity."""

    name: str

    def update(self, measurement: Measurement, dt: float) -> Estimate:
        """Ingest a measurement and return the current estimate."""
        ...

    def reset(self, **kwargs: Any) -> None:
        """Reinitialise internal state."""
        ...


__all__ = ["Measurement", "Estimate", "Estimator"]
