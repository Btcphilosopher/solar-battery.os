"""Fusion of competing estimates.

Running several estimators is only useful if their disagreement is handled
properly. Two failure modes have to be avoided:

* **Naive averaging**, which lets a broken estimator drag the answer.
* **Blind inverse-variance weighting**, which does the same thing whenever an
  estimator is confidently wrong -- and a confidently wrong estimator is
  exactly what a stale OCV fix or a mis-scaled coulomb counter looks like.

The fusion here therefore gates before it weights. Each candidate is tested
against the incumbent consensus with a chi-square (Mahalanobis) test; anything
beyond the gate is excluded from the fused value and reported as an outlier,
so the disagreement surfaces instead of being averaged away.

Where estimators genuinely disagree within the gate, the fused variance is
inflated by the spread between them. Two estimators that each claim 1 % but
sit 5 % apart cannot both be right, and the fused answer should not claim
0.7 %.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable, Mapping, Sequence

import numpy as np

from ..core.numerics import EPS
from .base import Estimate


@dataclass(frozen=True, slots=True)
class FusionResult:
    """A fused estimate plus the audit trail of how it was reached."""

    value: float
    variance: float
    #: Contributions actually used, keyed by estimator name, with weights.
    weights: Mapping[str, float] = field(default_factory=dict)
    #: Estimators excluded by the consistency gate, with their gate statistic.
    outliers: Mapping[str, float] = field(default_factory=dict)
    #: Estimators that declared themselves inapplicable, with their reasons.
    unavailable: Mapping[str, str] = field(default_factory=dict)
    #: Spread-based variance inflation actually applied.
    disagreement_inflation: float = 1.0

    @property
    def stddev(self) -> float:
        return self.variance**0.5 if self.variance > 0 else 0.0

    @property
    def agreement(self) -> float:
        """0-1 measure of how well the contributors agreed."""
        return 1.0 / self.disagreement_inflation if self.disagreement_inflation > 0 else 0.0

    def as_dict(self) -> dict[str, object]:
        return {
            "value": self.value,
            "variance": self.variance,
            "stddev": self.stddev,
            "weights": dict(self.weights),
            "outliers": dict(self.outliers),
            "unavailable": dict(self.unavailable),
            "agreement": self.agreement,
        }


def fuse(
    estimates: Iterable[Estimate],
    *,
    gate_sigma: float = 4.0,
    inflate_on_disagreement: bool = True,
    priority: Sequence[str] = (),
) -> FusionResult:
    """Gate, then inverse-variance weight, then inflate for disagreement.

    ``priority`` names estimators trusted to define the consensus for gating
    purposes -- typically the Kalman filter, which is the only estimator with
    a principled covariance. If none of them are available the highest-precision
    valid estimate is used as the reference instead.
    """
    valid: list[Estimate] = []
    unavailable: dict[str, str] = {}
    for est in estimates:
        if est.valid and np.isfinite(est.value) and np.isfinite(est.variance):
            valid.append(est)
        else:
            unavailable[est.source or "unnamed"] = est.reason or "invalid"

    if not valid:
        return FusionResult(
            value=float("nan"), variance=float("inf"), unavailable=unavailable
        )
    if len(valid) == 1:
        only = valid[0]
        return FusionResult(
            value=only.value,
            variance=only.variance,
            weights={only.source or "unnamed": 1.0},
            unavailable=unavailable,
        )

    # --- reference for the consistency gate --------------------------------
    reference = None
    for name in priority:
        for est in valid:
            if est.source == name:
                reference = est
                break
        if reference is not None:
            break
    if reference is None:
        reference = max(valid, key=lambda e: e.precision)

    accepted: list[Estimate] = []
    outliers: dict[str, float] = {}
    for est in valid:
        if est is reference:
            accepted.append(est)
            continue
        combined_var = est.variance + reference.variance
        distance = abs(est.value - reference.value) / max(combined_var**0.5, EPS)
        if distance > gate_sigma:
            outliers[est.source or "unnamed"] = float(distance)
        else:
            accepted.append(est)

    if not accepted:  # pragma: no cover - reference is always accepted
        accepted = [reference]

    precisions = np.array([e.precision for e in accepted], dtype=float)
    total = float(precisions.sum())
    if total <= EPS:
        value = float(np.mean([e.value for e in accepted]))
        variance = float(np.mean([e.variance for e in accepted]))
        weights = {e.source or f"e{k}": 1.0 / len(accepted) for k, e in enumerate(accepted)}
        return FusionResult(value, variance, weights, outliers, unavailable)

    weights_arr = precisions / total
    values = np.array([e.value for e in accepted], dtype=float)
    value = float(np.dot(weights_arr, values))
    variance = 1.0 / total

    inflation = 1.0
    if inflate_on_disagreement and len(accepted) > 1:
        spread = float(np.dot(weights_arr, (values - value) ** 2))
        if spread > variance:
            inflation = spread / max(variance, EPS)
            variance = spread

    return FusionResult(
        value=value,
        variance=variance,
        weights={
            (e.source or f"e{k}"): float(w) for k, (e, w) in enumerate(zip(accepted, weights_arr))
        },
        outliers=outliers,
        unavailable=unavailable,
        disagreement_inflation=inflation,
    )


__all__ = ["fuse", "FusionResult"]
