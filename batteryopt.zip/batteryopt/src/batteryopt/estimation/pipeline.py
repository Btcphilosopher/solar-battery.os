"""The state-estimation pipeline.

Assembles the individual estimators into the stage of the architecture that
turns telemetry into a :class:`~batteryopt.models.state.BatteryState`:

.. code-block:: text

    TELEMETRY -> VALIDATION -> [coulomb | OCV | EKF] -> FUSION -> SOH -> SOP
                                                                      -> STATE

Design decisions worth stating:

* **The EKF is the reference, not the answer.** Its SOC goes into fusion
  alongside coulomb counting and OCV inversion, and the fused result is fed
  back to re-anchor the coulomb counter. That keeps a single filter divergence
  from becoming a silent, permanent error.
* **SOH updates are slow and feed back.** A revised capacity is pushed into
  the coulomb counter and the EKF, because both integrate against it; a
  revised resistance is pushed into the EKF's voltage model. Without that
  feedback an ageing pack develops a persistent innovation bias.
* **Provenance is per field.** Voltage, current and temperature come out
  ``MEASURED``; SOC, SOH and capability come out ``ESTIMATED``. Nothing in the
  pipeline can produce a state that claims to have measured its own SOC.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ..core.numerics import clamp
from ..core.provenance import Provenance
from ..models.battery import Battery
from ..models.state import BatteryState
from .base import Estimate, Measurement
from .coulomb import CoulombCounter
from .ekf import ExtendedKalmanSOC
from .fusion import FusionResult, fuse
from .imbalance import ImbalanceEstimator, ImbalanceReport
from .ocv import OCVEstimator
from .soh import CapacityEstimator, ResistanceEstimator
from .sop import PowerCapability, PowerCapabilityEstimator


@dataclass(slots=True)
class EstimationDiagnostics:
    """Everything the pipeline learned, for logging and the dashboard."""

    soc_fusion: FusionResult | None = None
    soc_estimates: dict[str, Estimate] = field(default_factory=dict)
    capacity: Estimate | None = None
    resistance: Estimate | None = None
    imbalance: ImbalanceReport | None = None
    capability: PowerCapability | None = None
    ekf_consistency: float = 1.0
    frames: int = 0

    def as_dict(self) -> dict[str, Any]:
        return {
            "soc_fusion": self.soc_fusion.as_dict() if self.soc_fusion else None,
            "soc_estimates": {
                k: {"value": v.value, "stddev": v.stddev, "valid": v.valid, "reason": v.reason}
                for k, v in self.soc_estimates.items()
            },
            "capacity_ah": self.capacity.value if self.capacity else None,
            "resistance_growth": self.resistance.value if self.resistance else None,
            "imbalance": self.imbalance.as_dict() if self.imbalance else None,
            "capability": self.capability.as_dict() if self.capability else None,
            "ekf_consistency": self.ekf_consistency,
            "frames": self.frames,
        }


class StateEstimator:
    """Runs every estimator, fuses them and emits a battery state."""

    def __init__(
        self,
        battery: Battery,
        *,
        initial_soc: float = 0.5,
        initial_temperature_c: float = 25.0,
        sop_horizon_s: float = 10.0,
        soh_update_interval_s: float = 60.0,
        enable_imbalance: bool = True,
    ) -> None:
        self.battery = battery
        self.sop_horizon_s = sop_horizon_s
        self.soh_update_interval_s = soh_update_interval_s

        capacity = battery.capacity
        self.coulomb = CoulombCounter(
            capacity_ah=capacity,
            initial_soc=initial_soc,
            coulombic_efficiency=battery.envelope.coulombic_efficiency,
        )
        self.ocv = OCVEstimator(battery.electrical)
        self.ekf = ExtendedKalmanSOC(
            battery.electrical,
            capacity_ah=capacity,
            initial_soc=initial_soc,
            resistance_growth=battery.degradation_state.resistance_growth,
        )
        self.capacity_estimator = CapacityEstimator(
            nameplate_ah=battery.nameplate_capacity_ah,
            initial_capacity_ah=capacity,
            coulombic_efficiency=battery.envelope.coulombic_efficiency,
        )
        self.resistance_estimator = ResistanceEstimator(
            battery.chemistry,
            reference_ohm=battery.electrical.resistance(
                soc=0.5, temperature_c=battery.chemistry.resistance.t_ref_c
            ),
            n_series=battery.topology.n_series,
            initial_growth=battery.degradation_state.resistance_growth,
        )
        self.imbalance = (
            ImbalanceEstimator(
                battery.chemistry,
                cell_capacity_ah=battery.topology.cell.effective_capacity_ah,
            )
            if enable_imbalance
            else None
        )
        self.sop = PowerCapabilityEstimator(battery)

        self._state = battery.initial_state(
            soc=initial_soc,
            temperature_c=initial_temperature_c,
            provenance=Provenance.ESTIMATED,
        )
        self._diagnostics = EstimationDiagnostics()
        self._last_timestamp: float | None = None
        self._since_soh_update = 0.0

    # -- accessors ----------------------------------------------------------

    @property
    def state(self) -> BatteryState:
        return self._state

    @property
    def diagnostics(self) -> EstimationDiagnostics:
        return self._diagnostics

    # -- main entry point ---------------------------------------------------

    def update(self, measurement: Measurement, dt: float | None = None) -> BatteryState:
        """Ingest one telemetry frame and return the updated state."""
        if dt is None:
            dt = (
                measurement.timestamp - self._last_timestamp
                if self._last_timestamp is not None
                else 1.0
            )
        dt = max(float(dt), 0.0)
        self._last_timestamp = measurement.timestamp

        # --- SOC: three opinions, gated and fused -------------------------
        e_coulomb = self.coulomb.update(measurement, dt)
        e_ocv = self.ocv.update(measurement, dt)
        e_ekf = self.ekf.update(measurement, dt)
        fusion = fuse(
            [e_ekf, e_coulomb, e_ocv],
            priority=("ekf",),
        )
        soc = clamp(fusion.value, 0.0, 1.0)

        # Re-anchor the drifting integrator on the fused consensus, but only
        # when the consensus is materially better than the integrator itself.
        if fusion.variance < 0.5 * e_coulomb.variance:
            self.coulomb.anchor(soc, fusion.variance, timestamp=measurement.timestamp)
        # A rested OCV fix is the only thing entitled to correct the filter.
        if e_ocv.valid and e_ocv.variance < 4e-4:
            self.ekf.anchor(e_ocv.value, e_ocv.variance)

        # --- SOH: slow loop, with feedback into the fast estimators --------
        self._since_soh_update += dt
        e_capacity = self.capacity_estimator.update(
            measurement, dt, soc=soc, soc_variance=fusion.variance
        )
        e_resistance = self.resistance_estimator.update(measurement, dt)
        if self._since_soh_update >= self.soh_update_interval_s:
            self._since_soh_update = 0.0
            self.coulomb.set_capacity(e_capacity.value)
            self.ekf.set_capacity(e_capacity.value)
            if e_resistance.valid:
                self.ekf.set_resistance_growth(e_resistance.value)

        # --- imbalance ------------------------------------------------------
        imbalance_report = None
        if self.imbalance is not None and measurement.cell_voltages_v:
            self.imbalance.update(measurement, dt)
            imbalance_report = self.imbalance.report(measurement)

        # --- assemble the state ---------------------------------------------
        nameplate = self.battery.nameplate_capacity_ah
        soh = clamp(e_capacity.value / nameplate, 0.0, 1.5) if nameplate > 0 else 1.0
        growth = e_resistance.value if e_resistance.valid else (
            self.battery.degradation_state.resistance_growth
        )
        degradation = self.battery.degradation_state

        provisional = BatteryState(
            soc=soc,
            soh_capacity=soh,
            soh_resistance=1.0 + growth,
            capacity_ah=e_capacity.value,
            resistance_ohm=self.battery.electrical.resistance(
                soc=soc,
                temperature_c=measurement.temperature_c,
                resistance_growth=growth,
                charging=measurement.current_a < 0.0,
            ),
            voltage_v=measurement.voltage_v,
            current_a=measurement.current_a,
            power_w=measurement.voltage_v * measurement.current_a,
            rc_voltages=self.ekf.rc_voltages,
            hysteresis=self.ekf.hysteresis,
            temperature_c=measurement.temperature_c,
            temperature_max_c=(
                max(measurement.module_temperatures_c)
                if measurement.module_temperatures_c
                else measurement.temperature_c
            ),
            temperature_min_c=(
                min(measurement.module_temperatures_c)
                if measurement.module_temperatures_c
                else measurement.temperature_c
            ),
            ambient_c=(
                measurement.ambient_c
                if measurement.ambient_c is not None
                else self._state.ambient_c
            ),
            coolant_c=(
                measurement.coolant_c
                if measurement.coolant_c is not None
                else self._state.coolant_c
            ),
            cell_imbalance_v=measurement.cell_imbalance_v,
            cell_capacity_spread=(
                imbalance_report.soc_spread if imbalance_report is not None else 0.0
            ),
            energy_remaining_wh=self.battery.energy_between(0.0, soc),
            degradation=degradation,
            timestamp=measurement.timestamp,
            default_provenance=Provenance.ESTIMATED,
        ).with_provenance(
            voltage_v=Provenance.MEASURED,
            current_a=Provenance.MEASURED,
            temperature_c=Provenance.MEASURED,
            temperature_max_c=Provenance.MEASURED,
            temperature_min_c=Provenance.MEASURED,
            ambient_c=Provenance.MEASURED,
            coolant_c=Provenance.MEASURED,
            cell_imbalance_v=Provenance.MEASURED,
        )

        capability = self.sop.estimate(provisional, horizon_s=self.sop_horizon_s)
        self._state = provisional.evolve(
            power_limit_discharge_w=capability.discharge_w,
            power_limit_charge_w=-capability.charge_w,
        )

        self._diagnostics = EstimationDiagnostics(
            soc_fusion=fusion,
            soc_estimates={"ekf": e_ekf, "coulomb": e_coulomb, "ocv": e_ocv},
            capacity=e_capacity,
            resistance=e_resistance,
            imbalance=imbalance_report,
            capability=capability,
            ekf_consistency=self.ekf.consistency(),
            frames=self._diagnostics.frames + 1,
        )
        return self._state

    def reset(self, *, soc: float, temperature_c: float = 25.0) -> None:
        self.coulomb.reset(soc=soc)
        self.ekf.reset(soc=soc)
        self.ocv.reset()
        if self.imbalance is not None:
            self.imbalance.reset()
        self._state = self.battery.initial_state(
            soc=soc, temperature_c=temperature_c, provenance=Provenance.ESTIMATED
        )
        self._last_timestamp = None


__all__ = ["StateEstimator", "EstimationDiagnostics"]
