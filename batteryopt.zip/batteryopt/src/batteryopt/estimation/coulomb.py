"""Coulomb counting: integrate current, accept the drift, quantify it.

Coulomb counting is exactly right over short horizons and hopeless over long
ones, because the current sensor's offset error integrates linearly while its
random error integrates as the square root of time. This implementation tracks
both explicitly, so the fusion layer knows precisely how much to trust it:

.. code-block:: text

    var(soc) grows by  (sigma_offset * dt / (3600 * Q))^2      (systematic)
                    +  (sigma_random * dt / (3600 * Q))^2 / N   (random)

The systematic term is what dominates after an hour, and it is the reason a
pure coulomb counter must be re-anchored -- by an OCV reading at rest, or by
hitting a known full/empty rail.
"""

from __future__ import annotations

from typing import Any

from ..core.numerics import EPS, clamp
from ..core.units import SECONDS_PER_HOUR
from .base import Estimate, Measurement


class CoulombCounter:
    """Charge-integrating SOC estimator with an explicit error budget."""

    name = "coulomb"

    __slots__ = (
        "capacity_ah",
        "coulombic_efficiency",
        "offset_sigma_a",
        "random_sigma_a",
        "_soc",
        "_variance",
        "_charge_ah",
        "_anchored_at",
    )

    def __init__(
        self,
        *,
        capacity_ah: float,
        initial_soc: float = 0.5,
        initial_variance: float = 4e-4,
        coulombic_efficiency: float = 0.995,
        offset_sigma_a: float = 0.2,
        random_sigma_a: float = 0.5,
    ) -> None:
        self.capacity_ah = capacity_ah
        self.coulombic_efficiency = coulombic_efficiency
        self.offset_sigma_a = offset_sigma_a
        self.random_sigma_a = random_sigma_a
        self._soc = clamp(initial_soc, 0.0, 1.0)
        self._variance = initial_variance
        self._charge_ah = 0.0
        self._anchored_at = 0.0

    @property
    def soc(self) -> float:
        return self._soc

    @property
    def throughput_ah(self) -> float:
        """Absolute charge moved since construction or the last reset."""
        return self._charge_ah

    def update(self, measurement: Measurement, dt: float) -> Estimate:
        if dt <= 0.0 or self.capacity_ah <= EPS:
            return Estimate(self._soc, self._variance, source=self.name)
        i = measurement.current_a
        ah = i * dt / SECONDS_PER_HOUR
        if i < 0.0:
            ah *= self.coulombic_efficiency
        self._soc = clamp(self._soc - ah / self.capacity_ah, 0.0, 1.0)
        self._charge_ah += abs(ah)

        hours = dt / SECONDS_PER_HOUR
        per_ah = 1.0 / self.capacity_ah
        # Offset error is systematic: its contribution to the standard
        # deviation accumulates linearly, so it is added *before* squaring.
        systematic_sd = self.offset_sigma_a * hours * per_ah
        random_var = (self.random_sigma_a * hours * per_ah) ** 2
        self._variance = (
            (self._variance**0.5 + systematic_sd) ** 2 + random_var
        )
        return Estimate(self._soc, self._variance, source=self.name)

    def anchor(self, soc: float, variance: float, *, timestamp: float = 0.0) -> None:
        """Reset the integrator to a trusted external fix (OCV, full, empty)."""
        self._soc = clamp(soc, 0.0, 1.0)
        self._variance = max(variance, 1e-8)
        self._anchored_at = timestamp

    def reset(self, **kwargs: Any) -> None:
        self._soc = clamp(float(kwargs.get("soc", self._soc)), 0.0, 1.0)
        self._variance = float(kwargs.get("variance", 4e-4))
        self._charge_ah = 0.0

    def set_capacity(self, capacity_ah: float) -> None:
        """Update the capacity used for integration, after an SOH revision."""
        if capacity_ah > EPS:
            self.capacity_ah = capacity_ah


__all__ = ["CoulombCounter"]
