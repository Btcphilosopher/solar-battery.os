"""Extended Kalman filter over the equivalent-circuit state.

The filter estimates ``x = [soc, v_rc_1, ..., v_rc_n]`` from terminal voltage
and current. It is the workhorse estimator: coulomb counting supplies the
prediction step, voltage supplies the correction, and the covariance
bookkeeping decides automatically how much to believe each.

.. code-block:: text

    predict:   soc'   = soc - eta * i * dt / (3600 * Q)
               v_rc'  = a_j * v_rc + R_j * (1 - a_j) * i,   a_j = exp(-dt/tau_j)
    observe:   V      = OCV(soc) - i * R0(T, soc, age) - sum(v_rc)
    jacobian:  H      = [ dOCV/dsoc,  -1, ..., -1 ]

Two properties matter in practice and both fall out of the mathematics rather
than being special-cased:

* **Flat-OCV chemistries degrade gracefully.** On the LFP plateau ``dOCV/dsoc``
  is near zero, so ``H`` is near zero, the Kalman gain on SOC collapses, and
  the filter falls back to coulomb counting -- while its reported covariance
  grows, correctly telling the fusion layer that SOC is becoming uncertain.
* **A wrong capacity shows up as a persistent innovation bias.** That signal
  is what :mod:`batteryopt.estimation.soh` consumes to re-estimate capacity.

Joseph-form covariance update is used because the symmetric shortcut loses
positive-definiteness after a few thousand steps in single precision, and this
filter is expected to run for years.

**Adaptive measurement noise.** A textbook EKF fed a sensor noise figure
reports a covariance that is far too small, because the dominant residual is
not sensor noise -- it is model error: unmodelled hysteresis, RC time
constants that drift with age, a resistance map fitted at a different
temperature. Left alone the filter becomes overconfident, which is worse than
being wrong, because the fusion layer then ignores every other estimator.

This implementation therefore tracks the innovation variance online and
inflates ``R`` until the normalised innovation squared averages about one.
The reported SOC uncertainty then reflects total model-plus-sensor error, and
:meth:`ExtendedKalmanSOC.consistency` is a genuine health check rather than a
formality.

**Hysteresis state.** Adaptive noise handles zero-mean model error but not
*bias*, and voltage hysteresis is pure bias: after a discharge the rested
voltage sits below the true OCV, after a charge above it. On a 250-cell LFP
string a 12 mV per-cell hysteresis is 3 V at the terminals -- worth about 13 %
SOC on the plateau. A filter that ignores it converges confidently to the
wrong answer.

The filter therefore carries an optional hysteresis state ``h`` in [-1, 1]
(the standard Plett formulation), driven towards the sign of the current at a
rate proportional to throughput:

.. code-block:: text

    h' = A_h * h + (A_h - 1) * sign(i),   A_h = exp(-|gamma * eta * i * dt / (3600 Q)|)
    V  = OCV(soc) + M * h - i * R0 - sum(v_rc)

It is enabled automatically for any chemistry whose parameter file declares a
non-zero hysteresis.
"""

from __future__ import annotations

from typing import Any

import numpy as np

from ..core.numerics import EPS, clamp, require_finite
from ..core.units import SECONDS_PER_HOUR
from ..models.electrical import EquivalentCircuitModel
from .base import Estimate, Measurement


class ExtendedKalmanSOC:
    """EKF for SOC and diffusion overpotentials."""

    name = "ekf"

    __slots__ = (
        "ecm",
        "capacity_ah",
        "resistance_growth",
        "_x",
        "_p",
        "_q",
        "_r",
        "_n",
        "_innovation",
        "_innovation_var",
        "_nis_history",
        "process_soc_var_per_s",
        "process_rc_var_per_s",
        "coulombic_efficiency",
        "adaptive_measurement_noise",
        "adaptation_rate",
        "min_soc_variance",
        "_r_adaptive",
        "_hyst_index",
        "_hyst_magnitude_v",
        "hysteresis_gamma",
    )

    def __init__(
        self,
        ecm: EquivalentCircuitModel,
        *,
        capacity_ah: float,
        initial_soc: float = 0.5,
        initial_soc_variance: float = 4e-3,
        initial_rc_variance: float = 1e-4,
        process_soc_var_per_s: float = 1e-9,
        process_rc_var_per_s: float = 1e-6,
        measurement_variance_v: float | None = None,
        resistance_growth: float = 0.0,
        coulombic_efficiency: float | None = None,
        adaptive_measurement_noise: bool = True,
        adaptation_rate: float = 0.01,
        min_soc_variance: float = 1e-6,
        model_hysteresis: bool | None = None,
        hysteresis_gamma: float = 30.0,
    ) -> None:
        self.ecm = ecm
        self.capacity_ah = capacity_ah
        self.resistance_growth = resistance_growth
        self.coulombic_efficiency = (
            ecm.chemistry.envelope.coulombic_efficiency
            if coulombic_efficiency is None
            else coulombic_efficiency
        )
        n_rc = ecm.n_rc
        hyst_v_cell = ecm.chemistry.ocv.hysteresis_v
        use_hyst = (hyst_v_cell > 0.0) if model_hysteresis is None else bool(model_hysteresis)
        self._hyst_magnitude_v = hyst_v_cell * ecm.topology.n_series if use_hyst else 0.0
        self.hysteresis_gamma = hysteresis_gamma
        self._n = 1 + n_rc + (1 if use_hyst else 0)
        self._hyst_index = (1 + n_rc) if use_hyst else -1
        self._x = np.zeros(self._n)
        self._x[0] = clamp(initial_soc, 0.0, 1.0)
        diag = [initial_soc_variance] + [initial_rc_variance] * n_rc
        if use_hyst:
            diag.append(0.25)
        self._p = np.diag(np.asarray(diag, dtype=float))
        self.process_soc_var_per_s = process_soc_var_per_s
        self.process_rc_var_per_s = process_rc_var_per_s
        self._q = np.zeros((self._n, self._n))
        self._r = measurement_variance_v if measurement_variance_v is not None else 1e-4
        self._innovation = 0.0
        self._innovation_var = self._r
        self._nis_history: list[float] = []
        self.adaptive_measurement_noise = adaptive_measurement_noise
        self.adaptation_rate = adaptation_rate
        #: Floor applied to the *reported* SOC variance. The internal
        #: covariance is deliberately left unclamped -- clamping it would feed
        #: back into the Kalman gain and stop the filter ever recovering
        #: sensitivity after a period of low observability.
        self.min_soc_variance = min_soc_variance
        self._r_adaptive = self._r

    # -- accessors ----------------------------------------------------------

    @property
    def soc(self) -> float:
        return float(self._x[0])

    @property
    def soc_variance(self) -> float:
        return float(self._p[0, 0])

    @property
    def rc_voltages(self) -> tuple[float, ...]:
        end = self._hyst_index if self._hyst_index > 0 else self._n
        return tuple(float(v) for v in self._x[1:end])

    @property
    def hysteresis(self) -> float:
        """Hysteresis state in [-1, 1]; 0.0 when the state is not modelled."""
        return float(self._x[self._hyst_index]) if self._hyst_index > 0 else 0.0

    @property
    def models_hysteresis(self) -> bool:
        return self._hyst_index > 0

    @property
    def innovation(self) -> float:
        """Last voltage residual, V. A persistent bias implies a model error."""
        return self._innovation

    @property
    def normalised_innovation_squared(self) -> float:
        """NIS: should average ~1 for a correctly tuned filter."""
        return self._innovation**2 / max(self._innovation_var, EPS)

    def consistency(self, window: int = 100) -> float:
        """Mean NIS over the recent window; far from 1.0 means mis-tuned."""
        if not self._nis_history:
            return 1.0
        recent = self._nis_history[-window:]
        return float(np.mean(recent))

    # -- filter -------------------------------------------------------------

    def update(self, measurement: Measurement, dt: float) -> Estimate:
        if dt <= 0.0:
            return Estimate(self.soc, self.soc_variance, source=self.name)
        i = measurement.current_a
        temperature = measurement.temperature_c

        # --- predict --------------------------------------------------------
        eta = self.coulombic_efficiency if i < 0.0 else 1.0
        d_soc = -eta * i * dt / (SECONDS_PER_HOUR * max(self.capacity_ah, EPS))
        x = self._x.copy()
        x[0] = clamp(x[0] + d_soc, 0.0, 1.0)

        f = np.eye(self._n)
        rc_r = self.ecm.rc_resistances(self.resistance_growth)
        for k, (r_k, tau_k) in enumerate(zip(rc_r, self.ecm.rc_time_constants), start=1):
            a = float(np.exp(-dt / max(tau_k, EPS)))
            x[k] = x[k] * a + r_k * (1.0 - a) * i
            f[k, k] = a

        if self._hyst_index > 0:
            hi = self._hyst_index
            rate = abs(
                self.hysteresis_gamma * i * dt / (SECONDS_PER_HOUR * max(self.capacity_ah, EPS))
            )
            a_h = float(np.exp(-rate))
            sign = -1.0 if i > 0.0 else (1.0 if i < 0.0 else x[hi])
            x[hi] = clamp(x[hi] * a_h + (1.0 - a_h) * sign, -1.0, 1.0)
            f[hi, hi] = a_h

        self._q[0, 0] = self.process_soc_var_per_s * dt
        for k in range(1, self._n):
            self._q[k, k] = self.process_rc_var_per_s * dt
        if self._hyst_index > 0:
            self._q[self._hyst_index, self._hyst_index] = 1e-6 * dt
        p = f @ self._p @ f.T + self._q

        # --- observe ---------------------------------------------------------
        charging = i < 0.0
        r0 = self.ecm.resistance(
            soc=x[0],
            temperature_c=temperature,
            resistance_growth=self.resistance_growth,
            charging=charging,
        )
        # Base OCV without the sign-switched hysteresis offset: when the
        # hysteresis state is active it owns that term, and double-counting it
        # would bias the filter in exactly the direction it is meant to fix.
        ocv = float(self.ecm.ocv(x[0], hysteresis=0.0))
        rc_end = self._hyst_index if self._hyst_index > 0 else self._n
        v_pred = ocv - i * r0 - float(np.sum(x[1:rc_end]))
        if self._hyst_index > 0:
            v_pred += self._hyst_magnitude_v * x[self._hyst_index]

        n_series = self.ecm.topology.n_series
        slope_cell = self.ecm.chemistry.ocv.slope_at(x[0])
        h = np.empty(self._n)
        h[0] = slope_cell * n_series
        h[1:rc_end] = -1.0
        if self._hyst_index > 0:
            h[self._hyst_index] = self._hyst_magnitude_v

        r_sensor = max(measurement.voltage_sigma_v**2, 1e-8)
        innovation = float(measurement.voltage_v - v_pred)
        hph = float(h @ p @ h)

        if self.adaptive_measurement_noise:
            # Exponentially weighted estimate of the true innovation variance.
            beta = self.adaptation_rate
            self._r_adaptive = (1.0 - beta) * self._r_adaptive + beta * innovation**2
            r_meas = max(r_sensor, self._r_adaptive - hph)
        else:
            r_meas = r_sensor

        s = max(hph + r_meas, EPS)
        gain = (p @ h) / s

        x = x + gain * innovation
        x[0] = clamp(x[0], 0.0, 1.0)
        if self._hyst_index > 0:
            x[self._hyst_index] = clamp(x[self._hyst_index], -1.0, 1.0)

        # Joseph form: numerically stable and stays positive-definite.
        eye = np.eye(self._n)
        a = eye - np.outer(gain, h)
        p = a @ p @ a.T + np.outer(gain, gain) * r_meas
        p = 0.5 * (p + p.T)

        self._x = x
        self._p = p
        self._innovation = float(innovation)
        self._innovation_var = s
        self._nis_history.append(self.normalised_innovation_squared)
        if len(self._nis_history) > 2000:
            del self._nis_history[:1000]

        require_finite("EKF soc", self._x[0])
        return Estimate(
            value=self.soc,
            variance=max(self.soc_variance, self.min_soc_variance),
            source=self.name,
            meta={
                "innovation_v": self._innovation,
                "nis": self.normalised_innovation_squared,
                "ocv_slope_v_per_soc": slope_cell,
                "measurement_variance_v2": r_meas,
                "rc_voltages": self.rc_voltages,
                "hysteresis": self.hysteresis,
            },
        )

    # -- maintenance --------------------------------------------------------

    def set_capacity(self, capacity_ah: float) -> None:
        """Adopt a revised capacity from the SOH estimator."""
        if capacity_ah > EPS:
            self.capacity_ah = capacity_ah

    def set_resistance_growth(self, growth: float) -> None:
        self.resistance_growth = max(growth, -0.99)

    def anchor(self, soc: float, variance: float) -> None:
        """Fold in a trusted external SOC fix as a direct measurement."""
        p00 = self._p[0, 0]
        k = p00 / max(p00 + variance, EPS)
        self._x[0] = clamp(self._x[0] + k * (soc - self._x[0]), 0.0, 1.0)
        self._p[0, 0] = max((1.0 - k) * p00, 1e-10)

    def reset(self, **kwargs: Any) -> None:
        self._x[:] = 0.0
        self._x[0] = clamp(float(kwargs.get("soc", 0.5)), 0.0, 1.0)
        diag = np.full(self._n, float(kwargs.get("rc_variance", 1e-4)))
        diag[0] = float(kwargs.get("soc_variance", 4e-3))
        if self._hyst_index > 0:
            diag[self._hyst_index] = 0.25
        self._p = np.diag(diag)
        self._nis_history.clear()
        self._r_adaptive = self._r


__all__ = ["ExtendedKalmanSOC"]
