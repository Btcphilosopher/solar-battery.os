"""Cell imbalance analysis.

Two cells at the same SOC can sit at different voltages (resistance spread
under load) and two cells at the same voltage can hold different charge
(capacity spread). Telling them apart matters, because only one of them is
worth spending balancing energy on:

* **Voltage spread under load** is mostly resistance spread. Bleeding charge
  off the high cell does nothing for it and wastes energy.
* **Voltage spread at rest** is genuine SOC divergence, which balancing does
  fix -- and which costs usable pack capacity, because the pack empties when
  its *weakest* cell empties.

The estimator separates the two by regressing cell voltage on current across
recent frames: the slope is per-cell resistance, the intercept is per-cell
rest voltage, and the rest voltages convert to SOC through the OCV curve.

The output feeds :mod:`batteryopt.applications.balancing`, which decides
whether the recoverable capacity is worth the balancing energy and the
degradation the extra cycling causes.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np

from ..core.numerics import EPS
from ..models.chemistry import ChemistryParameters
from .base import Estimate, Measurement


@dataclass(frozen=True, slots=True)
class ImbalanceReport:
    """Per-cell divergence and what it costs."""

    #: Max-minus-min cell voltage at the last frame, V.
    voltage_spread_v: float
    #: Estimated max-minus-min cell SOC, dimensionless.
    soc_spread: float
    #: Standard deviation of estimated per-cell resistance, normalised.
    resistance_spread: float
    #: SOC of the weakest (lowest) and strongest (highest) cell.
    min_cell_soc: float
    max_cell_soc: float
    #: Indices of cells more than three sigma from the pack mean.
    outlier_cells: tuple[int, ...]
    #: Usable pack capacity lost to imbalance, as a fraction of nominal.
    capacity_loss_fraction: float
    #: Charge that would have to be bled from high cells to level the pack, Ah.
    balancing_charge_ah: float
    #: Confidence in the decomposition, 0-1 (needs current variation to work).
    confidence: float
    per_cell_soc: tuple[float, ...] = ()
    meta: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "voltage_spread_v": self.voltage_spread_v,
            "soc_spread": self.soc_spread,
            "resistance_spread": self.resistance_spread,
            "min_cell_soc": self.min_cell_soc,
            "max_cell_soc": self.max_cell_soc,
            "outlier_cells": list(self.outlier_cells),
            "capacity_loss_fraction": self.capacity_loss_fraction,
            "balancing_charge_ah": self.balancing_charge_ah,
            "confidence": self.confidence,
        }


class ImbalanceEstimator:
    """Separates SOC divergence from resistance spread across cells."""

    name = "imbalance"

    __slots__ = ("chemistry", "cell_capacity_ah", "window", "_v", "_i", "_n_cells")

    def __init__(
        self,
        chemistry: ChemistryParameters,
        *,
        cell_capacity_ah: float,
        window: int = 240,
    ) -> None:
        self.chemistry = chemistry
        self.cell_capacity_ah = cell_capacity_ah
        #: Number of recent frames retained for the regression. Needs to span
        #: enough current variation to identify the slope.
        self.window = window
        self._v: list[np.ndarray] = []
        self._i: list[float] = []
        self._n_cells = 0

    def update(self, measurement: Measurement, dt: float) -> Estimate:
        cells = measurement.cell_voltages_v
        if len(cells) < 2:
            return Estimate.unavailable(self.name, "no per-cell voltages available")
        arr = np.asarray(cells, dtype=float)
        if self._n_cells and arr.size != self._n_cells:
            self._v.clear()
            self._i.clear()
        self._n_cells = arr.size
        self._v.append(arr)
        self._i.append(measurement.current_a)
        if len(self._v) > self.window:
            del self._v[0]
            del self._i[0]
        return Estimate(
            value=float(arr.max() - arr.min()),
            variance=max(measurement.voltage_sigma_v**2, 1e-8),
            source=self.name,
            meta={"n_cells": int(arr.size)},
        )

    def report(self, measurement: Measurement | None = None) -> ImbalanceReport:
        """Decompose the accumulated frames into SOC and resistance spread."""
        if not self._v:
            return ImbalanceReport(0.0, 0.0, 0.0, 0.0, 0.0, (), 0.0, 0.0, 0.0)

        v = np.vstack(self._v)  # (frames, cells)
        i = np.asarray(self._i, dtype=float)
        latest = v[-1]
        spread_v = float(latest.max() - latest.min())

        i_var = float(np.var(i))
        if v.shape[0] >= 8 and i_var > 1.0:
            # v_c = a_c - i * r_c  ->  least squares per cell.
            i_centred = i - i.mean()
            denom = float(np.sum(i_centred**2))
            slopes = -(i_centred @ (v - v.mean(axis=0))) / max(denom, EPS)
            rest_v = v.mean(axis=0) + slopes * i.mean()
            confidence = float(min(1.0, i_var / 100.0)) * min(1.0, v.shape[0] / self.window)
            r_mean = float(np.mean(slopes))
            r_spread = float(np.std(slopes) / max(abs(r_mean), EPS)) if abs(r_mean) > EPS else 0.0
        else:
            # Not enough current variation: attribute everything to SOC, and
            # say so through the confidence figure rather than pretending.
            rest_v = latest
            confidence = 0.25
            r_spread = 0.0

        curve = self.chemistry.ocv
        per_cell_soc = np.asarray([curve.soc_at(float(x)) for x in rest_v], dtype=float)
        soc_spread = float(per_cell_soc.max() - per_cell_soc.min())

        mean_soc = float(per_cell_soc.mean())
        sd = float(per_cell_soc.std())
        outliers = (
            tuple(int(k) for k in np.flatnonzero(np.abs(per_cell_soc - mean_soc) > 3.0 * sd))
            if sd > 1e-6
            else ()
        )

        # A series string empties when its lowest cell empties and fills when
        # its highest fills, so the usable window shrinks by the full spread.
        capacity_loss = float(min(soc_spread, 1.0))
        balancing_ah = float(np.sum(per_cell_soc - per_cell_soc.min()) * self.cell_capacity_ah)

        return ImbalanceReport(
            voltage_spread_v=spread_v,
            soc_spread=soc_spread,
            resistance_spread=r_spread,
            min_cell_soc=float(per_cell_soc.min()),
            max_cell_soc=float(per_cell_soc.max()),
            outlier_cells=outliers,
            capacity_loss_fraction=capacity_loss,
            balancing_charge_ah=balancing_ah,
            confidence=confidence,
            per_cell_soc=tuple(float(x) for x in per_cell_soc),
            meta={"frames": int(v.shape[0]), "current_variance": i_var},
        )

    def reset(self, **kwargs: Any) -> None:
        self._v.clear()
        self._i.clear()


__all__ = ["ImbalanceEstimator", "ImbalanceReport"]
