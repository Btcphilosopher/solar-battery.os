"""Telemetry validation: the stage that decides what the engine is allowed to believe.

.. code-block:: text

    TELEMETRY -> VALIDATION -> STATE ESTIMATION -> ...

Everything downstream assumes its inputs are physically possible. That
assumption has to be enforced somewhere, and here is the only place where it is
cheap: rejecting a 4000 V reading costs one comparison, while letting it reach
the Kalman filter costs a diverged state and a bad recommendation.

Three outcomes, and the distinction between them matters:

* **Accept** -- the frame is plausible and passes through untouched.
* **Repair** -- a field is missing or stale but recoverable (a dropped
  temperature can be held from the previous frame for a few seconds). The frame
  passes through with the repair recorded, so a downstream consumer can see
  that it happened.
* **Reject** -- the frame is not physically possible, or is missing something
  irreplaceable. It is dropped and counted.

Repairs are deliberately time-limited. Holding the last good value forever is
how a failed sensor becomes invisible; holding it for a few seconds is how a
dropped packet becomes harmless.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any

from ..core.numerics import EPS
from ..models.battery import Battery
from .schema import FrameIssue, TelemetryFrame, ValidationResult


@dataclass(slots=True)
class ValidationStats:
    """Running counts, exposed by the API for monitoring."""

    seen: int = 0
    accepted: int = 0
    repaired: int = 0
    rejected: int = 0
    by_reason: dict[str, int] = field(default_factory=dict)
    sequence_gaps: int = 0

    def record(self, result: ValidationResult) -> None:
        self.seen += 1
        if result.accepted:
            self.accepted += 1
            if result.repaired:
                self.repaired += 1
        else:
            self.rejected += 1
        for issue in result.issues:
            key = f"{issue.severity}:{issue.field}"
            self.by_reason[key] = self.by_reason.get(key, 0) + 1

    @property
    def acceptance_rate(self) -> float:
        return self.accepted / self.seen if self.seen else 1.0

    def as_dict(self) -> dict[str, Any]:
        return {
            "seen": self.seen,
            "accepted": self.accepted,
            "repaired": self.repaired,
            "rejected": self.rejected,
            "acceptance_rate": self.acceptance_rate,
            "sequence_gaps": self.sequence_gaps,
            "by_reason": dict(self.by_reason),
        }


class TelemetryValidator:
    """Validates frames against the battery's physical envelope."""

    def __init__(
        self,
        battery: Battery,
        *,
        hold_seconds: float = 5.0,
        voltage_margin: float = 1.15,
        current_margin: float = 1.5,
        temperature_range_c: tuple[float, float] = (-60.0, 120.0),
        max_time_step_s: float = 3600.0,
    ) -> None:
        self.battery = battery
        #: How long a dropped field may be held from the previous frame.
        self.hold_seconds = hold_seconds
        #: Multiplier on the hard voltage limits beyond which a reading is
        #: treated as a sensor fault rather than a real excursion. Wider than
        #: the operating envelope on purpose: a genuine over-voltage event must
        #: reach the engine, not be discarded as noise.
        self.voltage_margin = voltage_margin
        self.current_margin = current_margin
        self.temperature_range_c = temperature_range_c
        self.max_time_step_s = max_time_step_s
        self.stats = ValidationStats()
        self._last: TelemetryFrame | None = None

    def validate(self, frame: TelemetryFrame) -> ValidationResult:
        issues: list[FrameIssue] = []
        updates: dict[str, Any] = {}
        battery = self.battery

        # --- timestamp ------------------------------------------------------
        if not math.isfinite(frame.timestamp):
            issues.append(
                FrameIssue("timestamp", "reject", "timestamp is not a finite number")
            )
            return self._finish(None, issues, accepted=False)
        if self._last is not None:
            dt = frame.timestamp - self._last.timestamp
            if dt < 0:
                issues.append(
                    FrameIssue(
                        "timestamp",
                        "reject",
                        f"timestamp goes backwards by {-dt:.3f} s",
                        frame.timestamp,
                    )
                )
                return self._finish(None, issues, accepted=False)
            if dt > self.max_time_step_s:
                issues.append(
                    FrameIssue(
                        "timestamp",
                        "warn",
                        f"gap of {dt:.0f} s since the previous frame; estimator "
                        "covariance will grow accordingly",
                    )
                )
            if (
                frame.sequence is not None
                and self._last.sequence is not None
                and frame.sequence != self._last.sequence + 1
            ):
                self.stats.sequence_gaps += 1
                issues.append(
                    FrameIssue(
                        "sequence",
                        "warn",
                        f"sequence jumped from {self._last.sequence} to {frame.sequence}",
                    )
                )

        # --- voltage --------------------------------------------------------
        v_max = battery.maximum_voltage * self.voltage_margin
        v_min = battery.minimum_voltage / self.voltage_margin
        if frame.voltage_v is None:
            repaired = self._hold(frame, "voltage_v")
            if repaired is None:
                issues.append(
                    FrameIssue("voltage_v", "reject", "voltage missing and no recent value to hold")
                )
                return self._finish(None, issues, accepted=False)
            updates["voltage_v"] = repaired
            issues.append(
                FrameIssue("voltage_v", "repair", "voltage held from the previous frame", None, repaired)
            )
        elif not math.isfinite(frame.voltage_v) or not (v_min <= frame.voltage_v <= v_max):
            issues.append(
                FrameIssue(
                    "voltage_v",
                    "reject",
                    f"voltage {frame.voltage_v} V is outside the plausible range "
                    f"[{v_min:.1f}, {v_max:.1f}] V for this battery",
                    frame.voltage_v,
                )
            )
            return self._finish(None, issues, accepted=False)

        # --- current --------------------------------------------------------
        i_limit = (
            max(battery.pulse_discharge_current, battery.pulse_charge_current)
            * self.current_margin
        )
        if frame.current_a is None:
            repaired = self._hold(frame, "current_a")
            if repaired is None:
                issues.append(
                    FrameIssue("current_a", "reject", "current missing and no recent value to hold")
                )
                return self._finish(None, issues, accepted=False)
            updates["current_a"] = repaired
            issues.append(
                FrameIssue("current_a", "repair", "current held from the previous frame", None, repaired)
            )
        elif not math.isfinite(frame.current_a) or abs(frame.current_a) > i_limit:
            issues.append(
                FrameIssue(
                    "current_a",
                    "reject",
                    f"current {frame.current_a} A exceeds the plausible magnitude "
                    f"{i_limit:.0f} A",
                    frame.current_a,
                )
            )
            return self._finish(None, issues, accepted=False)

        # --- temperature ----------------------------------------------------
        lo, hi = self.temperature_range_c
        if frame.temperature_c is None:
            repaired = self._hold(frame, "temperature_c")
            if repaired is None:
                updates["temperature_c"] = 25.0
                issues.append(
                    FrameIssue(
                        "temperature_c",
                        "repair",
                        "temperature missing with no recent value; defaulted to 25 degC, "
                        "which will widen the estimator's resistance uncertainty",
                        None,
                        25.0,
                    )
                )
            else:
                updates["temperature_c"] = repaired
                issues.append(
                    FrameIssue(
                        "temperature_c", "repair", "temperature held from the previous frame", None, repaired
                    )
                )
        elif not math.isfinite(frame.temperature_c) or not (lo <= frame.temperature_c <= hi):
            issues.append(
                FrameIssue(
                    "temperature_c",
                    "reject",
                    f"temperature {frame.temperature_c} degC is outside the sensor's "
                    f"plausible range [{lo}, {hi}] degC",
                    frame.temperature_c,
                )
            )
            return self._finish(None, issues, accepted=False)

        # --- per-cell data ---------------------------------------------------
        if frame.cell_voltages_v:
            cell_max = battery.envelope.v_max_cell * self.voltage_margin
            cell_min = battery.envelope.v_min_cell / self.voltage_margin
            bad = [
                v
                for v in frame.cell_voltages_v
                if not math.isfinite(v) or not (cell_min <= v <= cell_max)
            ]
            if bad:
                updates["cell_voltages_v"] = []
                issues.append(
                    FrameIssue(
                        "cell_voltages_v",
                        "repair",
                        f"{len(bad)} cell voltages outside the plausible range; the whole "
                        "cell array is dropped rather than partially trusted, because a "
                        "partial array would corrupt the imbalance decomposition",
                        bad[:4],
                        [],
                    )
                )

        # --- reported values (advisory) ---------------------------------------
        if frame.reported_soc is not None and not (0.0 <= frame.reported_soc <= 1.0):
            updates["reported_soc"] = None
            issues.append(
                FrameIssue(
                    "reported_soc",
                    "repair",
                    f"BMS-reported SOC {frame.reported_soc} is outside [0, 1] and was dropped",
                    frame.reported_soc,
                    None,
                )
            )

        out = frame.model_copy(update=updates) if updates else frame
        return self._finish(out, issues, accepted=True, repaired=bool(updates))

    # -- helpers ------------------------------------------------------------

    def _hold(self, frame: TelemetryFrame, field_name: str) -> float | None:
        """Last good value for a field, if it is recent enough to trust."""
        if self._last is None:
            return None
        if frame.timestamp - self._last.timestamp > self.hold_seconds:
            return None
        return getattr(self._last, field_name, None)

    def _finish(
        self,
        frame: TelemetryFrame | None,
        issues: list[FrameIssue],
        *,
        accepted: bool,
        repaired: bool = False,
    ) -> ValidationResult:
        result = ValidationResult(frame=frame, issues=issues, accepted=accepted, repaired=repaired)
        self.stats.record(result)
        if accepted and frame is not None:
            self._last = frame
        return result

    def reset(self) -> None:
        self._last = None
        self.stats = ValidationStats()


__all__ = ["TelemetryValidator", "ValidationStats"]
