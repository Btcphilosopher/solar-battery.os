"""The telemetry pipeline (specification section 25).

.. code-block:: text

    TELEMETRY -> VALIDATION -> STATE ESTIMATION -> SCENARIO GENERATION
              -> OPTIMISATION -> RECOMMENDATION

One object owns that chain for one battery. It is deliberately a *pull*
pipeline driven by the source: frames arrive, and each one advances the twin.
Optimisation runs on its own cadence, which is almost always slower than
telemetry -- a 10 Hz current sensor does not need a new recommendation ten
times a second, and pretending otherwise wastes the entire compute budget.

Three properties matter in production and are built in rather than bolted on:

* **Backpressure is visible.** If optimisation cannot keep up, frames are still
  consumed and the state stays current; the recommendation cadence slips and
  says so. The alternative -- queueing frames -- means optimising against a
  state that is minutes old.
* **A failed optimisation does not stop ingestion.** State estimation continues
  regardless, so the twin stays accurate even while the optimiser is failing,
  which is exactly when accurate state matters most.
* **Everything is recorded.** Raw frames, validation outcomes, states and
  recommendations all go to the repository, which is what makes an
  after-the-fact "why did it do that?" answerable.
"""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Callable

from ..core.exceptions import BatteryOptError, SafetyViolation
from ..models.state import BatteryState
from ..optimisation.engine import OptimisationEngine
from ..optimisation.problem import Demand, Recommendation
from ..twin.twin import DigitalTwin
from .schema import TelemetryFrame, ValidationResult
from .sources.base import TelemetrySource
from .validation import TelemetryValidator

log = logging.getLogger(__name__)


@dataclass(slots=True)
class PipelineStats:
    """What the pipeline has been doing, for monitoring and the dashboard."""

    frames_in: int = 0
    frames_accepted: int = 0
    frames_rejected: int = 0
    states_estimated: int = 0
    optimisations: int = 0
    optimisation_failures: int = 0
    safety_rejections: int = 0
    last_frame_timestamp: float | None = None
    last_optimisation_timestamp: float | None = None
    mean_optimise_ms: float = 0.0
    max_optimise_ms: float = 0.0
    mean_ingest_us: float = 0.0

    def as_dict(self) -> dict[str, Any]:
        return {
            "frames_in": self.frames_in,
            "frames_accepted": self.frames_accepted,
            "frames_rejected": self.frames_rejected,
            "states_estimated": self.states_estimated,
            "optimisations": self.optimisations,
            "optimisation_failures": self.optimisation_failures,
            "safety_rejections": self.safety_rejections,
            "last_frame_timestamp": self.last_frame_timestamp,
            "last_optimisation_timestamp": self.last_optimisation_timestamp,
            "mean_optimise_ms": self.mean_optimise_ms,
            "max_optimise_ms": self.max_optimise_ms,
            "mean_ingest_us": self.mean_ingest_us,
        }


class TelemetryPipeline:
    """Ingests telemetry, maintains the twin, and emits recommendations."""

    def __init__(
        self,
        twin: DigitalTwin,
        engine: OptimisationEngine,
        *,
        validator: TelemetryValidator | None = None,
        optimise_interval_s: float = 60.0,
        horizon_s: float = 900.0,
        dt_s: float = 60.0,
        demand: Callable[[BatteryState], Demand | float | None] | Demand | float | None = None,
        repository: Any | None = None,
        on_recommendation: Callable[[Recommendation, BatteryState], None] | None = None,
        on_rejected: Callable[[ValidationResult], None] | None = None,
    ) -> None:
        self.twin = twin
        self.engine = engine
        self.validator = validator or TelemetryValidator(twin.battery)
        #: Minimum wall-clock gap between optimisation runs.
        self.optimise_interval_s = optimise_interval_s
        self.horizon_s = horizon_s
        self.dt_s = dt_s
        self.demand = demand
        self.repository = repository
        self.on_recommendation = on_recommendation
        self.on_rejected = on_rejected
        self.stats = PipelineStats()
        self.latest_recommendation: Recommendation | None = None
        self._last_optimise_at: float | None = None
        self._optimise_samples = 0
        self._ingest_samples = 0
        self._running = False

    # -- single frame -------------------------------------------------------

    def ingest(self, frame: TelemetryFrame) -> BatteryState | None:
        """Validate one frame and advance the twin. Returns the new state."""
        started = time.perf_counter()
        self.stats.frames_in += 1
        result = self.validator.validate(frame)
        if self.repository is not None:
            try:
                self.repository.append_telemetry(frame, result)
            except Exception as exc:  # noqa: BLE001 - storage must never block ingest
                log.warning("failed to persist telemetry frame: %s", exc)

        if not result.accepted or result.frame is None:
            self.stats.frames_rejected += 1
            if self.on_rejected is not None:
                self.on_rejected(result)
            return None

        self.stats.frames_accepted += 1
        self.stats.last_frame_timestamp = result.frame.timestamp
        state = self.twin.ingest(result.frame.to_measurement())
        self.stats.states_estimated += 1
        if self.repository is not None:
            try:
                self.repository.append_state(state, battery_id=frame.battery_id)
            except Exception as exc:  # noqa: BLE001
                log.warning("failed to persist state estimate: %s", exc)

        elapsed_us = (time.perf_counter() - started) * 1e6
        self._ingest_samples += 1
        self.stats.mean_ingest_us += (
            elapsed_us - self.stats.mean_ingest_us
        ) / self._ingest_samples
        return state

    # -- optimisation -------------------------------------------------------

    def due_for_optimisation(self, now_s: float) -> bool:
        if self._last_optimise_at is None:
            return True
        return now_s - self._last_optimise_at >= self.optimise_interval_s

    def optimise(self, state: BatteryState | None = None) -> Recommendation | None:
        """Run one optimisation against the twin's current state.

        Failures are caught and counted rather than propagated: a control loop
        that stops ingesting telemetry because the optimiser raised is worse
        than one that keeps its state current and reports that it has no fresh
        recommendation.
        """
        state = state or self.twin.state
        demand = self.demand(state) if callable(self.demand) else self.demand
        started = time.perf_counter()
        try:
            recommendation = self.engine.optimise_state(
                state,
                demand=demand,
                horizon_s=self.horizon_s,
                dt_s=self.dt_s,
            )
        except SafetyViolation as exc:
            self.stats.optimisation_failures += 1
            self.stats.safety_rejections += 1
            log.error("optimisation rejected on safety grounds: %s", exc)
            return None
        except BatteryOptError as exc:
            self.stats.optimisation_failures += 1
            log.warning("optimisation failed: %s", exc)
            return None

        elapsed_ms = (time.perf_counter() - started) * 1000.0
        self._optimise_samples += 1
        self.stats.mean_optimise_ms += (
            elapsed_ms - self.stats.mean_optimise_ms
        ) / self._optimise_samples
        self.stats.max_optimise_ms = max(self.stats.max_optimise_ms, elapsed_ms)
        self.stats.optimisations += 1
        self.stats.last_optimisation_timestamp = state.timestamp
        self._last_optimise_at = state.timestamp
        self.latest_recommendation = recommendation

        if self.repository is not None:
            try:
                self.repository.append_recommendation(
                    recommendation, battery_id=self.twin.battery.battery_id
                )
            except Exception as exc:  # noqa: BLE001
                log.warning("failed to persist recommendation: %s", exc)
        if self.on_recommendation is not None:
            self.on_recommendation(recommendation, state)
        return recommendation

    def step(self, frame: TelemetryFrame) -> Recommendation | None:
        """Ingest a frame and optimise if the cadence allows."""
        state = self.ingest(frame)
        if state is None:
            return None
        if self.due_for_optimisation(state.timestamp):
            return self.optimise(state)
        return None

    # -- driving from a source ----------------------------------------------

    async def run(self, source: TelemetrySource, *, max_frames: int | None = None) -> PipelineStats:
        """Consume a source until it ends or ``max_frames`` is reached."""
        self._running = True
        count = 0
        try:
            async for frame in source:
                if not self._running:
                    break
                self.step(frame)
                count += 1
                if max_frames is not None and count >= max_frames:
                    break
        finally:
            self._running = False
        return self.stats

    def run_sync(self, frames: Any) -> PipelineStats:
        """Consume an iterable of frames synchronously, for replay and tests."""
        for frame in frames:
            self.step(frame)
        return self.stats

    def stop(self) -> None:
        self._running = False

    # -- reporting ----------------------------------------------------------

    def snapshot(self) -> dict[str, Any]:
        return {
            "battery_id": self.twin.battery.battery_id,
            "pipeline": self.stats.as_dict(),
            "validation": self.validator.stats.as_dict(),
            "twin": self.twin.snapshot().as_dict(),
            "recommendation": (
                self.latest_recommendation.as_dict() if self.latest_recommendation else None
            ),
        }

    def health(self) -> dict[str, Any]:
        """A compact health view: is telemetry flowing and is the engine keeping up?"""
        stats = self.stats
        stale = (
            stats.last_frame_timestamp is not None
            and stats.last_optimisation_timestamp is not None
            and (stats.last_frame_timestamp - stats.last_optimisation_timestamp)
            > 3.0 * self.optimise_interval_s
        )
        return {
            "telemetry_flowing": stats.frames_accepted > 0,
            "acceptance_rate": self.validator.stats.acceptance_rate,
            "recommendation_stale": bool(stale),
            "optimisation_failure_rate": (
                stats.optimisation_failures / max(stats.optimisations + stats.optimisation_failures, 1)
            ),
            "mean_optimise_ms": stats.mean_optimise_ms,
            "max_optimise_ms": stats.max_optimise_ms,
            "safety_rejections": stats.safety_rejections,
        }


__all__ = ["TelemetryPipeline", "PipelineStats"]
