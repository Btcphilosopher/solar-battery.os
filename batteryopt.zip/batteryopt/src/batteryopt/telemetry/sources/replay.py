"""CSV and columnar replay.

Replaying recorded telemetry is how an optimisation change is evaluated before
it touches hardware: run the new engine over last month's data and compare the
recommendations. For that to be meaningful the replay must be *faithful* --
same timestamps, same gaps, same bad frames -- so this source deliberately does
not clean anything. Cleaning is the validator's job, and hiding a data quality
problem at the replay stage would mean the offline evaluation is easier than
production.

Column names are mapped rather than assumed, because every BMS exports
different headers, and the mapping is explicit so a mis-mapped column is a
configuration error rather than a silently wrong result.
"""

from __future__ import annotations

import asyncio
import csv
from pathlib import Path
from typing import Any, AsyncIterator, Iterable, Iterator, Mapping

from ...core.exceptions import TelemetryError
from ...core.optional import try_import
from ..schema import TelemetryFrame
from .base import BaseSource

#: Default header mapping. Keys are frame fields, values are candidate column
#: names tried in order.
DEFAULT_COLUMNS: dict[str, tuple[str, ...]] = {
    "timestamp": ("timestamp", "time", "t", "time_s", "unix_time"),
    "voltage_v": ("voltage_v", "voltage", "pack_voltage", "v"),
    "current_a": ("current_a", "current", "pack_current", "i"),
    "temperature_c": ("temperature_c", "temperature", "temp", "cell_temp"),
    "ambient_c": ("ambient_c", "ambient", "ambient_temp"),
    "coolant_c": ("coolant_c", "coolant", "coolant_temp"),
    "reported_soc": ("soc", "reported_soc", "bms_soc"),
    "reported_soh": ("soh", "reported_soh", "bms_soh"),
}


def _to_float(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


class CSVReplaySource(BaseSource):
    """Replays a CSV file of telemetry, faithfully."""

    name = "csv_replay"

    def __init__(
        self,
        path: str | Path,
        *,
        battery_id: str = "battery-1",
        columns: Mapping[str, tuple[str, ...]] | None = None,
        cell_voltage_prefix: str = "cell_",
        module_temperature_prefix: str = "module_temp_",
        time_scale: float = 1.0,
        time_offset: float = 0.0,
        real_time: bool = False,
        speed: float = 1.0,
    ) -> None:
        super().__init__()
        self.path = Path(path)
        if not self.path.exists():
            raise TelemetryError(f"telemetry file not found: {self.path}")
        self.battery_id = battery_id
        self.columns = dict(DEFAULT_COLUMNS)
        if columns:
            self.columns.update(columns)
        self.cell_voltage_prefix = cell_voltage_prefix
        self.module_temperature_prefix = module_temperature_prefix
        #: Multiplier applied to the timestamp column, for files recorded in
        #: milliseconds or minutes.
        self.time_scale = time_scale
        self.time_offset = time_offset
        self.real_time = real_time
        self.speed = max(speed, 1e-6)

    def _resolve(self, header: Iterable[str]) -> dict[str, str]:
        available = {h.strip().lower(): h for h in header}
        resolved: dict[str, str] = {}
        for field, candidates in self.columns.items():
            for candidate in candidates:
                if candidate.lower() in available:
                    resolved[field] = available[candidate.lower()]
                    break
        if "timestamp" not in resolved:
            raise TelemetryError(
                f"{self.path}: no timestamp column found; tried "
                f"{', '.join(self.columns['timestamp'])}"
            )
        return resolved

    def rows(self) -> Iterator[TelemetryFrame]:
        """Synchronous iteration over the file."""
        with self.path.open("r", newline="", encoding="utf-8") as handle:
            reader = csv.DictReader(handle)
            if reader.fieldnames is None:
                raise TelemetryError(f"{self.path} has no header row")
            resolved = self._resolve(reader.fieldnames)
            cell_columns = sorted(
                c for c in reader.fieldnames if c.lower().startswith(self.cell_voltage_prefix)
            )
            module_columns = sorted(
                c
                for c in reader.fieldnames
                if c.lower().startswith(self.module_temperature_prefix)
            )
            for index, row in enumerate(reader):
                raw_time = _to_float(row.get(resolved["timestamp"]))
                if raw_time is None:
                    continue
                yield self._count(
                    TelemetryFrame(
                        battery_id=self.battery_id,
                        timestamp=raw_time * self.time_scale + self.time_offset,
                        voltage_v=_to_float(row.get(resolved.get("voltage_v", ""))),
                        current_a=_to_float(row.get(resolved.get("current_a", ""))),
                        temperature_c=_to_float(row.get(resolved.get("temperature_c", ""))),
                        ambient_c=_to_float(row.get(resolved.get("ambient_c", ""))),
                        coolant_c=_to_float(row.get(resolved.get("coolant_c", ""))),
                        cell_voltages_v=[
                            v for c in cell_columns if (v := _to_float(row.get(c))) is not None
                        ],
                        module_temperatures_c=[
                            v for c in module_columns if (v := _to_float(row.get(c))) is not None
                        ],
                        reported_soc=_to_float(row.get(resolved.get("reported_soc", ""))),
                        reported_soh=_to_float(row.get(resolved.get("reported_soh", ""))),
                        source=self.name,
                        sequence=index,
                    )
                )

    async def __aiter__(self) -> AsyncIterator[TelemetryFrame]:
        previous: float | None = None
        for frame in self.rows():
            if self.closed:
                return
            if self.real_time and previous is not None:
                await asyncio.sleep(max(0.0, (frame.timestamp - previous) / self.speed))
            previous = frame.timestamp
            yield frame
            if not self.real_time:
                await asyncio.sleep(0)

    def to_frame(self):  # pragma: no cover - optional dependency
        """Load the whole file into a Polars DataFrame, when Polars is present."""
        pl = try_import("polars")
        if pl is None:
            raise TelemetryError(
                "Polars is not installed; install batteryopt[frames] for frame output"
            )
        return pl.read_csv(self.path)


def write_csv(path: str | Path, frames: Iterable[TelemetryFrame]) -> int:
    """Write frames to CSV in a format :class:`CSVReplaySource` can read back."""
    frames = list(frames)
    if not frames:
        return 0
    n_cells = max(len(f.cell_voltages_v) for f in frames)
    header = [
        "timestamp",
        "voltage_v",
        "current_a",
        "temperature_c",
        "ambient_c",
        "coolant_c",
    ] + [f"cell_{k}" for k in range(n_cells)]
    with Path(path).open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(header)
        for f in frames:
            cells = list(f.cell_voltages_v) + [""] * (n_cells - len(f.cell_voltages_v))
            writer.writerow(
                [
                    f.timestamp,
                    "" if f.voltage_v is None else f.voltage_v,
                    "" if f.current_a is None else f.current_a,
                    "" if f.temperature_c is None else f.temperature_c,
                    "" if f.ambient_c is None else f.ambient_c,
                    "" if f.coolant_c is None else f.coolant_c,
                    *cells,
                ]
            )
    return len(frames)


__all__ = ["CSVReplaySource", "write_csv", "DEFAULT_COLUMNS"]
