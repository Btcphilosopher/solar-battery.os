"""Simulated telemetry: a virtual battery producing realistic frames.

This is the source that makes the whole platform testable without hardware
(specification section 33). It runs the plant model forward under a duty cycle
and emits frames with sensor noise, quantisation and -- importantly --
occasional dropouts, because software that has only ever seen perfect telemetry
falls over the first time a packet goes missing.

The noise model is explicit rather than incidental:

* Gaussian sensor noise at declared standard deviations.
* A fixed **current-sensor offset**, drawn once per source. This is the error
  that makes coulomb counting drift, and omitting it makes state estimation
  look far easier than it is.
* ADC quantisation on voltage.
* Random frame loss at a configurable rate.
"""

from __future__ import annotations

import asyncio
from typing import AsyncIterator, Callable

import numpy as np

from ...core.clock import SimulatedClock
from ...models.battery import Battery
from ...models.plant import Action, BatteryPlant
from ...models.state import BatteryState
from ..schema import TelemetryFrame
from .base import BaseSource


class SimulatedSource(BaseSource):
    """Drives a virtual battery and emits noisy telemetry from it."""

    name = "simulated"

    def __init__(
        self,
        battery: Battery,
        *,
        initial_soc: float = 0.5,
        initial_temperature_c: float = 25.0,
        ambient_c: float = 20.0,
        dt_s: float = 1.0,
        duty_cycle: Callable[[int, BatteryState], float] | float = 0.0,
        cooling: Callable[[int, BatteryState], float] | float = 0.0,
        n_cell_sensors: int = 0,
        voltage_sigma_v: float = 0.01,
        current_sigma_a: float = 0.5,
        temperature_sigma_c: float = 0.3,
        current_offset_a: float | None = None,
        voltage_quantum_v: float = 0.005,
        dropout_rate: float = 0.0,
        real_time: bool = False,
        max_frames: int | None = None,
        seed: int = 0,
        battery_id: str | None = None,
    ) -> None:
        super().__init__()
        self.battery = battery
        self.battery_id = battery_id or battery.battery_id
        self.plant = BatteryPlant(battery, track_states=False)
        self.state = battery.initial_state(
            soc=initial_soc, temperature_c=initial_temperature_c, ambient_c=ambient_c
        )
        self.ambient_c = ambient_c
        self.dt_s = dt_s
        self.duty_cycle = duty_cycle
        self.cooling = cooling
        self.n_cell_sensors = n_cell_sensors
        self.voltage_sigma_v = voltage_sigma_v
        self.current_sigma_a = current_sigma_a
        self.temperature_sigma_c = temperature_sigma_c
        self.voltage_quantum_v = voltage_quantum_v
        self.dropout_rate = dropout_rate
        #: When True, the source sleeps ``dt_s`` between frames. Off by default
        #: so tests and replays run at full speed.
        self.real_time = real_time
        self.max_frames = max_frames
        self.clock = SimulatedClock()
        self._rng = np.random.default_rng(seed)
        #: A fixed offset, drawn once: this is the error that integrates.
        self._current_offset = (
            current_offset_a
            if current_offset_a is not None
            else float(self._rng.normal(0.0, 0.3))
        )
        #: Per-cell capacity spread, drawn once, driving genuine imbalance.
        spread = battery.topology.cell.capacity_sigma
        self._cell_offsets = (
            self._rng.normal(0.0, spread, n_cell_sensors) if n_cell_sensors else np.empty(0)
        )
        self._k = 0

    @property
    def current_offset_a(self) -> float:
        """The (unknown to the estimator) current-sensor offset in this run."""
        return self._current_offset

    def _power(self) -> float:
        if callable(self.duty_cycle):
            return float(self.duty_cycle(self._k, self.state))
        return float(self.duty_cycle)

    def _cooling(self) -> float:
        if callable(self.cooling):
            return float(self.cooling(self._k, self.state))
        return float(self.cooling)

    def step(self) -> TelemetryFrame | None:
        """Advance the virtual battery one interval and produce a frame."""
        result = self.plant.step(
            self.state,
            Action(power_w=self._power(), cooling_fraction=self._cooling()),
            self.dt_s,
            ambient_c=self.ambient_c,
        )
        self.state = result.state
        self.clock.advance(self.dt_s)
        self._k += 1

        if self.dropout_rate > 0.0 and self._rng.random() < self.dropout_rate:
            return None

        v = self.state.voltage_v + self._rng.normal(0.0, self.voltage_sigma_v)
        if self.voltage_quantum_v > 0:
            v = round(v / self.voltage_quantum_v) * self.voltage_quantum_v
        i = self.state.current_a + self._current_offset + self._rng.normal(
            0.0, self.current_sigma_a
        )
        t = self.state.temperature_c + self._rng.normal(0.0, self.temperature_sigma_c)

        cells: list[float] = []
        if self.n_cell_sensors:
            per_cell = self.state.voltage_v / self.battery.topology.n_series
            slope = self.battery.chemistry.ocv.slope_at(self.state.soc)
            cells = [
                float(
                    per_cell
                    + offset * max(slope, 0.05)
                    + self._rng.normal(0.0, self.voltage_sigma_v)
                )
                for offset in self._cell_offsets
            ]

        return self._count(
            TelemetryFrame(
                battery_id=self.battery_id,
                timestamp=self.clock.now(),
                voltage_v=float(v),
                current_a=float(i),
                temperature_c=float(t),
                ambient_c=self.ambient_c,
                coolant_c=self.state.coolant_c,
                cell_voltages_v=cells,
                voltage_sigma_v=self.voltage_sigma_v,
                current_sigma_a=self.current_sigma_a,
                temperature_sigma_c=self.temperature_sigma_c,
                source=self.name,
                sequence=self._k,
            )
        )

    async def __aiter__(self) -> AsyncIterator[TelemetryFrame]:
        while not self.closed:
            if self.max_frames is not None and self._k >= self.max_frames:
                return
            frame = self.step()
            if frame is not None:
                yield frame
            if self.real_time:
                await asyncio.sleep(self.dt_s)
            else:
                await asyncio.sleep(0)

    def frames(self, n: int) -> list[TelemetryFrame]:
        """Synchronous helper: produce ``n`` frames, skipping dropouts."""
        out: list[TelemetryFrame] = []
        while len(out) < n:
            frame = self.step()
            if frame is not None:
                out.append(frame)
        return out


def drive_cycle(
    *, peak_w: float, period_steps: int = 600, regen_fraction: float = 0.3
) -> Callable[[int, object], float]:
    """A synthetic vehicle drive cycle: acceleration, cruise, braking, rest.

    Explicitly synthetic and not a standard cycle (WLTP, EPA and the rest are
    copyrighted test procedures). It exists to exercise the estimator and the
    optimiser with realistic dynamics -- sign changes, rest periods, regen --
    not to certify anything.
    """

    def profile(k: int, _state: object) -> float:
        phase = (k % period_steps) / period_steps
        if phase < 0.15:
            return peak_w * (phase / 0.15)
        if phase < 0.55:
            return peak_w * (0.55 + 0.25 * np.sin(2 * np.pi * (phase - 0.15) / 0.4))
        if phase < 0.75:
            return -peak_w * regen_fraction
        if phase < 0.9:
            return peak_w * 0.25
        return 0.0

    return profile


def storage_cycle(
    *, charge_w: float, discharge_w: float, period_steps: int = 2880
) -> Callable[[int, object], float]:
    """A daily stationary-storage cycle: charge overnight, discharge at peak."""

    def profile(k: int, _state: object) -> float:
        phase = (k % period_steps) / period_steps
        if phase < 0.25:
            return -charge_w
        if 0.65 <= phase < 0.85:
            return discharge_w
        return 0.0

    return profile


__all__ = ["SimulatedSource", "drive_cycle", "storage_cycle"]
