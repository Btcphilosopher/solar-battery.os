"""Push-based network sources: REST, WebSocket and MQTT.

All three share one shape: something outside the process delivers frames, and
the pipeline consumes them as an async iterator. :class:`QueueSource` provides
that bridge, and the three transports are thin adapters onto it.

The queue is **bounded and drops the oldest frame when full**. That choice is
deliberate and is the opposite of the usual default. An optimiser fed a growing
backlog is optimising against the past; if the consumer cannot keep up, the
right thing is to work on the newest state and count what was dropped, not to
fall further behind while memory grows.
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any, AsyncIterator, Callable

from ...core.exceptions import TelemetryError
from ...core.optional import require, try_import
from ..schema import TelemetryFrame
from .base import BaseSource

log = logging.getLogger(__name__)


class QueueSource(BaseSource):
    """An async queue of frames, fed by whatever transport is in front of it."""

    name = "queue"

    def __init__(self, *, maxsize: int = 256, drop_oldest: bool = True) -> None:
        super().__init__()
        self._queue: asyncio.Queue[TelemetryFrame | None] = asyncio.Queue(maxsize=maxsize)
        self.drop_oldest = drop_oldest
        self.dropped = 0

    def submit_nowait(self, frame: TelemetryFrame) -> bool:
        """Enqueue a frame without blocking. Returns False if it was dropped."""
        try:
            self._queue.put_nowait(frame)
            self._count(frame)
            return True
        except asyncio.QueueFull:
            if not self.drop_oldest:
                self.dropped += 1
                return False
            try:
                self._queue.get_nowait()
                self.dropped += 1
            except asyncio.QueueEmpty:  # pragma: no cover - race
                pass
            try:
                self._queue.put_nowait(frame)
                self._count(frame)
                return True
            except asyncio.QueueFull:  # pragma: no cover - race
                self.dropped += 1
                return False

    async def submit(self, frame: TelemetryFrame) -> None:
        await self._queue.put(frame)
        self._count(frame)

    @property
    def backlog(self) -> int:
        return self._queue.qsize()

    async def __aiter__(self) -> AsyncIterator[TelemetryFrame]:
        while True:
            frame = await self._queue.get()
            if frame is None:
                return
            yield frame

    async def close(self) -> None:
        await super().close()
        await self._queue.put(None)


class RESTSource(QueueSource):
    """Frames pushed in over HTTP.

    The FastAPI service exposes ``POST /telemetry`` and forwards the payload
    here. Kept as a queue rather than a callback so that a burst of requests
    cannot block the HTTP worker on optimisation work.
    """

    name = "rest"

    def ingest(self, payload: dict[str, Any]) -> bool:
        """Validate the payload shape and enqueue it."""
        try:
            frame = TelemetryFrame.model_validate({**payload, "source": self.name})
        except Exception as exc:  # noqa: BLE001 - payload is untrusted input
            raise TelemetryError(f"malformed telemetry payload: {exc}") from exc
        return self.submit_nowait(frame)


class WebSocketSource(QueueSource):
    """Frames arriving over a WebSocket connection.

    The server side is wired up in :mod:`batteryopt.api.app`; this class is the
    consumer end and is transport-agnostic, so it also serves a client
    connecting *out* to a vendor's telemetry socket.
    """

    name = "websocket"

    def ingest_text(self, message: str) -> bool:
        try:
            payload = json.loads(message)
        except json.JSONDecodeError as exc:
            raise TelemetryError(f"WebSocket message is not valid JSON: {exc}") from exc
        return self.ingest(payload)

    def ingest(self, payload: dict[str, Any]) -> bool:
        frame = TelemetryFrame.model_validate({**payload, "source": self.name})
        return self.submit_nowait(frame)

    async def consume(self, websocket: Any) -> None:
        """Read frames from an open WebSocket until it closes."""
        try:
            while not self.closed:
                message = await websocket.receive_text()
                self.ingest_text(message)
        except Exception as exc:  # noqa: BLE001 - transport errors are expected
            log.info("websocket telemetry connection ended: %s", exc)
        finally:
            await self.close()


class MQTTSource(QueueSource):
    """Frames arriving over MQTT.

    Requires ``batteryopt[mqtt]``. The topic is expected to carry one JSON frame
    per message; a decoder can be supplied for binary or vendor-specific
    payloads without subclassing.
    """

    name = "mqtt"

    def __init__(
        self,
        *,
        host: str = "localhost",
        port: int = 1883,
        topic: str = "batteryopt/telemetry",
        client_id: str = "batteryopt",
        decoder: Callable[[bytes], dict[str, Any]] | None = None,
        maxsize: int = 256,
    ) -> None:
        super().__init__(maxsize=maxsize)
        self.host = host
        self.port = port
        self.topic = topic
        self.client_id = client_id
        self.decoder = decoder or (lambda payload: json.loads(payload.decode("utf-8")))
        self._client: Any = None

    @staticmethod
    def available() -> bool:
        return try_import("paho") is not None

    def connect(self) -> None:
        """Connect and subscribe. Raises with install advice if paho is absent."""
        mqtt = require("paho")
        client = mqtt.Client(client_id=self.client_id)

        def on_message(_client: Any, _userdata: Any, message: Any) -> None:
            try:
                payload = self.decoder(message.payload)
                frame = TelemetryFrame.model_validate({**payload, "source": self.name})
                self.submit_nowait(frame)
            except Exception as exc:  # noqa: BLE001 - never kill the network thread
                log.warning("dropping malformed MQTT frame on %s: %s", message.topic, exc)

        client.on_message = on_message
        client.connect(self.host, self.port)
        client.subscribe(self.topic)
        client.loop_start()
        self._client = client

    async def close(self) -> None:
        if self._client is not None:
            try:
                self._client.loop_stop()
                self._client.disconnect()
            except Exception:  # pragma: no cover - shutdown races
                pass
            self._client = None
        await super().close()


__all__ = ["QueueSource", "RESTSource", "WebSocketSource", "MQTTSource"]
