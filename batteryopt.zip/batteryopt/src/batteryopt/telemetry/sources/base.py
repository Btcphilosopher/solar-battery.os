"""Telemetry source interface.

A source is an async iterator of :class:`~batteryopt.telemetry.schema.TelemetryFrame`.
That is the whole contract, and it is deliberately narrow: replaying a CSV,
subscribing to MQTT and stepping a simulated battery all look identical to the
pipeline, which is what makes simulation-first development work in practice
rather than only in principle.

Sources do not validate, estimate or interpret. They produce frames.
"""

from __future__ import annotations

from typing import AsyncIterator, Protocol, runtime_checkable

from ..schema import TelemetryFrame


@runtime_checkable
class TelemetrySource(Protocol):
    """Anything that yields telemetry frames."""

    name: str

    def __aiter__(self) -> AsyncIterator[TelemetryFrame]:
        ...

    async def close(self) -> None:
        """Release any transport resources. Must be idempotent."""
        ...


class BaseSource:
    """Shared bookkeeping for sources."""

    name = "source"

    def __init__(self) -> None:
        self._closed = False
        self._emitted = 0

    @property
    def emitted(self) -> int:
        return self._emitted

    @property
    def closed(self) -> bool:
        return self._closed

    async def close(self) -> None:
        self._closed = True

    def _count(self, frame: TelemetryFrame) -> TelemetryFrame:
        self._emitted += 1
        return frame


__all__ = ["TelemetrySource", "BaseSource"]
