"""Telemetry frame schema.

The wire format every source produces and the validation stage consumes. Kept
separate from :class:`~batteryopt.estimation.base.Measurement` on purpose: a
frame is *what arrived*, including whatever is missing, malformed or absent,
while a measurement is what survived validation and is fit to feed an
estimator. Collapsing the two would mean the estimator has to cope with nulls
and out-of-range values, and it would have nowhere to record that it did.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from ..estimation.base import Measurement


class TelemetryFrame(BaseModel):
    """One raw telemetry sample, exactly as received.

    Every field except the timestamp and battery id is optional, because real
    telemetry arrives incomplete: a CAN frame carries pack current but not cell
    voltages, an MQTT message may drop a field when a sensor faults.
    """

    model_config = ConfigDict(frozen=True, extra="allow")

    battery_id: str
    #: Seconds since the Unix epoch.
    timestamp: float

    voltage_v: float | None = None
    current_a: float | None = None
    temperature_c: float | None = None
    ambient_c: float | None = None
    coolant_c: float | None = None
    cell_voltages_v: list[float] = Field(default_factory=list)
    module_temperatures_c: list[float] = Field(default_factory=list)
    #: SOC and charge counter as reported by the BMS, if it has them. Inputs to
    #: fusion, never treated as ground truth.
    reported_soc: float | None = None
    reported_charge_ah: float | None = None
    reported_soh: float | None = None

    #: Sensor noise characteristics, when the hardware declares them.
    voltage_sigma_v: float = 0.01
    current_sigma_a: float = 0.5
    temperature_sigma_c: float = 0.5

    #: Which interface delivered this frame.
    source: str = "unknown"
    #: Sequence number, where the transport provides one. Gaps indicate loss.
    sequence: int | None = None
    meta: dict[str, Any] = Field(default_factory=dict)

    @property
    def complete(self) -> bool:
        """True when the three fields every estimator needs are present."""
        return (
            self.voltage_v is not None
            and self.current_a is not None
            and self.temperature_c is not None
        )

    def to_measurement(self) -> Measurement:
        """Convert to the estimator-facing type. Assumes validation has passed."""
        return Measurement(
            timestamp=self.timestamp,
            voltage_v=float(self.voltage_v or 0.0),
            current_a=float(self.current_a or 0.0),
            temperature_c=float(self.temperature_c or 25.0),
            ambient_c=self.ambient_c,
            coolant_c=self.coolant_c,
            cell_voltages_v=tuple(self.cell_voltages_v),
            module_temperatures_c=tuple(self.module_temperatures_c),
            reported_charge_ah=self.reported_charge_ah,
            reported_soc=self.reported_soc,
            voltage_sigma_v=self.voltage_sigma_v,
            current_sigma_a=self.current_sigma_a,
            temperature_sigma_c=self.temperature_sigma_c,
            meta=dict(self.meta),
        )

    def as_dict(self) -> dict[str, Any]:
        return self.model_dump(mode="json")


@dataclass(frozen=True, slots=True)
class FrameIssue:
    """One problem found in a frame."""

    field: str
    severity: str  # "reject" | "repair" | "warn"
    message: str
    original: Any = None
    replacement: Any = None

    def as_dict(self) -> dict[str, Any]:
        return {
            "field": self.field,
            "severity": self.severity,
            "message": self.message,
            "original": self.original,
            "replacement": self.replacement,
        }


@dataclass(slots=True)
class ValidationResult:
    """The outcome of validating one frame."""

    frame: TelemetryFrame | None
    issues: list[FrameIssue] = field(default_factory=list)
    accepted: bool = True
    repaired: bool = False

    @property
    def rejected(self) -> bool:
        return not self.accepted

    def reasons(self) -> list[str]:
        return [i.message for i in self.issues]

    def as_dict(self) -> dict[str, Any]:
        return {
            "accepted": self.accepted,
            "repaired": self.repaired,
            "issues": [i.as_dict() for i in self.issues],
        }


__all__ = ["TelemetryFrame", "FrameIssue", "ValidationResult"]
