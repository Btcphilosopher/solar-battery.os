"""BatteryOpt -- battery optimisation, simulation and decision engine.

BatteryOpt answers one question:

    Given the battery's present physical state, its future mission, the
    surrounding energy system and its configured constraints, what operating
    strategy produces the greatest useful outcome at the lowest lifetime cost?

It is **not** a battery management system. It sits above an existing BMS, EMS or
battery controller and returns recommendations; it never replaces independent
safety protection, and nothing in it is a substitute for one.

The progression, end to end::

    MEASURE -> ESTIMATE -> SIMULATE -> COMPARE -> OPTIMISE -> RECOMMEND -> MEASURE AGAIN

Quick start
-----------

.. code-block:: python

    from batteryopt import Battery, optimise
    from batteryopt.economics import Tariff

    battery = Battery.build(chemistry="nmc", cells_series=96, cells_parallel=4)
    state = battery.initial_state(soc=0.63, temperature_c=29.0)

    result = optimise(
        battery_state=state,
        battery=battery,
        demand=42_000.0,
        objective="ev",
        tariff=Tariff.time_of_use(peak_price=0.42, off_peak_price=0.09),
    )
    print(result.summary())

Everything runs without hardware. The core needs only NumPy, SciPy and
Pydantic; PyBaMM, OR-Tools, PyTorch, PostgreSQL, Redis and MQTT are optional and
degrade gracefully -- see :func:`batteryopt.core.optional.capabilities`.
"""

from __future__ import annotations

from .core.exceptions import (
    BatteryOptError,
    ConfigurationError,
    InfeasibleProblem,
    OptimisationError,
    SafetyViolation,
)
from .core.optional import capabilities
from .core.provenance import Provenance, Quantiles, Quantity
from .core.versioning import CODE_VERSION, MODEL_VERSION, version_report
from .economics.engine import EconomicConfig, EconomicEngine
from .economics.prices import PriceCurve, Tariff
from .models.battery import Battery
from .models.chemistry import (
    ChemistryParameters,
    available_chemistries,
    get_chemistry,
    register_chemistry,
)
from .models.fidelity import Fidelity
from .models.plant import Action, BatteryPlant, Trajectory
from .models.state import BatteryState, DegradationState
from .models.topology import Topology
from .optimisation.constraints import Constraint, ConstraintKind, ConstraintSet
from .optimisation.engine import OptimisationEngine, available_methods, optimise
from .optimisation.mpc import ModelPredictiveController
from .optimisation.objective import Objective, ObjectiveConfig, Outcome, available_presets, preset
from .optimisation.problem import Demand, Mission, OptimisationProblem, Recommendation
from .scenario.engine import Scenario, ScenarioEngine, ScenarioResult
from .twin.twin import DigitalTwin

__version__ = CODE_VERSION

__all__ = [
    "__version__",
    "CODE_VERSION",
    "MODEL_VERSION",
    "version_report",
    "capabilities",
    # models
    "Battery",
    "Topology",
    "BatteryState",
    "DegradationState",
    "BatteryPlant",
    "Action",
    "Trajectory",
    "Fidelity",
    "ChemistryParameters",
    "get_chemistry",
    "register_chemistry",
    "available_chemistries",
    # twin
    "DigitalTwin",
    # optimisation
    "optimise",
    "OptimisationEngine",
    "OptimisationProblem",
    "Recommendation",
    "Demand",
    "Mission",
    "Objective",
    "ObjectiveConfig",
    "Outcome",
    "preset",
    "available_presets",
    "available_methods",
    "Constraint",
    "ConstraintKind",
    "ConstraintSet",
    "ModelPredictiveController",
    "Scenario",
    "ScenarioEngine",
    "ScenarioResult",
    # economics
    "EconomicEngine",
    "EconomicConfig",
    "Tariff",
    "PriceCurve",
    # provenance
    "Provenance",
    "Quantity",
    "Quantiles",
    # errors
    "BatteryOptError",
    "ConfigurationError",
    "SafetyViolation",
    "OptimisationError",
    "InfeasibleProblem",
]
