"""Batch research mode (specification section 28).

Thousands of experiments, run reproducibly. Four shapes cover almost everything
a battery engineer wants to ask:

* :func:`parameter_sweep` -- grid over named parameters.
* :func:`monte_carlo` -- sample uncertain inputs, report the distribution.
* :func:`sensitivity` -- one-at-a-time and elementary-effects screening.
* :func:`compare_policies` -- rank operating policies by lifetime outcome.

Two properties are non-negotiable for research code and are built in:

* **Reproducibility.** Every experiment records its seed and the versions in
  force. Re-running the same design must produce the same numbers, and
  :meth:`SweepResult.digest` makes that checkable.
* **Failures are data.** An experiment that raises is recorded with its error
  rather than aborting the sweep. A sweep that dies on run 3,847 of 5,000 has
  wasted the whole run, and the failures are usually the interesting cases.
"""

from __future__ import annotations

import itertools
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable, Mapping, Sequence

import numpy as np

from ..core.numerics import EPS
from ..core.versioning import RunFingerprint, content_hash, version_report

log = logging.getLogger(__name__)


@dataclass(slots=True)
class Experiment:
    """One point in a design, with whatever it produced."""

    index: int
    parameters: dict[str, Any]
    outputs: dict[str, Any] = field(default_factory=dict)
    error: str | None = None
    seconds: float = 0.0

    @property
    def ok(self) -> bool:
        return self.error is None

    def as_dict(self) -> dict[str, Any]:
        return {
            "index": self.index,
            "parameters": self.parameters,
            "outputs": self.outputs,
            "error": self.error,
            "seconds": self.seconds,
        }


@dataclass(slots=True)
class SweepResult:
    """Every experiment in a design, plus the metadata to reproduce it."""

    name: str
    experiments: list[Experiment] = field(default_factory=list)
    seed: int | None = None
    design: dict[str, Any] = field(default_factory=dict)
    versions: dict[str, str] = field(default_factory=lambda: dict(version_report()))
    seconds: float = 0.0

    def __len__(self) -> int:
        return len(self.experiments)

    @property
    def successes(self) -> list[Experiment]:
        return [e for e in self.experiments if e.ok]

    @property
    def failures(self) -> list[Experiment]:
        return [e for e in self.experiments if not e.ok]

    @property
    def digest(self) -> str:
        """Hash of the design and versions -- not of the results."""
        return content_hash(
            {"name": self.name, "design": self.design, "seed": self.seed, "versions": self.versions}
        )

    def column(self, key: str) -> np.ndarray:
        """One output across all successful experiments."""
        return np.array(
            [e.outputs.get(key, np.nan) for e in self.successes], dtype=float
        )

    def parameter_column(self, key: str) -> np.ndarray:
        return np.array(
            [e.parameters.get(key, np.nan) for e in self.successes], dtype=float
        )

    def summary(self, keys: Sequence[str] | None = None) -> dict[str, Any]:
        keys = keys or sorted(
            {k for e in self.successes for k, v in e.outputs.items() if isinstance(v, (int, float))}
        )
        out: dict[str, Any] = {
            "name": self.name,
            "experiments": len(self),
            "successes": len(self.successes),
            "failures": len(self.failures),
            "seconds": self.seconds,
            "digest": self.digest,
        }
        for key in keys:
            values = self.column(key)
            values = values[np.isfinite(values)]
            if values.size:
                out[key] = {
                    "mean": float(values.mean()),
                    "std": float(values.std()),
                    "min": float(values.min()),
                    "p10": float(np.quantile(values, 0.10)),
                    "p50": float(np.quantile(values, 0.50)),
                    "p90": float(np.quantile(values, 0.90)),
                    "max": float(values.max()),
                }
        return out

    def to_rows(self) -> list[dict[str, Any]]:
        """Flatten to rows, ready for CSV or a dataframe."""
        rows = []
        for e in self.experiments:
            row: dict[str, Any] = {"index": e.index, "ok": e.ok, "error": e.error}
            row.update({f"in.{k}": v for k, v in e.parameters.items()})
            row.update({f"out.{k}": v for k, v in e.outputs.items()})
            rows.append(row)
        return rows

    def to_frame(self):  # pragma: no cover - optional dependency
        from ..core.optional import try_import

        pl = try_import("polars")
        rows = self.to_rows()
        return pl.DataFrame(rows) if pl else rows

    def table(self, keys: Sequence[str], *, limit: int = 20) -> str:
        header = f"{'#':>4}  " + "  ".join(f"{k:>14}" for k in keys)
        lines = [header, "-" * len(header)]
        for e in self.successes[:limit]:
            values = "  ".join(
                f"{e.outputs.get(k, float('nan')):>14.5g}"
                if isinstance(e.outputs.get(k), (int, float))
                else f"{str(e.outputs.get(k, '')):>14}"
                for k in keys
            )
            lines.append(f"{e.index:>4}  {values}")
        if len(self.successes) > limit:
            lines.append(f"... {len(self.successes) - limit} more")
        return "\n".join(lines)


def _run_design(
    name: str,
    design: Sequence[dict[str, Any]],
    run: Callable[[dict[str, Any]], Mapping[str, Any]],
    *,
    seed: int | None = None,
    design_meta: dict[str, Any] | None = None,
    progress_every: int = 0,
) -> SweepResult:
    started = time.perf_counter()
    result = SweepResult(name=name, seed=seed, design=design_meta or {})
    for index, parameters in enumerate(design):
        t0 = time.perf_counter()
        try:
            outputs = dict(run(parameters))
            experiment = Experiment(index, dict(parameters), outputs)
        except Exception as exc:  # noqa: BLE001 - a failed run is data, not a crash
            experiment = Experiment(index, dict(parameters), {}, error=f"{type(exc).__name__}: {exc}")
            log.debug("experiment %d failed: %s", index, exc)
        experiment.seconds = time.perf_counter() - t0
        result.experiments.append(experiment)
        if progress_every and (index + 1) % progress_every == 0:
            log.info("%s: %d/%d", name, index + 1, len(design))
    result.seconds = time.perf_counter() - started
    return result


def parameter_sweep(
    run: Callable[[dict[str, Any]], Mapping[str, Any]],
    grid: Mapping[str, Sequence[Any]],
    *,
    name: str = "parameter_sweep",
    fixed: Mapping[str, Any] | None = None,
    progress_every: int = 0,
) -> SweepResult:
    """Full factorial sweep over ``grid``.

    ``grid`` maps parameter names to the values to try. The design is the
    Cartesian product, in a deterministic order, so experiment ``k`` is the same
    point on every run.
    """
    keys = list(grid)
    combos = list(itertools.product(*(list(grid[k]) for k in keys)))
    design = [{**(fixed or {}), **dict(zip(keys, combo))} for combo in combos]
    return _run_design(
        name,
        design,
        run,
        design_meta={"grid": {k: list(v) for k, v in grid.items()}, "fixed": dict(fixed or {})},
        progress_every=progress_every,
    )


def monte_carlo(
    run: Callable[[dict[str, Any]], Mapping[str, Any]],
    distributions: Mapping[str, Callable[[np.random.Generator], Any]],
    *,
    n: int = 500,
    seed: int = 0,
    name: str = "monte_carlo",
    fixed: Mapping[str, Any] | None = None,
    progress_every: int = 0,
) -> SweepResult:
    """Sample uncertain inputs and report the distribution of outcomes.

    ``distributions`` maps parameter names to samplers taking a NumPy
    generator. Passing the generator rather than letting samplers use global
    randomness is what makes the whole sweep reproducible from one seed.
    """
    rng = np.random.default_rng(seed)
    design = [
        {**(fixed or {}), **{k: sampler(rng) for k, sampler in distributions.items()}}
        for _ in range(n)
    ]
    return _run_design(
        name,
        design,
        run,
        seed=seed,
        design_meta={"n": n, "parameters": sorted(distributions)},
        progress_every=progress_every,
    )


def sensitivity(
    run: Callable[[dict[str, Any]], Mapping[str, Any]],
    baseline: Mapping[str, float],
    *,
    output_key: str,
    relative_step: float = 0.1,
    name: str = "sensitivity",
) -> dict[str, Any]:
    """One-at-a-time sensitivity around a baseline point.

    Reports the elasticity of ``output_key`` to each parameter: the fractional
    change in output per fractional change in input. Elasticity rather than raw
    gradient because it is unit-free, so a sensitivity to temperature and one to
    price can be ranked against each other.

    One-at-a-time screening cannot see interactions, and says so in its own
    output: :func:`morris_screening` is the tool for that.
    """
    base_outputs = dict(run(dict(baseline)))
    base_value = float(base_outputs.get(output_key, np.nan))
    results: dict[str, Any] = {
        "baseline": dict(baseline),
        "baseline_output": base_value,
        "output_key": output_key,
        "method": "one-at-a-time elasticity",
        "caveat": (
            "One-at-a-time screening measures local sensitivity only and cannot "
            "detect interactions between parameters; use morris_screening for that."
        ),
        "elasticities": {},
    }
    for key, value in baseline.items():
        step = abs(float(value)) * relative_step or relative_step
        up = dict(baseline)
        up[key] = float(value) + step
        down = dict(baseline)
        down[key] = float(value) - step
        try:
            up_value = float(dict(run(up)).get(output_key, np.nan))
            down_value = float(dict(run(down)).get(output_key, np.nan))
        except Exception as exc:  # noqa: BLE001
            results["elasticities"][key] = {"error": str(exc)}
            continue
        gradient = (up_value - down_value) / (2.0 * step)
        elasticity = (
            gradient * float(value) / base_value
            if abs(base_value) > EPS and abs(float(value)) > EPS
            else float("nan")
        )
        results["elasticities"][key] = {
            "gradient": gradient,
            "elasticity": elasticity,
            "up": up_value,
            "down": down_value,
        }
    ranked = sorted(
        (
            (k, abs(v.get("elasticity", 0.0)))
            for k, v in results["elasticities"].items()
            if isinstance(v.get("elasticity"), float) and np.isfinite(v["elasticity"])
        ),
        key=lambda kv: kv[1],
        reverse=True,
    )
    results["ranked"] = [k for k, _ in ranked]
    results["name"] = name
    return results


def morris_screening(
    run: Callable[[dict[str, Any]], Mapping[str, Any]],
    bounds: Mapping[str, tuple[float, float]],
    *,
    output_key: str,
    trajectories: int = 10,
    levels: int = 4,
    seed: int = 0,
) -> dict[str, Any]:
    """Morris elementary-effects screening: cheap, and it does see interactions.

    For each parameter it reports ``mu_star`` (mean absolute effect -- overall
    importance) and ``sigma`` (spread of effects -- evidence of interaction or
    non-linearity). A parameter with a large ``sigma`` relative to ``mu_star``
    behaves differently in different parts of the space, which is precisely
    what one-at-a-time analysis cannot tell you.
    """
    rng = np.random.default_rng(seed)
    keys = list(bounds)
    delta = levels / (2.0 * (levels - 1))
    effects: dict[str, list[float]] = {k: [] for k in keys}

    for _ in range(trajectories):
        base = {k: rng.integers(0, levels) / (levels - 1) for k in keys}

        def evaluate(point: Mapping[str, float]) -> float:
            scaled = {
                k: bounds[k][0] + point[k] * (bounds[k][1] - bounds[k][0]) for k in keys
            }
            return float(dict(run(scaled)).get(output_key, np.nan))

        current = dict(base)
        current_value = evaluate(current)
        for key in rng.permutation(keys):
            step = delta if current[str(key)] + delta <= 1.0 else -delta
            nxt = dict(current)
            nxt[str(key)] = current[str(key)] + step
            try:
                next_value = evaluate(nxt)
            except Exception:  # noqa: BLE001
                continue
            span = bounds[str(key)][1] - bounds[str(key)][0]
            if abs(span) > EPS:
                effects[str(key)].append((next_value - current_value) / (step * span))
            current, current_value = nxt, next_value

    report = {}
    for key, values in effects.items():
        arr = np.asarray([v for v in values if np.isfinite(v)], dtype=float)
        report[key] = {
            "mu_star": float(np.mean(np.abs(arr))) if arr.size else float("nan"),
            "sigma": float(np.std(arr)) if arr.size else float("nan"),
            "samples": int(arr.size),
        }
    ranked = sorted(
        report, key=lambda k: report[k]["mu_star"] if np.isfinite(report[k]["mu_star"]) else -1,
        reverse=True,
    )
    return {
        "method": "Morris elementary effects",
        "output_key": output_key,
        "trajectories": trajectories,
        "effects": report,
        "ranked": ranked,
        "interpretation": (
            "mu_star ranks overall importance; a large sigma relative to mu_star "
            "means the parameter's effect depends on where you are in the space, "
            "i.e. it interacts with something else."
        ),
    }


__all__ = [
    "Experiment",
    "SweepResult",
    "parameter_sweep",
    "monte_carlo",
    "sensitivity",
    "morris_screening",
]
