"""Prepared studies: the comparisons the specification asks for by name.

Section 28's worked example is a temperature-by-strategy grid:

.. code-block:: text

    Compare  LOW / NORMAL / HIGH TEMPERATURE
    across   FAST / STANDARD / ECO charging strategies

These functions build and run those designs, so that the common questions are
one call rather than one script each -- and so that the *same* design is used
every time, which is what makes results comparable between runs and between
people.
"""

from __future__ import annotations

from typing import Any, Mapping, Sequence

import numpy as np

from ..applications.charging import SmartCharger
from ..applications.lifetime import LifetimeOptimiser, OperatingPolicy, standard_policies
from ..economics.prices import Tariff
from ..models.battery import Battery
from ..optimisation.engine import OptimisationEngine
from .sweeps import SweepResult, monte_carlo, parameter_sweep


def charging_strategy_study(
    battery: Battery,
    *,
    temperatures_c: Sequence[float] = (0.0, 25.0, 40.0),
    rate_fractions: Sequence[float] = (1.0, 0.6, 0.35),
    start_soc: float = 0.2,
    target_soc: float = 0.8,
    deadline_s: float = 4 * 3600.0,
    tariff: Tariff | None = None,
    objective: str = "balanced",
) -> SweepResult:
    """Charging strategy against ambient temperature (section 28's example).

    The interesting result is not that fast charging is worse -- it is *how much*
    worse, and how sharply that changes with temperature. Cold fast charging is
    the case that separates a degradation-aware optimiser from a rule of thumb.
    """
    engine = OptimisationEngine(battery, objective=objective, tariff=tariff)
    charger = SmartCharger(engine, dt_s=300.0)

    def run(params: dict[str, Any]) -> Mapping[str, Any]:
        temperature = float(params["temperature_c"])
        fraction = float(params["rate_fraction"])
        state = battery.initial_state(
            soc=start_soc, temperature_c=temperature, ambient_c=temperature
        )
        saved = charger.rate_fractions
        charger.rate_fractions = (fraction,)
        try:
            plan = charger.plan(
                state,
                target_soc=target_soc,
                deadline_s=deadline_s,
                tariff=tariff,
                ambient_c=temperature,
                allow_precondition=False,
            )
        finally:
            charger.rate_fractions = saved
        return {
            "duration_min": plan.duration_s / 60.0,
            "energy_kwh": plan.energy_delivered_wh / 1000.0,
            "energy_cost": plan.energy_cost,
            "degradation_pct": plan.estimated_degradation * 100.0,
            "efficiency_pct": plan.estimated_efficiency * 100.0,
            "peak_temperature_c": plan.peak_temperature_c,
            "reached_target": float(plan.target_soc >= target_soc - 0.02),
        }

    return parameter_sweep(
        run,
        {"temperature_c": list(temperatures_c), "rate_fraction": list(rate_fractions)},
        name="charging_strategy_by_temperature",
    )


def policy_lifetime_study(
    battery: Battery,
    *,
    policies: Sequence[OperatingPolicy] | None = None,
    cycles_per_year: Sequence[float] = (150.0, 300.0, 450.0),
    energy_value_per_kwh: float = 0.15,
    energy_cost_per_kwh: float = 0.08,
) -> SweepResult:
    """Lifetime energy and profit across operating policies and duty levels."""
    optimiser = LifetimeOptimiser(battery)
    base_policies = list(policies or standard_policies())
    by_name = {p.name: p for p in base_policies}

    def run(params: dict[str, Any]) -> Mapping[str, Any]:
        policy = by_name[params["policy"]]
        adjusted = OperatingPolicy(
            **{**policy.as_dict(), "cycles_per_year": float(params["cycles_per_year"])}
        )
        result = optimiser.simulate(
            adjusted,
            energy_value_per_kwh=energy_value_per_kwh,
            energy_cost_per_kwh=energy_cost_per_kwh,
        )
        return {
            "lifetime_years": result.lifetime_years,
            "lifetime_energy_mwh": result.lifetime_energy_wh / 1e6,
            "cost_per_kwh": result.cost_per_kwh_delivered,
            "lifetime_profit": result.lifetime_profit,
        }

    return parameter_sweep(
        run,
        {"policy": [p.name for p in base_policies], "cycles_per_year": list(cycles_per_year)},
        name="policy_lifetime",
    )


def mission_reliability_study(
    battery: Battery,
    *,
    target_soc: float = 0.8,
    mission_energy_wh: float = 45_000.0,
    energy_sigma: float = 0.12,
    temperature_mean_c: float = 10.0,
    temperature_sigma_c: float = 8.0,
    n: int = 400,
    seed: int = 0,
) -> SweepResult:
    """Monte Carlo over mission energy and weather: does the plan actually hold?

    This is the study that turns "charge to 80 %" into a reliability statement.
    Both the energy requirement and the ambient temperature are sampled, and
    temperature enters twice -- it raises consumption and lowers what the pack
    can deliver -- which is why the failure rate is more sensitive to weather
    than a single-factor analysis suggests.
    """
    from ..applications.mission import temperature_energy_factor

    reserve_soc = 0.05

    def run(params: dict[str, Any]) -> Mapping[str, Any]:
        ambient = float(params["ambient_c"])
        required = float(params["mission_energy_wh"]) * temperature_energy_factor(ambient)
        available = battery.energy_between(reserve_soc, target_soc)
        shortfall = max(0.0, required - available)
        return {
            "required_wh": required,
            "available_wh": available,
            "shortfall_wh": shortfall,
            "failed": float(shortfall > 0.0),
            "margin_wh": available - required,
        }

    return monte_carlo(
        run,
        {
            "mission_energy_wh": lambda rng: float(
                rng.normal(mission_energy_wh, mission_energy_wh * energy_sigma)
            ),
            "ambient_c": lambda rng: float(rng.normal(temperature_mean_c, temperature_sigma_c)),
        },
        n=n,
        seed=seed,
        name="mission_reliability",
    )


def chemistry_comparison_study(
    *,
    chemistries: Sequence[str] = ("nmc", "lfp", "nca", "sodium_ion", "lto"),
    target_energy_kwh: float = 100.0,
    target_voltage: float = 400.0,
    cycles_per_year: float = 300.0,
    depth_of_discharge: float = 0.8,
    temperature_c: float = 30.0,
) -> SweepResult:
    """Which chemistry delivers most lifetime energy for a given duty?

    Sized to the same energy and voltage so the comparison is like for like.
    The answer is duty-dependent and often surprises: LFP's flatter degradation
    beats NMC's higher energy density over a heavy cycling duty, and reverses
    when the duty is light and calendar ageing dominates.
    """
    from ..models.topology import Topology

    def run(params: dict[str, Any]) -> Mapping[str, Any]:
        chemistry = str(params["chemistry"])
        topology = Topology.sized_for(
            chemistry=chemistry,
            target_energy_kwh=target_energy_kwh,
            target_voltage=target_voltage,
        )
        battery = Battery(topology=topology, battery_id=f"study-{chemistry}")
        optimiser = LifetimeOptimiser(battery)
        policy = OperatingPolicy(
            name=chemistry,
            cycles_per_year=cycles_per_year,
            depth_of_discharge=depth_of_discharge,
            c_rate=0.5,
            temperature_c=temperature_c,
            mean_soc=0.55,
        )
        result = optimiser.simulate(policy)
        return {
            "installed_kwh": battery.nominal_energy_wh / 1000.0,
            "lifetime_years": result.lifetime_years,
            "lifetime_energy_mwh": result.lifetime_energy_wh / 1e6,
            "cost_per_kwh": result.cost_per_kwh_delivered,
            "cells": topology.cell_count,
        }

    return parameter_sweep(
        run, {"chemistry": list(chemistries)}, name="chemistry_comparison"
    )


def temperature_policy_study(
    battery: Battery,
    *,
    temperatures_c: Sequence[float] = (10.0, 20.0, 25.0, 30.0, 35.0, 40.0),
    cycles_per_year: float = 300.0,
    depth_of_discharge: float = 0.7,
) -> SweepResult:
    """Lifetime energy against operating temperature.

    Produces the U-shaped curve every battery engineer expects and few systems
    actually exploit: too cold costs power and plates lithium, too hot costs
    calendar life, and the optimum sits in a fairly narrow band.
    """
    optimiser = LifetimeOptimiser(battery)

    def run(params: dict[str, Any]) -> Mapping[str, Any]:
        policy = OperatingPolicy(
            name=f"{params['temperature_c']:.0f}C",
            cycles_per_year=cycles_per_year,
            depth_of_discharge=depth_of_discharge,
            c_rate=0.5,
            temperature_c=float(params["temperature_c"]),
            mean_soc=0.55,
        )
        result = optimiser.simulate(policy)
        return {
            "lifetime_years": result.lifetime_years,
            "lifetime_energy_mwh": result.lifetime_energy_wh / 1e6,
            "cost_per_kwh": result.cost_per_kwh_delivered,
        }

    return parameter_sweep(
        run, {"temperature_c": list(temperatures_c)}, name="temperature_policy"
    )


__all__ = [
    "charging_strategy_study",
    "policy_lifetime_study",
    "mission_reliability_study",
    "chemistry_comparison_study",
    "temperature_policy_study",
]
