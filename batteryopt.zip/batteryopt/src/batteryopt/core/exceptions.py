"""Exception hierarchy for BatteryOpt.

The hierarchy separates three failure classes that callers treat differently:

* :class:`ConfigurationError` -- the operator asked for something incoherent.
  Fail fast at start-up; never at 3 a.m. in the control loop.
* :class:`SafetyViolation` -- an operating point breached a hard constraint.
  This is never recoverable by relaxing the objective; it aborts the run.
* :class:`OptimisationError` / :class:`InfeasibleProblem` -- the solver could
  not find a point. Callers fall back to a safe default action.
"""

from __future__ import annotations

from typing import Any


class BatteryOptError(Exception):
    """Base class for every error raised by BatteryOpt."""


class ConfigurationError(BatteryOptError):
    """A configuration object is missing, malformed or self-contradictory."""


class ChemistryNotFound(ConfigurationError):
    """No chemistry is registered under the requested identifier."""

    def __init__(self, name: str, available: list[str] | None = None) -> None:
        self.name = name
        self.available = available or []
        hint = f" Available: {', '.join(sorted(self.available))}." if self.available else ""
        super().__init__(f"Unknown chemistry {name!r}.{hint}")


class TopologyError(ConfigurationError):
    """A pack/module/cell topology is inconsistent."""


class SafetyViolation(BatteryOptError):
    """A hard physical or safety constraint was breached.

    Raised only by the final guard in the optimisation pipeline and by
    explicit assertion helpers. The optimiser itself never *returns* a
    violating point -- it raises, so the fault is loud rather than silent.
    """

    def __init__(self, message: str, violations: list[Any] | None = None) -> None:
        self.violations = violations or []
        super().__init__(message)


class OptimisationError(BatteryOptError):
    """The optimiser failed to produce a usable result."""


class InfeasibleProblem(OptimisationError):
    """The feasible set is empty under the configured hard constraints."""

    def __init__(self, message: str, limiting: str | None = None) -> None:
        self.limiting = limiting
        super().__init__(message)


class SolverUnavailable(OptimisationError):
    """A requested solver backend is not installed in this environment."""

    def __init__(self, backend: str, extra: str) -> None:
        self.backend = backend
        super().__init__(
            f"Optimisation backend {backend!r} is not available. "
            f"Install it with: pip install 'batteryopt[{extra}]'"
        )


class ModelError(BatteryOptError):
    """A physical model failed to evaluate or diverged."""


class NumericalInstability(ModelError):
    """A model produced a non-finite or physically impossible state."""


class TelemetryError(BatteryOptError):
    """Telemetry could not be ingested."""


class ValidationError(TelemetryError):
    """A telemetry frame failed validation and was rejected or repaired."""

    def __init__(self, message: str, field: str | None = None, value: Any = None) -> None:
        self.field = field
        self.value = value
        super().__init__(message)


class PersistenceError(BatteryOptError):
    """A storage backend rejected an operation."""


class ImmutabilityError(PersistenceError):
    """An attempt was made to mutate append-only data (raw telemetry)."""


__all__ = [
    "BatteryOptError",
    "ConfigurationError",
    "ChemistryNotFound",
    "TopologyError",
    "SafetyViolation",
    "OptimisationError",
    "InfeasibleProblem",
    "SolverUnavailable",
    "ModelError",
    "NumericalInstability",
    "TelemetryError",
    "ValidationError",
    "PersistenceError",
    "ImmutabilityError",
]
