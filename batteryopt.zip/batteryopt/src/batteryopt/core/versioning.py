"""Version stamps and run fingerprints for reproducible optimisation.

Section 26 of the specification requires that every optimisation result can be
reproduced. That needs four things recorded alongside the answer: the code
version, the model version, the configuration version, and a content hash of
the actual inputs and constraints used. :class:`RunFingerprint` bundles them.

The fingerprint is a SHA-256 over a canonical JSON encoding, so two runs on
different machines that saw identical inputs produce identical digests.
"""

from __future__ import annotations

import hashlib
import json
import platform
from dataclasses import dataclass, field
from typing import Any, Mapping

#: Version of the BatteryOpt package itself.
CODE_VERSION = "0.1.0"

#: Version of the physical model formulations (ECM, thermal, degradation).
#: Bump whenever a model's equations or default coefficients change, because
#: stored results computed with an older model are no longer comparable.
MODEL_VERSION = "models-2026.08.1"

#: Version of the optimisation formulation (objective terms, constraint set
#: semantics, scenario generation rules).
OPTIMISER_VERSION = "opt-2026.08.1"

#: Schema version for persisted records.
SCHEMA_VERSION = "schema-3"


def canonical_json(obj: Any) -> str:
    """Deterministic JSON encoding: sorted keys, no whitespace jitter.

    NaN and +/-Infinity are rejected, because they do not round-trip through
    strict JSON and would silently corrupt a reproducibility hash.
    """
    return json.dumps(
        obj,
        sort_keys=True,
        separators=(",", ":"),
        default=_json_default,
        allow_nan=False,
    )


def _json_default(obj: Any) -> Any:
    if hasattr(obj, "as_dict"):
        return obj.as_dict()
    if hasattr(obj, "model_dump"):
        return obj.model_dump(mode="json")
    if hasattr(obj, "tolist"):  # numpy arrays / scalars
        return obj.tolist()
    if isinstance(obj, (set, frozenset)):
        return sorted(obj)
    if hasattr(obj, "value") and hasattr(obj, "name"):  # Enum
        return obj.value
    raise TypeError(f"cannot canonicalise {type(obj).__name__} for fingerprinting")


def content_hash(obj: Any) -> str:
    """SHA-256 of the canonical JSON encoding of ``obj``, hex-encoded."""
    return hashlib.sha256(canonical_json(obj).encode("utf-8")).hexdigest()


@dataclass(frozen=True, slots=True)
class RunFingerprint:
    """Everything needed to reproduce a single optimisation run."""

    code_version: str = CODE_VERSION
    model_version: str = MODEL_VERSION
    optimiser_version: str = OPTIMISER_VERSION
    schema_version: str = SCHEMA_VERSION
    #: Hash of the caller-supplied inputs (state, demand, forecasts).
    input_hash: str = ""
    #: Hash of the active hard-constraint set.
    constraint_hash: str = ""
    #: Hash of the objective configuration (weights, normalisation).
    objective_hash: str = ""
    #: Seed used for any stochastic component; ``None`` if fully deterministic.
    seed: int | None = None
    #: Interpreter and platform, recorded because floating-point results can
    #: differ across BLAS builds.
    runtime: str = field(
        default_factory=lambda: f"python{platform.python_version()}-{platform.machine()}"
    )

    @classmethod
    def build(
        cls,
        *,
        inputs: Any,
        constraints: Any,
        objective: Any,
        seed: int | None = None,
    ) -> "RunFingerprint":
        return cls(
            input_hash=content_hash(inputs),
            constraint_hash=content_hash(constraints),
            objective_hash=content_hash(objective),
            seed=seed,
        )

    @property
    def digest(self) -> str:
        """A single hash covering versions, inputs, constraints and objective."""
        return hashlib.sha256(
            "|".join(
                [
                    self.code_version,
                    self.model_version,
                    self.optimiser_version,
                    self.schema_version,
                    self.input_hash,
                    self.constraint_hash,
                    self.objective_hash,
                    str(self.seed),
                ]
            ).encode("utf-8")
        ).hexdigest()

    def matches(self, other: "RunFingerprint") -> bool:
        """True when two runs should, by construction, produce the same answer.

        ``runtime`` is deliberately excluded: a different machine is expected
        to reproduce the result to within floating-point tolerance.
        """
        return self.digest == other.digest

    def as_dict(self) -> dict[str, Any]:
        return {
            "code_version": self.code_version,
            "model_version": self.model_version,
            "optimiser_version": self.optimiser_version,
            "schema_version": self.schema_version,
            "input_hash": self.input_hash,
            "constraint_hash": self.constraint_hash,
            "objective_hash": self.objective_hash,
            "seed": self.seed,
            "runtime": self.runtime,
            "digest": self.digest,
        }


def version_report() -> Mapping[str, str]:
    """Human-readable version summary, surfaced by the API and the CLI."""
    return {
        "code": CODE_VERSION,
        "models": MODEL_VERSION,
        "optimiser": OPTIMISER_VERSION,
        "schema": SCHEMA_VERSION,
        "python": platform.python_version(),
        "platform": platform.platform(),
    }


__all__ = [
    "CODE_VERSION",
    "MODEL_VERSION",
    "OPTIMISER_VERSION",
    "SCHEMA_VERSION",
    "RunFingerprint",
    "canonical_json",
    "content_hash",
    "version_report",
]
