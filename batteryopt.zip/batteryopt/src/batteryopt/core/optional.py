"""Optional-dependency handling.

BatteryOpt's core runs on NumPy, SciPy and Pydantic alone. PyBaMM, OR-Tools,
PyTorch, PostgreSQL, Redis, MQTT and Numba are all optional accelerants or
integrations. Every one of them is reached through this module so that:

1. an import of :mod:`batteryopt` never fails because of a missing extra;
2. capability can be queried and reported (the API exposes ``/capabilities``);
3. the fallback path is explicit in the code, not an incidental ``except``.

Nothing in the real-time optimisation path requires an optional dependency.
"""

from __future__ import annotations

import importlib
import logging
from dataclasses import dataclass
from functools import lru_cache
from types import ModuleType

log = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class OptionalDependency:
    """Description of one optional dependency."""

    module: str
    extra: str
    purpose: str
    #: What BatteryOpt does instead when the dependency is absent.
    fallback: str


REGISTRY: dict[str, OptionalDependency] = {
    "pybamm": OptionalDependency(
        module="pybamm",
        extra="physics",
        purpose="DETAILED/RESEARCH fidelity electrochemical models (DFN, SPMe)",
        fallback="equivalent-circuit model with diffusion-lag RC branches",
    ),
    "ortools": OptionalDependency(
        module="ortools",
        extra="solvers",
        purpose="MILP scheduling for arbitrage and grid-service commitment",
        fallback="SciPy HiGHS linear programme with relaxed integrality",
    ),
    "torch": OptionalDependency(
        module="torch",
        extra="ml",
        purpose="learned residual forecasters for load and price",
        fallback="statistical forecasters (seasonal-naive, EWMA, harmonic regression)",
    ),
    "polars": OptionalDependency(
        module="polars",
        extra="frames",
        purpose="columnar telemetry replay and batch research frames",
        fallback="NumPy structured arrays and plain dictionaries",
    ),
    "psycopg": OptionalDependency(
        module="psycopg",
        extra="db",
        purpose="PostgreSQL persistence",
        fallback="in-memory repository with identical interface",
    ),
    "redis": OptionalDependency(
        module="redis",
        extra="db",
        purpose="shared cache for surrogate models and hot state",
        fallback="process-local LRU cache",
    ),
    "fastapi": OptionalDependency(
        module="fastapi",
        extra="api",
        purpose="HTTP/WebSocket service and dashboard",
        fallback="library and CLI use only",
    ),
    "paho": OptionalDependency(
        module="paho.mqtt.client",
        extra="mqtt",
        purpose="MQTT telemetry ingestion",
        fallback="simulated, CSV-replay, REST and WebSocket sources",
    ),
    "numba": OptionalDependency(
        module="numba",
        extra="accel",
        purpose="JIT compilation of inner simulation loops",
        fallback="vectorised NumPy kernels",
    ),
}


@lru_cache(maxsize=None)
def try_import(name: str) -> ModuleType | None:
    """Import ``name`` (a registry key or module path); ``None`` if absent.

    Results are cached, so a missing dependency costs one failed import per
    process rather than one per call in a control loop.
    """
    module_path = REGISTRY[name].module if name in REGISTRY else name
    try:
        return importlib.import_module(module_path)
    except Exception as exc:  # noqa: BLE001 - a broken optional dep must not crash us
        log.debug("optional dependency %s unavailable: %s", module_path, exc)
        return None


def have(name: str) -> bool:
    """True when the optional dependency ``name`` can be imported."""
    return try_import(name) is not None


def require(name: str) -> ModuleType:
    """Import ``name`` or raise :class:`SolverUnavailable` with install advice."""
    mod = try_import(name)
    if mod is None:
        from .exceptions import SolverUnavailable

        dep = REGISTRY.get(name)
        raise SolverUnavailable(name, dep.extra if dep else name)
    return mod


def capabilities() -> dict[str, dict[str, object]]:
    """Report which optional capabilities are active in this process."""
    return {
        key: {
            "available": have(key),
            "extra": dep.extra,
            "purpose": dep.purpose,
            "fallback_in_use": None if have(key) else dep.fallback,
        }
        for key, dep in REGISTRY.items()
    }


def capability_summary() -> str:
    """One-line-per-dependency text summary, used by the CLI."""
    lines = []
    for key, dep in sorted(REGISTRY.items()):
        mark = "yes" if have(key) else "no "
        detail = dep.purpose if have(key) else f"fallback: {dep.fallback}"
        lines.append(f"  [{mark}] {key:<10} {detail}")
    return "\n".join(lines)


__all__ = [
    "OptionalDependency",
    "REGISTRY",
    "try_import",
    "have",
    "require",
    "capabilities",
    "capability_summary",
]
