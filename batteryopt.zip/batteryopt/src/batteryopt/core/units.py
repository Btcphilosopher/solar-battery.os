"""Unit conventions for BatteryOpt.

BatteryOpt uses SI-derived engineering units throughout. Every public function
documents its units; there is no implicit conversion anywhere in the hot path.

Canonical units
---------------
=====================  ==========================================
Quantity               Unit
=====================  ==========================================
Time                   second (s); horizons expressed in seconds
Energy                 watt-hour (Wh) for capacity/throughput,
                       joule (J) only inside thermal integration
Power                  watt (W)
Voltage                volt (V)
Current                ampere (A)
Charge capacity        ampere-hour (Ah)
Temperature            degree Celsius (degC) at the API boundary,
                       kelvin (K) inside Arrhenius terms
Resistance             ohm (Ohm)
Thermal capacity       joule per kelvin (J/K)
Thermal conductance    watt per kelvin (W/K)
Price                  currency per kilowatt-hour (ccy/kWh)
=====================  ==========================================

Sign convention
---------------
**Positive current and positive power mean energy leaving the battery
(discharge). Negative means energy entering the battery (charge).**

This convention is applied without exception. A recommendation of
``+36_000 W`` is a 36 kW discharge; ``-11_000 W`` is an 11 kW charge.
Helper predicates :func:`is_charging` / :func:`is_discharging` should be used
rather than open-coded comparisons so that the convention stays greppable.
"""

from __future__ import annotations

from typing import Final

# ---------------------------------------------------------------------------
# Physical constants
# ---------------------------------------------------------------------------

#: Ideal gas constant, J/(mol*K).
GAS_CONSTANT: Final[float] = 8.314462618

#: Faraday constant, C/mol.
FARADAY: Final[float] = 96485.33212

#: Zero degrees Celsius expressed in kelvin.
KELVIN_OFFSET: Final[float] = 273.15

#: Seconds in an hour, used to convert between Wh/Ah and J/C.
SECONDS_PER_HOUR: Final[float] = 3600.0

#: Seconds in a (Julian) day and year, used by calendar-ageing models.
SECONDS_PER_DAY: Final[float] = 86400.0
SECONDS_PER_YEAR: Final[float] = 365.25 * SECONDS_PER_DAY


# ---------------------------------------------------------------------------
# Conversions
# ---------------------------------------------------------------------------


def celsius_to_kelvin(t_c: float) -> float:
    """Convert degrees Celsius to kelvin."""
    return t_c + KELVIN_OFFSET


def kelvin_to_celsius(t_k: float) -> float:
    """Convert kelvin to degrees Celsius."""
    return t_k - KELVIN_OFFSET


def wh_to_joule(wh: float) -> float:
    """Convert watt-hours to joules."""
    return wh * SECONDS_PER_HOUR


def joule_to_wh(j: float) -> float:
    """Convert joules to watt-hours."""
    return j / SECONDS_PER_HOUR


def c_rate_to_current(c_rate: float, capacity_ah: float) -> float:
    """Convert a C-rate to a current in amperes for a given capacity."""
    return c_rate * capacity_ah


def current_to_c_rate(current_a: float, capacity_ah: float) -> float:
    """Convert a current in amperes to a C-rate for a given capacity.

    Returns ``0.0`` for a non-positive capacity rather than raising, so that
    degenerate/end-of-life batteries do not blow up diagnostic code paths.
    """
    if capacity_ah <= 0.0:
        return 0.0
    return current_a / capacity_ah


# ---------------------------------------------------------------------------
# Sign-convention helpers
# ---------------------------------------------------------------------------

#: Currents/powers with magnitude below this are treated as rest.
REST_TOLERANCE_W: Final[float] = 1e-9


def is_charging(power_or_current: float, tol: float = REST_TOLERANCE_W) -> bool:
    """True when the signed power/current represents charging (negative)."""
    return power_or_current < -tol


def is_discharging(power_or_current: float, tol: float = REST_TOLERANCE_W) -> bool:
    """True when the signed power/current represents discharging (positive)."""
    return power_or_current > tol


def is_resting(power_or_current: float, tol: float = REST_TOLERANCE_W) -> bool:
    """True when the signed power/current is within the rest tolerance."""
    return abs(power_or_current) <= tol


def mode_of(power_or_current: float, tol: float = REST_TOLERANCE_W) -> str:
    """Return ``"charge"``, ``"discharge"`` or ``"rest"`` for a signed value."""
    if is_charging(power_or_current, tol):
        return "charge"
    if is_discharging(power_or_current, tol):
        return "discharge"
    return "rest"


__all__ = [
    "GAS_CONSTANT",
    "FARADAY",
    "KELVIN_OFFSET",
    "SECONDS_PER_HOUR",
    "SECONDS_PER_DAY",
    "SECONDS_PER_YEAR",
    "REST_TOLERANCE_W",
    "celsius_to_kelvin",
    "kelvin_to_celsius",
    "wh_to_joule",
    "joule_to_wh",
    "c_rate_to_current",
    "current_to_c_rate",
    "is_charging",
    "is_discharging",
    "is_resting",
    "mode_of",
]
