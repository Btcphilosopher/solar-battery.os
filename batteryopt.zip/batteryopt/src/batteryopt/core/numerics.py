"""Small numerical utilities shared across models and optimisers.

Everything here is written against NumPy with scalar fast paths, and is free
of Python-level loops over time steps. These functions are the most likely
candidates for later migration to Rust/C++ (see ``docs/acceleration.md``);
they are therefore kept free of object allocation and side effects.
"""

from __future__ import annotations

from typing import Callable, Sequence

import numpy as np

#: Generic tolerance for floating-point comparisons in engineering units.
EPS = 1e-12


def clamp(x: float, lo: float, hi: float) -> float:
    """Clamp a scalar into ``[lo, hi]``.

    ``lo > hi`` is treated as an empty interval and returns ``lo``, which keeps
    degenerate constraint sets from producing NaN downstream. Callers that
    care about emptiness should test feasibility explicitly first.
    """
    if hi < lo:
        return lo
    return lo if x < lo else (hi if x > hi else x)


def clamp_array(x: np.ndarray, lo: float | np.ndarray, hi: float | np.ndarray) -> np.ndarray:
    """Vectorised clamp."""
    return np.minimum(np.maximum(x, lo), hi)


def safe_div(num: float, den: float, default: float = 0.0) -> float:
    """Divide, returning ``default`` when the denominator is ~zero."""
    return num / den if abs(den) > EPS else default


def is_finite(*values: float) -> bool:
    """True when all arguments are finite floats."""
    return all(np.isfinite(v) for v in values)


def require_finite(name: str, value: float | np.ndarray) -> None:
    """Raise :class:`NumericalInstability` if ``value`` is not finite."""
    if not np.all(np.isfinite(value)):
        from .exceptions import NumericalInstability

        raise NumericalInstability(f"{name} became non-finite: {value!r}")


def interp_monotone(x: float | np.ndarray, xp: np.ndarray, fp: np.ndarray) -> float | np.ndarray:
    """Linear interpolation on a strictly increasing ``xp`` grid, with clamping.

    ``numpy.interp`` already clamps outside the grid, which is the behaviour we
    want for OCV and resistance lookups: extrapolating an OCV curve past 0 % or
    100 % SOC produces unphysical voltages that then corrupt the optimiser.
    """
    return np.interp(x, xp, fp)


def invert_monotone(
    f: Callable[[float], float],
    target: float,
    lo: float,
    hi: float,
    *,
    tol: float = 1e-9,
    max_iter: int = 100,
) -> float:
    """Invert a monotone scalar function by bisection.

    Used to recover SOC from OCV, and to find the power at which a voltage or
    temperature limit is exactly reached. Robustness matters more than speed
    here: bisection cannot diverge, whereas Newton on a piecewise-linear OCV
    curve routinely does.

    If ``target`` lies outside ``[f(lo), f(hi)]`` the nearer bracket endpoint is
    returned, i.e. the answer saturates rather than extrapolating.
    """
    f_lo, f_hi = f(lo), f(hi)
    increasing = f_hi >= f_lo
    if increasing:
        if target <= f_lo:
            return lo
        if target >= f_hi:
            return hi
    else:
        if target >= f_lo:
            return lo
        if target <= f_hi:
            return hi

    a, b = lo, hi
    for _ in range(max_iter):
        mid = 0.5 * (a + b)
        fm = f(mid)
        if abs(fm - target) < tol or (b - a) < tol:
            return mid
        if (fm < target) == increasing:
            a = mid
        else:
            b = mid
    return 0.5 * (a + b)


def golden_section(
    f: Callable[[float], float],
    lo: float,
    hi: float,
    *,
    tol: float = 1e-6,
    max_iter: int = 200,
) -> tuple[float, float]:
    """Minimise a unimodal scalar function on ``[lo, hi]``.

    Returns ``(x_min, f_min)``. Golden section is used rather than a gradient
    method because objective functions here contain piecewise-linear tariff
    terms whose derivatives are discontinuous.
    """
    if hi <= lo:
        return lo, f(lo)
    inv_phi = 0.6180339887498949
    a, b = lo, hi
    c = b - inv_phi * (b - a)
    d = a + inv_phi * (b - a)
    fc, fd = f(c), f(d)
    for _ in range(max_iter):
        if (b - a) < tol:
            break
        if fc < fd:
            b, d, fd = d, c, fc
            c = b - inv_phi * (b - a)
            fc = f(c)
        else:
            a, c, fc = c, d, fd
            d = a + inv_phi * (b - a)
            fd = f(d)
    x = 0.5 * (a + b)
    return x, f(x)


def trapezoid_integral(y: np.ndarray, dt: float | np.ndarray) -> float:
    """Trapezoidal integral of a sampled signal with uniform or per-step ``dt``."""
    y = np.asarray(y, dtype=float)
    if y.size < 2:
        return float(y.sum() * np.asarray(dt).sum() if y.size else 0.0)
    mid = 0.5 * (y[:-1] + y[1:])
    return float(np.sum(mid * np.asarray(dt, dtype=float)))


def normalise_weights(weights: dict[str, float]) -> dict[str, float]:
    """Scale non-negative weights to sum to one.

    An all-zero mapping is returned unchanged rather than raising: an objective
    with no active terms is legitimate (pure feasibility search).
    """
    total = sum(max(0.0, w) for w in weights.values())
    if total <= EPS:
        return dict(weights)
    return {k: max(0.0, v) / total for k, v in weights.items()}


def soft_min(values: Sequence[float], sharpness: float = 20.0) -> float:
    """Smooth (log-sum-exp) approximation to ``min``.

    Useful where an optimiser needs a differentiable surrogate for "the
    binding limit". Hard constraint checking never uses this -- it uses the
    true minimum -- because a smoothed limit is a violated limit.
    """
    arr = np.asarray(values, dtype=float)
    if arr.size == 0:
        return float("inf")
    m = float(arr.min())
    return m - float(np.log(np.sum(np.exp(-sharpness * (arr - m)))) / sharpness)


def pareto_mask(costs: np.ndarray) -> np.ndarray:
    """Boolean mask of Pareto-non-dominated rows of a minimisation cost matrix.

    ``costs`` has shape ``(n_points, n_objectives)`` and *all* objectives are
    minimised (maximisation objectives must be negated by the caller).
    Complexity is O(n^2 * m); n is the number of candidate strategies, which
    is in the tens to low thousands, so this is not worth optimising further.
    """
    costs = np.atleast_2d(np.asarray(costs, dtype=float))
    n = costs.shape[0]
    mask = np.ones(n, dtype=bool)
    for i in range(n):
        if not mask[i]:
            continue
        dominated = np.all(costs <= costs[i], axis=1) & np.any(costs < costs[i], axis=1)
        if np.any(dominated):
            mask[i] = False
    return mask


def crowding_distance(costs: np.ndarray) -> np.ndarray:
    """NSGA-II crowding distance, used to thin a dense Pareto front."""
    costs = np.atleast_2d(np.asarray(costs, dtype=float))
    n, m = costs.shape
    if n <= 2:
        return np.full(n, np.inf)
    dist = np.zeros(n)
    for j in range(m):
        order = np.argsort(costs[:, j])
        col = costs[order, j]
        span = col[-1] - col[0]
        dist[order[0]] = dist[order[-1]] = np.inf
        if span <= EPS:
            continue
        dist[order[1:-1]] += (col[2:] - col[:-2]) / span
    return dist


__all__ = [
    "EPS",
    "clamp",
    "clamp_array",
    "safe_div",
    "is_finite",
    "require_finite",
    "interp_monotone",
    "invert_monotone",
    "golden_section",
    "trapezoid_integral",
    "normalise_weights",
    "soft_min",
    "pareto_mask",
    "crowding_distance",
]
