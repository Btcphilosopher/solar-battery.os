"""Provenance tagging and uncertainty containers.

A recurring failure mode in battery software is quietly presenting a simulated
number as if it were measured. BatteryOpt makes that impossible to do by
accident: every scalar that crosses a subsystem boundary is wrapped in a
:class:`Quantity` carrying an explicit :class:`Provenance` tag, and the
reporting layer refuses to render a simulated value with measurement wording.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field, replace
from enum import Enum
from typing import Any, Iterable, Mapping


class Provenance(str, Enum):
    """Where a number came from.

    The four tags required for state reporting are :attr:`MEASURED`,
    :attr:`ESTIMATED`, :attr:`PREDICTED` and :attr:`SIMULATED`. Two further
    tags distinguish results in the validation and optimisation layers.

    Ordering (see :attr:`trust_rank`) runs from strongest evidence to weakest:
    a measurement outranks an estimate, which outranks a model output, which
    outranks a forward simulation or a prediction.
    """

    #: Directly observed by a sensor, subject only to sensor error.
    MEASURED = "MEASURED"
    #: Inferred from measurements at the present time (e.g. EKF SOC).
    ESTIMATED = "ESTIMATED"
    #: A statement about the future produced by a forecaster.
    PREDICTED = "PREDICTED"
    #: Produced by rolling a model forward over hypothetical inputs.
    SIMULATED = "SIMULATED"
    #: A direct model evaluation at a stated operating point (no roll-out).
    MODELLED = "MODELLED"
    #: The output of an optimisation run: a recommendation, not an observation.
    OPTIMISED = "OPTIMISED"

    @property
    def trust_rank(self) -> int:
        """Lower is stronger evidence."""
        return _TRUST_RANK[self]

    @property
    def is_empirical(self) -> bool:
        """True only for values traceable to a physical observation."""
        return self is Provenance.MEASURED

    def combine(self, other: "Provenance") -> "Provenance":
        """Provenance of a value derived from ``self`` and ``other``.

        Derived values inherit the *weakest* provenance of their inputs: a
        power computed from a measured voltage and a simulated current is
        simulated, not measured.
        """
        return self if self.trust_rank >= other.trust_rank else other


_TRUST_RANK: dict[Provenance, int] = {
    Provenance.MEASURED: 0,
    Provenance.ESTIMATED: 1,
    Provenance.MODELLED: 2,
    Provenance.OPTIMISED: 3,
    Provenance.SIMULATED: 4,
    Provenance.PREDICTED: 5,
}


#: Prior confidence attached to a value purely by virtue of where it came
#: from, before any uncertainty penalty is applied. Deliberately coarse.
_CONFIDENCE_PRIOR: dict[Provenance, float] = {
    Provenance.MEASURED: 0.98,
    Provenance.ESTIMATED: 0.90,
    Provenance.MODELLED: 0.80,
    Provenance.OPTIMISED: 0.75,
    Provenance.SIMULATED: 0.70,
    Provenance.PREDICTED: 0.60,
}


def combine_provenance(items: Iterable[Provenance]) -> Provenance:
    """Weakest provenance across ``items``; ``MEASURED`` for an empty input."""
    worst = Provenance.MEASURED
    for p in items:
        worst = worst.combine(p)
    return worst


@dataclass(frozen=True, slots=True)
class Quantiles:
    """A three-point summary of a predictive distribution.

    ``p10``/``p50``/``p90`` follow the usual convention: the true value is
    expected to fall below ``p10`` one time in ten and below ``p90`` nine
    times in ten.
    """

    p10: float
    p50: float
    p90: float

    def __post_init__(self) -> None:
        if not (self.p10 <= self.p50 <= self.p90):
            raise ValueError(
                f"quantiles must be non-decreasing, got p10={self.p10}, "
                f"p50={self.p50}, p90={self.p90}"
            )

    @property
    def spread(self) -> float:
        """Width of the 10th-to-90th percentile interval."""
        return self.p90 - self.p10

    @property
    def relative_spread(self) -> float:
        """Interval width normalised by |p50| (0.0 for a degenerate median)."""
        denom = abs(self.p50)
        return self.spread / denom if denom > 1e-12 else 0.0

    @classmethod
    def degenerate(cls, value: float) -> "Quantiles":
        """A point mass: all three quantiles equal."""
        return cls(value, value, value)

    @classmethod
    def from_normal(cls, mean: float, std: float) -> "Quantiles":
        """Quantiles of a normal distribution (z = 1.2815515655446004)."""
        z = 1.2815515655446004
        s = max(std, 0.0)
        return cls(mean - z * s, mean, mean + z * s)

    @classmethod
    def from_samples(cls, samples: Iterable[float]) -> "Quantiles":
        """Empirical quantiles from a sample using linear interpolation."""
        data = sorted(float(x) for x in samples)
        if not data:
            raise ValueError("cannot compute quantiles of an empty sample")
        return cls(_quantile(data, 0.10), _quantile(data, 0.50), _quantile(data, 0.90))

    def scaled(self, factor: float) -> "Quantiles":
        """Multiply all quantiles by ``factor`` (order-preserving for any sign)."""
        vals = sorted((self.p10 * factor, self.p50 * factor, self.p90 * factor))
        return Quantiles(*vals)

    def shifted(self, offset: float) -> "Quantiles":
        """Add ``offset`` to all quantiles."""
        return Quantiles(self.p10 + offset, self.p50 + offset, self.p90 + offset)

    def as_dict(self) -> dict[str, float]:
        return {"p10": self.p10, "p50": self.p50, "p90": self.p90}


def _quantile(sorted_data: list[float], q: float) -> float:
    """Linear-interpolation quantile of an already-sorted list."""
    n = len(sorted_data)
    if n == 1:
        return sorted_data[0]
    pos = q * (n - 1)
    lo = int(math.floor(pos))
    hi = min(lo + 1, n - 1)
    frac = pos - lo
    return sorted_data[lo] * (1.0 - frac) + sorted_data[hi] * frac


@dataclass(frozen=True, slots=True)
class Quantity:
    """A number that knows its unit, its provenance and its uncertainty.

    ``Quantity`` is deliberately cheap: frozen slots dataclass, no validation
    beyond a unit string. Hot numerical kernels operate on bare floats and
    NumPy arrays; quantities are constructed at subsystem boundaries only.
    """

    value: float
    unit: str
    provenance: Provenance = Provenance.ESTIMATED
    #: Optional predictive interval. ``None`` means "uncertainty not quantified".
    quantiles: Quantiles | None = None
    #: Optional 1-sigma standard deviation, when a full interval is not needed.
    stddev: float | None = None
    #: Free-form identifier of the producing component, e.g. ``"ekf_soc"``.
    source: str | None = None
    #: Seconds since the Unix epoch at which the value applies.
    timestamp: float | None = None
    #: Arbitrary structured annotations (model version, sensor id, ...).
    meta: Mapping[str, Any] = field(default_factory=dict)

    def __float__(self) -> float:
        return float(self.value)

    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        unc = ""
        if self.quantiles is not None:
            unc = f" [{self.quantiles.p10:.4g}..{self.quantiles.p90:.4g}]"
        elif self.stddev is not None:
            unc = f" +/-{self.stddev:.4g}"
        return f"<{self.value:.6g} {self.unit}{unc} {self.provenance.value}>"

    @property
    def is_measured(self) -> bool:
        return self.provenance is Provenance.MEASURED

    @property
    def confidence(self) -> float:
        """A 0-1 confidence heuristic derived from provenance and spread.

        This is an interpretability aid, not a calibrated probability. It
        starts from a provenance prior and is penalised by relative spread.
        """
        prior = _CONFIDENCE_PRIOR[self.provenance]
        if self.quantiles is not None:
            penalty = min(self.quantiles.relative_spread, 1.0)
        elif self.stddev is not None and abs(self.value) > 1e-12:
            penalty = min(2.0 * self.stddev / abs(self.value), 1.0)
        else:
            penalty = 0.0
        return max(0.0, min(1.0, prior * (1.0 - 0.5 * penalty)))

    def with_provenance(self, provenance: Provenance) -> "Quantity":
        return replace(self, provenance=provenance)

    def converted(self, factor: float, unit: str) -> "Quantity":
        """Scale the value (and any uncertainty) into a new unit."""
        return replace(
            self,
            value=self.value * factor,
            unit=unit,
            quantiles=self.quantiles.scaled(factor) if self.quantiles else None,
            stddev=abs(self.stddev * factor) if self.stddev is not None else None,
        )

    def as_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "value": self.value,
            "unit": self.unit,
            "provenance": self.provenance.value,
        }
        if self.quantiles is not None:
            out["quantiles"] = self.quantiles.as_dict()
        if self.stddev is not None:
            out["stddev"] = self.stddev
        if self.source is not None:
            out["source"] = self.source
        if self.timestamp is not None:
            out["timestamp"] = self.timestamp
        if self.meta:
            out["meta"] = dict(self.meta)
        return out


def measured(value: float, unit: str, *, source: str | None = None, **kw: Any) -> Quantity:
    """Construct a :attr:`Provenance.MEASURED` quantity."""
    return Quantity(value, unit, Provenance.MEASURED, source=source, **kw)


def estimated(value: float, unit: str, *, source: str | None = None, **kw: Any) -> Quantity:
    """Construct a :attr:`Provenance.ESTIMATED` quantity."""
    return Quantity(value, unit, Provenance.ESTIMATED, source=source, **kw)


def predicted(value: float, unit: str, *, source: str | None = None, **kw: Any) -> Quantity:
    """Construct a :attr:`Provenance.PREDICTED` quantity."""
    return Quantity(value, unit, Provenance.PREDICTED, source=source, **kw)


def simulated(value: float, unit: str, *, source: str | None = None, **kw: Any) -> Quantity:
    """Construct a :attr:`Provenance.SIMULATED` quantity."""
    return Quantity(value, unit, Provenance.SIMULATED, source=source, **kw)


def modelled(value: float, unit: str, *, source: str | None = None, **kw: Any) -> Quantity:
    """Construct a :attr:`Provenance.MODELLED` quantity."""
    return Quantity(value, unit, Provenance.MODELLED, source=source, **kw)


def optimised(value: float, unit: str, *, source: str | None = None, **kw: Any) -> Quantity:
    """Construct a :attr:`Provenance.OPTIMISED` quantity."""
    return Quantity(value, unit, Provenance.OPTIMISED, source=source, **kw)


__all__ = [
    "Provenance",
    "Quantiles",
    "Quantity",
    "combine_provenance",
    "measured",
    "estimated",
    "predicted",
    "simulated",
    "modelled",
    "optimised",
]
