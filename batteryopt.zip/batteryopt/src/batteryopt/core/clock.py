"""Time sources.

Simulation-first development requires that nothing in the engine calls
``time.time()`` directly. Every component takes a :class:`Clock`, so a
replayed 2019 telemetry file and a live control loop exercise identical code,
and a Monte Carlo sweep of ten thousand years of operation runs in seconds.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Protocol, runtime_checkable

from .units import SECONDS_PER_DAY


@runtime_checkable
class Clock(Protocol):
    """Minimal time source."""

    def now(self) -> float:
        """Seconds since the Unix epoch."""
        ...


class WallClock:
    """Real time. Used in production deployments."""

    __slots__ = ()

    def now(self) -> float:
        return time.time()

    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        return "WallClock()"


@dataclass(slots=True)
class SimulatedClock:
    """Deterministic, manually advanced clock.

    ``start`` defaults to 2026-01-01T00:00:00Z so that simulated runs land on a
    Thursday in mid-winter -- a deliberately unremarkable choice that keeps
    tariff and solar fixtures reproducible.
    """

    start: float = 1767225600.0
    _elapsed: float = field(default=0.0, init=False)

    def now(self) -> float:
        return self.start + self._elapsed

    def advance(self, seconds: float) -> float:
        """Advance the clock and return the new time."""
        if seconds < 0:
            raise ValueError("simulated time cannot run backwards")
        self._elapsed += seconds
        return self.now()

    def reset(self) -> None:
        self._elapsed = 0.0

    @property
    def elapsed(self) -> float:
        """Seconds advanced since construction or the last reset."""
        return self._elapsed

    @property
    def elapsed_days(self) -> float:
        return self._elapsed / SECONDS_PER_DAY


@dataclass(slots=True)
class ReplayClock:
    """Clock driven by timestamps read from a recorded telemetry stream."""

    _t: float = 0.0

    def now(self) -> float:
        return self._t

    def set(self, timestamp: float) -> None:
        """Jump to a timestamp from the recording (may go backwards on reset)."""
        self._t = float(timestamp)


#: Process-wide default. Components should accept a clock argument and fall
#: back to this rather than calling ``time.time()`` themselves.
DEFAULT_CLOCK: Clock = WallClock()


__all__ = ["Clock", "WallClock", "SimulatedClock", "ReplayClock", "DEFAULT_CLOCK"]
