"""Validation: analytical checks and cross-model comparison.

Nothing here produces a measurement. Every result is a MODEL RESULT or a
SIMULATION RESULT, and the reports say so on every page.
"""

from .analytical import (
    DEFAULT_CHECKS,
    Check,
    ValidationReport,
    check_charge_conservation,
    check_degradation_monotonicity,
    check_energy_balance,
    check_ocv_round_trip,
    check_power_inversion,
    check_provenance_discipline,
    check_surrogate_accuracy,
    check_thermal_steady_state,
    check_thermal_time_constant,
    validate_battery,
)
from .cross_model import CrossModelReport, compare_with_pybamm

__all__ = [
    "Check",
    "ValidationReport",
    "validate_battery",
    "DEFAULT_CHECKS",
    "check_charge_conservation",
    "check_energy_balance",
    "check_ocv_round_trip",
    "check_thermal_steady_state",
    "check_thermal_time_constant",
    "check_power_inversion",
    "check_degradation_monotonicity",
    "check_surrogate_accuracy",
    "check_provenance_discipline",
    "CrossModelReport",
    "compare_with_pybamm",
]
