"""Validation against analytical results (specification section 34).

Cross-checking a simulator against another simulator proves only that two
programs agree. These checks compare the plant against results that are true by
*derivation* -- conservation laws, closed-form solutions, and limiting cases
where the answer is known exactly. When one of these fails, the model is wrong,
not merely different.

The vocabulary is kept strict throughout, as the specification requires:

===================  ==================================================
Term                 Means
===================  ==================================================
MEASURED RESULT      Came from a sensor on physical hardware.
MODEL RESULT         A direct evaluation of a model at a stated point.
SIMULATION RESULT    A model rolled forward over hypothetical inputs.
OPTIMISATION RESULT  A recommendation. Neither observed nor simulated.
===================  ==================================================

Nothing in this module produces a MEASURED RESULT, and none of it should ever
be presented as evidence of physical performance.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Sequence

import numpy as np

from ..core.numerics import EPS
from ..core.provenance import Provenance
from ..core.units import SECONDS_PER_HOUR
from ..models.battery import Battery
from ..models.plant import Action, BatteryPlant


@dataclass(slots=True)
class Check:
    """One validation check and its outcome."""

    name: str
    description: str
    passed: bool
    #: The relative error observed, where the check is quantitative.
    error: float = 0.0
    tolerance: float = 0.0
    detail: str = ""
    result_kind: str = "MODEL RESULT"

    def as_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "passed": self.passed,
            "error": self.error,
            "tolerance": self.tolerance,
            "detail": self.detail,
            "result_kind": self.result_kind,
        }

    def __str__(self) -> str:
        mark = "PASS" if self.passed else "FAIL"
        return f"[{mark}] {self.name:<34} error {self.error:.3e} (tol {self.tolerance:.1e})  {self.detail}"


@dataclass(slots=True)
class ValidationReport:
    """A set of checks with an overall verdict."""

    checks: list[Check] = field(default_factory=list)
    battery_id: str = ""

    def add(self, check: Check) -> Check:
        self.checks.append(check)
        return check

    @property
    def passed(self) -> bool:
        return all(c.passed for c in self.checks)

    @property
    def failures(self) -> list[Check]:
        return [c for c in self.checks if not c.passed]

    def summary(self) -> str:
        header = (
            f"Validation report for {self.battery_id or 'battery'} -- "
            f"{len(self.checks) - len(self.failures)}/{len(self.checks)} passed"
        )
        body = "\n".join(str(c) for c in self.checks)
        note = (
            "\nAll results above are MODEL or SIMULATION results. None is a measurement, "
            "and none is evidence of physical performance."
        )
        return f"{header}\n{'-' * len(header)}\n{body}{note}"

    def as_dict(self) -> dict[str, Any]:
        return {
            "battery_id": self.battery_id,
            "passed": self.passed,
            "checks": [c.as_dict() for c in self.checks],
        }


def _relative(actual: float, expected: float) -> float:
    scale = max(abs(expected), 1e-9)
    return abs(actual - expected) / scale


def check_charge_conservation(
    battery: Battery, *, c_rate: float = 0.3, dt_s: float = 60.0, steps: int = 60
) -> Check:
    """Integrated current equals the capacity-weighted change in state of charge.

    The naive form of this check -- ``dSOC = -I dt / (3600 Q)`` with a fixed
    ``Q`` -- fails by a few parts per million, and the reason is instructive
    rather than a bug: capacity is *not* fixed during the run. Ageing shrinks it
    step by step, so state of charge is measured against a slightly smaller
    denominator each interval.

    The invariant that actually holds is stated per step, against that step's own
    capacity:

    .. code-block:: text

        integral(I dt) = sum_k (soc_k - soc_{k+1}) * Q_k

    which is checked here from the recorded trajectory. It is not circular: it
    re-derives the charge from the state history rather than re-running the
    update that produced it, so an error in the integration shows up.
    """
    # Size the test to the battery. A fixed 50 A empties a 5 Ah cell in minutes,
    # the plant correctly curtails at the state-of-charge rail, and the check
    # then "fails" for a reason that has nothing to do with conservation. Tests
    # expressed in C-rate scale across every configuration.
    plant = BatteryPlant(battery)
    state = battery.initial_state(soc=0.8, temperature_c=25.0)
    current_a = c_rate * battery.capacity
    trajectory = plant.simulate(state, [Action(current_a=current_a)] * steps, dt_s)
    if trajectory.was_curtailed():
        return Check(
            name="charge_conservation",
            description="Integrated current equals the capacity-weighted change in charge.",
            passed=False,
            error=float("inf"),
            tolerance=1e-9,
            detail=(
                "the trajectory was curtailed at a limit, so the premise of the check "
                f"does not hold: {trajectory.metrics()['limiting_constraint']}"
            ),
            result_kind="SIMULATION RESULT",
        )

    moved_ah = current_a * dt_s * steps / SECONDS_PER_HOUR
    socs = trajectory.soc
    capacities = np.array(
        [battery.nameplate_capacity_ah * s.soh_capacity for s in trajectory.states],
        dtype=float,
    )
    reconstructed = float(np.sum((socs[:-1] - socs[1:]) * capacities[:-1]))
    error = _relative(reconstructed, moved_ah)
    return Check(
        name="charge_conservation",
        description="Integrated current equals the capacity-weighted change in charge.",
        passed=error < 1e-9,
        error=error,
        tolerance=1e-9,
        detail=(
            f"reconstructed {reconstructed:.9f} Ah vs integrated {moved_ah:.9f} Ah "
            f"(capacity fell {capacities[0] - capacities[-1]:.6f} Ah over the run)"
        ),
        result_kind="SIMULATION RESULT",
    )


def check_energy_balance(
    battery: Battery, *, c_rate: float = 0.3, dt_s: float = 60.0, steps: int = 30
) -> Check:
    """Terminal energy plus internal loss equals the change in stored energy.

    Integrates ``P = V*I`` and ``P_loss = I^2 R`` from the trajectory and
    compares against the OCV-integrated energy actually removed from the cells.
    Any discrepancy is energy the model has created or destroyed.
    """
    plant = BatteryPlant(battery)
    state = battery.initial_state(soc=0.8, temperature_c=25.0)
    power_w = c_rate * battery.capacity * battery.nominal_voltage
    trajectory = plant.simulate(state, [Action(power_w=power_w)] * steps, dt_s)
    if trajectory.was_curtailed():
        return Check(
            name="energy_balance",
            description=(
                "Delivered energy plus internal losses equals energy removed from store."
            ),
            passed=False,
            error=float("inf"),
            tolerance=0.02,
            detail=(
                "the trajectory was curtailed at a limit, so the premise of the check "
                f"does not hold: {trajectory.metrics()['limiting_constraint']}"
            ),
            result_kind="SIMULATION RESULT",
        )

    delivered_wh = trajectory.energy_discharged_wh()
    losses_wh = trajectory.losses_wh()
    stored_change_wh = battery.energy_between(
        float(trajectory.soc[-1]), float(trajectory.soc[0])
    )
    error = _relative(delivered_wh + losses_wh, stored_change_wh)
    # The RC branches hold energy that has left the OCV store but not yet
    # reached the terminals, so a few tenths of a percent is expected over a
    # short run and is not a violation.
    tolerance = 0.02
    return Check(
        name="energy_balance",
        description="Delivered energy plus internal losses equals energy removed from store.",
        passed=error < tolerance,
        error=error,
        tolerance=tolerance,
        detail=(
            f"delivered {delivered_wh:.2f} Wh + losses {losses_wh:.2f} Wh "
            f"vs stored change {stored_change_wh:.2f} Wh"
        ),
        result_kind="SIMULATION RESULT",
    )


def check_ocv_round_trip(battery: Battery, *, points: int = 41) -> Check:
    """Inverting the OCV curve returns the SOC it was evaluated at.

    On a flat chemistry the inverse is genuinely ill-conditioned, so the
    tolerance is expressed in *volts* rather than SOC: the check is that the
    inverse lands on a SOC with the same voltage, which is the strongest claim
    that can honestly be made about a plateau.
    """
    curve = battery.chemistry.ocv
    grid = np.linspace(0.02, 0.98, points)
    worst = 0.0
    worst_soc = 0.0
    for soc in grid:
        voltage = float(curve.voltage_at(soc))
        recovered = curve.soc_at(voltage)
        err = abs(float(curve.voltage_at(recovered)) - voltage)
        if err > worst:
            worst, worst_soc = err, float(soc)
    return Check(
        name="ocv_inversion_round_trip",
        description="OCV inversion recovers a state of charge with the same voltage.",
        passed=worst < 1e-6,
        error=worst,
        tolerance=1e-6,
        detail=f"worst voltage error {worst:.3e} V near SOC {worst_soc:.2f}",
    )


def check_thermal_steady_state(battery: Battery, *, heat_w: float = 2_000.0) -> Check:
    """The thermal model converges to the analytic equilibrium ``T = T_sink + Q/k``.

    Run long enough for the exponential to settle, then compare. This catches
    sign errors and conductance-scaling errors that a short run hides.
    """
    thermal = battery.thermal
    sink = 20.0
    cooling = 0.5
    expected = thermal.equilibrium_temperature(
        heat_generation_w=heat_w, sink_c=sink, cooling_fraction=cooling
    )
    temperature = sink
    dt = 60.0
    for _ in range(2000):
        temperature = thermal.step(
            temperature_c=temperature,
            heat_generation_w=heat_w,
            dt=dt,
            ambient_c=sink,
            coolant_c=sink,
            cooling_fraction=cooling,
        ).temperature_c
    error = _relative(temperature, expected)
    return Check(
        name="thermal_steady_state",
        description="Lumped thermal model converges to T_sink + Q/k.",
        passed=error < 1e-6,
        error=error,
        tolerance=1e-6,
        detail=f"settled {temperature:.6f} degC vs analytic {expected:.6f} degC",
        result_kind="SIMULATION RESULT",
    )


def check_thermal_time_constant(battery: Battery) -> Check:
    """After one time constant the model has covered 1 - 1/e of the gap.

    Verifies the *dynamics*, not just the endpoint. An implementation using
    forward Euler at a coarse step passes the steady-state check and fails this
    one, which is exactly why both exist.
    """
    thermal = battery.thermal
    sink = 20.0
    start = 40.0
    k = thermal.conductance(0.0)
    tau = thermal.heat_capacity_j_k / k
    result = thermal.step(
        temperature_c=start,
        heat_generation_w=0.0,
        dt=tau,
        ambient_c=sink,
        coolant_c=sink,
        cooling_fraction=0.0,
    )
    expected = sink + (start - sink) * np.exp(-1.0)
    error = _relative(result.temperature_c, expected)
    return Check(
        name="thermal_time_constant",
        description="One time constant covers 1 - 1/e of the temperature gap.",
        passed=error < 1e-9,
        error=error,
        tolerance=1e-9,
        detail=f"tau = {tau:.1f} s, reached {result.temperature_c:.6f} degC",
    )


def check_power_inversion(battery: Battery, *, points: int = 25) -> Check:
    """Solving for the current that gives a power, then evaluating it, round-trips.

    The quadratic inversion is used everywhere in the optimiser; if it is even
    slightly wrong, every recommended power is slightly wrong too.
    """
    ecm = battery.electrical
    worst = 0.0
    v_nom = battery.nominal_voltage
    for power in np.linspace(-battery.maximum_charge_current * v_nom * 0.9,
                             battery.maximum_current * v_nom * 0.9, points):
        current = ecm.current_for_power(float(power), soc=0.5, temperature_c=25.0)
        recovered = ecm.power_for_current(current, soc=0.5, temperature_c=25.0)
        worst = max(worst, _relative(recovered, float(power)) if abs(power) > 1.0 else 0.0)
    return Check(
        name="power_current_inversion",
        description="Power-to-current inversion round-trips to the requested power.",
        passed=worst < 1e-9,
        error=worst,
        tolerance=1e-9,
        detail=f"worst relative error {worst:.3e} across {points} power points",
    )


def check_degradation_monotonicity(battery: Battery) -> Check:
    """Damage never decreases, and hotter, deeper and faster is never better.

    A degradation model that can be *improved* by operating harder will be
    exploited by the optimiser within seconds, and the failure is silent.
    """
    model = battery.degradation
    problems: list[str] = []

    fades = [model.fade(t, 0.0) for t in np.linspace(0, 20, 50)]
    if any(b < a - 1e-15 for a, b in zip(fades, fades[1:])):
        problems.append("calendar fade is not monotone in time")
    fades = [model.fade(0.0, a) for a in np.linspace(0, 5000, 50)]
    if any(b < a - 1e-15 for a, b in zip(fades, fades[1:])):
        problems.append("cycle fade is not monotone in throughput")

    hot = model.calendar_stress(soc=0.5, temperature_c=45.0)
    warm = model.calendar_stress(soc=0.5, temperature_c=25.0)
    if hot <= warm:
        problems.append("calendar stress does not increase with temperature")

    full = model.calendar_stress(soc=0.95, temperature_c=25.0)
    if full <= warm:
        problems.append("calendar stress does not increase with state of charge")

    deep = model.cycle_stress(c_rate=0.5, temperature_c=25.0, dod=0.9, charging=False)
    shallow = model.cycle_stress(c_rate=0.5, temperature_c=25.0, dod=0.2, charging=False)
    if deep <= shallow:
        problems.append("cycle stress does not increase with depth of discharge")

    fast = model.cycle_stress(c_rate=2.0, temperature_c=25.0, dod=0.5, charging=False)
    slow = model.cycle_stress(c_rate=0.2, temperature_c=25.0, dod=0.5, charging=False)
    if fast <= slow:
        problems.append("cycle stress does not increase with C-rate")

    # Probe below *this* chemistry's own plating threshold. Probing at a fixed
    # -5 degC would fail for LTO and sodium-ion, which genuinely do not plate
    # there -- and it would be the check that was wrong, not the model.
    threshold = battery.chemistry.degradation.plating_threshold_c
    cold_charge = model.plating_multiplier(
        temperature_c=threshold - 10.0, c_rate=1.0, charging=True
    )
    warm_charge = model.plating_multiplier(
        temperature_c=threshold + 10.0, c_rate=1.0, charging=True
    )
    if cold_charge <= warm_charge:
        problems.append(
            f"plating penalty does not increase below the {threshold:.0f} degC threshold"
        )
    if model.plating_multiplier(
        temperature_c=threshold - 10.0, c_rate=1.0, charging=False
    ) != 1.0:
        problems.append("plating penalty is applied to discharge, which is unphysical")

    return Check(
        name="degradation_monotonicity",
        description="Damage is monotone and every stress factor has the right sign.",
        passed=not problems,
        error=float(len(problems)),
        tolerance=0.0,
        detail="; ".join(problems) if problems else "all stress factors correctly signed",
    )


def check_surrogate_accuracy(battery: Battery, *, tolerance: float = 0.01) -> Check:
    """The surrogate agrees with the exact ECM within a stated tolerance.

    Quoted rather than assumed: the surrogate is used on the real-time path, so
    its error is part of the engine's error budget and belongs in the report.
    """
    from ..models.surrogate import build_surrogate

    surface = build_surrogate(battery)
    report = surface.validate_against(battery, n_samples=400)
    worst = max(v for k, v in report.items() if k.endswith("_rms_rel_error"))
    return Check(
        name="surrogate_accuracy",
        description="Surrogate response surface matches the exact equivalent-circuit model.",
        passed=worst < tolerance,
        error=worst,
        tolerance=tolerance,
        detail="; ".join(f"{k}={v:.2e}" for k, v in sorted(report.items()) if "rms" in k),
    )


def check_provenance_discipline(battery: Battery) -> Check:
    """A simulated state never claims to have been measured.

    Cheap to check and catastrophic to get wrong: the whole provenance system is
    worthless if one code path forgets to re-tag.
    """
    plant = BatteryPlant(battery)
    state = battery.initial_state(soc=0.5, temperature_c=25.0)
    trajectory = plant.simulate(state.as_simulated(), [Action(power_w=1000.0)] * 5, 60.0)
    problems = [
        f"step {k} is tagged {s.default_provenance.value}"
        for k, s in enumerate(trajectory.states[1:], start=1)
        if s.default_provenance is not Provenance.SIMULATED
    ]
    return Check(
        name="provenance_discipline",
        description="Simulated trajectories are tagged SIMULATED throughout.",
        passed=not problems,
        error=float(len(problems)),
        tolerance=0.0,
        detail="; ".join(problems) if problems else "every simulated state correctly tagged",
    )


DEFAULT_CHECKS: tuple[Callable[[Battery], Check], ...] = (
    check_charge_conservation,
    check_energy_balance,
    check_ocv_round_trip,
    check_thermal_steady_state,
    check_thermal_time_constant,
    check_power_inversion,
    check_degradation_monotonicity,
    check_surrogate_accuracy,
    check_provenance_discipline,
)


def validate_battery(
    battery: Battery, checks: Sequence[Callable[[Battery], Check]] | None = None
) -> ValidationReport:
    """Run every analytical check against a battery configuration."""
    report = ValidationReport(battery_id=battery.battery_id)
    for check in checks or DEFAULT_CHECKS:
        try:
            report.add(check(battery))
        except Exception as exc:  # noqa: BLE001 - a check that crashes is a failure
            report.add(
                Check(
                    name=getattr(check, "__name__", "unknown"),
                    description="check raised",
                    passed=False,
                    detail=f"{type(exc).__name__}: {exc}",
                )
            )
    return report


__all__ = [
    "Check",
    "ValidationReport",
    "validate_battery",
    "DEFAULT_CHECKS",
    "check_charge_conservation",
    "check_energy_balance",
    "check_ocv_round_trip",
    "check_thermal_steady_state",
    "check_thermal_time_constant",
    "check_power_inversion",
    "check_degradation_monotonicity",
    "check_surrogate_accuracy",
    "check_provenance_discipline",
]
