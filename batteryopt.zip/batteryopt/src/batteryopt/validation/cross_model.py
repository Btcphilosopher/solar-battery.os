"""Cross-model validation against PyBaMM.

The equivalent-circuit model is a *fit*, and a fit is only trustworthy inside
the envelope it was fitted over. This module re-runs a constant-current
discharge under a physics-based model and reports where the two diverge, so
that the ECM's error is a measured quantity rather than an assumption.

Requires ``batteryopt[physics]``. Without PyBaMM the comparison reports that it
could not be performed -- it does not silently return a pass, because a
validation step that quietly succeeds when it did not run is worse than no
validation step at all.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np

from ..core.optional import have
from ..models.battery import Battery
from ..models.plant import Action, BatteryPlant


@dataclass(slots=True)
class CrossModelReport:
    """Agreement between the equivalent-circuit model and a physics model."""

    performed: bool
    reason: str = ""
    voltage_rms_error_v: float = float("nan")
    voltage_max_error_v: float = float("nan")
    capacity_error_fraction: float = float("nan")
    reference_model: str = ""
    parameter_set: str = ""
    tolerance_v: float = 0.05
    detail: dict[str, Any] = field(default_factory=dict)

    @property
    def passed(self) -> bool:
        if not self.performed:
            return False
        return bool(
            np.isfinite(self.voltage_rms_error_v)
            and self.voltage_rms_error_v < self.tolerance_v
        )

    def summary(self) -> str:
        if not self.performed:
            return f"Cross-model validation NOT PERFORMED: {self.reason}"
        verdict = "PASS" if self.passed else "FAIL"
        return (
            f"[{verdict}] equivalent-circuit vs {self.reference_model} "
            f"({self.parameter_set}): voltage RMS {self.voltage_rms_error_v:.4f} V, "
            f"max {self.voltage_max_error_v:.4f} V, tolerance {self.tolerance_v:.3f} V. "
            "Both are MODEL RESULTS; agreement between two models is not evidence of "
            "physical accuracy."
        )

    def as_dict(self) -> dict[str, Any]:
        return {
            "performed": self.performed,
            "passed": self.passed,
            "reason": self.reason,
            "voltage_rms_error_v": self.voltage_rms_error_v,
            "voltage_max_error_v": self.voltage_max_error_v,
            "capacity_error_fraction": self.capacity_error_fraction,
            "reference_model": self.reference_model,
            "parameter_set": self.parameter_set,
            "tolerance_v": self.tolerance_v,
        }


def compare_with_pybamm(
    battery: Battery,
    *,
    c_rate: float = 0.5,
    duration_s: float | None = None,
    model: str = "SPMe",
    initial_soc: float = 0.95,
    ambient_c: float = 25.0,
    tolerance_v: float = 0.05,
) -> CrossModelReport:
    """Run the same discharge under the ECM and under PyBaMM, and compare.

    Comparison is per *cell*, since PyBaMM models a single cell; the ECM's
    pack-level voltage is divided by the series count. The tolerance is stated
    in volts per cell because that is the quantity an engineer can judge -- 50 mV
    on a 3.7 V cell is about 1.4 %, which is a reasonable expectation for a
    first-order equivalent circuit against a physics model over a moderate rate.
    """
    if not have("pybamm"):
        return CrossModelReport(
            performed=False,
            reason=(
                "PyBaMM is not installed, so no physics-based comparison was made. "
                "Install it with: pip install 'batteryopt[physics]'. This is reported "
                "as NOT PERFORMED rather than as a pass."
            ),
        )

    from ..models.physics import PyBaMMAdapter

    adapter = PyBaMMAdapter(battery, model=model)
    cell_capacity_ah = battery.topology.cell.effective_capacity_ah
    cell_current = c_rate * cell_capacity_ah
    if duration_s is None:
        duration_s = 0.7 * cell_capacity_ah / max(cell_current, 1e-9) * 3600.0

    try:
        physics = adapter.simulate_constant_current(
            cell_current_a=cell_current,
            duration_s=duration_s,
            initial_soc=initial_soc,
            ambient_c=ambient_c,
            n_points=120,
        )
    except Exception as exc:  # noqa: BLE001 - PyBaMM APIs vary between releases
        return CrossModelReport(
            performed=False,
            reason=f"PyBaMM simulation failed: {type(exc).__name__}: {exc}",
        )

    plant = BatteryPlant(battery)
    state = battery.initial_state(soc=initial_soc, temperature_c=ambient_c, ambient_c=ambient_c)
    pack_current = battery.topology.current_from_cell(cell_current)
    dt = duration_s / 120.0
    trajectory = plant.simulate(state, [Action(current_a=pack_current)] * 120, dt)
    ecm_cell_voltage = trajectory.voltage_v[1:] / battery.topology.n_series

    n = min(ecm_cell_voltage.size, physics.voltage_v.size)
    if n < 8:
        return CrossModelReport(
            performed=False, reason="not enough overlapping samples to compare"
        )
    grid = np.linspace(0.0, 1.0, n)
    ecm_interp = np.interp(grid, np.linspace(0.0, 1.0, ecm_cell_voltage.size), ecm_cell_voltage)
    physics_interp = np.interp(
        grid, np.linspace(0.0, 1.0, physics.voltage_v.size), physics.voltage_v
    )
    difference = ecm_interp - physics_interp

    return CrossModelReport(
        performed=True,
        voltage_rms_error_v=float(np.sqrt(np.mean(difference**2))),
        voltage_max_error_v=float(np.max(np.abs(difference))),
        capacity_error_fraction=float(
            abs(trajectory.soc[0] - trajectory.soc[-1]) - 0.7
        ),
        reference_model=physics.model_name,
        parameter_set=physics.parameter_set,
        tolerance_v=tolerance_v,
        detail={"c_rate": c_rate, "duration_s": duration_s, "samples": n},
    )


__all__ = ["compare_with_pybamm", "CrossModelReport"]
