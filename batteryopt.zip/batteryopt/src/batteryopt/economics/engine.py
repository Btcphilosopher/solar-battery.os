"""The economic engine (specification section 19).

The central idea: **a kilowatt-hour is not worth the same as another
kilowatt-hour if producing it consumed materially different amounts of
battery life.** Every quantity the optimiser trades is therefore converted
into one currency, so that "is this fast charge worth it?" becomes an
arithmetic question rather than a matter of taste.

Degradation cost
----------------
The battery has a replacement cost and a finite amount of capacity it can lose
before that replacement is due:

.. code-block:: text

    usable_fade  = 1 - eol_soh                    e.g. 0.20
    cost_per_fade = replacement_cost / usable_fade

so on a 250 kWh pack at 180 currency/kWh with an 80 % end of life, losing
0.001 of capacity costs ``45000 / 0.20 * 0.001 = 225``. That number is what
makes the optimiser refuse a fast charge that saves 30 pence of electricity
and costs 2 units of battery life.

Two refinements matter and are included:

* **Residual value.** A pack retired from its first application is often worth
  something in a second one. Net replacement cost is what should be amortised.
* **Discounting.** Damage done today is paid for at replacement time, years
  away. Cost is discounted over the projected remaining life, which materially
  changes the answer for long-lived stationary assets and barely changes it
  for anything approaching end of life.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np
from pydantic import BaseModel, ConfigDict, Field

from ..core.numerics import EPS
from ..core.units import SECONDS_PER_HOUR, SECONDS_PER_YEAR
from ..models.battery import Battery
from .prices import PriceCurve, Tariff


class EconomicConfig(BaseModel):
    """Costs and values attached to a battery asset."""

    model_config = ConfigDict(frozen=True)

    currency: str = "GBP"
    #: Installed replacement cost per kWh of nameplate energy.
    replacement_cost_per_kwh: float = Field(180.0, ge=0)
    #: Fraction of replacement cost recovered at end of first life.
    residual_value_fraction: float = Field(0.25, ge=0, lt=1.0)
    #: Capacity SOH at which replacement is triggered.
    end_of_life_soh: float = Field(0.80, gt=0, lt=1.0)
    #: Annual discount rate applied to deferred replacement cost.
    discount_rate: float = Field(0.06, ge=0, lt=1.0)
    #: Fixed maintenance cost per year, currency.
    maintenance_per_year: float = Field(0.0, ge=0)
    #: Cost attached to a resistance doubling, as a fraction of replacement
    #: cost. Resistance growth does not by itself end life, but it erodes
    #: power capability and round-trip efficiency.
    resistance_cost_fraction: float = Field(0.15, ge=0)
    #: Penalty per Wh of unmet demand -- the value of lost load. The default
    #: of 0.01 currency/Wh (10 per kWh) sits in the usual commercial VoLL
    #: range and is roughly forty times a peak tariff, so an unserved
    #: kilowatt-hour is expensive without being lexicographically infinite.
    #: Applications that genuinely cannot fail (medical, aviation) should
    #: raise this or, better, express the requirement as a hard constraint.
    mission_shortfall_cost_per_wh: float = Field(0.01, ge=0)
    #: Value of one Wh of stored energy when no price signal is available.
    default_energy_value_per_kwh: float = Field(0.15, ge=0)


@dataclass(frozen=True, slots=True)
class CostBreakdown:
    """Every cost and benefit of one candidate strategy, in one currency."""

    #: Cost of energy imported to charge, positive = money spent.
    energy_cost: float = 0.0
    #: Revenue from energy exported or delivered, positive = money earned.
    energy_revenue: float = 0.0
    #: Value of the internal losses, at the prevailing energy price.
    loss_cost: float = 0.0
    #: Energy consumed by cooling, heating and balancing.
    auxiliary_cost: float = 0.0
    #: Amortised cost of the capacity lost.
    degradation_cost: float = 0.0
    #: Amortised cost of the resistance gained.
    resistance_cost: float = 0.0
    #: Penalty for failing to meet a committed mission or reserve.
    shortfall_cost: float = 0.0
    #: Change in the market value of the stored energy (positive = gained).
    stored_energy_value_change: float = 0.0
    currency: str = "GBP"

    @property
    def total_cost(self) -> float:
        return (
            self.energy_cost
            + self.loss_cost
            + self.auxiliary_cost
            + self.degradation_cost
            + self.resistance_cost
            + self.shortfall_cost
        )

    @property
    def net_value(self) -> float:
        """Revenue plus change in stored value, minus every cost."""
        return self.energy_revenue + self.stored_energy_value_change - self.total_cost

    def as_dict(self) -> dict[str, float | str]:
        return {
            "energy_cost": self.energy_cost,
            "energy_revenue": self.energy_revenue,
            "loss_cost": self.loss_cost,
            "auxiliary_cost": self.auxiliary_cost,
            "degradation_cost": self.degradation_cost,
            "resistance_cost": self.resistance_cost,
            "shortfall_cost": self.shortfall_cost,
            "stored_energy_value_change": self.stored_energy_value_change,
            "total_cost": self.total_cost,
            "net_value": self.net_value,
            "currency": self.currency,
        }


class EconomicEngine:
    """Converts physical outcomes into money."""

    __slots__ = ("battery", "config", "_replacement_cost", "_cost_per_fade")

    def __init__(self, battery: Battery, config: EconomicConfig | None = None) -> None:
        self.battery = battery
        self.config = config or EconomicConfig()
        nameplate_kwh = battery.nominal_energy_wh / 1000.0
        gross = self.config.replacement_cost_per_kwh * nameplate_kwh
        self._replacement_cost = gross * (1.0 - self.config.residual_value_fraction)
        usable_fade = max(1.0 - self.config.end_of_life_soh, EPS)
        self._cost_per_fade = self._replacement_cost / usable_fade

    # -- asset economics ----------------------------------------------------

    @property
    def replacement_cost(self) -> float:
        """Net cost of replacing the battery, after residual value."""
        return self._replacement_cost

    @property
    def cost_per_unit_fade(self) -> float:
        """Currency per unit of fractional capacity fade, undiscounted."""
        return self._cost_per_fade

    def degradation_cost(
        self, capacity_fade: float, *, remaining_years: float | None = None
    ) -> float:
        """Cost of a given amount of capacity fade, optionally discounted.

        Discounting matters: 1 % of a pack that will be replaced in eleven
        years is worth materially less than 1 % of one being replaced next
        year, and an optimiser that ignores this over-conserves young assets.
        """
        cost = max(0.0, capacity_fade) * self._cost_per_fade
        if remaining_years is None or self.config.discount_rate <= 0.0:
            return cost
        years = max(0.0, remaining_years)
        return cost / ((1.0 + self.config.discount_rate) ** years)

    def resistance_cost(self, resistance_growth: float) -> float:
        """Cost attached to a given fractional resistance increase."""
        return (
            max(0.0, resistance_growth)
            * self.config.resistance_cost_fraction
            * self._replacement_cost
        )

    def energy_value_per_kwh(self, tariff: Tariff | None, t_s: float = 0.0) -> float:
        if tariff is None:
            return self.config.default_energy_value_per_kwh
        return float(np.atleast_1d(tariff.import_at(t_s))[0])

    # -- strategy pricing ---------------------------------------------------

    def price_outcome(
        self,
        *,
        energy_discharged_wh: float,
        energy_charged_wh: float,
        losses_wh: float,
        auxiliary_wh: float,
        capacity_fade: float,
        resistance_growth: float = 0.0,
        shortfall_wh: float = 0.0,
        start_soc: float = 0.0,
        end_soc: float = 0.0,
        tariff: Tariff | None = None,
        start_time_s: float = 0.0,
        end_time_s: float | None = None,
        remaining_years: float | None = None,
        future_energy_value_per_kwh: float | None = None,
    ) -> CostBreakdown:
        """Convert one simulated outcome into a full cost breakdown.

        ``future_energy_value_per_kwh`` is the marginal value of energy left in
        the battery at the end of the horizon. Getting this right is what stops
        a finite-horizon arbitrage optimiser from dumping the pack empty on the
        last step of every horizon (specification section 16).
        """
        cfg = self.config
        end_t = start_time_s if end_time_s is None else end_time_s
        import_price = self.energy_value_per_kwh(tariff, start_time_s)
        export_price = (
            float(np.atleast_1d(tariff.export_at(end_t))[0])
            if tariff is not None and tariff.export_price is not None
            else import_price
        )

        energy_cost = energy_charged_wh / 1000.0 * import_price
        energy_revenue = energy_discharged_wh / 1000.0 * export_price
        loss_cost = losses_wh / 1000.0 * import_price
        auxiliary_cost = auxiliary_wh / 1000.0 * import_price
        degradation = self.degradation_cost(capacity_fade, remaining_years=remaining_years)
        resistance = self.resistance_cost(resistance_growth)
        shortfall = shortfall_wh * cfg.mission_shortfall_cost_per_wh

        future_value = (
            future_energy_value_per_kwh
            if future_energy_value_per_kwh is not None
            else import_price
        )
        stored_delta_wh = self.battery.energy_between(
            min(start_soc, end_soc), max(start_soc, end_soc)
        )
        stored_delta_wh = stored_delta_wh if end_soc >= start_soc else -stored_delta_wh
        stored_value_change = stored_delta_wh / 1000.0 * future_value

        return CostBreakdown(
            energy_cost=energy_cost,
            energy_revenue=energy_revenue,
            loss_cost=loss_cost,
            auxiliary_cost=auxiliary_cost,
            degradation_cost=degradation,
            resistance_cost=resistance,
            shortfall_cost=shortfall,
            stored_energy_value_change=stored_value_change,
            currency=cfg.currency,
        )

    # -- headline metrics ---------------------------------------------------

    def cost_per_kwh_delivered(
        self, breakdown: CostBreakdown, energy_delivered_wh: float
    ) -> float:
        """All-in cost of each delivered kWh, including the battery life spent."""
        kwh = energy_delivered_wh / 1000.0
        if kwh <= EPS:
            return float("inf")
        return breakdown.total_cost / kwh

    def value_per_kwh(self, breakdown: CostBreakdown, energy_delivered_wh: float) -> float:
        kwh = energy_delivered_wh / 1000.0
        if kwh <= EPS:
            return 0.0
        return breakdown.net_value / kwh

    def lifetime_energy_wh(
        self,
        *,
        cycles_per_year: float,
        depth_of_discharge: float,
        remaining_years: float,
        mean_efficiency: float = 0.95,
    ) -> float:
        """Energy the battery will deliver over its remaining life, Wh.

        Uses the *present* capacity and applies mean fade over the period,
        which is the standard first-order treatment. The lifetime optimiser in
        :mod:`batteryopt.applications.lifetime` refines this by simulating the
        policy rather than assuming a mean.
        """
        if not np.isfinite(remaining_years):
            remaining_years = 25.0
        mean_soh = 0.5 * (self.battery.soh_capacity + self.config.end_of_life_soh)
        per_cycle_wh = (
            self.battery.nominal_energy_wh * depth_of_discharge * mean_soh * mean_efficiency
        )
        return per_cycle_wh * cycles_per_year * max(0.0, remaining_years)

    def levelised_cost_per_kwh(
        self,
        *,
        cycles_per_year: float,
        depth_of_discharge: float,
        remaining_years: float,
        mean_efficiency: float = 0.95,
        energy_price_per_kwh: float | None = None,
    ) -> float:
        """Levelised cost of storage: capital plus round-trip losses, per kWh out."""
        lifetime_wh = self.lifetime_energy_wh(
            cycles_per_year=cycles_per_year,
            depth_of_discharge=depth_of_discharge,
            remaining_years=remaining_years,
            mean_efficiency=mean_efficiency,
        )
        if lifetime_wh <= EPS:
            return float("inf")
        years = max(remaining_years, EPS) if np.isfinite(remaining_years) else 25.0
        capital = self._replacement_cost + self.config.maintenance_per_year * years
        price = (
            energy_price_per_kwh
            if energy_price_per_kwh is not None
            else self.config.default_energy_value_per_kwh
        )
        loss_cost = (lifetime_wh / 1000.0) * price * (1.0 / max(mean_efficiency, EPS) - 1.0)
        return (capital + loss_cost) / (lifetime_wh / 1000.0)

    def marginal_degradation_cost_per_second(
        self,
        *,
        fade_rate_per_s: float,
        remaining_years: float | None = None,
    ) -> float:
        """Currency per second of operating at a given fade rate."""
        return self.degradation_cost(fade_rate_per_s, remaining_years=remaining_years)

    def summary(self, *, remaining_years: float | None = None) -> dict[str, Any]:
        return {
            "currency": self.config.currency,
            "replacement_cost": round(self._replacement_cost, 2),
            "cost_per_unit_fade": round(self._cost_per_fade, 2),
            "cost_per_percent_soh": round(self._cost_per_fade * 0.01, 2),
            "nameplate_energy_kwh": round(self.battery.nominal_energy_wh / 1000.0, 2),
            "remaining_years": remaining_years,
        }


def energy_wh(power_w: float, seconds: float) -> float:
    return power_w * seconds / SECONDS_PER_HOUR


def years(seconds: float) -> float:
    return seconds / SECONDS_PER_YEAR


__all__ = ["EconomicEngine", "EconomicConfig", "CostBreakdown", "PriceCurve", "Tariff"]
