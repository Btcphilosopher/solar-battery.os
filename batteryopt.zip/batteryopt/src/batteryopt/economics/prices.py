"""Electricity price and tariff representation.

A price is a *time series*, not a number, and almost every interesting battery
decision turns on that. The engine therefore takes a :class:`PriceCurve`
everywhere a price is needed, with a flat-rate constructor for the simple case
so that a caller who genuinely has one number is not forced to build a series.

Import and export prices are separate curves, because they almost never match:
a domestic customer might import at 28 p/kWh and export at 15 p/kWh, and that
spread is what makes self-consumption worth more than export.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

import numpy as np

from ..core.numerics import EPS
from ..core.units import SECONDS_PER_HOUR


@dataclass(frozen=True, slots=True)
class PriceCurve:
    """Piecewise-constant price in currency per kWh over time.

    ``times_s`` are the left edges of each interval, in seconds on the same
    clock as the optimisation horizon. Lookups outside the range clamp to the
    first or last value rather than extrapolating, because extrapolating a
    tariff is never right.
    """

    times_s: np.ndarray
    prices: np.ndarray
    currency: str = "GBP"
    name: str = ""

    def __post_init__(self) -> None:
        if self.times_s.size != self.prices.size:
            raise ValueError("price curve times and prices must be the same length")
        if self.times_s.size == 0:
            raise ValueError("price curve cannot be empty")
        if np.any(np.diff(self.times_s) < 0):
            raise ValueError("price curve times must be non-decreasing")

    @classmethod
    def flat(cls, price: float, *, currency: str = "GBP", name: str = "flat") -> "PriceCurve":
        return cls(np.array([0.0]), np.array([float(price)]), currency, name)

    @classmethod
    def from_pairs(
        cls, pairs: Sequence[tuple[float, float]], *, currency: str = "GBP", name: str = ""
    ) -> "PriceCurve":
        ordered = sorted(pairs)
        return cls(
            np.array([t for t, _ in ordered], dtype=float),
            np.array([p for _, p in ordered], dtype=float),
            currency,
            name,
        )

    @classmethod
    def half_hourly(
        cls,
        prices: Sequence[float],
        *,
        start_s: float = 0.0,
        currency: str = "GBP",
        name: str = "half-hourly",
    ) -> "PriceCurve":
        """Build a curve from consecutive half-hourly settlement prices."""
        times = start_s + np.arange(len(prices), dtype=float) * 1800.0
        return cls(times, np.asarray(prices, dtype=float), currency, name)

    def at(self, t_s: float | np.ndarray) -> np.ndarray:
        """Price in effect at each time; clamped outside the curve."""
        idx = np.clip(np.searchsorted(self.times_s, t_s, side="right") - 1, 0, self.prices.size - 1)
        return self.prices[idx]

    def mean(self, start_s: float | None = None, end_s: float | None = None) -> float:
        lo = self.times_s[0] if start_s is None else start_s
        hi = self.times_s[-1] + 1800.0 if end_s is None else end_s
        if hi <= lo:
            return float(self.at(lo))
        grid = np.linspace(lo, hi, 256)
        return float(np.mean(self.at(grid)))

    @property
    def min(self) -> float:
        return float(self.prices.min())

    @property
    def max(self) -> float:
        return float(self.prices.max())

    @property
    def spread(self) -> float:
        """Peak-to-trough spread: the headline number for arbitrage value."""
        return self.max - self.min

    def cheapest_window(self, duration_s: float, horizon_s: float | None = None) -> tuple[float, float]:
        """Start and mean price of the cheapest contiguous window."""
        end = self.times_s[-1] + 1800.0 if horizon_s is None else horizon_s
        starts = np.linspace(self.times_s[0], max(self.times_s[0], end - duration_s), 512)
        best_start, best_price = float(starts[0]), float("inf")
        for s in starts:
            grid = np.linspace(s, s + duration_s, 32)
            p = float(np.mean(self.at(grid)))
            if p < best_price:
                best_price, best_start = p, float(s)
        return best_start, best_price

    def cost_of(self, energy_wh: float | np.ndarray, t_s: float | np.ndarray) -> np.ndarray:
        """Cost of importing ``energy_wh`` at time ``t_s``, in currency."""
        return np.asarray(energy_wh, dtype=float) / 1000.0 * self.at(t_s)

    def as_dict(self) -> dict[str, object]:
        return {
            "name": self.name,
            "currency": self.currency,
            "times_s": self.times_s.tolist(),
            "prices": self.prices.tolist(),
        }


@dataclass(frozen=True, slots=True)
class Tariff:
    """Import and export prices plus any standing or capacity charges."""

    import_price: PriceCurve
    export_price: PriceCurve | None = None
    #: Charge per kW of peak demand in the billing period, currency per kW.
    demand_charge_per_kw: float = 0.0
    #: Fixed cost per day, currency. Does not affect marginal decisions but
    #: does affect reported cost per kWh delivered.
    standing_charge_per_day: float = 0.0
    currency: str = "GBP"
    name: str = ""

    @classmethod
    def flat(
        cls, import_price: float, export_price: float | None = None, *, currency: str = "GBP"
    ) -> "Tariff":
        return cls(
            import_price=PriceCurve.flat(import_price, currency=currency),
            export_price=(
                PriceCurve.flat(export_price, currency=currency)
                if export_price is not None
                else None
            ),
            currency=currency,
            name="flat",
        )

    @classmethod
    def time_of_use(
        cls,
        *,
        peak_price: float,
        off_peak_price: float,
        peak_start_hour: float = 16.0,
        peak_end_hour: float = 19.0,
        export_price: float | None = None,
        horizon_hours: float = 48.0,
        currency: str = "GBP",
    ) -> "Tariff":
        """A simple two-rate tariff repeated over the horizon."""
        pairs: list[tuple[float, float]] = []
        for hour in range(int(horizon_hours) + 1):
            hour_of_day = hour % 24
            price = (
                peak_price if peak_start_hour <= hour_of_day < peak_end_hour else off_peak_price
            )
            pairs.append((hour * SECONDS_PER_HOUR, price))
        return cls(
            import_price=PriceCurve.from_pairs(pairs, currency=currency, name="time-of-use"),
            export_price=(
                PriceCurve.flat(export_price, currency=currency)
                if export_price is not None
                else None
            ),
            currency=currency,
            name="time-of-use",
        )

    def import_at(self, t_s: float | np.ndarray) -> np.ndarray:
        return self.import_price.at(t_s)

    def export_at(self, t_s: float | np.ndarray) -> np.ndarray:
        if self.export_price is None:
            return np.zeros_like(np.asarray(t_s, dtype=float))
        return self.export_price.at(t_s)

    @property
    def arbitrage_spread(self) -> float:
        return self.import_price.spread

    def as_dict(self) -> dict[str, object]:
        return {
            "name": self.name,
            "currency": self.currency,
            "import": self.import_price.as_dict(),
            "export": self.export_price.as_dict() if self.export_price else None,
            "demand_charge_per_kw": self.demand_charge_per_kw,
            "standing_charge_per_day": self.standing_charge_per_day,
        }


def uk_style_day_ahead(seed: int = 0, hours: int = 48, currency: str = "GBP") -> PriceCurve:
    """A synthetic but realistically shaped half-hourly wholesale price curve.

    Two demand peaks (morning and evening), a solar-driven midday trough that
    can go negative, and autocorrelated noise. Used for demos and tests; it is
    explicitly synthetic and must not be presented as market data.
    """
    rng = np.random.default_rng(seed)
    n = hours * 2
    t = np.arange(n) / 2.0
    hod = t % 24.0
    base = (
        70.0
        + 45.0 * np.exp(-0.5 * ((hod - 8.0) / 1.6) ** 2)
        + 70.0 * np.exp(-0.5 * ((hod - 18.0) / 2.0) ** 2)
        - 45.0 * np.exp(-0.5 * ((hod - 13.0) / 2.8) ** 2)
    )
    noise = np.zeros(n)
    for k in range(1, n):
        noise[k] = 0.85 * noise[k - 1] + rng.normal(0.0, 9.0)
    prices = np.maximum(base + noise, -30.0) / 1000.0  # currency per kWh
    return PriceCurve.half_hourly(prices, currency=currency, name="synthetic day-ahead")


__all__ = ["PriceCurve", "Tariff", "uk_style_day_ahead"]
