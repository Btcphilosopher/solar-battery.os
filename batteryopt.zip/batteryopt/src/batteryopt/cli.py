"""Command-line interface.

Everything the platform does, reachable without writing Python. The commands
map onto the specification's sections rather than onto the code's modules,
because that is how the questions arrive:

.. code-block:: text

    batteryopt chemistries              list the built-in parameter sets
    batteryopt describe --chemistry nmc  what does this battery look like
    batteryopt optimise                  what should it do now (section 27)
    batteryopt charge                    plan a charge (section 6)
    batteryopt mission                   plan for a journey (section 7)
    batteryopt arbitrage                 charge / hold / discharge (section 16)
    batteryopt lifetime                  compare operating policies (section 20)
    batteryopt pareto                    show the trade-offs (section 5)
    batteryopt study                     run a prepared study (section 28)
    batteryopt validate                  analytical checks (section 34)
    batteryopt simulate                  run a virtual battery end to end
    batteryopt serve                     start the API and dashboard
    batteryopt capabilities              which optional extras are active
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
from typing import Any, Sequence

from .core.optional import capability_summary
from .core.versioning import version_report


def _battery_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--chemistry", default="nmc", help="registered chemistry name")
    parser.add_argument("--series", type=int, default=96, help="cells in series")
    parser.add_argument("--parallel", type=int, default=4, help="cells in parallel")
    parser.add_argument("--cell-capacity-ah", type=float, default=None)
    parser.add_argument("--age-years", type=float, default=0.0)
    parser.add_argument("--cycles", type=float, default=0.0, help="equivalent full cycles")
    parser.add_argument("--soc", type=float, default=0.5)
    parser.add_argument("--temperature", type=float, default=25.0, help="cell temperature, degC")
    parser.add_argument("--ambient", type=float, default=None, help="ambient temperature, degC")
    parser.add_argument("--max-charge-kw", type=float, default=None)
    parser.add_argument("--max-discharge-kw", type=float, default=None)


def _build_battery(args: argparse.Namespace):
    from .models.battery import Battery

    battery = Battery.build(
        chemistry=args.chemistry,
        cells_series=args.series,
        cells_parallel=args.parallel,
        cell_capacity_ah=args.cell_capacity_ah,
        battery_id=getattr(args, "battery_id", "cli-battery"),
        max_charge_power_w=(args.max_charge_kw * 1000.0) if args.max_charge_kw else None,
        max_discharge_power_w=(args.max_discharge_kw * 1000.0) if args.max_discharge_kw else None,
    )
    if args.age_years > 0 or args.cycles > 0:
        battery = Battery.aged(
            battery, years=args.age_years, equivalent_full_cycles=args.cycles
        )
    return battery


def _tariff(args: argparse.Namespace):
    from .economics.prices import Tariff, uk_style_day_ahead

    if getattr(args, "day_ahead", False):
        curve = uk_style_day_ahead(seed=getattr(args, "seed", 0), hours=48)
        return Tariff(import_price=curve, export_price=curve, name="synthetic day-ahead")
    if getattr(args, "peak_price", None) is not None:
        return Tariff.time_of_use(
            peak_price=args.peak_price,
            off_peak_price=args.off_peak_price,
            export_price=getattr(args, "export_price", None),
        )
    if getattr(args, "price", None) is not None:
        return Tariff.flat(args.price, getattr(args, "export_price", None))
    return None


def _emit(payload: Any, *, as_json: bool) -> None:
    if as_json:
        print(json.dumps(payload, indent=2, default=str))
    else:
        print(payload)


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------


def cmd_chemistries(args: argparse.Namespace) -> int:
    from .models.chemistry import available_chemistries, get_chemistry

    rows = []
    for name in available_chemistries():
        chem = get_chemistry(name)
        rows.append(
            {
                "name": chem.name,
                "family": chem.family,
                "nominal_voltage_cell": chem.nominal_voltage_cell,
                "capacity_ah": chem.nominal_capacity_ah,
                "v_window": [chem.envelope.v_min_cell, chem.envelope.v_max_cell],
                "max_charge_c": chem.envelope.max_charge_c_rate,
                "max_discharge_c": chem.envelope.max_discharge_c_rate,
                "source": chem.parameter_source,
            }
        )
    if args.json:
        _emit(rows, as_json=True)
        return 0
    print(f"{'NAME':<22} {'FAMILY':<12} {'V/CELL':>7} {'Ah':>8} {'CHG C':>6} {'DIS C':>6}")
    print("-" * 66)
    for row in rows:
        print(
            f"{row['name']:<22} {row['family']:<12} {row['nominal_voltage_cell']:7.2f} "
            f"{row['capacity_ah']:8.1f} {row['max_charge_c']:6.2f} {row['max_discharge_c']:6.2f}"
        )
    print("\nBuilt-in parameter sets are representative literature values for a class of")
    print("chemistry, not a datasheet for any product. Fit your own before deployment.")
    return 0


def cmd_describe(args: argparse.Namespace) -> int:
    battery = _build_battery(args)
    _emit(battery.describe(), as_json=True)
    return 0


def cmd_optimise(args: argparse.Namespace) -> int:
    from .optimisation.engine import OptimisationEngine

    battery = _build_battery(args)
    engine = OptimisationEngine(
        battery, objective=args.objective, tariff=_tariff(args), method=args.method
    )
    state = battery.initial_state(
        soc=args.soc,
        temperature_c=args.temperature,
        ambient_c=args.ambient if args.ambient is not None else args.temperature,
    )
    recommendation = engine.optimise_state(
        state,
        demand=args.demand_kw * 1000.0 if args.demand_kw is not None else None,
        horizon_s=args.horizon_min * 60.0,
        dt_s=args.step_s,
        ambient_c=args.ambient,
    )
    if args.json:
        _emit(recommendation.as_dict(), as_json=True)
        return 0
    print(recommendation.summary())
    print()
    print("WHY")
    if recommendation.objective_value:
        for name, amount in sorted(
            recommendation.objective_value.weighted_terms.items(),
            key=lambda kv: abs(kv[1]),
            reverse=True,
        ):
            if abs(amount) > 1e-9:
                print(f"  {name:<16} {amount:+10.4f} {recommendation.currency}")
    print()
    print(recommendation.reason)
    return 0


def cmd_charge(args: argparse.Namespace) -> int:
    from .applications.charging import SmartCharger
    from .optimisation.engine import OptimisationEngine

    battery = _build_battery(args)
    engine = OptimisationEngine(battery, objective=args.objective, tariff=_tariff(args))
    charger = SmartCharger(engine)
    state = battery.initial_state(
        soc=args.soc,
        temperature_c=args.temperature,
        ambient_c=args.ambient if args.ambient is not None else args.temperature,
    )
    if args.compare:
        plans = charger.compare_rates(
            state,
            target_soc=args.target_soc,
            deadline_s=args.deadline_h * 3600.0,
            tariff=_tariff(args),
            ambient_c=args.ambient,
        )
        print(SmartCharger.comparison_table(plans))
        return 0
    plan = charger.plan(
        state,
        target_soc=args.target_soc,
        deadline_s=args.deadline_h * 3600.0,
        tariff=_tariff(args),
        ambient_c=args.ambient,
    )
    if args.json:
        _emit(plan.as_dict(), as_json=True)
        return 0
    print(plan.summary())
    print()
    print(plan.reason)
    return 0


def cmd_mission(args: argparse.Namespace) -> int:
    from .applications.mission import MissionPlanner
    from .core.provenance import Quantiles
    from .optimisation.engine import OptimisationEngine
    from .optimisation.problem import Mission

    battery = _build_battery(args)
    engine = OptimisationEngine(battery, objective="ev", tariff=_tariff(args))
    planner = MissionPlanner(engine)
    energy_wh = args.energy_kwh * 1000.0
    mission = Mission(
        energy_wh=energy_wh,
        departure_s=args.departure_h * 3600.0,
        quantiles=Quantiles(energy_wh * 0.92, energy_wh, energy_wh * 1.12),
        required_reliability=args.reliability,
        reserve_soc=args.reserve,
        ambient_c=args.ambient,
    )
    state = battery.initial_state(
        soc=args.soc,
        temperature_c=args.temperature,
        ambient_c=args.ambient if args.ambient is not None else args.temperature,
    )
    plan = planner.plan(state, mission, ambient_c=args.ambient, tariff=_tariff(args))
    if args.json:
        _emit(plan.as_dict(), as_json=True)
        return 0
    print(planner.report(plan, state))
    print()
    print(plan.reason)
    return 0


def cmd_arbitrage(args: argparse.Namespace) -> int:
    from .applications.arbitrage import ArbitrageOptimiser
    from .optimisation.engine import OptimisationEngine

    tariff = _tariff(args)
    if tariff is None:
        print("arbitrage needs a tariff: pass --day-ahead, --price or --peak-price",
              file=sys.stderr)
        return 2
    battery = _build_battery(args)
    engine = OptimisationEngine(battery, objective=args.objective, tariff=tariff)
    optimiser = ArbitrageOptimiser(engine)
    state = battery.initial_state(soc=args.soc, temperature_c=args.temperature)
    plan = optimiser.plan(
        state, tariff=tariff, horizon_s=args.horizon_h * 3600.0, dt_s=args.step_s
    )
    if args.json:
        _emit(plan.as_dict(), as_json=True)
        return 0
    print(plan.summary())
    print()
    print(plan.reason)
    print()
    print("SCHEDULE (kW, positive = discharge)")
    print(
        "  "
        + " ".join(f"{p / 1000.0:6.0f}" for p in plan.schedule_w[: int(48)])
    )
    return 0


def cmd_lifetime(args: argparse.Namespace) -> int:
    from .applications.lifetime import LifetimeOptimiser, standard_policies

    battery = _build_battery(args)
    optimiser = LifetimeOptimiser(battery)
    results = optimiser.compare(standard_policies(cycles_per_year=args.cycles_per_year))
    if args.json:
        _emit([r.as_dict() for r in results], as_json=True)
        return 0
    print(LifetimeOptimiser.table(results))
    print()
    best, worst = results[0], results[-1]
    gain = (
        best.lifetime_energy_wh / worst.lifetime_energy_wh - 1.0
        if worst.lifetime_energy_wh > 0
        else 0.0
    )
    print(
        f"The {best.policy.name} policy delivers {gain * 100:.0f}% more lifetime energy "
        f"than {worst.policy.name}, at {best.cost_per_kwh_delivered:.4f} versus "
        f"{worst.cost_per_kwh_delivered:.4f} {best.currency} per delivered kWh."
    )
    return 0


def cmd_pareto(args: argparse.Namespace) -> int:
    from .optimisation.engine import OptimisationEngine

    battery = _build_battery(args)
    engine = OptimisationEngine(battery, objective=args.objective, tariff=_tariff(args))
    problem = engine.build_problem(
        battery.initial_state(soc=args.soc, temperature_c=args.temperature),
        demand=args.demand_kw * 1000.0 if args.demand_kw is not None else None,
        horizon_s=args.horizon_min * 60.0,
        dt_s=args.step_s,
    )
    front = engine.pareto(problem)
    if args.json:
        _emit(front.as_dict(), as_json=True)
        return 0
    print(front.table())
    return 0


def cmd_validate(args: argparse.Namespace) -> int:
    from .validation import compare_with_pybamm, validate_battery

    battery = _build_battery(args)
    report = validate_battery(battery)
    if args.json:
        payload = report.as_dict()
        payload["cross_model"] = compare_with_pybamm(battery).as_dict()
        _emit(payload, as_json=True)
        return 0 if report.passed else 1
    print(report.summary())
    print()
    print(compare_with_pybamm(battery).summary())
    return 0 if report.passed else 1


def cmd_study(args: argparse.Namespace) -> int:
    from . import research

    battery = _build_battery(args)
    studies = {
        "charging": lambda: research.charging_strategy_study(battery, tariff=_tariff(args)),
        "lifetime": lambda: research.policy_lifetime_study(battery),
        "mission": lambda: research.mission_reliability_study(battery),
        "chemistry": research.chemistry_comparison_study,
        "temperature": lambda: research.temperature_policy_study(battery),
    }
    if args.name not in studies:
        print(f"unknown study {args.name!r}; choose from {', '.join(sorted(studies))}",
              file=sys.stderr)
        return 2
    result = studies[args.name]()
    if args.json:
        _emit({"summary": result.summary(), "rows": result.to_rows()}, as_json=True)
        return 0
    _emit(json.dumps(result.summary(), indent=2), as_json=False)
    print()
    keys = sorted(
        {k for e in result.successes for k, v in e.outputs.items() if isinstance(v, (int, float))}
    )
    print(result.table(keys[:5], limit=30))
    return 0


def cmd_simulate(args: argparse.Namespace) -> int:
    from .economics.prices import Tariff
    from .optimisation.engine import OptimisationEngine
    from .telemetry.pipeline import TelemetryPipeline
    from .telemetry.sources.simulated import SimulatedSource, drive_cycle, storage_cycle
    from .twin.twin import DigitalTwin

    battery = _build_battery(args)
    profile = (
        drive_cycle(peak_w=args.peak_kw * 1000.0)
        if args.profile == "drive"
        else storage_cycle(
            charge_w=args.peak_kw * 1000.0, discharge_w=args.peak_kw * 1000.0
        )
    )
    source = SimulatedSource(
        battery,
        initial_soc=args.soc,
        initial_temperature_c=args.temperature,
        ambient_c=args.ambient if args.ambient is not None else args.temperature,
        dt_s=args.step_s,
        duty_cycle=profile,
        n_cell_sensors=12,
        dropout_rate=args.dropout,
        seed=args.seed,
    )
    twin = DigitalTwin(
        battery, initial_soc=args.soc, initial_temperature_c=args.temperature
    )
    engine = OptimisationEngine(battery, objective=args.objective, tariff=_tariff(args))
    pipeline = TelemetryPipeline(
        twin, engine, optimise_interval_s=args.optimise_interval_s, horizon_s=600.0, dt_s=60.0
    )
    pipeline.run_sync(source.frames(args.frames))

    payload = {
        "true_soc": source.state.soc,
        "estimated_soc": twin.state.soc,
        "soc_error": abs(twin.state.soc - source.state.soc),
        "current_sensor_offset_a": source.current_offset_a,
        "pipeline": pipeline.stats.as_dict(),
        "validation": pipeline.validator.stats.as_dict(),
        "recommendation": (
            pipeline.latest_recommendation.summary()
            if pipeline.latest_recommendation
            else None
        ),
    }
    if args.json:
        _emit(payload, as_json=True)
        return 0
    print(f"Simulated {args.frames} frames at {args.step_s:.0f} s.")
    print(
        f"  true SOC {payload['true_soc'] * 100:.2f}%   estimated "
        f"{payload['estimated_soc'] * 100:.2f}%   error "
        f"{payload['soc_error'] * 100:.3f} percentage points"
    )
    print(
        f"  (the estimator did not know the current sensor had a "
        f"{source.current_offset_a:+.3f} A offset)"
    )
    print(f"  frames accepted {pipeline.stats.frames_accepted}, "
          f"rejected {pipeline.stats.frames_rejected}")
    print(f"  optimisations {pipeline.stats.optimisations}, "
          f"mean {pipeline.stats.mean_optimise_ms:.1f} ms")
    if pipeline.latest_recommendation:
        print(f"  latest: {pipeline.latest_recommendation.summary()}")
    return 0


def cmd_serve(args: argparse.Namespace) -> int:  # pragma: no cover - process entry
    from .api.app import serve

    serve(host=args.host, port=args.port, demo=args.demo, log_level=args.log_level)
    return 0


def cmd_capabilities(args: argparse.Namespace) -> int:
    if args.json:
        from .core.optional import capabilities

        _emit({"versions": dict(version_report()), "optional": capabilities()}, as_json=True)
        return 0
    print("BatteryOpt " + version_report()["code"])
    for key, value in version_report().items():
        print(f"  {key:<10} {value}")
    print("\nOptional dependencies:")
    print(capability_summary())
    return 0


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="batteryopt",
        description=(
            "Battery optimisation, simulation and decision engine. Produces "
            "recommendations for an existing BMS or EMS. Not a battery management "
            "system and not a substitute for independent protection."
        ),
    )
    parser.add_argument("--json", action="store_true", help="emit JSON")
    parser.add_argument("--verbose", "-v", action="count", default=0)
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("chemistries", help="list built-in chemistries")
    p.set_defaults(func=cmd_chemistries)

    p = sub.add_parser("describe", help="describe a battery configuration")
    _battery_arguments(p)
    p.set_defaults(func=cmd_describe)

    p = sub.add_parser("optimise", help="recommend an operating point")
    _battery_arguments(p)
    p.add_argument("--objective", default="balanced")
    p.add_argument("--demand-kw", type=float, default=None)
    p.add_argument("--horizon-min", type=float, default=15.0)
    p.add_argument("--step-s", type=float, default=60.0)
    p.add_argument("--method", default="auto")
    p.add_argument("--price", type=float, default=None, help="flat import price per kWh")
    p.add_argument("--export-price", type=float, default=None)
    p.add_argument("--peak-price", type=float, default=None)
    p.add_argument("--off-peak-price", type=float, default=0.09)
    p.add_argument("--day-ahead", action="store_true")
    p.add_argument("--seed", type=int, default=0)
    p.set_defaults(func=cmd_optimise)

    p = sub.add_parser("charge", help="plan a charging session")
    _battery_arguments(p)
    p.add_argument("--target-soc", type=float, default=0.8)
    p.add_argument("--deadline-h", type=float, default=8.0)
    p.add_argument("--objective", default="ev")
    p.add_argument("--compare", action="store_true", help="fast/normal/slow comparison")
    p.add_argument("--price", type=float, default=None)
    p.add_argument("--export-price", type=float, default=None)
    p.add_argument("--peak-price", type=float, default=None)
    p.add_argument("--off-peak-price", type=float, default=0.09)
    p.add_argument("--day-ahead", action="store_true")
    p.add_argument("--seed", type=int, default=0)
    p.set_defaults(func=cmd_charge)

    p = sub.add_parser("mission", help="plan charging around a future mission")
    _battery_arguments(p)
    p.add_argument("--energy-kwh", type=float, default=54.0)
    p.add_argument("--departure-h", type=float, default=8.0)
    p.add_argument("--reliability", type=float, default=0.9)
    p.add_argument("--reserve", type=float, default=0.08)
    p.add_argument("--price", type=float, default=None)
    p.add_argument("--export-price", type=float, default=None)
    p.add_argument("--peak-price", type=float, default=None)
    p.add_argument("--off-peak-price", type=float, default=0.09)
    p.add_argument("--day-ahead", action="store_true")
    p.add_argument("--seed", type=int, default=0)
    p.set_defaults(func=cmd_mission)

    p = sub.add_parser("arbitrage", help="charge, hold or discharge against prices")
    _battery_arguments(p)
    p.add_argument("--objective", default="grid_storage")
    p.add_argument("--horizon-h", type=float, default=24.0)
    p.add_argument("--step-s", type=float, default=1800.0)
    p.add_argument("--price", type=float, default=None)
    p.add_argument("--export-price", type=float, default=None)
    p.add_argument("--peak-price", type=float, default=None)
    p.add_argument("--off-peak-price", type=float, default=0.09)
    p.add_argument("--day-ahead", action="store_true")
    p.add_argument("--seed", type=int, default=0)
    p.set_defaults(func=cmd_arbitrage)

    p = sub.add_parser("lifetime", help="compare operating policies over the whole life")
    _battery_arguments(p)
    p.add_argument("--cycles-per-year", type=float, default=300.0)
    p.set_defaults(func=cmd_lifetime)

    p = sub.add_parser("pareto", help="show the trade-off front")
    _battery_arguments(p)
    p.add_argument("--objective", default="balanced")
    p.add_argument("--demand-kw", type=float, default=None)
    p.add_argument("--horizon-min", type=float, default=15.0)
    p.add_argument("--step-s", type=float, default=60.0)
    p.add_argument("--price", type=float, default=None)
    p.add_argument("--export-price", type=float, default=None)
    p.add_argument("--peak-price", type=float, default=None)
    p.add_argument("--off-peak-price", type=float, default=0.09)
    p.add_argument("--day-ahead", action="store_true")
    p.add_argument("--seed", type=int, default=0)
    p.set_defaults(func=cmd_pareto)

    p = sub.add_parser("validate", help="run analytical validation checks")
    _battery_arguments(p)
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("study", help="run a prepared research study")
    _battery_arguments(p)
    p.add_argument(
        "name",
        choices=["charging", "lifetime", "mission", "chemistry", "temperature"],
    )
    p.add_argument("--price", type=float, default=0.15)
    p.add_argument("--export-price", type=float, default=None)
    p.add_argument("--peak-price", type=float, default=None)
    p.add_argument("--off-peak-price", type=float, default=0.09)
    p.add_argument("--day-ahead", action="store_true")
    p.add_argument("--seed", type=int, default=0)
    p.set_defaults(func=cmd_study)

    p = sub.add_parser("simulate", help="run a virtual battery through the whole pipeline")
    _battery_arguments(p)
    p.add_argument("--frames", type=int, default=600)
    p.add_argument("--step-s", type=float, default=1.0)
    p.add_argument("--profile", choices=["drive", "storage"], default="drive")
    p.add_argument("--peak-kw", type=float, default=50.0)
    p.add_argument("--dropout", type=float, default=0.01)
    p.add_argument("--objective", default="ev")
    p.add_argument("--optimise-interval-s", type=float, default=60.0)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--price", type=float, default=None)
    p.add_argument("--export-price", type=float, default=None)
    p.add_argument("--peak-price", type=float, default=None)
    p.add_argument("--off-peak-price", type=float, default=0.09)
    p.add_argument("--day-ahead", action="store_true")
    p.set_defaults(func=cmd_simulate)

    p = sub.add_parser("serve", help="run the HTTP service and dashboard")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=8000)
    p.add_argument("--demo", action="store_true", help="seed a simulated battery")
    p.add_argument("--log-level", default="info")
    p.set_defaults(func=cmd_serve)

    p = sub.add_parser("capabilities", help="show versions and optional extras")
    p.set_defaults(func=cmd_capabilities)

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    logging.basicConfig(
        level=logging.WARNING - min(args.verbose, 2) * 10,
        format="%(levelname)s %(name)s: %(message)s",
    )
    try:
        return int(args.func(args) or 0)
    except KeyboardInterrupt:  # pragma: no cover
        return 130
    except Exception as exc:  # noqa: BLE001 - the CLI reports, it does not traceback
        if args.verbose:
            raise
        print(f"error: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
