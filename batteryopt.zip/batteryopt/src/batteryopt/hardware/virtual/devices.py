"""Virtual hardware (specification section 33).

A complete set of devices backed by the plant model, so the entire platform --
pipeline, optimiser, MPC, API, dashboard -- can be exercised end to end with no
hardware present. This is not a stub layer: the virtual devices have realistic
imperfections, because software that has only met perfect hardware breaks on
contact with the real thing.

What is deliberately imperfect:

* the charger tapers near full and has a finite ramp rate;
* the inverter has a load-dependent efficiency curve with poor part-load
  behaviour, which is where a real inverter loses its energy;
* the thermal system has first-order lag, so a cooling command does not take
  effect instantly;
* the BMS applies its *own* limits on top of whatever BatteryOpt advises, and
  reports its own SOC, which drifts -- exactly the situation a real integration
  faces.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Sequence

import numpy as np

from ...core.numerics import EPS, clamp
from ...estimation.base import Measurement
from ...models.battery import Battery
from ...models.plant import Action, BatteryPlant
from ...models.state import BatteryState
from ..interfaces import (
    DeviceInfo,
    DeviceRegistry,
    DeviceStatus,
    OperatingLimits,
)


class VirtualCell:
    """One cell of the virtual pack, with its own manufacturing spread."""

    def __init__(self, index: int, *, capacity_offset: float, resistance_offset: float) -> None:
        self.index = index
        self.capacity_offset = capacity_offset
        self.resistance_offset = resistance_offset
        self._voltage = 0.0
        self._temperature = 25.0
        self._balancing = False

    def info(self) -> DeviceInfo:
        return DeviceInfo(
            device_id=f"cell-{self.index}",
            kind="cell",
            manufacturer="virtual",
            capabilities=("voltage", "balancing"),
        )

    def voltage(self) -> float:
        return self._voltage

    def temperature(self) -> float | None:
        return self._temperature

    def balancing_active(self) -> bool:
        return self._balancing

    def set_balancing(self, active: bool) -> None:
        self._balancing = bool(active)

    def update(self, pack_voltage_per_cell: float, temperature_c: float, slope: float) -> None:
        self._voltage = pack_voltage_per_cell + self.capacity_offset * max(slope, 0.05)
        self._temperature = temperature_c


class VirtualModule:
    """A module of virtual cells."""

    def __init__(self, index: int, cells: Sequence[VirtualCell]) -> None:
        self.index = index
        self._cells = list(cells)

    def info(self) -> DeviceInfo:
        return DeviceInfo(device_id=f"module-{self.index}", kind="module", manufacturer="virtual")

    def cells(self) -> Sequence[VirtualCell]:
        return self._cells

    def voltage(self) -> float:
        return sum(c.voltage() for c in self._cells)

    def temperatures(self) -> Sequence[float]:
        return [c.temperature() or 25.0 for c in self._cells]


class VirtualPack:
    """The virtual pack: owns the plant model and the true state."""

    def __init__(
        self,
        battery: Battery,
        *,
        initial_soc: float = 0.5,
        initial_temperature_c: float = 25.0,
        ambient_c: float = 20.0,
        n_cell_sensors: int = 12,
        seed: int = 0,
    ) -> None:
        self.battery = battery
        self.plant = BatteryPlant(battery, track_states=False)
        self.state: BatteryState = battery.initial_state(
            soc=initial_soc, temperature_c=initial_temperature_c, ambient_c=ambient_c
        )
        self.ambient_c = ambient_c
        self._contactors = True
        rng = np.random.default_rng(seed)
        spread = battery.topology.cell.capacity_sigma
        r_spread = battery.topology.cell.resistance_sigma
        cells = [
            VirtualCell(
                k,
                capacity_offset=float(rng.normal(0.0, spread)),
                resistance_offset=float(rng.normal(0.0, r_spread)),
            )
            for k in range(n_cell_sensors)
        ]
        self._modules = [VirtualModule(0, cells)]
        self._refresh_cells()

    def info(self) -> DeviceInfo:
        return DeviceInfo(
            device_id=f"pack-{self.battery.battery_id}",
            kind="pack",
            manufacturer="virtual",
            model=self.battery.chemistry_name,
            capabilities=("voltage", "current", "temperature", "contactors"),
        )

    def modules(self) -> Sequence[VirtualModule]:
        return self._modules

    def voltage(self) -> float:
        return self.state.voltage_v

    def current(self) -> float:
        return self.state.current_a

    def temperatures(self) -> Sequence[float]:
        return [self.state.temperature_min_c, self.state.temperature_c, self.state.temperature_max_c]

    def contactors_closed(self) -> bool:
        return self._contactors

    def open_contactors(self) -> None:
        self._contactors = False

    def close_contactors(self) -> None:
        self._contactors = True

    def _refresh_cells(self) -> None:
        per_cell = self.state.voltage_v / max(self.battery.topology.n_series, 1)
        slope = self.battery.chemistry.ocv.slope_at(self.state.soc)
        for module in self._modules:
            for cell in module.cells():
                cell.update(per_cell, self.state.temperature_c, slope)

    def step(
        self, *, power_w: float, dt_s: float, cooling: float = 0.0, heating: float = 0.0
    ) -> BatteryState:
        """Advance the virtual pack. Open contactors force zero power."""
        applied = 0.0 if not self._contactors else power_w
        result = self.plant.step(
            self.state,
            Action(power_w=applied, cooling_fraction=cooling, heating_fraction=heating),
            dt_s,
            ambient_c=self.ambient_c,
        )
        self.state = result.state
        self._refresh_cells()
        return self.state


class VirtualBMS:
    """A virtual BMS with its own limits, its own SOC and its own opinions.

    Two details make this useful rather than decorative:

    * It applies its own protection limits *on top of* whatever BatteryOpt
      advises, and narrows rather than widens. An integration that assumes its
      advice is obeyed exactly will be caught here.
    * Its reported SOC is a simple coulomb counter with an offset error, so it
      drifts away from the truth over hours -- which is the behaviour that makes
      independent state estimation worth doing in the first place.
    """

    def __init__(
        self,
        pack: VirtualPack,
        *,
        soc_offset: float = 0.03,
        soc_drift_per_hour: float = 0.004,
        noise_seed: int = 1,
    ) -> None:
        self.pack = pack
        self._limits = OperatingLimits()
        self._reported_soc = clamp(pack.state.soc + soc_offset, 0.0, 1.0)
        self.soc_drift_per_hour = soc_drift_per_hour
        self._rng = np.random.default_rng(noise_seed)
        self._faults: list[str] = []
        self._elapsed_s = 0.0

    def info(self) -> DeviceInfo:
        status = DeviceStatus.FAULT if self._faults else DeviceStatus.OK
        return DeviceInfo(
            device_id="bms-virtual",
            kind="bms",
            manufacturer="virtual",
            firmware="1.0",
            status=status,
            capabilities=("measurement", "limits", "faults"),
        )

    def read_measurement(self) -> Measurement:
        state = self.pack.state
        cells = [c.voltage() for m in self.pack.modules() for c in m.cells()]
        return Measurement(
            timestamp=state.timestamp,
            voltage_v=state.voltage_v + float(self._rng.normal(0.0, 0.01)),
            current_a=state.current_a + float(self._rng.normal(0.0, 0.3)),
            temperature_c=state.temperature_c + float(self._rng.normal(0.0, 0.2)),
            ambient_c=state.ambient_c,
            coolant_c=state.coolant_c,
            cell_voltages_v=tuple(cells),
            reported_soc=self._reported_soc,
            voltage_sigma_v=0.01,
            current_sigma_a=0.3,
            temperature_sigma_c=0.2,
        )

    def reported_state(self) -> BatteryState | None:
        """The BMS's own view. Deliberately less accurate than the twin's."""
        state = self.pack.state
        return state.evolve(soc=self._reported_soc)

    def apply_limits(self, limits: OperatingLimits) -> bool:
        """Accept advisory limits, intersected with the BMS's own protection."""
        battery = self.pack.battery
        own_charge = battery.maximum_charge_current
        own_discharge = battery.maximum_current
        self._limits = OperatingLimits(
            max_charge_current_a=min(
                limits.max_charge_current_a or own_charge, own_charge
            ),
            max_discharge_current_a=min(
                limits.max_discharge_current_a or own_discharge, own_discharge
            ),
            max_charge_power_w=limits.max_charge_power_w,
            max_discharge_power_w=limits.max_discharge_power_w,
            max_voltage_v=min(
                limits.max_voltage_v or battery.maximum_voltage, battery.maximum_voltage
            ),
            min_voltage_v=max(
                limits.min_voltage_v or battery.minimum_voltage, battery.minimum_voltage
            ),
            target_soc=limits.target_soc,
            reason=f"advisory intersected with BMS protection: {limits.reason}",
        )
        return True

    @property
    def limits(self) -> OperatingLimits:
        return self._limits

    def active_faults(self) -> Sequence[str]:
        return list(self._faults)

    def inject_fault(self, name: str) -> None:
        """Force a fault, for testing the pipeline's degraded paths."""
        self._faults.append(name)

    def clear_faults(self) -> None:
        self._faults.clear()

    def tick(self, dt_s: float) -> None:
        """Advance the BMS's own (drifting) charge counter."""
        self._elapsed_s += dt_s
        capacity = max(self.pack.battery.capacity, EPS)
        d_soc = -self.pack.state.current_a * dt_s / (3600.0 * capacity)
        drift = self.soc_drift_per_hour * dt_s / 3600.0
        self._reported_soc = clamp(self._reported_soc + d_soc + drift, 0.0, 1.0)


class VirtualCharger:
    """A charger with a ramp rate and a taper near full."""

    def __init__(self, *, rated_power_w: float, ramp_w_per_s: float = 5000.0) -> None:
        self.rated_power_w = rated_power_w
        self.ramp_w_per_s = ramp_w_per_s
        self._setpoint = 0.0
        self._actual = 0.0
        self._connected = True

    def info(self) -> DeviceInfo:
        return DeviceInfo(
            device_id="charger-virtual",
            kind="charger",
            manufacturer="virtual",
            capabilities=("power_control", "bidirectional"),
        )

    def available_power_w(self) -> float:
        return self.rated_power_w if self._connected else 0.0

    def set_power(self, power_w: float, *, advisory: bool = True) -> bool:
        self._setpoint = clamp(power_w, -self.rated_power_w, self.rated_power_w)
        return True

    def actual_power_w(self) -> float:
        return self._actual

    def is_connected(self) -> bool:
        return self._connected

    def disconnect(self) -> None:
        self._connected = False
        self._setpoint = 0.0

    def connect(self) -> None:
        self._connected = True

    def tick(self, dt_s: float) -> float:
        """Ramp towards the setpoint and return the power actually delivered."""
        if not self._connected:
            self._actual = 0.0
            return 0.0
        limit = self.ramp_w_per_s * dt_s
        delta = clamp(self._setpoint - self._actual, -limit, limit)
        self._actual += delta
        return self._actual


class VirtualInverter:
    """A grid-tied inverter with a realistic part-load efficiency curve.

    Efficiency peaks around 40 % of rating and falls away sharply below 10 %,
    which is why running a large inverter at a trickle is expensive and why the
    optimiser should know about it.
    """

    def __init__(
        self,
        *,
        rated_power_w: float,
        peak_efficiency: float = 0.975,
        standby_fraction: float = 0.004,
        standby_w: float | None = None,
    ) -> None:
        self.rated_power_w = rated_power_w
        self.peak_efficiency = peak_efficiency
        #: Standby draw as a fraction of rating. Expressed as a fraction
        #: rather than an absolute figure because that is how it actually
        #: scales: a 250 kW inverter does not idle on the same 40 W as a 5 kW
        #: one, and a fixed value makes part-load losses vanish on large units,
        #: which is exactly where they hurt most.
        self.standby_w = (
            standby_w if standby_w is not None else standby_fraction * rated_power_w
        )
        self._setpoint = 0.0

    def info(self) -> DeviceInfo:
        return DeviceInfo(
            device_id="inverter-virtual",
            kind="inverter",
            manufacturer="virtual",
            capabilities=("power_control", "four_quadrant"),
        )

    def set_power(self, power_w: float, *, advisory: bool = True) -> bool:
        self._setpoint = clamp(power_w, -self.rated_power_w, self.rated_power_w)
        return True

    def actual_power_w(self) -> float:
        return self._setpoint

    def efficiency_at(self, power_w: float) -> float:
        """Load-dependent conversion efficiency."""
        load = abs(power_w) / max(self.rated_power_w, EPS)
        if load <= 1e-4:
            return 0.0
        # Standby loss plus a load-dependent conduction loss.
        losses = self.standby_w / max(self.rated_power_w, EPS) / load + (
            1.0 - self.peak_efficiency
        ) * (0.35 + 0.65 * load)
        return clamp(1.0 - losses, 0.0, 1.0)

    def limits_w(self) -> tuple[float, float]:
        return -self.rated_power_w, self.rated_power_w


class VirtualThermalSystem:
    """Cooling and heating with first-order actuator lag."""

    def __init__(
        self,
        battery: Battery,
        *,
        time_constant_s: float = 20.0,
        coolant_setpoint_c: float = 18.0,
    ) -> None:
        self.battery = battery
        self.time_constant_s = time_constant_s
        self.coolant_setpoint_c = coolant_setpoint_c
        self._cooling_command = 0.0
        self._cooling_actual = 0.0
        self._heating_command = 0.0
        self._heating_actual = 0.0

    def info(self) -> DeviceInfo:
        return DeviceInfo(
            device_id="thermal-virtual",
            kind="thermal_system",
            manufacturer="virtual",
            capabilities=("cooling", "heating", "coolant_temperature"),
        )

    def set_cooling(self, fraction: float) -> bool:
        self._cooling_command = clamp(fraction, 0.0, 1.0)
        return True

    def set_heating(self, fraction: float) -> bool:
        self._heating_command = clamp(fraction, 0.0, 1.0)
        return True

    def coolant_temperature_c(self) -> float:
        return self.coolant_setpoint_c

    def parasitic_power_w(self) -> float:
        return self.battery.thermal.parasitic_power(self._cooling_actual, self._heating_actual)

    @property
    def cooling(self) -> float:
        return self._cooling_actual

    @property
    def heating(self) -> float:
        return self._heating_actual

    def tick(self, dt_s: float) -> tuple[float, float]:
        """Advance the actuators towards their commands."""
        alpha = 1.0 - math.exp(-dt_s / max(self.time_constant_s, EPS))
        self._cooling_actual += alpha * (self._cooling_command - self._cooling_actual)
        self._heating_actual += alpha * (self._heating_command - self._heating_actual)
        return self._cooling_actual, self._heating_actual


class VirtualEnergyMeter:
    """A site meter accumulating import and export."""

    def __init__(self) -> None:
        self._power = 0.0
        self._import_wh = 0.0
        self._export_wh = 0.0

    def info(self) -> DeviceInfo:
        return DeviceInfo(
            device_id="meter-virtual", kind="energy_meter", manufacturer="virtual"
        )

    def power_w(self) -> float:
        return self._power

    def cumulative_import_wh(self) -> float:
        return self._import_wh

    def cumulative_export_wh(self) -> float:
        return self._export_wh

    def tick(self, power_w: float, dt_s: float) -> None:
        """Record ``power_w`` at the connection point; positive means import."""
        self._power = power_w
        wh = abs(power_w) * dt_s / 3600.0
        if power_w >= 0:
            self._import_wh += wh
        else:
            self._export_wh += wh


@dataclass(slots=True)
class VirtualSystem:
    """A complete virtual installation, wired together and steppable."""

    battery: Battery
    pack: VirtualPack
    bms: VirtualBMS
    charger: VirtualCharger
    inverter: VirtualInverter
    thermal: VirtualThermalSystem
    meter: VirtualEnergyMeter
    registry: DeviceRegistry = field(default_factory=DeviceRegistry)

    @classmethod
    def build(
        cls,
        battery: Battery,
        *,
        initial_soc: float = 0.5,
        initial_temperature_c: float = 25.0,
        ambient_c: float = 20.0,
        charger_power_w: float | None = None,
        inverter_power_w: float | None = None,
        n_cell_sensors: int = 12,
        seed: int = 0,
    ) -> "VirtualSystem":
        pack = VirtualPack(
            battery,
            initial_soc=initial_soc,
            initial_temperature_c=initial_temperature_c,
            ambient_c=ambient_c,
            n_cell_sensors=n_cell_sensors,
            seed=seed,
        )
        bms = VirtualBMS(pack, noise_seed=seed + 1)
        rated = charger_power_w or battery.maximum_charge_current * battery.nominal_voltage
        charger = VirtualCharger(rated_power_w=rated)
        inverter = VirtualInverter(
            rated_power_w=inverter_power_w
            or battery.maximum_current * battery.nominal_voltage
        )
        thermal = VirtualThermalSystem(battery, coolant_setpoint_c=ambient_c - 2.0)
        meter = VirtualEnergyMeter()
        system = cls(
            battery=battery,
            pack=pack,
            bms=bms,
            charger=charger,
            inverter=inverter,
            thermal=thermal,
            meter=meter,
        )
        system.registry = DeviceRegistry(
            bms=bms, pack=pack, charger=charger, inverter=inverter, thermal=thermal, meter=meter
        )
        return system

    def apply(self, *, power_w: float, cooling: float = 0.0, heating: float = 0.0) -> None:
        """Send commands to the devices. They take effect on the next tick."""
        if power_w < 0:
            self.charger.set_power(power_w)
            self.inverter.set_power(0.0)
        else:
            self.charger.set_power(0.0)
            self.inverter.set_power(power_w)
        self.thermal.set_cooling(cooling)
        self.thermal.set_heating(heating)

    def tick(self, dt_s: float) -> BatteryState:
        """Advance every device by ``dt_s`` and return the true battery state.

        Actuator lag is applied *before* the plant step, so the pack sees the
        power the hardware actually delivered rather than the power that was
        asked for. That gap is the point of the exercise.
        """
        charger_power = self.charger.tick(dt_s)
        cooling, heating = self.thermal.tick(dt_s)
        commanded = charger_power if charger_power < 0 else self.inverter.actual_power_w()
        state = self.pack.step(
            power_w=commanded, dt_s=dt_s, cooling=cooling, heating=heating
        )
        self.bms.tick(dt_s)
        terminal = state.power_w
        parasitic = self.thermal.parasitic_power_w()
        if terminal >= 0:
            grid_power = -(terminal * self.inverter.efficiency_at(terminal) - parasitic)
        else:
            grid_power = -terminal / max(self.inverter.efficiency_at(terminal), EPS) + parasitic
        self.meter.tick(grid_power, dt_s)
        return state

    def measurement(self) -> Measurement:
        return self.bms.read_measurement()

    def describe(self) -> dict[str, Any]:
        return self.registry.describe()


__all__ = [
    "VirtualSystem",
    "VirtualPack",
    "VirtualBMS",
    "VirtualCharger",
    "VirtualInverter",
    "VirtualThermalSystem",
    "VirtualEnergyMeter",
    "VirtualCell",
    "VirtualModule",
]
