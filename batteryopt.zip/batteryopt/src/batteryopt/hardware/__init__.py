"""Hardware abstraction and virtual devices.

Interfaces are structural protocols so that vendor adapters never import the
optimisation layer, and virtual implementations let the whole platform run
without hardware.
"""

from .interfaces import (
    BMSInterface,
    CellInterface,
    ChargerInterface,
    Command,
    DeviceInfo,
    DeviceRegistry,
    DeviceStatus,
    EnergyMeterInterface,
    InverterInterface,
    ModuleInterface,
    OperatingLimits,
    PackInterface,
    PowerConverterInterface,
    Sensor,
    ThermalSystemInterface,
    limits_from_recommendation,
)
from .virtual import (
    VirtualBMS,
    VirtualCharger,
    VirtualEnergyMeter,
    VirtualInverter,
    VirtualPack,
    VirtualSystem,
    VirtualThermalSystem,
)

__all__ = [
    "DeviceStatus",
    "DeviceInfo",
    "Command",
    "OperatingLimits",
    "Sensor",
    "CellInterface",
    "ModuleInterface",
    "PackInterface",
    "BMSInterface",
    "ChargerInterface",
    "InverterInterface",
    "ThermalSystemInterface",
    "PowerConverterInterface",
    "EnergyMeterInterface",
    "DeviceRegistry",
    "limits_from_recommendation",
    "VirtualSystem",
    "VirtualPack",
    "VirtualBMS",
    "VirtualCharger",
    "VirtualInverter",
    "VirtualThermalSystem",
    "VirtualEnergyMeter",
]
