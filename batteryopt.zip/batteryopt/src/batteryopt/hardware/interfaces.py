"""Hardware abstraction (specification section 24).

The rule the specification sets is the one that matters: **manufacturer-specific
integrations must remain separate from the optimisation engine.** Every
interface here is a :class:`typing.Protocol` -- structural, not inherited -- so
a vendor adapter satisfies it by having the right methods and never imports
anything from the optimisation layer. The dependency arrow points one way, and
it points away from the physics.

A second rule is enforced by the shapes of these interfaces: BatteryOpt
*recommends*, and hardware *decides*. :meth:`BMSInterface.apply_limits` sends
advisory limits, not commands, and :class:`Command` carries an explicit
``advisory`` flag that defaults to True. An integration that wants BatteryOpt to
drive a contactor has to say so deliberately, in its own code, and take
responsibility for it. Nothing here can accidentally become a safety system.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Protocol, Sequence, runtime_checkable

from ..estimation.base import Measurement
from ..models.state import BatteryState


class DeviceStatus(str, Enum):
    """Coarse device health, common to every interface."""

    OK = "OK"
    DEGRADED = "DEGRADED"
    FAULT = "FAULT"
    OFFLINE = "OFFLINE"


@dataclass(frozen=True, slots=True)
class DeviceInfo:
    """Identity and capability of one connected device."""

    device_id: str
    kind: str
    manufacturer: str = ""
    model: str = ""
    firmware: str = ""
    status: DeviceStatus = DeviceStatus.OK
    capabilities: tuple[str, ...] = ()
    meta: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "device_id": self.device_id,
            "kind": self.kind,
            "manufacturer": self.manufacturer,
            "model": self.model,
            "firmware": self.firmware,
            "status": self.status.value,
            "capabilities": list(self.capabilities),
        }


@dataclass(frozen=True, slots=True)
class Command:
    """A request sent to a device.

    ``advisory`` defaults to True: BatteryOpt sits *above* the control system
    and its normal output is a recommendation the BMS or EMS is free to clamp,
    delay or ignore. A caller that genuinely wants direct actuation must set it
    to False explicitly, which makes that decision visible in the audit trail.
    """

    quantity: str
    value: float
    unit: str
    advisory: bool = True
    #: Seconds after which the command should be treated as stale by the device.
    valid_for_s: float = 60.0
    reason: str = ""
    source: str = "batteryopt"

    def as_dict(self) -> dict[str, Any]:
        return {
            "quantity": self.quantity,
            "value": self.value,
            "unit": self.unit,
            "advisory": self.advisory,
            "valid_for_s": self.valid_for_s,
            "reason": self.reason,
            "source": self.source,
        }


@dataclass(frozen=True, slots=True)
class OperatingLimits:
    """Advisory limits BatteryOpt asks a BMS to respect.

    These *narrow* whatever the BMS already enforces; they never widen it. A
    BMS that receives a higher current limit than its own must keep its own,
    and a correct integration says so in its adapter.
    """

    max_charge_current_a: float | None = None
    max_discharge_current_a: float | None = None
    max_charge_power_w: float | None = None
    max_discharge_power_w: float | None = None
    max_voltage_v: float | None = None
    min_voltage_v: float | None = None
    max_temperature_c: float | None = None
    target_soc: float | None = None
    reason: str = ""

    def as_dict(self) -> dict[str, Any]:
        return {
            k: v
            for k, v in {
                "max_charge_current_a": self.max_charge_current_a,
                "max_discharge_current_a": self.max_discharge_current_a,
                "max_charge_power_w": self.max_charge_power_w,
                "max_discharge_power_w": self.max_discharge_power_w,
                "max_voltage_v": self.max_voltage_v,
                "min_voltage_v": self.min_voltage_v,
                "max_temperature_c": self.max_temperature_c,
                "target_soc": self.target_soc,
                "reason": self.reason,
            }.items()
            if v is not None and v != ""
        }


# ---------------------------------------------------------------------------
# Interfaces
# ---------------------------------------------------------------------------


@runtime_checkable
class Sensor(Protocol):
    """Anything that reports a scalar measurement."""

    def info(self) -> DeviceInfo: ...
    def read(self) -> float: ...


@runtime_checkable
class CellInterface(Protocol):
    """A single cell, where the hardware exposes cell-level data."""

    def info(self) -> DeviceInfo: ...
    def voltage(self) -> float: ...
    def temperature(self) -> float | None: ...
    def balancing_active(self) -> bool: ...
    def set_balancing(self, active: bool) -> None: ...


@runtime_checkable
class ModuleInterface(Protocol):
    """A module: a group of cells with its own sensing."""

    def info(self) -> DeviceInfo: ...
    def cells(self) -> Sequence[CellInterface]: ...
    def voltage(self) -> float: ...
    def temperatures(self) -> Sequence[float]: ...


@runtime_checkable
class PackInterface(Protocol):
    """A pack: modules plus pack-level sensing and contactors."""

    def info(self) -> DeviceInfo: ...
    def modules(self) -> Sequence[ModuleInterface]: ...
    def voltage(self) -> float: ...
    def current(self) -> float: ...
    def temperatures(self) -> Sequence[float]: ...
    def contactors_closed(self) -> bool: ...


@runtime_checkable
class BMSInterface(Protocol):
    """The battery management system.

    BatteryOpt reads state from the BMS and offers it advisory limits. It does
    not replace it, and the interface offers no way to disable a protection.
    """

    def info(self) -> DeviceInfo: ...
    def read_measurement(self) -> Measurement: ...
    def reported_state(self) -> BatteryState | None: ...
    def apply_limits(self, limits: OperatingLimits) -> bool: ...
    def active_faults(self) -> Sequence[str]: ...


@runtime_checkable
class ChargerInterface(Protocol):
    """A charger or bidirectional charging station."""

    def info(self) -> DeviceInfo: ...
    def available_power_w(self) -> float: ...
    def set_power(self, power_w: float, *, advisory: bool = True) -> bool: ...
    def actual_power_w(self) -> float: ...
    def is_connected(self) -> bool: ...


@runtime_checkable
class InverterInterface(Protocol):
    """A grid-tied inverter or power conversion system."""

    def info(self) -> DeviceInfo: ...
    def set_power(self, power_w: float, *, advisory: bool = True) -> bool: ...
    def actual_power_w(self) -> float: ...
    def efficiency_at(self, power_w: float) -> float: ...
    def limits_w(self) -> tuple[float, float]: ...


@runtime_checkable
class ThermalSystemInterface(Protocol):
    """Cooling and heating hardware."""

    def info(self) -> DeviceInfo: ...
    def set_cooling(self, fraction: float) -> bool: ...
    def set_heating(self, fraction: float) -> bool: ...
    def coolant_temperature_c(self) -> float: ...
    def parasitic_power_w(self) -> float: ...


@runtime_checkable
class PowerConverterInterface(Protocol):
    """A DC/DC converter between the pack and a bus."""

    def info(self) -> DeviceInfo: ...
    def set_current(self, current_a: float) -> bool: ...
    def efficiency_at(self, power_w: float) -> float: ...


@runtime_checkable
class EnergyMeterInterface(Protocol):
    """A revenue or site meter at the point of connection."""

    def info(self) -> DeviceInfo: ...
    def power_w(self) -> float: ...
    def cumulative_import_wh(self) -> float: ...
    def cumulative_export_wh(self) -> float: ...


@dataclass(slots=True)
class DeviceRegistry:
    """Everything BatteryOpt is connected to, for one battery system."""

    bms: BMSInterface | None = None
    pack: PackInterface | None = None
    charger: ChargerInterface | None = None
    inverter: InverterInterface | None = None
    thermal: ThermalSystemInterface | None = None
    converter: PowerConverterInterface | None = None
    meter: EnergyMeterInterface | None = None
    sensors: dict[str, Sensor] = field(default_factory=dict)

    def devices(self) -> dict[str, Any]:
        return {
            name: device
            for name, device in {
                "bms": self.bms,
                "pack": self.pack,
                "charger": self.charger,
                "inverter": self.inverter,
                "thermal": self.thermal,
                "converter": self.converter,
                "meter": self.meter,
            }.items()
            if device is not None
        }

    def describe(self) -> dict[str, Any]:
        return {
            name: device.info().as_dict() for name, device in self.devices().items()
        }

    def health(self) -> dict[str, str]:
        return {
            name: device.info().status.value for name, device in self.devices().items()
        }


def limits_from_recommendation(recommendation: Any, battery: Any) -> OperatingLimits:
    """Translate a recommendation into advisory limits for a BMS.

    The translation is deliberately conservative: the recommended power becomes
    a *ceiling* rather than a setpoint, so a BMS that honours it can always do
    less. That is the correct direction for an advisory system -- BatteryOpt
    saying "no more than this" is safe; saying "exactly this" is not its call.
    """
    power = float(getattr(recommendation, "recommended_power_w", 0.0))
    voltage = max(getattr(battery, "nominal_voltage", 1.0), 1.0)
    limits = OperatingLimits(
        max_discharge_power_w=max(0.0, power) if power > 0 else 0.0,
        max_charge_power_w=max(0.0, -power) if power < 0 else 0.0,
        max_discharge_current_a=max(0.0, power) / voltage if power > 0 else 0.0,
        max_charge_current_a=max(0.0, -power) / voltage if power < 0 else 0.0,
        target_soc=float(getattr(recommendation, "target_soc", 0.5)),
        reason=str(getattr(recommendation, "reason", ""))[:400],
    )
    return limits


__all__ = [
    "DeviceStatus",
    "DeviceInfo",
    "Command",
    "OperatingLimits",
    "Sensor",
    "CellInterface",
    "ModuleInterface",
    "PackInterface",
    "BMSInterface",
    "ChargerInterface",
    "InverterInterface",
    "ThermalSystemInterface",
    "PowerConverterInterface",
    "EnergyMeterInterface",
    "DeviceRegistry",
    "limits_from_recommendation",
]
