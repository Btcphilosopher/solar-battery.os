"""Equivalent-circuit electrical model.

The real-time optimiser needs a voltage/power/loss model that evaluates in
microseconds and can be differentiated or inverted analytically. A first-order
Thevenin model with one or two diffusion RC branches is the standard choice and
is what BatteryOpt uses on the fast path:

.. code-block:: text

    V_terminal = OCV(soc) - I*R0(T, soc, age) - sum_k V_rc,k
    dV_rc,k/dt = -V_rc,k / tau_k + I * R_k / tau_k

with ``I`` positive on discharge. The RC branches are what make a 30-second
pulse and a 30-minute discharge at the same current produce different terminal
voltages -- which is precisely the difference between a mission-capable pack
and one that trips on undervoltage ten minutes in.

Everything here is closed-form. In particular:

* power-to-current inversion is a quadratic, not an iteration;
* the voltage-limited power ceiling has an analytic expression;
* heat generation splits into irreversible (I^2 R) and reversible
  (entropic, ``I * T * dU/dT``) terms.

Higher-fidelity electrochemistry (PyBaMM DFN/SPMe) plugs in through
:mod:`batteryopt.models.physics` for offline validation and for fitting the
parameters used here.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from ..core.numerics import EPS, clamp
from ..core.units import KELVIN_OFFSET, SECONDS_PER_HOUR
from .chemistry import ChemistryParameters
from .topology import Topology


@dataclass(frozen=True, slots=True)
class ElectricalResponse:
    """Result of evaluating the electrical model at one operating point."""

    voltage_v: float
    current_a: float
    power_w: float
    #: Open-circuit voltage at the present SOC, system level.
    ocv_v: float
    #: Effective series resistance actually used, ohms, system level.
    resistance_ohm: float
    #: Sum of the diffusion overpotentials, volts.
    diffusion_v: float
    #: Irreversible (joule) heat, watts. Always non-negative.
    irreversible_heat_w: float
    #: Reversible (entropic) heat, watts. Signed: can cool the cell.
    reversible_heat_w: float
    #: Updated RC branch voltages after the step, if a step was taken.
    rc_voltages: tuple[float, ...] = ()

    @property
    def heat_w(self) -> float:
        """Total heat generation, watts."""
        return self.irreversible_heat_w + self.reversible_heat_w

    @property
    def loss_w(self) -> float:
        """Electrical loss, watts -- the irreversible part only."""
        return self.irreversible_heat_w


class EquivalentCircuitModel:
    """Thevenin ECM scaled from cell parameters to system terminals."""

    __slots__ = (
        "topology",
        "chemistry",
        "_n_rc",
        "_rc_r_cell",
        "_rc_tau",
        "_use_hysteresis",
        "hysteresis_gamma",
    )

    def __init__(
        self, topology: Topology, *, use_hysteresis: bool = True, hysteresis_gamma: float = 30.0
    ) -> None:
        self.topology = topology
        self.chemistry: ChemistryParameters = topology.chemistry
        pairs = self.chemistry.resistance.rc_pairs
        self._n_rc = len(pairs)
        self._rc_r_cell = tuple(float(r) for r, _ in pairs)
        self._rc_tau = tuple(float(t) for _, t in pairs)
        self._use_hysteresis = use_hysteresis
        #: Rate at which the hysteresis state slews, per unit of throughput
        #: expressed in nameplate capacities. Larger means it snaps to the
        #: active branch faster.
        self.hysteresis_gamma = hysteresis_gamma

    # -- static quantities --------------------------------------------------

    @property
    def n_rc(self) -> int:
        return self._n_rc

    def ocv(
        self, soc: float | np.ndarray, *, hysteresis: float = 0.0
    ) -> float | np.ndarray:
        """System open-circuit voltage in volts, including the hysteresis offset.

        ``hysteresis`` is the normalised state in [-1, 1], not the current
        sign: after a discharge the pack rests *below* its true equilibrium
        OCV and stays there, so the offset has to survive the current going to
        zero. Passing 0.0 gives the equilibrium curve.
        """
        v_cell = self.chemistry.ocv.voltage_at(np.clip(soc, 0.0, 1.0))
        if self._use_hysteresis and self.chemistry.ocv.hysteresis_v > 0.0:
            v_cell = v_cell + float(np.clip(hysteresis, -1.0, 1.0)) * self.chemistry.ocv.hysteresis_v
        return self.topology.voltage_from_cell(v_cell)

    @property
    def hysteresis_magnitude_v(self) -> float:
        """Full-branch hysteresis offset at system level, volts."""
        if not self._use_hysteresis:
            return 0.0
        return self.chemistry.ocv.hysteresis_v * self.topology.n_series

    def step_hysteresis(
        self, hysteresis: float, current_a: float, dt: float, *, capacity_ah: float
    ) -> float:
        """Advance the hysteresis state (Plett formulation).

        The state relaxes towards the branch selected by the current sign at a
        rate set by throughput, so a deep cycle flips it and a trickle does not.
        """
        if not self._use_hysteresis or self.chemistry.ocv.hysteresis_v <= 0.0:
            return 0.0
        if capacity_ah <= EPS:
            return hysteresis
        rate = abs(self.hysteresis_gamma * current_a * dt / (SECONDS_PER_HOUR * capacity_ah))
        decay = math.exp(-rate)
        target = -1.0 if current_a > 0.0 else (1.0 if current_a < 0.0 else hysteresis)
        return float(np.clip(hysteresis * decay + target * (1.0 - decay), -1.0, 1.0))

    def resistance(
        self,
        *,
        soc: float,
        temperature_c: float,
        resistance_growth: float = 0.0,
        charging: bool = False,
    ) -> float:
        """System series resistance in ohms at the given conditions."""
        r_cell = self.chemistry.resistance.r0(
            temperature_c=temperature_c,
            soc=clamp(soc, 0.0, 1.0),
            resistance_growth=resistance_growth,
            charging=charging,
        )
        return self.topology.resistance_from_cell(r_cell)

    def rc_resistances(self, resistance_growth: float = 0.0) -> tuple[float, ...]:
        """System-level RC branch resistances in ohms."""
        scale = 1.0 + max(resistance_growth, -0.99)
        return tuple(
            self.topology.resistance_from_cell(r * scale) for r in self._rc_r_cell
        )

    @property
    def rc_time_constants(self) -> tuple[float, ...]:
        return self._rc_tau

    def capacity_ah(self, soh_capacity: float = 1.0) -> float:
        """Present system capacity in Ah for a given capacity SOH."""
        return self.topology.capacity_ah * clamp(soh_capacity, 0.0, 1.0)

    # -- evaluation ---------------------------------------------------------

    def evaluate(
        self,
        *,
        soc: float,
        current_a: float,
        temperature_c: float,
        rc_voltages: tuple[float, ...] = (),
        resistance_growth: float = 0.0,
        hysteresis: float = 0.0,
    ) -> ElectricalResponse:
        """Terminal response at a *given current*, without advancing time."""
        charging = current_a < 0.0
        ocv = float(self.ocv(soc, hysteresis=hysteresis))
        r0 = self.resistance(
            soc=soc,
            temperature_c=temperature_c,
            resistance_growth=resistance_growth,
            charging=charging,
        )
        diffusion = float(sum(rc_voltages)) if rc_voltages else 0.0
        voltage = ocv - current_a * r0 - diffusion
        power = voltage * current_a

        rc_r = self.rc_resistances(resistance_growth)
        irrev = current_a * current_a * r0 + sum(
            (v * v) / r for v, r in zip(rc_voltages, rc_r) if r > EPS
        )
        dudt_cell = float(self.chemistry.ocv.dudt_at(clamp(soc, 0.0, 1.0)))
        t_k = temperature_c + KELVIN_OFFSET
        # Reversible heat: -I * T * dU/dT per cell in series, with I positive
        # on discharge. A positive dU/dT therefore cools the pack on discharge.
        i_cell = self.topology.cell_current_from_system(current_a)
        reversible = -i_cell * t_k * dudt_cell * self.topology.cell_count

        return ElectricalResponse(
            voltage_v=voltage,
            current_a=current_a,
            power_w=power,
            ocv_v=ocv,
            resistance_ohm=r0,
            diffusion_v=diffusion,
            irreversible_heat_w=max(0.0, irrev),
            reversible_heat_w=reversible,
            rc_voltages=tuple(rc_voltages),
        )

    def step_rc(
        self,
        rc_voltages: tuple[float, ...],
        current_a: float,
        dt: float,
        resistance_growth: float = 0.0,
    ) -> tuple[float, ...]:
        """Advance the diffusion branches by ``dt`` seconds (exact ZOH update)."""
        if self._n_rc == 0:
            return ()
        rc_r = self.rc_resistances(resistance_growth)
        current = rc_voltages if len(rc_voltages) == self._n_rc else (0.0,) * self._n_rc
        out = []
        for v, r, tau in zip(current, rc_r, self._rc_tau):
            decay = math.exp(-dt / tau) if tau > EPS else 0.0
            out.append(v * decay + current_a * r * (1.0 - decay))
        return tuple(out)

    # -- inversion ----------------------------------------------------------

    def current_for_power(
        self,
        power_w: float,
        *,
        soc: float,
        temperature_c: float,
        rc_voltages: tuple[float, ...] = (),
        resistance_growth: float = 0.0,
        hysteresis: float = 0.0,
    ) -> float:
        """Current that delivers ``power_w`` at the terminals.

        Solves ``R0*I^2 - E*I + P = 0`` where ``E = OCV - sum(V_rc)``, taking
        the low-current root, which is the physical branch. If the requested
        power exceeds the matched-impedance maximum ``E^2 / (4*R0)`` the
        discriminant goes negative; the current at maximum power is returned
        instead, and the caller's constraint check will reject the point.
        """
        charging = power_w < 0.0
        ocv = float(self.ocv(soc, hysteresis=hysteresis))
        r0 = self.resistance(
            soc=soc,
            temperature_c=temperature_c,
            resistance_growth=resistance_growth,
            charging=charging,
        )
        e = ocv - (float(sum(rc_voltages)) if rc_voltages else 0.0)
        if r0 <= EPS:
            return power_w / e if abs(e) > EPS else 0.0
        disc = e * e - 4.0 * r0 * power_w
        if disc <= 0.0:
            return e / (2.0 * r0)
        return (e - math.sqrt(disc)) / (2.0 * r0)

    def power_for_current(
        self,
        current_a: float,
        *,
        soc: float,
        temperature_c: float,
        rc_voltages: tuple[float, ...] = (),
        resistance_growth: float = 0.0,
        hysteresis: float = 0.0,
    ) -> float:
        return self.evaluate(
            soc=soc,
            current_a=current_a,
            temperature_c=temperature_c,
            rc_voltages=rc_voltages,
            resistance_growth=resistance_growth,
            hysteresis=hysteresis,
        ).power_w

    def current_at_voltage_limit(
        self,
        voltage_limit_v: float,
        *,
        soc: float,
        temperature_c: float,
        rc_voltages: tuple[float, ...] = (),
        resistance_growth: float = 0.0,
        charging: bool,
        hysteresis: float = 0.0,
    ) -> float:
        """Current at which the terminal voltage exactly reaches a limit."""
        ocv = float(self.ocv(soc, hysteresis=hysteresis))
        r0 = self.resistance(
            soc=soc,
            temperature_c=temperature_c,
            resistance_growth=resistance_growth,
            charging=charging,
        )
        e = ocv - (float(sum(rc_voltages)) if rc_voltages else 0.0)
        if r0 <= EPS:
            return math.inf if e > voltage_limit_v else -math.inf
        return (e - voltage_limit_v) / r0

    def power_at_voltage_limit(
        self,
        voltage_limit_v: float,
        *,
        soc: float,
        temperature_c: float,
        rc_voltages: tuple[float, ...] = (),
        resistance_growth: float = 0.0,
        charging: bool,
        hysteresis: float = 0.0,
    ) -> float:
        """Terminal power when the voltage limit is exactly reached, in watts."""
        i = self.current_at_voltage_limit(
            voltage_limit_v,
            soc=soc,
            temperature_c=temperature_c,
            rc_voltages=rc_voltages,
            resistance_growth=resistance_growth,
            charging=charging,
            hysteresis=hysteresis,
        )
        if not math.isfinite(i):
            return math.copysign(math.inf, i)
        return voltage_limit_v * i

    # -- charge integration -------------------------------------------------

    def soc_delta(
        self,
        current_a: float,
        dt: float,
        *,
        capacity_ah: float,
        coulombic_efficiency: float | None = None,
    ) -> float:
        """Change in SOC over ``dt`` seconds at constant current.

        Coulombic efficiency is applied on charge only: some of the charge
        pushed in does not end up stored. Discharge is counted at face value,
        which is the conservative direction for a mission-reliability
        calculation.
        """
        if capacity_ah <= EPS:
            return 0.0
        eta = (
            self.chemistry.envelope.coulombic_efficiency
            if coulombic_efficiency is None
            else coulombic_efficiency
        )
        ah = current_a * dt / SECONDS_PER_HOUR
        if current_a < 0.0:
            ah *= eta
        return -ah / capacity_ah

    # -- vectorised helper --------------------------------------------------

    def evaluate_many(
        self,
        soc: np.ndarray,
        current_a: np.ndarray,
        temperature_c: np.ndarray,
        *,
        resistance_growth: float = 0.0,
    ) -> dict[str, np.ndarray]:
        """Vectorised steady-state evaluation over arrays of operating points.

        Used by the scenario engine to price a whole candidate grid at once.
        Diffusion overpotentials are omitted here (steady state assumed); the
        time-stepping simulator carries them properly.
        """
        soc = np.asarray(soc, dtype=float)
        current_a = np.asarray(current_a, dtype=float)
        temperature_c = np.asarray(temperature_c, dtype=float)
        charging = current_a < 0.0

        # The vectorised path evaluates the *equilibrium* OCV curve: hysteresis
        # is a state, and a stateless bulk evaluation has no state to carry.
        v_cell = np.asarray(self.chemistry.ocv.voltage_at(np.clip(soc, 0.0, 1.0)), dtype=float)
        ocv = v_cell * self.topology.n_series

        rmodel = self.chemistry.resistance
        r_cell = (
            rmodel.r0_ref_ohm
            * np.asarray(rmodel.temperature_factor(temperature_c), dtype=float)
            * np.asarray(rmodel.soc_factor(np.clip(soc, 0.0, 1.0)), dtype=float)
            * (1.0 + max(resistance_growth, -0.99))
        )
        r_cell = np.where(charging, r_cell * rmodel.charge_multiplier, r_cell)
        # Vectorised counterpart of Topology.resistance_from_cell for the flat case.
        r0 = np.asarray([self.topology.resistance_from_cell(float(r)) for r in np.atleast_1d(r_cell)])
        r0 = r0.reshape(np.shape(r_cell)) if np.ndim(r_cell) else float(r0[0])

        voltage = ocv - current_a * r0
        power = voltage * current_a
        loss = current_a * current_a * r0
        return {
            "ocv_v": ocv,
            "resistance_ohm": r0,
            "voltage_v": voltage,
            "power_w": power,
            "loss_w": loss,
        }


__all__ = ["EquivalentCircuitModel", "ElectricalResponse"]
