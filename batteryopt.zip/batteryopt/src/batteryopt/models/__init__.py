"""Physical models: chemistry, topology, electrical, thermal, degradation, plant."""

from .battery import Battery, CycleHistory, ThermalLimits
from .chemistry import (
    ChemistryParameters,
    DegradationCoefficients,
    OCVCurve,
    OperatingEnvelope,
    ResistanceModel,
    ThermalProperties,
    available_chemistries,
    get_chemistry,
    register_chemistry,
)
from .degradation import DegradationModel, LifeEstimate, RainflowCounter
from .electrical import ElectricalResponse, EquivalentCircuitModel
from .fidelity import Fidelity, build_plant, default_time_step, effective_backend, profile_for
from .plant import Action, BatteryPlant, StepResult, Trajectory
from .state import BatteryState, DegradationState
from .surrogate import ResponseSurface, SurrogateCache, build_surrogate, degradation_rate_array
from .thermal import LumpedThermalModel, ThermalResponse
from .topology import CellSpec, ModuleSpec, PackSpec, SystemSpec, Topology

__all__ = [
    "Battery",
    "CycleHistory",
    "ThermalLimits",
    "ChemistryParameters",
    "OCVCurve",
    "ResistanceModel",
    "ThermalProperties",
    "DegradationCoefficients",
    "OperatingEnvelope",
    "get_chemistry",
    "register_chemistry",
    "available_chemistries",
    "DegradationModel",
    "LifeEstimate",
    "RainflowCounter",
    "EquivalentCircuitModel",
    "ElectricalResponse",
    "Fidelity",
    "profile_for",
    "effective_backend",
    "build_plant",
    "default_time_step",
    "BatteryPlant",
    "Action",
    "StepResult",
    "Trajectory",
    "BatteryState",
    "DegradationState",
    "ResponseSurface",
    "build_surrogate",
    "degradation_rate_array",
    "SurrogateCache",
    "LumpedThermalModel",
    "ThermalResponse",
    "Topology",
    "CellSpec",
    "ModuleSpec",
    "PackSpec",
    "SystemSpec",
]
