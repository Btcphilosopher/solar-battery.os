"""PyBaMM adapter for high-fidelity electrochemical simulation.

BatteryOpt does not *depend* on PyBaMM, and nothing on the real-time path
touches it. It is used for three things, all offline:

1. **Validation.** Re-simulating a recommended strategy under a DFN model and
   checking that the ECM's voltage, temperature and energy predictions agree
   within tolerance (specification section 34).
2. **Parameter fitting.** Deriving the ECM's series resistance, RC branches
   and OCV curve from an electrochemical model or from lab data.
3. **Surrogate construction.** Generating the tabulated response surfaces that
   :mod:`batteryopt.models.surrogate` interpolates at run time.

When PyBaMM is absent every entry point raises a clear
:class:`~batteryopt.core.exceptions.SolverUnavailable` naming the extra to
install, except :func:`available`, which simply reports ``False``.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Sequence

import numpy as np

from ..core.exceptions import ModelError
from ..core.optional import have, require
from ..core.provenance import Provenance
from .battery import Battery

#: Mapping from BatteryOpt chemistry families to PyBaMM parameter sets.
#: These are PyBaMM's own published parameter sets; the mapping is a starting
#: point for a fitting exercise, not a claim that a given pack matches them.
PARAMETER_SET_HINTS: dict[str, str] = {
    "nmc": "Chen2020",
    "nca": "NCA_Kim2011",
    "lfp": "Prada2013",
    "lithium_ion": "Marquis2019",
    "lco": "Marquis2019",
}


def available() -> bool:
    """True when PyBaMM can be imported in this process."""
    return have("pybamm")


@dataclass(frozen=True, slots=True)
class PhysicsResult:
    """Output of a high-fidelity simulation, always tagged SIMULATED."""

    time_s: np.ndarray
    voltage_v: np.ndarray
    current_a: np.ndarray
    temperature_c: np.ndarray
    discharge_capacity_ah: np.ndarray
    model_name: str
    parameter_set: str
    provenance: Provenance = Provenance.SIMULATED

    def summary(self) -> dict[str, Any]:
        return {
            "model": self.model_name,
            "parameter_set": self.parameter_set,
            "duration_s": float(self.time_s[-1] - self.time_s[0]) if self.time_s.size else 0.0,
            "min_voltage_v": float(np.min(self.voltage_v)) if self.voltage_v.size else 0.0,
            "max_temperature_c": float(np.max(self.temperature_c))
            if self.temperature_c.size
            else 0.0,
            "provenance": self.provenance.value,
        }


class PyBaMMAdapter:
    """Thin, defensive wrapper over a PyBaMM simulation.

    Deliberately narrow: it runs a constant-current or piecewise-constant
    current experiment on one cell and returns arrays. Pack-level scaling is
    applied by the caller through the topology, exactly as for the ECM, so the
    two model tiers remain comparable.
    """

    def __init__(
        self,
        battery: Battery,
        *,
        model: str = "SPMe",
        parameter_set: str | None = None,
        thermal: str = "lumped",
    ) -> None:
        self.battery = battery
        self.model_name = model
        self.thermal = thermal
        family = battery.chemistry.family
        self.parameter_set = parameter_set or PARAMETER_SET_HINTS.get(family, "Chen2020")

    def _build(self) -> tuple[Any, Any]:
        pybamm = require("pybamm")
        options = {"thermal": self.thermal}
        try:
            if self.model_name.upper() == "DFN":
                model = pybamm.lithium_ion.DFN(options=options)
            elif self.model_name.upper() == "SPM":
                model = pybamm.lithium_ion.SPM(options=options)
            else:
                model = pybamm.lithium_ion.SPMe(options=options)
            params = pybamm.ParameterValues(self.parameter_set)
        except Exception as exc:  # pragma: no cover - depends on PyBaMM version
            raise ModelError(
                f"could not construct PyBaMM model {self.model_name!r} with parameter set "
                f"{self.parameter_set!r}: {exc}"
            ) from exc
        return model, params

    def simulate_constant_current(
        self,
        *,
        cell_current_a: float,
        duration_s: float,
        initial_soc: float = 1.0,
        ambient_c: float = 25.0,
        n_points: int = 200,
    ) -> PhysicsResult:
        """Run a constant-current experiment on a single cell."""
        pybamm = require("pybamm")
        model, params = self._build()
        params.update({"Ambient temperature [K]": ambient_c + 273.15}, check_already_exists=False)
        sim = pybamm.Simulation(model, parameter_values=params)
        t_eval = np.linspace(0.0, duration_s, n_points)
        try:
            solution = sim.solve(
                t_eval, initial_soc=initial_soc, inputs={}, current=cell_current_a
            )
        except TypeError:
            # Older/newer PyBaMM signatures differ; fall back to the experiment API.
            params.update({"Current function [A]": cell_current_a})
            sim = pybamm.Simulation(model, parameter_values=params)
            solution = sim.solve(t_eval, initial_soc=initial_soc)
        except Exception as exc:  # pragma: no cover
            raise ModelError(f"PyBaMM solve failed: {exc}") from exc

        def get(key: str, default: float = 0.0) -> np.ndarray:
            try:
                return np.asarray(solution[key].entries, dtype=float)
            except Exception:
                return np.full(len(solution.t), default)

        temp_k = get("Volume-averaged cell temperature [K]", ambient_c + 273.15)
        return PhysicsResult(
            time_s=np.asarray(solution.t, dtype=float),
            voltage_v=get("Terminal voltage [V]"),
            current_a=get("Current [A]", cell_current_a),
            temperature_c=temp_k - 273.15,
            discharge_capacity_ah=get("Discharge capacity [A.h]"),
            model_name=self.model_name,
            parameter_set=self.parameter_set,
        )

    def fit_ecm_resistance(
        self,
        *,
        soc_points: Sequence[float] = (0.2, 0.5, 0.8),
        pulse_current_a: float = 1.0,
        pulse_s: float = 10.0,
    ) -> dict[str, float]:
        """Estimate an ECM series resistance from simulated current pulses.

        Returns the mean ``R0`` across the requested SOC points, which is the
        first step of the fitting workflow documented in ``docs/validation.md``.
        """
        results: list[float] = []
        for soc in soc_points:
            res = self.simulate_constant_current(
                cell_current_a=pulse_current_a,
                duration_s=pulse_s,
                initial_soc=float(soc),
                n_points=20,
            )
            if res.voltage_v.size < 2:
                continue
            drop = float(res.voltage_v[0] - res.voltage_v[1])
            if pulse_current_a > 0:
                results.append(drop / pulse_current_a)
        if not results:
            raise ModelError("no usable pulses returned by PyBaMM")
        return {"r0_ref_ohm": float(np.mean(results)), "n_points": float(len(results))}


__all__ = ["PyBaMMAdapter", "PhysicsResult", "available", "PARAMETER_SET_HINTS"]
