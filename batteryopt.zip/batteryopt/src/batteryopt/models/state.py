"""The battery state vector.

One immutable object carries everything the estimator, the simulator, the
optimiser and the reporting layer need to agree on. It is a plain frozen
dataclass of floats rather than a Pydantic model because it is constructed
millions of times inside scenario roll-outs; validation happens at the API
boundary, not in the inner loop.

Provenance is tracked per field in a side mapping. That keeps the numeric
payload cheap while still making it impossible to render a simulated SOC as
though it had been measured.
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import Any, Mapping

from ..core.provenance import Provenance, Quantity
from ..core.units import SECONDS_PER_HOUR, SECONDS_PER_YEAR, mode_of

#: Fields that carry a physical unit, used by :meth:`BatteryState.quantities`.
FIELD_UNITS: dict[str, str] = {
    "soc": "-",
    "soh_capacity": "-",
    "soh_resistance": "-",
    "voltage_v": "V",
    "current_a": "A",
    "power_w": "W",
    "temperature_c": "degC",
    "temperature_max_c": "degC",
    "temperature_min_c": "degC",
    "ambient_c": "degC",
    "coolant_c": "degC",
    "capacity_ah": "Ah",
    "resistance_ohm": "Ohm",
    "cell_imbalance_v": "V",
    "energy_remaining_wh": "Wh",
    "power_limit_charge_w": "W",
    "power_limit_discharge_w": "W",
}


@dataclass(frozen=True, slots=True)
class DegradationState:
    """Accumulated ageing, expressed both as damage and as stress history.

    ``t_eq_years`` and ``a_eq_efc`` are the *stress-weighted* accumulators that
    drive the power-law ageing model: a year spent at 45 degC and 100 % SOC
    contributes several equivalent years, and a cycle at 2C in the cold
    contributes several equivalent full cycles.
    """

    #: Stress-weighted calendar time, in equivalent years at reference conditions.
    t_eq_years: float = 0.0
    #: Stress-weighted throughput, in equivalent full cycles at reference conditions.
    a_eq_efc: float = 0.0
    #: Raw (unweighted) charge throughput in Ah, for reporting and warranty terms.
    throughput_ah: float = 0.0
    #: Raw equivalent full cycles, throughput / (2 * nameplate capacity).
    equivalent_full_cycles: float = 0.0
    #: Wall-clock age in seconds since manufacture.
    age_s: float = 0.0
    #: Fractional capacity lost so far (0.04 == 4 % lost, SOH 96 %).
    capacity_fade: float = 0.0
    #: Fractional resistance increase so far (0.4 == 40 % higher than new).
    resistance_growth: float = 0.0

    @property
    def soh_capacity(self) -> float:
        return max(0.0, 1.0 - self.capacity_fade)

    @property
    def age_years(self) -> float:
        return self.age_s / SECONDS_PER_YEAR

    def as_dict(self) -> dict[str, float]:
        return {
            "t_eq_years": self.t_eq_years,
            "a_eq_efc": self.a_eq_efc,
            "throughput_ah": self.throughput_ah,
            "equivalent_full_cycles": self.equivalent_full_cycles,
            "age_s": self.age_s,
            "age_years": self.age_years,
            "capacity_fade": self.capacity_fade,
            "resistance_growth": self.resistance_growth,
            "soh_capacity": self.soh_capacity,
        }


@dataclass(frozen=True, slots=True)
class BatteryState:
    """Complete system-level state at one instant.

    Sign convention: ``current_a`` and ``power_w`` are **positive when
    discharging**.
    """

    # --- charge and health -------------------------------------------------
    soc: float = 0.5
    soh_capacity: float = 1.0
    soh_resistance: float = 1.0
    capacity_ah: float = 0.0
    resistance_ohm: float = 0.0

    # --- electrical --------------------------------------------------------
    voltage_v: float = 0.0
    current_a: float = 0.0
    power_w: float = 0.0
    #: Voltages across each diffusion RC branch, in volts (system level).
    rc_voltages: tuple[float, ...] = ()
    #: Normalised voltage-hysteresis state in [-1, 1]. -1 is the fully
    #: discharged branch (terminal voltage depressed), +1 the fully charged
    #: branch. Hysteresis is a genuine state: it persists through rest, which
    #: is why it cannot be reconstructed from the instantaneous current sign.
    hysteresis: float = 0.0

    # --- thermal -----------------------------------------------------------
    temperature_c: float = 25.0
    temperature_max_c: float = 25.0
    temperature_min_c: float = 25.0
    ambient_c: float = 20.0
    coolant_c: float = 20.0
    #: Instantaneous heat generation inside the cells, W.
    heat_generation_w: float = 0.0
    #: Fraction of maximum active cooling currently commanded, 0-1.
    cooling_fraction: float = 0.0

    # --- pack uniformity ---------------------------------------------------
    cell_imbalance_v: float = 0.0
    cell_capacity_spread: float = 0.0

    # --- capability --------------------------------------------------------
    energy_remaining_wh: float = 0.0
    power_limit_charge_w: float = 0.0
    power_limit_discharge_w: float = 0.0

    # --- ageing ------------------------------------------------------------
    degradation: DegradationState = field(default_factory=DegradationState)

    # --- bookkeeping -------------------------------------------------------
    timestamp: float = 0.0
    provenance: Mapping[str, Provenance] = field(default_factory=dict)
    #: Default provenance for fields not listed in :attr:`provenance`.
    default_provenance: Provenance = Provenance.ESTIMATED

    # -- accessors ----------------------------------------------------------

    def provenance_of(self, field_name: str) -> Provenance:
        return self.provenance.get(field_name, self.default_provenance)

    def q(self, field_name: str) -> Quantity:
        """Wrap one field as a :class:`Quantity` with its provenance and unit."""
        return Quantity(
            value=float(getattr(self, field_name)),
            unit=FIELD_UNITS.get(field_name, "-"),
            provenance=self.provenance_of(field_name),
            timestamp=self.timestamp,
        )

    def quantities(self) -> dict[str, Quantity]:
        """All unit-carrying fields as provenance-tagged quantities."""
        return {name: self.q(name) for name in FIELD_UNITS}

    @property
    def mode(self) -> str:
        """``"charge"``, ``"discharge"`` or ``"rest"``."""
        return mode_of(self.power_w)

    @property
    def soh(self) -> float:
        """Alias for capacity-based state of health."""
        return self.soh_capacity

    @property
    def c_rate(self) -> float:
        """Signed C-rate; positive discharging."""
        return self.current_a / self.capacity_ah if self.capacity_ah > 0 else 0.0

    @property
    def charge_ah(self) -> float:
        """Charge currently stored, in Ah."""
        return self.soc * self.capacity_ah

    def with_provenance(self, **fields: Provenance) -> "BatteryState":
        merged = dict(self.provenance)
        merged.update(fields)
        return replace(self, provenance=merged)

    def evolve(self, **changes: Any) -> "BatteryState":
        """Return a copy with fields replaced (thin :func:`dataclasses.replace`)."""
        return replace(self, **changes)

    def as_simulated(self) -> "BatteryState":
        """Mark this state as the output of a simulation, not an observation."""
        return replace(self, default_provenance=Provenance.SIMULATED, provenance={})

    def as_dict(self, *, include_provenance: bool = True) -> dict[str, Any]:
        out: dict[str, Any] = {
            "timestamp": self.timestamp,
            "soc": self.soc,
            "soh_capacity": self.soh_capacity,
            "soh_resistance": self.soh_resistance,
            "capacity_ah": self.capacity_ah,
            "resistance_ohm": self.resistance_ohm,
            "voltage_v": self.voltage_v,
            "current_a": self.current_a,
            "power_w": self.power_w,
            "rc_voltages": list(self.rc_voltages),
            "hysteresis": self.hysteresis,
            "temperature_c": self.temperature_c,
            "temperature_max_c": self.temperature_max_c,
            "temperature_min_c": self.temperature_min_c,
            "ambient_c": self.ambient_c,
            "coolant_c": self.coolant_c,
            "heat_generation_w": self.heat_generation_w,
            "cooling_fraction": self.cooling_fraction,
            "cell_imbalance_v": self.cell_imbalance_v,
            "cell_capacity_spread": self.cell_capacity_spread,
            "energy_remaining_wh": self.energy_remaining_wh,
            "power_limit_charge_w": self.power_limit_charge_w,
            "power_limit_discharge_w": self.power_limit_discharge_w,
            "degradation": self.degradation.as_dict(),
            "mode": self.mode,
        }
        if include_provenance:
            out["provenance"] = {
                name: self.provenance_of(name).value for name in FIELD_UNITS
            }
            out["default_provenance"] = self.default_provenance.value
        return out

    def summary(self) -> str:
        """One-line human summary, used in logs and the CLI."""
        return (
            f"SOC {self.soc * 100:5.1f}%  SOH {self.soh_capacity * 100:5.1f}%  "
            f"{self.voltage_v:7.1f} V  {self.current_a:8.1f} A  "
            f"{self.power_w / 1000.0:8.2f} kW  {self.temperature_c:5.1f} degC  "
            f"[{self.default_provenance.value}]"
        )


def energy_between(capacity_ah: float, voltage_v: float, soc_lo: float, soc_hi: float) -> float:
    """Approximate energy in Wh between two SOC points at a fixed voltage.

    Used only where a first-order estimate is acceptable (UI hints, initial
    guesses). The scenario simulator integrates the real OCV curve instead.
    """
    return max(0.0, soc_hi - soc_lo) * capacity_ah * voltage_v


def ah_to_wh(ah: float, voltage_v: float) -> float:
    return ah * voltage_v


def seconds_to_hours(seconds: float) -> float:
    return seconds / SECONDS_PER_HOUR


__all__ = [
    "BatteryState",
    "DegradationState",
    "FIELD_UNITS",
    "energy_between",
    "ah_to_wh",
    "seconds_to_hours",
]
