"""Surrogate response surface: the vectorised kernel of the real-time path.

Dynamic programming and scenario sweeps evaluate the plant hundreds of
thousands of times per optimisation. Calling the object-oriented ECM in a
Python loop for that is hopeless; this module provides the same physics as a
handful of NumPy array operations.

Design
------
The naive approach -- tabulate everything over ``(soc, temperature, power)``
and interpolate -- is both slow and inaccurate, because loss is quadratic in
power and series resistance is *discontinuous* at zero power (charge and
discharge have different charge-transfer resistance). Interpolating across
that step smears it.

So the surface stores only what is genuinely smooth, on a **two-dimensional**
``(soc, temperature)`` grid:

* ``ocv_v`` -- open-circuit voltage,
* ``r_discharge_ohm`` and ``r_charge_ohm`` -- kept as separate tables, which
  represents the discontinuity exactly instead of averaging it away,
* ``dudt_v_per_k`` -- entropic coefficient.

Everything else is reconstructed in closed form at lookup time:

.. code-block:: text

    I = (E - sqrt(E^2 - 4*R*P)) / (2*R)      exact power inversion
    V = E - I*R
    loss = I^2 * R
    heat = loss - I_cell * T_K * dU/dT * n_cells

The result is a kernel that is *more* accurate than a 3-D interpolation (the
only error left is the smooth 2-D interpolation of OCV and R) and roughly an
order of magnitude faster, because the power axis disappears entirely and a
whole action grid is priced with array arithmetic.

Degradation rates are evaluated analytically rather than tabulated: the stress
model is a handful of exponentials and vectorises directly.
"""

from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass, field
from typing import Any, Callable

import numpy as np

from ..core.numerics import EPS
from ..core.units import GAS_CONSTANT, KELVIN_OFFSET, SECONDS_PER_HOUR, SECONDS_PER_YEAR
from ..core.versioning import MODEL_VERSION
from .battery import Battery

#: Quantities held on the 2-D grid.
TABULATED = ("ocv_v", "r_discharge_ohm", "r_charge_ohm", "dudt_v_per_k")


def _battery_fingerprint(battery: Battery) -> str:
    payload = (
        f"{battery.chemistry_name}|{battery.topology.n_series}x{battery.topology.n_parallel}"
        f"|{battery.nameplate_capacity_ah:.6f}|{battery.soh_capacity:.6f}"
        f"|{battery.degradation_state.resistance_growth:.6f}|{MODEL_VERSION}"
    )
    return hashlib.sha256(payload.encode()).hexdigest()[:16]


@dataclass(slots=True)
class SurrogateResponse:
    """Vectorised plant response at a set of operating points."""

    current_a: np.ndarray
    voltage_v: np.ndarray
    ocv_v: np.ndarray
    resistance_ohm: np.ndarray
    loss_w: np.ndarray
    heat_w: np.ndarray
    reversible_heat_w: np.ndarray
    #: True where the requested power exceeds what the cell can physically
    #: deliver at this state (the quadratic has no real root).
    infeasible: np.ndarray

    def as_dict(self) -> dict[str, np.ndarray]:
        return {
            "current_a": self.current_a,
            "voltage_v": self.voltage_v,
            "ocv_v": self.ocv_v,
            "resistance_ohm": self.resistance_ohm,
            "loss_w": self.loss_w,
            "heat_w": self.heat_w,
            "reversible_heat_w": self.reversible_heat_w,
            "infeasible": self.infeasible,
        }


@dataclass(slots=True)
class ResponseSurface:
    """Interpolated ``(soc, temperature)`` tables plus closed-form reconstruction."""

    soc_grid: np.ndarray
    temperature_grid: np.ndarray
    tables: dict[str, np.ndarray]
    fingerprint: str
    heat_capacity_j_k: float = 1.0
    cell_count: int = 1
    parallel_strings: float = 1.0
    nameplate_capacity_ah: float = 1.0
    model_version: str = MODEL_VERSION
    build_seconds: float = 0.0
    meta: dict[str, Any] = field(default_factory=dict)

    # -- interpolation ------------------------------------------------------

    def _weights(
        self, soc: np.ndarray, temperature_c: np.ndarray
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        sg, tg = self.soc_grid, self.temperature_grid
        i = np.clip(np.searchsorted(sg, soc) - 1, 0, sg.size - 2)
        j = np.clip(np.searchsorted(tg, temperature_c) - 1, 0, tg.size - 2)
        ds = np.maximum(sg[i + 1] - sg[i], EPS)
        dt = np.maximum(tg[j + 1] - tg[j], EPS)
        wi = np.clip((soc - sg[i]) / ds, 0.0, 1.0)
        wj = np.clip((temperature_c - tg[j]) / dt, 0.0, 1.0)
        return i, j, wi, wj

    def interpolate(
        self,
        quantity: str,
        soc: float | np.ndarray,
        temperature_c: float | np.ndarray,
    ) -> np.ndarray:
        """Bilinear interpolation of one tabulated quantity."""
        table = self.tables.get(quantity)
        if table is None:
            raise KeyError(f"surrogate has no table {quantity!r}; has {sorted(self.tables)}")
        s, t = np.broadcast_arrays(
            np.asarray(soc, dtype=float), np.asarray(temperature_c, dtype=float)
        )
        i, j, wi, wj = self._weights(s, t)
        c0 = table[i, j] * (1.0 - wj) + table[i, j + 1] * wj
        c1 = table[i + 1, j] * (1.0 - wj) + table[i + 1, j + 1] * wj
        return c0 * (1.0 - wi) + c1 * wi

    # -- closed-form reconstruction ----------------------------------------

    def evaluate(
        self,
        soc: float | np.ndarray,
        temperature_c: float | np.ndarray,
        power_w: float | np.ndarray,
    ) -> SurrogateResponse:
        """Price a whole grid of operating points at once."""
        s, t, p = np.broadcast_arrays(
            np.asarray(soc, dtype=float),
            np.asarray(temperature_c, dtype=float),
            np.asarray(power_w, dtype=float),
        )
        charging = p < 0.0
        ocv = self.interpolate("ocv_v", s, t)
        r = np.where(
            charging,
            self.interpolate("r_charge_ohm", s, t),
            self.interpolate("r_discharge_ohm", s, t),
        )
        r = np.maximum(r, EPS)

        disc = ocv * ocv - 4.0 * r * p
        infeasible = disc < 0.0
        # At the matched-impedance limit the two roots coincide at E/(2R).
        root = np.sqrt(np.maximum(disc, 0.0))
        current = np.where(infeasible, ocv / (2.0 * r), (ocv - root) / (2.0 * r))

        voltage = ocv - current * r
        loss = current * current * r
        dudt = self.interpolate("dudt_v_per_k", s, t)
        i_cell = current / max(self.parallel_strings, EPS)
        reversible = -i_cell * (t + KELVIN_OFFSET) * dudt * self.cell_count
        return SurrogateResponse(
            current_a=current,
            voltage_v=voltage,
            ocv_v=ocv,
            resistance_ohm=r,
            loss_w=loss,
            heat_w=loss + reversible,
            reversible_heat_w=reversible,
            infeasible=infeasible,
        )

    def current_for_power(
        self,
        soc: float | np.ndarray,
        temperature_c: float | np.ndarray,
        power_w: float | np.ndarray,
    ) -> np.ndarray:
        return self.evaluate(soc, temperature_c, power_w).current_a

    def loss_w(
        self,
        soc: float | np.ndarray,
        temperature_c: float | np.ndarray,
        power_w: float | np.ndarray,
    ) -> np.ndarray:
        return self.evaluate(soc, temperature_c, power_w).loss_w

    def voltage_v(
        self,
        soc: float | np.ndarray,
        temperature_c: float | np.ndarray,
        power_w: float | np.ndarray,
    ) -> np.ndarray:
        return self.evaluate(soc, temperature_c, power_w).voltage_v

    def delta_temperature_k(
        self,
        soc: float | np.ndarray,
        temperature_c: float | np.ndarray,
        power_w: float | np.ndarray,
        dt_s: float,
        conductance_w_k: float = 0.0,
        sink_c: float | np.ndarray = 20.0,
    ) -> np.ndarray:
        """Temperature change over ``dt_s`` using the exact exponential update."""
        heat = self.evaluate(soc, temperature_c, power_w).heat_w
        k = max(conductance_w_k, EPS)
        t_inf = np.asarray(sink_c, dtype=float) + heat / k
        decay = np.exp(-k * dt_s / max(self.heat_capacity_j_k, EPS))
        return (t_inf + (np.asarray(temperature_c, dtype=float) - t_inf) * decay) - np.asarray(
            temperature_c, dtype=float
        )

    def soc_delta(
        self,
        current_a: np.ndarray,
        dt_s: float,
        capacity_ah: float,
        coulombic_efficiency: float = 1.0,
    ) -> np.ndarray:
        """Vectorised charge integration matching :meth:`BatteryPlant.step`."""
        ah = current_a * dt_s / SECONDS_PER_HOUR
        ah = np.where(current_a < 0.0, ah * coulombic_efficiency, ah)
        return -ah / max(capacity_ah, EPS)

    # -- housekeeping -------------------------------------------------------

    def matches(self, battery: Battery) -> bool:
        return self.fingerprint == _battery_fingerprint(battery)

    def size_bytes(self) -> int:
        return sum(arr.nbytes for arr in self.tables.values())

    def validate_against(
        self,
        battery: Battery,
        *,
        n_samples: int = 300,
        seed: int = 0,
    ) -> dict[str, float]:
        """Error against the exact ECM at random interior points.

        Errors are normalised by the physical *range* each quantity spans over
        the sample. Pointwise normalisation makes anything that legitimately
        passes through zero -- loss at zero power -- look catastrophic.
        """
        rng = np.random.default_rng(seed)
        ecm = battery.electrical
        growth = battery.degradation_state.resistance_growth
        socs = rng.uniform(self.soc_grid[0], self.soc_grid[-1], n_samples)
        temps = rng.uniform(self.temperature_grid[0], self.temperature_grid[-1], n_samples)
        v_nom = battery.nominal_voltage
        powers = rng.uniform(
            -battery.maximum_charge_current * v_nom, battery.maximum_current * v_nom, n_samples
        )

        truth = {"current_a": [], "voltage_v": [], "loss_w": []}
        for s, t, p in zip(socs, temps, powers):
            i = ecm.current_for_power(
                float(p), soc=float(s), temperature_c=float(t), resistance_growth=growth
            )
            resp = ecm.evaluate(
                soc=float(s),
                current_a=i,
                temperature_c=float(t),
                resistance_growth=growth,
            )
            truth["current_a"].append(i)
            truth["voltage_v"].append(resp.voltage_v)
            truth["loss_w"].append(resp.loss_w)

        approx = self.evaluate(socs, temps, powers)
        got = {
            "current_a": approx.current_a,
            "voltage_v": approx.voltage_v,
            "loss_w": approx.loss_w,
        }
        report: dict[str, float] = {}
        for key, values in truth.items():
            tr = np.asarray(values)
            ap = np.asarray(got[key])
            scale = max(float(tr.max() - tr.min()), 1e-9)
            err = np.abs(ap - tr) / scale
            report[f"{key}_max_rel_error"] = float(err.max())
            report[f"{key}_rms_rel_error"] = float(np.sqrt(np.mean(err**2)))
        return report


def build_surrogate(
    battery: Battery,
    *,
    n_soc: int = 81,
    n_temp: int = 31,
    soc_range: tuple[float, float] = (0.0, 1.0),
    temperature_range: tuple[float, float] = (-20.0, 60.0),
) -> ResponseSurface:
    """Tabulate OCV, resistance and entropic coefficient on a 2-D grid.

    The grid is cheap -- a few thousand evaluations of closed-form expressions
    -- so it is built at full resolution by default rather than traded off.
    """
    started = time.perf_counter()
    chem = battery.chemistry
    topo = battery.topology
    growth = battery.degradation_state.resistance_growth

    soc_grid = np.linspace(soc_range[0], soc_range[1], n_soc)
    temp_grid = np.linspace(temperature_range[0], temperature_range[1], n_temp)
    ss, tt = np.meshgrid(soc_grid, temp_grid, indexing="ij")

    ocv_cell = np.asarray(chem.ocv.voltage_at(ss), dtype=float)
    dudt_cell = np.asarray(chem.ocv.dudt_at(ss), dtype=float)
    rmodel = chem.resistance
    r_cell = (
        rmodel.r0_ref_ohm
        * np.asarray(rmodel.temperature_factor(tt), dtype=float)
        * np.asarray(rmodel.soc_factor(ss), dtype=float)
        * (1.0 + max(growth, -0.99))
    )
    # Scale to system level. resistance_from_cell is affine in the cell
    # resistance, so two evaluations recover its slope and intercept exactly.
    r0_at_zero = topo.resistance_from_cell(0.0)
    r0_slope = topo.resistance_from_cell(1.0) - r0_at_zero
    r_dis = r0_at_zero + r0_slope * r_cell
    r_chg = r0_at_zero + r0_slope * (r_cell * rmodel.charge_multiplier)

    tables = {
        "ocv_v": ocv_cell * topo.n_series,
        "r_discharge_ohm": r_dis,
        "r_charge_ohm": r_chg,
        "dudt_v_per_k": dudt_cell,
    }
    return ResponseSurface(
        soc_grid=soc_grid,
        temperature_grid=temp_grid,
        tables=tables,
        fingerprint=_battery_fingerprint(battery),
        heat_capacity_j_k=topo.heat_capacity_j_k,
        cell_count=topo.cell_count,
        parallel_strings=topo.n_parallel * topo.parallel_sharing_efficiency,
        nameplate_capacity_ah=battery.nameplate_capacity_ah,
        build_seconds=time.perf_counter() - started,
        meta={
            "battery_id": battery.battery_id,
            "chemistry": battery.chemistry_name,
            "grid": [n_soc, n_temp],
        },
    )


def degradation_rate_array(
    battery: Battery,
    *,
    soc: np.ndarray,
    temperature_c: np.ndarray,
    current_a: np.ndarray,
    dod: float | None = None,
) -> np.ndarray:
    """Vectorised marginal capacity-fade rate, per second.

    A NumPy transcription of
    :meth:`~batteryopt.models.degradation.DegradationModel.marginal_fade_rate`.
    Kept here rather than in the degradation module because it is a
    performance concern, and verified against the scalar implementation in the
    test suite so the two cannot silently diverge.
    """
    c = battery.chemistry.degradation
    state = battery.degradation_state
    q_nom = max(battery.nameplate_capacity_ah, EPS)
    charging = current_a < 0.0
    c_rate = np.abs(current_a) / q_nom
    dod_v = c.dod_stress_ref if dod is None else dod

    # Saturated exactly as the scalar model does; see degradation.MAX_STRESS.
    t_k = np.clip(temperature_c + KELVIN_OFFSET, 200.0, 500.0)
    t_ref_k = c.t_ref_c + KELVIN_OFFSET
    s = np.clip(soc, 0.0, 1.0)

    from .degradation import MAX_STRESS

    ceiling = np.log(MAX_STRESS)

    def sat_exp(x):
        return np.exp(np.clip(x, -ceiling, ceiling))

    arr_cal = sat_exp(c.ea_calendar_j_mol / GAS_CONSTANT * (1.0 / t_ref_k - 1.0 / t_k))
    soc_term = sat_exp(c.soc_stress_gain * (s - c.soc_stress_ref))
    low = np.maximum(c.low_soc_threshold - s, 0.0)
    soc_term = soc_term + c.low_soc_gain * low * low
    hot = np.where(
        temperature_c > c.high_temp_threshold_c,
        sat_exp(c.high_temp_gain * np.maximum(temperature_c - c.high_temp_threshold_c, 0.0)),
        1.0,
    )
    s_cal = np.minimum(arr_cal * soc_term * hot, MAX_STRESS)

    arr_cyc = sat_exp(c.ea_cycle_j_mol / GAS_CONSTANT * (1.0 / t_ref_k - 1.0 / t_k))
    dod_term = sat_exp(c.dod_stress_gain * (np.clip(dod_v, 0.0, 1.0) - c.dod_stress_ref))
    rate_term = sat_exp(c.c_rate_stress_gain * (c_rate - c.c_rate_stress_ref))
    asym = np.where(charging, c.charge_stress_multiplier, 1.0)
    deficit = np.maximum(c.plating_threshold_c - temperature_c, 0.0)
    plating = np.where(
        charging,
        np.minimum(
            sat_exp(c.plating_gain * deficit * np.maximum(c_rate, 0.05)),
            c.plating_max_multiplier,
        ),
        1.0,
    )
    s_cyc = np.minimum(arr_cyc * dod_term * rate_term * asym * hot * plating, MAX_STRESS)

    t_eq = max(state.t_eq_years, 0.0) + c.formation_years
    a_eq = max(state.a_eq_efc, 0.0) + c.formation_efc
    d_t_eq_dt = s_cal / SECONDS_PER_YEAR
    d_a_eq_dt = s_cyc * np.abs(current_a) / (SECONDS_PER_HOUR * 2.0 * q_nom)
    return (
        c.a_calendar * c.z_calendar * t_eq ** (c.z_calendar - 1.0) * d_t_eq_dt
        + c.a_cycle * c.z_cycle * a_eq ** (c.z_cycle - 1.0) * d_a_eq_dt
    )


class SurrogateCache:
    """Process-local LRU cache of surrogates, keyed by battery fingerprint."""

    __slots__ = ("_items", "_max_items", "_builder")

    def __init__(
        self,
        *,
        max_items: int = 8,
        builder: Callable[[Battery], ResponseSurface] | None = None,
    ) -> None:
        self._items: dict[str, ResponseSurface] = {}
        self._max_items = max_items
        self._builder = builder or build_surrogate

    def get(self, battery: Battery) -> ResponseSurface:
        key = _battery_fingerprint(battery)
        surface = self._items.pop(key, None)
        if surface is None:
            surface = self._builder(battery)
            if len(self._items) >= self._max_items:
                self._items.pop(next(iter(self._items)))
        self._items[key] = surface
        return surface

    def clear(self) -> None:
        self._items.clear()

    def __len__(self) -> int:
        return len(self._items)


__all__ = [
    "ResponseSurface",
    "SurrogateResponse",
    "build_surrogate",
    "degradation_rate_array",
    "SurrogateCache",
    "TABULATED",
]
