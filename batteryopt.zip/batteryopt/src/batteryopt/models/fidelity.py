"""Model fidelity tiers (specification section 13).

Four tiers, one interface. The optimiser runs FAST or STANDARD inside its
inner loop and DETAILED or RESEARCH offline to check that the fast model has
not drifted away from the physics.

============  ===========================================================
Tier          What it is
============  ===========================================================
``FAST``      Quasi-static ECM: OCV, series resistance, no diffusion state.
              Evaluates in ~1 microsecond. Used for candidate screening and
              for the innermost loop of dynamic programming.
``STANDARD``  Full Thevenin ECM with diffusion RC branches, lumped thermal
              model and the stress-weighted degradation model. This is the
              default and what recommendations are computed against.
``DETAILED``  STANDARD plus a coolant thermal node, finer default time step
              and, when PyBaMM is installed, a single-particle model with
              electrolyte (SPMe) for the electrical response.
``RESEARCH``  PyBaMM Doyle-Fuller-Newman. Offline only: seconds per
              simulated minute, but it is the reference the surrogate and
              the ECM parameters are fitted against.
============  ===========================================================

Choosing a tier changes accuracy and cost, never units or sign conventions,
so a scenario can be re-priced at a higher tier without touching the caller.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from ..core.optional import have
from .battery import Battery
from .plant import BatteryPlant
from .thermal import LumpedThermalModel


class Fidelity(str, Enum):
    FAST = "FAST"
    STANDARD = "STANDARD"
    DETAILED = "DETAILED"
    RESEARCH = "RESEARCH"

    @property
    def rank(self) -> int:
        return {"FAST": 0, "STANDARD": 1, "DETAILED": 2, "RESEARCH": 3}[self.value]

    @property
    def is_realtime_safe(self) -> bool:
        """Whether this tier belongs on the real-time path."""
        return self.rank <= 1


@dataclass(frozen=True, slots=True)
class FidelityProfile:
    """Concrete settings behind a fidelity tier."""

    fidelity: Fidelity
    #: Default integration step, seconds.
    time_step_s: float
    #: Include diffusion RC branches in the electrical model.
    use_rc: bool
    #: Include OCV hysteresis.
    use_hysteresis: bool
    #: Track a separate coolant thermal node.
    coolant_node: bool
    #: Preferred electrical backend: ``"ecm"``, ``"spme"`` or ``"dfn"``.
    backend: str
    #: Rough relative cost per simulated step, for planning sweeps.
    relative_cost: float


PROFILES: dict[Fidelity, FidelityProfile] = {
    Fidelity.FAST: FidelityProfile(
        fidelity=Fidelity.FAST,
        time_step_s=300.0,
        use_rc=False,
        use_hysteresis=False,
        coolant_node=False,
        backend="ecm",
        relative_cost=1.0,
    ),
    Fidelity.STANDARD: FidelityProfile(
        fidelity=Fidelity.STANDARD,
        time_step_s=60.0,
        use_rc=True,
        use_hysteresis=True,
        coolant_node=False,
        backend="ecm",
        relative_cost=3.0,
    ),
    Fidelity.DETAILED: FidelityProfile(
        fidelity=Fidelity.DETAILED,
        time_step_s=10.0,
        use_rc=True,
        use_hysteresis=True,
        coolant_node=True,
        backend="spme",
        relative_cost=40.0,
    ),
    Fidelity.RESEARCH: FidelityProfile(
        fidelity=Fidelity.RESEARCH,
        time_step_s=1.0,
        use_rc=True,
        use_hysteresis=True,
        coolant_node=True,
        backend="dfn",
        relative_cost=5000.0,
    ),
}


def profile_for(fidelity: Fidelity | str) -> FidelityProfile:
    return PROFILES[Fidelity(fidelity)]


def effective_backend(fidelity: Fidelity | str) -> str:
    """Backend actually usable here, degrading gracefully without PyBaMM.

    A DETAILED or RESEARCH request on a machine without PyBaMM does not fail;
    it falls back to the ECM and the caller can see that it did, because the
    returned backend name differs from the requested one.
    """
    prof = profile_for(fidelity)
    if prof.backend in ("spme", "dfn") and not have("pybamm"):
        return "ecm"
    return prof.backend


def build_plant(
    battery: Battery,
    fidelity: Fidelity | str = Fidelity.STANDARD,
    *,
    track_states: bool = True,
) -> BatteryPlant:
    """Construct a plant configured for the requested fidelity tier.

    The returned plant is always a :class:`BatteryPlant`; higher tiers change
    the models hanging off it rather than the stepping interface, so callers
    are fidelity-agnostic.
    """
    prof = profile_for(fidelity)
    from .electrical import EquivalentCircuitModel

    ecm = EquivalentCircuitModel(battery.topology, use_hysteresis=prof.use_hysteresis)
    if not prof.use_rc:
        # Collapse the diffusion branches into the series resistance so that
        # the quasi-static model still accounts for their steady-state drop.
        object.__setattr__(ecm, "_n_rc", 0)
        object.__setattr__(ecm, "_rc_r_cell", ())
        object.__setattr__(ecm, "_rc_tau", ())
    battery._ecm = ecm  # noqa: SLF001 - deliberate model injection

    if prof.coolant_node:
        topo = battery.topology
        battery._thermal = LumpedThermalModel(  # noqa: SLF001
            topo,
            coolant_heat_capacity_j_k=0.25 * topo.heat_capacity_j_k,
            coolant_conductance_w_k=2.5 * topo.active_conductance_w_k,
        )
    return BatteryPlant(battery, track_states=track_states)


def default_time_step(fidelity: Fidelity | str) -> float:
    return profile_for(fidelity).time_step_s


__all__ = [
    "Fidelity",
    "FidelityProfile",
    "PROFILES",
    "profile_for",
    "effective_backend",
    "build_plant",
    "default_time_step",
]
