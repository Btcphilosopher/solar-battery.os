"""Degradation engine (specification sections 11 and 12).

Degradation is treated as a first-class optimisation variable, not a
post-hoc report. Every candidate strategy is priced in lost capacity and
gained resistance, so the optimiser can trade 30 pence of electricity against
0.004 % of battery life and get the sign right.

Formulation
-----------
Two mechanisms accumulate independently, each as a stress-weighted power law:

.. code-block:: text

    t_eq += s_cal(soc, T) * dt          [equivalent years]
    A_eq += s_cyc(C, T, soc, DOD) * dQ  [equivalent full cycles]

    fade     = a_cal * ((t_eq + t0)**z_cal - t0**z_cal)
             + a_cyc * ((A_eq + A0)**z_cyc - A0**z_cyc)
    R_growth = b_cal * ((t_eq + t0)**y_cal - t0**y_cal)
             + b_cyc * ((A_eq + A0)**y_cyc - A0**y_cyc)

with ``z, y < 1`` and ``t0``, ``A0`` the formation offsets that stop the law
being singular at zero age (see :class:`DegradationCoefficients`). Sub-linear exponents reproduce the diffusion-limited growth
of the SEI layer: the first hundred cycles cost more capacity than the second
hundred. The optimiser sees this correctly as a declining marginal cost of
cycling, which is the physically right behaviour and the opposite of what a
naive linear "cycles used" counter would say.

Stress factors
--------------
* **Calendar**: Arrhenius in temperature, exponential in SOC above a
  reference, with an extra penalty at very low SOC.
* **Cycle**: Arrhenius in temperature, exponential in C-rate and in depth of
  discharge, asymmetric between charge and discharge.
* **Lithium plating**: a multiplicative penalty applied *only when charging
  below a threshold temperature*, growing with both the temperature deficit
  and the rate. This single term is what makes "warm the pack, then charge"
  the correct winter answer, and it is the reason a naive optimiser that
  ignores temperature will destroy a pack in a cold climate.
* **High-temperature**: an additional exponential above ~45 degC where
  electrolyte decomposition adds to the Arrhenius trend.

The coefficients are representative literature values, not a warranty model.
:meth:`DegradationModel.confidence` reports how far the present operating
point sits outside the region where such models are usually fitted, so
downstream consumers can widen their intervals rather than trust an
extrapolation.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, replace

import numpy as np

from ..core.numerics import EPS, clamp
from ..core.provenance import Quantiles
from ..core.units import (
    GAS_CONSTANT,
    KELVIN_OFFSET,
    SECONDS_PER_HOUR,
    SECONDS_PER_YEAR,
)
from .chemistry import DegradationCoefficients
from .state import DegradationState

# The formation offsets in the chemistry parameters make the power law
# non-singular at zero age, so no artificial floor is needed when
# differentiating it. See DegradationCoefficients.formation_efc.

#: Ceiling on any single stress factor and on their product.
#:
#: The stress model is a product of exponentials, and at absurd inputs -- a
#: simulated 200 degC excursion, a 50C pulse -- that product overflows a double
#: before anything else notices. Saturating it is not a cosmetic guard: an
#: unbounded acceleration factor is meaningless anyway, because a cell at those
#: conditions has vented rather than aged, and a NaN propagating out of the
#: degradation model silently poisons every downstream cost.
MAX_STRESS = 1.0e6

#: Temperature range over which the stress model is evaluated at all. Outside
#: it the factors are clamped rather than extrapolated.
_MIN_TEMPERATURE_K = 200.0
_MAX_TEMPERATURE_K = 500.0


def _saturating_exp(x: float) -> float:
    """``exp`` that saturates instead of overflowing."""
    if x >= _EXP_CEILING:
        return MAX_STRESS
    if x <= -_EXP_CEILING:
        return 1.0 / MAX_STRESS
    return math.exp(x)


_EXP_CEILING = math.log(MAX_STRESS)


@dataclass(frozen=True, slots=True)
class DegradationIncrement:
    """Damage attributable to one interval of operation."""

    capacity_fade: float
    resistance_growth: float
    t_eq_years: float
    a_eq_efc: float
    throughput_ah: float
    #: Stress multipliers that produced this increment, for explanation.
    calendar_stress: float
    cycle_stress: float
    plating_multiplier: float

    def __add__(self, other: "DegradationIncrement") -> "DegradationIncrement":
        return DegradationIncrement(
            capacity_fade=self.capacity_fade + other.capacity_fade,
            resistance_growth=self.resistance_growth + other.resistance_growth,
            t_eq_years=self.t_eq_years + other.t_eq_years,
            a_eq_efc=self.a_eq_efc + other.a_eq_efc,
            throughput_ah=self.throughput_ah + other.throughput_ah,
            calendar_stress=max(self.calendar_stress, other.calendar_stress),
            cycle_stress=max(self.cycle_stress, other.cycle_stress),
            plating_multiplier=max(self.plating_multiplier, other.plating_multiplier),
        )


@dataclass(frozen=True, slots=True)
class LifeEstimate:
    """Remaining-useful-life estimate with an explicit uncertainty band."""

    remaining_seconds: float
    remaining_years: float
    expected_capacity_at_horizon: float
    expected_resistance_at_horizon: float
    quantiles_years: Quantiles
    confidence: float
    limiting_mechanism: str

    def as_dict(self) -> dict[str, object]:
        return {
            "remaining_seconds": self.remaining_seconds,
            "remaining_years": self.remaining_years,
            "expected_capacity_at_horizon": self.expected_capacity_at_horizon,
            "expected_resistance_at_horizon": self.expected_resistance_at_horizon,
            "quantiles_years": self.quantiles_years.as_dict(),
            "confidence": self.confidence,
            "limiting_mechanism": self.limiting_mechanism,
        }


class DegradationModel:
    """Stress-weighted power-law ageing model."""

    __slots__ = ("c",)

    def __init__(self, coefficients: DegradationCoefficients) -> None:
        self.c = coefficients

    # -- stress factors -----------------------------------------------------

    def calendar_stress(self, *, soc: float, temperature_c: float) -> float:
        """Dimensionless calendar-ageing acceleration versus reference."""
        c = self.c
        t_k = clamp(temperature_c + KELVIN_OFFSET, _MIN_TEMPERATURE_K, _MAX_TEMPERATURE_K)
        t_ref_k = c.t_ref_c + KELVIN_OFFSET
        arrhenius = _saturating_exp(
            c.ea_calendar_j_mol / GAS_CONSTANT * (1.0 / t_ref_k - 1.0 / t_k)
        )
        s = clamp(soc, 0.0, 1.0)
        soc_term = _saturating_exp(c.soc_stress_gain * (s - c.soc_stress_ref))
        if s < c.low_soc_threshold:
            deficit = c.low_soc_threshold - s
            soc_term += c.low_soc_gain * deficit * deficit
        hot = 1.0
        if temperature_c > c.high_temp_threshold_c:
            hot = _saturating_exp(
                c.high_temp_gain * (temperature_c - c.high_temp_threshold_c)
            )
        return min(arrhenius * soc_term * hot, MAX_STRESS)

    def plating_multiplier(self, *, temperature_c: float, c_rate: float, charging: bool) -> float:
        """Lithium-plating penalty. 1.0 unless charging below the threshold."""
        c = self.c
        if not charging or temperature_c >= c.plating_threshold_c:
            return 1.0
        deficit = c.plating_threshold_c - temperature_c
        mult = _saturating_exp(c.plating_gain * deficit * max(abs(c_rate), 0.05))
        return min(mult, c.plating_max_multiplier)

    def cycle_stress(
        self,
        *,
        c_rate: float,
        temperature_c: float,
        dod: float,
        charging: bool,
    ) -> float:
        """Dimensionless cycling-ageing acceleration per ampere-hour moved."""
        c = self.c
        t_k = clamp(temperature_c + KELVIN_OFFSET, _MIN_TEMPERATURE_K, _MAX_TEMPERATURE_K)
        t_ref_k = c.t_ref_c + KELVIN_OFFSET
        arrhenius = _saturating_exp(
            c.ea_cycle_j_mol / GAS_CONSTANT * (1.0 / t_ref_k - 1.0 / t_k)
        )
        dod_term = _saturating_exp(
            c.dod_stress_gain * (clamp(dod, 0.0, 1.0) - c.dod_stress_ref)
        )
        rate_term = _saturating_exp(
            c.c_rate_stress_gain * (abs(c_rate) - c.c_rate_stress_ref)
        )
        asym = c.charge_stress_multiplier if charging else 1.0
        hot = 1.0
        if temperature_c > c.high_temp_threshold_c:
            hot = _saturating_exp(
                c.high_temp_gain * (temperature_c - c.high_temp_threshold_c)
            )
        plating = self.plating_multiplier(
            temperature_c=temperature_c, c_rate=c_rate, charging=charging
        )
        return min(arrhenius * dod_term * rate_term * asym * hot * plating, MAX_STRESS)

    # -- damage laws --------------------------------------------------------

    def fade(self, t_eq_years: float, a_eq_efc: float) -> float:
        """Fractional capacity loss for given stress-weighted accumulators."""
        c = self.c
        t0, a0 = c.formation_years, c.formation_efc
        return c.a_calendar * (
            (max(t_eq_years, 0.0) + t0) ** c.z_calendar - t0**c.z_calendar
        ) + c.a_cycle * ((max(a_eq_efc, 0.0) + a0) ** c.z_cycle - a0**c.z_cycle)

    def growth(self, t_eq_years: float, a_eq_efc: float) -> float:
        """Fractional resistance increase for given stress-weighted accumulators."""
        c = self.c
        t0, a0 = c.formation_years, c.formation_efc
        return c.b_calendar * (
            (max(t_eq_years, 0.0) + t0) ** c.y_calendar - t0**c.y_calendar
        ) + c.b_cycle * ((max(a_eq_efc, 0.0) + a0) ** c.y_cycle - a0**c.y_cycle)

    # -- integration --------------------------------------------------------

    def step(
        self,
        state: DegradationState,
        *,
        dt: float,
        soc: float,
        temperature_c: float,
        current_a: float,
        nameplate_capacity_ah: float,
        dod: float | None = None,
    ) -> tuple[DegradationState, DegradationIncrement]:
        """Accumulate damage over ``dt`` seconds at a constant operating point.

        ``dod`` is the depth of the cycle this interval belongs to. When it is
        unknown, the instantaneous swing implied by the current over the
        interval is used, which under-counts deep cycles slightly; the
        :class:`RainflowCounter` provides the correct value when a full SOC
        trace is available.
        """
        if dt <= 0.0 or nameplate_capacity_ah <= EPS:
            return state, DegradationIncrement(0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0)

        charging = current_a < 0.0
        c_rate = abs(current_a) / nameplate_capacity_ah
        throughput_ah = abs(current_a) * dt / SECONDS_PER_HOUR
        if dod is None:
            dod = min(1.0, throughput_ah / max(nameplate_capacity_ah, EPS))

        s_cal = self.calendar_stress(soc=soc, temperature_c=temperature_c)
        s_cyc = self.cycle_stress(
            c_rate=c_rate, temperature_c=temperature_c, dod=dod, charging=charging
        )
        plating = self.plating_multiplier(
            temperature_c=temperature_c, c_rate=c_rate, charging=charging
        )

        d_t_eq = s_cal * dt / SECONDS_PER_YEAR
        # One equivalent full cycle is two nameplate capacities of throughput.
        d_a_eq = s_cyc * throughput_ah / (2.0 * nameplate_capacity_ah)

        t_eq = state.t_eq_years + d_t_eq
        a_eq = state.a_eq_efc + d_a_eq
        fade_new = self.fade(t_eq, a_eq)
        growth_new = self.growth(t_eq, a_eq)

        new_state = DegradationState(
            t_eq_years=t_eq,
            a_eq_efc=a_eq,
            throughput_ah=state.throughput_ah + throughput_ah,
            equivalent_full_cycles=state.equivalent_full_cycles
            + throughput_ah / (2.0 * nameplate_capacity_ah),
            age_s=state.age_s + dt,
            capacity_fade=fade_new,
            resistance_growth=growth_new,
        )
        increment = DegradationIncrement(
            capacity_fade=fade_new - state.capacity_fade,
            resistance_growth=growth_new - state.resistance_growth,
            t_eq_years=d_t_eq,
            a_eq_efc=d_a_eq,
            throughput_ah=throughput_ah,
            calendar_stress=s_cal,
            cycle_stress=s_cyc,
            plating_multiplier=plating,
        )
        return new_state, increment

    # -- marginal rates (what the optimiser actually consumes) --------------

    def marginal_fade_rate(
        self,
        state: DegradationState,
        *,
        soc: float,
        temperature_c: float,
        current_a: float,
        nameplate_capacity_ah: float,
        dod: float | None = None,
    ) -> float:
        """Instantaneous capacity-fade rate, per second.

        The analytic derivative of the power law. This is the quantity the
        objective function multiplies by a replacement cost to get pounds per
        second of operating at a given point, and it is what makes the whole
        engine degradation-aware rather than degradation-reporting.
        """
        c = self.c
        if nameplate_capacity_ah <= EPS:
            return 0.0
        charging = current_a < 0.0
        c_rate = abs(current_a) / nameplate_capacity_ah
        if dod is None:
            dod = c.dod_stress_ref

        s_cal = self.calendar_stress(soc=soc, temperature_c=temperature_c)
        s_cyc = self.cycle_stress(
            c_rate=c_rate, temperature_c=temperature_c, dod=dod, charging=charging
        )

        t_eq = max(state.t_eq_years, 0.0) + c.formation_years
        a_eq = max(state.a_eq_efc, 0.0) + c.formation_efc

        d_t_eq_dt = s_cal / SECONDS_PER_YEAR
        d_a_eq_dt = s_cyc * abs(current_a) / (SECONDS_PER_HOUR * 2.0 * nameplate_capacity_ah)

        cal_term = c.a_calendar * c.z_calendar * t_eq ** (c.z_calendar - 1.0) * d_t_eq_dt
        cyc_term = c.a_cycle * c.z_cycle * a_eq ** (c.z_cycle - 1.0) * d_a_eq_dt
        return cal_term + cyc_term

    def marginal_growth_rate(
        self,
        state: DegradationState,
        *,
        soc: float,
        temperature_c: float,
        current_a: float,
        nameplate_capacity_ah: float,
        dod: float | None = None,
    ) -> float:
        """Instantaneous resistance-growth rate, per second."""
        c = self.c
        if nameplate_capacity_ah <= EPS:
            return 0.0
        charging = current_a < 0.0
        c_rate = abs(current_a) / nameplate_capacity_ah
        if dod is None:
            dod = c.dod_stress_ref
        s_cal = self.calendar_stress(soc=soc, temperature_c=temperature_c)
        s_cyc = self.cycle_stress(
            c_rate=c_rate, temperature_c=temperature_c, dod=dod, charging=charging
        )
        t_eq = max(state.t_eq_years, 0.0) + c.formation_years
        a_eq = max(state.a_eq_efc, 0.0) + c.formation_efc
        d_t_eq_dt = s_cal / SECONDS_PER_YEAR
        d_a_eq_dt = s_cyc * abs(current_a) / (SECONDS_PER_HOUR * 2.0 * nameplate_capacity_ah)
        return (
            c.b_calendar * c.y_calendar * t_eq ** (c.y_calendar - 1.0) * d_t_eq_dt
            + c.b_cycle * c.y_cycle * a_eq ** (c.y_cycle - 1.0) * d_a_eq_dt
        )

    # -- prognosis ----------------------------------------------------------

    def confidence(self, *, soc: float, temperature_c: float, c_rate: float) -> float:
        """How much to trust the model at this operating point, 0-1.

        Ageing coefficients are fitted over a limited envelope, typically
        0-45 degC and up to about 2C. Outside it the model is extrapolating and
        says so, rather than returning a confident number that happens to be
        wrong.
        """
        penalty = 0.0
        if temperature_c > 45.0:
            penalty += 0.04 * (temperature_c - 45.0)
        if temperature_c < 0.0:
            penalty += 0.03 * (0.0 - temperature_c)
        if abs(c_rate) > 2.0:
            penalty += 0.15 * (abs(c_rate) - 2.0)
        if soc > 0.95:
            penalty += 2.0 * (soc - 0.95)
        return clamp(0.9 - penalty, 0.05, 0.95)

    def remaining_useful_life(
        self,
        state: DegradationState,
        *,
        soc: float,
        temperature_c: float,
        mean_current_a: float,
        nameplate_capacity_ah: float,
        dod: float | None = None,
        eol_soh: float | None = None,
        horizon_years: float = 25.0,
    ) -> LifeEstimate:
        """Project remaining life at the present duty cycle.

        The projection integrates the power law forward at constant stress
        rather than linearly extrapolating the present rate. Because the law
        is sub-linear, a linear extrapolation would be badly pessimistic for a
        new cell and badly optimistic for an old one.
        """
        c = self.c
        target_fade = 1.0 - (eol_soh if eol_soh is not None else c.end_of_life_soh)
        if state.capacity_fade >= target_fade:
            return LifeEstimate(
                remaining_seconds=0.0,
                remaining_years=0.0,
                expected_capacity_at_horizon=state.soh_capacity,
                expected_resistance_at_horizon=state.resistance_growth,
                quantiles_years=Quantiles.degenerate(0.0),
                confidence=0.9,
                limiting_mechanism="already at end of life",
            )

        charging = mean_current_a < 0.0
        c_rate = abs(mean_current_a) / max(nameplate_capacity_ah, EPS)
        if dod is None:
            dod = c.dod_stress_ref
        s_cal = self.calendar_stress(soc=soc, temperature_c=temperature_c)
        s_cyc = self.cycle_stress(
            c_rate=c_rate, temperature_c=temperature_c, dod=dod, charging=charging
        )
        d_t_eq_dt = s_cal / SECONDS_PER_YEAR
        d_a_eq_dt = (
            s_cyc * abs(mean_current_a) / (SECONDS_PER_HOUR * 2.0 * max(nameplate_capacity_ah, EPS))
        )

        def fade_after(seconds: float) -> float:
            return self.fade(
                state.t_eq_years + d_t_eq_dt * seconds,
                state.a_eq_efc + d_a_eq_dt * seconds,
            )

        horizon_s = horizon_years * SECONDS_PER_YEAR
        if fade_after(horizon_s) < target_fade:
            remaining = math.inf
            remaining_years = math.inf
        else:
            lo, hi = 0.0, horizon_s
            for _ in range(80):
                mid = 0.5 * (lo + hi)
                if fade_after(mid) < target_fade:
                    lo = mid
                else:
                    hi = mid
            remaining = 0.5 * (lo + hi)
            remaining_years = remaining / SECONDS_PER_YEAR

        # Which mechanism dominates the remaining damage?
        probe = remaining if math.isfinite(remaining) else horizon_s
        t0, a0 = c.formation_years, c.formation_efc
        cal_share = c.a_calendar * (
            (state.t_eq_years + d_t_eq_dt * probe + t0) ** c.z_calendar - t0**c.z_calendar
        )
        cyc_share = c.a_cycle * (
            (state.a_eq_efc + d_a_eq_dt * probe + a0) ** c.z_cycle - a0**c.z_cycle
        )
        mechanism = "calendar ageing" if cal_share >= cyc_share else "cycle ageing"

        conf = self.confidence(soc=soc, temperature_c=temperature_c, c_rate=c_rate)
        # Coefficient uncertainty of roughly +/-30 % maps to a life band. The
        # band is asymmetric because life scales as fade**(1/z) with z < 1.
        if math.isfinite(remaining_years):
            lo_y = remaining_years * (1.0 - 0.45 * (1.0 - conf) - 0.18)
            hi_y = remaining_years * (1.0 + 0.75 * (1.0 - conf) + 0.22)
            band = Quantiles(max(0.0, lo_y), remaining_years, hi_y)
        else:
            band = Quantiles(horizon_years, horizon_years, horizon_years)

        horizon_fade = fade_after(horizon_s)
        return LifeEstimate(
            remaining_seconds=remaining,
            remaining_years=remaining_years,
            expected_capacity_at_horizon=max(0.0, 1.0 - horizon_fade),
            expected_resistance_at_horizon=self.growth(
                state.t_eq_years + d_t_eq_dt * horizon_s,
                state.a_eq_efc + d_a_eq_dt * horizon_s,
            ),
            quantiles_years=band,
            confidence=conf,
            limiting_mechanism=mechanism,
        )

    def project(
        self,
        state: DegradationState,
        *,
        years: np.ndarray,
        soc: float,
        temperature_c: float,
        mean_current_a: float,
        nameplate_capacity_ah: float,
        dod: float | None = None,
    ) -> dict[str, np.ndarray]:
        """Vectorised capacity/resistance trajectory over a year grid."""
        c = self.c
        charging = mean_current_a < 0.0
        c_rate = abs(mean_current_a) / max(nameplate_capacity_ah, EPS)
        s_cal = self.calendar_stress(soc=soc, temperature_c=temperature_c)
        s_cyc = self.cycle_stress(
            c_rate=c_rate,
            temperature_c=temperature_c,
            dod=c.dod_stress_ref if dod is None else dod,
            charging=charging,
        )
        yrs = np.asarray(years, dtype=float)
        t_eq = state.t_eq_years + s_cal * yrs
        a_eq = state.a_eq_efc + s_cyc * (
            abs(mean_current_a) * yrs * SECONDS_PER_YEAR
            / (SECONDS_PER_HOUR * 2.0 * max(nameplate_capacity_ah, EPS))
        )
        t0, a0 = c.formation_years, c.formation_efc
        fade = c.a_calendar * ((t_eq + t0) ** c.z_calendar - t0**c.z_calendar) + c.a_cycle * (
            (a_eq + a0) ** c.z_cycle - a0**c.z_cycle
        )
        growth = c.b_calendar * ((t_eq + t0) ** c.y_calendar - t0**c.y_calendar) + c.b_cycle * (
            (a_eq + a0) ** c.y_cycle - a0**c.y_cycle
        )
        return {
            "years": yrs,
            "soh_capacity": np.maximum(0.0, 1.0 - fade),
            "resistance_growth": growth,
            "t_eq_years": t_eq,
            "a_eq_efc": a_eq,
        }


class RainflowCounter:
    """Streaming rainflow cycle counter over an SOC trace.

    Depth of discharge drives ageing far more strongly than throughput alone,
    so counting "how much charge moved" is not enough: one 80 % swing is worse
    than four 20 % swings of the same total throughput. This is the standard
    three-point rainflow reduction, run incrementally so it can consume live
    telemetry without buffering the whole history.
    """

    __slots__ = ("_stack", "_cycles", "_last", "_direction")

    def __init__(self) -> None:
        self._stack: list[float] = []
        self._cycles: list[tuple[float, float]] = []  # (range, mean)
        self._last: float | None = None
        self._direction: int = 0

    def update(self, soc: float) -> None:
        """Feed one SOC sample."""
        if self._last is None:
            self._last = soc
            self._stack.append(soc)
            return
        direction = 1 if soc > self._last else (-1 if soc < self._last else 0)
        if direction == 0:
            return
        if self._direction != 0 and direction != self._direction:
            self._stack.append(self._last)
            self._reduce()
        self._direction = direction
        self._last = soc

    def _reduce(self) -> None:
        while len(self._stack) >= 3:
            a, b, c = self._stack[-3], self._stack[-2], self._stack[-1]
            r1 = abs(b - a)
            r2 = abs(c - b)
            if r2 < r1:
                break
            self._cycles.append((r1, 0.5 * (a + b)))
            del self._stack[-3:-1]

    def close(self) -> None:
        """Flush residual half-cycles at the end of a trace."""
        if self._last is not None:
            self._stack.append(self._last)
        for a, b in zip(self._stack, self._stack[1:]):
            self._cycles.append((abs(b - a), 0.5 * (a + b)))
        self._stack = self._stack[-1:] if self._stack else []

    @property
    def cycles(self) -> list[tuple[float, float]]:
        """List of ``(depth_of_discharge, mean_soc)`` pairs."""
        return list(self._cycles)

    @property
    def equivalent_full_cycles(self) -> float:
        return sum(r for r, _ in self._cycles)

    def mean_dod(self) -> float:
        """Throughput-weighted mean depth of discharge; 0.0 if no cycles yet."""
        total = sum(r for r, _ in self._cycles)
        if total <= EPS:
            return 0.0
        return sum(r * r for r, _ in self._cycles) / total

    def histogram(self, bins: int = 10) -> dict[str, list[float]]:
        edges = np.linspace(0.0, 1.0, bins + 1)
        depths = np.array([r for r, _ in self._cycles], dtype=float)
        counts, _ = np.histogram(depths, bins=edges)
        return {"edges": edges.tolist(), "counts": counts.astype(float).tolist()}


def with_fade(state: DegradationState, fade: float, growth: float) -> DegradationState:
    """Return a copy of ``state`` with damage overridden (used when fitting)."""
    return replace(state, capacity_fade=fade, resistance_growth=growth)


__all__ = [
    "DegradationModel",
    "DegradationIncrement",
    "LifeEstimate",
    "RainflowCounter",
    "with_fade",
]
