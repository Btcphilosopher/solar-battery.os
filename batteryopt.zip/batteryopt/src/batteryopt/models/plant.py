"""The plant model: the forward simulator that everything else is built on.

This is the "digital battery model" of specification section 14. It composes
the electrical, thermal and degradation models into a single time-stepping
object whose contract is deliberately narrow:

    given a state and an action, return the next state and what that step cost

Everything downstream -- the scenario engine, MPC, the virtual hardware, the
research sweeps -- drives this one object. That is what makes a scenario
comparison meaningful: every candidate is priced by identical physics.

Outputs are tagged :attr:`~batteryopt.core.provenance.Provenance.SIMULATED`
without exception. A simulated trajectory is never presented as evidence of
physical performance (specification section 34).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Iterable, Sequence

import numpy as np

from ..core.numerics import EPS, clamp, require_finite
from ..core.provenance import Provenance
from ..core.units import SECONDS_PER_HOUR
from .battery import Battery
from .degradation import DegradationIncrement
from .state import BatteryState


@dataclass(frozen=True, slots=True)
class Action:
    """One control action applied over one interval.

    Exactly one of ``power_w`` and ``current_a`` should be set; ``power_w``
    takes precedence. Both follow the sign convention (positive = discharge).
    """

    power_w: float | None = None
    current_a: float | None = None
    cooling_fraction: float = 0.0
    heating_fraction: float = 0.0
    #: Balancing current bled from the highest cells, A. Costs energy.
    balancing_current_a: float = 0.0

    def as_dict(self) -> dict[str, float | None]:
        return {
            "power_w": self.power_w,
            "current_a": self.current_a,
            "cooling_fraction": self.cooling_fraction,
            "heating_fraction": self.heating_fraction,
            "balancing_current_a": self.balancing_current_a,
        }


@dataclass(frozen=True, slots=True)
class StepResult:
    """The consequences of one simulated step."""

    state: BatteryState
    #: Energy across the battery terminals over the step, Wh (positive = out).
    terminal_energy_wh: float
    #: Energy actually available to the load after auxiliary consumption, Wh.
    net_energy_wh: float
    #: Ohmic and diffusion losses inside the battery, Wh.
    loss_wh: float
    #: Energy consumed by pumps, fans, heaters and balancing, Wh.
    auxiliary_wh: float
    #: Capacity fade and resistance growth incurred by this step.
    degradation: DegradationIncrement
    #: True if the requested action had to be curtailed to stay inside limits.
    curtailed: bool
    #: Name of the limit that curtailed the action, if any.
    limiting: str | None
    dt: float

    @property
    def efficiency(self) -> float:
        """Step efficiency: useful energy out over energy drawn from storage.

        On discharge this is ``net / (net + losses + aux)``; on charge it is
        ``stored / drawn``. Rest steps return 1.0 by convention.
        """
        gross = abs(self.terminal_energy_wh)
        if gross <= EPS:
            return 1.0
        if self.terminal_energy_wh > 0.0:  # discharging
            drawn = gross + self.loss_wh
            return max(0.0, self.net_energy_wh) / drawn if drawn > EPS else 0.0
        drawn = gross + self.auxiliary_wh
        stored = max(0.0, gross - self.loss_wh)
        return stored / drawn if drawn > EPS else 0.0


@dataclass(slots=True)
class Trajectory:
    """A simulated time series, with the metrics an optimiser cares about."""

    time_s: np.ndarray
    soc: np.ndarray
    voltage_v: np.ndarray
    current_a: np.ndarray
    power_w: np.ndarray
    net_power_w: np.ndarray
    temperature_c: np.ndarray
    loss_w: np.ndarray
    auxiliary_w: np.ndarray
    capacity_fade: np.ndarray
    resistance_growth: np.ndarray
    states: list[BatteryState] = field(default_factory=list)
    curtailed: np.ndarray | None = None
    limiting: list[str | None] = field(default_factory=list)

    @property
    def duration_s(self) -> float:
        return float(self.time_s[-1] - self.time_s[0]) if self.time_s.size > 1 else 0.0

    @property
    def final_state(self) -> BatteryState:
        return self.states[-1]

    @property
    def dt(self) -> np.ndarray:
        return np.diff(self.time_s)

    def energy_discharged_wh(self) -> float:
        dt = self.dt
        p = np.clip(self.power_w[1:], 0.0, None)
        return float(np.sum(p * dt) / SECONDS_PER_HOUR)

    def energy_charged_wh(self) -> float:
        dt = self.dt
        p = np.clip(-self.power_w[1:], 0.0, None)
        return float(np.sum(p * dt) / SECONDS_PER_HOUR)

    def net_energy_delivered_wh(self) -> float:
        dt = self.dt
        return float(np.sum(self.net_power_w[1:] * dt) / SECONDS_PER_HOUR)

    def losses_wh(self) -> float:
        dt = self.dt
        return float(np.sum(self.loss_w[1:] * dt) / SECONDS_PER_HOUR)

    def auxiliary_wh(self) -> float:
        dt = self.dt
        return float(np.sum(self.auxiliary_w[1:] * dt) / SECONDS_PER_HOUR)

    def total_fade(self) -> float:
        return float(self.capacity_fade[-1] - self.capacity_fade[0])

    def total_resistance_growth(self) -> float:
        return float(self.resistance_growth[-1] - self.resistance_growth[0])

    def peak_temperature_c(self) -> float:
        return float(np.max(self.temperature_c))

    def mean_efficiency(self) -> float:
        """Energy-weighted efficiency over the whole trajectory."""
        out = self.energy_discharged_wh()
        loss = self.losses_wh()
        aux = self.auxiliary_wh()
        if out > EPS:
            denom = out + loss + aux
            return (out - aux) / denom if denom > EPS else 0.0
        inp = self.energy_charged_wh()
        if inp > EPS:
            return max(0.0, inp - loss - aux) / inp
        return 1.0

    def was_curtailed(self) -> bool:
        return bool(self.curtailed is not None and np.any(self.curtailed))

    def metrics(self) -> dict[str, float | bool | str | None]:
        binding = next((x for x in self.limiting if x), None)
        return {
            "duration_s": self.duration_s,
            "energy_discharged_wh": self.energy_discharged_wh(),
            "energy_charged_wh": self.energy_charged_wh(),
            "net_energy_delivered_wh": self.net_energy_delivered_wh(),
            "losses_wh": self.losses_wh(),
            "auxiliary_wh": self.auxiliary_wh(),
            "mean_efficiency": self.mean_efficiency(),
            "capacity_fade": self.total_fade(),
            "resistance_growth": self.total_resistance_growth(),
            "peak_temperature_c": self.peak_temperature_c(),
            "final_soc": float(self.soc[-1]),
            "min_soc": float(np.min(self.soc)),
            "max_soc": float(np.max(self.soc)),
            "min_voltage_v": float(np.min(self.voltage_v)),
            "max_voltage_v": float(np.max(self.voltage_v)),
            "curtailed": self.was_curtailed(),
            "limiting_constraint": binding,
        }


class BatteryPlant:
    """Time-stepping simulator over a :class:`Battery`.

    The plant enforces *physical* saturation (an empty battery cannot
    discharge, a full one cannot charge) but is deliberately **not** the safety
    layer. Constraint enforcement lives in
    :mod:`batteryopt.optimisation.constraints` so that there is exactly one
    place where hard limits are defined and one place where they are checked.
    The plant will happily simulate an illegal action, which is what makes it
    useful for demonstrating *why* that action is illegal.
    """

    __slots__ = ("battery", "_ecm", "_thermal", "_degradation", "track_states")

    def __init__(self, battery: Battery, *, track_states: bool = True) -> None:
        self.battery = battery
        self._ecm = battery.electrical
        self._thermal = battery.thermal
        self._degradation = battery.degradation
        self.track_states = track_states

    # -- single step --------------------------------------------------------

    def step(
        self,
        state: BatteryState,
        action: Action,
        dt: float,
        *,
        ambient_c: float | None = None,
        dod_hint: float | None = None,
    ) -> StepResult:
        """Advance one interval. ``dt`` in seconds."""
        if dt <= 0.0:
            raise ValueError("dt must be positive")
        battery = self.battery
        ambient = state.ambient_c if ambient_c is None else ambient_c
        capacity_ah = max(battery.nameplate_capacity_ah * state.soh_capacity, EPS)
        growth = state.degradation.resistance_growth

        # --- resolve the requested action into a current ---------------------
        curtailed = False
        limiting: str | None = None
        if action.power_w is not None:
            current = self._ecm.current_for_power(
                action.power_w,
                soc=state.soc,
                temperature_c=state.temperature_c,
                rc_voltages=state.rc_voltages,
                resistance_growth=growth,
                hysteresis=state.hysteresis,
            )
        elif action.current_a is not None:
            current = action.current_a
        else:
            current = 0.0

        # --- physical saturation at the SOC rails ---------------------------
        max_discharge_i = state.soc * capacity_ah * SECONDS_PER_HOUR / dt
        max_charge_i = (
            (1.0 - state.soc)
            * capacity_ah
            * SECONDS_PER_HOUR
            / (dt * max(battery.envelope.coulombic_efficiency, EPS))
        )
        if current > max_discharge_i:
            current = max_discharge_i
            curtailed, limiting = True, "state_of_charge_empty"
        elif current < -max_charge_i:
            current = -max_charge_i
            curtailed, limiting = True, "state_of_charge_full"

        # --- electrical ------------------------------------------------------
        response = self._ecm.evaluate(
            soc=state.soc,
            current_a=current,
            temperature_c=state.temperature_c,
            rc_voltages=state.rc_voltages,
            resistance_growth=growth,
            hysteresis=state.hysteresis,
        )
        rc_next = self._ecm.step_rc(state.rc_voltages, current, dt, growth)
        hyst_next = self._ecm.step_hysteresis(
            state.hysteresis, current, dt, capacity_ah=capacity_ah
        )

        # --- charge integration ----------------------------------------------
        d_soc = self._ecm.soc_delta(current, dt, capacity_ah=capacity_ah)
        soc_next = clamp(state.soc + d_soc, 0.0, 1.0)

        # --- thermal ----------------------------------------------------------
        thermal = self._thermal.step(
            temperature_c=state.temperature_c,
            heat_generation_w=response.heat_w,
            dt=dt,
            ambient_c=ambient,
            coolant_c=state.coolant_c,
            cooling_fraction=action.cooling_fraction,
            heating_fraction=action.heating_fraction,
        )

        # --- degradation ------------------------------------------------------
        deg_next, increment = self._degradation.step(
            state.degradation,
            dt=dt,
            soc=0.5 * (state.soc + soc_next),
            temperature_c=0.5 * (state.temperature_c + thermal.temperature_c),
            current_a=current,
            nameplate_capacity_ah=battery.nameplate_capacity_ah,
            dod=dod_hint,
        )

        # --- energy accounting -------------------------------------------------
        hours = dt / SECONDS_PER_HOUR
        terminal_wh = response.power_w * hours
        balancing_w = abs(action.balancing_current_a) * response.voltage_v
        aux_w = thermal.parasitic_power_w + balancing_w
        auxiliary_wh = aux_w * hours
        loss_wh = response.loss_w * hours
        net_wh = terminal_wh - auxiliary_wh

        soh_next = deg_next.soh_capacity
        capacity_next = battery.nameplate_capacity_ah * soh_next

        new_state = BatteryState(
            soc=soc_next,
            soh_capacity=soh_next,
            soh_resistance=1.0 + deg_next.resistance_growth,
            capacity_ah=capacity_next,
            resistance_ohm=response.resistance_ohm,
            voltage_v=response.voltage_v,
            current_a=current,
            power_w=response.power_w,
            rc_voltages=rc_next,
            hysteresis=hyst_next,
            temperature_c=thermal.temperature_c,
            temperature_max_c=thermal.temperature_max_c,
            temperature_min_c=thermal.temperature_min_c,
            ambient_c=ambient,
            coolant_c=thermal.coolant_c,
            heat_generation_w=response.heat_w,
            cooling_fraction=clamp(action.cooling_fraction, 0.0, 1.0),
            cell_imbalance_v=state.cell_imbalance_v,
            cell_capacity_spread=state.cell_capacity_spread,
            energy_remaining_wh=battery.energy_between(0.0, soc_next),
            power_limit_charge_w=state.power_limit_charge_w,
            power_limit_discharge_w=state.power_limit_discharge_w,
            degradation=deg_next,
            timestamp=state.timestamp + dt,
            default_provenance=Provenance.SIMULATED,
        )
        require_finite("simulated voltage", new_state.voltage_v)
        require_finite("simulated temperature", new_state.temperature_c)

        return StepResult(
            state=new_state,
            terminal_energy_wh=terminal_wh,
            net_energy_wh=net_wh,
            loss_wh=loss_wh,
            auxiliary_wh=auxiliary_wh,
            degradation=increment,
            curtailed=curtailed,
            limiting=limiting,
            dt=dt,
        )

    # -- multi-step ----------------------------------------------------------

    def simulate(
        self,
        state: BatteryState,
        actions: Sequence[Action],
        dts: Sequence[float] | float,
        *,
        ambient_c: Sequence[float] | float | None = None,
        dod_hint: float | None = None,
    ) -> Trajectory:
        """Roll the plant forward over a sequence of actions.

        ``dts`` may be a scalar (uniform step) or a per-step sequence, which is
        what lets MPC use fine steps near the present and coarse steps far out
        without changing any code here.
        """
        n = len(actions)
        dt_arr = np.full(n, float(dts)) if np.isscalar(dts) else np.asarray(dts, dtype=float)
        if dt_arr.size != n:
            raise ValueError("dts must be scalar or match the number of actions")
        if ambient_c is None:
            amb_arr = np.full(n, state.ambient_c)
        elif np.isscalar(ambient_c):
            amb_arr = np.full(n, float(ambient_c))
        else:
            amb_arr = np.asarray(ambient_c, dtype=float)
            if amb_arr.size != n:
                raise ValueError("ambient_c sequence must match the number of actions")

        m = n + 1
        time_s = np.empty(m)
        soc = np.empty(m)
        voltage = np.empty(m)
        current = np.empty(m)
        power = np.empty(m)
        net_power = np.empty(m)
        temperature = np.empty(m)
        loss = np.empty(m)
        aux = np.empty(m)
        fade = np.empty(m)
        growth = np.empty(m)
        curtailed = np.zeros(m, dtype=bool)
        limiting: list[str | None] = [None] * m
        states: list[BatteryState] = []

        cur = state
        time_s[0] = cur.timestamp
        soc[0] = cur.soc
        voltage[0] = cur.voltage_v
        current[0] = cur.current_a
        power[0] = cur.power_w
        net_power[0] = cur.power_w
        temperature[0] = cur.temperature_c
        loss[0] = 0.0
        aux[0] = 0.0
        fade[0] = cur.degradation.capacity_fade
        growth[0] = cur.degradation.resistance_growth
        if self.track_states:
            states.append(cur)

        for k in range(n):
            res = self.step(
                cur, actions[k], float(dt_arr[k]), ambient_c=float(amb_arr[k]), dod_hint=dod_hint
            )
            cur = res.state
            hours = dt_arr[k] / SECONDS_PER_HOUR
            time_s[k + 1] = cur.timestamp
            soc[k + 1] = cur.soc
            voltage[k + 1] = cur.voltage_v
            current[k + 1] = cur.current_a
            power[k + 1] = cur.power_w
            net_power[k + 1] = res.net_energy_wh / hours if hours > EPS else 0.0
            temperature[k + 1] = cur.temperature_c
            loss[k + 1] = res.loss_wh / hours if hours > EPS else 0.0
            aux[k + 1] = res.auxiliary_wh / hours if hours > EPS else 0.0
            fade[k + 1] = cur.degradation.capacity_fade
            growth[k + 1] = cur.degradation.resistance_growth
            curtailed[k + 1] = res.curtailed
            limiting[k + 1] = res.limiting
            if self.track_states:
                states.append(cur)

        if not self.track_states:
            states = [state, cur]

        return Trajectory(
            time_s=time_s,
            soc=soc,
            voltage_v=voltage,
            current_a=current,
            power_w=power,
            net_power_w=net_power,
            temperature_c=temperature,
            loss_w=loss,
            auxiliary_w=aux,
            capacity_fade=fade,
            resistance_growth=growth,
            states=states,
            curtailed=curtailed,
            limiting=limiting,
        )

    def simulate_constant_power(
        self,
        state: BatteryState,
        power_w: float,
        *,
        duration_s: float,
        dt: float,
        cooling_fraction: float = 0.0,
        ambient_c: float | None = None,
    ) -> Trajectory:
        """Convenience: hold a constant terminal power for a fixed duration."""
        n = max(1, int(round(duration_s / dt)))
        action = Action(power_w=power_w, cooling_fraction=cooling_fraction)
        return self.simulate(state, [action] * n, dt, ambient_c=ambient_c)

    def simulate_profile(
        self,
        state: BatteryState,
        power_profile: Iterable[float],
        dt: float,
        *,
        cooling_fraction: float | Sequence[float] = 0.0,
        ambient_c: Sequence[float] | float | None = None,
    ) -> Trajectory:
        """Simulate a power profile, e.g. a drive cycle or a load trace."""
        profile = list(power_profile)
        if np.isscalar(cooling_fraction):
            cools = [float(cooling_fraction)] * len(profile)
        else:
            cools = list(cooling_fraction)  # type: ignore[arg-type]
            if len(cools) != len(profile):
                raise ValueError("cooling_fraction sequence must match the profile length")
        actions = [Action(power_w=p, cooling_fraction=c) for p, c in zip(profile, cools)]
        return self.simulate(state, actions, dt, ambient_c=ambient_c)


__all__ = ["BatteryPlant", "Action", "StepResult", "Trajectory"]
