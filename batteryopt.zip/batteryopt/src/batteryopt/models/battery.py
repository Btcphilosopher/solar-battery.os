"""The battery abstraction: topology + envelope + history + present state.

This is the object the rest of the platform passes around. It answers
"what is this battery, what is it allowed to do, and what has it been
through", and it derives system-level limits from per-cell data so that no
caller ever has to multiply by a series count by hand.

Specification section 1 requires every battery to expose ``chemistry``,
``nominal_voltage``, ``capacity``, ``maximum_voltage``, ``minimum_voltage``,
``maximum_current``, ``thermal_limits``, ``cycle_history``, ``age`` and
``degradation_state``. All are properties derived from configuration -- none
are hard-coded numbers.
"""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import Any

from ..core.numerics import EPS, clamp
from ..core.provenance import Provenance
from ..core.units import SECONDS_PER_HOUR, SECONDS_PER_YEAR
from .chemistry import ChemistryParameters, OperatingEnvelope
from .degradation import DegradationModel
from .electrical import EquivalentCircuitModel
from .state import BatteryState, DegradationState
from .thermal import LumpedThermalModel
from .topology import Topology


@dataclass(frozen=True, slots=True)
class ThermalLimits:
    """System-level temperature limits, in degrees Celsius."""

    t_max_c: float
    t_min_c: float
    t_min_charge_c: float
    t_max_charge_c: float
    #: Temperature above which the operator wants power derated even though
    #: the cell is still legally within its envelope. Soft, not hard.
    t_derate_c: float = 40.0
    #: Preferred operating band, used by the thermal optimiser as a target.
    t_optimal_low_c: float = 15.0
    t_optimal_high_c: float = 35.0

    def as_dict(self) -> dict[str, float]:
        return {
            "t_max_c": self.t_max_c,
            "t_min_c": self.t_min_c,
            "t_min_charge_c": self.t_min_charge_c,
            "t_max_charge_c": self.t_max_charge_c,
            "t_derate_c": self.t_derate_c,
            "t_optimal_low_c": self.t_optimal_low_c,
            "t_optimal_high_c": self.t_optimal_high_c,
        }


@dataclass(frozen=True, slots=True)
class CycleHistory:
    """What the battery has been through.

    Kept separate from :class:`DegradationState` because history is a *record*
    (auditable, append-only, comes from the database) while degradation state
    is a *model inference* that changes when the model is refitted.
    """

    equivalent_full_cycles: float = 0.0
    throughput_ah: float = 0.0
    energy_charged_wh: float = 0.0
    energy_discharged_wh: float = 0.0
    #: Throughput-weighted mean depth of discharge, from rainflow counting.
    mean_dod: float = 0.0
    #: Time-weighted mean cell temperature over the battery's life, degC.
    mean_temperature_c: float = 25.0
    #: Time-weighted mean SOC over the battery's life.
    mean_soc: float = 0.5
    #: Count of excursions beyond the operating envelope, from the BMS log.
    over_temperature_events: int = 0
    over_voltage_events: int = 0
    under_voltage_events: int = 0
    fast_charge_sessions: int = 0
    #: Seconds spent above 90 % SOC and below 10 % SOC.
    seconds_above_90_soc: float = 0.0
    seconds_below_10_soc: float = 0.0

    @property
    def round_trip_efficiency(self) -> float:
        """Lifetime measured round-trip efficiency; 0.0 if nothing recorded."""
        if self.energy_charged_wh <= EPS:
            return 0.0
        return self.energy_discharged_wh / self.energy_charged_wh

    def as_dict(self) -> dict[str, Any]:
        return {
            "equivalent_full_cycles": self.equivalent_full_cycles,
            "throughput_ah": self.throughput_ah,
            "energy_charged_wh": self.energy_charged_wh,
            "energy_discharged_wh": self.energy_discharged_wh,
            "mean_dod": self.mean_dod,
            "mean_temperature_c": self.mean_temperature_c,
            "mean_soc": self.mean_soc,
            "over_temperature_events": self.over_temperature_events,
            "over_voltage_events": self.over_voltage_events,
            "under_voltage_events": self.under_voltage_events,
            "fast_charge_sessions": self.fast_charge_sessions,
            "seconds_above_90_soc": self.seconds_above_90_soc,
            "seconds_below_10_soc": self.seconds_below_10_soc,
            "round_trip_efficiency": self.round_trip_efficiency,
        }


@dataclass(slots=True)
class Battery:
    """A configured battery system with its models attached."""

    topology: Topology
    #: Identifier used by the persistence layer.
    battery_id: str = "battery-1"
    name: str = ""
    #: Wall-clock age since manufacture, seconds.
    age_s: float = 0.0
    cycle_history: CycleHistory = field(default_factory=CycleHistory)
    degradation_state: DegradationState = field(default_factory=DegradationState)
    #: Optional operator overrides applied on top of the chemistry envelope.
    #: Overrides may only ever make limits *tighter*; see :meth:`envelope`.
    envelope_overrides: dict[str, float] = field(default_factory=dict)
    #: System-level power limits imposed by the inverter, contactors or grid
    #: connection rather than by the cells themselves.
    max_charge_power_w: float | None = None
    max_discharge_power_w: float | None = None

    _ecm: EquivalentCircuitModel | None = field(default=None, init=False, repr=False)
    _thermal: LumpedThermalModel | None = field(default=None, init=False, repr=False)
    _degradation: DegradationModel | None = field(default=None, init=False, repr=False)
    _envelope: OperatingEnvelope | None = field(default=None, init=False, repr=False)

    # -- identity -----------------------------------------------------------

    @property
    def chemistry(self) -> ChemistryParameters:
        return self.topology.chemistry

    @property
    def chemistry_name(self) -> str:
        return self.chemistry.name

    # -- attached models (lazily constructed, then cached) ------------------

    @property
    def electrical(self) -> EquivalentCircuitModel:
        if self._ecm is None:
            self._ecm = EquivalentCircuitModel(self.topology)
        return self._ecm

    @property
    def thermal(self) -> LumpedThermalModel:
        if self._thermal is None:
            self._thermal = LumpedThermalModel(self.topology)
        return self._thermal

    @property
    def degradation(self) -> DegradationModel:
        if self._degradation is None:
            self._degradation = DegradationModel(self.chemistry.degradation)
        return self._degradation

    # -- envelope -----------------------------------------------------------

    @property
    def envelope(self) -> OperatingEnvelope:
        """Effective per-cell envelope after applying operator overrides.

        Overrides are intersected with the chemistry envelope, never unioned:
        an operator can be more conservative than the cell manufacturer but
        never less. An attempt to widen a limit is silently narrowed back,
        because a configuration typo must not be able to raise a safety limit.
        """
        if self._envelope is None:
            base = self.chemistry.envelope
            if not self.envelope_overrides:
                self._envelope = base
            else:
                o = self.envelope_overrides
                self._envelope = OperatingEnvelope(
                    v_max_cell=min(base.v_max_cell, o.get("v_max_cell", base.v_max_cell)),
                    v_min_cell=max(base.v_min_cell, o.get("v_min_cell", base.v_min_cell)),
                    max_charge_c_rate=min(
                        base.max_charge_c_rate, o.get("max_charge_c_rate", base.max_charge_c_rate)
                    ),
                    max_discharge_c_rate=min(
                        base.max_discharge_c_rate,
                        o.get("max_discharge_c_rate", base.max_discharge_c_rate),
                    ),
                    pulse_charge_c_rate=base.pulse_charge_c_rate,
                    pulse_discharge_c_rate=base.pulse_discharge_c_rate,
                    pulse_duration_s=base.pulse_duration_s,
                    t_max_c=min(base.t_max_c, o.get("t_max_c", base.t_max_c)),
                    t_min_c=max(base.t_min_c, o.get("t_min_c", base.t_min_c)),
                    t_min_charge_c=max(
                        base.t_min_charge_c, o.get("t_min_charge_c", base.t_min_charge_c)
                    ),
                    t_max_charge_c=min(
                        base.t_max_charge_c, o.get("t_max_charge_c", base.t_max_charge_c)
                    ),
                    soc_max=min(base.soc_max, o.get("soc_max", base.soc_max)),
                    soc_min=max(base.soc_min, o.get("soc_min", base.soc_min)),
                    coulombic_efficiency=base.coulombic_efficiency,
                )
        return self._envelope

    # -- required section-1 attributes, all derived -------------------------

    @property
    def nominal_voltage(self) -> float:
        """Nominal system voltage, V."""
        return self.topology.nominal_voltage

    @property
    def maximum_voltage(self) -> float:
        """Hard maximum system terminal voltage, V."""
        return self.envelope.v_max_cell * self.topology.n_series

    @property
    def minimum_voltage(self) -> float:
        """Hard minimum system terminal voltage, V."""
        return self.envelope.v_min_cell * self.topology.n_series

    @property
    def nameplate_capacity_ah(self) -> float:
        """Beginning-of-life capacity, Ah."""
        return self.topology.capacity_ah

    @property
    def capacity(self) -> float:
        """Present capacity after ageing, Ah."""
        return self.nameplate_capacity_ah * self.soh_capacity

    @property
    def capacity_ah(self) -> float:
        return self.capacity

    @property
    def nominal_energy_wh(self) -> float:
        return self.topology.nominal_energy_wh

    @property
    def energy_wh(self) -> float:
        """Present full-to-empty energy after ageing, Wh."""
        return self.nominal_energy_wh * self.soh_capacity

    @property
    def maximum_current(self) -> float:
        """Hard maximum continuous discharge current, A (positive)."""
        return self.envelope.max_discharge_c_rate * self.nameplate_capacity_ah

    @property
    def maximum_charge_current(self) -> float:
        """Hard maximum continuous charge current magnitude, A (positive)."""
        return self.envelope.max_charge_c_rate * self.nameplate_capacity_ah

    @property
    def pulse_discharge_current(self) -> float:
        e = self.envelope
        rate = e.pulse_discharge_c_rate or e.max_discharge_c_rate
        return rate * self.nameplate_capacity_ah

    @property
    def pulse_charge_current(self) -> float:
        e = self.envelope
        rate = e.pulse_charge_c_rate or e.max_charge_c_rate
        return rate * self.nameplate_capacity_ah

    @property
    def thermal_limits(self) -> ThermalLimits:
        e = self.envelope
        return ThermalLimits(
            t_max_c=e.t_max_c,
            t_min_c=e.t_min_c,
            t_min_charge_c=e.t_min_charge_c,
            t_max_charge_c=e.t_max_charge_c,
        )

    @property
    def age(self) -> float:
        """Calendar age in seconds."""
        return max(self.age_s, self.degradation_state.age_s)

    @property
    def age_years(self) -> float:
        return self.age / SECONDS_PER_YEAR

    @property
    def soh_capacity(self) -> float:
        return self.degradation_state.soh_capacity

    @property
    def soh_resistance(self) -> float:
        """Resistance SOH expressed as R0/R_new (>= 1 means degraded)."""
        return 1.0 + self.degradation_state.resistance_growth

    # -- convenience --------------------------------------------------------

    def resistance_now(self, *, soc: float, temperature_c: float, charging: bool = False) -> float:
        return self.electrical.resistance(
            soc=soc,
            temperature_c=temperature_c,
            resistance_growth=self.degradation_state.resistance_growth,
            charging=charging,
        )

    def initial_state(
        self,
        *,
        soc: float = 0.5,
        temperature_c: float = 25.0,
        ambient_c: float | None = None,
        timestamp: float = 0.0,
        provenance: Provenance = Provenance.SIMULATED,
    ) -> BatteryState:
        """Build a consistent starting state for simulation or testing."""
        soc = clamp(soc, 0.0, 1.0)
        ecm = self.electrical
        capacity = self.capacity
        ocv = float(ecm.ocv(soc))
        amb = temperature_c if ambient_c is None else ambient_c
        return BatteryState(
            soc=soc,
            soh_capacity=self.soh_capacity,
            soh_resistance=self.soh_resistance,
            capacity_ah=capacity,
            resistance_ohm=self.resistance_now(soc=soc, temperature_c=temperature_c),
            voltage_v=ocv,
            current_a=0.0,
            power_w=0.0,
            rc_voltages=(0.0,) * ecm.n_rc,
            hysteresis=0.0,
            temperature_c=temperature_c,
            temperature_max_c=temperature_c,
            temperature_min_c=temperature_c,
            ambient_c=amb,
            coolant_c=amb,
            energy_remaining_wh=self.energy_between(0.0, soc),
            degradation=self.degradation_state,
            timestamp=timestamp,
            default_provenance=provenance,
        )

    def energy_between(self, soc_lo: float, soc_hi: float, n: int = 129) -> float:
        """Energy in Wh stored between two SOC points, integrating the OCV curve."""
        import numpy as np

        lo, hi = sorted((clamp(soc_lo, 0.0, 1.0), clamp(soc_hi, 0.0, 1.0)))
        if hi - lo < EPS:
            return 0.0
        grid = np.linspace(lo, hi, n)
        v = np.asarray(self.chemistry.ocv.voltage_at(grid), dtype=float) * self.topology.n_series
        return float(np.trapezoid(v, grid) * self.capacity)

    def soc_for_energy(self, energy_wh: float, *, from_soc: float = 0.0) -> float:
        """SOC that stores ``energy_wh`` more than ``from_soc``."""
        from ..core.numerics import invert_monotone

        return invert_monotone(
            lambda s: self.energy_between(from_soc, s), energy_wh, from_soc, 1.0, tol=1e-6
        )

    def with_degradation(self, degradation: DegradationState) -> "Battery":
        """Return a copy carrying an updated degradation state."""
        return replace(self, degradation_state=degradation)

    def describe(self) -> dict[str, Any]:
        return {
            "battery_id": self.battery_id,
            "name": self.name or self.battery_id,
            "chemistry": self.chemistry_name,
            "topology": self.topology.describe(),
            "nominal_voltage_v": round(self.nominal_voltage, 2),
            "maximum_voltage_v": round(self.maximum_voltage, 2),
            "minimum_voltage_v": round(self.minimum_voltage, 2),
            "nameplate_capacity_ah": round(self.nameplate_capacity_ah, 2),
            "present_capacity_ah": round(self.capacity, 2),
            "nominal_energy_kwh": round(self.nominal_energy_wh / 1000.0, 3),
            "present_energy_kwh": round(self.energy_wh / 1000.0, 3),
            "maximum_discharge_current_a": round(self.maximum_current, 1),
            "maximum_charge_current_a": round(self.maximum_charge_current, 1),
            "max_discharge_power_w": self.max_discharge_power_w,
            "max_charge_power_w": self.max_charge_power_w,
            "thermal_limits": self.thermal_limits.as_dict(),
            "age_years": round(self.age_years, 3),
            "soh_capacity": round(self.soh_capacity, 5),
            "soh_resistance": round(self.soh_resistance, 5),
            "cycle_history": self.cycle_history.as_dict(),
            "degradation_state": self.degradation_state.as_dict(),
        }

    # -- factory helpers ----------------------------------------------------

    @classmethod
    def build(
        cls,
        *,
        chemistry: str = "lithium_ion_generic",
        cells_series: int = 1,
        cells_parallel: int = 1,
        modules_series: int = 1,
        modules_parallel: int = 1,
        packs_series: int = 1,
        packs_parallel: int = 1,
        cell_capacity_ah: float | None = None,
        **kwargs: Any,
    ) -> "Battery":
        topology = Topology.build(
            chemistry=chemistry,
            cells_series=cells_series,
            cells_parallel=cells_parallel,
            modules_series=modules_series,
            modules_parallel=modules_parallel,
            packs_series=packs_series,
            packs_parallel=packs_parallel,
            cell_capacity_ah=cell_capacity_ah,
        )
        return cls(topology=topology, **kwargs)

    @classmethod
    def aged(
        cls,
        battery: "Battery",
        *,
        years: float,
        equivalent_full_cycles: float,
        mean_soc: float = 0.5,
        mean_temperature_c: float = 25.0,
    ) -> "Battery":
        """Construct an aged copy of a battery, for what-if and test fixtures.

        The stress-weighted accumulators are back-computed from the stated
        mean conditions, so an "eight-year-old pack that lived at 35 degC and
        80 % SOC" is a legitimate, self-consistent object rather than a
        hand-set SOH number with no history behind it.
        """
        model = DegradationModel(battery.chemistry.degradation)
        s_cal = model.calendar_stress(soc=mean_soc, temperature_c=mean_temperature_c)
        s_cyc = model.cycle_stress(
            c_rate=0.5, temperature_c=mean_temperature_c, dod=0.6, charging=False
        )
        t_eq = years * s_cal
        a_eq = equivalent_full_cycles * s_cyc
        deg = DegradationState(
            t_eq_years=t_eq,
            a_eq_efc=a_eq,
            throughput_ah=equivalent_full_cycles * 2.0 * battery.nameplate_capacity_ah,
            equivalent_full_cycles=equivalent_full_cycles,
            age_s=years * SECONDS_PER_YEAR,
            capacity_fade=model.fade(t_eq, a_eq),
            resistance_growth=model.growth(t_eq, a_eq),
        )
        history = CycleHistory(
            equivalent_full_cycles=equivalent_full_cycles,
            throughput_ah=deg.throughput_ah,
            energy_charged_wh=deg.throughput_ah * battery.nominal_voltage / 2.0,
            energy_discharged_wh=deg.throughput_ah * battery.nominal_voltage / 2.0 * 0.95,
            mean_dod=0.6,
            mean_temperature_c=mean_temperature_c,
            mean_soc=mean_soc,
        )
        return replace(
            battery,
            age_s=years * SECONDS_PER_YEAR,
            degradation_state=deg,
            cycle_history=history,
        )


def hours(seconds: float) -> float:
    return seconds / SECONDS_PER_HOUR


__all__ = ["Battery", "CycleHistory", "ThermalLimits"]
