"""Cell -> module -> pack -> system topology and electrical scaling.

The optimiser works in pack (or system) engineering units -- volts, amperes,
watts -- but every physical parameter is defined per cell. This module is the
single place where the scaling between those two worlds happens, so a
misplaced factor of ``n_series`` has exactly one place to hide.

Scaling rules for ``S`` cells in series and ``P`` in parallel:

.. code-block:: text

    voltage      = S * v_cell
    current      = P * i_cell
    capacity_Ah  = P * q_cell
    resistance   = (S / P) * r_cell
    heat_capacity= S * P * c_cell
    conductance  = S * P * k_cell     (each cell has its own cooling path)

Real packs are not ideal: interconnect resistance, current-sharing imbalance
between parallel strings and non-uniform cooling all cost a few percent.
Rather than pretend otherwise, the topology carries explicit *derating*
factors, defaulting to mildly pessimistic values, and documents them.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field, model_validator

from ..core.exceptions import TopologyError
from .chemistry import ChemistryParameters, get_chemistry


class CellSpec(BaseModel):
    """One physical cell.

    ``capacity_ah`` defaults to the chemistry's reference capacity but may be
    overridden, which is how a 2170 and a 4680 built on the same chemistry are
    represented without duplicating the chemistry file.
    """

    model_config = ConfigDict(frozen=True)

    chemistry: str = "lithium_ion_generic"
    capacity_ah: float | None = Field(None, gt=0)
    #: Manufacturing spread in capacity, 1-sigma as a fraction. Drives the
    #: synthetic cell-imbalance model in the virtual pack.
    capacity_sigma: float = Field(0.015, ge=0, lt=0.5)
    #: Manufacturing spread in series resistance, 1-sigma as a fraction.
    resistance_sigma: float = Field(0.05, ge=0, lt=0.5)
    label: str = ""

    def resolve(self) -> ChemistryParameters:
        return get_chemistry(self.chemistry)

    @property
    def effective_capacity_ah(self) -> float:
        return self.capacity_ah if self.capacity_ah is not None else self.resolve().nominal_capacity_ah


class ModuleSpec(BaseModel):
    """A group of cells wired ``cells_series`` x ``cells_parallel``."""

    model_config = ConfigDict(frozen=True)

    cell: CellSpec = Field(default_factory=CellSpec)
    cells_series: int = Field(1, ge=1)
    cells_parallel: int = Field(1, ge=1)
    #: Ohmic resistance of busbars and welds inside the module, ohms.
    interconnect_resistance_ohm: float = Field(0.0, ge=0)
    label: str = ""

    @property
    def cell_count(self) -> int:
        return self.cells_series * self.cells_parallel


class PackSpec(BaseModel):
    """A group of modules wired ``modules_series`` x ``modules_parallel``."""

    model_config = ConfigDict(frozen=True)

    module: ModuleSpec = Field(default_factory=ModuleSpec)
    modules_series: int = Field(1, ge=1)
    modules_parallel: int = Field(1, ge=1)
    interconnect_resistance_ohm: float = Field(0.0, ge=0)
    label: str = ""

    @property
    def module_count(self) -> int:
        return self.modules_series * self.modules_parallel


class SystemSpec(BaseModel):
    """One or more packs forming the optimisable system."""

    model_config = ConfigDict(frozen=True)

    pack: PackSpec = Field(default_factory=PackSpec)
    packs_series: int = Field(1, ge=1)
    packs_parallel: int = Field(1, ge=1)
    label: str = ""

    @property
    def pack_count(self) -> int:
        return self.packs_series * self.packs_parallel


class Topology(BaseModel):
    """Complete electrical topology with derived pack-level scaling factors."""

    model_config = ConfigDict(frozen=True)

    system: SystemSpec = Field(default_factory=SystemSpec)

    #: Fraction of nameplate current the weakest parallel string actually
    #: carries at balance. 1.0 means perfect current sharing.
    parallel_sharing_efficiency: float = Field(0.97, gt=0, le=1.0)
    #: Fraction of nameplate cooling conductance realised in the built pack.
    cooling_effectiveness: float = Field(0.85, gt=0, le=1.0)
    #: Total interconnect/contactor/fuse resistance outside the modules, ohms.
    system_resistance_ohm: float = Field(0.0, ge=0)

    # -- counts -------------------------------------------------------------

    @property
    def n_series(self) -> int:
        """Total cells in series across the whole system."""
        s = self.system
        return s.packs_series * s.pack.modules_series * s.pack.module.cells_series

    @property
    def n_parallel(self) -> int:
        """Total cells in parallel across the whole system."""
        s = self.system
        return s.packs_parallel * s.pack.modules_parallel * s.pack.module.cells_parallel

    @property
    def cell_count(self) -> int:
        return self.n_series * self.n_parallel

    @property
    def module_count(self) -> int:
        return self.system.pack_count * self.system.pack.module_count

    @property
    def pack_count(self) -> int:
        return self.system.pack_count

    @property
    def cell(self) -> CellSpec:
        return self.system.pack.module.cell

    @property
    def chemistry(self) -> ChemistryParameters:
        return self.cell.resolve()

    # -- electrical scaling -------------------------------------------------

    @property
    def capacity_ah(self) -> float:
        """Nameplate system capacity in ampere-hours at beginning of life."""
        return self.cell.effective_capacity_ah * self.n_parallel * self.parallel_sharing_efficiency

    def voltage_from_cell(self, v_cell: float) -> float:
        return v_cell * self.n_series

    def cell_voltage_from_system(self, v_system: float) -> float:
        return v_system / self.n_series

    def current_from_cell(self, i_cell: float) -> float:
        return i_cell * self.n_parallel * self.parallel_sharing_efficiency

    def cell_current_from_system(self, i_system: float) -> float:
        return i_system / (self.n_parallel * self.parallel_sharing_efficiency)

    def resistance_from_cell(self, r_cell: float) -> float:
        """System series resistance including interconnect contributions."""
        mod = self.system.pack.module
        pack = self.system.pack
        r_module = (
            r_cell * mod.cells_series / mod.cells_parallel + mod.interconnect_resistance_ohm
        )
        r_pack = (
            r_module * pack.modules_series / pack.modules_parallel
            + pack.interconnect_resistance_ohm
        )
        r_system = (
            r_pack * self.system.packs_series / self.system.packs_parallel
            + self.system_resistance_ohm
        )
        return r_system

    @property
    def heat_capacity_j_k(self) -> float:
        """System thermal mass in J/K."""
        return self.chemistry.thermal.heat_capacity_j_k * self.cell_count

    @property
    def passive_conductance_w_k(self) -> float:
        return (
            self.chemistry.thermal.passive_conductance_w_k
            * self.cell_count
            * self.cooling_effectiveness
        )

    @property
    def active_conductance_w_k(self) -> float:
        return (
            self.chemistry.thermal.active_conductance_w_k
            * self.cell_count
            * self.cooling_effectiveness
        )

    @property
    def cooling_power_w(self) -> float:
        """Parasitic electrical power at 100 % cooling effort, W."""
        return self.chemistry.thermal.cooling_power_w * self.cell_count

    @property
    def heating_power_w(self) -> float:
        return self.chemistry.thermal.heating_power_w * self.cell_count

    @property
    def nominal_voltage(self) -> float:
        return self.chemistry.nominal_voltage_cell * self.n_series

    @property
    def nominal_energy_wh(self) -> float:
        """Beginning-of-life usable energy, integrated over the OCV curve."""
        return (
            self.chemistry.energy_wh_cell()
            / self.chemistry.nominal_capacity_ah
            * self.cell.effective_capacity_ah
            * self.n_parallel
            * self.n_series
            * self.parallel_sharing_efficiency
        )

    # -- construction helpers ----------------------------------------------

    @classmethod
    def build(
        cls,
        *,
        chemistry: str = "lithium_ion_generic",
        cells_series: int = 1,
        cells_parallel: int = 1,
        modules_series: int = 1,
        modules_parallel: int = 1,
        packs_series: int = 1,
        packs_parallel: int = 1,
        cell_capacity_ah: float | None = None,
        **kwargs: Any,
    ) -> "Topology":
        """Convenience constructor for the common flat-hierarchy case."""
        cell = CellSpec(chemistry=chemistry, capacity_ah=cell_capacity_ah)
        module = ModuleSpec(
            cell=cell, cells_series=cells_series, cells_parallel=cells_parallel
        )
        pack = PackSpec(
            module=module, modules_series=modules_series, modules_parallel=modules_parallel
        )
        system = SystemSpec(
            pack=pack, packs_series=packs_series, packs_parallel=packs_parallel
        )
        return cls(system=system, **kwargs)

    @classmethod
    def sized_for(
        cls,
        *,
        chemistry: str,
        target_energy_kwh: float,
        target_voltage: float,
        cell_capacity_ah: float | None = None,
        **kwargs: Any,
    ) -> "Topology":
        """Size a topology to hit an energy and voltage target.

        Series count is chosen from the voltage target and parallel count from
        the energy target, then both are rounded up so the built system meets
        or exceeds the request. Useful for sweeps over system size.
        """
        chem = get_chemistry(chemistry)
        q_cell = cell_capacity_ah or chem.nominal_capacity_ah
        n_series = max(1, round(target_voltage / chem.nominal_voltage_cell))
        wh_per_cell = chem.energy_wh_cell() / chem.nominal_capacity_ah * q_cell
        n_parallel = max(1, int(-(-target_energy_kwh * 1000.0 // (wh_per_cell * n_series))))
        return cls.build(
            chemistry=chemistry,
            cells_series=n_series,
            cells_parallel=n_parallel,
            cell_capacity_ah=cell_capacity_ah,
            **kwargs,
        )

    @model_validator(mode="after")
    def _sanity(self) -> "Topology":
        # Resolve the chemistry eagerly. Deferring it means an unknown name
        # surfaces much later, from whichever property happens to touch it
        # first -- typically deep inside a request handler that has already
        # decided the configuration was fine.
        self.chemistry  # noqa: B018 - raises ChemistryNotFound if unknown
        if self.cell_count > 5_000_000:
            raise TopologyError(
                f"topology declares {self.cell_count} cells; this is almost certainly "
                "a units error in the series/parallel counts"
            )
        return self

    def describe(self) -> dict[str, Any]:
        return {
            "chemistry": self.chemistry.name,
            "cells": self.cell_count,
            "modules": self.module_count,
            "packs": self.pack_count,
            "series": self.n_series,
            "parallel": self.n_parallel,
            "nominal_voltage_v": round(self.nominal_voltage, 2),
            "capacity_ah": round(self.capacity_ah, 2),
            "nominal_energy_kwh": round(self.nominal_energy_wh / 1000.0, 3),
        }


__all__ = ["CellSpec", "ModuleSpec", "PackSpec", "SystemSpec", "Topology"]
