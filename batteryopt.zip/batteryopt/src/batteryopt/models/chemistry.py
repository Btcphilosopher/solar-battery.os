"""Configurable cell chemistry parameters and registry.

Nothing about a specific cell is hard-coded into the engine. A chemistry is a
*data object*: open-circuit-voltage curve, resistance and its temperature
dependence, thermal properties, degradation coefficients and the manufacturer
operating envelope. Chemistries ship as JSON in ``batteryopt/data/chemistries``
and can be registered, overridden or synthesised at runtime.

The built-in parameter sets are **representative literature values for a class
of chemistry, not a datasheet for any particular product**. They exist so that
the platform is runnable and testable without hardware. Any deployment against
real cells must supply a fitted chemistry file; see ``docs/chemistry.md``.
"""

from __future__ import annotations

import json
from functools import cached_property
from importlib import resources
from typing import Any, Iterable, Literal

import numpy as np
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from ..core.exceptions import ChemistryNotFound, ConfigurationError
from ..core.numerics import invert_monotone
from ..core.units import GAS_CONSTANT, KELVIN_OFFSET, celsius_to_kelvin

ChemistryFamily = Literal[
    "lithium_ion",
    "lfp",
    "nmc",
    "nca",
    "lco",
    "lto",
    "sodium_ion",
    "lead_acid",
    "flow",
    "other",
]


class OCVCurve(BaseModel):
    """Open-circuit voltage as a function of state of charge.

    Stored as a sampled curve rather than an analytic fit because real OCV
    curves -- particularly LFP, which is almost flat between 20 % and 80 % --
    are not well represented by low-order polynomials, and because a table is
    what a cell characterisation lab actually produces.
    """

    model_config = ConfigDict(frozen=True)

    soc: list[float] = Field(..., description="Strictly increasing SOC grid in [0, 1]")
    voltage: list[float] = Field(..., description="Cell OCV in volts at each SOC point")
    #: Entropic coefficient dU/dT in V/K, optionally SOC-dependent. A single
    #: value is broadcast across the grid. Drives reversible heat generation.
    dudt: list[float] | float = 0.0
    #: Charge/discharge hysteresis half-width in volts, applied as +/- offset.
    hysteresis_v: float = 0.0

    @field_validator("soc")
    @classmethod
    def _soc_monotone(cls, v: list[float]) -> list[float]:
        if len(v) < 2:
            raise ValueError("OCV curve needs at least two points")
        if any(b <= a for a, b in zip(v, v[1:])):
            raise ValueError("OCV soc grid must be strictly increasing")
        if v[0] < -1e-9 or v[-1] > 1.0 + 1e-9:
            raise ValueError("OCV soc grid must lie within [0, 1]")
        return v

    @model_validator(mode="after")
    def _same_length(self) -> "OCVCurve":
        if len(self.soc) != len(self.voltage):
            raise ValueError("OCV soc and voltage arrays must be the same length")
        if isinstance(self.dudt, list) and len(self.dudt) != len(self.soc):
            raise ValueError("OCV dudt array must match the soc grid length")
        if any(b < a - 1e-6 for a, b in zip(self.voltage, self.voltage[1:])):
            raise ValueError("OCV must be non-decreasing in SOC")
        return self

    @cached_property
    def _soc_arr(self) -> np.ndarray:
        return np.asarray(self.soc, dtype=float)

    @cached_property
    def _v_arr(self) -> np.ndarray:
        return np.asarray(self.voltage, dtype=float)

    @cached_property
    def _dudt_arr(self) -> np.ndarray:
        if isinstance(self.dudt, list):
            return np.asarray(self.dudt, dtype=float)
        return np.full_like(self._soc_arr, float(self.dudt))

    def voltage_at(self, soc: float | np.ndarray) -> float | np.ndarray:
        """OCV in volts; clamped outside the tabulated SOC range."""
        return np.interp(soc, self._soc_arr, self._v_arr)

    def dudt_at(self, soc: float | np.ndarray) -> float | np.ndarray:
        """Entropic coefficient dU/dT in V/K."""
        return np.interp(soc, self._soc_arr, self._dudt_arr)

    def soc_at(self, voltage: float) -> float:
        """Invert the curve: SOC for a given OCV.

        Bisection is used rather than ``np.interp`` on the inverse because a
        flat plateau makes the inverse ill-conditioned; bisection at least
        returns the mid-point of the plateau deterministically.
        """
        return invert_monotone(lambda s: float(self.voltage_at(s)), voltage, 0.0, 1.0)

    def slope_at(self, soc: float) -> float:
        """dOCV/dSOC in V per unit SOC -- the EKF's observation sensitivity.

        Near-zero slope is exactly the LFP problem: voltage carries almost no
        SOC information mid-range, so the filter must lean on coulomb counting.
        """
        s = float(np.clip(soc, 0.0, 1.0))
        h = 1e-3
        lo = max(0.0, s - h)
        hi = min(1.0, s + h)
        if hi <= lo:
            return 0.0
        return float((self.voltage_at(hi) - self.voltage_at(lo)) / (hi - lo))

    @property
    def v_min(self) -> float:
        return float(self._v_arr[0])

    @property
    def v_max(self) -> float:
        return float(self._v_arr[-1])


class ResistanceModel(BaseModel):
    """Series resistance and its dependence on temperature, SOC and age.

    ``R0(T, soc, soh) = r0_ref * arrhenius(T) * shape(soc) * age(soh)``

    The Arrhenius term uses an activation energy for charge transfer, which is
    why cold cells are both less powerful and more damaged by fast charging.
    """

    model_config = ConfigDict(frozen=True)

    #: Ohmic + charge-transfer resistance of one cell at reference conditions.
    r0_ref_ohm: float = Field(..., gt=0)
    #: Reference temperature for ``r0_ref_ohm``, in degrees Celsius.
    t_ref_c: float = 25.0
    #: Activation energy for the resistance Arrhenius term, J/mol.
    activation_energy_j_mol: float = Field(20000.0, ge=0)
    #: Multiplicative resistance shape versus SOC, sampled on ``soc_grid``.
    soc_grid: list[float] = Field(default_factory=lambda: [0.0, 0.1, 0.5, 0.9, 1.0])
    soc_shape: list[float] = Field(default_factory=lambda: [1.6, 1.15, 1.0, 1.1, 1.35])
    #: Additional resistance multiplier when charging (asymmetric kinetics).
    charge_multiplier: float = Field(1.0, gt=0)
    #: RC branches modelling diffusion: (resistance ohm, time constant s).
    rc_pairs: list[tuple[float, float]] = Field(default_factory=list)

    @model_validator(mode="after")
    def _check(self) -> "ResistanceModel":
        if len(self.soc_grid) != len(self.soc_shape):
            raise ValueError("resistance soc_grid and soc_shape must be the same length")
        if any(b <= a for a, b in zip(self.soc_grid, self.soc_grid[1:])):
            raise ValueError("resistance soc_grid must be strictly increasing")
        if any(r <= 0 or tau <= 0 for r, tau in self.rc_pairs):
            raise ValueError("RC pair resistances and time constants must be positive")
        return self

    @cached_property
    def _soc_grid_arr(self) -> np.ndarray:
        return np.asarray(self.soc_grid, dtype=float)

    @cached_property
    def _soc_shape_arr(self) -> np.ndarray:
        return np.asarray(self.soc_shape, dtype=float)

    def temperature_factor(self, temperature_c: float | np.ndarray) -> float | np.ndarray:
        """Arrhenius multiplier; >1 below the reference temperature."""
        t_k = np.asarray(temperature_c, dtype=float) + KELVIN_OFFSET
        t_ref_k = celsius_to_kelvin(self.t_ref_c)
        t_k = np.maximum(t_k, 200.0)  # guard against nonsense telemetry
        return np.exp(self.activation_energy_j_mol / GAS_CONSTANT * (1.0 / t_k - 1.0 / t_ref_k))

    def soc_factor(self, soc: float | np.ndarray) -> float | np.ndarray:
        return np.interp(soc, self._soc_grid_arr, self._soc_shape_arr)

    def r0(
        self,
        *,
        temperature_c: float,
        soc: float,
        resistance_growth: float = 0.0,
        charging: bool = False,
    ) -> float:
        """Cell series resistance in ohms.

        ``resistance_growth`` is the fractional increase from ageing, e.g.
        ``0.4`` for a cell whose resistance has risen 40 % from beginning of
        life.
        """
        r = (
            self.r0_ref_ohm
            * float(self.temperature_factor(temperature_c))
            * float(self.soc_factor(soc))
            * (1.0 + max(resistance_growth, -0.99))
        )
        if charging:
            r *= self.charge_multiplier
        return r


class ThermalProperties(BaseModel):
    """Per-cell thermal properties, scaled to pack level by the topology."""

    model_config = ConfigDict(frozen=True)

    #: Specific heat capacity of the cell, J/(kg*K).
    specific_heat_j_kg_k: float = Field(1000.0, gt=0)
    #: Cell mass, kg.
    mass_kg: float = Field(..., gt=0)
    #: Passive (no active cooling) conductance from cell to ambient, W/K.
    passive_conductance_w_k: float = Field(0.15, gt=0)
    #: Additional conductance available at 100 % active cooling, W/K.
    active_conductance_w_k: float = Field(1.2, ge=0)
    #: Electrical parasitic power at 100 % cooling effort, W per cell.
    cooling_power_w: float = Field(0.6, ge=0)
    #: Exponent linking cooling effort to parasitic power. Pumps and fans
    #: follow affinity laws, so power grows roughly with the cube of flow.
    cooling_power_exponent: float = Field(3.0, ge=1.0)
    #: Heating power available for cold-weather preconditioning, W per cell.
    heating_power_w: float = Field(1.0, ge=0)
    #: Heater efficiency (fraction of electrical input reaching the cell).
    heating_efficiency: float = Field(0.95, gt=0, le=1.0)

    @property
    def heat_capacity_j_k(self) -> float:
        """Cell thermal mass, J/K."""
        return self.specific_heat_j_kg_k * self.mass_kg


class DegradationCoefficients(BaseModel):
    """Semi-empirical ageing coefficients.

    The formulation is the standard two-mechanism, stress-weighted power law
    used across the ageing literature (Wang, Schmalstieg, Naumann and others):

    .. code-block:: text

        capacity_fade = a_cal * ((t_eq + t0) ** z_cal - t0 ** z_cal)
                      + a_cyc * ((A_eq + A0) ** z_cyc - A0 ** z_cyc)

    with the same form for resistance growth using ``b``, ``y``.

    where ``t_eq`` is stress-weighted time in years and ``A_eq`` is
    stress-weighted throughput in equivalent full cycles. Weighting each
    increment by its instantaneous stress and accumulating makes the model
    path-dependent in the ways that matter (hot storage at high SOC, cold fast
    charging) while keeping it cheap enough to evaluate inside an optimiser
    loop thousands of times per second.

    Sub-linear exponents (``z < 1``) reproduce the observed slowing of SEI
    growth: the marginal cost of a cycle falls as the cell ages, which the
    optimiser correctly exploits.

    The ``t0``/``A0`` offsets (:attr:`formation_years`, :attr:`formation_efc`)
    matter more than they look. A bare power law has infinite marginal damage
    at zero age, so a brand-new pack would appear to lose a large fraction of
    its life on its very first cycle and the optimiser would refuse to use it.
    Physically, the cell has already been through factory formation cycling and
    its nameplate capacity is measured *after* that, so the curve should be
    entered part-way along. The offsets do exactly that, and the subtraction of
    the baseline keeps ``fade(0) = 0`` so SOH still starts at 100 %.

    With the shipped values a new cell degrades roughly five times faster per
    equivalent full cycle than a mid-life one -- steep, but in line with
    measured incremental-capacity data, and far short of the twenty-fold
    artefact an unoffset power law produces.
    """

    model_config = ConfigDict(frozen=True)

    # --- capacity fade -----------------------------------------------------
    a_calendar: float = Field(0.0262, ge=0, description="Fade coefficient, per year^z")
    z_calendar: float = Field(0.75, gt=0, le=1.0)
    a_cycle: float = Field(0.00365, ge=0, description="Fade coefficient, per EFC^z")
    z_cycle: float = Field(0.5, gt=0, le=1.0)

    # --- resistance growth -------------------------------------------------
    b_calendar: float = Field(0.050, ge=0)
    y_calendar: float = Field(0.75, gt=0, le=1.0)
    b_cycle: float = Field(0.0091, ge=0)
    y_cycle: float = Field(0.5, gt=0, le=1.0)

    # --- calendar stress ---------------------------------------------------
    #: Activation energy for calendar ageing, J/mol. ~50 kJ/mol doubles the
    #: rate per 10 K near room temperature.
    ea_calendar_j_mol: float = Field(50000.0, ge=0)
    t_ref_c: float = 25.0
    #: Exponential SOC sensitivity of calendar ageing.
    soc_stress_gain: float = Field(1.4, ge=0)
    soc_stress_ref: float = Field(0.5, ge=0, le=1.0)
    #: Extra calendar stress at very low SOC (anode potential excursions).
    low_soc_threshold: float = Field(0.10, ge=0, le=1.0)
    low_soc_gain: float = Field(6.0, ge=0)

    # --- cycle stress ------------------------------------------------------
    ea_cycle_j_mol: float = Field(30000.0, ge=0)
    #: Exponential sensitivity to depth of discharge, relative to the ref DOD.
    dod_stress_gain: float = Field(0.9, ge=0)
    dod_stress_ref: float = Field(0.6, gt=0, le=1.0)
    #: Exponential sensitivity to C-rate, relative to the reference rate.
    c_rate_stress_gain: float = Field(0.55, ge=0)
    c_rate_stress_ref: float = Field(0.5, gt=0)
    #: Charging is harder on the cell than discharging at the same rate.
    charge_stress_multiplier: float = Field(1.35, ge=1.0)

    # --- lithium plating (low-temperature charging) ------------------------
    #: Below this temperature, charging incurs a rapidly growing plating
    #: penalty. This is the single most important asymmetry for an optimiser:
    #: it is what makes "precondition, then charge" the right answer in winter.
    plating_threshold_c: float = Field(12.0)
    plating_gain: float = Field(0.28, ge=0, description="Per K below threshold, per C")
    plating_max_multiplier: float = Field(25.0, ge=1.0)

    # --- high-temperature acceleration beyond Arrhenius --------------------
    #: Above this temperature, additional decomposition mechanisms switch on.
    high_temp_threshold_c: float = Field(45.0)
    high_temp_gain: float = Field(0.09, ge=0, description="Per K above threshold")

    # --- power-law offsets (see the class docstring) -----------------------
    #: Equivalent full cycles of factory formation already embodied in the
    #: nameplate capacity.
    formation_efc: float = Field(100.0, gt=0)
    #: Equivalent calendar years already embodied in the nameplate capacity.
    formation_years: float = Field(0.5, gt=0)

    #: Capacity fraction at which the cell is considered end-of-life.
    end_of_life_soh: float = Field(0.80, gt=0, lt=1.0)


class OperatingEnvelope(BaseModel):
    """Manufacturer operating envelope for one cell.

    These are the numbers that become **hard constraints**. Everything in this
    class is a limit that the optimiser must never propose crossing; the
    objective function has no authority over them.
    """

    model_config = ConfigDict(frozen=True)

    v_max_cell: float = Field(..., gt=0)
    v_min_cell: float = Field(..., gt=0)
    #: Continuous charge/discharge C-rate limits (positive magnitudes).
    max_charge_c_rate: float = Field(..., gt=0)
    max_discharge_c_rate: float = Field(..., gt=0)
    #: Short-duration pulse limits and the window over which they apply.
    pulse_charge_c_rate: float | None = None
    pulse_discharge_c_rate: float | None = None
    pulse_duration_s: float = Field(10.0, gt=0)
    #: Absolute temperature limits for operation.
    t_max_c: float = Field(..., gt=-273.15)
    t_min_c: float = Field(..., gt=-273.15)
    #: Charging is usually forbidden below a higher temperature than discharge.
    t_min_charge_c: float = Field(0.0)
    t_max_charge_c: float = Field(45.0)
    #: Recommended SOC window for normal operation (soft-limited by default).
    soc_max: float = Field(1.0, gt=0, le=1.0)
    soc_min: float = Field(0.0, ge=0, lt=1.0)
    #: Coulombic efficiency, used for round-trip energy accounting.
    coulombic_efficiency: float = Field(0.995, gt=0, le=1.0)

    @model_validator(mode="after")
    def _ordering(self) -> "OperatingEnvelope":
        if self.v_min_cell >= self.v_max_cell:
            raise ValueError("v_min_cell must be below v_max_cell")
        if self.t_min_c >= self.t_max_c:
            raise ValueError("t_min_c must be below t_max_c")
        if self.soc_min >= self.soc_max:
            raise ValueError("soc_min must be below soc_max")
        if self.t_min_charge_c < self.t_min_c:
            raise ValueError("t_min_charge_c cannot be below the absolute t_min_c")
        if self.t_max_charge_c > self.t_max_c:
            raise ValueError("t_max_charge_c cannot exceed the absolute t_max_c")
        return self


class ChemistryParameters(BaseModel):
    """A complete, self-contained description of one cell chemistry."""

    model_config = ConfigDict(frozen=True)

    name: str
    family: ChemistryFamily = "other"
    description: str = ""
    #: Provenance of the parameter set itself: where these numbers came from.
    parameter_source: str = "representative literature values (not a datasheet)"
    version: str = "1"

    nominal_voltage_cell: float = Field(..., gt=0)
    nominal_capacity_ah: float = Field(..., gt=0, description="Reference cell capacity")

    ocv: OCVCurve
    resistance: ResistanceModel
    thermal: ThermalProperties
    degradation: DegradationCoefficients = Field(default_factory=DegradationCoefficients)
    envelope: OperatingEnvelope

    @model_validator(mode="after")
    def _consistency(self) -> "ChemistryParameters":
        if self.envelope.v_max_cell < self.ocv.v_max - 1e-6:
            raise ValueError(
                f"chemistry {self.name!r}: envelope v_max_cell "
                f"({self.envelope.v_max_cell}) is below the top of the OCV curve "
                f"({self.ocv.v_max}); the cell could never reach 100 % SOC"
            )
        if self.envelope.v_min_cell > self.ocv.v_min + 1e-6:
            raise ValueError(
                f"chemistry {self.name!r}: envelope v_min_cell is above the bottom "
                "of the OCV curve"
            )
        return self

    # -- convenience --------------------------------------------------------

    def ocv_at(self, soc: float | np.ndarray) -> float | np.ndarray:
        return self.ocv.voltage_at(soc)

    def energy_wh_cell(self, soc_lo: float = 0.0, soc_hi: float = 1.0, n: int = 201) -> float:
        """Usable energy of one cell between two SOC points, in Wh.

        Integrates OCV over charge rather than assuming ``nominal_V * Ah``,
        which overstates LFP and understates sloped chemistries.
        """
        grid = np.linspace(soc_lo, soc_hi, n)
        v = np.asarray(self.ocv.voltage_at(grid), dtype=float)
        return float(np.trapezoid(v, grid) * self.nominal_capacity_ah)

    def as_dict(self) -> dict[str, Any]:
        return self.model_dump(mode="json")


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------


class ChemistryRegistry:
    """Lookup and registration of chemistries.

    Built-in JSON files are loaded lazily on first access. Registering a
    chemistry with an existing name requires ``overwrite=True``, so a typo in
    an operator-supplied file cannot silently shadow a validated parameter set.
    """

    def __init__(self) -> None:
        self._items: dict[str, ChemistryParameters] = {}
        self._builtins_loaded = False

    def _ensure_builtins(self) -> None:
        if self._builtins_loaded:
            return
        self._builtins_loaded = True
        try:
            pkg = resources.files("batteryopt.data.chemistries")
        except (ModuleNotFoundError, FileNotFoundError):  # pragma: no cover
            return
        for entry in sorted(pkg.iterdir(), key=lambda p: p.name):
            if entry.name.endswith(".json"):
                try:
                    payload = json.loads(entry.read_text(encoding="utf-8"))
                except Exception as exc:  # pragma: no cover - packaging fault
                    raise ConfigurationError(
                        f"built-in chemistry {entry.name} is not valid JSON: {exc}"
                    ) from exc
                chem = ChemistryParameters.model_validate(payload)
                self._items.setdefault(chem.name, chem)

    def register(self, chemistry: ChemistryParameters, *, overwrite: bool = False) -> None:
        self._ensure_builtins()
        if chemistry.name in self._items and not overwrite:
            raise ConfigurationError(
                f"chemistry {chemistry.name!r} already registered; pass overwrite=True "
                "to replace it"
            )
        self._items[chemistry.name] = chemistry

    def get(self, name: str) -> ChemistryParameters:
        self._ensure_builtins()
        try:
            return self._items[name]
        except KeyError:
            raise ChemistryNotFound(name, list(self._items)) from None

    def names(self) -> list[str]:
        self._ensure_builtins()
        return sorted(self._items)

    def all(self) -> Iterable[ChemistryParameters]:
        self._ensure_builtins()
        return list(self._items.values())

    def load_file(self, path: str, *, overwrite: bool = False) -> ChemistryParameters:
        """Load a chemistry from a JSON file on disk and register it."""
        with open(path, "r", encoding="utf-8") as fh:
            chem = ChemistryParameters.model_validate(json.load(fh))
        self.register(chem, overwrite=overwrite)
        return chem

    def clear_user_entries(self) -> None:
        """Reset to built-ins only. Primarily a test-isolation helper."""
        self._items.clear()
        self._builtins_loaded = False


#: Process-wide registry. Applications may create their own instance.
REGISTRY = ChemistryRegistry()


def get_chemistry(name: str) -> ChemistryParameters:
    """Fetch a registered chemistry by name."""
    return REGISTRY.get(name)


def register_chemistry(chemistry: ChemistryParameters, *, overwrite: bool = False) -> None:
    """Register a chemistry in the process-wide registry."""
    REGISTRY.register(chemistry, overwrite=overwrite)


def available_chemistries() -> list[str]:
    """Names of all registered chemistries."""
    return REGISTRY.names()


__all__ = [
    "ChemistryFamily",
    "OCVCurve",
    "ResistanceModel",
    "ThermalProperties",
    "DegradationCoefficients",
    "OperatingEnvelope",
    "ChemistryParameters",
    "ChemistryRegistry",
    "REGISTRY",
    "get_chemistry",
    "register_chemistry",
    "available_chemistries",
]
