"""Lumped thermal model with controllable cooling and heating.

Thermal behaviour is not a side effect in BatteryOpt -- it is a decision
variable. The engine co-optimises battery power and cooling power, because
running the chiller flat out to hold 24 degC can easily cost more energy than
the degradation it avoids is worth (specification section 9).

Model
-----
A single lumped cell-mass node exchanging heat with a coolant/ambient sink:

.. code-block:: text

    C_th dT/dt = Q_gen + Q_heater - k(u) * (T - T_sink)
    k(u)       = k_passive + u * k_active            u in [0, 1]
    P_cool(u)  = P_cool_max * u**n                   n ~ 3 (affinity law)

Integration is exact for a zero-order-hold input rather than forward Euler:

.. code-block:: text

    T_inf   = T_sink + (Q_gen + Q_heater) / k
    T(t+dt) = T_inf + (T(t) - T_inf) * exp(-k*dt / C_th)

This matters because the optimiser takes 5-, 15- and 60-minute steps, and
explicit Euler at those step sizes is unconditionally wrong for a pack whose
thermal time constant is a few minutes. The exponential form is stable for any
step size and costs one ``exp``.

A second, optional coolant node captures loop thermal inertia for systems where
the chiller cannot respond instantly.

Cell-to-cell temperature spread is modelled as proportional to the heat flux
being pushed through the cooling path, which reproduces the observed behaviour
that packs are uniform at rest and stratified under load.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from ..core.numerics import EPS, clamp
from .topology import Topology


@dataclass(frozen=True, slots=True)
class ThermalResponse:
    """Result of one thermal step."""

    temperature_c: float
    temperature_max_c: float
    temperature_min_c: float
    coolant_c: float
    #: Electrical power consumed by the thermal system, W (always >= 0).
    parasitic_power_w: float
    #: Heat removed by the cooling path over the step, W (signed: negative if
    #: the pack was being warmed by ambient).
    heat_removed_w: float
    #: Steady-state temperature the pack is heading towards, degC.
    equilibrium_c: float
    #: Effective conductance actually in use, W/K.
    conductance_w_k: float


class LumpedThermalModel:
    """Configurable lumped-capacity thermal model for a system topology."""

    __slots__ = (
        "topology",
        "heat_capacity_j_k",
        "passive_conductance_w_k",
        "active_conductance_w_k",
        "cooling_power_w",
        "cooling_exponent",
        "heating_power_w",
        "heating_efficiency",
        "spread_gain_k_per_w",
        "coolant_heat_capacity_j_k",
        "coolant_conductance_w_k",
    )

    def __init__(
        self,
        topology: Topology,
        *,
        spread_gain_k_per_w: float | None = None,
        coolant_heat_capacity_j_k: float | None = None,
        coolant_conductance_w_k: float | None = None,
    ) -> None:
        thermal = topology.chemistry.thermal
        self.topology = topology
        self.heat_capacity_j_k = topology.heat_capacity_j_k
        self.passive_conductance_w_k = topology.passive_conductance_w_k
        self.active_conductance_w_k = topology.active_conductance_w_k
        self.cooling_power_w = topology.cooling_power_w
        self.cooling_exponent = thermal.cooling_power_exponent
        self.heating_power_w = topology.heating_power_w
        self.heating_efficiency = thermal.heating_efficiency
        #: Kelvin of cell-to-cell spread per watt of heat flux. Defaults to a
        #: value giving roughly 4 K of spread at a 2C discharge, consistent with
        #: instrumented automotive packs.
        total_k = self.passive_conductance_w_k + self.active_conductance_w_k
        self.spread_gain_k_per_w = (
            spread_gain_k_per_w
            if spread_gain_k_per_w is not None
            else 0.35 / max(total_k, EPS)
        )
        self.coolant_heat_capacity_j_k = coolant_heat_capacity_j_k or 0.0
        self.coolant_conductance_w_k = (
            coolant_conductance_w_k
            if coolant_conductance_w_k is not None
            else 2.0 * max(total_k, EPS)
        )

    # -- static properties --------------------------------------------------

    def conductance(self, cooling_fraction: float) -> float:
        """Cell-to-sink conductance at a given cooling effort, W/K."""
        u = clamp(cooling_fraction, 0.0, 1.0)
        return self.passive_conductance_w_k + u * self.active_conductance_w_k

    def parasitic_power(self, cooling_fraction: float, heating_fraction: float = 0.0) -> float:
        """Electrical power drawn by pumps, fans and heaters, W."""
        u = clamp(cooling_fraction, 0.0, 1.0)
        h = clamp(heating_fraction, 0.0, 1.0)
        cool = self.cooling_power_w * (u**self.cooling_exponent)
        heat = self.heating_power_w * h / max(self.heating_efficiency, EPS)
        return cool + heat

    def heater_heat(self, heating_fraction: float) -> float:
        """Heat delivered into the cells by the heater, W."""
        h = clamp(heating_fraction, 0.0, 1.0)
        return self.heating_power_w * h

    @property
    def time_constant_s(self) -> float:
        """Thermal time constant at full cooling, seconds."""
        return self.heat_capacity_j_k / max(self.conductance(1.0), EPS)

    @property
    def max_cooling_w_per_k(self) -> float:
        return self.conductance(1.0)

    def cooling_capacity_w(self, temperature_c: float, sink_c: float) -> float:
        """Maximum heat removal rate at the present temperature difference, W."""
        return self.conductance(1.0) * (temperature_c - sink_c)

    # -- evaluation ---------------------------------------------------------

    def equilibrium_temperature(
        self,
        *,
        heat_generation_w: float,
        sink_c: float,
        cooling_fraction: float,
        heating_fraction: float = 0.0,
    ) -> float:
        """Temperature the pack settles at if conditions persist, degC."""
        k = self.conductance(cooling_fraction)
        q = heat_generation_w + self.heater_heat(heating_fraction)
        return sink_c + q / max(k, EPS)

    def step(
        self,
        *,
        temperature_c: float,
        heat_generation_w: float,
        dt: float,
        ambient_c: float,
        coolant_c: float | None = None,
        cooling_fraction: float = 0.0,
        heating_fraction: float = 0.0,
    ) -> ThermalResponse:
        """Advance the thermal state by ``dt`` seconds.

        The sink temperature is the coolant when active cooling is engaged and
        the ambient when it is not; the model blends between them in proportion
        to the conductance each path contributes, which is the correct
        first-order treatment of a partially engaged loop.
        """
        u = clamp(cooling_fraction, 0.0, 1.0)
        sink_coolant = ambient_c if coolant_c is None else coolant_c
        k_passive = self.passive_conductance_w_k
        k_active = u * self.active_conductance_w_k
        k_total = k_passive + k_active
        if k_total <= EPS:
            sink = ambient_c
        else:
            sink = (k_passive * ambient_c + k_active * sink_coolant) / k_total

        q = heat_generation_w + self.heater_heat(heating_fraction)
        t_inf = sink + q / max(k_total, EPS)
        decay = math.exp(-k_total * dt / max(self.heat_capacity_j_k, EPS))
        t_new = t_inf + (temperature_c - t_inf) * decay

        # Mean heat removed over the step, from the energy balance.
        removed = k_total * (0.5 * (temperature_c + t_new) - sink)

        # Coolant node: warms as it absorbs heat, cools towards ambient via the
        # chiller. Only tracked when a coolant thermal mass was configured.
        if self.coolant_heat_capacity_j_k > EPS and coolant_c is not None:
            k_chiller = self.coolant_conductance_w_k
            c_inf = ambient_c + removed / max(k_chiller, EPS)
            c_decay = math.exp(-k_chiller * dt / self.coolant_heat_capacity_j_k)
            coolant_out = c_inf + (coolant_c - c_inf) * c_decay
        else:
            coolant_out = sink_coolant

        spread = self.spread_gain_k_per_w * abs(heat_generation_w)
        return ThermalResponse(
            temperature_c=t_new,
            temperature_max_c=t_new + 0.5 * spread,
            temperature_min_c=t_new - 0.5 * spread,
            coolant_c=coolant_out,
            parasitic_power_w=self.parasitic_power(u, heating_fraction),
            heat_removed_w=removed,
            equilibrium_c=t_inf,
            conductance_w_k=k_total,
        )

    # -- inversion ----------------------------------------------------------

    def cooling_for_target(
        self,
        *,
        target_c: float,
        heat_generation_w: float,
        sink_c: float,
    ) -> float:
        """Minimum cooling fraction holding steady state at ``target_c``.

        Returns 0.0 if passive cooling suffices and 1.0 if even full cooling
        cannot hold the target -- in which case the power constraint, not the
        cooling command, is what must give way.
        """
        dt_k = target_c - sink_c
        if heat_generation_w <= 0.0:
            return 0.0
        if dt_k <= EPS:
            return 1.0
        k_needed = heat_generation_w / dt_k
        if k_needed <= self.passive_conductance_w_k:
            return 0.0
        if self.active_conductance_w_k <= EPS:
            return 1.0
        return clamp(
            (k_needed - self.passive_conductance_w_k) / self.active_conductance_w_k, 0.0, 1.0
        )

    def max_sustainable_heat_w(
        self, *, limit_c: float, sink_c: float, cooling_fraction: float = 1.0
    ) -> float:
        """Heat generation the pack can shed indefinitely without exceeding a limit."""
        return max(0.0, self.conductance(cooling_fraction) * (limit_c - sink_c))

    def time_to_limit_s(
        self,
        *,
        temperature_c: float,
        limit_c: float,
        heat_generation_w: float,
        sink_c: float,
        cooling_fraction: float = 0.0,
    ) -> float:
        """Seconds until the pack reaches ``limit_c``; ``inf`` if it never does.

        This is what lets the optimiser allow a short high-power burst that
        would be inadmissible as a steady state: the constraint is not "the
        equilibrium temperature is legal" but "the temperature stays legal over
        the horizon I am actually planning".
        """
        if temperature_c >= limit_c:
            return 0.0
        k = self.conductance(cooling_fraction)
        t_inf = sink_c + heat_generation_w / max(k, EPS)
        if t_inf <= limit_c:
            return math.inf
        tau = self.heat_capacity_j_k / max(k, EPS)
        return tau * math.log((t_inf - temperature_c) / (t_inf - limit_c))


__all__ = ["LumpedThermalModel", "ThermalResponse"]
