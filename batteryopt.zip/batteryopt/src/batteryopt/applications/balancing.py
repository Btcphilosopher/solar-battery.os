"""Cell balancing optimisation (specification section 10).

"Do not assume maximum balancing is always optimal." Passive balancing works by
*burning* charge off the highest cells through a resistor. That energy is gone,
and the extra micro-cycling it causes is not free either. Balancing is worth
doing when the usable capacity it recovers is worth more than the energy and
life it consumes -- and not otherwise.

The decision has three inputs and one subtlety:

* recoverable capacity, from the SOC spread across the string;
* balancing energy, from the charge that must be bled and the pack voltage;
* the *rate* at which the imbalance is growing, because a pack that diverges
  quickly will need balancing again regardless, and one that is stable may not
  need it at all.

The subtlety is that voltage spread under load is mostly *resistance* spread,
which balancing cannot fix. Bleeding charge to level a resistance-driven spread
wastes energy and makes the SOC spread worse.
:class:`~batteryopt.estimation.imbalance.ImbalanceEstimator` separates the two,
and this planner refuses to act on the part balancing cannot help.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ..core.numerics import EPS
from ..core.units import SECONDS_PER_HOUR
from ..economics.engine import EconomicEngine
from ..estimation.imbalance import ImbalanceReport
from ..models.battery import Battery
from ..models.state import BatteryState


@dataclass(slots=True)
class BalancingPlan:
    """Whether to balance, how hard, and what it is worth."""

    should_balance: bool
    #: Bleed current per balancing channel, A.
    balancing_current_a: float
    #: Expected duration of the balancing session, seconds.
    duration_s: float
    #: Charge to be removed from the high cells, Ah.
    charge_to_move_ah: float
    #: Usable pack capacity recovered, Wh.
    recovered_energy_wh: float
    #: Energy consumed by balancing itself, Wh.
    balancing_energy_wh: float
    #: Value of the recovered capacity, in currency.
    benefit: float
    #: Cost of the energy burned plus the extra ageing, in currency.
    cost: float
    confidence: float
    reason: str = ""
    currency: str = "GBP"
    meta: dict[str, Any] = field(default_factory=dict)

    @property
    def net_value(self) -> float:
        return self.benefit - self.cost

    def summary(self) -> str:
        if not self.should_balance:
            return f"no balancing: {self.reason}"
        return (
            f"balance at {self.balancing_current_a:.2f} A for "
            f"{self.duration_s / 3600.0:.1f} h, recovering "
            f"{self.recovered_energy_wh / 1000.0:.2f} kWh for "
            f"{self.balancing_energy_wh / 1000.0:.2f} kWh spent "
            f"(net {self.net_value:+.3f} {self.currency})"
        )

    def as_dict(self) -> dict[str, Any]:
        return {
            "should_balance": self.should_balance,
            "balancing_current_a": self.balancing_current_a,
            "duration_s": self.duration_s,
            "charge_to_move_ah": self.charge_to_move_ah,
            "recovered_energy_wh": self.recovered_energy_wh,
            "balancing_energy_wh": self.balancing_energy_wh,
            "benefit": self.benefit,
            "cost": self.cost,
            "net_value": self.net_value,
            "confidence": self.confidence,
            "reason": self.reason,
            "currency": self.currency,
        }


class BalancingOptimiser:
    """Decides whether balancing pays for itself."""

    def __init__(
        self,
        battery: Battery,
        economics: EconomicEngine | None = None,
        *,
        max_balancing_current_a: float = 0.15,
        min_soc_spread: float = 0.01,
        min_confidence: float = 0.4,
        passive: bool = True,
    ) -> None:
        self.battery = battery
        self.economics = economics or EconomicEngine(battery)
        #: Per-channel bleed current the BMS hardware supports.
        self.max_balancing_current_a = max_balancing_current_a
        #: Spread below which balancing is not worth considering at all.
        self.min_soc_spread = min_soc_spread
        #: Imbalance-decomposition confidence below which the planner declines
        #: to act, because it cannot yet tell SOC spread from resistance spread.
        self.min_confidence = min_confidence
        #: Passive (resistive bleed) balancing loses the energy; active
        #: (charge-shuttling) balancing recovers most of it.
        self.passive = passive

    def plan(
        self,
        state: BatteryState,
        report: ImbalanceReport,
        *,
        energy_value_per_kwh: float | None = None,
        expected_remaining_years: float | None = None,
    ) -> BalancingPlan:
        battery = self.battery
        price = (
            energy_value_per_kwh
            if energy_value_per_kwh is not None
            else self.economics.config.default_energy_value_per_kwh
        )
        currency = self.economics.config.currency

        if report.confidence < self.min_confidence:
            return BalancingPlan(
                should_balance=False,
                balancing_current_a=0.0,
                duration_s=0.0,
                charge_to_move_ah=0.0,
                recovered_energy_wh=0.0,
                balancing_energy_wh=0.0,
                benefit=0.0,
                cost=0.0,
                confidence=report.confidence,
                currency=currency,
                reason=(
                    "the imbalance decomposition is not yet confident enough to "
                    "distinguish state-of-charge spread from resistance spread; "
                    "balancing a resistance-driven spread burns energy for nothing"
                ),
            )

        if report.soc_spread < self.min_soc_spread:
            return BalancingPlan(
                should_balance=False,
                balancing_current_a=0.0,
                duration_s=0.0,
                charge_to_move_ah=0.0,
                recovered_energy_wh=0.0,
                balancing_energy_wh=0.0,
                benefit=0.0,
                cost=0.0,
                confidence=report.confidence,
                currency=currency,
                reason=(
                    f"state-of-charge spread is {report.soc_spread * 100:.2f} %, below "
                    f"the {self.min_soc_spread * 100:.2f} % threshold at which "
                    "balancing recovers more than it costs"
                ),
            )

        charge_ah = report.balancing_charge_ah
        cell_v = battery.chemistry.nominal_voltage_cell
        balancing_wh = charge_ah * cell_v * (1.0 if self.passive else 0.15)

        # Recovered capacity: the string's usable window widens by the spread,
        # but only up to the point where the weakest cell's own capacity binds.
        recovered_wh = min(report.soc_spread, report.capacity_loss_fraction) * (
            battery.energy_wh
        )
        benefit = recovered_wh / 1000.0 * price

        # Cost: energy burned, plus the ageing the extra throughput causes.
        energy_cost = balancing_wh / 1000.0 * price
        # ``balancing_charge_ah`` is summed across the string. Ageing is a
        # per-cell phenomenon, and the pack-equivalent throughput is therefore
        # the charge bled from a representative cell, not the sum over all of
        # them -- a factor of ``n_series``. Getting this wrong makes balancing
        # look about a hundred times more damaging than it is, and a balancer
        # that never runs is not a conservative balancer, it is a broken one.
        per_cell_ah = charge_ah / max(battery.topology.n_series, 1)
        cell_capacity_ah = max(battery.topology.cell.effective_capacity_ah, EPS)
        extra_efc = per_cell_ah / (2.0 * cell_capacity_ah)
        fade = battery.degradation.fade(
            battery.degradation_state.t_eq_years,
            battery.degradation_state.a_eq_efc + extra_efc,
        ) - battery.degradation_state.capacity_fade
        ageing_cost = self.economics.degradation_cost(
            max(fade, 0.0), remaining_years=expected_remaining_years
        )
        cost = energy_cost + ageing_cost

        current = self.max_balancing_current_a
        duration = charge_ah / max(current, EPS) * SECONDS_PER_HOUR

        should = benefit > cost
        if should:
            reason = (
                f"Balancing {charge_ah:.2f} Ah recovers "
                f"{recovered_wh / 1000.0:.2f} kWh of usable capacity worth "
                f"{benefit:.3f} {currency}, against {energy_cost:.3f} of energy burned "
                f"and {ageing_cost:.3f} of extra ageing. Net "
                f"{benefit - cost:+.3f} {currency}."
            )
        else:
            reason = (
                f"Balancing would recover {recovered_wh / 1000.0:.2f} kWh worth "
                f"{benefit:.3f} {currency} but cost {cost:.3f} to do, so it does not "
                "pay for itself yet. Revisit once the spread grows."
            )
        if report.resistance_spread > 0.15:
            reason += (
                f" Note: {report.resistance_spread * 100:.0f} % resistance spread is "
                "present, which balancing cannot correct and which will keep the "
                "voltage spread visible under load."
            )

        return BalancingPlan(
            should_balance=should,
            balancing_current_a=current if should else 0.0,
            duration_s=duration if should else 0.0,
            charge_to_move_ah=charge_ah,
            recovered_energy_wh=recovered_wh,
            balancing_energy_wh=balancing_wh,
            benefit=benefit,
            cost=cost,
            confidence=report.confidence,
            reason=reason,
            currency=currency,
            meta={
                "soc_spread": report.soc_spread,
                "resistance_spread": report.resistance_spread,
                "outlier_cells": list(report.outlier_cells),
                "extra_equivalent_full_cycles": extra_efc,
            },
        )

    def best_window(self, state: BatteryState) -> str:
        """When balancing is most effective, as operator guidance.

        Passive balancing is most effective near the top of charge, where cell
        voltages diverge most and the OCV curve is steepest, so the same bled
        charge corrects more spread. It should be avoided at low SOC on flat
        chemistries, where voltage carries almost no state-of-charge signal and
        the balancer is effectively acting on noise.
        """
        slope = self.battery.chemistry.ocv.slope_at(state.soc)
        top_slope = self.battery.chemistry.ocv.slope_at(0.9)
        if state.soc > 0.85:
            return "now: the pack is near the top of charge, where the OCV curve is steepest"
        if slope < 0.3 * top_slope:
            return (
                "defer to the top of charge: at this state of charge the OCV curve is "
                "too flat for cell voltages to indicate state of charge reliably"
            )
        return "acceptable now, but more effective near the top of charge"


__all__ = ["BalancingOptimiser", "BalancingPlan"]
