"""Mission-based charging (specification section 7).

.. code-block:: text

    VEHICLE                       BATTERYOPT
    Required journey  280 km      Recommended target    86 %
    Departure         07:30       Recommended charging  +11.4 kWh
    Expected energy   54 kWh      Estimated completion  06:58
    Weather           5 degC
    Current SOC       74 %

The objective is stated precisely in the specification: *have sufficient energy
for the mission while minimising unnecessary charging and degradation.* Both
halves matter. Charging to 100 % "to be safe" is the single most common way to
destroy an EV battery, because time spent at high SOC is what calendar ageing
charges the most for.

Reliability, not optimism
-------------------------
The energy a mission needs is a *distribution*, not a number. Cold weather,
traffic, a heavier load and a different driver all move it. The planner
therefore takes the requirement as quantiles and plans to the operator's stated
reliability -- P90 by default, meaning "enough energy nine times out of ten" --
rather than to the median, which by construction leaves the driver short half
the time.

Ambient temperature enters twice: it raises the energy the mission consumes
(cabin heating, higher rolling resistance, reduced regeneration) and it lowers
what the pack can deliver. Both effects are applied, which is why a 5 degC
morning produces a materially higher target than the same journey in summer.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ..core.numerics import EPS, clamp
from ..core.provenance import Quantiles
from ..core.units import SECONDS_PER_HOUR
from ..economics.prices import Tariff
from ..models.state import BatteryState
from ..optimisation.engine import OptimisationEngine
from ..optimisation.problem import Mission
from .charging import ChargePlan, SmartCharger


@dataclass(slots=True)
class MissionPlan:
    """What the battery must do before a mission, and why."""

    mission: Mission
    #: SOC to be at when the mission starts.
    recommended_target_soc: float
    #: Energy that must be added to reach it, Wh.
    recommended_charge_wh: float
    #: Energy the mission is planned to consume at the stated reliability, Wh.
    planning_energy_wh: float
    #: Seconds from now at which charging should complete.
    completion_s: float
    charge_plan: ChargePlan | None
    #: Probability the plan leaves the mission short, from the quantiles.
    shortfall_risk: float
    #: SOC expected at the end of the mission.
    arrival_soc: float
    reason: str = ""
    warnings: tuple[str, ...] = ()
    meta: dict[str, Any] = field(default_factory=dict)

    def summary(self) -> str:
        return (
            f"target {self.recommended_target_soc * 100:.0f} %, add "
            f"{self.recommended_charge_wh / 1000.0:.1f} kWh, complete "
            f"{self.completion_s / 60.0:.0f} min from now, arrive at "
            f"{self.arrival_soc * 100:.0f} % (risk {self.shortfall_risk * 100:.1f} %)"
        )

    def as_dict(self) -> dict[str, Any]:
        return {
            "mission": self.mission.as_dict(),
            "recommended_target_soc": self.recommended_target_soc,
            "recommended_charge_wh": self.recommended_charge_wh,
            "planning_energy_wh": self.planning_energy_wh,
            "completion_s": self.completion_s,
            "shortfall_risk": self.shortfall_risk,
            "arrival_soc": self.arrival_soc,
            "reason": self.reason,
            "warnings": list(self.warnings),
            "charge_plan": self.charge_plan.as_dict() if self.charge_plan else None,
        }


def temperature_energy_factor(ambient_c: float) -> float:
    """Multiplier on mission energy from ambient temperature.

    A piecewise-linear fit to the well-documented cold-weather range penalty:
    roughly +35 % at -10 degC, +20 % at 0 degC, +10 % at 5 degC, nothing at
    20 degC, and a smaller air-conditioning penalty above 30 degC. Deliberately
    simple and explicit -- a fleet with its own telemetry should replace this
    with a fitted model, and the function exists as a single seam for that.
    """
    if ambient_c <= -10.0:
        return 1.35
    if ambient_c < 20.0:
        return 1.35 - 0.35 * (ambient_c + 10.0) / 30.0
    if ambient_c <= 30.0:
        return 1.0
    return min(1.15, 1.0 + 0.015 * (ambient_c - 30.0))


class MissionPlanner:
    """Works out the smallest charge that makes a future mission safe."""

    def __init__(
        self,
        engine: OptimisationEngine,
        charger: SmartCharger | None = None,
        *,
        default_reliability: float = 0.9,
    ) -> None:
        self.engine = engine
        self.charger = charger or SmartCharger(engine)
        self.default_reliability = default_reliability

    # -- energy requirement -------------------------------------------------

    def required_energy(
        self, mission: Mission, *, ambient_c: float | None = None
    ) -> Quantiles:
        """Mission energy as quantiles, adjusted for ambient temperature."""
        base = mission.quantiles or Quantiles(
            mission.energy_wh * 0.92, mission.energy_wh, mission.energy_wh * 1.12
        )
        ambient = ambient_c if ambient_c is not None else mission.ambient_c
        if ambient is None:
            return base
        factor = temperature_energy_factor(ambient)
        return base.scaled(factor)

    @staticmethod
    def _risk_of_shortfall(available_wh: float, requirement: Quantiles) -> float:
        """Rough probability the requirement exceeds what is available.

        Linear interpolation on the three-point summary. It is not a
        distribution fit and does not pretend to be; it is a monotone, bounded
        statement about where the available energy sits in the predicted range,
        which is exactly what the reliability decision needs.
        """
        if available_wh >= requirement.p90:
            span = max(requirement.p90 - requirement.p50, EPS)
            excess = (available_wh - requirement.p90) / span
            return max(0.0, 0.10 * (1.0 - min(excess, 1.0)))
        if available_wh >= requirement.p50:
            frac = (available_wh - requirement.p50) / max(
                requirement.p90 - requirement.p50, EPS
            )
            return 0.50 - 0.40 * frac
        if available_wh >= requirement.p10:
            frac = (available_wh - requirement.p10) / max(
                requirement.p50 - requirement.p10, EPS
            )
            return 0.90 - 0.40 * frac
        return min(0.99, 0.90 + 0.09 * (requirement.p10 - available_wh) / max(requirement.p10, EPS))

    # -- planning -----------------------------------------------------------

    def plan(
        self,
        state: BatteryState,
        mission: Mission,
        *,
        ambient_c: float | None = None,
        tariff: Tariff | None = None,
        objective: Any = None,
    ) -> MissionPlan:
        """Return the minimum charge that meets the mission at the required reliability."""
        battery = self.engine.battery
        constraints = self.engine.constraints
        requirement = self.required_energy(mission, ambient_c=ambient_c)
        reliability = mission.required_reliability or self.default_reliability
        planning_wh = Mission(
            energy_wh=requirement.p50,
            departure_s=mission.departure_s,
            quantiles=requirement,
            required_reliability=reliability,
            reserve_soc=mission.reserve_soc,
        ).planning_energy_wh()

        warnings: list[str] = []

        # Energy needed = mission energy + the reserve that must survive it.
        reserve_floor = max(mission.reserve_soc, battery.envelope.soc_min)
        usable_now = battery.energy_between(reserve_floor, state.soc)
        deficit_wh = max(0.0, planning_wh - usable_now)

        if deficit_wh <= EPS:
            target = state.soc
            reason = (
                f"No charging needed: {usable_now / 1000.0:.1f} kWh is already available "
                f"above the {reserve_floor * 100:.0f} % reserve, against a planning "
                f"requirement of {planning_wh / 1000.0:.1f} kWh at P"
                f"{reliability * 100:.0f}."
            )
            charge_plan = None
        else:
            target = clamp(
                battery.soc_for_energy(
                    usable_now + deficit_wh, from_soc=reserve_floor
                ),
                state.soc,
                battery.envelope.soc_max,
            )
            if target >= battery.envelope.soc_max - 1e-6:
                warnings.append(
                    "The mission requires charging to the maximum permitted state of "
                    "charge; there is no margin left for a longer-than-expected journey."
                )
            charge_plan = self.charger.plan(
                state,
                target_soc=target,
                deadline_s=mission.departure_s,
                tariff=tariff,
                ambient_c=ambient_c,
                objective=objective,
            )
            if not charge_plan.feasible:
                warnings.append(
                    "The target cannot be reached before departure at any admissible "
                    f"rate; the plan reaches {charge_plan.target_soc * 100:.1f} % instead."
                )
                target = charge_plan.target_soc
            reason = (
                f"Planning to P{reliability * 100:.0f} of the energy distribution "
                f"({requirement.p10 / 1000.0:.1f}-{requirement.p90 / 1000.0:.1f} kWh, "
                f"median {requirement.p50 / 1000.0:.1f} kWh) rather than the median, so "
                "the mission is met nine times in ten. "
                f"Adding {deficit_wh / 1000.0:.1f} kWh takes the pack from "
                f"{state.soc * 100:.0f} % to {target * 100:.0f} % -- the smallest charge "
                "that clears the requirement, because time spent at high state of charge "
                "is what calendar ageing charges the most for."
            )

        available = battery.energy_between(reserve_floor, target)
        risk = self._risk_of_shortfall(available, requirement)
        arrival = clamp(
            battery.soc_for_energy(
                max(0.0, available - requirement.p50), from_soc=reserve_floor
            ),
            0.0,
            1.0,
        )
        completion = (
            charge_plan.end_s if charge_plan is not None else 0.0
        )
        ambient = ambient_c if ambient_c is not None else mission.ambient_c
        if ambient is not None and ambient < 10.0:
            reason += (
                f" Ambient {ambient:.0f} degC raises the mission's energy requirement by "
                f"{(temperature_energy_factor(ambient) - 1.0) * 100:.0f} %."
            )
        return MissionPlan(
            mission=mission,
            recommended_target_soc=target,
            recommended_charge_wh=battery.energy_between(state.soc, target),
            planning_energy_wh=planning_wh,
            completion_s=completion,
            charge_plan=charge_plan,
            shortfall_risk=risk,
            arrival_soc=arrival,
            reason=reason,
            warnings=tuple(warnings),
            meta={
                "requirement_quantiles": requirement.as_dict(),
                "usable_now_wh": usable_now,
                "reserve_floor_soc": reserve_floor,
                "constraint_energy_wh": constraints.energy_available_wh(state),
            },
        )

    def report(self, plan: MissionPlan, state: BatteryState) -> str:
        """The specification's side-by-side presentation."""
        m = plan.mission
        q = Quantiles(**plan.meta["requirement_quantiles"])
        lines = [
            "VEHICLE",
            "",
            f"  Departure in         {m.departure_s / 3600.0:.1f} h",
            f"  Expected energy      {q.p50 / 1000.0:.1f} kWh  (P10-P90 "
            f"{q.p10 / 1000.0:.1f}-{q.p90 / 1000.0:.1f} kWh)",
            f"  Current SOC          {state.soc * 100:.0f} %",
            "",
            "BATTERYOPT",
            "",
            f"  Recommended target   {plan.recommended_target_soc * 100:.0f} %",
            f"  Recommended charging +{plan.recommended_charge_wh / 1000.0:.1f} kWh",
            f"  Estimated completion +{plan.completion_s / 60.0:.0f} min",
            f"  Shortfall risk       {plan.shortfall_risk * 100:.1f} %",
        ]
        if plan.charge_plan is not None:
            lines.append(
                f"  Degradation          {plan.charge_plan.estimated_degradation * 100:.4f} %"
            )
            lines.append(
                f"  Energy cost          {plan.charge_plan.energy_cost:.2f} "
                f"{plan.charge_plan.currency}"
            )
        for w in plan.warnings:
            lines.append(f"  WARNING: {w}")
        return "\n".join(lines)


__all__ = ["MissionPlanner", "MissionPlan", "temperature_energy_factor"]
