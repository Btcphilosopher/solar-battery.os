"""Thermal optimisation (specification section 9).

The section's worked example is the whole argument:

.. code-block:: text

    Cooling 100 %  ->  24 degC, 4.2 kW consumed
    Cooling  45 %  ->  29 degC, 1.6 kW consumed, health impact negligible
    RECOMMENDATION: 45 % cooling

Cooling is not free and temperature is not a constraint to be minimised. It is
a variable to be optimised, and the optimum is where the marginal parasitic
power equals the marginal degradation avoided. Because pump and fan power grows
roughly with the cube of flow, that optimum is almost never at either end of the
range -- which is exactly why an on/off thermostat leaves value on the table.

This planner sweeps the cooling command against the plant, prices each point in
the same currency as everything else, and returns the interior optimum together
with the curve, so an operator can see the shape of the trade-off rather than
being handed a number.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np

from ..core.numerics import EPS
from ..models.state import BatteryState
from ..optimisation.engine import OptimisationEngine
from ..optimisation.problem import Demand
from ..scenario.strategies import cooling_sweep


@dataclass(slots=True)
class ThermalOperatingPoint:
    """One cooling command, priced."""

    cooling_fraction: float
    equilibrium_temperature_c: float
    peak_temperature_c: float
    parasitic_power_w: float
    capacity_fade: float
    degradation_cost: float
    parasitic_cost: float
    total_cost: float
    feasible: bool = True

    def as_dict(self) -> dict[str, Any]:
        return {
            "cooling_fraction": self.cooling_fraction,
            "equilibrium_temperature_c": self.equilibrium_temperature_c,
            "peak_temperature_c": self.peak_temperature_c,
            "parasitic_power_w": self.parasitic_power_w,
            "capacity_fade": self.capacity_fade,
            "degradation_cost": self.degradation_cost,
            "parasitic_cost": self.parasitic_cost,
            "total_cost": self.total_cost,
            "feasible": self.feasible,
        }


@dataclass(slots=True)
class ThermalPlan:
    """The recommended cooling command, with the curve behind it."""

    recommended_cooling: float
    recommended_heating: float
    points: tuple[ThermalOperatingPoint, ...]
    reason: str = ""
    currency: str = "GBP"
    meta: dict[str, Any] = field(default_factory=dict)

    @property
    def best(self) -> ThermalOperatingPoint | None:
        feasible = [p for p in self.points if p.feasible]
        return min(feasible, key=lambda p: p.total_cost) if feasible else None

    def table(self) -> str:
        lines = [
            f"{'COOLING':>8} {'TEMP':>8} {'PARASITIC':>11} {'DEGRADATION':>13} "
            f"{'COOLING COST':>13} {'TOTAL':>9}",
            "-" * 66,
        ]
        for p in self.points:
            flag = "" if p.feasible else "  <- exceeds limit"
            lines.append(
                f"{p.cooling_fraction * 100:6.0f}% {p.peak_temperature_c:7.1f}C "
                f"{p.parasitic_power_w:9.0f} W {p.capacity_fade * 100:12.5f}% "
                f"{p.parasitic_cost:12.4f} {p.total_cost:8.4f}{flag}"
            )
        return "\n".join(lines)

    def as_dict(self) -> dict[str, Any]:
        return {
            "recommended_cooling": self.recommended_cooling,
            "recommended_heating": self.recommended_heating,
            "points": [p.as_dict() for p in self.points],
            "reason": self.reason,
            "currency": self.currency,
        }


class ThermalOptimiser:
    """Co-optimises battery power and cooling power."""

    def __init__(
        self,
        engine: OptimisationEngine,
        *,
        fractions: tuple[float, ...] = (0.0, 0.15, 0.3, 0.45, 0.6, 0.75, 0.9, 1.0),
    ) -> None:
        self.engine = engine
        self.fractions = fractions

    def plan(
        self,
        state: BatteryState,
        *,
        power_w: float,
        horizon_s: float = 1800.0,
        dt_s: float = 60.0,
        ambient_c: float | None = None,
        objective: Any = None,
    ) -> ThermalPlan:
        """Sweep the cooling command at a fixed battery power and price each point."""
        problem = self.engine.build_problem(
            state,
            demand=Demand(power_w=max(0.0, power_w), firm=False),
            horizon_s=horizon_s,
            dt_s=dt_s,
            ambient_c=ambient_c,
            objective=objective,
        )
        scenarios = cooling_sweep(problem, power_w, fractions=self.fractions)
        results = self.engine.scenarios.compare(problem, scenarios)
        by_fraction = {
            float(r.scenario.first_cooling): r for r in results
        }

        battery = self.engine.battery
        econ = self.engine.economics
        price = econ.config.default_energy_value_per_kwh
        tariff = self.engine.tariff
        if tariff is not None:
            price = float(np.atleast_1d(tariff.import_at(state.timestamp))[0])

        points: list[ThermalOperatingPoint] = []
        for fraction in self.fractions:
            result = by_fraction.get(float(fraction))
            if result is None:
                continue
            outcome = result.outcome
            parasitic_w = battery.thermal.parasitic_power(fraction)
            parasitic_cost = (
                parasitic_w * horizon_s / 3600.0 / 1000.0 * price
            )
            degradation_cost = econ.degradation_cost(
                outcome.capacity_fade,
                remaining_years=self.engine.objective.config.remaining_life_years,
            )
            points.append(
                ThermalOperatingPoint(
                    cooling_fraction=fraction,
                    equilibrium_temperature_c=battery.thermal.equilibrium_temperature(
                        heat_generation_w=state.heat_generation_w or 0.0,
                        sink_c=state.coolant_c,
                        cooling_fraction=fraction,
                    ),
                    peak_temperature_c=outcome.peak_temperature_c,
                    parasitic_power_w=parasitic_w,
                    capacity_fade=outcome.capacity_fade,
                    degradation_cost=degradation_cost,
                    parasitic_cost=parasitic_cost,
                    total_cost=degradation_cost + parasitic_cost,
                    feasible=result.feasible,
                )
            )

        best = min(
            (p for p in points if p.feasible), key=lambda p: p.total_cost, default=None
        )
        heating = self.heating_requirement(state)
        if best is None:
            reason = "No cooling command kept the pack inside its temperature limits."
            recommended = 1.0
        else:
            full = next((p for p in points if p.cooling_fraction >= 0.999), None)
            saving = (full.total_cost - best.total_cost) if full else 0.0
            recommended = best.cooling_fraction
            reason = (
                f"Cooling at {best.cooling_fraction * 100:.0f} % costs "
                f"{best.parasitic_cost:.4f} in parasitic energy and "
                f"{best.degradation_cost:.4f} in battery life, for "
                f"{best.total_cost:.4f} total. "
            )
            if full is not None and saving > 0:
                reason += (
                    f"Full cooling would hold the pack "
                    f"{best.peak_temperature_c - full.peak_temperature_c:.1f} K cooler "
                    f"but cost {saving:.4f} more in total, because pump power grows with "
                    "roughly the cube of flow while the degradation avoided is nearly "
                    "linear in temperature."
                )
        if heating > 0.0:
            reason += (
                f" Heating at {heating * 100:.0f} % is recommended first: the pack is "
                "below the temperature at which charging is permitted."
            )

        return ThermalPlan(
            recommended_cooling=recommended,
            recommended_heating=heating,
            points=tuple(points),
            reason=reason,
            currency=econ.config.currency,
            meta={"price_per_kwh": price, "power_w": power_w},
        )

    def heating_requirement(self, state: BatteryState) -> float:
        """Heating command needed before charging is permitted, 0-1."""
        limits = self.engine.battery.thermal_limits
        if state.temperature_c >= limits.t_min_charge_c + 2.0:
            return 0.0
        deficit = (limits.t_min_charge_c + 2.0) - state.temperature_c
        # Full heat until within 2 K, then proportional, to avoid overshoot.
        return float(min(1.0, max(0.2, deficit / 5.0)))

    def cooling_for_limit(
        self, state: BatteryState, *, power_w: float, limit_c: float
    ) -> float:
        """Minimum cooling that holds a temperature limit at a given power."""
        battery = self.engine.battery
        response = battery.electrical.evaluate(
            soc=state.soc,
            current_a=battery.electrical.current_for_power(
                power_w,
                soc=state.soc,
                temperature_c=state.temperature_c,
                resistance_growth=state.degradation.resistance_growth,
                hysteresis=state.hysteresis,
            ),
            temperature_c=state.temperature_c,
            resistance_growth=state.degradation.resistance_growth,
            hysteresis=state.hysteresis,
        )
        return battery.thermal.cooling_for_target(
            target_c=limit_c,
            heat_generation_w=max(response.heat_w, 0.0),
            sink_c=state.coolant_c,
        )

    def max_power_at_temperature(
        self, state: BatteryState, *, limit_c: float, cooling_fraction: float = 1.0
    ) -> float:
        """Largest steady power whose heat the cooling system can shed."""
        battery = self.engine.battery
        heat_budget = battery.thermal.max_sustainable_heat_w(
            limit_c=limit_c, sink_c=state.coolant_c, cooling_fraction=cooling_fraction
        )
        r = battery.resistance_now(soc=state.soc, temperature_c=state.temperature_c)
        if r <= EPS:
            return float("inf")
        current = (heat_budget / r) ** 0.5
        v = float(battery.electrical.ocv(state.soc, hysteresis=state.hysteresis))
        current = min(current, v / (2.0 * r))
        return max(0.0, (v - current * r) * current)


__all__ = ["ThermalOptimiser", "ThermalPlan", "ThermalOperatingPoint"]
