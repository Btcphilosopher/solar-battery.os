"""Grid services (specification section 18).

Peak shaving, load shifting, frequency response, reserve capacity and demand
response are all the same shape of question: *is the revenue worth the
degradation and the energy loss?* This module answers it per service, in one
currency, so that a portfolio of services can be ranked rather than argued over.

The four things that decide the answer:

* **Revenue model.** Availability payments (paid for being ready) behave
  completely differently from utilisation payments (paid for energy delivered).
  An availability-paid service can be extremely profitable precisely because it
  is rarely called, and modelling it as though it were always dispatched
  destroys that.
* **Expected utilisation.** Frequency response is called for a few minutes a
  day; a capacity market contract might be called twice a winter. Degradation
  should be charged on the expected throughput, not the contracted power.
* **Opportunity cost.** Capacity committed to reserve cannot be traded. That
  forgone arbitrage is a real cost of the service and is included.
* **State-of-charge obligation.** Reserve services require the battery to sit
  at a state of charge that is often worse for calendar ageing than where it
  would otherwise be. That cost is charged too.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Sequence

import numpy as np

from ..core.numerics import EPS, clamp
from ..core.units import SECONDS_PER_HOUR, SECONDS_PER_YEAR
from ..models.battery import Battery
from ..models.state import BatteryState
from ..optimisation.engine import OptimisationEngine


class ServiceType(str, Enum):
    PEAK_SHAVING = "peak_shaving"
    LOAD_SHIFTING = "load_shifting"
    FREQUENCY_RESPONSE = "frequency_response"
    RESERVE_CAPACITY = "reserve_capacity"
    DEMAND_RESPONSE = "demand_response"


@dataclass(frozen=True, slots=True)
class ServiceContract:
    """The commercial and technical terms of one grid service."""

    service: ServiceType
    #: Power the battery must be able to deliver, W.
    committed_power_w: float
    #: Payment for being available, currency per kW per hour of availability.
    availability_payment_per_kw_h: float = 0.0
    #: Payment for energy actually delivered, currency per kWh.
    utilisation_payment_per_kwh: float = 0.0
    #: Fraction of the contracted hours during which energy is actually
    #: delivered. Frequency response is typically a few percent.
    expected_utilisation: float = 0.05
    #: Hours per year the contract is active.
    hours_per_year: float = 8760.0
    #: State of charge that must be held to be able to respond in both
    #: directions. ``None`` means no obligation.
    required_soc: float | None = None
    #: Maximum time the service can be called for continuously, seconds.
    max_duration_s: float = 900.0
    #: Penalty for failing to deliver when called, currency per event.
    non_delivery_penalty: float = 0.0
    label: str = ""

    @property
    def committed_energy_wh(self) -> float:
        """Energy that must be deliverable in a single worst-case call."""
        return self.committed_power_w * self.max_duration_s / SECONDS_PER_HOUR

    def as_dict(self) -> dict[str, Any]:
        return {
            "service": self.service.value,
            "label": self.label,
            "committed_power_w": self.committed_power_w,
            "availability_payment_per_kw_h": self.availability_payment_per_kw_h,
            "utilisation_payment_per_kwh": self.utilisation_payment_per_kwh,
            "expected_utilisation": self.expected_utilisation,
            "hours_per_year": self.hours_per_year,
            "required_soc": self.required_soc,
            "max_duration_s": self.max_duration_s,
            "committed_energy_wh": self.committed_energy_wh,
        }


@dataclass(slots=True)
class ServiceAssessment:
    """Whether a service is worth providing, and why."""

    contract: ServiceContract
    annual_revenue: float
    annual_degradation_cost: float
    annual_energy_cost: float
    annual_opportunity_cost: float
    #: Extra calendar ageing from holding the required state of charge.
    annual_soc_obligation_cost: float
    deliverable: bool
    limiting_constraint: str | None
    currency: str = "GBP"
    reason: str = ""
    meta: dict[str, Any] = field(default_factory=dict)

    @property
    def annual_cost(self) -> float:
        return (
            self.annual_degradation_cost
            + self.annual_energy_cost
            + self.annual_opportunity_cost
            + self.annual_soc_obligation_cost
        )

    @property
    def annual_margin(self) -> float:
        return self.annual_revenue - self.annual_cost

    @property
    def worthwhile(self) -> bool:
        return self.deliverable and self.annual_margin > 0.0

    def summary(self) -> str:
        verdict = "worth providing" if self.worthwhile else "not worth providing"
        if not self.deliverable:
            verdict = f"cannot be delivered ({self.limiting_constraint})"
        return (
            f"{self.contract.service.value}: revenue {self.annual_revenue:,.0f}, "
            f"cost {self.annual_cost:,.0f}, margin {self.annual_margin:+,.0f} "
            f"{self.currency}/year -- {verdict}"
        )

    def as_dict(self) -> dict[str, Any]:
        return {
            "contract": self.contract.as_dict(),
            "annual_revenue": self.annual_revenue,
            "annual_degradation_cost": self.annual_degradation_cost,
            "annual_energy_cost": self.annual_energy_cost,
            "annual_opportunity_cost": self.annual_opportunity_cost,
            "annual_soc_obligation_cost": self.annual_soc_obligation_cost,
            "annual_cost": self.annual_cost,
            "annual_margin": self.annual_margin,
            "worthwhile": self.worthwhile,
            "deliverable": self.deliverable,
            "limiting_constraint": self.limiting_constraint,
            "currency": self.currency,
            "reason": self.reason,
        }


class GridServiceOptimiser:
    """Prices grid services against degradation, losses and opportunity cost."""

    def __init__(
        self,
        engine: OptimisationEngine,
        *,
        arbitrage_value_per_kwh: float = 0.03,
        one_way_efficiency: float = 0.97,
    ) -> None:
        self.engine = engine
        #: Margin the battery would earn per kWh traded if it were free to do
        #: arbitrage instead. Used for the opportunity cost of committed
        #: capacity.
        self.arbitrage_value_per_kwh = arbitrage_value_per_kwh
        self.one_way_efficiency = one_way_efficiency

    # -- helpers ------------------------------------------------------------

    def _wear_cost_per_kwh(self) -> float:
        battery = self.engine.battery
        chem = battery.chemistry.degradation
        state = battery.degradation_state
        a_eq = max(state.a_eq_efc, 0.0) + chem.formation_efc
        fade_per_efc = chem.a_cycle * chem.z_cycle * a_eq ** (chem.z_cycle - 1.0)
        cost_per_efc = self.engine.economics.degradation_cost(
            fade_per_efc, remaining_years=self.engine.objective.config.remaining_life_years
        )
        kwh_per_efc = 2.0 * max(battery.nominal_energy_wh / 1000.0, EPS)
        return cost_per_efc / kwh_per_efc

    def _soc_obligation_cost(self, contract: ServiceContract, state: BatteryState) -> float:
        """Annual calendar-ageing cost of holding the contract's required SOC."""
        if contract.required_soc is None:
            return 0.0
        battery = self.engine.battery
        model = battery.degradation
        chem = battery.chemistry.degradation
        stress_required = model.calendar_stress(
            soc=contract.required_soc, temperature_c=state.temperature_c
        )
        # The counterfactual is the state of charge the asset would otherwise
        # sit at, taken as the calendar-optimal reference point.
        stress_reference = model.calendar_stress(
            soc=chem.soc_stress_ref, temperature_c=state.temperature_c
        )
        t_eq = max(battery.degradation_state.t_eq_years, 0.0) + chem.formation_years
        per_year = chem.a_calendar * chem.z_calendar * t_eq ** (chem.z_calendar - 1.0)
        duty = clamp(contract.hours_per_year / 8760.0, 0.0, 1.0)
        delta_fade = per_year * duty * max(0.0, stress_required - stress_reference)
        return self.engine.economics.degradation_cost(
            delta_fade, remaining_years=self.engine.objective.config.remaining_life_years
        )

    def deliverable(
        self, contract: ServiceContract, state: BatteryState
    ) -> tuple[bool, str | None]:
        """Can the battery actually meet the commitment from this state?"""
        from ..estimation.sop import PowerCapabilityEstimator

        sop = PowerCapabilityEstimator(self.engine.battery)
        capability = sop.estimate(state, horizon_s=contract.max_duration_s)
        if capability.discharge_w < contract.committed_power_w:
            return False, capability.discharge_limiting
        energy_available = self.engine.constraints.energy_available_wh(state)
        if energy_available < contract.committed_energy_wh:
            return False, "insufficient stored energy for a full-duration call"
        return True, None

    # -- assessment ---------------------------------------------------------

    def assess(
        self,
        contract: ServiceContract,
        state: BatteryState,
        *,
        energy_price_per_kwh: float | None = None,
    ) -> ServiceAssessment:
        """Price one service contract over a year."""
        engine = self.engine
        econ = engine.economics
        price = (
            energy_price_per_kwh
            if energy_price_per_kwh is not None
            else econ.config.default_energy_value_per_kwh
        )
        kw = contract.committed_power_w / 1000.0

        availability_revenue = (
            contract.availability_payment_per_kw_h * kw * contract.hours_per_year
        )
        delivered_kwh = (
            kw * contract.hours_per_year * contract.expected_utilisation
        )
        utilisation_revenue = contract.utilisation_payment_per_kwh * delivered_kwh
        revenue = availability_revenue + utilisation_revenue

        # Frequency response cycles in both directions, so throughput is about
        # twice the net energy delivered.
        throughput_factor = 2.0 if contract.service is ServiceType.FREQUENCY_RESPONSE else 1.0
        throughput_kwh = delivered_kwh * throughput_factor
        degradation_cost = throughput_kwh * self._wear_cost_per_kwh()
        energy_cost = (
            throughput_kwh * price * (1.0 / max(self.one_way_efficiency**2, EPS) - 1.0)
        )
        opportunity_cost = 0.0
        if contract.service in (ServiceType.RESERVE_CAPACITY, ServiceType.FREQUENCY_RESPONSE):
            # Capacity held in reserve cannot be cycled for arbitrage. Valued
            # at one forgone round trip per contracted day.
            forgone_kwh = (
                contract.committed_energy_wh / 1000.0 * contract.hours_per_year / 24.0
            )
            opportunity_cost = forgone_kwh * self.arbitrage_value_per_kwh
        soc_cost = self._soc_obligation_cost(contract, state)

        ok, limiting = self.deliverable(contract, state)
        assessment = ServiceAssessment(
            contract=contract,
            annual_revenue=revenue,
            annual_degradation_cost=degradation_cost,
            annual_energy_cost=energy_cost,
            annual_opportunity_cost=opportunity_cost,
            annual_soc_obligation_cost=soc_cost,
            deliverable=ok,
            limiting_constraint=limiting,
            currency=econ.config.currency,
            meta={
                "delivered_kwh": delivered_kwh,
                "throughput_kwh": throughput_kwh,
                "wear_cost_per_kwh": self._wear_cost_per_kwh(),
            },
        )
        parts = [
            f"Availability pays {availability_revenue:,.0f} and utilisation "
            f"{utilisation_revenue:,.0f}, against {degradation_cost:,.0f} of degradation "
            f"on {throughput_kwh:,.0f} kWh of throughput."
        ]
        if opportunity_cost > 0:
            parts.append(
                f"Committing {kw:.0f} kW to reserve forgoes about "
                f"{opportunity_cost:,.0f} of arbitrage margin."
            )
        if soc_cost > 0:
            parts.append(
                f"Holding {contract.required_soc * 100:.0f} % state of charge to stay "
                f"responsive costs {soc_cost:,.0f} of extra calendar ageing."
            )
        if not ok:
            parts.append(
                f"The battery cannot currently meet the commitment: {limiting}."
            )
        assessment.reason = " ".join(parts)
        return assessment

    def rank(
        self,
        contracts: Sequence[ServiceContract],
        state: BatteryState,
        *,
        energy_price_per_kwh: float | None = None,
    ) -> list[ServiceAssessment]:
        """Assess several contracts and return them by margin, best first."""
        results = [
            self.assess(c, state, energy_price_per_kwh=energy_price_per_kwh) for c in contracts
        ]
        results.sort(key=lambda a: (a.deliverable, a.annual_margin), reverse=True)
        return results

    @staticmethod
    def table(assessments: Sequence[ServiceAssessment]) -> str:
        lines = [
            f"{'SERVICE':<22} {'REVENUE':>12} {'DEGRADATION':>12} {'OTHER COST':>12} "
            f"{'MARGIN':>12}  VERDICT",
            "-" * 88,
        ]
        for a in assessments:
            other = a.annual_energy_cost + a.annual_opportunity_cost + a.annual_soc_obligation_cost
            verdict = (
                "provide"
                if a.worthwhile
                else ("undeliverable" if not a.deliverable else "decline")
            )
            lines.append(
                f"{a.contract.label or a.contract.service.value:<22} "
                f"{a.annual_revenue:12,.0f} {a.annual_degradation_cost:12,.0f} "
                f"{other:12,.0f} {a.annual_margin:+12,.0f}  {verdict}"
            )
        return "\n".join(lines)

    # -- peak shaving -------------------------------------------------------

    def peak_shaving_plan(
        self,
        state: BatteryState,
        *,
        load_w: np.ndarray,
        dt_s: float,
        demand_charge_per_kw: float,
        target_peak_w: float | None = None,
    ) -> dict[str, Any]:
        """Find the peak the battery can hold down, and what that is worth.

        Demand charges are billed on the highest interval in the period, so the
        value of shaving is a step function of the peak achieved -- which makes
        this a different problem from arbitrage and worth solving separately.
        """
        load = np.asarray(load_w, dtype=float).ravel()
        if load.size == 0:
            return {"achievable_peak_w": 0.0, "saving": 0.0}
        battery = self.engine.battery
        available_wh = self.engine.constraints.energy_available_wh(state)
        bounds = self.engine.constraints.bounds(state, dt_s)
        dt_h = dt_s / SECONDS_PER_HOUR

        original_peak = float(load.max())
        candidates = np.linspace(load.min(), original_peak, 128)
        achievable = original_peak
        for target in candidates:
            excess = np.clip(load - target, 0.0, None)
            if float(excess.max()) > bounds.max_power_w:
                continue
            if float(np.sum(excess) * dt_h) > available_wh:
                continue
            achievable = float(target)
            break

        if target_peak_w is not None:
            achievable = max(achievable, target_peak_w)
        reduction_kw = (original_peak - achievable) / 1000.0
        energy_wh = float(np.sum(np.clip(load - achievable, 0.0, None)) * dt_h)
        saving = reduction_kw * demand_charge_per_kw
        degradation = energy_wh / 1000.0 * self._wear_cost_per_kwh()
        return {
            "original_peak_w": original_peak,
            "achievable_peak_w": achievable,
            "reduction_kw": reduction_kw,
            "energy_required_wh": energy_wh,
            "demand_charge_saving": saving,
            "degradation_cost": degradation,
            "net_saving": saving - degradation,
            "energy_available_wh": available_wh,
            "power_limit_w": bounds.max_power_w,
            "currency": self.engine.economics.config.currency,
        }


def typical_contracts(power_w: float) -> list[ServiceContract]:
    """A representative set of contracts for demonstration and testing.

    The payment levels are illustrative orders of magnitude for a GB-style
    market, **not** current market prices, and must be replaced with real terms
    before any commercial decision.
    """
    return [
        ServiceContract(
            service=ServiceType.FREQUENCY_RESPONSE,
            committed_power_w=power_w,
            availability_payment_per_kw_h=0.006,
            utilisation_payment_per_kwh=0.0,
            expected_utilisation=0.04,
            hours_per_year=8000.0,
            required_soc=0.55,
            max_duration_s=900.0,
            label="dynamic frequency response",
        ),
        ServiceContract(
            service=ServiceType.RESERVE_CAPACITY,
            committed_power_w=power_w,
            availability_payment_per_kw_h=0.002,
            utilisation_payment_per_kwh=0.12,
            expected_utilisation=0.01,
            hours_per_year=4000.0,
            required_soc=0.75,
            max_duration_s=7200.0,
            label="reserve capacity",
        ),
        ServiceContract(
            service=ServiceType.DEMAND_RESPONSE,
            committed_power_w=power_w,
            availability_payment_per_kw_h=0.0,
            utilisation_payment_per_kwh=0.45,
            expected_utilisation=0.02,
            hours_per_year=600.0,
            max_duration_s=3600.0,
            label="demand response",
        ),
    ]


__all__ = [
    "GridServiceOptimiser",
    "ServiceContract",
    "ServiceAssessment",
    "ServiceType",
    "typical_contracts",
]
