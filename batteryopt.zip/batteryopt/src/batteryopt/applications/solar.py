"""Solar-plus-storage optimisation (specification section 17).

.. code-block:: text

    SOLAR -> BATTERYOPT -> BATTERY -> LOAD / GRID

The decision at every interval is where each watt of generation should go, and
the ranking is set by prices rather than by a rule of thumb:

============================  ==========================================
Destination                   Value of one kWh sent there
============================  ==========================================
Direct to load                the import price avoided
Into the battery, for load    import price avoided later, minus round-trip
                              loss and battery wear
Export to grid                the export price
Curtailed                     nothing
============================  ==========================================

Self-consumption usually wins because the import/export spread is wide -- a
typical domestic tariff imports at three times what it exports -- but "usually"
is not "always", and the cases where it loses are exactly the ones an operator
cares about: a battery already full, an export tariff with a peak, or a wear
cost that exceeds the spread on an old pack.

The planner therefore evaluates the ranking numerically at each interval rather
than hard-coding self-consumption, and reports the split so the result can be
checked.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np

from ..core.numerics import EPS, clamp
from ..core.units import SECONDS_PER_HOUR
from ..economics.prices import Tariff
from ..models.state import BatteryState
from ..optimisation.engine import OptimisationEngine
from .arbitrage import ArbitrageOptimiser


@dataclass(frozen=True, slots=True)
class EnergyFlows:
    """Where the energy went over one interval, in watt-hours."""

    solar_to_load_wh: float = 0.0
    solar_to_battery_wh: float = 0.0
    solar_to_grid_wh: float = 0.0
    solar_curtailed_wh: float = 0.0
    battery_to_load_wh: float = 0.0
    battery_to_grid_wh: float = 0.0
    grid_to_load_wh: float = 0.0
    grid_to_battery_wh: float = 0.0

    @property
    def solar_total_wh(self) -> float:
        return (
            self.solar_to_load_wh
            + self.solar_to_battery_wh
            + self.solar_to_grid_wh
            + self.solar_curtailed_wh
        )

    @property
    def self_consumption_ratio(self) -> float:
        """Fraction of generation used on site rather than exported or curtailed."""
        total = self.solar_total_wh
        if total <= EPS:
            return 0.0
        return (self.solar_to_load_wh + self.solar_to_battery_wh) / total

    @property
    def self_sufficiency_ratio(self) -> float:
        """Fraction of load met without importing."""
        load = self.solar_to_load_wh + self.battery_to_load_wh + self.grid_to_load_wh
        if load <= EPS:
            return 0.0
        return (self.solar_to_load_wh + self.battery_to_load_wh) / load

    def __add__(self, other: "EnergyFlows") -> "EnergyFlows":
        return EnergyFlows(
            solar_to_load_wh=self.solar_to_load_wh + other.solar_to_load_wh,
            solar_to_battery_wh=self.solar_to_battery_wh + other.solar_to_battery_wh,
            solar_to_grid_wh=self.solar_to_grid_wh + other.solar_to_grid_wh,
            solar_curtailed_wh=self.solar_curtailed_wh + other.solar_curtailed_wh,
            battery_to_load_wh=self.battery_to_load_wh + other.battery_to_load_wh,
            battery_to_grid_wh=self.battery_to_grid_wh + other.battery_to_grid_wh,
            grid_to_load_wh=self.grid_to_load_wh + other.grid_to_load_wh,
            grid_to_battery_wh=self.grid_to_battery_wh + other.grid_to_battery_wh,
        )

    def as_dict(self) -> dict[str, float]:
        return {
            "solar_to_load_wh": self.solar_to_load_wh,
            "solar_to_battery_wh": self.solar_to_battery_wh,
            "solar_to_grid_wh": self.solar_to_grid_wh,
            "solar_curtailed_wh": self.solar_curtailed_wh,
            "battery_to_load_wh": self.battery_to_load_wh,
            "battery_to_grid_wh": self.battery_to_grid_wh,
            "grid_to_load_wh": self.grid_to_load_wh,
            "grid_to_battery_wh": self.grid_to_battery_wh,
            "self_consumption_ratio": self.self_consumption_ratio,
            "self_sufficiency_ratio": self.self_sufficiency_ratio,
        }


@dataclass(slots=True)
class SolarPlan:
    """Battery command plus the resulting energy flows and economics."""

    battery_power_w: float
    schedule_w: tuple[float, ...]
    dt_s: float
    flows: EnergyFlows
    grid_cost: float
    export_revenue: float
    degradation_cost: float
    currency: str = "GBP"
    reason: str = ""
    meta: dict[str, Any] = field(default_factory=dict)

    @property
    def net_cost(self) -> float:
        return self.grid_cost - self.export_revenue + self.degradation_cost

    def summary(self) -> str:
        return (
            f"battery {self.battery_power_w / 1000.0:+.1f} kW, self-consumption "
            f"{self.flows.self_consumption_ratio * 100:.0f} %, self-sufficiency "
            f"{self.flows.self_sufficiency_ratio * 100:.0f} %, net cost "
            f"{self.net_cost:.2f} {self.currency}"
        )

    def as_dict(self) -> dict[str, Any]:
        return {
            "battery_power_w": self.battery_power_w,
            "schedule_w": list(self.schedule_w),
            "dt_s": self.dt_s,
            "flows": self.flows.as_dict(),
            "grid_cost": self.grid_cost,
            "export_revenue": self.export_revenue,
            "degradation_cost": self.degradation_cost,
            "net_cost": self.net_cost,
            "currency": self.currency,
            "reason": self.reason,
        }


class SolarOptimiser:
    """Co-optimises PV, storage, load and the grid connection."""

    def __init__(self, engine: OptimisationEngine, arbitrage: ArbitrageOptimiser | None = None) -> None:
        self.engine = engine
        self.arbitrage = arbitrage or ArbitrageOptimiser(engine)

    # -- ranking ------------------------------------------------------------

    def destination_values(
        self, state: BatteryState, tariff: Tariff, t_s: float, *, horizon_s: float = 24 * 3600.0
    ) -> dict[str, float]:
        """Value of sending one kWh of generation to each destination."""
        import_now = float(np.atleast_1d(tariff.import_at(t_s))[0])
        export_now = float(np.atleast_1d(tariff.export_at(t_s))[0])
        eta = self.arbitrage.one_way_efficiency(state)
        wear = self.arbitrage.wear_cost_per_kwh()
        stored_value = self.arbitrage.marginal_value(
            state, tariff.import_price, horizon_s=horizon_s
        )
        return {
            "load": import_now,
            "battery": max(0.0, stored_value * eta - wear),
            "grid": export_now,
            "curtail": 0.0,
        }

    # -- planning -----------------------------------------------------------

    def plan(
        self,
        state: BatteryState,
        *,
        tariff: Tariff,
        solar_w: float | np.ndarray,
        load_w: float | np.ndarray,
        horizon_s: float = 24 * 3600.0,
        dt_s: float = 1800.0,
        ambient_c: float | None = None,
        export_limit_w: float | None = None,
    ) -> SolarPlan:
        """Schedule the battery against a PV and load forecast."""
        engine = self.engine
        battery = engine.battery
        n = max(1, int(round(horizon_s / dt_s)))

        solar = np.broadcast_to(np.atleast_1d(np.asarray(solar_w, dtype=float)), (n,)).astype(
            float
        ) if np.size(solar_w) in (1, n) else np.interp(
            np.linspace(0, 1, n),
            np.linspace(0, 1, np.size(solar_w)),
            np.asarray(solar_w, dtype=float).ravel(),
        )
        load = np.broadcast_to(np.atleast_1d(np.asarray(load_w, dtype=float)), (n,)).astype(
            float
        ) if np.size(load_w) in (1, n) else np.interp(
            np.linspace(0, 1, n),
            np.linspace(0, 1, np.size(load_w)),
            np.asarray(load_w, dtype=float).ravel(),
        )

        # Net site load after PV: positive means the site needs power, negative
        # means it has a surplus. The battery is scheduled against this, which
        # is what makes self-consumption emerge from the economics rather than
        # being imposed as a rule.
        net_load = load - solar

        plan = self.arbitrage.plan(
            state,
            tariff=tariff,
            load_w=np.clip(net_load, 0.0, None),
            solar_w=np.clip(-net_load, 0.0, None),
            horizon_s=horizon_s,
            dt_s=dt_s,
            ambient_c=ambient_c,
        )
        schedule = np.asarray(plan.schedule_w, dtype=float)
        if schedule.size != n:
            schedule = np.resize(schedule, n)

        flows, grid_cost, export_revenue = self._account(
            schedule, solar, load, tariff, state.timestamp, dt_s, export_limit_w
        )

        values = self.destination_values(state, tariff, state.timestamp, horizon_s=horizon_s)
        ranked = sorted(values.items(), key=lambda kv: kv[1], reverse=True)
        reason = (
            "Generation is worth "
            + ", ".join(f"{v:.3f}/kWh to {k}" for k, v in ranked)
            + f". {plan.reason}"
        )
        if flows.solar_curtailed_wh > 1.0:
            reason += (
                f" {flows.solar_curtailed_wh / 1000.0:.1f} kWh of generation is curtailed: "
                "the battery is full, the load is satisfied and the export limit is reached."
            )

        return SolarPlan(
            battery_power_w=float(schedule[0]) if schedule.size else 0.0,
            schedule_w=tuple(float(p) for p in schedule),
            dt_s=dt_s,
            flows=flows,
            grid_cost=grid_cost,
            export_revenue=export_revenue,
            degradation_cost=plan.expected_degradation_cost,
            currency=tariff.currency,
            reason=reason,
            meta={
                "destination_values": values,
                "marginal_energy_value_per_kwh": plan.marginal_energy_value_per_kwh,
            },
        )

    def _account(
        self,
        schedule: np.ndarray,
        solar: np.ndarray,
        load: np.ndarray,
        tariff: Tariff,
        start_time_s: float,
        dt_s: float,
        export_limit_w: float | None,
    ) -> tuple[EnergyFlows, float, float]:
        """Attribute every watt-hour to a source and a destination."""
        dt_h = dt_s / SECONDS_PER_HOUR
        total = EnergyFlows()
        grid_cost = 0.0
        export_revenue = 0.0
        times = start_time_s + np.arange(schedule.size) * dt_s
        import_price = np.asarray(tariff.import_at(times), dtype=float)
        export_price = np.asarray(tariff.export_at(times), dtype=float)

        for k in range(schedule.size):
            pv = max(0.0, float(solar[k]))
            demand = max(0.0, float(load[k]))
            battery = float(schedule[k])  # positive = discharge

            # Priority of use, computed rather than assumed: PV serves load
            # first because avoiding an import is worth the import price, which
            # is above every other destination on a typical tariff.
            pv_to_load = min(pv, demand)
            remaining_pv = pv - pv_to_load
            remaining_load = demand - pv_to_load

            battery_charge = max(0.0, -battery)
            pv_to_battery = min(remaining_pv, battery_charge)
            remaining_pv -= pv_to_battery
            grid_to_battery = battery_charge - pv_to_battery

            battery_discharge = max(0.0, battery)
            battery_to_load = min(battery_discharge, remaining_load)
            remaining_load -= battery_to_load
            battery_to_grid = battery_discharge - battery_to_load

            export = remaining_pv + battery_to_grid
            curtailed = 0.0
            if export_limit_w is not None and export > export_limit_w:
                curtailed = export - export_limit_w
                # Curtail generation before storage: stored energy has already
                # paid its round-trip cost.
                pv_curtailed = min(curtailed, remaining_pv)
                remaining_pv -= pv_curtailed
                battery_to_grid -= curtailed - pv_curtailed
                export = export_limit_w
                curtailed = pv_curtailed

            total = total + EnergyFlows(
                solar_to_load_wh=pv_to_load * dt_h,
                solar_to_battery_wh=pv_to_battery * dt_h,
                solar_to_grid_wh=remaining_pv * dt_h,
                solar_curtailed_wh=curtailed * dt_h,
                battery_to_load_wh=battery_to_load * dt_h,
                battery_to_grid_wh=max(0.0, battery_to_grid) * dt_h,
                grid_to_load_wh=remaining_load * dt_h,
                grid_to_battery_wh=grid_to_battery * dt_h,
            )
            grid_cost += (remaining_load + grid_to_battery) * dt_h / 1000.0 * import_price[k]
            export_revenue += export * dt_h / 1000.0 * export_price[k]

        return total, grid_cost, export_revenue

    # -- comparison ---------------------------------------------------------

    def compare_with_no_battery(
        self,
        state: BatteryState,
        *,
        tariff: Tariff,
        solar_w: np.ndarray,
        load_w: np.ndarray,
        horizon_s: float = 24 * 3600.0,
        dt_s: float = 1800.0,
    ) -> dict[str, Any]:
        """Value the battery adds over PV alone, which is the number that pays for it."""
        with_battery = self.plan(
            state,
            tariff=tariff,
            solar_w=solar_w,
            load_w=load_w,
            horizon_s=horizon_s,
            dt_s=dt_s,
        )
        n = len(with_battery.schedule_w)
        zero = np.zeros(n)
        solar = np.resize(np.asarray(solar_w, dtype=float).ravel(), n)
        load = np.resize(np.asarray(load_w, dtype=float).ravel(), n)
        flows, grid_cost, export_revenue = self._account(
            zero, solar, load, tariff, state.timestamp, dt_s, None
        )
        baseline_net = grid_cost - export_revenue
        return {
            "with_battery_net_cost": with_battery.net_cost,
            "without_battery_net_cost": baseline_net,
            "saving": baseline_net - with_battery.net_cost,
            "with_battery_self_consumption": with_battery.flows.self_consumption_ratio,
            "without_battery_self_consumption": flows.self_consumption_ratio,
            "currency": tariff.currency,
        }


def synthetic_pv_profile(
    *,
    peak_w: float,
    n: int,
    dt_s: float,
    start_hour: float = 0.0,
    cloudiness: float = 0.15,
    seed: int = 0,
) -> np.ndarray:
    """A clear-sky-shaped PV profile with correlated cloud attenuation.

    Explicitly synthetic: a raised-cosine day multiplied by a smoothed random
    attenuation. Used for demonstrations and tests, never presented as measured
    generation.
    """
    rng = np.random.default_rng(seed)
    hours = start_hour + np.arange(n) * dt_s / SECONDS_PER_HOUR
    hod = hours % 24.0
    clear = np.clip(np.sin(np.pi * (hod - 6.0) / 12.0), 0.0, None) ** 1.4
    cloud = np.ones(n)
    for k in range(1, n):
        cloud[k] = clamp(0.9 * cloud[k - 1] + 0.1 * rng.uniform(1.0 - 2.0 * cloudiness, 1.0), 0.2, 1.0)
    return peak_w * clear * cloud


def synthetic_load_profile(
    *, base_w: float, peak_w: float, n: int, dt_s: float, start_hour: float = 0.0, seed: int = 0
) -> np.ndarray:
    """A domestic-shaped load profile: overnight base, morning and evening peaks."""
    rng = np.random.default_rng(seed)
    hours = start_hour + np.arange(n) * dt_s / SECONDS_PER_HOUR
    hod = hours % 24.0
    shape = (
        1.0
        + 0.9 * np.exp(-0.5 * ((hod - 7.5) / 1.1) ** 2)
        + 1.6 * np.exp(-0.5 * ((hod - 18.5) / 1.8) ** 2)
    )
    noise = 1.0 + 0.12 * rng.standard_normal(n)
    return np.clip(base_w * shape * noise, 0.0, peak_w)


__all__ = [
    "SolarOptimiser",
    "SolarPlan",
    "EnergyFlows",
    "synthetic_pv_profile",
    "synthetic_load_profile",
]
