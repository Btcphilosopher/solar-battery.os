"""Energy arbitrage (specification section 16).

.. code-block:: text

    ELECTRICITY PRICE + LOAD + SOLAR + BATTERY SOC + BATTERY HEALTH
                                |
                        CHARGE / HOLD / DISCHARGE

The section's warning is the design constraint: **do not simply discharge
whenever prices are high.** Two things stop that being the right rule.

*The spread has to clear the cost of trading.* A round trip loses energy twice
to conversion and once to the cooling it provokes, and it consumes battery life
that has a known replacement cost. The break-even spread is therefore

.. code-block:: text

    spread_min = price / eta_rt - price + wear_per_kwh

which for a typical lithium asset is several pence per kWh. Any trade tighter
than that loses money however attractive the headline price looks.

*The future value of stored energy matters.* Discharging into a 40 p peak is
wrong if a 90 p peak is coming in four hours and the pack cannot be refilled in
between. This is what the value function from the dynamic programme provides,
and it is why the arbitrage planner exposes the marginal value of stored energy
as a first-class output rather than an internal detail.

Storage is not free either
--------------------------
One behaviour surprises people and is worth stating plainly, because it is a
real result and not a modelling artefact: with **no** spread worth trading, the
optimiser will still often prefer to sit at a *low* state of charge rather than
a middling one. Calendar ageing rises exponentially with state of charge, so
holding a large pack at 40 % costs measurably more battery life per day than
holding it near empty -- and if the stored energy has no arbitrage value, that
cost buys nothing.

This is correct, and it is also incomplete on its own: a pack sitting empty
cannot serve an unexpected load, and refilling it costs round-trip losses that a
short horizon does not see. Operators who need availability should express it --
as a state-of-charge reserve on the constraint set, or as a reserve-capacity
service in :mod:`batteryopt.applications.grid_services` -- rather than relying on
the optimiser to guess. :attr:`ArbitragePlan.storage_ageing_saving` reports the
calendar-ageing saving explicitly whenever it, rather than the price spread, is
what drove the recommendation.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any

import numpy as np

from ..core.numerics import EPS
from ..core.units import SECONDS_PER_HOUR, SECONDS_PER_YEAR
from ..economics.prices import PriceCurve, Tariff
from ..models.state import BatteryState
from ..optimisation.engine import OptimisationEngine
from ..optimisation.methods.dynamic_programming import DynamicProgrammingMethod
from ..optimisation.problem import Demand


class ArbitrageAction(str, Enum):
    CHARGE = "CHARGE"
    HOLD = "HOLD"
    DISCHARGE = "DISCHARGE"


@dataclass(slots=True)
class ArbitragePlan:
    """The immediate action, the schedule behind it, and the economics."""

    action: ArbitrageAction
    power_w: float
    #: Full planned power schedule over the horizon, W.
    schedule_w: tuple[float, ...]
    dt_s: float
    #: Marginal value of a kWh stored in the battery right now.
    marginal_energy_value_per_kwh: float
    #: Minimum price spread that makes a round trip worthwhile.
    break_even_spread_per_kwh: float
    #: Spread actually available over the horizon.
    available_spread_per_kwh: float
    expected_revenue: float
    expected_degradation_cost: float
    expected_energy_cost: float
    cycles_planned: float
    #: Calendar-ageing cost avoided over the horizon by holding a lower mean
    #: state of charge than the present one, in currency. Positive means the
    #: plan is partly motivated by storage health rather than by price.
    storage_ageing_saving: float = 0.0
    currency: str = "GBP"
    reason: str = ""
    meta: dict[str, Any] = field(default_factory=dict)

    @property
    def net_value(self) -> float:
        return self.expected_revenue - self.expected_energy_cost - self.expected_degradation_cost

    @property
    def worth_trading(self) -> bool:
        return self.available_spread_per_kwh > self.break_even_spread_per_kwh

    def summary(self) -> str:
        return (
            f"{self.action.value} {abs(self.power_w) / 1000.0:.0f} kW  "
            f"spread {self.available_spread_per_kwh:.3f} vs break-even "
            f"{self.break_even_spread_per_kwh:.3f} {self.currency}/kWh  "
            f"net {self.net_value:+.2f} {self.currency}"
        )

    def as_dict(self) -> dict[str, Any]:
        return {
            "action": self.action.value,
            "power_w": self.power_w,
            "schedule_w": list(self.schedule_w),
            "dt_s": self.dt_s,
            "marginal_energy_value_per_kwh": self.marginal_energy_value_per_kwh,
            "break_even_spread_per_kwh": self.break_even_spread_per_kwh,
            "available_spread_per_kwh": self.available_spread_per_kwh,
            "expected_revenue": self.expected_revenue,
            "expected_energy_cost": self.expected_energy_cost,
            "expected_degradation_cost": self.expected_degradation_cost,
            "net_value": self.net_value,
            "cycles_planned": self.cycles_planned,
            "storage_ageing_saving": self.storage_ageing_saving,
            "worth_trading": self.worth_trading,
            "currency": self.currency,
            "reason": self.reason,
        }


class ArbitrageOptimiser:
    """Schedules charging and discharging against a price forecast."""

    def __init__(
        self,
        engine: OptimisationEngine,
        *,
        round_trip_efficiency: float = 0.90,
        horizon_s: float = 24 * 3600.0,
        dt_s: float = 1800.0,
        soc_grid_points: int = 81,
    ) -> None:
        self.engine = engine
        #: Fallback round-trip efficiency, used only when the battery model
        #: cannot be evaluated. In normal operation the efficiency is measured
        #: from the model at the present state -- see :meth:`one_way_efficiency`.
        #: A hard-coded value here is dangerous rather than merely inaccurate:
        #: if the assumed efficiency is *worse* than the real one, stored energy
        #: is systematically undervalued, and the optimiser liquidates the
        #: battery even when there is no spread to trade.
        self.round_trip_efficiency = round_trip_efficiency
        self.horizon_s = horizon_s
        self.dt_s = dt_s
        self.soc_grid_points = soc_grid_points

    # -- economics ----------------------------------------------------------

    def one_way_efficiency(self, state: BatteryState, *, c_rate: float = 0.4) -> float:
        """One-way conversion efficiency at the present state, from the model.

        Measured as terminal voltage over open-circuit voltage at a
        representative rate: the fraction of stored energy that reaches the
        terminals. Reading this off the model rather than assuming it is what
        keeps the marginal value of stored energy consistent with the revenue
        the optimiser will actually book for selling it.
        """
        battery = self.engine.battery
        ecm = battery.electrical
        current = max(c_rate * battery.capacity, EPS)
        response = ecm.evaluate(
            soc=state.soc,
            current_a=current,
            temperature_c=state.temperature_c,
            resistance_growth=state.degradation.resistance_growth,
            hysteresis=state.hysteresis,
        )
        if response.ocv_v <= EPS:
            return self.round_trip_efficiency**0.5
        return float(min(1.0, max(0.5, response.voltage_v / response.ocv_v)))

    def wear_cost_per_kwh(self) -> float:
        """Marginal degradation cost of moving one kWh through the battery."""
        battery = self.engine.battery
        chem = battery.chemistry.degradation
        state = battery.degradation_state
        a_eq = max(state.a_eq_efc, 0.0) + chem.formation_efc
        fade_per_efc = chem.a_cycle * chem.z_cycle * a_eq ** (chem.z_cycle - 1.0)
        cost_per_efc = self.engine.economics.degradation_cost(
            fade_per_efc,
            remaining_years=self.engine.objective.config.remaining_life_years,
        )
        kwh_per_efc = 2.0 * max(battery.nominal_energy_wh / 1000.0, EPS)
        return cost_per_efc / kwh_per_efc

    def break_even_spread(
        self, buy_price_per_kwh: float, *, state: BatteryState | None = None
    ) -> float:
        """Minimum peak-to-trough spread that makes a round trip profitable."""
        if state is not None:
            eta = self.one_way_efficiency(state) ** 2
        else:
            eta = max(self.round_trip_efficiency, EPS)
        conversion = buy_price_per_kwh * (1.0 / max(eta, EPS) - 1.0)
        return conversion + self.wear_cost_per_kwh()

    def marginal_value(
        self, state: BatteryState, prices: PriceCurve, *, horizon_s: float | None = None
    ) -> float:
        """Marginal value of a stored kWh, from the forward price shape.

        The value of energy in the battery is not the current price -- it is
        what that energy can be sold for later, converted into the same units
        as the trades the optimiser is pricing. Stored energy is *internal*;
        revenue is earned on *terminal* energy, so the future price is derated
        by one-way discharge efficiency.

        The wear cost is deliberately **not** subtracted here. The dynamic
        programme already charges wear on every transition, including the one
        that would sell this energy. Subtracting it again would make holding
        look worse than trading by exactly the amount that is supposed to
        discourage trading -- and the symptom is unmistakable: under a flat
        tariff, where no arbitrage exists at all, the optimiser liquidates the
        battery. Under a flat tariff the correct answer is to hold, and it
        falls out of this formulation without a special case.
        """
        horizon = horizon_s or self.horizon_s
        grid = state.timestamp + np.linspace(0.0, horizon, 128)
        forward = np.asarray(prices.at(grid), dtype=float)
        best_future = float(np.quantile(forward, 0.9))
        return max(0.0, best_future * self.one_way_efficiency(state))

    # -- planning -----------------------------------------------------------

    def plan(
        self,
        state: BatteryState,
        *,
        tariff: Tariff,
        load_w: float | np.ndarray | None = None,
        solar_w: float | np.ndarray | None = None,
        horizon_s: float | None = None,
        dt_s: float | None = None,
        ambient_c: float | None = None,
    ) -> ArbitragePlan:
        horizon = horizon_s or self.horizon_s
        dt = dt_s or self.dt_s
        engine = self.engine
        battery = engine.battery

        demand = None
        if load_w is not None:
            demand = Demand(power_w=load_w, firm=False, label="site load")

        marginal = self.marginal_value(state, tariff.import_price, horizon_s=horizon)
        problem = engine.build_problem(
            state,
            demand=demand,
            horizon_s=horizon,
            dt_s=dt,
            ambient_c=ambient_c,
            solar_w=solar_w,
            terminal_energy_value_per_kwh=marginal,
        )
        problem.tariff = tariff

        method = DynamicProgrammingMethod(
            n_soc=self.soc_grid_points, terminal_value_per_kwh=marginal
        )
        result = method.solve(problem)

        schedule = np.asarray(result.power_w, dtype=float)
        first = float(schedule[0]) if schedule.size else 0.0
        if first < -100.0:
            action = ArbitrageAction.CHARGE
        elif first > 100.0:
            action = ArbitrageAction.DISCHARGE
        else:
            action = ArbitrageAction.HOLD

        times = state.timestamp + np.arange(schedule.size) * dt
        import_price = np.asarray(tariff.import_at(times), dtype=float)
        export_price = (
            np.asarray(tariff.export_at(times), dtype=float)
            if tariff.export_price is not None
            else import_price
        )
        dt_h = dt / SECONDS_PER_HOUR
        charged_kwh = np.clip(-schedule, 0.0, None) * dt_h / 1000.0
        discharged_kwh = np.clip(schedule, 0.0, None) * dt_h / 1000.0
        energy_cost = float(np.sum(charged_kwh * import_price))
        revenue = float(np.sum(discharged_kwh * export_price))
        throughput_kwh = float(np.sum(charged_kwh + discharged_kwh))
        cycles = throughput_kwh / (2.0 * max(battery.nominal_energy_wh / 1000.0, EPS))
        degradation_cost = throughput_kwh * self.wear_cost_per_kwh()

        spread = float(import_price.max() - import_price.min())
        break_even = self.break_even_spread(float(import_price.min()), state=state)
        ageing_saving = self._calendar_saving(state, schedule, dt)

        if action is ArbitrageAction.HOLD:
            if spread <= break_even:
                reason = (
                    f"Holding: the available spread of {spread:.3f} "
                    f"{tariff.currency}/kWh over the horizon does not clear the "
                    f"{break_even:.3f} needed to cover conversion losses "
                    f"({(1.0 / self.one_way_efficiency(state) ** 2 - 1.0) * 100:.1f} % of the "
                    f"purchase price) plus {self.wear_cost_per_kwh():.3f} of battery "
                    "wear. Trading this spread would lose money."
                )
            else:
                reason = (
                    "Holding now: the spread is worth trading, but the schedule places "
                    "the trade later in the horizon where the price is more favourable."
                )
        elif action is ArbitrageAction.CHARGE:
            reason = (
                f"Charging at {import_price[0]:.3f} {tariff.currency}/kWh against a "
                f"marginal stored-energy value of {marginal:.3f}. The schedule expects "
                f"to recover {revenue:.2f} against {energy_cost:.2f} spent and "
                f"{degradation_cost:.2f} of battery life consumed."
            )
        else:
            reason = (
                f"Discharging at {export_price[0]:.3f} {tariff.currency}/kWh, above the "
                f"marginal stored-energy value of {marginal:.3f}. Selling now beats "
                "holding the energy for later."
            )
            if spread <= break_even and ageing_saving > 0.0:
                reason = (
                    f"Discharging despite a spread of only {spread:.3f} "
                    f"{tariff.currency}/kWh: the driver here is storage health, not "
                    f"arbitrage. Holding {state.soc * 100:.0f} % state of charge over the "
                    f"horizon would cost about {ageing_saving:.2f} {tariff.currency} more "
                    "in calendar ageing than the planned lower average, because calendar "
                    "ageing rises exponentially with state of charge. If the asset needs "
                    "to stay available, set a state-of-charge reserve on the constraint "
                    "set rather than relying on the price signal to keep it charged."
                )

        return ArbitragePlan(
            action=action,
            power_w=first,
            schedule_w=tuple(float(p) for p in schedule),
            dt_s=dt,
            marginal_energy_value_per_kwh=marginal,
            break_even_spread_per_kwh=break_even,
            available_spread_per_kwh=spread,
            expected_revenue=revenue,
            expected_energy_cost=energy_cost,
            expected_degradation_cost=degradation_cost,
            cycles_planned=cycles,
            storage_ageing_saving=ageing_saving,
            currency=tariff.currency,
            reason=reason,
            meta={"method": result.method, "diagnostics": result.diagnostics},
        )

    def _calendar_saving(
        self, state: BatteryState, schedule: np.ndarray, dt_s: float
    ) -> float:
        """Calendar-ageing cost avoided by the plan's lower mean state of charge."""
        battery = self.engine.battery
        if schedule.size == 0:
            return 0.0
        capacity_ah = max(battery.capacity, EPS)
        soc = state.soc
        socs: list[float] = []
        for power in schedule:
            current = battery.electrical.current_for_power(
                float(power),
                soc=soc,
                temperature_c=state.temperature_c,
                resistance_growth=state.degradation.resistance_growth,
            )
            soc = float(
                np.clip(
                    soc + battery.electrical.soc_delta(current, dt_s, capacity_ah=capacity_ah),
                    0.0,
                    1.0,
                )
            )
            socs.append(soc)
        mean_soc = float(np.mean(socs))
        model = battery.degradation
        chem = battery.chemistry.degradation
        stress_hold = model.calendar_stress(soc=state.soc, temperature_c=state.temperature_c)
        stress_plan = model.calendar_stress(soc=mean_soc, temperature_c=state.temperature_c)
        t_eq = max(battery.degradation_state.t_eq_years, 0.0) + chem.formation_years
        per_year = chem.a_calendar * chem.z_calendar * t_eq ** (chem.z_calendar - 1.0)
        years = dt_s * schedule.size / SECONDS_PER_YEAR
        delta_fade = per_year * years * (stress_hold - stress_plan)
        return max(
            0.0,
            self.engine.economics.degradation_cost(
                delta_fade,
                remaining_years=self.engine.objective.config.remaining_life_years,
            ),
        )

    def value_of_spread(self, spread_per_kwh: float, *, energy_kwh: float) -> float:
        """Net value of trading a given spread on a given quantity of energy."""
        return energy_kwh * (
            spread_per_kwh - self.wear_cost_per_kwh()
        ) * self.round_trip_efficiency


__all__ = ["ArbitrageOptimiser", "ArbitragePlan", "ArbitrageAction"]
