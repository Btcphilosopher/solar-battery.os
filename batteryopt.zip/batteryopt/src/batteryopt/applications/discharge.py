"""Smart discharge (specification section 8).

"Avoid unnecessarily aggressive discharge where a better operating point
exists." The decision is not usually *whether* to serve the load -- that is
generally firm -- but how to serve it: how much of it to take from the battery
now, how much reserve to protect, and what to do when the load exceeds what the
battery should sensibly deliver.

Three things distinguish this from "just discharge at the load":

* **Reserve protection.** A reserve is only worth having if something enforces
  it. The planner treats it as a soft floor whose value is the cost of failing
  the *next* commitment, not zero.
* **Load splitting.** Where the load is larger than the economically sensible
  battery contribution, the planner returns the split explicitly -- battery
  share and residual -- rather than either saturating the pack or silently
  failing to serve.
* **Future demand.** A discharge that is fine on its own can be the wrong
  choice if a larger demand is coming; the planner accepts a forecast of future
  demand and values retained energy accordingly.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import numpy as np

from ..core.numerics import EPS, clamp
from ..core.units import SECONDS_PER_HOUR
from ..economics.prices import Tariff
from ..models.state import BatteryState
from ..optimisation.engine import OptimisationEngine
from ..optimisation.problem import Demand, Recommendation


@dataclass(slots=True)
class DischargePlan:
    """How to serve a load from the battery over the next interval."""

    #: Power the battery should supply, W.
    battery_power_w: float
    #: Load the battery is not covering, W. The caller must source this
    #: elsewhere (grid, generator, load shedding) or accept it as unserved.
    residual_load_w: float
    cooling_requirement: float
    reserve_protected_wh: float
    estimated_efficiency: float
    estimated_degradation: float
    estimated_cost: float
    limiting_constraint: str | None
    #: Discharge power still available after this interval, W.
    remaining_capability_w: float
    currency: str = "GBP"
    reason: str = ""
    recommendation: Recommendation | None = None
    meta: dict[str, Any] = field(default_factory=dict)

    @property
    def fully_served(self) -> bool:
        return self.residual_load_w <= 1.0

    def summary(self) -> str:
        return (
            f"battery {self.battery_power_w / 1000.0:.1f} kW"
            + (
                f", residual {self.residual_load_w / 1000.0:.1f} kW"
                if not self.fully_served
                else ""
            )
            + f", cooling {self.cooling_requirement * 100:.0f} %, "
            f"limited by {self.limiting_constraint or 'nothing'}"
        )

    def as_dict(self) -> dict[str, Any]:
        return {
            "battery_power_w": self.battery_power_w,
            "residual_load_w": self.residual_load_w,
            "cooling_requirement": self.cooling_requirement,
            "reserve_protected_wh": self.reserve_protected_wh,
            "estimated_efficiency": self.estimated_efficiency,
            "estimated_degradation": self.estimated_degradation,
            "estimated_cost": self.estimated_cost,
            "limiting_constraint": self.limiting_constraint,
            "remaining_capability_w": self.remaining_capability_w,
            "fully_served": self.fully_served,
            "reason": self.reason,
        }


class DischargePlanner:
    """Chooses the battery's contribution to a load."""

    def __init__(self, engine: OptimisationEngine) -> None:
        self.engine = engine

    def plan(
        self,
        state: BatteryState,
        *,
        load_w: float | np.ndarray,
        horizon_s: float = 900.0,
        dt_s: float = 60.0,
        reserve_soc: float | None = None,
        firm: bool = True,
        future_demand_wh: float = 0.0,
        tariff: Tariff | None = None,
        ambient_c: float | None = None,
        objective: Any = None,
    ) -> DischargePlan:
        """Decide how much of ``load_w`` the battery should supply now."""
        battery = self.engine.battery
        constraints = self.engine.constraints

        # Energy the battery must keep back for what is coming next. Retained
        # energy is valued at what it would cost to fail the next commitment,
        # which is what stops the optimiser spending it on a cheap load now.
        terminal_value = None
        if future_demand_wh > 0.0:
            headroom = constraints.energy_available_wh(state)
            scarcity = clamp(future_demand_wh / max(headroom, EPS), 0.0, 3.0)
            base = (
                float(np.atleast_1d(tariff.import_at(state.timestamp))[0])
                if tariff is not None
                else self.engine.economics.config.default_energy_value_per_kwh
            )
            terminal_value = base * (1.0 + scarcity)

        problem = self.engine.build_problem(
            state,
            demand=Demand(power_w=load_w, firm=firm, label="load"),
            horizon_s=horizon_s,
            dt_s=dt_s,
            ambient_c=ambient_c,
            terminal_energy_value_per_kwh=terminal_value,
            objective=objective,
        )
        if reserve_soc is not None:
            problem.constraints.soc_reserve = max(
                problem.constraints.soc_reserve, reserve_soc
            )

        recommendation = self.engine.optimise(problem)
        requested = float(np.atleast_1d(load_w).flat[0])
        supplied = max(0.0, recommendation.recommended_power_w)
        residual = max(0.0, requested - supplied)

        reserve_wh = battery.energy_between(
            0.0, max(problem.constraints.soc_reserve, battery.envelope.soc_min)
        )

        reasons = [recommendation.reason]
        if residual > 1.0:
            reasons.append(
                f"The battery covers {supplied / 1000.0:.1f} kW of a "
                f"{requested / 1000.0:.1f} kW load; the remaining "
                f"{residual / 1000.0:.1f} kW must come from elsewhere, because "
                f"{recommendation.limiting_constraint or 'the economics'} prevents "
                "the battery from covering it."
            )
        elif supplied > requested + 1.0:
            reasons.append(
                f"Discharging {(supplied - requested) / 1000.0:.1f} kW above the load, "
                "because exporting the surplus is worth more than storing it."
            )
        if future_demand_wh > 0.0:
            reasons.append(
                f"Energy retained for a forecast {future_demand_wh / 1000.0:.1f} kWh of "
                "future demand is valued above the prevailing price, so the battery "
                "holds back rather than serving cheap load now."
            )

        return DischargePlan(
            battery_power_w=recommendation.recommended_power_w,
            residual_load_w=residual,
            cooling_requirement=recommendation.cooling_requirement,
            reserve_protected_wh=reserve_wh,
            estimated_efficiency=recommendation.estimated_efficiency,
            estimated_degradation=recommendation.estimated_degradation,
            estimated_cost=recommendation.estimated_cost,
            limiting_constraint=recommendation.limiting_constraint,
            remaining_capability_w=(
                recommendation.outcome.residual_power_capability_w
                if recommendation.outcome
                else 0.0
            ),
            currency=recommendation.currency,
            reason=" ".join(r for r in reasons if r),
            recommendation=recommendation,
            meta={"terminal_energy_value_per_kwh": terminal_value},
        )

    def sustainable_power(
        self, state: BatteryState, *, duration_s: float, reserve_soc: float = 0.1
    ) -> float:
        """Largest power the battery can hold for ``duration_s`` and still keep the reserve."""
        battery = self.engine.battery
        available_wh = battery.energy_between(reserve_soc, state.soc)
        energy_limited = available_wh * SECONDS_PER_HOUR / max(duration_s, EPS)
        bounds = self.engine.constraints.bounds(state, duration_s)
        return max(0.0, min(energy_limited, bounds.max_power_w))


__all__ = ["DischargePlanner", "DischargePlan"]
