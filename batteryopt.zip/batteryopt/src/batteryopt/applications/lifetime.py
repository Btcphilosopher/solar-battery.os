"""Lifetime optimisation (specification section 20).

The goal is stated in one line: **maximise useful lifetime energy delivered.**

.. code-block:: text

    AGGRESSIVE POLICY          OPTIMISED POLICY
    Lifetime          8 years  Lifetime         11 years
    Energy delivered  1.82 GWh Energy delivered  2.31 GWh

That comparison is the entire argument for the platform, and it is also the
easiest thing in battery engineering to get wrong, because the two policies
differ on *every* axis at once: throughput per year, depth of discharge, rate,
temperature and resting state of charge. Comparing them honestly means
simulating both under the same ageing model rather than reasoning about them
separately.

Method
------
Each policy is described by its duty cycle -- cycles per year, depth, rate,
operating temperature and resting state of charge -- and integrated forward
year by year:

* stress-weighted accumulators advance under that duty cycle;
* capacity fade and resistance growth follow from the power law;
* the energy delivered each year uses that year's *degraded* capacity, which is
  what makes the integral fall over time rather than being a straight line;
* the policy ends when capacity reaches end of life.

The result is total lifetime energy, lifetime profit, and cost per delivered
kWh. Those three, not cycle count, are what actually decide which policy is
better -- and they routinely disagree with cycle count, which is why the
comparison is worth running.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Sequence

import numpy as np

from ..core.numerics import EPS, clamp
from ..core.units import SECONDS_PER_HOUR, SECONDS_PER_YEAR
from ..economics.engine import EconomicEngine
from ..models.battery import Battery
from ..models.state import DegradationState


@dataclass(frozen=True, slots=True)
class OperatingPolicy:
    """A duty cycle, described in the terms an operator would use."""

    name: str
    #: Equivalent full cycles per year.
    cycles_per_year: float
    #: Depth of each cycle, as a fraction of usable capacity.
    depth_of_discharge: float
    #: Mean C-rate during the active part of the cycle.
    c_rate: float
    #: Mean cell temperature during operation, degC.
    temperature_c: float = 25.0
    #: Mean state of charge over the whole year, including rest.
    mean_soc: float = 0.5
    #: Fraction of charging done at high rate (above 1C).
    fast_charge_fraction: float = 0.0
    #: Round-trip efficiency achieved under this policy.
    round_trip_efficiency: float = 0.94
    description: str = ""

    def as_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "cycles_per_year": self.cycles_per_year,
            "depth_of_discharge": self.depth_of_discharge,
            "c_rate": self.c_rate,
            "temperature_c": self.temperature_c,
            "mean_soc": self.mean_soc,
            "fast_charge_fraction": self.fast_charge_fraction,
            "round_trip_efficiency": self.round_trip_efficiency,
            "description": self.description,
        }


@dataclass(slots=True)
class LifetimeResult:
    """What one policy delivers over the battery's whole life."""

    policy: OperatingPolicy
    lifetime_years: float
    #: Total useful energy delivered before end of life, Wh.
    lifetime_energy_wh: float
    #: Energy purchased to deliver it, Wh.
    lifetime_energy_purchased_wh: float
    lifetime_revenue: float
    lifetime_energy_cost: float
    #: Amortised capital cost of the battery over this policy's life.
    capital_cost: float
    #: SOH trajectory, one entry per simulated year.
    soh_trajectory: tuple[float, ...] = ()
    resistance_trajectory: tuple[float, ...] = ()
    energy_per_year_wh: tuple[float, ...] = ()
    currency: str = "GBP"
    meta: dict[str, Any] = field(default_factory=dict)

    @property
    def lifetime_profit(self) -> float:
        return self.lifetime_revenue - self.lifetime_energy_cost - self.capital_cost

    @property
    def cost_per_kwh_delivered(self) -> float:
        kwh = self.lifetime_energy_wh / 1000.0
        if kwh <= EPS:
            return float("inf")
        return (self.capital_cost + self.lifetime_energy_cost) / kwh

    @property
    def lifetime_energy_gwh(self) -> float:
        return self.lifetime_energy_wh / 1e9

    def summary(self) -> str:
        return (
            f"{self.policy.name:<16} {self.lifetime_years:5.1f} years  "
            f"{self.lifetime_energy_gwh:6.3f} GWh delivered  "
            f"{self.cost_per_kwh_delivered:7.4f} {self.currency}/kWh  "
            f"profit {self.lifetime_profit:+,.0f}"
        )

    def as_dict(self) -> dict[str, Any]:
        return {
            "policy": self.policy.as_dict(),
            "lifetime_years": self.lifetime_years,
            "lifetime_energy_wh": self.lifetime_energy_wh,
            "lifetime_energy_gwh": self.lifetime_energy_gwh,
            "lifetime_energy_purchased_wh": self.lifetime_energy_purchased_wh,
            "lifetime_revenue": self.lifetime_revenue,
            "lifetime_energy_cost": self.lifetime_energy_cost,
            "capital_cost": self.capital_cost,
            "lifetime_profit": self.lifetime_profit,
            "cost_per_kwh_delivered": self.cost_per_kwh_delivered,
            "soh_trajectory": list(self.soh_trajectory),
            "energy_per_year_wh": list(self.energy_per_year_wh),
            "currency": self.currency,
        }


class LifetimeOptimiser:
    """Compares operating policies on lifetime energy and lifetime profit."""

    def __init__(
        self,
        battery: Battery,
        economics: EconomicEngine | None = None,
        *,
        max_years: float = 30.0,
        year_step: float = 0.25,
    ) -> None:
        self.battery = battery
        self.economics = economics or EconomicEngine(battery)
        self.max_years = max_years
        #: Integration step. Quarterly is fine: the ageing law is smooth and a
        #: finer step changes lifetime by well under a percent.
        self.year_step = year_step

    # -- simulation ---------------------------------------------------------

    def simulate(
        self,
        policy: OperatingPolicy,
        *,
        energy_value_per_kwh: float = 0.15,
        energy_cost_per_kwh: float = 0.08,
        start_state: DegradationState | None = None,
    ) -> LifetimeResult:
        """Integrate one policy forward to end of life."""
        battery = self.battery
        model = battery.degradation
        chem = battery.chemistry.degradation
        econ = self.economics
        eol_fade = 1.0 - econ.config.end_of_life_soh

        state = start_state or battery.degradation_state
        nameplate_ah = max(battery.nameplate_capacity_ah, EPS)
        nominal_wh = battery.nominal_energy_wh

        # Stress factors are constant under a stationary duty cycle, so the
        # accumulators advance linearly and only the power law is non-linear.
        s_cal = model.calendar_stress(
            soc=policy.mean_soc, temperature_c=policy.temperature_c
        )
        # A cycle is half discharge and half charge, and the two are not
        # equally damaging: charging carries the asymmetry multiplier and, below
        # the plating threshold, a rapidly growing penalty. Averaging the two
        # halves is what makes cold operation show up as *bad* rather than good.
        # Scoring the whole cycle at the discharge stress -- the obvious
        # simplification -- produces the confidently wrong conclusion that a
        # battery lives longest at 0 degC.
        s_discharge = model.cycle_stress(
            c_rate=policy.c_rate,
            temperature_c=policy.temperature_c,
            dod=policy.depth_of_discharge,
            charging=False,
        )
        s_charge = model.cycle_stress(
            c_rate=policy.c_rate,
            temperature_c=policy.temperature_c,
            dod=policy.depth_of_discharge,
            charging=True,
        )
        if policy.fast_charge_fraction > 0.0:
            s_fast = model.cycle_stress(
                c_rate=max(policy.c_rate, 1.5),
                temperature_c=policy.temperature_c,
                dod=policy.depth_of_discharge,
                charging=True,
            )
            s_charge = (
                1.0 - policy.fast_charge_fraction
            ) * s_charge + policy.fast_charge_fraction * s_fast
        s_cyc = 0.5 * (s_discharge + s_charge)

        t_eq = state.t_eq_years
        a_eq = state.a_eq_efc
        fade = state.capacity_fade
        years = 0.0
        energy_delivered = 0.0
        energy_purchased = 0.0
        soh_trajectory: list[float] = [1.0 - fade]
        resistance_trajectory: list[float] = [state.resistance_growth]
        energy_per_year: list[float] = []

        while fade < eol_fade and years < self.max_years:
            step = self.year_step
            soh = max(0.0, 1.0 - fade)
            # Energy delivered this step uses the capacity the battery has
            # *now*, which is what makes the annual yield fall as it ages.
            year_energy = (
                nominal_wh
                * soh
                * policy.depth_of_discharge
                * policy.cycles_per_year
                * step
            )
            energy_delivered += year_energy
            energy_purchased += year_energy / max(policy.round_trip_efficiency, EPS)
            energy_per_year.append(year_energy / step)

            t_eq += s_cal * step
            a_eq += s_cyc * policy.cycles_per_year * step
            fade = model.fade(t_eq, a_eq)
            years += step
            soh_trajectory.append(max(0.0, 1.0 - fade))
            resistance_trajectory.append(model.growth(t_eq, a_eq))

        revenue = energy_delivered / 1000.0 * energy_value_per_kwh
        cost = energy_purchased / 1000.0 * energy_cost_per_kwh
        return LifetimeResult(
            policy=policy,
            lifetime_years=years,
            lifetime_energy_wh=energy_delivered,
            lifetime_energy_purchased_wh=energy_purchased,
            lifetime_revenue=revenue,
            lifetime_energy_cost=cost,
            capital_cost=econ.replacement_cost,
            soh_trajectory=tuple(soh_trajectory),
            resistance_trajectory=tuple(resistance_trajectory),
            energy_per_year_wh=tuple(energy_per_year),
            currency=econ.config.currency,
            meta={
                "calendar_stress": s_cal,
                "cycle_stress": s_cyc,
                "reached_end_of_life": fade >= eol_fade,
                "final_soh": max(0.0, 1.0 - fade),
            },
        )

    # -- comparison ---------------------------------------------------------

    def compare(
        self,
        policies: Sequence[OperatingPolicy],
        *,
        energy_value_per_kwh: float = 0.15,
        energy_cost_per_kwh: float = 0.08,
    ) -> list[LifetimeResult]:
        """Simulate several policies and rank them by lifetime energy delivered."""
        results = [
            self.simulate(
                p,
                energy_value_per_kwh=energy_value_per_kwh,
                energy_cost_per_kwh=energy_cost_per_kwh,
            )
            for p in policies
        ]
        results.sort(key=lambda r: r.lifetime_energy_wh, reverse=True)
        return results

    @staticmethod
    def table(results: Sequence[LifetimeResult]) -> str:
        lines = [
            f"{'POLICY':<18} {'LIFETIME':>10} {'ENERGY':>12} {'COST/kWh':>10} "
            f"{'PROFIT':>14} {'CYCLES/yr':>10}",
            "-" * 78,
        ]
        for r in results:
            lines.append(
                f"{r.policy.name:<18} {r.lifetime_years:8.1f} y "
                f"{r.lifetime_energy_gwh:9.3f} GWh "
                f"{r.cost_per_kwh_delivered:10.4f} "
                f"{r.lifetime_profit:+14,.0f} "
                f"{r.policy.cycles_per_year:10.0f}"
            )
        return "\n".join(lines)

    # -- policy search ------------------------------------------------------

    def optimal_depth_of_discharge(
        self,
        *,
        annual_energy_requirement_wh: float,
        c_rate: float = 0.5,
        temperature_c: float = 25.0,
        depths: Sequence[float] = (0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0),
    ) -> tuple[float, list[LifetimeResult]]:
        """Best depth of discharge for a fixed annual energy requirement.

        Shallower cycles age the battery less *per cycle*, but a fixed annual
        energy requirement then needs proportionally more of them. The optimum
        is a genuine interior trade-off, and it moves with chemistry: LFP,
        whose depth sensitivity is weaker, tolerates deeper cycling than NMC.
        """
        nominal_wh = max(self.battery.nominal_energy_wh, EPS)
        results: list[LifetimeResult] = []
        for depth in depths:
            cycles = annual_energy_requirement_wh / (nominal_wh * depth)
            policy = OperatingPolicy(
                name=f"DOD {depth * 100:.0f}%",
                cycles_per_year=cycles,
                depth_of_discharge=depth,
                c_rate=c_rate,
                temperature_c=temperature_c,
                mean_soc=clamp(1.0 - depth / 2.0, 0.1, 0.9),
                description=(
                    f"{cycles:.0f} cycles a year at {depth * 100:.0f} % depth to deliver "
                    f"{annual_energy_requirement_wh / 1e6:.1f} MWh a year."
                ),
            )
            results.append(self.simulate(policy))
        best = max(results, key=lambda r: r.lifetime_energy_wh)
        return best.policy.depth_of_discharge, results

    def optimal_temperature(
        self,
        policy: OperatingPolicy,
        *,
        temperatures: Sequence[float] = (10.0, 15.0, 20.0, 25.0, 30.0, 35.0, 40.0),
    ) -> tuple[float, list[LifetimeResult]]:
        """Operating temperature that maximises lifetime energy under a policy.

        Note that this deliberately ignores the cost of *achieving* the
        temperature. The thermal optimiser prices that; this answers the
        narrower question of where the battery would like to live.
        """
        results = [
            self.simulate(
                OperatingPolicy(
                    **{**policy.as_dict(), "name": f"{t:.0f} degC", "temperature_c": t}
                )
            )
            for t in temperatures
        ]
        best = max(results, key=lambda r: r.lifetime_energy_wh)
        return best.policy.temperature_c, results


def standard_policies(*, cycles_per_year: float = 300.0) -> list[OperatingPolicy]:
    """The aggressive/moderate/optimised comparison from section 20."""
    return [
        OperatingPolicy(
            name="AGGRESSIVE",
            cycles_per_year=cycles_per_year,
            depth_of_discharge=0.95,
            c_rate=1.5,
            temperature_c=35.0,
            mean_soc=0.75,
            fast_charge_fraction=0.6,
            round_trip_efficiency=0.90,
            description="Deep, fast, hot, stored full. Maximum throughput per cycle.",
        ),
        OperatingPolicy(
            name="MODERATE",
            cycles_per_year=cycles_per_year,
            depth_of_discharge=0.80,
            c_rate=0.8,
            temperature_c=28.0,
            mean_soc=0.60,
            fast_charge_fraction=0.2,
            round_trip_efficiency=0.93,
            description="A conventional, unoptimised duty cycle.",
        ),
        OperatingPolicy(
            name="OPTIMISED",
            cycles_per_year=cycles_per_year,
            depth_of_discharge=0.65,
            c_rate=0.4,
            temperature_c=22.0,
            mean_soc=0.50,
            fast_charge_fraction=0.0,
            round_trip_efficiency=0.96,
            description=(
                "Shallower, gentler, cooler, rested mid-pack. Less energy per cycle, "
                "far more cycles, and a materially lower cost per delivered kWh."
            ),
        ),
    ]


__all__ = ["LifetimeOptimiser", "OperatingPolicy", "LifetimeResult", "standard_policies"]
