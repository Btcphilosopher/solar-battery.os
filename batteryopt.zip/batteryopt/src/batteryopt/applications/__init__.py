"""Application layer: the questions operators actually ask.

Each module here composes the optimisation engine into one decision:

=========================  ==================================================
Module                     Question it answers
=========================  ==================================================
``charging``               How should this charge be scheduled?
``mission``                What state of charge do I need before departure?
``discharge``              How much of this load should the battery serve?
``thermal``                How hard should the cooling run?
``balancing``              Is balancing worth the energy it burns?
``arbitrage``              Charge, hold or discharge, at what power?
``solar``                  Where should each watt of generation go?
``grid_services``          Is this service contract worth signing?
``lifetime``               Which operating policy delivers most over the life?
=========================  ==================================================
"""

from .arbitrage import ArbitrageAction, ArbitrageOptimiser, ArbitragePlan
from .balancing import BalancingOptimiser, BalancingPlan
from .charging import ChargePlan, SmartCharger
from .discharge import DischargePlan, DischargePlanner
from .grid_services import (
    GridServiceOptimiser,
    ServiceAssessment,
    ServiceContract,
    ServiceType,
    typical_contracts,
)
from .lifetime import LifetimeOptimiser, LifetimeResult, OperatingPolicy, standard_policies
from .mission import MissionPlan, MissionPlanner, temperature_energy_factor
from .solar import (
    EnergyFlows,
    SolarOptimiser,
    SolarPlan,
    synthetic_load_profile,
    synthetic_pv_profile,
)
from .thermal import ThermalOperatingPoint, ThermalOptimiser, ThermalPlan

__all__ = [
    "SmartCharger",
    "ChargePlan",
    "MissionPlanner",
    "MissionPlan",
    "temperature_energy_factor",
    "DischargePlanner",
    "DischargePlan",
    "ThermalOptimiser",
    "ThermalPlan",
    "ThermalOperatingPoint",
    "BalancingOptimiser",
    "BalancingPlan",
    "ArbitrageOptimiser",
    "ArbitragePlan",
    "ArbitrageAction",
    "SolarOptimiser",
    "SolarPlan",
    "EnergyFlows",
    "synthetic_pv_profile",
    "synthetic_load_profile",
    "GridServiceOptimiser",
    "ServiceContract",
    "ServiceAssessment",
    "ServiceType",
    "typical_contracts",
    "LifetimeOptimiser",
    "OperatingPolicy",
    "LifetimeResult",
    "standard_policies",
]
