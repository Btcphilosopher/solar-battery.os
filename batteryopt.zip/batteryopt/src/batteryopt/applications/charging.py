"""Smart charging (specification section 6).

The premise of the section is the important part: **do not assume maximum
charging speed is optimal.** Charging fast costs money in three separate
currencies -- electricity bought at the wrong time, energy lost to internal
resistance, and battery life consumed disproportionately by high rates, high
final SOC and low temperatures. A charging plan is the schedule that buys the
required energy at the lowest total of all three, subject to being finished in
time.

The planner answers the six questions the specification asks for:

.. code-block:: text

    Optimal start time
    Optimal charging power
    Optimal end time
    Optimal target SOC
    Expected degradation
    Energy cost

It works by searching over start times and rate profiles, simulating each
candidate through the plant, and pricing the result with the configured
objective. Deadline feasibility is checked first, so an impossible request is
reported as impossible rather than silently returning the best of a bad set.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field, replace
from typing import Any

import numpy as np

from ..core.numerics import EPS, clamp
from ..core.units import SECONDS_PER_HOUR
from ..economics.prices import Tariff
from ..models.state import BatteryState
from ..optimisation.engine import OptimisationEngine
from ..optimisation.problem import OptimisationProblem
from ..scenario.engine import Scenario, ScenarioResult
from ..scenario.strategies import charge_storage_fraction, preconditioned_charge


@dataclass(slots=True)
class ChargePlan:
    """A complete charging recommendation."""

    #: Seconds from now at which charging should begin.
    start_s: float
    #: Seconds from now at which charging is expected to finish.
    end_s: float
    #: Mean charging power over the active window, W (positive magnitude).
    mean_power_w: float
    peak_power_w: float
    target_soc: float
    start_soc: float
    energy_delivered_wh: float
    energy_purchased_wh: float
    energy_cost: float
    estimated_degradation: float
    estimated_efficiency: float
    peak_temperature_c: float
    currency: str = "GBP"
    label: str = ""
    reason: str = ""
    feasible: bool = True
    #: Per-step power profile, W (signed, negative = charging).
    profile_w: tuple[float, ...] = ()
    dt_s: float = 60.0
    alternatives: tuple[dict[str, Any], ...] = ()
    meta: dict[str, Any] = field(default_factory=dict)

    @property
    def duration_s(self) -> float:
        return max(0.0, self.end_s - self.start_s)

    @property
    def cost_per_kwh(self) -> float:
        kwh = self.energy_delivered_wh / 1000.0
        return self.energy_cost / kwh if kwh > EPS else math.inf

    def summary(self) -> str:
        return (
            f"start +{self.start_s / 60.0:.0f} min, finish +{self.end_s / 60.0:.0f} min, "
            f"{self.mean_power_w / 1000.0:.1f} kW mean, target SOC "
            f"{self.target_soc * 100:.1f} %, {self.energy_delivered_wh / 1000.0:.2f} kWh, "
            f"cost {self.energy_cost:.2f} {self.currency}, "
            f"degradation {self.estimated_degradation * 100:.4f} %"
        )

    def as_dict(self) -> dict[str, Any]:
        return {
            "start_s": self.start_s,
            "end_s": self.end_s,
            "duration_s": self.duration_s,
            "mean_power_w": self.mean_power_w,
            "peak_power_w": self.peak_power_w,
            "target_soc": self.target_soc,
            "start_soc": self.start_soc,
            "energy_delivered_wh": self.energy_delivered_wh,
            "energy_purchased_wh": self.energy_purchased_wh,
            "energy_cost": self.energy_cost,
            "cost_per_kwh": self.cost_per_kwh,
            "estimated_degradation": self.estimated_degradation,
            "estimated_efficiency": self.estimated_efficiency,
            "peak_temperature_c": self.peak_temperature_c,
            "currency": self.currency,
            "feasible": self.feasible,
            "label": self.label,
            "reason": self.reason,
            "alternatives": list(self.alternatives),
        }


class SmartCharger:
    """Plans a charging session against price, time, health and temperature."""

    def __init__(
        self,
        engine: OptimisationEngine,
        *,
        rate_fractions: tuple[float, ...] = (0.25, 0.4, 0.55, 0.7, 0.85, 1.0),
        start_options: int = 9,
        dt_s: float = 300.0,
    ) -> None:
        self.engine = engine
        #: Charging rates to consider, as fractions of the admissible maximum.
        self.rate_fractions = rate_fractions
        #: Number of candidate start times across the available window.
        self.start_options = start_options
        self.dt_s = dt_s

    # -- feasibility --------------------------------------------------------

    def _charge_capability(
        self, state: BatteryState, *, allow_precondition: bool = True
    ) -> tuple[float, float]:
        """Peak admissible charge power, and the seconds of heating it needs first.

        Below the low-temperature charge limit the admissible charge power is
        exactly zero, and every question asked at the present state -- how fast
        can this charge, how high can it get by the deadline -- correctly
        answers "not at all". That answer is only right if heating is off the
        table. When preconditioning is allowed the capability has to be
        evaluated at the temperature the pack *will* be at, with the heating
        time carried alongside it so the caller can still add it back.
        """
        battery = self.engine.battery
        bounds = self.engine.constraints.bounds(state, self.dt_s)
        peak = -bounds.min_power_w
        if peak > EPS or not allow_precondition:
            return max(EPS, peak), 0.0

        target_c = battery.thermal_limits.t_min_charge_c + 8.0
        if state.temperature_c >= target_c:
            return max(EPS, peak), 0.0
        thermal = battery.thermal
        heat_w = max(thermal.heater_heat(1.0), EPS)
        heating_s = (target_c - state.temperature_c) * thermal.heat_capacity_j_k / heat_w
        warmed = replace(state, temperature_c=target_c)
        warm_bounds = self.engine.constraints.bounds(warmed, self.dt_s)
        return max(EPS, -warm_bounds.min_power_w), heating_s

    def minimum_duration_s(
        self, state: BatteryState, target_soc: float, *, allow_precondition: bool = True
    ) -> float:
        """Fastest possible charge to ``target_soc``, ignoring cost.

        Uses the admissible charge power at the present state and derates for
        the constant-voltage tail, which is why the true minimum is roughly a
        third longer than energy divided by peak power. If the pack is too cold
        to charge at all, the time spent warming it is part of the answer.
        """
        battery = self.engine.battery
        energy_wh = battery.energy_between(state.soc, target_soc)
        peak, heating_s = self._charge_capability(
            state, allow_precondition=allow_precondition
        )
        taper_factor = 0.72 if target_soc > 0.8 else 0.9
        return heating_s + energy_wh / (peak * taper_factor) * SECONDS_PER_HOUR

    # -- planning -----------------------------------------------------------

    def plan(
        self,
        state: BatteryState,
        *,
        target_soc: float,
        deadline_s: float,
        tariff: Tariff | None = None,
        ambient_c: float | None = None,
        objective: Any = None,
        allow_precondition: bool = True,
    ) -> ChargePlan:
        """Find the cheapest admissible way to reach ``target_soc`` by the deadline."""
        battery = self.engine.battery
        target_soc = clamp(target_soc, state.soc, battery.envelope.soc_max)
        required_wh = battery.energy_between(state.soc, target_soc)
        if required_wh <= EPS:
            return ChargePlan(
                start_s=0.0,
                end_s=0.0,
                mean_power_w=0.0,
                peak_power_w=0.0,
                target_soc=state.soc,
                start_soc=state.soc,
                energy_delivered_wh=0.0,
                energy_purchased_wh=0.0,
                energy_cost=0.0,
                estimated_degradation=0.0,
                estimated_efficiency=1.0,
                peak_temperature_c=state.temperature_c,
                label="NO CHARGE REQUIRED",
                reason="The battery is already at or above the requested state of charge.",
            )

        fastest = self.minimum_duration_s(
            state, target_soc, allow_precondition=allow_precondition
        )
        feasible = fastest <= deadline_s * 1.02
        if not feasible:
            reachable = self._reachable_soc(
                state, deadline_s, allow_precondition=allow_precondition
            )
            target_soc = reachable

        horizon_s = max(deadline_s, self.dt_s * 2)
        n = max(2, int(round(horizon_s / self.dt_s)))
        dt = horizon_s / n

        problem = self.engine.build_problem(
            state,
            horizon_s=horizon_s,
            dt_s=dt,
            ambient_c=ambient_c,
            objective=objective,
        )
        if tariff is not None:
            problem.tariff = tariff

        candidates = self._candidates(problem, target_soc, deadline_s, allow_precondition)
        results = self.engine.scenarios.compare(problem, candidates)
        # Only candidates that actually reach the target count as solutions.
        achieved = [
            r
            for r in results
            if r.feasible and r.outcome.end_soc >= target_soc - 0.015
        ]
        if achieved:
            chosen = achieved[0]
        else:
            # Nothing reaches the target. The useful answer is then the feasible
            # candidate that gets *closest*, not the cheapest one -- and the
            # cheapest one is always "do nothing", which is the least useful
            # possible reply to "charge this as far as you can by six o'clock".
            feasible = [r for r in results if r.feasible]
            chosen = (
                max(feasible, key=lambda r: r.outcome.end_soc)
                if feasible
                else (results[0] if results else None)
            )
        if chosen is None:  # pragma: no cover - compare always returns something
            raise RuntimeError("no charging candidates were generated")

        return self._to_plan(
            problem,
            chosen,
            target_soc=target_soc,
            deadline_s=deadline_s,
            feasible=feasible and bool(achieved),
            fastest_s=fastest,
            alternatives=[r.as_dict() for r in results[1:7]],
        )

    def _reachable_soc(
        self, state: BatteryState, deadline_s: float, *, allow_precondition: bool = True
    ) -> float:
        """Highest SOC actually reachable within the deadline."""
        battery = self.engine.battery
        peak, heating_s = self._charge_capability(
            state, allow_precondition=allow_precondition
        )
        usable_s = max(0.0, deadline_s - heating_s)
        energy = peak * 0.8 * usable_s / SECONDS_PER_HOUR
        return clamp(
            battery.soc_for_energy(energy, from_soc=state.soc),
            state.soc,
            battery.envelope.soc_max,
        )

    def _candidates(
        self,
        problem: OptimisationProblem,
        target_soc: float,
        deadline_s: float,
        allow_precondition: bool,
    ) -> list[Scenario]:
        """Delayed-start, constant-rate and tapered charging candidates."""
        battery = self.engine.battery
        n = problem.n_steps
        dt = problem.dt_s
        bounds = self.engine.constraints.bounds(problem.state, dt)
        peak = -bounds.min_power_w
        capacity_wh = max(battery.energy_wh, EPS)
        latest_start = max(0.0, deadline_s - self.minimum_duration_s(problem.state, target_soc))
        starts = np.linspace(0.0, latest_start, max(1, self.start_options))

        out: list[Scenario] = []
        for start_s in starts:
            for fraction in self.rate_fractions:
                power = -peak * fraction
                soc = problem.state.soc
                profile: list[float] = []
                for k in range(n):
                    t = k * dt
                    if t < start_s - EPS or soc >= target_soc - 1e-4:
                        profile.append(0.0)
                        continue
                    # Taper near the top: constant power into a nearly full cell
                    # is not achievable, and pretending otherwise makes fast
                    # candidates look better than they are.
                    if soc > 0.75:
                        span = max(battery.envelope.soc_max - 0.75, EPS)
                        taper = clamp(1.0 - (soc - 0.75) / span, 0.1, 1.0)
                    else:
                        taper = 1.0
                    p = power * taper
                    p, _ = bounds.clamp(p)
                    profile.append(float(p))
                    # Not every terminal watt-hour lands in the store: on charge
                    # the terminal voltage sits above the open-circuit voltage by
                    # the ohmic drop. Integrating without that factor makes the
                    # candidate stop several steps early and miss its target by a
                    # couple of per cent -- which then reads as "the deadline
                    # cannot be met" when the real problem is the arithmetic.
                    eta = charge_storage_fraction(
                        problem,
                        power_w=p,
                        soc=soc,
                        temperature_c=problem.state.temperature_c,
                    )
                    soc = clamp(
                        soc + abs(p) * eta * dt / SECONDS_PER_HOUR / capacity_wh, 0.0, 1.0
                    )
                cooling = 0.25 + 0.55 * fraction
                out.append(
                    Scenario(
                        label=(
                            f"start +{start_s / 60.0:.0f} min @ "
                            f"{peak * fraction / 1000.0:.0f} kW"
                        ),
                        power_w=tuple(profile),
                        cooling=(clamp(cooling, 0.0, 1.0),) * n,
                        description=(
                            f"Delay {start_s / 60.0:.0f} minutes, then charge at "
                            f"{fraction * 100:.0f} % of the admissible maximum with a "
                            "taper above 75 % SOC."
                        ),
                        tags=("charge", f"rate{fraction:.2f}"),
                        meta={"start_s": float(start_s), "rate_fraction": fraction},
                    )
                )
        if allow_precondition and problem.state.temperature_c < (
            battery.thermal_limits.t_min_charge_c + 10.0
        ):
            out.append(preconditioned_charge(problem, target_soc=target_soc))
        return out

    def _to_plan(
        self,
        problem: OptimisationProblem,
        result: ScenarioResult,
        *,
        target_soc: float,
        deadline_s: float,
        feasible: bool,
        fastest_s: float,
        alternatives: list[dict[str, Any]],
    ) -> ChargePlan:
        profile = np.asarray(result.scenario.power_w, dtype=float)
        dt = problem.dt_s
        active = np.flatnonzero(profile < -1.0)
        start_s = float(active[0] * dt) if active.size else 0.0
        end_s = float((active[-1] + 1) * dt) if active.size else 0.0
        charging = -profile[profile < 0.0]
        outcome = result.outcome
        breakdown = result.value.breakdown

        reason_parts = [
            f"Chosen from {len(alternatives) + 1} candidate schedules.",
            f"Fastest admissible charge would take {fastest_s / 60.0:.0f} minutes; "
            f"the deadline allows {deadline_s / 60.0:.0f}.",
        ]
        if not feasible:
            reason_parts.append(
                "The requested target is NOT reachable by the deadline; the plan "
                f"reaches {outcome.end_soc * 100:.1f} % instead."
            )
        if result.scenario.meta.get("precondition_steps"):
            reason_parts.append(
                "Preconditioning first: charging a cold pack plates lithium and the "
                "heater energy is cheaper than the damage."
            )
        reason_parts.append(result.value.explain())

        return ChargePlan(
            start_s=start_s,
            end_s=end_s,
            mean_power_w=float(charging.mean()) if charging.size else 0.0,
            peak_power_w=float(charging.max()) if charging.size else 0.0,
            target_soc=outcome.end_soc,
            start_soc=outcome.start_soc,
            energy_delivered_wh=self.engine.battery.energy_between(
                outcome.start_soc, outcome.end_soc
            ),
            energy_purchased_wh=outcome.energy_charged_wh,
            energy_cost=breakdown.energy_cost + breakdown.auxiliary_cost,
            estimated_degradation=outcome.capacity_fade,
            estimated_efficiency=outcome.mean_efficiency,
            peak_temperature_c=outcome.peak_temperature_c,
            currency=result.value.currency,
            label=result.scenario.label,
            reason=" ".join(reason_parts),
            feasible=feasible,
            profile_w=tuple(float(p) for p in profile),
            dt_s=dt,
            alternatives=tuple(alternatives),
            meta={"scenario": result.scenario.as_dict()},
        )

    # -- comparison ---------------------------------------------------------

    def compare_rates(
        self,
        state: BatteryState,
        *,
        target_soc: float,
        deadline_s: float,
        tariff: Tariff | None = None,
        ambient_c: float | None = None,
    ) -> list[ChargePlan]:
        """The section 12 table: fast, normal and slow, priced side by side."""
        plans: list[ChargePlan] = []
        saved = self.rate_fractions
        try:
            for label, fraction in (
                ("FAST", 1.0),
                ("NORMAL", 0.6),
                ("SLOW", 0.35),
            ):
                self.rate_fractions = (fraction,)
                plan = self.plan(
                    state,
                    target_soc=target_soc,
                    deadline_s=deadline_s,
                    tariff=tariff,
                    ambient_c=ambient_c,
                    allow_precondition=False,
                )
                plan.label = label
                plans.append(plan)
        finally:
            self.rate_fractions = saved
        return plans

    @staticmethod
    def comparison_table(plans: list[ChargePlan]) -> str:
        lines = [
            f"{'OPTION':<10} {'DURATION':>10} {'ENERGY':>10} {'COST':>10} "
            f"{'DEGRADATION':>13} {'PEAK T':>9}",
            "-" * 66,
        ]
        for p in plans:
            lines.append(
                f"{p.label:<10} {p.duration_s / 60.0:8.0f} min "
                f"{p.energy_delivered_wh / 1000.0:8.2f} kWh "
                f"{p.energy_cost:9.2f} "
                f"{p.estimated_degradation * 100:12.5f}% "
                f"{p.peak_temperature_c:8.1f}C"
            )
        return "\n".join(lines)


__all__ = ["SmartCharger", "ChargePlan"]
