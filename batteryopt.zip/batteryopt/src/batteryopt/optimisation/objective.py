"""The configurable objective function (specification sections 4, 5, 19, 20).

Every candidate strategy is reduced to one number, and the way that reduction
happens is the single most consequential design decision in the platform.

**Everything is priced in one currency first, then weighted.** The alternative
-- normalising each term to 0-1 and weighting the normalised values -- looks
tidier but is unusable in practice: the weights become uninterpretable, they
have to be re-tuned whenever the scale of any input changes, and nobody can
say what a weight of 0.3 on "degradation" actually means. Here, a weight of
1.0 everywhere means "maximise net economic value", and any other weighting is
an explicit statement that the operator values something differently from its
market price. An EV operator who sets ``mission=6.0`` is saying that arriving
with enough charge is worth six times its raw energy value. That is a
statement a fleet manager can check.

Term structure
--------------

.. code-block:: text

    MAXIMISE                       MINIMISE
      useful energy delivered        internal losses
      stored energy value            degradation (capacity and resistance)
      mission success                thermal stress
      economic revenue               operating cost
      retained power capability      unnecessary cycling

Each contributes a signed currency amount. The total is the *net
lifetime-adjusted value* of the candidate, and the per-term breakdown is what
the dashboard shows when it explains why an operating point was chosen.

Hard constraints do not appear here. They cannot be traded against value at
any weight; see :mod:`batteryopt.optimisation.constraints`.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Mapping

import numpy as np
from pydantic import BaseModel, ConfigDict, Field

from ..core.numerics import EPS
from ..economics.engine import CostBreakdown, EconomicEngine
from ..economics.prices import Tariff
from ..models.battery import Battery


class Term(str, Enum):
    """Named contributions to the objective."""

    ENERGY = "energy"
    EFFICIENCY = "efficiency"
    LIFETIME = "lifetime"
    MISSION = "mission"
    ECONOMIC = "economic"
    THERMAL = "thermal"
    CYCLING = "cycling"
    RESPONSIVENESS = "responsiveness"


@dataclass(frozen=True, slots=True)
class Outcome:
    """The physical consequences of one candidate strategy.

    Produced by the scenario engine from a simulated trajectory, consumed by
    the objective. Keeping it a plain record -- rather than passing trajectories
    around -- is what lets the same objective price a full simulation, a
    surrogate evaluation and an analytic approximation identically.
    """

    energy_discharged_wh: float = 0.0
    energy_charged_wh: float = 0.0
    net_energy_delivered_wh: float = 0.0
    losses_wh: float = 0.0
    auxiliary_wh: float = 0.0
    capacity_fade: float = 0.0
    resistance_growth: float = 0.0
    peak_temperature_c: float = 25.0
    mean_temperature_c: float = 25.0
    duration_s: float = 0.0
    start_soc: float = 0.5
    end_soc: float = 0.5
    equivalent_full_cycles: float = 0.0
    #: Energy the strategy failed to supply against a committed requirement.
    shortfall_wh: float = 0.0
    mean_efficiency: float = 1.0
    #: Discharge power still available at the end of the horizon, W.
    residual_power_capability_w: float = 0.0
    curtailed: bool = False
    limiting_constraint: str | None = None
    #: 0-1 probability that the strategy fails to meet its commitment, from
    #: the uncertainty-aware evaluation. 0.0 when uncertainty is not modelled.
    risk: float = 0.0
    label: str = ""
    meta: dict[str, Any] = field(default_factory=dict)

    @property
    def soc_change(self) -> float:
        return self.end_soc - self.start_soc

    def as_dict(self) -> dict[str, Any]:
        return {
            "label": self.label,
            "energy_discharged_wh": self.energy_discharged_wh,
            "energy_charged_wh": self.energy_charged_wh,
            "net_energy_delivered_wh": self.net_energy_delivered_wh,
            "losses_wh": self.losses_wh,
            "auxiliary_wh": self.auxiliary_wh,
            "capacity_fade": self.capacity_fade,
            "resistance_growth": self.resistance_growth,
            "peak_temperature_c": self.peak_temperature_c,
            "mean_temperature_c": self.mean_temperature_c,
            "duration_s": self.duration_s,
            "start_soc": self.start_soc,
            "end_soc": self.end_soc,
            "equivalent_full_cycles": self.equivalent_full_cycles,
            "shortfall_wh": self.shortfall_wh,
            "mean_efficiency": self.mean_efficiency,
            "curtailed": self.curtailed,
            "limiting_constraint": self.limiting_constraint,
            "risk": self.risk,
        }


class ObjectiveConfig(BaseModel):
    """Weights and parameters defining what "best" means here."""

    model_config = ConfigDict(frozen=True)

    name: str = "balanced"
    description: str = ""

    #: Weight per term. 1.0 means "value this at its market price".
    weights: dict[str, float] = Field(
        default_factory=lambda: {t.value: 1.0 for t in Term}
    )

    #: Preferred temperature band. Excursions above the upper bound are
    #: penalised through the thermal term in addition to the degradation they
    #: already cause, because sustained heat also stresses cooling hardware
    #: and reduces available power.
    thermal_comfort_high_c: float = 35.0
    thermal_penalty_per_kelvin_hour: float = Field(0.02, ge=0)

    #: Penalty per equivalent full cycle beyond what the task requires.
    #: Distinct from degradation cost: it discourages pointless churn even
    #: where the modelled damage is small.
    cycling_penalty_per_efc: float = Field(0.05, ge=0)

    #: Value attached to retaining discharge capability, per kW still
    #: available at the end of the horizon. Matters for consumer devices and
    #: for reserve services, and is zero for most stationary arbitrage.
    responsiveness_value_per_kw: float = Field(0.0, ge=0)

    #: Multiplier on the loss term, over and above its raw energy cost. Set
    #: above 1.0 where losses also cost cooling or grid-connection headroom.
    loss_multiplier: float = Field(1.0, ge=0)

    #: Risk aversion. The objective subtracts ``risk_aversion * risk *
    #: mission_value``, so a strategy with a 5 % chance of missing a mission is
    #: penalised even when its expected value is high.
    risk_aversion: float = Field(1.0, ge=0)

    #: Discount deferred replacement cost over this many years. ``None``
    #: disables discounting.
    remaining_life_years: float | None = None

    def weight(self, term: Term | str) -> float:
        key = term.value if isinstance(term, Term) else term
        return float(self.weights.get(key, 1.0))

    def with_weights(self, **weights: float) -> "ObjectiveConfig":
        merged = dict(self.weights)
        merged.update(weights)
        return self.model_copy(update={"weights": merged})

    def as_dict(self) -> dict[str, Any]:
        return self.model_dump(mode="json")


# ---------------------------------------------------------------------------
# Application presets (specification section 4)
# ---------------------------------------------------------------------------

PRESETS: dict[str, ObjectiveConfig] = {
    "balanced": ObjectiveConfig(
        name="balanced",
        description="Everything valued at its market price. The neutral default.",
    ),
    "ev": ObjectiveConfig(
        name="ev",
        description=(
            "Electric vehicle: mission reliability first, then efficiency. "
            "Arriving short is worth far more than the energy it would have taken."
        ),
        weights={
            Term.ENERGY.value: 1.0,
            Term.EFFICIENCY.value: 1.6,
            Term.LIFETIME.value: 1.0,
            Term.MISSION.value: 6.0,
            Term.ECONOMIC.value: 0.8,
            Term.THERMAL.value: 1.2,
            Term.CYCLING.value: 0.5,
            Term.RESPONSIVENESS.value: 0.8,
        },
        responsiveness_value_per_kw=0.01,
        risk_aversion=2.5,
    ),
    "grid_storage": ObjectiveConfig(
        name="grid_storage",
        description=(
            "Grid storage: economic return over the asset's life. Degradation "
            "is a real, priced cost of every traded megawatt-hour."
        ),
        weights={
            Term.ENERGY.value: 1.0,
            Term.EFFICIENCY.value: 1.2,
            Term.LIFETIME.value: 1.4,
            Term.MISSION.value: 1.0,
            Term.ECONOMIC.value: 1.5,
            Term.THERMAL.value: 0.8,
            Term.CYCLING.value: 1.0,
            Term.RESPONSIVENESS.value: 0.0,
        },
        cycling_penalty_per_efc=0.15,
        remaining_life_years=10.0,
    ),
    "consumer": ObjectiveConfig(
        name="consumer",
        description=(
            "Consumer device: longevity and responsiveness. The user notices a "
            "battery that has aged badly long before they notice a penny of "
            "electricity."
        ),
        weights={
            Term.ENERGY.value: 0.6,
            Term.EFFICIENCY.value: 0.8,
            Term.LIFETIME.value: 3.0,
            Term.MISSION.value: 2.0,
            Term.ECONOMIC.value: 0.2,
            Term.THERMAL.value: 2.0,
            Term.CYCLING.value: 1.5,
            Term.RESPONSIVENESS.value: 2.0,
        },
        thermal_comfort_high_c=32.0,
        responsiveness_value_per_kw=0.05,
    ),
    "industrial": ObjectiveConfig(
        name="industrial",
        description=(
            "Industrial: energy efficiency and uptime. Losses are paid for "
            "twice, once as energy and once as cooling."
        ),
        weights={
            Term.ENERGY.value: 1.0,
            Term.EFFICIENCY.value: 2.0,
            Term.LIFETIME.value: 1.2,
            Term.MISSION.value: 3.0,
            Term.ECONOMIC.value: 1.0,
            Term.THERMAL.value: 1.5,
            Term.CYCLING.value: 0.8,
            Term.RESPONSIVENESS.value: 1.0,
        },
        loss_multiplier=1.4,
    ),
    "lifetime": ObjectiveConfig(
        name="lifetime",
        description=(
            "Maximise useful lifetime energy delivered. Near-pure preservation: "
            "used for policy comparison in section 20, not for daily dispatch."
        ),
        weights={
            Term.ENERGY.value: 1.0,
            Term.EFFICIENCY.value: 1.0,
            Term.LIFETIME.value: 6.0,
            Term.MISSION.value: 1.0,
            Term.ECONOMIC.value: 0.3,
            Term.THERMAL.value: 2.5,
            Term.CYCLING.value: 2.0,
            Term.RESPONSIVENESS.value: 0.0,
        },
        cycling_penalty_per_efc=0.3,
    ),
    "efficiency": ObjectiveConfig(
        name="efficiency",
        description="Maximum round-trip efficiency, ignoring most other concerns.",
        weights={
            Term.ENERGY.value: 1.0,
            Term.EFFICIENCY.value: 8.0,
            Term.LIFETIME.value: 0.5,
            Term.MISSION.value: 1.0,
            Term.ECONOMIC.value: 0.5,
            Term.THERMAL.value: 0.5,
            Term.CYCLING.value: 0.2,
            Term.RESPONSIVENESS.value: 0.0,
        },
    ),
    "power": ObjectiveConfig(
        name="power",
        description="Maximum immediate power, subject only to hard constraints.",
        weights={
            Term.ENERGY.value: 4.0,
            Term.EFFICIENCY.value: 0.1,
            Term.LIFETIME.value: 0.1,
            Term.MISSION.value: 1.0,
            Term.ECONOMIC.value: 0.1,
            Term.THERMAL.value: 0.1,
            Term.CYCLING.value: 0.0,
            Term.RESPONSIVENESS.value: 0.0,
        },
    ),
}


def preset(name: str) -> ObjectiveConfig:
    """Fetch an application preset by name."""
    from ..core.exceptions import ConfigurationError

    try:
        return PRESETS[name]
    except KeyError:
        raise ConfigurationError(
            f"unknown objective preset {name!r}; available: {', '.join(sorted(PRESETS))}"
        ) from None


def available_presets() -> list[str]:
    return sorted(PRESETS)


# ---------------------------------------------------------------------------
# Evaluation
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class ObjectiveValue:
    """The score of one candidate, with its full derivation."""

    total: float
    terms: Mapping[str, float]
    weighted_terms: Mapping[str, float]
    breakdown: CostBreakdown
    currency: str = "GBP"
    #: Raw objective vector for multi-objective work, all **minimised**.
    pareto_costs: tuple[float, ...] = ()
    pareto_names: tuple[str, ...] = ()

    def __float__(self) -> float:
        return float(self.total)

    @property
    def dominant_term(self) -> str:
        """The term contributing most to the score, by absolute magnitude."""
        if not self.weighted_terms:
            return ""
        return max(self.weighted_terms, key=lambda k: abs(self.weighted_terms[k]))

    def explain(self, top: int = 4) -> str:
        """Human-readable one-liner naming the terms that decided the score."""
        ordered = sorted(
            self.weighted_terms.items(), key=lambda kv: abs(kv[1]), reverse=True
        )[:top]
        parts = [f"{name} {value:+.3f}" for name, value in ordered]
        return f"total {self.total:+.3f} {self.currency} = " + " ".join(parts)

    def as_dict(self) -> dict[str, Any]:
        return {
            "total": self.total,
            "currency": self.currency,
            "terms": dict(self.terms),
            "weighted_terms": dict(self.weighted_terms),
            "breakdown": self.breakdown.as_dict(),
            "dominant_term": self.dominant_term,
        }


class Objective:
    """Scores outcomes against a configured set of priorities."""

    __slots__ = ("battery", "config", "economics", "tariff")

    def __init__(
        self,
        battery: Battery,
        config: ObjectiveConfig | str | None = None,
        *,
        economics: EconomicEngine | None = None,
        tariff: Tariff | None = None,
    ) -> None:
        self.battery = battery
        if isinstance(config, str):
            config = preset(config)
        self.config = config or PRESETS["balanced"]
        self.economics = economics or EconomicEngine(battery)
        self.tariff = tariff

    # -- term computation ---------------------------------------------------

    def _thermal_penalty(self, outcome: Outcome) -> float:
        cfg = self.config
        excess = max(0.0, outcome.mean_temperature_c - cfg.thermal_comfort_high_c)
        peak_excess = max(0.0, outcome.peak_temperature_c - cfg.thermal_comfort_high_c)
        hours = outcome.duration_s / 3600.0
        # The peak is weighted separately: a brief excursion is not the same
        # as a sustained one, but it is not free either.
        return cfg.thermal_penalty_per_kelvin_hour * (excess * hours + 0.25 * peak_excess)

    def evaluate(
        self,
        outcome: Outcome,
        *,
        start_time_s: float = 0.0,
        future_energy_value_per_kwh: float | None = None,
    ) -> ObjectiveValue:
        """Score one outcome. Higher is better; units are currency."""
        cfg = self.config
        econ = self.economics
        breakdown = econ.price_outcome(
            energy_discharged_wh=outcome.energy_discharged_wh,
            energy_charged_wh=outcome.energy_charged_wh,
            losses_wh=outcome.losses_wh,
            auxiliary_wh=outcome.auxiliary_wh,
            capacity_fade=outcome.capacity_fade,
            resistance_growth=outcome.resistance_growth,
            shortfall_wh=outcome.shortfall_wh,
            start_soc=outcome.start_soc,
            end_soc=outcome.end_soc,
            tariff=self.tariff,
            start_time_s=start_time_s,
            end_time_s=start_time_s + outcome.duration_s,
            remaining_years=cfg.remaining_life_years,
            future_energy_value_per_kwh=future_energy_value_per_kwh,
        )

        mission_penalty = breakdown.shortfall_cost + (
            cfg.risk_aversion
            * outcome.risk
            * max(breakdown.shortfall_cost, econ.config.mission_shortfall_cost_per_wh * 1000.0)
        )

        terms: dict[str, float] = {
            Term.ENERGY.value: breakdown.energy_revenue + breakdown.stored_energy_value_change,
            Term.EFFICIENCY.value: -breakdown.loss_cost * cfg.loss_multiplier,
            Term.LIFETIME.value: -(breakdown.degradation_cost + breakdown.resistance_cost),
            Term.MISSION.value: -mission_penalty,
            Term.ECONOMIC.value: -(breakdown.energy_cost + breakdown.auxiliary_cost),
            Term.THERMAL.value: -self._thermal_penalty(outcome),
            Term.CYCLING.value: -cfg.cycling_penalty_per_efc * outcome.equivalent_full_cycles,
            Term.RESPONSIVENESS.value: cfg.responsiveness_value_per_kw
            * outcome.residual_power_capability_w
            / 1000.0,
        }
        weighted = {k: cfg.weight(k) * v for k, v in terms.items()}
        total = float(sum(weighted.values()))

        # Multi-objective view: every entry minimised, unweighted, so that a
        # Pareto front is a property of the physics rather than of the weights.
        pareto_names = (
            "cost",
            "degradation",
            "losses",
            "shortfall",
            "thermal_stress",
        )
        pareto_costs = (
            breakdown.energy_cost + breakdown.auxiliary_cost - breakdown.energy_revenue,
            outcome.capacity_fade,
            outcome.losses_wh,
            outcome.shortfall_wh,
            max(0.0, outcome.peak_temperature_c - cfg.thermal_comfort_high_c),
        )

        return ObjectiveValue(
            total=total,
            terms=terms,
            weighted_terms=weighted,
            breakdown=breakdown,
            currency=econ.config.currency,
            pareto_costs=pareto_costs,
            pareto_names=pareto_names,
        )

    def compare(self, outcomes: list[Outcome], **kwargs: Any) -> list[tuple[Outcome, ObjectiveValue]]:
        """Score a list of candidates and return them best-first."""
        scored = [(o, self.evaluate(o, **kwargs)) for o in outcomes]
        scored.sort(key=lambda pair: pair[1].total, reverse=True)
        return scored

    def fingerprint_payload(self) -> dict[str, Any]:
        return {
            "config": self.config.as_dict(),
            "economics": self.economics.config.model_dump(mode="json"),
            "tariff": self.tariff.as_dict() if self.tariff else None,
        }


def pareto_matrix(values: list[ObjectiveValue]) -> np.ndarray:
    """Stack the minimisation cost vectors of several scored candidates."""
    if not values:
        return np.empty((0, 0))
    return np.array([v.pareto_costs for v in values], dtype=float)


__all__ = [
    "Term",
    "Outcome",
    "Objective",
    "ObjectiveConfig",
    "ObjectiveValue",
    "PRESETS",
    "preset",
    "available_presets",
    "pareto_matrix",
]
