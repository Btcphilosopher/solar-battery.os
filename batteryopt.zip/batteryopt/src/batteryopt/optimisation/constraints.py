"""Hard constraints. The part of the engine the objective function cannot argue with.

Specification section 23 is unambiguous: BatteryOpt must never optimise outside
defined physical limits, and safety limits dominate the objective. This module
is the single place where that is enforced, and it is deliberately structured
so that the enforcement cannot be bypassed by accident:

* **Definition, projection and checking are separate.** :meth:`ConstraintSet.bounds`
  computes the feasible power interval, :meth:`ConstraintSet.project` clamps a
  proposal into it, and :meth:`ConstraintSet.check` independently re-derives
  every violation from the resulting trajectory. The optimiser uses the first
  two; the guard at the end of the pipeline uses the third. A bug in the
  projection is therefore caught by the check rather than hidden by it.

* **Hard constraints are never weighted.** They do not appear in the objective
  at all. There is no penalty coefficient large enough to trade against a
  cell venting, so none is offered.

* **Soft constraints are advisory.** Preferred SOC windows, derating
  temperatures and comfort limits are expressed as soft constraints, which the
  objective may trade against value. They are reported separately so an
  operator can always see which kind of limit shaped a recommendation.

BatteryOpt is not a substitute for independent BMS protection. These
constraints stop the *optimiser* from proposing something unsafe; they are not
a hardware protection layer and must not be relied on as one.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field, replace
from enum import Enum
from typing import Any, Iterable, Sequence

from ..core.exceptions import InfeasibleProblem, SafetyViolation
from ..core.numerics import EPS
from ..core.units import SECONDS_PER_HOUR
from ..models.battery import Battery
from ..models.state import BatteryState


class ConstraintKind(str, Enum):
    """Whether a limit may ever be traded against value."""

    #: Physical or safety limit. Inviolable. Never enters the objective.
    HARD = "HARD"
    #: Operator preference. May be traded against value by the objective.
    SOFT = "SOFT"


@dataclass(frozen=True, slots=True)
class Constraint:
    """One named bound on one quantity."""

    name: str
    quantity: str
    kind: ConstraintKind
    unit: str
    lower: float = -math.inf
    upper: float = math.inf
    source: str = ""
    description: str = ""

    def violation(self, value: float) -> float:
        """Signed excess beyond the bound; 0.0 when satisfied."""
        if value < self.lower:
            return value - self.lower
        if value > self.upper:
            return value - self.upper
        return 0.0

    def satisfied(self, value: float, *, tolerance: float = 0.0) -> bool:
        return abs(self.violation(value)) <= tolerance

    def as_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "quantity": self.quantity,
            "kind": self.kind.value,
            "unit": self.unit,
            "lower": None if self.lower == -math.inf else self.lower,
            "upper": None if self.upper == math.inf else self.upper,
            "source": self.source,
            "description": self.description,
        }


@dataclass(frozen=True, slots=True)
class Violation:
    """A breach of one constraint at one point."""

    constraint: Constraint
    value: float
    excess: float
    at_time_s: float | None = None
    context: str = ""

    @property
    def is_hard(self) -> bool:
        return self.constraint.kind is ConstraintKind.HARD

    def __str__(self) -> str:  # pragma: no cover - cosmetic
        bound = self.constraint.upper if self.excess > 0 else self.constraint.lower
        return (
            f"{self.constraint.kind.value} constraint {self.constraint.name!r} breached: "
            f"{self.constraint.quantity}={self.value:.4g} {self.constraint.unit} "
            f"vs limit {bound:.4g} (excess {self.excess:+.4g})"
        )

    def as_dict(self) -> dict[str, Any]:
        return {
            "constraint": self.constraint.as_dict(),
            "value": self.value,
            "excess": self.excess,
            "at_time_s": self.at_time_s,
            "context": self.context,
        }


@dataclass(frozen=True, slots=True)
class PowerBounds:
    """Feasible signed-power interval and what determines each end."""

    #: Most negative admissible power (largest charge), W.
    min_power_w: float
    #: Most positive admissible power (largest discharge), W.
    max_power_w: float
    charge_limiting: str
    discharge_limiting: str
    #: Every evaluated candidate bound, for explanation.
    charge_candidates: dict[str, float] = field(default_factory=dict)
    discharge_candidates: dict[str, float] = field(default_factory=dict)

    @property
    def is_empty(self) -> bool:
        return self.max_power_w < self.min_power_w - EPS

    @property
    def width_w(self) -> float:
        return max(0.0, self.max_power_w - self.min_power_w)

    def clamp(self, power_w: float) -> tuple[float, str | None]:
        """Clamp a proposal into the interval, naming the binding limit."""
        if self.is_empty:
            raise InfeasibleProblem(
                "no admissible power: charge and discharge bounds cross",
                limiting=f"{self.charge_limiting}/{self.discharge_limiting}",
            )
        if power_w > self.max_power_w:
            return self.max_power_w, self.discharge_limiting
        if power_w < self.min_power_w:
            return self.min_power_w, self.charge_limiting
        return power_w, None

    def as_dict(self) -> dict[str, Any]:
        return {
            "min_power_w": self.min_power_w,
            "max_power_w": self.max_power_w,
            "charge_limiting": self.charge_limiting,
            "discharge_limiting": self.discharge_limiting,
            "charge_candidates": self.charge_candidates,
            "discharge_candidates": self.discharge_candidates,
        }


class ConstraintSet:
    """The active constraint set for one battery in one operating context."""

    def __init__(
        self,
        battery: Battery,
        *,
        constraints: Sequence[Constraint] | None = None,
        soc_reserve: float = 0.0,
        soc_ceiling: float | None = None,
        grid_import_limit_w: float | None = None,
        grid_export_limit_w: float | None = None,
        tolerance: dict[str, float] | None = None,
    ) -> None:
        self.battery = battery
        #: Operator-imposed energy reserve, above the cell floor. Soft by
        #: default: a mission may legitimately eat into it, but the optimiser
        #: must be told to.
        self.soc_reserve = soc_reserve
        self.soc_ceiling = soc_ceiling
        self.grid_import_limit_w = grid_import_limit_w
        self.grid_export_limit_w = grid_export_limit_w
        self._constraints: list[Constraint] = list(constraints) if constraints else []
        if not self._constraints:
            self._constraints = self._derive_from_battery()
        #: Numerical slack when checking, per quantity. Exists so that a
        #: floating-point round-trip through the plant does not register as a
        #: safety violation; it is orders of magnitude below any real margin.
        self.tolerance = {
            "voltage_v": 1e-6,
            "current_a": 1e-6,
            "temperature_c": 1e-9,
            "soc": 1e-9,
            "power_w": 1e-6,
            "c_rate": 1e-9,
        }
        if tolerance:
            self.tolerance.update(tolerance)

    # -- construction -------------------------------------------------------

    def _derive_from_battery(self) -> list[Constraint]:
        b = self.battery
        env = b.envelope
        limits = b.thermal_limits
        out: list[Constraint] = [
            Constraint(
                name="terminal_voltage",
                quantity="voltage_v",
                kind=ConstraintKind.HARD,
                unit="V",
                lower=b.minimum_voltage,
                upper=b.maximum_voltage,
                source="cell envelope x series count",
                description="Terminal voltage must stay inside the cell voltage window.",
            ),
            Constraint(
                name="discharge_current",
                quantity="current_a",
                kind=ConstraintKind.HARD,
                unit="A",
                lower=-b.maximum_charge_current,
                upper=b.maximum_current,
                source="cell continuous C-rate",
                description="Continuous current rating in both directions.",
            ),
            Constraint(
                name="cell_temperature",
                quantity="temperature_c",
                kind=ConstraintKind.HARD,
                unit="degC",
                lower=limits.t_min_c,
                upper=limits.t_max_c,
                source="manufacturer operating envelope",
                description="Absolute operating temperature limits.",
            ),
            Constraint(
                name="charge_temperature_window",
                quantity="charge_temperature_c",
                kind=ConstraintKind.HARD,
                unit="degC",
                lower=limits.t_min_charge_c,
                upper=limits.t_max_charge_c,
                source="manufacturer charging envelope",
                description=(
                    "Charging is prohibited outside this window; below the lower "
                    "bound charging plates lithium metal on the anode."
                ),
            ),
            Constraint(
                name="state_of_charge",
                quantity="soc",
                kind=ConstraintKind.HARD,
                unit="-",
                lower=env.soc_min,
                upper=env.soc_max,
                source="cell envelope",
                description="Absolute SOC window.",
            ),
        ]
        if b.max_discharge_power_w is not None or b.max_charge_power_w is not None:
            out.append(
                Constraint(
                    name="system_power_rating",
                    quantity="power_w",
                    kind=ConstraintKind.HARD,
                    unit="W",
                    lower=-abs(b.max_charge_power_w) if b.max_charge_power_w else -math.inf,
                    upper=abs(b.max_discharge_power_w) if b.max_discharge_power_w else math.inf,
                    source="inverter / contactor / grid connection rating",
                    description="Power-electronics and connection ratings.",
                )
            )
        if self.soc_reserve > 0.0:
            out.append(
                Constraint(
                    name="operational_soc_reserve",
                    quantity="soc",
                    kind=ConstraintKind.SOFT,
                    unit="-",
                    lower=max(env.soc_min, self.soc_reserve),
                    upper=math.inf,
                    source="operator configuration",
                    description="Energy reserve the operator prefers to keep untouched.",
                )
            )
        if self.soc_ceiling is not None:
            out.append(
                Constraint(
                    name="operational_soc_ceiling",
                    quantity="soc",
                    kind=ConstraintKind.SOFT,
                    unit="-",
                    upper=min(env.soc_max, self.soc_ceiling),
                    source="operator configuration",
                    description=(
                        "Preferred upper SOC. Sitting at high SOC accelerates "
                        "calendar ageing, so the optimiser avoids it unless paid to."
                    ),
                )
            )
        out.append(
            Constraint(
                name="derate_temperature",
                quantity="temperature_c",
                kind=ConstraintKind.SOFT,
                unit="degC",
                upper=limits.t_derate_c,
                source="operator configuration",
                description="Preferred maximum operating temperature.",
            )
        )
        if self.grid_import_limit_w is not None or self.grid_export_limit_w is not None:
            out.append(
                Constraint(
                    name="grid_connection",
                    quantity="grid_power_w",
                    kind=ConstraintKind.HARD,
                    unit="W",
                    lower=-abs(self.grid_import_limit_w)
                    if self.grid_import_limit_w is not None
                    else -math.inf,
                    upper=abs(self.grid_export_limit_w)
                    if self.grid_export_limit_w is not None
                    else math.inf,
                    source="grid connection agreement",
                    description="Import and export limits at the point of connection.",
                )
            )
        return out

    # -- access -------------------------------------------------------------

    @property
    def constraints(self) -> list[Constraint]:
        return list(self._constraints)

    @property
    def hard(self) -> list[Constraint]:
        return [c for c in self._constraints if c.kind is ConstraintKind.HARD]

    @property
    def soft(self) -> list[Constraint]:
        return [c for c in self._constraints if c.kind is ConstraintKind.SOFT]

    def get(self, name: str) -> Constraint | None:
        return next((c for c in self._constraints if c.name == name), None)

    def add(self, constraint: Constraint) -> None:
        """Add a constraint. Hard constraints may only ever be tightened."""
        existing = self.get(constraint.name)
        if existing is not None and existing.kind is ConstraintKind.HARD:
            if constraint.kind is not ConstraintKind.HARD:
                raise SafetyViolation(
                    f"refusing to downgrade hard constraint {constraint.name!r} to soft"
                )
            tightened = replace(
                existing,
                lower=max(existing.lower, constraint.lower),
                upper=min(existing.upper, constraint.upper),
                source=f"{existing.source}; tightened by {constraint.source or 'operator'}",
            )
            self._constraints = [
                tightened if c.name == constraint.name else c for c in self._constraints
            ]
            return
        self._constraints = [c for c in self._constraints if c.name != constraint.name]
        self._constraints.append(constraint)

    # -- feasible action set ------------------------------------------------

    def bounds(
        self,
        state: BatteryState,
        dt: float,
        *,
        include_soft: bool = False,
        soc_floor: float | None = None,
        soc_ceiling: float | None = None,
    ) -> PowerBounds:
        """Feasible signed-power interval over the next ``dt`` seconds.

        This is the optimiser's action space. It is derived from the same
        limits :meth:`check` uses, but *forward*: rather than asking whether a
        trajectory broke a rule, it asks what the rules permit.

        Every candidate limit is converted into a terminal power at the current
        state, and the tightest wins. Naming the winner is not decoration -- it
        is the ``limiting_constraint`` field of the recommendation.
        """
        from ..estimation.sop import PowerCapabilityEstimator

        battery = self.battery
        env = battery.envelope
        floor = env.soc_min if soc_floor is None else max(env.soc_min, soc_floor)
        ceiling = env.soc_max if soc_ceiling is None else min(env.soc_max, soc_ceiling)
        if include_soft:
            reserve = self.get("operational_soc_reserve")
            if reserve is not None:
                floor = max(floor, reserve.lower)
            cap = self.get("operational_soc_ceiling")
            if cap is not None:
                ceiling = min(ceiling, cap.upper)

        sop = PowerCapabilityEstimator(battery)
        capability = sop.estimate(state, horizon_s=dt, soc_min=floor, soc_max=ceiling)

        discharge_candidates = dict(capability.discharge_limits_w)
        charge_candidates = dict(capability.charge_limits_w)

        # Hard power ratings declared as constraints (inverter, grid).
        power_constraint = self.get("system_power_rating")
        if power_constraint is not None:
            if math.isfinite(power_constraint.upper):
                discharge_candidates["system_power_rating"] = power_constraint.upper
            if math.isfinite(power_constraint.lower):
                charge_candidates["system_power_rating"] = abs(power_constraint.lower)
        grid = self.get("grid_connection")
        if grid is not None:
            if math.isfinite(grid.upper):
                discharge_candidates["grid_connection"] = grid.upper
            if math.isfinite(grid.lower):
                charge_candidates["grid_connection"] = abs(grid.lower)
        if include_soft:
            derate = self.get("derate_temperature")
            if derate is not None and state.temperature_c > derate.upper:
                # Linear derating above the preferred temperature, reaching zero
                # at the hard limit. Soft, so it can be overridden by value.
                hard_max = battery.thermal_limits.t_max_c
                span = max(hard_max - derate.upper, EPS)
                factor = max(0.0, 1.0 - (state.temperature_c - derate.upper) / span)
                discharge_candidates["derate_temperature"] = (
                    capability.discharge_w * factor
                )
                charge_candidates["derate_temperature"] = capability.charge_w * factor

        dis_name = min(discharge_candidates, key=lambda k: discharge_candidates[k])
        chg_name = min(charge_candidates, key=lambda k: charge_candidates[k])
        return PowerBounds(
            min_power_w=-max(0.0, charge_candidates[chg_name]),
            max_power_w=max(0.0, discharge_candidates[dis_name]),
            charge_limiting=chg_name,
            discharge_limiting=dis_name,
            charge_candidates={k: float(v) for k, v in charge_candidates.items()},
            discharge_candidates={k: float(v) for k, v in discharge_candidates.items()},
        )

    def project(
        self, power_w: float, state: BatteryState, dt: float, *, include_soft: bool = False
    ) -> tuple[float, str | None]:
        """Clamp a proposed power into the feasible interval."""
        return self.bounds(state, dt, include_soft=include_soft).clamp(power_w)

    # -- verification -------------------------------------------------------

    def check_state(
        self, state: BatteryState, *, include_soft: bool = True, context: str = ""
    ) -> list[Violation]:
        """Independently re-derive every violation present in a state.

        Deliberately duplicates the logic in :meth:`bounds` rather than sharing
        it. Shared logic means a bug in the forward computation is invisible to
        the check; separate logic means the check can catch it.
        """
        out: list[Violation] = []
        tol = self.tolerance
        for c in self._constraints:
            if c.kind is ConstraintKind.SOFT and not include_soft:
                continue
            if c.quantity == "voltage_v":
                value = state.voltage_v
            elif c.quantity == "current_a":
                value = state.current_a
            elif c.quantity == "temperature_c":
                # The hottest cell is what matters, not the pack mean.
                value = state.temperature_max_c
                if c.lower > -math.inf:
                    cold = state.temperature_min_c
                    if cold < c.lower - tol.get("temperature_c", 0.0):
                        out.append(
                            Violation(c, cold, cold - c.lower, state.timestamp, context)
                        )
                    value = state.temperature_max_c
            elif c.quantity == "soc":
                value = state.soc
            elif c.quantity == "power_w":
                value = state.power_w
            elif c.quantity == "charge_temperature_c":
                if state.current_a >= -EPS:
                    continue  # not charging: the window does not apply
                value = state.temperature_c
            elif c.quantity == "c_rate":
                value = state.c_rate
            else:
                continue
            excess = c.violation(value)
            if abs(excess) > tol.get(c.quantity, 0.0):
                out.append(Violation(c, value, excess, state.timestamp, context))
        return out

    def check_trajectory(
        self, states: Iterable[BatteryState], *, include_soft: bool = True
    ) -> list[Violation]:
        out: list[Violation] = []
        for state in states:
            out.extend(self.check_state(state, include_soft=include_soft))
        return out

    def hard_violations(self, states: Iterable[BatteryState]) -> list[Violation]:
        return [v for v in self.check_trajectory(states, include_soft=False) if v.is_hard]

    def assert_satisfied(
        self, states: Iterable[BatteryState], *, context: str = "optimisation result"
    ) -> None:
        """Raise :class:`SafetyViolation` if any hard constraint is breached.

        This is the final guard in the optimisation pipeline. It runs on the
        simulated consequence of the recommendation, not on the recommendation
        itself, because a power figure that looks legal can still drive the
        pack through an illegal voltage two minutes later.
        """
        violations = self.hard_violations(states)
        if violations:
            detail = "; ".join(str(v) for v in violations[:5])
            more = f" (and {len(violations) - 5} more)" if len(violations) > 5 else ""
            raise SafetyViolation(
                f"{context} violates hard constraints: {detail}{more}", violations
            )

    # -- reporting ----------------------------------------------------------

    def energy_available_wh(self, state: BatteryState, *, include_soft: bool = True) -> float:
        """Energy that may legally be discharged from the present state, Wh."""
        floor = self.battery.envelope.soc_min
        if include_soft:
            reserve = self.get("operational_soc_reserve")
            if reserve is not None:
                floor = max(floor, reserve.lower)
        return self.battery.energy_between(floor, state.soc)

    def headroom_wh(self, state: BatteryState, *, include_soft: bool = True) -> float:
        """Energy that may legally be charged into the battery, Wh."""
        ceiling = self.battery.envelope.soc_max
        if include_soft:
            cap = self.get("operational_soc_ceiling")
            if cap is not None:
                ceiling = min(ceiling, cap.upper)
        return self.battery.energy_between(state.soc, ceiling)

    def max_energy_ah(self, state: BatteryState, dt: float) -> float:
        """Charge that may move over ``dt``, Ah -- used by LP formulations."""
        bounds = self.bounds(state, dt)
        v = max(state.voltage_v, self.battery.nominal_voltage * 0.5)
        return max(abs(bounds.max_power_w), abs(bounds.min_power_w)) * dt / (
            SECONDS_PER_HOUR * v
        )

    def as_dict(self) -> dict[str, Any]:
        return {
            "battery_id": self.battery.battery_id,
            "hard": [c.as_dict() for c in self.hard],
            "soft": [c.as_dict() for c in self.soft],
            "soc_reserve": self.soc_reserve,
            "soc_ceiling": self.soc_ceiling,
        }

    def fingerprint_payload(self) -> dict[str, Any]:
        """Canonical payload for the reproducibility hash."""
        return {
            "constraints": sorted(
                (c.as_dict() for c in self._constraints), key=lambda d: str(d["name"])
            ),
            "soc_reserve": self.soc_reserve,
            "soc_ceiling": self.soc_ceiling,
            "grid_import_limit_w": self.grid_import_limit_w,
            "grid_export_limit_w": self.grid_export_limit_w,
        }


__all__ = [
    "Constraint",
    "ConstraintKind",
    "ConstraintSet",
    "PowerBounds",
    "Violation",
]
