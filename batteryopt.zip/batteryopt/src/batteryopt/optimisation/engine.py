"""The optimisation engine: method selection, execution and the safety guard.

This is the component the rest of the platform calls. It:

1. picks an appropriate method for the problem (or uses the one asked for);
2. runs it, falling back through alternatives if it fails;
3. **re-simulates the winning plan through the full plant model**;
4. checks that simulation against every hard constraint and refuses to return
   a recommendation that breaks one;
5. assembles the section 27 result, including the comparison of alternatives
   and the reason the operating point was chosen.

Step 3 is not redundant with step 2. Fast methods work against surrogates and
relaxations; the guard works against the same model the platform validates.
A recommendation that survives both is one whose consequences have actually
been simulated, not merely scored.

Step 4 is the hard-constraint property the specification requires: no optimiser
can produce a recommendation violating a configured hard constraint. It is
enforced here, once, on the way out -- and tested directly in the test suite by
throwing adversarial problems at every method.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from typing import Any, Sequence

import numpy as np

from ..core.exceptions import InfeasibleProblem, OptimisationError, SafetyViolation
from ..core.numerics import clamp
from ..economics.engine import EconomicConfig, EconomicEngine
from ..economics.prices import Tariff
from ..models.battery import Battery
from ..models.fidelity import Fidelity, build_plant
from ..models.state import BatteryState
from ..scenario.engine import Scenario, ScenarioEngine
from .constraints import ConstraintKind, ConstraintSet
from .methods.base import MethodResult, OptimisationMethod
from .methods.continuous import GoldenSectionMethod, ScipyMethod
from .methods.dynamic_programming import DynamicProgrammingMethod
from .methods.enumeration import EnumerationMethod, ScenarioComparisonMethod
from .methods.fast import SurrogateSweepMethod
from .methods.linear_program import LinearProgramMethod
from .methods.mixed_integer import MixedIntegerMethod
from .methods.pareto import ParetoFront, ParetoMethod
from .objective import Objective, ObjectiveConfig, preset
from .problem import Demand, Mission, OptimisationProblem, Recommendation, build_recommendation

log = logging.getLogger(__name__)

#: Registry of available methods, by name.
METHODS: dict[str, type] = {
    "enumeration": EnumerationMethod,
    "scenario_comparison": ScenarioComparisonMethod,
    "golden_section": GoldenSectionMethod,
    "scipy": ScipyMethod,
    "surrogate_sweep": SurrogateSweepMethod,
    "linear_program": LinearProgramMethod,
    "dynamic_programming": DynamicProgrammingMethod,
    "mixed_integer": MixedIntegerMethod,
    "pareto": ParetoMethod,
}


def available_methods() -> list[str]:
    return sorted(METHODS)


@dataclass(slots=True)
class MethodChoice:
    """Which method was selected and why."""

    primary: str
    fallbacks: tuple[str, ...]
    reason: str


def select_method(problem: OptimisationProblem) -> MethodChoice:
    """Choose a method from the structure of the problem.

    The rules are deliberately explicit rather than learned, because an
    operator asking "why did it use dynamic programming here?" deserves an
    answer that fits in a sentence.
    """
    n = problem.n_steps
    tariff = problem.tariff or problem.objective.tariff
    price_varies = False
    if tariff is not None:
        times = problem.state.timestamp + np.arange(n) * problem.dt_s
        prices = np.asarray(tariff.import_at(times), dtype=float)
        price_varies = float(prices.max() - prices.min()) > 1e-4

    if n <= 2:
        return MethodChoice(
            primary="golden_section",
            fallbacks=("surrogate_sweep", "enumeration"),
            reason=(
                "Single control interval: the decision is one continuous power, so a "
                "bracketed 1-D search over the full plant model is both exact enough "
                "and cheap."
            ),
        )
    if price_varies and n >= 4:
        return MethodChoice(
            primary="dynamic_programming",
            fallbacks=("linear_program", "surrogate_sweep", "enumeration"),
            reason=(
                f"Prices vary over {n} intervals, so this is a scheduling problem. "
                "Dynamic programming is used because round-trip efficiency and "
                "degradation are non-linear in power, which a linear programme would "
                "have to approximate away."
            ),
        )
    if n >= 4:
        return MethodChoice(
            primary="surrogate_sweep",
            fallbacks=("golden_section", "enumeration"),
            reason=(
                f"{n} intervals with a flat price: no scheduling gain is available, so "
                "the problem reduces to choosing a steady operating point, found by "
                "vectorised sweep."
            ),
        )
    return MethodChoice(
        primary="golden_section",
        fallbacks=("surrogate_sweep", "enumeration"),
        reason="Short horizon: a bracketed continuous search over the plant model.",
    )


class OptimisationEngine:
    """Answers "what should the battery do now?" for one battery."""

    def __init__(
        self,
        battery: Battery,
        *,
        objective: Objective | ObjectiveConfig | str | None = None,
        constraints: ConstraintSet | None = None,
        economics: EconomicEngine | EconomicConfig | None = None,
        tariff: Tariff | None = None,
        fidelity: Fidelity | str = Fidelity.STANDARD,
        method: str = "auto",
        commitment_window_s: float | None = None,
    ) -> None:
        self.battery = battery
        self.constraints = constraints or ConstraintSet(battery)
        if isinstance(economics, EconomicConfig):
            economics = EconomicEngine(battery, economics)
        self.economics = economics or EconomicEngine(battery)
        self.tariff = tariff
        if isinstance(objective, Objective):
            self.objective = objective
        else:
            config = objective if isinstance(objective, ObjectiveConfig) else preset(
                objective or "balanced"
            )
            self.objective = Objective(
                battery, config, economics=self.economics, tariff=tariff
            )
        self.fidelity = Fidelity(fidelity)
        self.plant = build_plant(battery, self.fidelity)
        self.scenarios = ScenarioEngine(battery, self.plant)
        self.method = method
        #: How far into the plan counts as committed. Defaults to the whole
        #: horizon, resolved per problem in :meth:`optimise`. Only a caller that
        #: re-plans before reaching the tail should shorten it.
        self.commitment_window_s = commitment_window_s or 0.0
        self._instances: dict[str, Any] = {}

    # -- problem construction ----------------------------------------------

    def build_problem(
        self,
        state: BatteryState,
        *,
        demand: Demand | float | None = None,
        mission: Mission | None = None,
        horizon_s: float = 900.0,
        dt_s: float = 60.0,
        ambient_c: float | np.ndarray | None = None,
        solar_w: float | np.ndarray | None = None,
        terminal_energy_value_per_kwh: float | None = None,
        objective: Objective | ObjectiveConfig | str | None = None,
        seed: int | None = None,
        label: str = "",
    ) -> OptimisationProblem:
        if isinstance(demand, (int, float)):
            demand = Demand(power_w=float(demand), firm=True, label="scalar demand")
        obj = self.objective
        if objective is not None and not isinstance(objective, Objective):
            config = objective if isinstance(objective, ObjectiveConfig) else preset(objective)
            obj = Objective(self.battery, config, economics=self.economics, tariff=self.tariff)
        elif isinstance(objective, Objective):
            obj = objective
        return OptimisationProblem(
            state=state,
            constraints=self.constraints,
            objective=obj,
            horizon_s=horizon_s,
            dt_s=dt_s,
            demand=demand,
            mission=mission,
            tariff=self.tariff,
            ambient_c=ambient_c,
            solar_w=solar_w,
            terminal_energy_value_per_kwh=terminal_energy_value_per_kwh,
            seed=seed,
            label=label,
        )

    # -- method handling ----------------------------------------------------

    def _method(self, name: str) -> OptimisationMethod:
        instance = self._instances.get(name)
        if instance is None:
            cls = METHODS.get(name)
            if cls is None:
                raise OptimisationError(
                    f"unknown method {name!r}; available: {', '.join(available_methods())}"
                )
            kwargs: dict[str, Any] = {}
            if name in ("enumeration", "scenario_comparison", "golden_section", "scipy", "pareto"):
                kwargs["engine"] = self.scenarios
            instance = cls(**kwargs)
            self._instances[name] = instance
        return instance

    def _run_method(
        self, problem: OptimisationProblem, choice: MethodChoice
    ) -> tuple[MethodResult, list[str]]:
        attempts: list[str] = []
        errors: list[str] = []
        for name in (choice.primary, *choice.fallbacks):
            attempts.append(name)
            try:
                return self._method(name).solve(problem), attempts
            except (InfeasibleProblem, OptimisationError) as exc:
                errors.append(f"{name}: {exc}")
                log.debug("method %s declined the problem: %s", name, exc)
        raise InfeasibleProblem(
            "no optimisation method produced a feasible plan: " + "; ".join(errors)
        )

    # -- the guard ----------------------------------------------------------

    def _verify(
        self, problem: OptimisationProblem, result: MethodResult
    ) -> tuple[Scenario, Any, list[Any]]:
        """Re-simulate the plan at full fidelity and enforce hard constraints.

        Two things happen here that cannot happen inside a method:

        * the plan is priced by the *same* plant model used for validation, so
          a surrogate's error cannot leak into the reported outcome;
        * every hard constraint is re-checked from scratch against the
          resulting trajectory.

        The check is split by horizon position. By default the **commitment
        window is the whole horizon**: a recommendation returned for a fifteen
        minute horizon must be safe to hold for fifteen minutes, because a
        caller has every right to do exactly that. Only a caller that genuinely
        re-plans -- the MPC layer -- may shorten the window to its control
        interval, and it has to say so.

        Violations inside the commitment window are repaired, not reported. The
        repair is a bisection on a scale factor applied to the whole plan, with
        cooling raised to maximum: resting is always admissible, so a feasible
        point always exists unless the *starting state* is already outside its
        limits, and bisection finds the largest feasible fraction of the
        proposed plan in about a dozen simulations.

        If even resting breaches a limit, the battery was already outside its
        envelope when the state arrived. That is a real condition and the engine
        raises rather than pretending it can be optimised away.

        Two trajectories are checked, not one:

        1. **The plan as scheduled.** What happens if the whole schedule runs.
        2. **The first action, held.** What happens if the caller takes
           ``recommended_power_w`` and simply applies it until it asks again.

        The second matters because that is what a BMS or EMS integration
        actually does with the answer. A schedule whose first step is only safe
        because step four backs off is not a safe recommendation to hand to a
        controller that has never heard of step four.
        """
        n = problem.n_steps
        power = tuple(result.power_w[:n]) or (0.0,) * n
        cooling = tuple(result.cooling[:n]) or (0.0,) * n
        while len(power) < n:
            power = power + (power[-1],)
        while len(cooling) < n:
            cooling = cooling + (cooling[-1],)

        scenario = Scenario(
            label=f"plan[{result.method}]",
            power_w=power,
            cooling=cooling,
            description=result.reason,
            tags=("plan", result.method),
        )
        evaluated = self.scenarios.evaluate(problem, scenario)
        committed, advisory = self._split_violations(problem, evaluated)
        held = self._held_action_violations(problem, scenario)
        if committed or held:
            scenario, evaluated, advisory = self._repair(problem, result, scenario)
        return scenario, evaluated, advisory

    def _held_action_violations(
        self, problem: OptimisationProblem, scenario: Scenario
    ) -> list[Any]:
        """Violations from holding the first action for the commitment window."""
        window = min(self.commitment_window_s, problem.horizon_s)
        steps = max(1, int(round(window / problem.dt_s)))
        held = Scenario(
            label=f"{scenario.label} held",
            power_w=(scenario.first_power_w,) * steps,
            cooling=(scenario.first_cooling,) * steps,
            tags=("held",),
        )
        evaluated = self.scenarios.evaluate(problem, held)
        return list(evaluated.hard_violations)

    def _repair(
        self, problem: OptimisationProblem, result: MethodResult, scenario: Scenario
    ) -> tuple[Scenario, Any, list[Any]]:
        """Scale a violating plan down until its simulated consequences are legal.

        Bisection on a single scale factor rather than a per-step projection,
        because the violations that matter are *cumulative*: a power that is
        admissible for one interval can still cook the pack over ten of them,
        and clamping each step against the present-state bounds cannot see that.
        Scaling the whole plan can, and it converges in a fixed number of
        simulations.
        """
        n = len(scenario.power_w)
        cooling = (1.0,) * n  # more cooling never makes a limit harder to meet

        def attempt(alpha: float) -> tuple[Scenario, Any, list[Any], list[Any]]:
            candidate = Scenario(
                label=f"plan[{result.method}] scaled {alpha:.3f}",
                power_w=tuple(p * alpha for p in scenario.power_w),
                cooling=cooling,
                description=result.reason + f" (scaled to {alpha * 100:.0f} % for safety)",
                tags=("plan", result.method, "repaired"),
            )
            ev = self.scenarios.evaluate(problem, candidate)
            committed, advisory = self._split_violations(problem, ev)
            committed = committed + self._held_action_violations(problem, candidate)
            return candidate, ev, committed, advisory

        rest_scenario, rest_evaluated, rest_committed, rest_advisory = attempt(0.0)
        if rest_committed:
            preexisting = problem.constraints.check_state(
                problem.state, include_soft=False
            )
            detail = "; ".join(str(v) for v in rest_committed[:3])
            if preexisting:
                raise SafetyViolation(
                    "the battery is already outside its operating envelope, so no "
                    "recommendation can be made: "
                    + "; ".join(str(v) for v in preexisting[:3]),
                    list(preexisting),
                )
            raise SafetyViolation(
                f"no admissible plan exists from this state -- even resting breaches "
                f"a hard constraint: {detail}",
                rest_committed,
            )

        best = (0.0, rest_scenario, rest_evaluated, rest_advisory)
        lo, hi = 0.0, 1.0
        for _ in range(12):
            mid = 0.5 * (lo + hi)
            candidate, ev, committed, advisory = attempt(mid)
            if committed:
                hi = mid
            else:
                lo = mid
                best = (mid, candidate, ev, advisory)
        log.info(
            "repaired a %s plan by scaling it to %.1f %% of the proposed power",
            result.method,
            best[0] * 100.0,
        )
        return best[1], best[2], best[3]

    def _split_violations(
        self, problem: OptimisationProblem, evaluated: Any
    ) -> tuple[list[Any], list[Any]]:
        """Partition hard violations into committed-window and advisory-tail."""
        cutoff = problem.state.timestamp + self.commitment_window_s
        committed: list[Any] = []
        advisory: list[Any] = []
        for violation in evaluated.hard_violations:
            at = violation.at_time_s
            if at is None or at <= cutoff + 1e-9:
                committed.append(violation)
            else:
                advisory.append(violation)
        return committed, advisory

    @staticmethod
    def _confidence(problem: OptimisationProblem, evaluated: Any, result: MethodResult) -> float:
        """Combine model confidence with how close the plan sits to a limit.

        A recommendation pressed hard against a constraint is more fragile than
        one in the middle of the feasible region, because a small state error
        moves it outside. That fragility belongs in the confidence figure.
        """
        battery = problem.constraints.battery
        outcome = evaluated.outcome
        degradation_confidence = battery.degradation.confidence(
            soc=problem.state.soc,
            temperature_c=problem.state.temperature_c,
            c_rate=abs(problem.state.c_rate),
        )
        bounds = problem.constraints.bounds(problem.state, problem.dt_s)
        chosen = result.first_power_w
        margin = min(
            abs(chosen - bounds.min_power_w), abs(bounds.max_power_w - chosen)
        ) / max(bounds.width_w, 1.0)
        proximity = clamp(0.55 + 0.9 * margin, 0.5, 1.0)
        soft_penalty = 1.0 - 0.05 * min(len(evaluated.soft_violations), 4)
        curtailment = 0.85 if outcome.curtailed else 1.0
        method_factor = 1.0 if result.converged else 0.85
        return clamp(
            degradation_confidence * proximity * soft_penalty * curtailment * method_factor,
            0.05,
            0.99,
        )

    # -- public entry points ------------------------------------------------

    def optimise(self, problem: OptimisationProblem) -> Recommendation:
        """Solve one problem and return a verified recommendation."""
        started = time.perf_counter()
        if self.method == "auto":
            choice = select_method(problem)
        else:
            choice = MethodChoice(
                primary=self.method,
                fallbacks=("golden_section", "surrogate_sweep", "enumeration"),
                reason=f"Method {self.method!r} requested explicitly.",
            )
        if self.commitment_window_s <= 0.0:
            # The whole horizon is committed unless a caller that genuinely
            # re-plans (the MPC layer) says otherwise.
            self.commitment_window_s = problem.horizon_s
        result, attempts = self._run_method(problem, choice)
        scenario, evaluated, advisory = self._verify(problem, result)

        limiting = evaluated.outcome.limiting_constraint
        if limiting is None:
            bounds = problem.constraints.bounds(problem.state, problem.dt_s)
            chosen = scenario.first_power_w
            if abs(chosen - bounds.max_power_w) < 1e-6:
                limiting = bounds.discharge_limiting
            elif abs(chosen - bounds.min_power_w) < 1e-6:
                limiting = bounds.charge_limiting
        if limiting is None and evaluated.soft_violations:
            limiting = evaluated.soft_violations[0].constraint.name

        reason = " ".join(
            part
            for part in (
                choice.reason,
                result.reason,
                evaluated.value.explain(),
            )
            if part
        )
        alternatives = list(result.alternatives)
        if advisory:
            reason += (
                f" Note: {len(advisory)} hard-constraint excursions appear later in the "
                "advisory tail of the plan; only the first interval is committed and the "
                "plan will be re-derived from a measured state before those intervals "
                "are reached."
            )
        recommendation = build_recommendation(
            problem=problem,
            power_w=scenario.first_power_w,
            cooling=scenario.first_cooling,
            outcome=evaluated.outcome,
            value=evaluated.value,
            limiting=limiting,
            plan_power=scenario.power_w,
            plan_cooling=scenario.cooling,
            alternatives=alternatives,
            soft_violations=evaluated.soft_violations,
            reason=reason,
            method=result.method,
            confidence=self._confidence(problem, evaluated, result)
            * (0.85 if advisory else 1.0),
            solve_seconds=time.perf_counter() - started,
        )
        if advisory:
            recommendation.meta["advisory_violations"] = [v.as_dict() for v in advisory]
        recommendation.meta["method_attempts"] = attempts
        return recommendation

    def optimise_state(
        self,
        state: BatteryState,
        *,
        demand: Demand | float | None = None,
        objective: Objective | ObjectiveConfig | str | None = None,
        horizon_s: float = 900.0,
        dt_s: float = 60.0,
        **kwargs: Any,
    ) -> Recommendation:
        """Convenience wrapper: build the problem and solve it in one call."""
        problem = self.build_problem(
            state,
            demand=demand,
            objective=objective,
            horizon_s=horizon_s,
            dt_s=dt_s,
            **kwargs,
        )
        return self.optimise(problem)

    def pareto(self, problem: OptimisationProblem, **kwargs: Any) -> ParetoFront:
        """Return the Pareto front of trade-offs for this problem."""
        method = ParetoMethod(engine=self.scenarios, **kwargs)
        return method.front(problem)

    def compare(
        self, problem: OptimisationProblem, scenarios: Sequence[Scenario] | None = None
    ) -> list[Any]:
        """Score an explicit candidate set, for explanation rather than control."""
        if scenarios is None:
            from ..scenario.strategies import default_candidates

            scenarios = default_candidates(problem)
        return self.scenarios.compare(problem, scenarios)


# ---------------------------------------------------------------------------
# Module-level convenience API (specification section 27)
# ---------------------------------------------------------------------------


def optimise(
    *,
    battery_state: BatteryState,
    battery: Battery,
    demand: Demand | float | None = None,
    objective: str | ObjectiveConfig | Objective = "balanced",
    constraints: ConstraintSet | None = None,
    tariff: Tariff | None = None,
    economics: EconomicEngine | EconomicConfig | None = None,
    horizon_s: float = 900.0,
    dt_s: float = 60.0,
    method: str = "auto",
    **kwargs: Any,
) -> Recommendation:
    """Recommend an operating point for a battery in a given state.

    This is the function the specification's example calls::

        result = batteryopt.optimise(
            battery_state=state, demand=demand, objective="lifetime_efficiency"
        )

    The returned :class:`~batteryopt.optimisation.problem.Recommendation` is
    guaranteed to satisfy every configured hard constraint when simulated
    through the plant model; the engine raises rather than returning one that
    does not.
    """
    engine = OptimisationEngine(
        battery,
        objective=objective,
        constraints=constraints,
        economics=economics,
        tariff=tariff,
        method=method,
    )
    return engine.optimise_state(
        battery_state, demand=demand, horizon_s=horizon_s, dt_s=dt_s, **kwargs
    )


__all__ = [
    "OptimisationEngine",
    "optimise",
    "select_method",
    "MethodChoice",
    "METHODS",
    "available_methods",
]
