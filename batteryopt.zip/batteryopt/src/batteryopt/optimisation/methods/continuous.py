"""Continuous search over the immediate operating point.

For "what power should the battery run at right now?", the decision variable is
one or two continuous numbers and the objective is smooth-ish but not
differentiable in closed form (tariffs are piecewise constant, constraints
saturate). Two backends cover that:

* :class:`GoldenSectionMethod` -- derivative-free 1-D search over power, with an
  outer search over the cooling command. Unimodality is not guaranteed in
  general, so the search is seeded by a coarse bracket from enumeration; that
  combination is robust in a way that either alone is not.
* :class:`ScipyMethod` -- SciPy's bounded minimisers over the same variables,
  used when the problem is well conditioned and a sharper answer is wanted.

Both evaluate through the full plant model, so the score they return is
directly comparable with every other method's.
"""

from __future__ import annotations

import time
from typing import Callable

import numpy as np
from scipy import optimize

from ...core.exceptions import InfeasibleProblem
from ...core.numerics import EPS, clamp, golden_section
from ...scenario.engine import ScenarioEngine
from ...scenario.strategies import constant_power
from ..problem import OptimisationProblem
from .base import MethodResult


def _make_evaluator(
    problem: OptimisationProblem, engine: ScenarioEngine
) -> Callable[[float, float], tuple[float, dict]]:
    """Return a function scoring one (power, cooling) pair through the plant."""
    cache: dict[tuple[int, int], tuple[float, dict]] = {}

    def evaluate(power_w: float, cooling: float) -> tuple[float, dict]:
        key = (int(round(power_w)), int(round(cooling * 1000)))
        hit = cache.get(key)
        if hit is not None:
            return hit
        scenario = constant_power(
            problem,
            power_w,
            label=f"p={power_w / 1000.0:.2f}kW c={cooling:.2f}",
            cooling=cooling,
            tags=("continuous",),
        )
        result = engine.evaluate(problem, scenario)
        payload = (
            result.score,
            {
                "power_w": scenario.first_power_w,
                "cooling": cooling,
                "feasible": result.feasible,
                "outcome": result.outcome,
                "violations": result.hard_violations,
            },
        )
        cache[key] = payload
        return payload

    return evaluate


class GoldenSectionMethod:
    """Derivative-free search over power, with a nested search over cooling."""

    name = "golden_section"

    def __init__(
        self,
        *,
        engine: ScenarioEngine | None = None,
        cooling_points: tuple[float, ...] = (0.0, 0.2, 0.4, 0.6, 0.8, 1.0),
        bracket_points: int = 9,
        tolerance_w: float = 50.0,
    ) -> None:
        self._engine = engine
        self.cooling_points = cooling_points
        #: Coarse bracket resolution. The objective can be multi-modal when a
        #: constraint saturates part-way through the range, so a pure golden
        #: section from the full interval is not safe; bracketing first is.
        self.bracket_points = bracket_points
        self.tolerance_w = tolerance_w

    def suitable_for(self, problem: OptimisationProblem) -> bool:
        return problem.n_steps <= 240

    def solve(self, problem: OptimisationProblem) -> MethodResult:
        started = time.perf_counter()
        engine = self._engine or ScenarioEngine(problem.constraints.battery)
        evaluate = _make_evaluator(problem, engine)
        bounds = problem.constraints.bounds(problem.state, problem.dt_s)
        if bounds.width_w <= EPS:
            raise InfeasibleProblem(
                "feasible power interval is empty",
                limiting=bounds.discharge_limiting,
            )

        best = (float("-inf"), 0.0, 0.0, {})
        evaluations = 0
        for cooling in self.cooling_points:
            grid = np.linspace(bounds.min_power_w, bounds.max_power_w, self.bracket_points)
            scores = []
            for p in grid:
                s, meta = evaluate(float(p), cooling)
                evaluations += 1
                scores.append(s if meta["feasible"] else float("-inf"))
            k = int(np.argmax(scores))
            if scores[k] == float("-inf"):
                continue
            lo = float(grid[max(0, k - 1)])
            hi = float(grid[min(len(grid) - 1, k + 1)])

            def negative(p: float, _c: float = cooling) -> float:
                s, meta = evaluate(p, _c)
                return -s if meta["feasible"] else 1e18

            p_opt, neg = golden_section(negative, lo, hi, tol=self.tolerance_w)
            evaluations += 30
            score = -neg
            if score > best[0]:
                _, meta = evaluate(p_opt, cooling)
                best = (score, p_opt, cooling, meta)

        if best[0] == float("-inf"):
            raise InfeasibleProblem(
                "no feasible operating point found in the admissible interval",
                limiting=bounds.discharge_limiting,
            )

        score, power, cooling, meta = best
        n = problem.n_steps
        return MethodResult(
            power_w=(float(power),) * n,
            cooling=(float(cooling),) * n,
            score=score,
            method=self.name,
            diagnostics={
                "evaluations": evaluations,
                "bounds_w": [bounds.min_power_w, bounds.max_power_w],
                "solve_seconds": time.perf_counter() - started,
            },
            reason=(
                f"Continuous search over the admissible interval "
                f"[{bounds.min_power_w / 1000.0:.1f}, {bounds.max_power_w / 1000.0:.1f}] kW "
                f"with cooling at {cooling * 100:.0f} %."
            ),
        )


class ScipyMethod:
    """Bounded minimisation with SciPy over (power, cooling) jointly."""

    name = "scipy"

    def __init__(
        self,
        *,
        engine: ScenarioEngine | None = None,
        optimiser: str = "L-BFGS-B",
        max_iterations: int = 60,
        restarts: int = 3,
    ) -> None:
        self._engine = engine
        self.optimiser = optimiser
        self.max_iterations = max_iterations
        #: Multi-start, because the feasible region can be disconnected when a
        #: temperature or voltage limit binds part-way through the horizon.
        self.restarts = restarts

    def suitable_for(self, problem: OptimisationProblem) -> bool:
        return problem.n_steps <= 240

    def solve(self, problem: OptimisationProblem) -> MethodResult:
        started = time.perf_counter()
        engine = self._engine or ScenarioEngine(problem.constraints.battery)
        evaluate = _make_evaluator(problem, engine)
        bounds = problem.constraints.bounds(problem.state, problem.dt_s)
        if bounds.width_w <= EPS:
            raise InfeasibleProblem("feasible power interval is empty")

        span = max(bounds.width_w, EPS)

        def negative(x: np.ndarray) -> float:
            power = bounds.min_power_w + clamp(float(x[0]), 0.0, 1.0) * span
            cooling = clamp(float(x[1]), 0.0, 1.0)
            score, meta = evaluate(power, cooling)
            # Infeasible points get a large but finite penalty so that gradient
            # estimates near the boundary stay informative.
            return -score if meta["feasible"] else 1e9 - score * 0.0

        best_x, best_val = None, float("inf")
        starts = np.linspace(0.1, 0.9, max(1, self.restarts))
        for s in starts:
            x0 = np.array([s, 0.4])
            try:
                res = optimize.minimize(
                    negative,
                    x0,
                    method=self.optimiser,
                    bounds=[(0.0, 1.0), (0.0, 1.0)],
                    options={"maxiter": self.max_iterations},
                )
            except Exception:  # pragma: no cover - solver-specific failures
                continue
            if res.fun < best_val:
                best_val, best_x = float(res.fun), res.x

        if best_x is None or best_val >= 1e8:
            raise InfeasibleProblem("SciPy found no feasible operating point")

        power = bounds.min_power_w + clamp(float(best_x[0]), 0.0, 1.0) * span
        cooling = clamp(float(best_x[1]), 0.0, 1.0)
        score, _ = evaluate(power, cooling)
        n = problem.n_steps
        return MethodResult(
            power_w=(float(power),) * n,
            cooling=(float(cooling),) * n,
            score=score,
            method=self.name,
            diagnostics={
                "optimiser": self.optimiser,
                "restarts": self.restarts,
                "solve_seconds": time.perf_counter() - started,
            },
            reason=f"SciPy {self.optimiser} over power and cooling, {self.restarts} restarts.",
        )


__all__ = ["GoldenSectionMethod", "ScipyMethod"]
