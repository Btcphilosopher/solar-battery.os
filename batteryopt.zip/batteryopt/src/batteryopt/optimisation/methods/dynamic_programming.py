"""Dynamic programming over a discretised state of charge.

The linear programme is fast and exact for the problem it models -- but the
problem it models is linear, and battery economics are not. Round-trip
efficiency falls with power, resistance rises at low SOC and low temperature,
and degradation is a convex-then-concave function of rate and depth. Where
those non-linearities decide the answer, dynamic programming solves the real
problem instead of a convenient approximation of it.

Backward induction over an SOC grid:

.. code-block:: text

    V_N(e)  = -terminal_value * e
    V_k(e)  = min over e' of [ stage_cost(e -> e', k) + V_{k+1}(e') ]

The stage cost is evaluated with the vectorised surrogate, so a 101-point SOC
grid over 48 intervals -- roughly half a million transitions -- costs tens of
milliseconds rather than minutes.

DP earns its keep in three places: it is exact for non-convex costs, it
naturally produces the *value function*, which is the terminal energy value the
LP and MPC layers need, and its policy is a lookup table rather than a schedule,
so it degrades gracefully when the state drifts from plan.
"""

from __future__ import annotations

import time

import numpy as np

from ...core.exceptions import InfeasibleProblem
from ...core.numerics import EPS
from ...core.units import SECONDS_PER_HOUR
from ...models.surrogate import build_surrogate, degradation_rate_array
from ..problem import OptimisationProblem
from .base import MethodResult


class DynamicProgrammingMethod:
    """Backward induction over an SOC grid with the true non-linear stage cost."""

    name = "dynamic_programming"

    def __init__(
        self,
        *,
        n_soc: int = 81,
        cooling: float = 0.3,
        terminal_value_per_kwh: float | None = None,
        include_degradation: bool = True,
        voltage_margin_v: float = 0.5,
        soc_margin: float = 0.02,
    ) -> None:
        self.n_soc = n_soc
        #: Voltage headroom kept between the dynamic programme's feasible set
        #: and the true hard limit. The DP works on a discretised SOC grid and
        #: a surrogate with a small interpolation error; without a margin its
        #: optimum sits exactly on the limit, and the full-fidelity guard then
        #: rejects the plan for a millivolt.
        self.voltage_margin_v = voltage_margin_v
        #: SOC headroom kept between the programme's grid and the hard SOC
        #: limits. The programme plans against a surrogate without diffusion
        #: dynamics; over a long horizon the real trajectory drifts from the
        #: planned one, and a grid that runs to the exact rails leaves nowhere
        #: for that drift to go.
        self.soc_margin = soc_margin
        self.cooling = cooling
        self.terminal_value_per_kwh = terminal_value_per_kwh
        self.include_degradation = include_degradation

    def suitable_for(self, problem: OptimisationProblem) -> bool:
        return 2 <= problem.n_steps <= 400

    # -- stage cost ---------------------------------------------------------

    @staticmethod
    def _transition_current(
        delta_soc: np.ndarray,
        *,
        capacity_ah: float,
        dt_s: float,
        coulombic_efficiency: float,
    ) -> np.ndarray:
        """Current required to move between two SOC grid points.

        Deliberately worked in **charge**, not energy. SOC is defined by
        coulomb counting, and the plant integrates ``dSOC = -I dt / (3600 Q)``
        exactly. Solving the transition in energy space instead introduces a
        mismatch between what the dynamic programme thinks a transition does
        and what the plant actually does -- small per step, but enough over a
        long horizon to walk the trajectory into a voltage limit the DP
        believed it was avoiding.
        """
        ah = -np.asarray(delta_soc, dtype=float) * capacity_ah
        current = ah * 3600.0 / max(dt_s, EPS)
        # Charging (current < 0) suffers coulombic loss: more charge must be
        # pushed in than ends up stored.
        return np.where(current < 0.0, current / max(coulombic_efficiency, EPS), current)

    def solve(self, problem: OptimisationProblem) -> MethodResult:
        started = time.perf_counter()
        battery = problem.constraints.battery
        n = problem.n_steps
        dt_h = problem.dt_s / SECONDS_PER_HOUR
        env = battery.envelope

        span = env.soc_max - env.soc_min
        margin = min(self.soc_margin, 0.25 * span)
        soc_grid = np.linspace(env.soc_min + margin, env.soc_max - margin, self.n_soc)
        energy_grid = np.array([battery.energy_between(0.0, s) for s in soc_grid])

        bounds = problem.constraints.bounds(problem.state, problem.dt_s)
        p_min, p_max = bounds.min_power_w, bounds.max_power_w
        if p_max - p_min <= EPS:
            raise InfeasibleProblem("no admissible power interval for dynamic programming")

        surface = build_surrogate(battery)
        temperature = problem.state.temperature_c

        tariff = problem.tariff or problem.objective.tariff
        rel = np.arange(n) * problem.dt_s
        abs_times = problem.state.timestamp + rel
        if tariff is not None:
            import_price = np.asarray(tariff.import_at(abs_times), dtype=float).reshape(n)
            export_price = (
                np.asarray(tariff.export_at(abs_times), dtype=float).reshape(n)
                if tariff.export_price is not None
                else import_price
            )
        else:
            flat = problem.objective.economics.config.default_energy_value_per_kwh
            import_price = np.full(n, flat)
            export_price = np.full(n, flat)

        terminal_value = (
            self.terminal_value_per_kwh
            if self.terminal_value_per_kwh is not None
            else (
                problem.terminal_energy_value_per_kwh
                if problem.terminal_energy_value_per_kwh is not None
                else float(np.mean(import_price))
            )
        )

        demand = problem.demand_profile()
        solar = problem.solar_profile()
        firm = problem.demand.firm if problem.demand is not None else False
        shortfall_price = problem.objective.economics.config.mission_shortfall_cost_per_wh
        lifetime_weight = problem.objective.config.weight("lifetime")
        econ = problem.objective.economics

        # --- precompute the transition grid ---------------------------------
        capacity_ah = max(battery.capacity, EPS)
        soc_mid = 0.5 * (soc_grid[:, None] + soc_grid[None, :])
        delta_soc = soc_grid[None, :] - soc_grid[:, None]
        current = self._transition_current(
            delta_soc,
            capacity_ah=capacity_ah,
            dt_s=problem.dt_s,
            coulombic_efficiency=env.coulombic_efficiency,
        )

        # Terminal power follows from the current through the ECM, evaluated at
        # the mid-interval SOC (the representative operating point) and again at
        # the end SOC (where the voltage limits actually bind).
        ocv_mid = surface.interpolate("ocv_v", soc_mid, temperature)
        r_mid = np.where(
            current < 0.0,
            surface.interpolate("r_charge_ohm", soc_mid, temperature),
            surface.interpolate("r_discharge_ohm", soc_mid, temperature),
        )
        v_mid = ocv_mid - current * r_mid
        power = v_mid * current
        loss_w = current * current * r_mid

        # The plan is *emitted* as power, and the plant converts that power back
        # into a current using the state at the START of the interval. To make
        # the round trip exact -- so the plant lands on the SOC the programme
        # planned for -- the emitted power must be computed at the start SOC
        # too. Mid-interval values remain the right ones for costing, because
        # they represent the interval as a whole.
        soc_start = np.broadcast_to(soc_grid[:, None], current.shape)
        ocv_start = surface.interpolate("ocv_v", soc_start, temperature)
        r_start = np.where(
            current < 0.0,
            surface.interpolate("r_charge_ohm", soc_start, temperature),
            surface.interpolate("r_discharge_ohm", soc_start, temperature),
        )
        v_start = ocv_start - current * r_start
        power_command = v_start * current

        clipped = np.clip(power, p_min, p_max)
        feasible = (power >= p_min - EPS) & (power <= p_max + EPS)
        feasible &= np.abs(current) <= max(
            battery.maximum_current, battery.maximum_charge_current
        )
        feasible &= np.where(
            current < 0.0,
            np.abs(current) <= battery.maximum_charge_current,
            current <= battery.maximum_current,
        )
        feasible &= v_mid >= battery.minimum_voltage + self.voltage_margin_v
        feasible &= v_mid <= battery.maximum_voltage - self.voltage_margin_v
        feasible &= v_start >= battery.minimum_voltage + self.voltage_margin_v
        feasible &= v_start <= battery.maximum_voltage - self.voltage_margin_v
        feasible &= power_command >= p_min - EPS
        feasible &= power_command <= p_max + EPS

        # Voltage feasibility is evaluated at the *end* of the interval, not the
        # middle. Charging pushes the terminal voltage highest when the cell is
        # fullest, and discharging pushes it lowest when the cell is emptiest --
        # both of which happen at the end state. Checking the midpoint passes
        # transitions that breach the limit on arrival, which the engine's
        # full-fidelity guard then correctly rejects, leaving the controller
        # with no plan at all. Checking the endpoint is what makes the
        # dynamic programme's own feasible set match the real one.
        soc_end = np.broadcast_to(soc_grid[None, :], power.shape)
        ocv_end = surface.interpolate("ocv_v", soc_end, temperature)
        r_end = np.where(
            current < 0.0,
            surface.interpolate("r_charge_ohm", soc_end, temperature),
            surface.interpolate("r_discharge_ohm", soc_end, temperature),
        )
        v_end = ocv_end - current * r_end
        feasible &= v_end >= battery.minimum_voltage + self.voltage_margin_v
        feasible &= v_end <= battery.maximum_voltage - self.voltage_margin_v

        if self.include_degradation:
            fade_rate = degradation_rate_array(
                battery,
                soc=soc_mid,
                temperature_c=np.full_like(soc_mid, temperature),
                current_a=current,
            )
            fade = fade_rate * problem.dt_s
            degradation_cost = lifetime_weight * econ.degradation_cost(
                1.0, remaining_years=problem.objective.config.remaining_life_years
            ) * fade
        else:
            degradation_cost = np.zeros_like(power)

        big = 1e15
        # --- backward induction ---------------------------------------------
        value = -terminal_value * energy_grid / 1000.0
        policy = np.zeros((n, self.n_soc), dtype=np.int32)
        for k in range(n - 1, -1, -1):
            served = np.clip(power, 0.0, None)
            required = max(0.0, float(demand[k] - solar[k]))
            shortfall = np.clip(required - served, 0.0, None) * dt_h if firm else 0.0

            # Charging is *not* always priced at the import tariff, and getting
            # this wrong is expensive. When the site has a local surplus -- more
            # generation than load -- the marginal cost of the energy going into
            # the battery is the export revenue forgone, not the import price.
            # Priced at the import tariff, the optimiser exports free generation
            # at 0.03 and then buys grid energy at the off-peak rate to fill the
            # battery, which is exactly backwards.
            #
            # The mirror image applies to discharging: energy that offsets unmet
            # load is worth the *import* price avoided, and only the remainder is
            # worth the export price.
            surplus_w = max(0.0, float(solar[k] - demand[k]))
            deficit_w = max(0.0, float(demand[k] - solar[k]))

            charge_w = np.clip(-power, 0.0, None)
            discharge_w = np.clip(power, 0.0, None)

            from_surplus = np.minimum(charge_w, surplus_w)
            from_grid = charge_w - from_surplus
            to_load = np.minimum(discharge_w, deficit_w)
            to_grid = discharge_w - to_load

            energy_cost = (
                from_grid * import_price[k]
                + from_surplus * export_price[k]
                - to_load * import_price[k]
                - to_grid * export_price[k]
            ) * dt_h / 1000.0
            stage = energy_cost + degradation_cost + shortfall * shortfall_price
            stage = np.where(feasible, stage, big)

            total = stage + value[None, :]
            best = np.argmin(total, axis=1)
            policy[k] = best
            value = total[np.arange(self.n_soc), best]

        # --- roll the policy forward from the actual state -------------------
        start_index = int(np.argmin(np.abs(soc_grid - problem.state.soc)))
        plan_power: list[float] = []
        idx = start_index
        for k in range(n):
            j = int(policy[k, idx])
            plan_power.append(float(np.clip(power_command[idx, j], p_min, p_max)))
            idx = j
        final_soc = float(soc_grid[idx])

        if value[start_index] >= big / 2:
            raise InfeasibleProblem(
                "dynamic programme found no feasible trajectory from the current state"
            )

        return MethodResult(
            power_w=tuple(plan_power),
            cooling=(self.cooling,) * n,
            score=-float(value[start_index]),
            method=self.name,
            diagnostics={
                "soc_grid_points": self.n_soc,
                "transitions": int(self.n_soc * self.n_soc * n),
                "terminal_value_per_kwh": terminal_value,
                "final_soc": final_soc,
                "value_at_start": float(value[start_index]),
                "solve_seconds": time.perf_counter() - started,
            },
            reason=(
                f"Dynamic programme over a {self.n_soc}-point SOC grid and {n} intervals "
                f"({self.n_soc * self.n_soc * n:,} transitions), with non-linear losses "
                "and degradation priced per transition."
            ),
        )

    def value_function(self, problem: OptimisationProblem) -> np.ndarray:
        """Expose the value function; used to set terminal values elsewhere.

        The derivative of this with respect to stored energy is the marginal
        value of energy in the battery -- exactly the number the arbitrage layer
        and MPC need so that a finite horizon does not distort the answer.
        """
        result = self.solve(problem)
        return np.asarray(result.diagnostics.get("value_curve", []))


__all__ = ["DynamicProgrammingMethod"]
