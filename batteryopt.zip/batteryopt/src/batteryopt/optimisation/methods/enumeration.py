"""Enumeration over an explicit candidate set.

The simplest method and the most trustworthy: build a set of candidate
strategies, simulate every one through the real plant, score them all, take the
best feasible one. No gradients, no convexity assumptions, no solver status to
interpret, and the full comparison table falls out as a by-product -- which is
exactly what section 3 of the specification asks the engine to show.

Its cost is resolution: the answer is only as good as the grid. That is why the
engine uses enumeration to bracket the optimum and then refines it with a
continuous method, rather than choosing between them.
"""

from __future__ import annotations

import time
from typing import Sequence

from ...core.exceptions import InfeasibleProblem
from ...scenario.engine import Scenario, ScenarioEngine
from ...scenario.strategies import archetypes, cooling_sweep, default_candidates, power_sweep
from ..problem import OptimisationProblem
from .base import MethodResult


class EnumerationMethod:
    """Exhaustive comparison over a candidate set."""

    name = "enumeration"

    def __init__(
        self,
        *,
        engine: ScenarioEngine | None = None,
        candidates: Sequence[Scenario] | None = None,
        power_points: int = 21,
        cooling_points: tuple[float, ...] = (0.0, 0.3, 0.6, 1.0),
        include_archetypes: bool = True,
        max_alternatives: int = 12,
    ) -> None:
        self._engine = engine
        self._candidates = list(candidates) if candidates else None
        self.power_points = power_points
        self.cooling_points = cooling_points
        self.include_archetypes = include_archetypes
        self.max_alternatives = max_alternatives

    def suitable_for(self, problem: OptimisationProblem) -> bool:
        return True  # always applicable, if not always sharp

    def build_candidates(self, problem: OptimisationProblem) -> list[Scenario]:
        if self._candidates is not None:
            return list(self._candidates)
        out: list[Scenario] = []
        if self.include_archetypes:
            out.extend(archetypes(problem))
        for cooling in self.cooling_points:
            out.extend(power_sweep(problem, n=self.power_points, cooling=cooling))
        return out

    def solve(self, problem: OptimisationProblem) -> MethodResult:
        started = time.perf_counter()
        engine = self._engine or ScenarioEngine(problem.constraints.battery)
        candidates = self.build_candidates(problem)
        results = engine.compare(problem, candidates)
        feasible = [r for r in results if r.feasible]
        if not feasible:
            raise InfeasibleProblem(
                "every enumerated candidate violated a hard constraint",
                limiting=(
                    results[0].hard_violations[0].constraint.name if results else None
                ),
            )
        best = feasible[0]
        alternatives = [r.as_dict() for r in results[1 : 1 + self.max_alternatives]]
        return MethodResult(
            power_w=best.scenario.power_w,
            cooling=best.scenario.cooling or (0.0,) * len(best.scenario),
            score=best.score,
            method=self.name,
            alternatives=alternatives,
            diagnostics={
                "candidates": len(candidates),
                "feasible": len(feasible),
                "infeasible": len(results) - len(feasible),
                "best_label": best.scenario.label,
            },
            reason=(
                f"Best of {len(feasible)} feasible candidates out of {len(candidates)} "
                f"evaluated: {best.scenario.label}."
            ),
        )


class ScenarioComparisonMethod(EnumerationMethod):
    """Enumeration restricted to the named archetypes plus cooling variants.

    Used when the caller wants the *explanatory* comparison -- FAST versus
    NORMAL versus ECO -- rather than the sharpest possible number.
    """

    name = "scenario_comparison"

    def build_candidates(self, problem: OptimisationProblem) -> list[Scenario]:
        out = default_candidates(problem, sweep=9)
        demand = problem.demand_profile()
        if demand.size and float(demand.max()) > 0.0:
            out.extend(cooling_sweep(problem, float(demand.max())))
        return out


__all__ = ["EnumerationMethod", "ScenarioComparisonMethod"]
