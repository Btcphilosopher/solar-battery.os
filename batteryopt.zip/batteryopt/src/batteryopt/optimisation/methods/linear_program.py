"""Linear programming for multi-period energy scheduling.

Arbitrage, load shifting and peak shaving over a day are scheduling problems,
not point decisions. Written in terms of *energy* rather than power they are
very nearly linear, and a linear programme solves a 96-interval day in a few
milliseconds -- fast enough to re-solve every control cycle inside MPC.

Formulation
-----------
Decision variables per interval ``k``: charge power ``c_k >= 0``, discharge
power ``d_k >= 0``, and stored energy ``e_k``.

.. code-block:: text

    minimise  sum_k [ p_k*c_k*dt - q_k*d_k*dt + w*(c_k + d_k)*dt ] - v_T * e_N

    subject to  e_{k+1} = e_k + eta_c*c_k*dt - d_k*dt/eta_d
                e_min <= e_k <= e_max
                0 <= c_k <= C_k,   0 <= d_k <= D_k

``p_k`` is the import price, ``q_k`` the export/value price, ``w`` the marginal
wear cost per unit of throughput, and ``v_T`` the terminal value of stored
energy.

Three modelling points that decide whether the answer is any good:

* **The wear term.** Without ``w`` the LP trades on any price spread at all,
  including spreads far too small to pay for the battery life consumed. With
  it, the optimiser only cycles when the spread clears round-trip losses *and*
  degradation -- which is the whole point of section 18.
* **The terminal value.** A finite-horizon LP with no terminal value empties
  the battery on the last interval of every horizon, because stored energy is
  worthless after the horizon ends. Section 16 calls this out explicitly.
* **Simultaneous charge and discharge.** The LP can in principle do both at
  once to burn energy when prices go negative. That is physically impossible,
  so it is checked for and reported; with a positive wear cost and non-unity
  efficiency it is never optimal, which is why a linear relaxation suffices
  and the integer formulation is only needed for genuinely discrete decisions.
"""

from __future__ import annotations

import time

import numpy as np
from scipy import optimize

from ...core.exceptions import InfeasibleProblem, OptimisationError
from ...core.numerics import EPS
from ...core.units import SECONDS_PER_HOUR
from ..problem import OptimisationProblem
from .base import MethodResult


class LinearProgramMethod:
    """Energy-space LP over the planning horizon."""

    name = "linear_program"

    def __init__(
        self,
        *,
        wear_cost_per_kwh: float | None = None,
        terminal_value_per_kwh: float | None = None,
        cooling: float = 0.3,
        solver: str = "highs",
    ) -> None:
        #: Marginal cost of moving one kWh through the battery, in currency.
        #: Derived from the economic engine when not supplied.
        self.wear_cost_per_kwh = wear_cost_per_kwh
        self.terminal_value_per_kwh = terminal_value_per_kwh
        self.cooling = cooling
        self.solver = solver

    def suitable_for(self, problem: OptimisationProblem) -> bool:
        # Worth using once there are enough intervals for scheduling to matter.
        return problem.n_steps >= 4

    # -- helpers ------------------------------------------------------------

    def _wear_cost(self, problem: OptimisationProblem) -> float:
        if self.wear_cost_per_kwh is not None:
            return self.wear_cost_per_kwh
        objective = problem.objective
        econ = objective.economics
        battery = problem.constraints.battery
        # One equivalent full cycle moves two nameplate energies of charge.
        chem = battery.chemistry.degradation
        state = battery.degradation_state
        a0 = chem.formation_efc
        a_eq = max(state.a_eq_efc, 0.0) + a0
        fade_per_efc = chem.a_cycle * chem.z_cycle * a_eq ** (chem.z_cycle - 1.0)
        cost_per_efc = econ.degradation_cost(
            fade_per_efc, remaining_years=objective.config.remaining_life_years
        )
        kwh_per_efc = 2.0 * max(battery.nominal_energy_wh / 1000.0, EPS)
        lifetime_weight = objective.config.weight("lifetime")
        return lifetime_weight * cost_per_efc / kwh_per_efc

    def _terminal_value(self, problem: OptimisationProblem, prices: np.ndarray) -> float:
        if self.terminal_value_per_kwh is not None:
            return self.terminal_value_per_kwh
        if problem.terminal_energy_value_per_kwh is not None:
            return problem.terminal_energy_value_per_kwh
        # A sane default: energy left in the battery is worth what it would
        # cost to buy back, averaged over the horizon. This is the neutral
        # choice that neither hoards nor dumps.
        return float(np.mean(prices))

    # -- solve --------------------------------------------------------------

    def solve(self, problem: OptimisationProblem) -> MethodResult:
        started = time.perf_counter()
        battery = problem.constraints.battery
        n = problem.n_steps
        dt_h = problem.dt_s / SECONDS_PER_HOUR

        bounds = problem.constraints.bounds(problem.state, problem.dt_s)
        p_charge_max = max(0.0, -bounds.min_power_w)
        p_discharge_max = max(0.0, bounds.max_power_w)
        if p_charge_max <= EPS and p_discharge_max <= EPS:
            raise InfeasibleProblem("no admissible power in either direction")

        env = battery.envelope
        e_min = battery.energy_between(0.0, env.soc_min)
        e_max = battery.energy_between(0.0, env.soc_max)
        e_now = battery.energy_between(0.0, problem.state.soc)

        tariff = problem.tariff or problem.objective.tariff
        rel_times = np.arange(n) * problem.dt_s
        abs_times = problem.state.timestamp + rel_times
        if tariff is not None:
            import_price = np.asarray(tariff.import_at(abs_times), dtype=float).reshape(n)
            export_price = np.asarray(tariff.export_at(abs_times), dtype=float).reshape(n)
            if tariff.export_price is None:
                export_price = import_price
        else:
            flat = problem.objective.economics.config.default_energy_value_per_kwh
            import_price = np.full(n, flat)
            export_price = np.full(n, flat)

        eta_c = env.coulombic_efficiency
        eta_d = 0.97  # representative one-way conversion efficiency

        wear = self._wear_cost(problem)
        terminal = self._terminal_value(problem, import_price)

        demand = problem.demand_profile()
        solar = problem.solar_profile()
        # Per-interval local surplus and unmet load. These are what make the
        # marginal price of charging and the marginal value of discharging depend
        # on the *site*, not only on the tariff.
        surplus = np.clip(solar - demand, 0.0, None)
        deficit = np.clip(demand - solar, 0.0, None)
        firm = problem.demand is not None and problem.demand.firm
        export_allowed = tariff is None or tariff.export_price is not None

        # Variable layout, four blocks of n plus the energy trajectory:
        #   cs_k  charge from local surplus   -- costs the export revenue forgone
        #   cg_k  charge from the grid        -- costs the import price
        #   dl_k  discharge into unmet load   -- worth the import price avoided
        #   dg_k  discharge into the grid     -- worth the export price
        #   e_k   stored energy
        # Splitting charge and discharge by *destination* rather than pricing
        # both at the import tariff is what stops the programme exporting free
        # generation and then buying grid energy to refill the battery.
        #   sh_k  unserved firm load           -- priced at the shortfall cost
        n_var = 6 * n
        CS, CG, DL, DG, EN, SH = 0, n, 2 * n, 3 * n, 4 * n, 5 * n
        shortfall_price_per_wh = (
            problem.objective.economics.config.mission_shortfall_cost_per_wh
        )
        cost = np.zeros(n_var)
        cost[CS : CS + n] = (export_price + wear) * dt_h / 1000.0
        cost[CG : CG + n] = (import_price + wear) * dt_h / 1000.0
        cost[DL : DL + n] = (-import_price + wear) * dt_h / 1000.0
        cost[DG : DG + n] = (-export_price + wear) * dt_h / 1000.0
        cost[EN + n - 1] = -terminal / 1000.0
        # Leaving a firm load unserved has to *cost* something, or the programme
        # will rationally hold energy whose terminal value exceeds the price it
        # could sell it at and let the load go dark. The DP has always priced
        # this; without the same term the LP quietly answers "rest" to "serve
        # 250 kW, firmly".
        # A non-firm demand is an opportunity, not an obligation, so leaving it
        # unserved is free.
        cost[SH : SH + n] = shortfall_price_per_wh * dt_h if firm else 0.0

        # Dynamics: e_k - e_{k-1} - eta_c*(cs_k + cg_k)*dt + (dl_k + dg_k)*dt/eta_d = 0
        rows = np.zeros((n, n_var))
        rhs = np.zeros(n)
        for k in range(n):
            rows[k, CS + k] = -eta_c * dt_h
            rows[k, CG + k] = -eta_c * dt_h
            rows[k, DL + k] = dt_h / eta_d
            rows[k, DG + k] = dt_h / eta_d
            rows[k, EN + k] = 1.0
            if k == 0:
                rhs[k] = e_now
            else:
                rows[k, EN + k - 1] = -1.0
                rhs[k] = 0.0

        # Total charge and total discharge each stay inside the power bounds, and
        # discharge into load plus shortfall must cover the unmet demand.
        power_rows = np.zeros((3 * n, n_var))
        power_rhs = np.zeros(3 * n)
        for k in range(n):
            power_rows[k, CS + k] = 1.0
            power_rows[k, CG + k] = 1.0
            power_rhs[k] = p_charge_max
            power_rows[n + k, DL + k] = 1.0
            power_rows[n + k, DG + k] = 1.0
            power_rhs[n + k] = p_discharge_max
            # -dl_k - sh_k <= -deficit_k, i.e. dl_k + sh_k >= deficit_k
            power_rows[2 * n + k, DL + k] = -1.0
            power_rows[2 * n + k, SH + k] = -1.0
            power_rhs[2 * n + k] = -float(deficit[k])

        var_bounds: list[tuple[float, float]] = []
        for k in range(n):
            # Only the actual surplus can be charged from the surplus.
            var_bounds.append((0.0, min(p_charge_max, float(surplus[k]))))
        for _ in range(n):
            var_bounds.append((0.0, p_charge_max))
        for k in range(n):
            # Only the actual unmet load can be served.
            var_bounds.append((0.0, min(p_discharge_max, float(deficit[k]))))
        for _ in range(n):
            # A firm load with no export route leaves nowhere for the energy to
            # go beyond the load itself.
            var_bounds.append((0.0, p_discharge_max if export_allowed or not firm else 0.0))
        for _ in range(n):
            var_bounds.append((e_min, e_max))
        for k in range(n):
            var_bounds.append((0.0, float(deficit[k])))

        try:
            result = optimize.linprog(
                c=cost,
                A_ub=power_rows,
                b_ub=power_rhs,
                A_eq=rows,
                b_eq=rhs,
                bounds=var_bounds,
                method=self.solver,
            )
        except Exception as exc:  # pragma: no cover - solver availability
            raise OptimisationError(f"linear programme failed: {exc}") from exc

        if not result.success:
            raise InfeasibleProblem(f"linear programme infeasible: {result.message}")

        charge = np.asarray(result.x[CS : CS + n]) + np.asarray(result.x[CG : CG + n])
        discharge = np.asarray(result.x[DL : DL + n]) + np.asarray(result.x[DG : DG + n])
        energy = np.asarray(result.x[EN:])
        simultaneous = float(np.sum(np.minimum(charge, discharge) * dt_h))

        power = discharge - charge
        return MethodResult(
            power_w=tuple(float(p) for p in power),
            cooling=(self.cooling,) * n,
            score=-float(result.fun),
            method=self.name,
            diagnostics={
                "status": int(result.status),
                "message": str(result.message),
                "wear_cost_per_kwh": wear,
                "terminal_value_per_kwh": terminal,
                "simultaneous_charge_discharge_wh": simultaneous,
                "charged_from_surplus_wh": float(
                    np.sum(np.asarray(result.x[CS : CS + n]) * dt_h)
                ),
                "charged_from_grid_wh": float(
                    np.sum(np.asarray(result.x[CG : CG + n]) * dt_h)
                ),
                "discharged_to_load_wh": float(
                    np.sum(np.asarray(result.x[DL : DL + n]) * dt_h)
                ),
                "discharged_to_grid_wh": float(
                    np.sum(np.asarray(result.x[DG : DG + n]) * dt_h)
                ),
                "final_energy_wh": float(energy[-1]) if energy.size else e_now,
                "price_spread": float(import_price.max() - import_price.min()),
                "solve_seconds": time.perf_counter() - started,
            },
            reason=(
                f"Linear programme over {n} intervals; wear priced at "
                f"{wear:.4f}/kWh against a price spread of "
                f"{import_price.max() - import_price.min():.4f}/kWh."
            ),
        )


__all__ = ["LinearProgramMethod"]
