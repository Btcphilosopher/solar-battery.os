"""Vectorised power sweep for the real-time path.

Enumeration through the full plant model costs roughly a millisecond per
simulated step, which is fine for planning and far too slow for a control loop
that must answer in single-digit milliseconds while considering hundreds of
candidate powers.

This method prices the whole candidate grid with array arithmetic against the
:class:`~batteryopt.models.surrogate.ResponseSurface`: one evaluation covers
every candidate at every step. It is the FAST-fidelity counterpart of
:class:`~batteryopt.optimisation.methods.enumeration.EnumerationMethod`, and
the engine uses it to bracket the optimum before refining with a full-fidelity
method -- so the speed is bought without giving up the accuracy of the final
answer.

Accuracy against the full model is quantified rather than assumed: see
:meth:`~batteryopt.models.surrogate.ResponseSurface.validate_against`, which
reports sub-percent RMS error on the quantities used here.
"""

from __future__ import annotations

import time

from typing import Any

import numpy as np

from ...core.exceptions import InfeasibleProblem
from ...core.numerics import EPS
from ...core.units import SECONDS_PER_HOUR
from ...models.surrogate import ResponseSurface, build_surrogate, degradation_rate_array
from ..problem import OptimisationProblem
from .base import MethodResult


class SurrogateSweepMethod:
    """Array-priced sweep over constant-power candidates."""

    name = "surrogate_sweep"

    def __init__(
        self,
        *,
        n_power: int = 257,
        cooling_points: tuple[float, ...] = (0.0, 0.2, 0.4, 0.6, 0.8, 1.0),
        surface: ResponseSurface | None = None,
        voltage_margin_v: float = 0.5,
        temperature_margin_c: float = 1.5,
    ) -> None:
        self.n_power = n_power
        self.cooling_points = cooling_points
        self._surface = surface
        #: Margins kept between this method's feasible set and the true limits.
        #: The sweep prices candidates with a surrogate that omits diffusion
        #: overpotentials and blends the thermal sink differently from the full
        #: plant, so its feasible set is very slightly optimistic. Without a
        #: margin its optimum sits exactly on a limit and the engine's guard has
        #: to scale the plan back, which wastes a solve and produces a worse
        #: answer than simply staying inside the line.
        self.voltage_margin_v = voltage_margin_v
        self.temperature_margin_c = temperature_margin_c

    def suitable_for(self, problem: OptimisationProblem) -> bool:
        return True

    def solve(self, problem: OptimisationProblem) -> MethodResult:
        started = time.perf_counter()
        battery = problem.constraints.battery
        surface = self._surface
        if surface is None or not surface.matches(battery):
            surface = build_surrogate(battery)
            self._surface = surface

        n = problem.n_steps
        dt_s = problem.dt_s
        dt_h = dt_s / SECONDS_PER_HOUR
        bounds = problem.constraints.bounds(problem.state, dt_s)
        if bounds.width_w <= EPS:
            raise InfeasibleProblem("no admissible power interval")

        powers = np.linspace(bounds.min_power_w, bounds.max_power_w, self.n_power)
        n_cool = len(self.cooling_points)
        cooling = np.asarray(self.cooling_points, dtype=float)

        thermal = battery.thermal
        econ = problem.objective.economics
        cfg = problem.objective.config
        capacity_ah = max(battery.capacity, EPS)
        eta = battery.envelope.coulombic_efficiency

        # State arrays: (n_cool, n_power)
        soc = np.full((n_cool, self.n_power), problem.state.soc)
        temp = np.full((n_cool, self.n_power), problem.state.temperature_c)
        p_grid = np.broadcast_to(powers, (n_cool, self.n_power)).copy()
        cool_grid = np.broadcast_to(cooling[:, None], (n_cool, self.n_power)).copy()

        ambient = problem.ambient_profile()
        demand = problem.demand_profile()
        solar = problem.solar_profile()
        firm = problem.demand.firm if problem.demand is not None else False

        tariff = problem.tariff or problem.objective.tariff
        abs_times = problem.state.timestamp + np.arange(n) * dt_s
        if tariff is not None:
            import_price = np.asarray(tariff.import_at(abs_times), dtype=float).reshape(n)
            export_price = (
                np.asarray(tariff.export_at(abs_times), dtype=float).reshape(n)
                if tariff.export_price is not None
                else import_price
            )
        else:
            flat = econ.config.default_energy_value_per_kwh
            import_price = np.full(n, flat)
            export_price = np.full(n, flat)

        value = np.zeros((n_cool, self.n_power))
        feasible = np.ones((n_cool, self.n_power), dtype=bool)
        peak_temp = temp.copy()
        total_fade = np.zeros_like(value)
        total_loss_wh = np.zeros_like(value)
        total_aux_wh = np.zeros_like(value)
        total_out_wh = np.zeros_like(value)
        total_in_wh = np.zeros_like(value)

        k_cool = np.array([thermal.conductance(float(c)) for c in cooling])[:, None]
        parasitic = np.array([thermal.parasitic_power(float(c)) for c in cooling])[:, None]
        fade_cost_unit = cfg.weight("lifetime") * econ.degradation_cost(
            1.0, remaining_years=cfg.remaining_life_years
        )

        for k in range(n):
            resp = surface.evaluate(soc, temp, p_grid)
            feasible &= ~resp.infeasible
            feasible &= resp.voltage_v >= battery.minimum_voltage + self.voltage_margin_v
            feasible &= resp.voltage_v <= battery.maximum_voltage - self.voltage_margin_v

            d_soc = surface.soc_delta(resp.current_a, dt_s, capacity_ah, eta)
            soc = np.clip(soc + d_soc, 0.0, 1.0)
            feasible &= soc >= battery.envelope.soc_min - 1e-9
            feasible &= soc <= battery.envelope.soc_max + 1e-9

            sink = float(ambient[k])
            t_inf = sink + resp.heat_w / np.maximum(k_cool, EPS)
            decay = np.exp(-k_cool * dt_s / max(surface.heat_capacity_j_k, EPS))
            temp = t_inf + (temp - t_inf) * decay
            peak_temp = np.maximum(peak_temp, temp)
            feasible &= temp <= battery.thermal_limits.t_max_c - self.temperature_margin_c
            charging = p_grid < 0.0
            feasible &= ~(charging & (temp < battery.thermal_limits.t_min_charge_c - 1e-9))

            fade = (
                degradation_rate_array(
                    battery, soc=soc, temperature_c=temp, current_a=resp.current_a
                )
                * dt_s
            )
            total_fade += fade

            out_wh = np.clip(p_grid, 0.0, None) * dt_h
            in_wh = np.clip(-p_grid, 0.0, None) * dt_h
            total_out_wh += out_wh
            total_in_wh += in_wh
            total_loss_wh += resp.loss_w * dt_h
            total_aux_wh += parasitic * dt_h

            revenue = out_wh / 1000.0 * export_price[k]
            cost = in_wh / 1000.0 * import_price[k]
            aux_cost = parasitic * dt_h / 1000.0 * import_price[k]
            loss_cost = resp.loss_w * dt_h / 1000.0 * import_price[k] * cfg.loss_multiplier
            fade_cost = fade * fade_cost_unit

            shortfall = 0.0
            if firm:
                required = max(0.0, float(demand[k] - solar[k]))
                shortfall = (
                    np.clip(required - np.clip(p_grid, 0.0, None), 0.0, None)
                    * dt_h
                    * econ.config.mission_shortfall_cost_per_wh
                    * cfg.weight("mission")
                )
            value += (
                cfg.weight("energy") * revenue
                - cfg.weight("economic") * (cost + aux_cost)
                - cfg.weight("efficiency") * loss_cost
                - fade_cost
                - shortfall
            )

        terminal = (
            problem.terminal_energy_value_per_kwh
            if problem.terminal_energy_value_per_kwh is not None
            else float(np.mean(import_price))
        )
        start_energy = battery.energy_between(0.0, problem.state.soc)
        end_energy = np.array(
            [[battery.energy_between(0.0, float(s)) for s in row] for row in soc]
        )
        value += cfg.weight("energy") * (end_energy - start_energy) / 1000.0 * terminal

        scored = np.where(feasible, value, -np.inf)
        if not np.any(np.isfinite(scored)):
            raise InfeasibleProblem(
                "surrogate sweep found no feasible candidate",
                limiting=bounds.discharge_limiting,
            )
        ci, pi = np.unravel_index(int(np.argmax(scored)), scored.shape)
        best_power = float(powers[pi])
        best_cooling = float(cooling[ci])

        # Alternatives are chosen for *diversity*, not for being the runners-up.
        # The eight highest-scoring points on a fine grid are always eight
        # neighbours of the optimum, which tells an operator nothing: the useful
        # question is "why not much more power, or much less, or no cooling at
        # all?". So the list is the best candidate at each cooling level plus
        # the best in each of several power bands.
        alternatives: list[dict[str, Any]] = []
        seen: set[tuple[int, int]] = set()

        def add(a: int, b_: int) -> None:
            if (a, b_) == (ci, pi) or (a, b_) in seen or not np.isfinite(scored[a, b_]):
                return
            seen.add((a, b_))
            alternatives.append(
                {
                    "power_w": float(powers[b_]),
                    "cooling": float(cooling[a]),
                    "score": float(scored[a, b_]),
                    "capacity_fade": float(total_fade[a, b_]),
                    "peak_temperature_c": float(peak_temp[a, b_]),
                    "final_soc": float(soc[a, b_]),
                }
            )

        for a in range(n_cool):
            row = scored[a]
            if np.any(np.isfinite(row)):
                add(a, int(np.argmax(row)))
        for band in np.array_split(np.arange(self.n_power), min(6, self.n_power)):
            if band.size == 0:
                continue
            sub = scored[:, band]
            if not np.any(np.isfinite(sub)):
                continue
            a, local = np.unravel_index(int(np.argmax(sub)), sub.shape)
            add(int(a), int(band[local]))
        alternatives.sort(key=lambda item: item["score"], reverse=True)
        alternatives = alternatives[:10]

        return MethodResult(
            power_w=(best_power,) * n,
            cooling=(best_cooling,) * n,
            score=float(scored[ci, pi]),
            method=self.name,
            alternatives=alternatives,
            diagnostics={
                "candidates": int(self.n_power * n_cool),
                "feasible": int(np.count_nonzero(feasible)),
                "capacity_fade": float(total_fade[ci, pi]),
                "peak_temperature_c": float(peak_temp[ci, pi]),
                "losses_wh": float(total_loss_wh[ci, pi]),
                "final_soc": float(soc[ci, pi]),
                "solve_seconds": time.perf_counter() - started,
            },
            reason=(
                f"Vectorised surrogate sweep over {self.n_power * n_cool} candidates "
                f"({self.n_power} power points x {n_cool} cooling levels)."
            ),
        )


__all__ = ["SurrogateSweepMethod"]
