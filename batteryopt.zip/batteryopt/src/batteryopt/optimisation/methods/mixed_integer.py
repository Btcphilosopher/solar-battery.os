"""Mixed-integer scheduling via OR-Tools, with a HiGHS relaxation fallback.

Some scheduling decisions really are discrete: a grid-service contract commits
to a block of hours, a charger offers a fixed set of power levels, an operator
requires a minimum run time so the contactors are not cycled every interval.
A linear relaxation of those decisions returns fractional commitments that are
not implementable.

This method formulates the horizon as a MILP with binary charge/discharge mode
variables, optional minimum run times, and an optional cap on the number of
mode changes. OR-Tools' CP-SAT solves it when installed; without OR-Tools the
method degrades to the linear relaxation and *says so* in its diagnostics,
rather than silently returning something the caller cannot execute.
"""

from __future__ import annotations

import time

import numpy as np

from ...core.exceptions import InfeasibleProblem, OptimisationError
from ...core.numerics import EPS
from ...core.optional import have, try_import
from ...core.units import SECONDS_PER_HOUR
from ..problem import OptimisationProblem
from .base import MethodResult
from .linear_program import LinearProgramMethod


class MixedIntegerMethod:
    """Discrete-commitment scheduling."""

    name = "mixed_integer"

    def __init__(
        self,
        *,
        power_levels: int = 9,
        min_run_intervals: int = 1,
        max_mode_changes: int | None = None,
        cooling: float = 0.3,
        scale: int = 1000,
    ) -> None:
        #: Number of discrete power levels the charger/inverter can select.
        self.power_levels = power_levels
        #: Minimum number of consecutive intervals in one mode.
        self.min_run_intervals = max(1, min_run_intervals)
        self.max_mode_changes = max_mode_changes
        self.cooling = cooling
        #: CP-SAT is integer-only; all quantities are scaled by this factor.
        self.scale = scale

    def suitable_for(self, problem: OptimisationProblem) -> bool:
        return 2 <= problem.n_steps <= 200

    def solve(self, problem: OptimisationProblem) -> MethodResult:
        started = time.perf_counter()
        if not have("ortools"):
            fallback = LinearProgramMethod(cooling=self.cooling).solve(problem)
            fallback.method = f"{self.name}(relaxed)"
            fallback.diagnostics["integrality"] = "relaxed"
            fallback.diagnostics["note"] = (
                "OR-Tools is not installed, so the integer commitment variables were "
                "relaxed. The schedule may contain fractional commitments; install "
                "batteryopt[solvers] for an implementable one."
            )
            fallback.reason += " Integrality relaxed (OR-Tools unavailable)."
            fallback.converged = False
            return fallback

        cp_model = try_import("ortools.sat.python.cp_model")
        if cp_model is None:  # pragma: no cover - partial install
            raise OptimisationError("OR-Tools present but cp_model could not be imported")

        battery = problem.constraints.battery
        n = problem.n_steps
        dt_h = problem.dt_s / SECONDS_PER_HOUR
        bounds = problem.constraints.bounds(problem.state, problem.dt_s)
        p_charge_max = max(0.0, -bounds.min_power_w)
        p_discharge_max = max(0.0, bounds.max_power_w)
        if p_charge_max <= EPS and p_discharge_max <= EPS:
            raise InfeasibleProblem("no admissible power in either direction")

        env = battery.envelope
        e_min = int(battery.energy_between(0.0, env.soc_min))
        e_max = int(battery.energy_between(0.0, env.soc_max))
        e_now = int(battery.energy_between(0.0, problem.state.soc))

        tariff = problem.tariff or problem.objective.tariff
        abs_times = problem.state.timestamp + np.arange(n) * problem.dt_s
        if tariff is not None:
            import_price = np.asarray(tariff.import_at(abs_times), dtype=float).reshape(n)
            export_price = (
                np.asarray(tariff.export_at(abs_times), dtype=float).reshape(n)
                if tariff.export_price is not None
                else import_price
            )
        else:
            flat = problem.objective.economics.config.default_energy_value_per_kwh
            import_price = np.full(n, flat)
            export_price = np.full(n, flat)

        wear = LinearProgramMethod()._wear_cost(problem)  # noqa: SLF001 - shared pricing
        levels = np.linspace(0.0, 1.0, self.power_levels)

        model = cp_model.CpModel()
        charging = [model.NewBoolVar(f"chg_{k}") for k in range(n)]
        discharging = [model.NewBoolVar(f"dis_{k}") for k in range(n)]
        level_vars = [
            [model.NewBoolVar(f"lvl_{k}_{j}") for j in range(self.power_levels)]
            for k in range(n)
        ]
        energy = [model.NewIntVar(e_min, e_max, f"e_{k}") for k in range(n + 1)]
        model.Add(energy[0] == e_now)

        objective_terms = []
        for k in range(n):
            model.Add(charging[k] + discharging[k] <= 1)
            model.AddExactlyOne(level_vars[k])

            # Energy balance, in whole watt-hours.
            charge_wh = [
                int(round(p_charge_max * levels[j] * dt_h * env.coulombic_efficiency))
                for j in range(self.power_levels)
            ]
            discharge_wh = [
                int(round(p_discharge_max * levels[j] * dt_h / 0.97))
                for j in range(self.power_levels)
            ]
            delta = sum(
                level_vars[k][j] * charge_wh[j] for j in range(self.power_levels)
            ) - sum(level_vars[k][j] * discharge_wh[j] for j in range(self.power_levels))
            # Level applies to whichever mode is active; resting forces level 0.
            model.Add(level_vars[k][0] == 1).OnlyEnforceIf(
                [charging[k].Not(), discharging[k].Not()]
            )
            charge_delta = model.NewIntVar(-e_max, e_max, f"d_{k}")
            model.Add(charge_delta == delta).OnlyEnforceIf(charging[k])
            model.Add(charge_delta == -delta).OnlyEnforceIf(discharging[k])
            model.Add(charge_delta == 0).OnlyEnforceIf(
                [charging[k].Not(), discharging[k].Not()]
            )
            model.Add(energy[k + 1] == energy[k] + charge_delta)

            for j in range(self.power_levels):
                cost = int(
                    round(
                        self.scale
                        * (
                            (import_price[k] + wear)
                            * p_charge_max
                            * levels[j]
                            * dt_h
                            / 1000.0
                        )
                    )
                )
                revenue = int(
                    round(
                        self.scale
                        * (
                            (export_price[k] - wear)
                            * p_discharge_max
                            * levels[j]
                            * dt_h
                            / 1000.0
                        )
                    )
                )
                charge_active = model.NewBoolVar(f"ca_{k}_{j}")
                model.AddMultiplicationEquality(charge_active, [charging[k], level_vars[k][j]])
                discharge_active = model.NewBoolVar(f"da_{k}_{j}")
                model.AddMultiplicationEquality(
                    discharge_active, [discharging[k], level_vars[k][j]]
                )
                objective_terms.append(charge_active * cost)
                objective_terms.append(discharge_active * -revenue)

        # Minimum run time on each mode.
        if self.min_run_intervals > 1:
            for mode in (charging, discharging):
                for k in range(n - self.min_run_intervals):
                    for m in range(1, self.min_run_intervals):
                        # A start at k forces the mode to hold for the run length.
                        model.Add(mode[k + m] >= mode[k] - (mode[k - 1] if k else 0))

        if self.max_mode_changes is not None:
            changes = []
            for k in range(1, n):
                ch = model.NewBoolVar(f"change_{k}")
                model.Add(ch >= charging[k] - charging[k - 1])
                model.Add(ch >= discharging[k] - discharging[k - 1])
                changes.append(ch)
            model.Add(sum(changes) <= self.max_mode_changes)

        terminal_value = (
            problem.terminal_energy_value_per_kwh
            if problem.terminal_energy_value_per_kwh is not None
            else float(np.mean(import_price))
        )
        objective_terms.append(
            energy[n] * -int(round(self.scale * terminal_value / 1000.0))
        )
        model.Minimize(sum(objective_terms))

        solver = cp_model.CpSolver()
        solver.parameters.max_time_in_seconds = 10.0
        solver.parameters.num_search_workers = 4
        status = solver.Solve(model)
        if status not in (cp_model.OPTIMAL, cp_model.FEASIBLE):
            raise InfeasibleProblem(
                f"mixed-integer schedule infeasible (status {solver.StatusName(status)})"
            )

        plan: list[float] = []
        for k in range(n):
            level = next(
                (
                    float(levels[j])
                    for j in range(self.power_levels)
                    if solver.Value(level_vars[k][j])
                ),
                0.0,
            )
            if solver.Value(charging[k]):
                plan.append(-p_charge_max * level)
            elif solver.Value(discharging[k]):
                plan.append(p_discharge_max * level)
            else:
                plan.append(0.0)

        return MethodResult(
            power_w=tuple(plan),
            cooling=(self.cooling,) * n,
            score=-solver.ObjectiveValue() / self.scale,
            method=self.name,
            diagnostics={
                "status": solver.StatusName(status),
                "integrality": "enforced",
                "power_levels": self.power_levels,
                "min_run_intervals": self.min_run_intervals,
                "wall_time_s": solver.WallTime(),
                "solve_seconds": time.perf_counter() - started,
            },
            converged=status == cp_model.OPTIMAL,
            reason=(
                f"CP-SAT mixed-integer schedule over {n} intervals with "
                f"{self.power_levels} discrete power levels."
            ),
        )


__all__ = ["MixedIntegerMethod"]
