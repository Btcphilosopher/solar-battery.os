"""Multi-objective optimisation and Pareto fronts (specification section 5).

"Return the trade-offs rather than hiding them." A single weighted score is
what a controller needs, but it is not what a person deciding *how to weight
things* needs. This module produces the front itself, plus the named corner
strategies operators actually ask for:

.. code-block:: text

    STRATEGY A   maximum efficiency
    STRATEGY B   maximum battery life
    STRATEGY C   maximum immediate power
    STRATEGY D   minimum cost
    STRATEGY E   balanced optimum

Objectives are all expressed as *minimised costs* in
:attr:`~batteryopt.optimisation.objective.ObjectiveValue.pareto_costs`, and are
deliberately **unweighted**: the front is a property of the physics and the
constraints, not of anybody's preferences. Weights come in afterwards, when a
point on the front is selected.

The balanced point is chosen by the knee of the front -- the point closest to
the utopia corner in normalised objective space -- rather than by an arbitrary
equal weighting, because equal weights on incommensurable units are meaningless.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Sequence

import numpy as np

from ...core.exceptions import InfeasibleProblem
from ...core.numerics import EPS, crowding_distance, pareto_mask
from ...scenario.engine import Scenario, ScenarioEngine, ScenarioResult
from ...scenario.strategies import cooling_sweep, power_sweep
from ..problem import OptimisationProblem
from .base import MethodResult


@dataclass(slots=True)
class ParetoPoint:
    """One non-dominated candidate with its objective vector."""

    result: ScenarioResult
    costs: tuple[float, ...]
    names: tuple[str, ...]
    #: Named role, when this point is a corner or the knee.
    role: str = ""
    crowding: float = 0.0

    def as_dict(self) -> dict[str, Any]:
        return {
            "label": self.result.scenario.label,
            "role": self.role,
            "power_w": self.result.scenario.first_power_w,
            "cooling": self.result.scenario.first_cooling,
            "objectives": dict(zip(self.names, self.costs)),
            "outcome": self.result.outcome.as_dict(),
            "score": self.result.score,
        }


@dataclass(slots=True)
class ParetoFront:
    """The non-dominated set, with named strategies picked out of it."""

    points: list[ParetoPoint] = field(default_factory=list)
    objective_names: tuple[str, ...] = ()
    dominated_count: int = 0
    #: Roles mapped to indices into :attr:`points`.
    roles: dict[str, int] = field(default_factory=dict)

    def __len__(self) -> int:
        return len(self.points)

    def by_role(self, role: str) -> ParetoPoint | None:
        idx = self.roles.get(role)
        return self.points[idx] if idx is not None else None

    @property
    def balanced(self) -> ParetoPoint | None:
        return self.by_role("balanced")

    def table(self) -> str:
        lines = [
            f"{'ROLE':<20} {'STRATEGY':<22} {'POWER':>10} "
            + " ".join(f"{n.upper():>13}" for n in self.objective_names),
            "-" * (54 + 14 * len(self.objective_names)),
        ]
        for point in self.points:
            lines.append(
                f"{point.role or '-':<20} {point.result.scenario.label:<22} "
                f"{point.result.scenario.first_power_w / 1000.0:8.2f}kW "
                + " ".join(f"{c:13.5g}" for c in point.costs)
            )
        return "\n".join(lines)

    def as_dict(self) -> dict[str, Any]:
        return {
            "objective_names": list(self.objective_names),
            "points": [p.as_dict() for p in self.points],
            "dominated_count": self.dominated_count,
            "roles": dict(self.roles),
        }


def build_front(results: Sequence[ScenarioResult], *, max_points: int = 24) -> ParetoFront:
    """Extract the non-dominated set from scored candidates and name its corners."""
    feasible = [r for r in results if r.feasible]
    if not feasible:
        return ParetoFront()

    names = feasible[0].value.pareto_names
    costs = np.array([r.value.pareto_costs for r in feasible], dtype=float)
    mask = pareto_mask(costs)
    idx = np.flatnonzero(mask)
    front_costs = costs[idx]

    # Thin a dense front by crowding distance, keeping the extremes.
    if idx.size > max_points:
        distances = crowding_distance(front_costs)
        keep = np.argsort(distances)[::-1][:max_points]
        idx = idx[np.sort(keep)]
        front_costs = costs[idx]

    points = [
        ParetoPoint(result=feasible[int(i)], costs=tuple(costs[int(i)]), names=names)
        for i in idx
    ]

    # --- name the corners -------------------------------------------------
    roles: dict[str, int] = {}

    def assign(role: str, position: int) -> None:
        if 0 <= position < len(points) and role not in roles:
            roles[role] = position
            if not points[position].role:
                points[position].role = role

    outcomes = [p.result.outcome for p in points]
    if outcomes:
        assign("maximum efficiency", int(np.argmax([o.mean_efficiency for o in outcomes])))
        assign("maximum battery life", int(np.argmin([o.capacity_fade for o in outcomes])))
        assign(
            "maximum immediate power",
            int(np.argmax([abs(p.result.scenario.first_power_w) for p in points])),
        )
        cost_index = list(names).index("cost") if "cost" in names else 0
        assign("minimum cost", int(np.argmin(front_costs[:, cost_index])))

        # Knee: closest to the utopia point in range-normalised space.
        lo = front_costs.min(axis=0)
        hi = front_costs.max(axis=0)
        span = np.where(hi - lo > EPS, hi - lo, 1.0)
        normalised = (front_costs - lo) / span
        assign("balanced", int(np.argmin(np.linalg.norm(normalised, axis=1))))

    return ParetoFront(
        points=points,
        objective_names=names,
        dominated_count=int(costs.shape[0] - len(points)),
        roles=roles,
    )


class ParetoMethod:
    """Builds a Pareto front and returns the balanced point as the plan."""

    name = "pareto"

    def __init__(
        self,
        *,
        engine: ScenarioEngine | None = None,
        power_points: int = 25,
        cooling_points: tuple[float, ...] = (0.0, 0.25, 0.5, 0.75, 1.0),
        select: str = "balanced",
        max_points: int = 24,
    ) -> None:
        self._engine = engine
        self.power_points = power_points
        self.cooling_points = cooling_points
        #: Which role to return as the recommended plan.
        self.select = select
        self.max_points = max_points
        self.last_front: ParetoFront | None = None

    def suitable_for(self, problem: OptimisationProblem) -> bool:
        return True

    def candidates(self, problem: OptimisationProblem) -> list[Scenario]:
        out: list[Scenario] = []
        for cooling in self.cooling_points:
            out.extend(power_sweep(problem, n=self.power_points, cooling=cooling))
        demand = problem.demand_profile()
        if demand.size and float(demand.max()) > 0.0:
            out.extend(cooling_sweep(problem, float(demand.max())))
        return out

    def front(self, problem: OptimisationProblem) -> ParetoFront:
        engine = self._engine or ScenarioEngine(problem.constraints.battery)
        results = engine.compare(problem, self.candidates(problem))
        front = build_front(results, max_points=self.max_points)
        self.last_front = front
        return front

    def solve(self, problem: OptimisationProblem) -> MethodResult:
        started = time.perf_counter()
        front = self.front(problem)
        if not front.points:
            raise InfeasibleProblem("no feasible candidate to build a Pareto front from")
        chosen = front.by_role(self.select) or front.points[0]
        n = problem.n_steps
        scenario = chosen.result.scenario
        return MethodResult(
            power_w=scenario.power_w if len(scenario) == n else (scenario.first_power_w,) * n,
            cooling=scenario.cooling if scenario.cooling else (0.0,) * n,
            score=chosen.result.score,
            method=self.name,
            alternatives=[p.as_dict() for p in front.points if p is not chosen],
            diagnostics={
                "front_size": len(front),
                "dominated": front.dominated_count,
                "roles": dict(front.roles),
                "objective_names": list(front.objective_names),
                "solve_seconds": time.perf_counter() - started,
            },
            reason=(
                f"Pareto front of {len(front)} non-dominated strategies "
                f"({front.dominated_count} dominated); returning the "
                f"{self.select!r} point."
            ),
        )


__all__ = ["ParetoMethod", "ParetoFront", "ParetoPoint", "build_front"]
