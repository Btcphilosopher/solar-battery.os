"""Common interface for optimisation backends.

Specification section 29 is explicit: do not force every optimisation problem
through one algorithm. Different questions have different structure, and the
right method depends on which:

===========================  =====================================================
Question                     Method
===========================  =====================================================
What power right now?        1-D continuous search (golden section / SciPy)
Which of these strategies?   Enumeration over the candidate set
How to schedule 24 hours?    Linear programme over energy, or dynamic programming
                             when the cost is genuinely non-convex
On/off or discrete blocks?   Mixed-integer programme (OR-Tools, HiGHS fallback)
What are the trade-offs?     Multi-objective / Pareto
What to do as things move?   Model predictive control wrapping any of the above
===========================  =====================================================

Every backend implements :class:`OptimisationMethod`, returns a
:class:`MethodResult`, and is free to decline a problem it is not suited to by
raising :class:`~batteryopt.core.exceptions.OptimisationError`. The engine then
falls back, so a missing solver degrades the answer rather than breaking it.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol, Sequence, runtime_checkable

from ..problem import OptimisationProblem


@dataclass(slots=True)
class MethodResult:
    """What a backend returns: a plan plus enough context to explain it."""

    #: Terminal power per step over the horizon, W.
    power_w: tuple[float, ...]
    #: Cooling command per step, 0-1.
    cooling: tuple[float, ...]
    #: Objective value of the chosen plan (higher is better).
    score: float
    method: str
    #: Candidates evaluated and rejected, best-first, for the audit trail.
    alternatives: list[dict[str, Any]] = field(default_factory=list)
    #: Backend-specific diagnostics (iterations, solver status, gap, ...).
    diagnostics: dict[str, Any] = field(default_factory=dict)
    #: Whether the backend believes it reached an optimum.
    converged: bool = True
    reason: str = ""

    @property
    def first_power_w(self) -> float:
        return self.power_w[0] if self.power_w else 0.0

    @property
    def first_cooling(self) -> float:
        return self.cooling[0] if self.cooling else 0.0


@runtime_checkable
class OptimisationMethod(Protocol):
    """A pluggable optimisation backend."""

    name: str

    def solve(self, problem: OptimisationProblem) -> MethodResult:
        """Solve the problem, or raise ``OptimisationError`` if unsuitable."""
        ...

    def suitable_for(self, problem: OptimisationProblem) -> bool:
        """Cheap check used by automatic method selection."""
        ...


def uniform_plan(value: float, n: int) -> tuple[float, ...]:
    return (float(value),) * n


def pad_plan(values: Sequence[float], n: int) -> tuple[float, ...]:
    """Extend or truncate a plan to exactly ``n`` steps."""
    out = list(values[:n])
    while len(out) < n:
        out.append(out[-1] if out else 0.0)
    return tuple(float(v) for v in out)


__all__ = ["OptimisationMethod", "MethodResult", "uniform_plan", "pad_plan"]
