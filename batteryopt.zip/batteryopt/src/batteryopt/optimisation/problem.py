"""Problem definition and result shapes for the optimisation API.

Specification section 27 fixes the public contract::

    result = batteryopt.optimise(battery_state=state, demand=demand,
                                 objective="lifetime_efficiency")

returning ``recommended_power``, ``recommended_charge_rate``,
``recommended_discharge_rate``, ``cooling_requirement``, ``target_soc``,
``estimated_efficiency``, ``estimated_degradation``, ``estimated_cost``,
``confidence`` and ``limiting_constraint``. :class:`Recommendation` is that
contract; everything else here is what goes in.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Sequence

import numpy as np

from ..core.numerics import EPS
from ..core.provenance import Provenance, Quantiles, Quantity
from ..core.units import SECONDS_PER_HOUR, mode_of
from ..core.versioning import RunFingerprint
from ..economics.prices import Tariff
from ..models.state import BatteryState
from .constraints import ConstraintSet, Violation
from .objective import Objective, ObjectiveValue, Outcome


@dataclass(frozen=True, slots=True)
class Demand:
    """Load the battery is being asked to serve over the horizon.

    ``firm`` decides how a shortfall is treated. A firm demand that cannot be
    met is penalised at the value of lost load; a flexible one simply is not
    served, and the optimiser is free to choose a lower power if that is worth
    more. Getting this distinction right is the difference between an engine
    that always runs flat out and one that derates sensibly.
    """

    #: Constant power, W (positive = the load draws from the battery), or a
    #: profile sampled at ``times_s``.
    power_w: float | np.ndarray = 0.0
    times_s: np.ndarray | None = None
    firm: bool = True
    #: Uncertainty in the demand, when a forecaster supplied it.
    quantiles: Quantiles | None = None
    label: str = ""

    def at(self, t_s: float | np.ndarray) -> np.ndarray:
        if self.times_s is None or np.isscalar(self.power_w):
            return np.full(np.shape(t_s), float(np.asarray(self.power_w).flat[0]))
        idx = np.clip(
            np.searchsorted(self.times_s, t_s, side="right") - 1,
            0,
            np.asarray(self.power_w).size - 1,
        )
        return np.asarray(self.power_w, dtype=float)[idx]

    def energy_wh(self, horizon_s: float) -> float:
        if self.times_s is None or np.isscalar(self.power_w):
            return float(np.asarray(self.power_w).flat[0]) * horizon_s / SECONDS_PER_HOUR
        grid = np.linspace(0.0, horizon_s, 512)
        return float(np.trapezoid(self.at(grid), grid) / SECONDS_PER_HOUR)

    @property
    def peak_w(self) -> float:
        return float(np.max(np.atleast_1d(self.power_w)))

    def as_dict(self) -> dict[str, Any]:
        return {
            "label": self.label,
            "firm": self.firm,
            "peak_w": self.peak_w,
            "profile": self.times_s is not None,
            "quantiles": self.quantiles.as_dict() if self.quantiles else None,
        }


@dataclass(frozen=True, slots=True)
class Mission:
    """A future commitment the battery must be ready for (section 7)."""

    #: Energy the mission is expected to consume, Wh.
    energy_wh: float
    #: Seconds from now until the mission starts.
    departure_s: float
    #: Uncertainty in the energy requirement, from the forecaster.
    quantiles: Quantiles | None = None
    #: Reliability the operator requires, e.g. 0.9 means plan to the P90.
    required_reliability: float = 0.9
    #: SOC that must remain when the mission ends.
    reserve_soc: float = 0.05
    ambient_c: float | None = None
    label: str = ""

    def planning_energy_wh(self) -> float:
        """Energy to plan for, at the configured reliability.

        With quantiles available this interpolates between P50 and P90 rather
        than always taking the median, which is what makes "arrive with enough"
        a reliability statement instead of a coin flip.
        """
        if self.quantiles is None:
            return self.energy_wh
        q = self.quantiles
        r = min(max(self.required_reliability, 0.0), 1.0)
        if r <= 0.5:
            frac = (0.5 - r) / 0.4 if r >= 0.1 else 1.0
            return q.p50 - frac * (q.p50 - q.p10)
        frac = (r - 0.5) / 0.4
        return q.p50 + min(frac, 1.0) * (q.p90 - q.p50)

    def as_dict(self) -> dict[str, Any]:
        return {
            "label": self.label,
            "energy_wh": self.energy_wh,
            "planning_energy_wh": self.planning_energy_wh(),
            "departure_s": self.departure_s,
            "required_reliability": self.required_reliability,
            "reserve_soc": self.reserve_soc,
            "quantiles": self.quantiles.as_dict() if self.quantiles else None,
        }


@dataclass(slots=True)
class OptimisationProblem:
    """Everything needed to answer "what should the battery do now?"."""

    state: BatteryState
    constraints: ConstraintSet
    objective: Objective
    #: Planning horizon, seconds.
    horizon_s: float = 900.0
    #: Control interval, seconds. The first step is what gets recommended.
    dt_s: float = 60.0
    demand: Demand | None = None
    mission: Mission | None = None
    tariff: Tariff | None = None
    #: Forecast ambient temperature over the horizon, degC.
    ambient_c: float | np.ndarray | None = None
    #: Forecast PV generation over the horizon, W.
    solar_w: float | np.ndarray | None = None
    #: Marginal value of energy left in the battery at the end of the horizon,
    #: currency per kWh. Set by the arbitrage layer from the value function;
    #: ``None`` falls back to the prevailing tariff price.
    terminal_energy_value_per_kwh: float | None = None
    #: Seed for any stochastic component, recorded in the fingerprint.
    seed: int | None = None
    label: str = ""
    meta: dict[str, Any] = field(default_factory=dict)

    @property
    def n_steps(self) -> int:
        return max(1, int(round(self.horizon_s / self.dt_s)))

    @property
    def times_s(self) -> np.ndarray:
        return self.state.timestamp + np.arange(self.n_steps + 1) * self.dt_s

    def ambient_profile(self) -> np.ndarray:
        n = self.n_steps
        if self.ambient_c is None:
            return np.full(n, self.state.ambient_c)
        arr = np.atleast_1d(np.asarray(self.ambient_c, dtype=float))
        if arr.size == 1:
            return np.full(n, float(arr[0]))
        if arr.size == n:
            return arr
        return np.interp(np.linspace(0.0, 1.0, n), np.linspace(0.0, 1.0, arr.size), arr)

    def demand_profile(self) -> np.ndarray:
        n = self.n_steps
        if self.demand is None:
            return np.zeros(n)
        rel = np.arange(n) * self.dt_s
        return np.asarray(self.demand.at(rel), dtype=float).reshape(n)

    def solar_profile(self) -> np.ndarray:
        n = self.n_steps
        if self.solar_w is None:
            return np.zeros(n)
        arr = np.atleast_1d(np.asarray(self.solar_w, dtype=float))
        if arr.size == 1:
            return np.full(n, float(arr[0]))
        if arr.size == n:
            return arr
        return np.interp(np.linspace(0.0, 1.0, n), np.linspace(0.0, 1.0, arr.size), arr)

    def fingerprint(self) -> RunFingerprint:
        return RunFingerprint.build(
            inputs={
                "state": self.state.as_dict(include_provenance=False),
                "horizon_s": self.horizon_s,
                "dt_s": self.dt_s,
                "demand": self.demand.as_dict() if self.demand else None,
                "mission": self.mission.as_dict() if self.mission else None,
                "ambient": self.ambient_profile().tolist(),
                "solar": self.solar_profile().tolist(),
                "terminal_value": self.terminal_energy_value_per_kwh,
            },
            constraints=self.constraints.fingerprint_payload(),
            objective=self.objective.fingerprint_payload(),
            seed=self.seed,
        )


@dataclass(frozen=True, slots=True)
class Recommendation:
    """The engine's answer, in the shape section 27 specifies."""

    #: Signed terminal power to apply now, W. Positive = discharge.
    recommended_power_w: float
    #: Magnitude of the recommended charge, W, and as a C-rate.
    recommended_charge_rate_w: float
    recommended_charge_c_rate: float
    #: Magnitude of the recommended discharge, W, and as a C-rate.
    recommended_discharge_rate_w: float
    recommended_discharge_c_rate: float
    #: Fraction of maximum active cooling to command, 0-1.
    cooling_requirement: float
    #: SOC the plan is aiming at by the end of the horizon.
    target_soc: float
    estimated_efficiency: float
    #: Capacity fade expected over the horizon, as a fraction.
    estimated_degradation: float
    #: Net cost of the horizon under this plan, in the configured currency.
    estimated_cost: float
    #: 0-1 confidence, combining model confidence and constraint proximity.
    confidence: float
    #: Name of the constraint that determined the recommendation.
    limiting_constraint: str | None

    # --- context and audit ------------------------------------------------
    mode: str = "rest"
    horizon_s: float = 0.0
    objective_value: ObjectiveValue | None = None
    outcome: Outcome | None = None
    #: Full planned action sequence, not just the first step.
    plan_power_w: tuple[float, ...] = ()
    plan_cooling: tuple[float, ...] = ()
    #: Alternatives that were evaluated and rejected, best-first.
    alternatives: tuple[dict[str, Any], ...] = ()
    #: Soft-constraint violations accepted by the plan.
    soft_violations: tuple[Violation, ...] = ()
    reason: str = ""
    method: str = ""
    fingerprint: RunFingerprint | None = None
    solve_seconds: float = 0.0
    currency: str = "GBP"
    meta: dict[str, Any] = field(default_factory=dict)

    def as_quantities(self) -> dict[str, Quantity]:
        """Provenance-tagged view: a recommendation is OPTIMISED, not measured."""
        return {
            "recommended_power": Quantity(
                self.recommended_power_w, "W", Provenance.OPTIMISED, source="optimiser"
            ),
            "target_soc": Quantity(
                self.target_soc, "-", Provenance.OPTIMISED, source="optimiser"
            ),
            "estimated_efficiency": Quantity(
                self.estimated_efficiency, "-", Provenance.SIMULATED, source="plant"
            ),
            "estimated_degradation": Quantity(
                self.estimated_degradation, "-", Provenance.SIMULATED, source="degradation model"
            ),
            "estimated_cost": Quantity(
                self.estimated_cost, self.currency, Provenance.SIMULATED, source="economics"
            ),
        }

    def as_dict(self) -> dict[str, Any]:
        return {
            "recommended_power_w": self.recommended_power_w,
            "recommended_charge_rate_w": self.recommended_charge_rate_w,
            "recommended_charge_c_rate": self.recommended_charge_c_rate,
            "recommended_discharge_rate_w": self.recommended_discharge_rate_w,
            "recommended_discharge_c_rate": self.recommended_discharge_c_rate,
            "cooling_requirement": self.cooling_requirement,
            "target_soc": self.target_soc,
            "estimated_efficiency": self.estimated_efficiency,
            "estimated_degradation": self.estimated_degradation,
            "estimated_cost": self.estimated_cost,
            "confidence": self.confidence,
            "limiting_constraint": self.limiting_constraint,
            "mode": self.mode,
            "horizon_s": self.horizon_s,
            "reason": self.reason,
            "method": self.method,
            "currency": self.currency,
            "plan_power_w": list(self.plan_power_w),
            "plan_cooling": list(self.plan_cooling),
            "objective": self.objective_value.as_dict() if self.objective_value else None,
            "outcome": self.outcome.as_dict() if self.outcome else None,
            "alternatives": list(self.alternatives),
            "soft_violations": [v.as_dict() for v in self.soft_violations],
            "fingerprint": self.fingerprint.as_dict() if self.fingerprint else None,
            "solve_seconds": self.solve_seconds,
        }

    def summary(self) -> str:
        return (
            f"{self.mode.upper()} {abs(self.recommended_power_w) / 1000.0:.1f} kW  "
            f"cooling {self.cooling_requirement * 100:.0f}%  "
            f"target SOC {self.target_soc * 100:.1f}%  "
            f"eff {self.estimated_efficiency * 100:.1f}%  "
            f"fade {self.estimated_degradation * 100:.4f}%  "
            f"limited by {self.limiting_constraint or 'nothing'}"
        )


def build_recommendation(
    *,
    problem: OptimisationProblem,
    power_w: float,
    cooling: float,
    outcome: Outcome,
    value: ObjectiveValue,
    limiting: str | None,
    plan_power: Sequence[float] = (),
    plan_cooling: Sequence[float] = (),
    alternatives: Sequence[dict[str, Any]] = (),
    soft_violations: Sequence[Violation] = (),
    reason: str = "",
    method: str = "",
    confidence: float = 0.8,
    solve_seconds: float = 0.0,
) -> Recommendation:
    """Assemble a :class:`Recommendation` from a solved plan."""
    battery = problem.constraints.battery
    capacity_ah = max(battery.capacity, EPS)
    v = max(problem.state.voltage_v, EPS)
    current = power_w / v
    charge_w = max(0.0, -power_w)
    discharge_w = max(0.0, power_w)
    return Recommendation(
        recommended_power_w=power_w,
        recommended_charge_rate_w=charge_w,
        recommended_charge_c_rate=max(0.0, -current) / capacity_ah,
        recommended_discharge_rate_w=discharge_w,
        recommended_discharge_c_rate=max(0.0, current) / capacity_ah,
        cooling_requirement=cooling,
        target_soc=outcome.end_soc,
        estimated_efficiency=outcome.mean_efficiency,
        estimated_degradation=outcome.capacity_fade,
        estimated_cost=value.breakdown.total_cost,
        confidence=confidence,
        limiting_constraint=limiting,
        mode=mode_of(power_w),
        horizon_s=problem.horizon_s,
        objective_value=value,
        outcome=outcome,
        plan_power_w=tuple(float(p) for p in plan_power),
        plan_cooling=tuple(float(c) for c in plan_cooling),
        alternatives=tuple(alternatives),
        soft_violations=tuple(soft_violations),
        reason=reason,
        method=method,
        fingerprint=problem.fingerprint(),
        solve_seconds=solve_seconds,
        currency=value.currency,
    )


__all__ = [
    "Demand",
    "Mission",
    "OptimisationProblem",
    "Recommendation",
    "build_recommendation",
]
