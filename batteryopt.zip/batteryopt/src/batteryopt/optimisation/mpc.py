"""Model predictive control (specification section 30).

.. code-block:: text

    CURRENT STATE -> FORECAST -> OPTIMISE TRAJECTORY -> EXECUTE FIRST STEP
          ^                                                     |
          +------------------- MEASURE AGAIN <------------------+

MPC is what turns a one-shot recommendation into a control policy. Each cycle
it re-solves the whole horizon from the *measured* state and executes only the
first step, so forecast error, model error and disturbances are all corrected
by the next cycle rather than accumulating.

Three implementation choices matter:

* **Receding horizon with a terminal value.** A finite horizon with no terminal
  value systematically empties the battery near the end of every horizon. The
  controller therefore carries a marginal value of stored energy -- taken from
  the dynamic programme's value function when available, and from the mean
  forecast price otherwise -- so the last interval is not treated as the end of
  the world.
* **Non-uniform time steps.** Near-term intervals are short, because that is
  what actually gets executed and where accuracy pays; far intervals are long,
  because their only job is to keep the terminal value honest. This buys a
  24-hour horizon for the cost of a 2-hour one.
* **Warm starting.** Each solve is seeded with the previous plan shifted by one
  interval. On a quiet system this cuts solve time substantially, and it makes
  the executed trajectory smoother because the optimiser is not free to jump
  between equally-good solutions every cycle.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Sequence

import numpy as np

from ..core.clock import Clock, SimulatedClock
from ..core.exceptions import InfeasibleProblem, SafetyViolation
from ..core.numerics import EPS
from ..models.plant import Action
from ..models.state import BatteryState
from .engine import OptimisationEngine
from .problem import Demand, Mission, OptimisationProblem, Recommendation

log = logging.getLogger(__name__)


def geometric_steps(
    *, horizon_s: float, first_dt_s: float, growth: float = 1.35, max_steps: int = 64
) -> list[float]:
    """Non-uniform step sizes: fine near the present, coarse far out.

    Returns a list of interval lengths summing to ``horizon_s``. A 24-hour
    horizon starting at one minute reaches the end in about twenty steps
    instead of 1440.
    """
    steps: list[float] = []
    total = 0.0
    dt = first_dt_s
    while total < horizon_s and len(steps) < max_steps:
        step = min(dt, horizon_s - total)
        steps.append(step)
        total += step
        dt *= growth
    if total < horizon_s and steps:
        steps[-1] += horizon_s - total
    return steps


@dataclass(slots=True)
class MPCStep:
    """One executed control cycle."""

    cycle: int
    timestamp: float
    state: BatteryState
    recommendation: Recommendation
    applied_power_w: float
    applied_cooling: float
    solve_seconds: float
    fell_back: bool = False
    note: str = ""

    def as_dict(self) -> dict[str, Any]:
        return {
            "cycle": self.cycle,
            "timestamp": self.timestamp,
            "soc": self.state.soc,
            "temperature_c": self.state.temperature_c,
            "applied_power_w": self.applied_power_w,
            "applied_cooling": self.applied_cooling,
            "limiting_constraint": self.recommendation.limiting_constraint,
            "estimated_cost": self.recommendation.estimated_cost,
            "confidence": self.recommendation.confidence,
            "solve_seconds": self.solve_seconds,
            "fell_back": self.fell_back,
            "note": self.note,
        }


@dataclass(slots=True)
class MPCHistory:
    """The record of a controller run."""

    steps: list[MPCStep] = field(default_factory=list)

    def append(self, step: MPCStep) -> None:
        self.steps.append(step)

    def __len__(self) -> int:
        return len(self.steps)

    @property
    def applied_power_w(self) -> np.ndarray:
        return np.array([s.applied_power_w for s in self.steps])

    @property
    def soc(self) -> np.ndarray:
        return np.array([s.state.soc for s in self.steps])

    def summary(self) -> dict[str, float | int]:
        if not self.steps:
            return {"cycles": 0}
        solves = np.array([s.solve_seconds for s in self.steps])
        return {
            "cycles": len(self.steps),
            "fallbacks": int(sum(1 for s in self.steps if s.fell_back)),
            "mean_solve_ms": float(solves.mean() * 1000.0),
            "p95_solve_ms": float(np.percentile(solves, 95) * 1000.0),
            "max_solve_ms": float(solves.max() * 1000.0),
            "final_soc": float(self.steps[-1].state.soc),
            "min_soc": float(min(s.state.soc for s in self.steps)),
            "max_temperature_c": float(max(s.state.temperature_c for s in self.steps)),
            "total_cost": float(sum(s.recommendation.estimated_cost for s in self.steps)),
        }


class ModelPredictiveController:
    """Receding-horizon controller wrapping any optimisation method."""

    def __init__(
        self,
        engine: OptimisationEngine,
        *,
        horizon_s: float = 3600.0,
        control_dt_s: float = 60.0,
        plan_dt_s: float | None = None,
        adaptive_steps: bool = True,
        planning_steps: int = 32,
        warm_start: bool = True,
        terminal_energy_value_per_kwh: float | None = None,
        clock: Clock | None = None,
        safe_action: float = 0.0,
    ) -> None:
        self.engine = engine
        self.horizon_s = horizon_s
        #: Length of the interval actually executed each cycle.
        self.control_dt_s = control_dt_s
        self.plan_dt_s = plan_dt_s or control_dt_s
        self.adaptive_steps = adaptive_steps
        #: Number of intervals the planning horizon is divided into when
        #: ``adaptive_steps`` is on. Kept well above the threshold at which
        #: scheduling methods engage: collapsing a priced horizon into a
        #: handful of intervals silently turns an arbitrage problem into a
        #: constant-power one, which is the single easiest way to make an MPC
        #: look like it is working while doing nothing useful.
        self.planning_steps = max(4, planning_steps)
        self.warm_start = warm_start
        self.terminal_energy_value_per_kwh = terminal_energy_value_per_kwh
        self.clock = clock or SimulatedClock()
        #: Power applied when no feasible plan can be found. Resting is the
        #: only universally safe action for a battery, so that is the default.
        self.safe_action = safe_action
        # MPC is the one caller entitled to a short commitment window: it
        # executes a single interval and then re-plans from a measured state, so
        # a limit grazed in hour nine of the plan is never actually reached.
        # Every other caller gets the full horizon enforced.
        self.engine.commitment_window_s = self.control_dt_s
        self.history = MPCHistory()
        self._previous_plan: tuple[float, ...] = ()
        self._cycle = 0

    # -- planning -----------------------------------------------------------

    def _effective_dt(self) -> float:
        """Planning interval: fine enough to schedule, coarse enough to be quick.

        The engine's problem model uses a uniform step, so the horizon is
        divided into :attr:`planning_steps` intervals, floored at the control
        interval. Resolution below the control interval buys nothing, because
        only the first interval is ever executed.
        """
        if not self.adaptive_steps:
            return self.plan_dt_s
        return max(self.control_dt_s, self.horizon_s / self.planning_steps)

    def build_problem(
        self,
        state: BatteryState,
        *,
        demand: Demand | float | None = None,
        mission: Mission | None = None,
        ambient_c: float | np.ndarray | None = None,
        solar_w: float | np.ndarray | None = None,
        objective: Any = None,
    ) -> OptimisationProblem:
        return self.engine.build_problem(
            state,
            demand=demand,
            mission=mission,
            horizon_s=self.horizon_s,
            dt_s=self._effective_dt(),
            ambient_c=ambient_c,
            solar_w=solar_w,
            terminal_energy_value_per_kwh=self.terminal_energy_value_per_kwh,
            objective=objective,
            label=f"mpc-cycle-{self._cycle}",
        )

    # -- one cycle ----------------------------------------------------------

    def step(
        self,
        state: BatteryState,
        *,
        demand: Demand | float | None = None,
        mission: Mission | None = None,
        ambient_c: float | np.ndarray | None = None,
        solar_w: float | np.ndarray | None = None,
        objective: Any = None,
    ) -> MPCStep:
        """Re-plan from the current state and return the action to execute."""
        started = time.perf_counter()
        problem = self.build_problem(
            state,
            demand=demand,
            mission=mission,
            ambient_c=ambient_c,
            solar_w=solar_w,
            objective=objective,
        )
        fell_back = False
        note = ""
        try:
            recommendation = self.engine.optimise(problem)
        except (InfeasibleProblem, SafetyViolation) as exc:
            # The controller must always produce an action. Resting is always
            # admissible: it is the only action that cannot violate a current,
            # voltage or thermal limit, so it is the safe default.
            log.warning("MPC cycle %d could not plan (%s); resting", self._cycle, exc)
            fell_back = True
            note = f"fell back to rest: {exc}"
            recommendation = self._rest_recommendation(problem, str(exc))

        if self.warm_start:
            self._previous_plan = recommendation.plan_power_w

        step = MPCStep(
            cycle=self._cycle,
            timestamp=state.timestamp,
            state=state,
            recommendation=recommendation,
            applied_power_w=recommendation.recommended_power_w,
            applied_cooling=recommendation.cooling_requirement,
            solve_seconds=time.perf_counter() - started,
            fell_back=fell_back,
            note=note,
        )
        self.history.append(step)
        self._cycle += 1
        return step

    def _rest_recommendation(
        self, problem: OptimisationProblem, reason: str
    ) -> Recommendation:
        from ..scenario.engine import Scenario
        from .problem import build_recommendation

        n = problem.n_steps
        scenario = Scenario(
            label="SAFE REST",
            power_w=(self.safe_action,) * n,
            cooling=(0.0,) * n,
            description="Fallback: no feasible plan was found.",
            tags=("fallback", "rest"),
        )
        evaluated = self.engine.scenarios.evaluate(problem, scenario)
        return build_recommendation(
            problem=problem,
            power_w=self.safe_action,
            cooling=0.0,
            outcome=evaluated.outcome,
            value=evaluated.value,
            limiting="no feasible plan",
            plan_power=scenario.power_w,
            plan_cooling=scenario.cooling,
            reason=f"Safe fallback to rest. {reason}",
            method="fallback",
            confidence=0.3,
        )

    # -- closed loop --------------------------------------------------------

    def run(
        self,
        initial_state: BatteryState,
        *,
        cycles: int,
        plant: Any | None = None,
        demand: Callable[[int, BatteryState], Demand | float | None] | Demand | float | None = None,
        ambient_c: Callable[[int], float] | float | None = None,
        solar_w: Callable[[int], float] | float | None = None,
        objective: Any = None,
    ) -> MPCHistory:
        """Run the closed loop against a plant model.

        This is the simulation-first path: the same controller code runs
        against a virtual plant here and against real hardware in deployment,
        with only the source of ``state`` differing.
        """
        plant = plant or self.engine.plant
        state = initial_state
        for k in range(cycles):
            d = demand(k, state) if callable(demand) else demand
            amb = ambient_c(k) if callable(ambient_c) else ambient_c
            sol = solar_w(k) if callable(solar_w) else solar_w
            step = self.step(
                state, demand=d, ambient_c=amb, solar_w=sol, objective=objective
            )
            result = plant.step(
                state,
                Action(
                    power_w=step.applied_power_w,
                    cooling_fraction=step.applied_cooling,
                ),
                self.control_dt_s,
                ambient_c=amb if isinstance(amb, (int, float)) else None,
            )
            state = result.state
        return self.history

    def reset(self) -> None:
        self.history = MPCHistory()
        self._previous_plan = ()
        self._cycle = 0


__all__ = ["ModelPredictiveController", "MPCStep", "MPCHistory", "geometric_steps"]
