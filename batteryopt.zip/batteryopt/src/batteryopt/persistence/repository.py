"""Persistence: one interface, two backends.

:class:`Repository` is a protocol. :class:`InMemoryRepository` implements it
with no dependencies and is what tests, simulations and single-process
deployments use. :class:`PostgresRepository` implements the same protocol over
``psycopg`` and is what production uses. Nothing above this layer knows which
one it has.

The immutability rule from section 26 is enforced in *both* backends, not just
in the database: :meth:`InMemoryRepository.append_telemetry` returns records
that are frozen, and any attempt to modify stored raw telemetry raises
:class:`~batteryopt.core.exceptions.ImmutabilityError`. A rule that only holds
in production is a rule that gets broken in development.
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from typing import Any, Iterable, Protocol, Sequence, runtime_checkable

from ..core.exceptions import ImmutabilityError, PersistenceError
from ..core.optional import try_import
from ..core.versioning import (
    CODE_VERSION,
    MODEL_VERSION,
    OPTIMISER_VERSION,
    SCHEMA_VERSION,
    content_hash,
)
from ..models.state import BatteryState
from ..optimisation.problem import Recommendation
from ..telemetry.schema import TelemetryFrame, ValidationResult

log = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class TelemetryRecord:
    """A stored raw frame. Frozen, because raw telemetry is append-only."""

    id: int
    battery_id: str
    frame: TelemetryFrame
    accepted: bool
    repaired: bool
    issues: tuple[dict[str, Any], ...] = ()


@dataclass(frozen=True, slots=True)
class OptimisationRecord:
    """A stored optimisation run, complete enough to reproduce."""

    run_id: int
    battery_id: str
    timestamp: float
    code_version: str
    model_version: str
    optimiser_version: str
    configuration_version: str
    inputs: dict[str, Any]
    constraints: dict[str, Any]
    objective: dict[str, Any]
    result: dict[str, Any]
    digest: str
    method: str
    seed: int | None = None
    solve_seconds: float = 0.0

    def as_dict(self) -> dict[str, Any]:
        return {
            "run_id": self.run_id,
            "battery_id": self.battery_id,
            "timestamp": self.timestamp,
            "code_version": self.code_version,
            "model_version": self.model_version,
            "optimiser_version": self.optimiser_version,
            "configuration_version": self.configuration_version,
            "digest": self.digest,
            "method": self.method,
            "seed": self.seed,
            "solve_seconds": self.solve_seconds,
        }


@runtime_checkable
class Repository(Protocol):
    """Storage interface used by the pipeline and the API."""

    def append_telemetry(
        self, frame: TelemetryFrame, result: ValidationResult | None = None
    ) -> TelemetryRecord: ...
    def append_state(self, state: BatteryState, *, battery_id: str) -> int: ...
    def append_recommendation(
        self, recommendation: Recommendation, *, battery_id: str
    ) -> OptimisationRecord: ...
    def latest_state(self, battery_id: str) -> BatteryState | None: ...
    def recent_states(self, battery_id: str, limit: int = 100) -> Sequence[BatteryState]: ...
    def recent_telemetry(self, battery_id: str, limit: int = 100) -> Sequence[TelemetryRecord]: ...
    def optimisation_runs(self, battery_id: str, limit: int = 50) -> Sequence[OptimisationRecord]: ...
    def find_run(self, digest: str) -> OptimisationRecord | None: ...
    def close(self) -> None: ...


class InMemoryRepository:
    """Dependency-free repository with the same semantics as the database.

    Bounded by construction: without a limit, a long-running process accumulates
    every frame it has ever seen and eventually dies. The bound is explicit and
    the eviction count is reported, because silently forgetting data is worse
    than refusing to store it.
    """

    def __init__(self, *, max_telemetry: int = 200_000, max_states: int = 200_000) -> None:
        self.max_telemetry = max_telemetry
        self.max_states = max_states
        self._telemetry: list[TelemetryRecord] = []
        self._states: list[tuple[str, BatteryState]] = []
        self._runs: list[OptimisationRecord] = []
        self._recommendations: list[tuple[str, Recommendation]] = []
        self._by_digest: dict[str, OptimisationRecord] = {}
        self._next_telemetry_id = 1
        self._next_run_id = 1
        self.evicted_telemetry = 0
        self.evicted_states = 0

    # -- writes -------------------------------------------------------------

    def append_telemetry(
        self, frame: TelemetryFrame, result: ValidationResult | None = None
    ) -> TelemetryRecord:
        record = TelemetryRecord(
            id=self._next_telemetry_id,
            battery_id=frame.battery_id,
            frame=frame,
            accepted=result.accepted if result else True,
            repaired=result.repaired if result else False,
            issues=tuple(i.as_dict() for i in result.issues) if result else (),
        )
        self._next_telemetry_id += 1
        self._telemetry.append(record)
        if len(self._telemetry) > self.max_telemetry:
            overflow = len(self._telemetry) - self.max_telemetry
            del self._telemetry[:overflow]
            self.evicted_telemetry += overflow
        return record

    def append_state(self, state: BatteryState, *, battery_id: str) -> int:
        self._states.append((battery_id, state))
        if len(self._states) > self.max_states:
            overflow = len(self._states) - self.max_states
            del self._states[:overflow]
            self.evicted_states += overflow
        return len(self._states)

    def append_recommendation(
        self, recommendation: Recommendation, *, battery_id: str
    ) -> OptimisationRecord:
        fingerprint = recommendation.fingerprint
        payload = recommendation.as_dict()
        record = OptimisationRecord(
            run_id=self._next_run_id,
            battery_id=battery_id,
            timestamp=payload.get("outcome", {}).get("duration_s", 0.0)
            if payload.get("outcome")
            else 0.0,
            code_version=fingerprint.code_version if fingerprint else CODE_VERSION,
            model_version=fingerprint.model_version if fingerprint else MODEL_VERSION,
            optimiser_version=fingerprint.optimiser_version if fingerprint else OPTIMISER_VERSION,
            configuration_version=SCHEMA_VERSION,
            inputs={"input_hash": fingerprint.input_hash if fingerprint else ""},
            constraints={"constraint_hash": fingerprint.constraint_hash if fingerprint else ""},
            objective=payload.get("objective") or {},
            result=payload,
            digest=fingerprint.digest if fingerprint else content_hash(payload),
            method=recommendation.method,
            seed=fingerprint.seed if fingerprint else None,
            solve_seconds=recommendation.solve_seconds,
        )
        self._next_run_id += 1
        self._runs.append(record)
        self._by_digest[record.digest] = record
        self._recommendations.append((battery_id, recommendation))
        return record

    # -- immutability -------------------------------------------------------

    def delete_telemetry(self, record_id: int) -> None:
        """Always raises. Raw telemetry is append-only in every backend."""
        raise ImmutabilityError(
            f"raw telemetry record {record_id} cannot be deleted: the telemetry log is "
            "append-only, because it is the only record that cannot be recomputed"
        )

    def update_telemetry(self, record_id: int, **changes: Any) -> None:
        """Always raises. See :meth:`delete_telemetry`."""
        raise ImmutabilityError(
            f"raw telemetry record {record_id} cannot be modified; store a corrected "
            "derived value instead and leave the original frame intact"
        )

    # -- reads --------------------------------------------------------------

    def latest_state(self, battery_id: str) -> BatteryState | None:
        for stored_id, state in reversed(self._states):
            if stored_id == battery_id:
                return state
        return None

    def recent_states(self, battery_id: str, limit: int = 100) -> Sequence[BatteryState]:
        out = [s for bid, s in self._states if bid == battery_id]
        return out[-limit:]

    def recent_telemetry(self, battery_id: str, limit: int = 100) -> Sequence[TelemetryRecord]:
        out = [r for r in self._telemetry if r.battery_id == battery_id]
        return out[-limit:]

    def optimisation_runs(
        self, battery_id: str, limit: int = 50
    ) -> Sequence[OptimisationRecord]:
        out = [r for r in self._runs if r.battery_id == battery_id]
        return out[-limit:]

    def latest_recommendation(self, battery_id: str) -> Recommendation | None:
        for stored_id, rec in reversed(self._recommendations):
            if stored_id == battery_id:
                return rec
        return None

    def find_run(self, digest: str) -> OptimisationRecord | None:
        return self._by_digest.get(digest)

    def stats(self) -> dict[str, int]:
        return {
            "telemetry": len(self._telemetry),
            "states": len(self._states),
            "runs": len(self._runs),
            "evicted_telemetry": self.evicted_telemetry,
            "evicted_states": self.evicted_states,
        }

    def close(self) -> None:
        return None


class PostgresRepository:
    """PostgreSQL-backed repository.

    Requires ``batteryopt[db]``. Writes are batched by default: telemetry at ten
    frames a second per battery is a lot of round trips, and a single-row insert
    per frame is the usual reason a working prototype falls over in production.
    """

    def __init__(
        self,
        dsn: str,
        *,
        batch_size: int = 64,
        autocommit: bool = True,
        create_schema: bool = False,
    ) -> None:
        psycopg = try_import("psycopg")
        if psycopg is None:
            raise PersistenceError(
                "PostgreSQL support requires psycopg. Install it with: "
                "pip install 'batteryopt[db]'"
            )
        self._psycopg = psycopg
        self.dsn = dsn
        self.batch_size = batch_size
        self._conn = psycopg.connect(dsn, autocommit=autocommit)
        self._telemetry_batch: list[tuple] = []
        if create_schema:
            self.create_schema()

    @staticmethod
    def schema_sql() -> str:
        from importlib import resources

        return (
            resources.files("batteryopt.persistence").joinpath("schema.sql").read_text("utf-8")
        )

    def create_schema(self) -> None:
        with self._conn.cursor() as cur:
            cur.execute(self.schema_sql())

    # -- writes -------------------------------------------------------------

    def append_telemetry(
        self, frame: TelemetryFrame, result: ValidationResult | None = None
    ) -> TelemetryRecord:
        row = (
            frame.battery_id,
            frame.timestamp,
            frame.voltage_v,
            frame.current_a,
            frame.temperature_c,
            frame.ambient_c,
            frame.coolant_c,
            list(frame.cell_voltages_v) or None,
            list(frame.module_temperatures_c) or None,
            frame.reported_soc,
            frame.reported_soh,
            frame.source,
            frame.sequence,
            result.accepted if result else True,
            result.repaired if result else False,
            json.dumps([i.as_dict() for i in result.issues] if result else []),
        )
        self._telemetry_batch.append(row)
        if len(self._telemetry_batch) >= self.batch_size:
            self.flush()
        return TelemetryRecord(
            id=-1,
            battery_id=frame.battery_id,
            frame=frame,
            accepted=result.accepted if result else True,
            repaired=result.repaired if result else False,
            issues=tuple(i.as_dict() for i in result.issues) if result else (),
        )

    def flush(self) -> int:
        if not self._telemetry_batch:
            return 0
        sql = """
            INSERT INTO batteryopt.telemetry
                (battery_id, ts, voltage_v, current_a, temperature_c, ambient_c,
                 coolant_c, cell_voltages_v, module_temperatures_c, reported_soc,
                 reported_soh, source, sequence, accepted, repaired, issues)
            VALUES (%s, to_timestamp(%s), %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
                    %s, %s, %s, %s::jsonb)
        """
        with self._conn.cursor() as cur:
            cur.executemany(sql, self._telemetry_batch)
        count = len(self._telemetry_batch)
        self._telemetry_batch.clear()
        return count

    def append_state(self, state: BatteryState, *, battery_id: str) -> int:
        sql = """
            INSERT INTO batteryopt.state_estimates
                (battery_id, ts, soc, soh_capacity, soh_resistance, capacity_ah,
                 resistance_ohm, voltage_v, current_a, power_w, temperature_c,
                 cell_imbalance_v, power_limit_charge_w, power_limit_discharge_w,
                 provenance, model_version)
            VALUES (%s, to_timestamp(%s), %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
                    %s, %s, %s::jsonb, %s)
            RETURNING id
        """
        payload = state.as_dict()
        with self._conn.cursor() as cur:
            cur.execute(
                sql,
                (
                    battery_id,
                    state.timestamp,
                    state.soc,
                    state.soh_capacity,
                    state.soh_resistance,
                    state.capacity_ah,
                    state.resistance_ohm,
                    state.voltage_v,
                    state.current_a,
                    state.power_w,
                    state.temperature_c,
                    state.cell_imbalance_v,
                    state.power_limit_charge_w,
                    state.power_limit_discharge_w,
                    json.dumps(payload.get("provenance", {})),
                    MODEL_VERSION,
                ),
            )
            row = cur.fetchone()
        return int(row[0]) if row else -1

    def append_recommendation(
        self, recommendation: Recommendation, *, battery_id: str
    ) -> OptimisationRecord:
        fingerprint = recommendation.fingerprint
        payload = recommendation.as_dict()
        digest = fingerprint.digest if fingerprint else content_hash(payload)
        run_sql = """
            INSERT INTO batteryopt.optimisation_runs
                (battery_id, ts, code_version, model_version, optimiser_version,
                 configuration_version, inputs, constraints, objective, result,
                 digest, seed, method, solve_seconds)
            VALUES (%s, to_timestamp(%s), %s, %s, %s, %s, %s::jsonb, %s::jsonb,
                    %s::jsonb, %s::jsonb, %s, %s, %s, %s)
            RETURNING run_id
        """
        with self._conn.cursor() as cur:
            cur.execute(
                run_sql,
                (
                    battery_id,
                    payload.get("horizon_s", 0.0),
                    fingerprint.code_version if fingerprint else CODE_VERSION,
                    fingerprint.model_version if fingerprint else MODEL_VERSION,
                    fingerprint.optimiser_version if fingerprint else OPTIMISER_VERSION,
                    SCHEMA_VERSION,
                    json.dumps({"input_hash": fingerprint.input_hash if fingerprint else ""}),
                    json.dumps(
                        {"constraint_hash": fingerprint.constraint_hash if fingerprint else ""}
                    ),
                    json.dumps(payload.get("objective") or {}),
                    json.dumps(payload),
                    digest,
                    fingerprint.seed if fingerprint else None,
                    recommendation.method,
                    recommendation.solve_seconds,
                ),
            )
            row = cur.fetchone()
            run_id = int(row[0]) if row else -1

            cur.execute(
                """
                INSERT INTO batteryopt.recommendations
                    (run_id, battery_id, ts, recommended_power_w, cooling_requirement,
                     target_soc, estimated_efficiency, estimated_degradation,
                     estimated_cost, currency, confidence, limiting_constraint, mode, reason)
                VALUES (%s, %s, to_timestamp(%s), %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """,
                (
                    run_id,
                    battery_id,
                    payload.get("horizon_s", 0.0),
                    recommendation.recommended_power_w,
                    recommendation.cooling_requirement,
                    recommendation.target_soc,
                    recommendation.estimated_efficiency,
                    recommendation.estimated_degradation,
                    recommendation.estimated_cost,
                    recommendation.currency,
                    recommendation.confidence,
                    recommendation.limiting_constraint,
                    recommendation.mode,
                    recommendation.reason[:4000],
                ),
            )
        return OptimisationRecord(
            run_id=run_id,
            battery_id=battery_id,
            timestamp=payload.get("horizon_s", 0.0),
            code_version=CODE_VERSION,
            model_version=MODEL_VERSION,
            optimiser_version=OPTIMISER_VERSION,
            configuration_version=SCHEMA_VERSION,
            inputs={},
            constraints={},
            objective=payload.get("objective") or {},
            result=payload,
            digest=digest,
            method=recommendation.method,
            solve_seconds=recommendation.solve_seconds,
        )

    # -- reads --------------------------------------------------------------

    def latest_state(self, battery_id: str) -> BatteryState | None:
        with self._conn.cursor() as cur:
            cur.execute(
                "SELECT soc, soh_capacity, soh_resistance, voltage_v, current_a, "
                "power_w, temperature_c, extract(epoch from ts) "
                "FROM batteryopt.latest_state WHERE battery_id = %s",
                (battery_id,),
            )
            row = cur.fetchone()
        if row is None:
            return None
        return BatteryState(
            soc=row[0],
            soh_capacity=row[1],
            soh_resistance=row[2],
            voltage_v=row[3],
            current_a=row[4],
            power_w=row[5],
            temperature_c=row[6],
            timestamp=row[7],
        )

    def recent_states(self, battery_id: str, limit: int = 100) -> Sequence[BatteryState]:
        with self._conn.cursor() as cur:
            cur.execute(
                "SELECT soc, soh_capacity, soh_resistance, voltage_v, current_a, power_w, "
                "temperature_c, extract(epoch from ts) FROM batteryopt.state_estimates "
                "WHERE battery_id = %s ORDER BY ts DESC LIMIT %s",
                (battery_id, limit),
            )
            rows = cur.fetchall()
        return [
            BatteryState(
                soc=r[0],
                soh_capacity=r[1],
                soh_resistance=r[2],
                voltage_v=r[3],
                current_a=r[4],
                power_w=r[5],
                temperature_c=r[6],
                timestamp=r[7],
            )
            for r in reversed(rows)
        ]

    def recent_telemetry(self, battery_id: str, limit: int = 100) -> Sequence[TelemetryRecord]:
        self.flush()
        with self._conn.cursor() as cur:
            cur.execute(
                "SELECT id, extract(epoch from ts), voltage_v, current_a, temperature_c, "
                "accepted, repaired FROM batteryopt.telemetry WHERE battery_id = %s "
                "ORDER BY ts DESC LIMIT %s",
                (battery_id, limit),
            )
            rows = cur.fetchall()
        return [
            TelemetryRecord(
                id=int(r[0]),
                battery_id=battery_id,
                frame=TelemetryFrame(
                    battery_id=battery_id,
                    timestamp=r[1],
                    voltage_v=r[2],
                    current_a=r[3],
                    temperature_c=r[4],
                    source="postgres",
                ),
                accepted=bool(r[5]),
                repaired=bool(r[6]),
            )
            for r in reversed(rows)
        ]

    def optimisation_runs(
        self, battery_id: str, limit: int = 50
    ) -> Sequence[OptimisationRecord]:
        with self._conn.cursor() as cur:
            cur.execute(
                "SELECT run_id, extract(epoch from ts), code_version, model_version, "
                "optimiser_version, configuration_version, result, digest, method, "
                "solve_seconds FROM batteryopt.optimisation_runs WHERE battery_id = %s "
                "ORDER BY ts DESC LIMIT %s",
                (battery_id, limit),
            )
            rows = cur.fetchall()
        return [
            OptimisationRecord(
                run_id=int(r[0]),
                battery_id=battery_id,
                timestamp=r[1],
                code_version=r[2],
                model_version=r[3],
                optimiser_version=r[4],
                configuration_version=r[5],
                inputs={},
                constraints={},
                objective={},
                result=r[6],
                digest=r[7],
                method=r[8],
                solve_seconds=r[9],
            )
            for r in reversed(rows)
        ]

    def find_run(self, digest: str) -> OptimisationRecord | None:
        runs = []
        with self._conn.cursor() as cur:
            cur.execute(
                "SELECT run_id, battery_id, extract(epoch from ts), result, method "
                "FROM batteryopt.optimisation_runs WHERE digest = %s LIMIT 1",
                (digest,),
            )
            row = cur.fetchone()
        if row is None:
            return None
        return OptimisationRecord(
            run_id=int(row[0]),
            battery_id=row[1],
            timestamp=row[2],
            code_version=CODE_VERSION,
            model_version=MODEL_VERSION,
            optimiser_version=OPTIMISER_VERSION,
            configuration_version=SCHEMA_VERSION,
            inputs={},
            constraints={},
            objective={},
            result=row[3],
            digest=digest,
            method=row[4],
        )

    def close(self) -> None:
        try:
            self.flush()
        finally:
            self._conn.close()


def open_repository(dsn: str | None = None, **kwargs: Any) -> Repository:
    """Open a repository, falling back to in-memory when no DSN is given.

    The fallback is loud in the logs rather than silent: a deployment that meant
    to have a database and does not should find out from the first log line, not
    from an empty audit trail three months later.
    """
    if not dsn:
        log.info("no database DSN configured; using the in-memory repository")
        return InMemoryRepository(**kwargs)
    try:
        return PostgresRepository(dsn, **kwargs)
    except PersistenceError as exc:
        log.warning("falling back to the in-memory repository: %s", exc)
        return InMemoryRepository()


__all__ = [
    "Repository",
    "InMemoryRepository",
    "PostgresRepository",
    "TelemetryRecord",
    "OptimisationRecord",
    "open_repository",
]
