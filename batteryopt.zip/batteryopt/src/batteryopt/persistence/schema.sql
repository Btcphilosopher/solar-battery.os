-- BatteryOpt PostgreSQL schema (specification section 26).
--
-- Two design rules run through the whole schema.
--
-- 1. RAW TELEMETRY IS IMMUTABLE. The telemetry table is append-only and is
--    protected by a trigger that rejects UPDATE and DELETE outright, not by
--    convention or by permissions alone. Everything downstream is a derived
--    view that can be recomputed; the raw record is the one thing that cannot
--    be reconstructed, so it is the one thing the database refuses to change.
--
-- 2. EVERY OPTIMISATION RESULT IS REPRODUCIBLE. optimisation_runs stores the
--    model version, the configuration version, the inputs, the constraints, the
--    objective and a content hash of all four. Re-running the same digest on
--    the same code must produce the same recommendation, and the digest is what
--    makes that checkable rather than hoped for.

CREATE SCHEMA IF NOT EXISTS batteryopt;
SET search_path TO batteryopt, public;

-- ---------------------------------------------------------------------------
-- Configuration
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS chemistries (
    name              TEXT PRIMARY KEY,
    family            TEXT NOT NULL,
    version           TEXT NOT NULL,
    parameters        JSONB NOT NULL,
    parameter_source  TEXT,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS batteries (
    battery_id        TEXT PRIMARY KEY,
    name              TEXT,
    chemistry         TEXT NOT NULL REFERENCES chemistries(name),
    topology          JSONB NOT NULL,
    envelope          JSONB NOT NULL,
    nameplate_capacity_ah  DOUBLE PRECISION NOT NULL,
    nominal_energy_wh      DOUBLE PRECISION NOT NULL,
    commissioned_at   TIMESTAMPTZ,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS packs (
    pack_id           TEXT PRIMARY KEY,
    battery_id        TEXT NOT NULL REFERENCES batteries(battery_id) ON DELETE CASCADE,
    position          INTEGER NOT NULL,
    serial_number     TEXT,
    metadata          JSONB NOT NULL DEFAULT '{}'::jsonb
);

CREATE TABLE IF NOT EXISTS modules (
    module_id         TEXT PRIMARY KEY,
    pack_id           TEXT NOT NULL REFERENCES packs(pack_id) ON DELETE CASCADE,
    position          INTEGER NOT NULL,
    serial_number     TEXT,
    metadata          JSONB NOT NULL DEFAULT '{}'::jsonb
);

CREATE TABLE IF NOT EXISTS cells (
    cell_id           TEXT PRIMARY KEY,
    module_id         TEXT NOT NULL REFERENCES modules(module_id) ON DELETE CASCADE,
    position          INTEGER NOT NULL,
    capacity_ah       DOUBLE PRECISION,
    metadata          JSONB NOT NULL DEFAULT '{}'::jsonb
);

-- ---------------------------------------------------------------------------
-- Raw telemetry: APPEND ONLY
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS telemetry (
    id                BIGSERIAL PRIMARY KEY,
    battery_id        TEXT NOT NULL,
    ts                TIMESTAMPTZ NOT NULL,
    voltage_v         DOUBLE PRECISION,
    current_a         DOUBLE PRECISION,
    temperature_c     DOUBLE PRECISION,
    ambient_c         DOUBLE PRECISION,
    coolant_c         DOUBLE PRECISION,
    cell_voltages_v   DOUBLE PRECISION[],
    module_temperatures_c DOUBLE PRECISION[],
    reported_soc      DOUBLE PRECISION,
    reported_soh      DOUBLE PRECISION,
    source            TEXT NOT NULL,
    sequence          BIGINT,
    -- Validation outcome is recorded alongside the raw frame rather than
    -- replacing it: a rejected frame is still evidence of what the sensor said.
    accepted          BOOLEAN NOT NULL DEFAULT TRUE,
    repaired          BOOLEAN NOT NULL DEFAULT FALSE,
    issues            JSONB NOT NULL DEFAULT '[]'::jsonb,
    ingested_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS telemetry_battery_ts_idx ON telemetry (battery_id, ts DESC);
CREATE INDEX IF NOT EXISTS telemetry_accepted_idx ON telemetry (battery_id, accepted, ts DESC);

CREATE OR REPLACE FUNCTION reject_telemetry_mutation() RETURNS TRIGGER AS $$
BEGIN
    RAISE EXCEPTION
        'batteryopt.telemetry is append-only: % on raw telemetry is not permitted',
        TG_OP;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS telemetry_immutable ON telemetry;
CREATE TRIGGER telemetry_immutable
    BEFORE UPDATE OR DELETE ON telemetry
    FOR EACH ROW EXECUTE FUNCTION reject_telemetry_mutation();

-- ---------------------------------------------------------------------------
-- Derived state
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS state_estimates (
    id                BIGSERIAL PRIMARY KEY,
    battery_id        TEXT NOT NULL,
    ts                TIMESTAMPTZ NOT NULL,
    soc               DOUBLE PRECISION NOT NULL,
    soc_stddev        DOUBLE PRECISION,
    soh_capacity      DOUBLE PRECISION NOT NULL,
    soh_resistance    DOUBLE PRECISION NOT NULL,
    capacity_ah       DOUBLE PRECISION,
    resistance_ohm    DOUBLE PRECISION,
    voltage_v         DOUBLE PRECISION,
    current_a         DOUBLE PRECISION,
    power_w           DOUBLE PRECISION,
    temperature_c     DOUBLE PRECISION,
    cell_imbalance_v  DOUBLE PRECISION,
    power_limit_charge_w    DOUBLE PRECISION,
    power_limit_discharge_w DOUBLE PRECISION,
    -- Per-field provenance, so a stored state can never be mistaken for a
    -- stored measurement.
    provenance        JSONB NOT NULL DEFAULT '{}'::jsonb,
    model_version     TEXT NOT NULL,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS state_battery_ts_idx ON state_estimates (battery_id, ts DESC);

CREATE TABLE IF NOT EXISTS health_estimates (
    id                BIGSERIAL PRIMARY KEY,
    battery_id        TEXT NOT NULL,
    ts                TIMESTAMPTZ NOT NULL,
    soh_capacity      DOUBLE PRECISION NOT NULL,
    resistance_growth DOUBLE PRECISION NOT NULL,
    capacity_fade     DOUBLE PRECISION NOT NULL,
    t_eq_years        DOUBLE PRECISION,
    a_eq_efc          DOUBLE PRECISION,
    remaining_useful_life_years DOUBLE PRECISION,
    rul_p10_years     DOUBLE PRECISION,
    rul_p90_years     DOUBLE PRECISION,
    limiting_mechanism TEXT,
    confidence        DOUBLE PRECISION,
    model_version     TEXT NOT NULL,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS health_battery_ts_idx ON health_estimates (battery_id, ts DESC);

CREATE TABLE IF NOT EXISTS degradation_events (
    id                BIGSERIAL PRIMARY KEY,
    battery_id        TEXT NOT NULL,
    ts                TIMESTAMPTZ NOT NULL,
    mechanism         TEXT NOT NULL,
    severity          DOUBLE PRECISION,
    capacity_fade     DOUBLE PRECISION,
    stress_factors    JSONB NOT NULL DEFAULT '{}'::jsonb,
    notes             TEXT
);

CREATE TABLE IF NOT EXISTS thermal_events (
    id                BIGSERIAL PRIMARY KEY,
    battery_id        TEXT NOT NULL,
    ts                TIMESTAMPTZ NOT NULL,
    kind              TEXT NOT NULL,
    peak_temperature_c DOUBLE PRECISION,
    duration_s        DOUBLE PRECISION,
    cooling_fraction  DOUBLE PRECISION,
    notes             TEXT
);

-- ---------------------------------------------------------------------------
-- Sessions
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS charging_sessions (
    session_id        BIGSERIAL PRIMARY KEY,
    battery_id        TEXT NOT NULL,
    started_at        TIMESTAMPTZ NOT NULL,
    ended_at          TIMESTAMPTZ,
    start_soc         DOUBLE PRECISION,
    end_soc           DOUBLE PRECISION,
    energy_wh         DOUBLE PRECISION,
    mean_power_w      DOUBLE PRECISION,
    peak_power_w      DOUBLE PRECISION,
    peak_temperature_c DOUBLE PRECISION,
    energy_cost       DOUBLE PRECISION,
    currency          TEXT,
    capacity_fade     DOUBLE PRECISION,
    plan              JSONB
);

CREATE TABLE IF NOT EXISTS discharging_sessions (
    session_id        BIGSERIAL PRIMARY KEY,
    battery_id        TEXT NOT NULL,
    started_at        TIMESTAMPTZ NOT NULL,
    ended_at          TIMESTAMPTZ,
    start_soc         DOUBLE PRECISION,
    end_soc           DOUBLE PRECISION,
    energy_wh         DOUBLE PRECISION,
    mean_power_w      DOUBLE PRECISION,
    peak_power_w      DOUBLE PRECISION,
    peak_temperature_c DOUBLE PRECISION,
    revenue           DOUBLE PRECISION,
    currency          TEXT,
    capacity_fade     DOUBLE PRECISION
);

CREATE TABLE IF NOT EXISTS maintenance (
    id                BIGSERIAL PRIMARY KEY,
    battery_id        TEXT NOT NULL,
    ts                TIMESTAMPTZ NOT NULL,
    action            TEXT NOT NULL,
    performed_by      TEXT,
    notes             TEXT,
    metadata          JSONB NOT NULL DEFAULT '{}'::jsonb
);

-- ---------------------------------------------------------------------------
-- Optimisation: reproducibility is the whole point of these tables
-- ---------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS optimisation_runs (
    run_id            BIGSERIAL PRIMARY KEY,
    battery_id        TEXT NOT NULL,
    ts                TIMESTAMPTZ NOT NULL,
    -- Reproducibility fields (specification section 26).
    code_version      TEXT NOT NULL,
    model_version     TEXT NOT NULL,
    optimiser_version TEXT NOT NULL,
    configuration_version TEXT NOT NULL,
    inputs            JSONB NOT NULL,
    constraints       JSONB NOT NULL,
    objective         JSONB NOT NULL,
    result            JSONB NOT NULL,
    digest            TEXT NOT NULL,
    seed              BIGINT,
    method            TEXT NOT NULL,
    solve_seconds     DOUBLE PRECISION,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS optimisation_battery_ts_idx ON optimisation_runs (battery_id, ts DESC);
CREATE INDEX IF NOT EXISTS optimisation_digest_idx ON optimisation_runs (digest);

CREATE TABLE IF NOT EXISTS recommendations (
    id                BIGSERIAL PRIMARY KEY,
    run_id            BIGINT REFERENCES optimisation_runs(run_id) ON DELETE CASCADE,
    battery_id        TEXT NOT NULL,
    ts                TIMESTAMPTZ NOT NULL,
    recommended_power_w     DOUBLE PRECISION NOT NULL,
    cooling_requirement     DOUBLE PRECISION,
    target_soc              DOUBLE PRECISION,
    estimated_efficiency    DOUBLE PRECISION,
    estimated_degradation   DOUBLE PRECISION,
    estimated_cost          DOUBLE PRECISION,
    currency                TEXT,
    confidence              DOUBLE PRECISION,
    limiting_constraint     TEXT,
    mode                    TEXT,
    reason                  TEXT,
    -- Whether the downstream BMS or EMS actually followed the advice, filled
    -- in later. Without this the platform can never learn whether its
    -- recommendations were used, let alone whether they were any good.
    accepted_by_controller  BOOLEAN,
    actual_power_w          DOUBLE PRECISION
);

CREATE INDEX IF NOT EXISTS recommendations_battery_ts_idx ON recommendations (battery_id, ts DESC);

CREATE TABLE IF NOT EXISTS scenarios (
    id                BIGSERIAL PRIMARY KEY,
    run_id            BIGINT REFERENCES optimisation_runs(run_id) ON DELETE CASCADE,
    label             TEXT NOT NULL,
    rank              INTEGER,
    feasible          BOOLEAN NOT NULL,
    score             DOUBLE PRECISION,
    outcome           JSONB NOT NULL,
    violations        JSONB NOT NULL DEFAULT '[]'::jsonb
);

CREATE INDEX IF NOT EXISTS scenarios_run_idx ON scenarios (run_id, rank);

-- ---------------------------------------------------------------------------
-- Convenience views
-- ---------------------------------------------------------------------------

CREATE OR REPLACE VIEW latest_state AS
SELECT DISTINCT ON (battery_id) *
FROM state_estimates
ORDER BY battery_id, ts DESC;

CREATE OR REPLACE VIEW latest_recommendation AS
SELECT DISTINCT ON (battery_id) *
FROM recommendations
ORDER BY battery_id, ts DESC;

CREATE OR REPLACE VIEW telemetry_quality AS
SELECT
    battery_id,
    date_trunc('hour', ts) AS hour,
    count(*)                                        AS frames,
    count(*) FILTER (WHERE accepted)                AS accepted,
    count(*) FILTER (WHERE repaired)                AS repaired,
    count(*) FILTER (WHERE NOT accepted)            AS rejected,
    avg(CASE WHEN accepted THEN 1.0 ELSE 0.0 END)   AS acceptance_rate
FROM telemetry
GROUP BY battery_id, hour;
