"""Caching: Redis when available, process-local otherwise.

Two things are worth caching in this platform, and they have different
lifetimes:

* **Surrogate response surfaces**, which are expensive to build and depend only
  on the battery configuration. Shared across processes, they are what makes a
  horizontally-scaled deployment start quickly.
* **Hot state and recommendations**, which are cheap but read constantly by
  dashboards and other services.

Both go through :class:`Cache`, and the process-local implementation is a real
LRU with TTL rather than a stub, so behaviour is the same with and without
Redis. Cache keys always include the model version, so a deployment that
upgrades the physics cannot serve a stale surrogate built by the old one.
"""

from __future__ import annotations

import json
import logging
import pickle
import time
from collections import OrderedDict
from typing import Any, Protocol, runtime_checkable

from ..core.optional import try_import
from ..core.versioning import MODEL_VERSION

log = logging.getLogger(__name__)


def versioned_key(*parts: str) -> str:
    """Build a cache key that includes the model version."""
    return "batteryopt:" + MODEL_VERSION + ":" + ":".join(parts)


@runtime_checkable
class Cache(Protocol):
    def get(self, key: str) -> Any | None: ...
    def set(self, key: str, value: Any, *, ttl_s: float | None = None) -> None: ...
    def delete(self, key: str) -> None: ...
    def clear(self) -> None: ...


class LocalCache:
    """LRU cache with per-entry TTL. No dependencies."""

    def __init__(self, *, max_items: int = 256, default_ttl_s: float | None = None) -> None:
        self.max_items = max_items
        self.default_ttl_s = default_ttl_s
        self._items: OrderedDict[str, tuple[Any, float | None]] = OrderedDict()
        self.hits = 0
        self.misses = 0

    def get(self, key: str) -> Any | None:
        entry = self._items.get(key)
        if entry is None:
            self.misses += 1
            return None
        value, expires = entry
        if expires is not None and time.monotonic() > expires:
            del self._items[key]
            self.misses += 1
            return None
        self._items.move_to_end(key)
        self.hits += 1
        return value

    def set(self, key: str, value: Any, *, ttl_s: float | None = None) -> None:
        ttl = ttl_s if ttl_s is not None else self.default_ttl_s
        expires = time.monotonic() + ttl if ttl else None
        self._items[key] = (value, expires)
        self._items.move_to_end(key)
        while len(self._items) > self.max_items:
            self._items.popitem(last=False)

    def delete(self, key: str) -> None:
        self._items.pop(key, None)

    def clear(self) -> None:
        self._items.clear()

    def stats(self) -> dict[str, Any]:
        total = self.hits + self.misses
        return {
            "backend": "local",
            "items": len(self._items),
            "hits": self.hits,
            "misses": self.misses,
            "hit_rate": self.hits / total if total else 0.0,
        }


class RedisCache:
    """Redis-backed cache, for sharing across processes.

    Values are pickled, which means the cache is trusted infrastructure and must
    not be exposed to untrusted writers -- the same assumption every Python
    object cache makes, stated here so it is not discovered by accident.
    JSON-serialisable values take a JSON path instead, so the common case of
    caching a recommendation stays inspectable with ``redis-cli``.
    """

    def __init__(self, url: str = "redis://localhost:6379/0", *, default_ttl_s: float = 3600.0) -> None:
        redis = try_import("redis")
        if redis is None:
            raise RuntimeError(
                "Redis support requires the redis package. Install it with: "
                "pip install 'batteryopt[db]'"
            )
        self._client = redis.Redis.from_url(url)
        self.default_ttl_s = default_ttl_s

    def get(self, key: str) -> Any | None:
        raw = self._client.get(key)
        if raw is None:
            return None
        if raw.startswith(b"json:"):
            return json.loads(raw[5:].decode("utf-8"))
        return pickle.loads(raw[7:]) if raw.startswith(b"pickle:") else None

    def set(self, key: str, value: Any, *, ttl_s: float | None = None) -> None:
        try:
            payload = b"json:" + json.dumps(value).encode("utf-8")
        except (TypeError, ValueError):
            payload = b"pickle:" + pickle.dumps(value)
        self._client.set(key, payload, ex=int(ttl_s or self.default_ttl_s))

    def delete(self, key: str) -> None:
        self._client.delete(key)

    def clear(self) -> None:
        """Delete only this platform's keys, never the whole database."""
        pattern = versioned_key("*")
        for key in self._client.scan_iter(match=pattern):
            self._client.delete(key)

    def stats(self) -> dict[str, Any]:
        try:
            info = self._client.info("stats")
            hits = int(info.get("keyspace_hits", 0))
            misses = int(info.get("keyspace_misses", 0))
        except Exception:  # pragma: no cover - depends on server config
            hits = misses = 0
        total = hits + misses
        return {
            "backend": "redis",
            "hits": hits,
            "misses": misses,
            "hit_rate": hits / total if total else 0.0,
        }


def open_cache(url: str | None = None, **kwargs: Any) -> Cache:
    """Open a Redis cache when a URL is given and reachable, else a local one."""
    if not url:
        return LocalCache(**kwargs)
    try:
        cache = RedisCache(url, **kwargs)
        cache.get(versioned_key("healthcheck"))
        return cache
    except Exception as exc:  # noqa: BLE001 - any connection failure falls back
        log.warning("Redis unavailable (%s); using the process-local cache", exc)
        return LocalCache()


__all__ = ["Cache", "LocalCache", "RedisCache", "open_cache", "versioned_key"]
