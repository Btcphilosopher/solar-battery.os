"""Persistence: immutable telemetry, reproducible optimisation runs, caching."""

from .cache import Cache, LocalCache, RedisCache, open_cache, versioned_key
from .repository import (
    InMemoryRepository,
    OptimisationRecord,
    PostgresRepository,
    Repository,
    TelemetryRecord,
    open_repository,
)

__all__ = [
    "Repository",
    "InMemoryRepository",
    "PostgresRepository",
    "TelemetryRecord",
    "OptimisationRecord",
    "open_repository",
    "Cache",
    "LocalCache",
    "RedisCache",
    "open_cache",
    "versioned_key",
]
