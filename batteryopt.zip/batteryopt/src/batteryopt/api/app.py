"""FastAPI service.

A thin HTTP surface over the engine. It does five things and nothing else:
register batteries, accept telemetry, expose state, run optimisations, and
serve the dashboard. Every route is a few lines, because the moment the API
layer starts making decisions it becomes a second, undocumented copy of the
optimiser.

Two properties are worth calling out:

* **Optimisation is serialised per process.** The twin's estimator is stateful,
  and two concurrent requests interleaving inside a Kalman update would corrupt
  it. The service state holds a lock; the routes use it.
* **Safety violations return 409, not 500.** A recommendation refused because
  it would breach a hard constraint is a *correct* outcome of the engine, not
  an internal failure, and a caller must be able to tell the two apart.
"""

from __future__ import annotations

import logging
from typing import Any

from ..core.exceptions import (
    ConfigurationError,
    InfeasibleProblem,
    OptimisationError,
    SafetyViolation,
    TelemetryError,
)
from ..core.optional import capabilities, have
from ..core.versioning import version_report
from ..economics.prices import Tariff
from ..models.battery import Battery
from ..models.chemistry import available_chemistries
from ..optimisation.objective import available_presets
from ..optimisation.problem import Demand
from ..telemetry.schema import TelemetryFrame
from pydantic import BaseModel, Field

from .dashboard import render_dashboard, render_error
from .state import SERVICE, ServiceState

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Request models
#
# Defined at module level, not inside create_app(). With
# ``from __future__ import annotations`` every annotation is a string, and
# FastAPI resolves those against the *module* namespace. A model defined in a
# function's local scope cannot be found there, so FastAPI silently falls back
# to treating the parameter as a query string -- which shows up as a confusing
# "field required" error on a request that plainly has a body.
# ---------------------------------------------------------------------------


class RegisterRequest(BaseModel):
    """Create a battery from a topology description."""

    battery_id: str
    chemistry: str = "lithium_ion_generic"
    cells_series: int = Field(1, ge=1)
    cells_parallel: int = Field(1, ge=1)
    modules_series: int = Field(1, ge=1)
    modules_parallel: int = Field(1, ge=1)
    cell_capacity_ah: float | None = None
    objective: str = "balanced"
    initial_soc: float = Field(0.5, ge=0.0, le=1.0)
    initial_temperature_c: float = 25.0
    max_charge_power_w: float | None = None
    max_discharge_power_w: float | None = None
    age_years: float = Field(0.0, ge=0.0)
    equivalent_full_cycles: float = Field(0.0, ge=0.0)
    import_price_per_kwh: float | None = None
    export_price_per_kwh: float | None = None
    label: str = ""


class OptimiseRequest(BaseModel):
    """Ask for a recommendation."""

    demand_w: float | None = None
    firm: bool = True
    objective: str | None = None
    horizon_s: float = Field(900.0, gt=0)
    dt_s: float = Field(60.0, gt=0)
    ambient_c: float | None = None
    method: str | None = None




def create_app(service: ServiceState | None = None) -> Any:
    """Build the FastAPI application.

    Importing this module never requires FastAPI; only calling this function
    does, so the library remains usable in environments where the HTTP extra is
    not installed.
    """
    if not have("fastapi"):
        raise ConfigurationError(
            "The HTTP service requires FastAPI. Install it with: "
            "pip install 'batteryopt[api]'"
        )
    from fastapi import Body, FastAPI, HTTPException, Query, WebSocket, WebSocketDisconnect
    from fastapi.responses import HTMLResponse, JSONResponse

    state = service or SERVICE

    app = FastAPI(
        title="BatteryOpt",
        version=version_report()["code"],
        description=(
            "Battery optimisation, simulation and decision engine. Produces "
            "recommendations for an existing BMS or EMS; it is not a battery "
            "management system and is not a substitute for independent protection."
        ),
    )

    # -- meta ---------------------------------------------------------------

    @app.get("/health", tags=["meta"])
    def health() -> dict[str, Any]:
        return {
            "status": "ok",
            "versions": dict(version_report()),
            "batteries": state.ids(),
        }

    @app.get("/capabilities", tags=["meta"])
    def capabilities_route() -> dict[str, Any]:
        """Which optional dependencies are active, and what is used instead."""
        return {
            "optional_dependencies": capabilities(),
            "chemistries": available_chemistries(),
            "objectives": available_presets(),
        }

    # -- battery registry ---------------------------------------------------

    @app.post("/batteries", tags=["batteries"], status_code=201)
    def register_battery(request: RegisterRequest) -> dict[str, Any]:
        try:
            battery = Battery.build(
                chemistry=request.chemistry,
                cells_series=request.cells_series,
                cells_parallel=request.cells_parallel,
                modules_series=request.modules_series,
                modules_parallel=request.modules_parallel,
                cell_capacity_ah=request.cell_capacity_ah,
                battery_id=request.battery_id,
                name=request.label,
                max_charge_power_w=request.max_charge_power_w,
                max_discharge_power_w=request.max_discharge_power_w,
            )
            if request.age_years > 0 or request.equivalent_full_cycles > 0:
                battery = Battery.aged(
                    battery,
                    years=request.age_years,
                    equivalent_full_cycles=request.equivalent_full_cycles,
                )
        except ConfigurationError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

        tariff = None
        if request.import_price_per_kwh is not None:
            tariff = Tariff.flat(
                request.import_price_per_kwh, request.export_price_per_kwh
            )
        managed = state.register(
            battery,
            objective=request.objective,
            tariff=tariff,
            initial_soc=request.initial_soc,
            initial_temperature_c=request.initial_temperature_c,
            label=request.label,
        )
        return {"battery_id": managed.battery_id, "battery": battery.describe()}

    @app.get("/batteries", tags=["batteries"])
    def list_batteries() -> dict[str, Any]:
        return state.summary()

    @app.get("/batteries/{battery_id}", tags=["batteries"])
    def get_battery(battery_id: str) -> dict[str, Any]:
        try:
            return state.require(battery_id).battery.describe()
        except ConfigurationError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc

    @app.delete("/batteries/{battery_id}", tags=["batteries"])
    def delete_battery(battery_id: str) -> dict[str, Any]:
        return {"removed": state.unregister(battery_id)}

    # -- telemetry ----------------------------------------------------------

    @app.post("/batteries/{battery_id}/telemetry", tags=["telemetry"])
    def post_telemetry(battery_id: str, payload: dict[str, Any] = Body(...)) -> dict[str, Any]:
        try:
            managed = state.require(battery_id)
        except ConfigurationError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        try:
            frame = TelemetryFrame.model_validate({**payload, "battery_id": battery_id,
                                                   "source": "rest"})
        except Exception as exc:  # noqa: BLE001 - untrusted input
            raise HTTPException(status_code=422, detail=f"malformed frame: {exc}") from exc
        with state.lock:
            recommendation = managed.pipeline.step(frame)
        return {
            "accepted": managed.pipeline.stats.frames_accepted,
            "rejected": managed.pipeline.stats.frames_rejected,
            "state": managed.twin.state.as_dict(include_provenance=False),
            "recommendation": recommendation.as_dict() if recommendation else None,
        }

    @app.websocket("/batteries/{battery_id}/telemetry/ws")
    async def telemetry_socket(websocket: WebSocket, battery_id: str) -> None:
        await websocket.accept()
        managed = state.get(battery_id)
        if managed is None:
            await websocket.close(code=4404)
            return
        try:
            while True:
                message = await websocket.receive_json()
                try:
                    frame = TelemetryFrame.model_validate(
                        {**message, "battery_id": battery_id, "source": "websocket"}
                    )
                except Exception as exc:  # noqa: BLE001
                    await websocket.send_json({"error": f"malformed frame: {exc}"})
                    continue
                with state.lock:
                    recommendation = managed.pipeline.step(frame)
                await websocket.send_json(
                    {
                        "soc": managed.twin.state.soc,
                        "temperature_c": managed.twin.state.temperature_c,
                        "recommended_power_w": (
                            recommendation.recommended_power_w if recommendation else None
                        ),
                    }
                )
        except WebSocketDisconnect:
            log.info("telemetry websocket for %s disconnected", battery_id)

    @app.get("/batteries/{battery_id}/telemetry/stats", tags=["telemetry"])
    def telemetry_stats(battery_id: str) -> dict[str, Any]:
        try:
            managed = state.require(battery_id)
        except ConfigurationError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        return {
            "pipeline": managed.pipeline.stats.as_dict(),
            "validation": managed.pipeline.validator.stats.as_dict(),
            "health": managed.pipeline.health(),
        }

    # -- state --------------------------------------------------------------

    @app.get("/batteries/{battery_id}/state", tags=["state"])
    def get_state(battery_id: str) -> dict[str, Any]:
        try:
            managed = state.require(battery_id)
        except ConfigurationError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        return managed.twin.state.as_dict()

    @app.get("/batteries/{battery_id}/twin", tags=["state"])
    def get_twin(battery_id: str) -> dict[str, Any]:
        try:
            managed = state.require(battery_id)
        except ConfigurationError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        return managed.twin.snapshot().as_dict()

    @app.get("/batteries/{battery_id}/health", tags=["state"])
    def battery_health(battery_id: str) -> dict[str, Any]:
        try:
            managed = state.require(battery_id)
        except ConfigurationError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        life = managed.twin.project_life()
        return {"life": life.as_dict(), "state": managed.twin.state.as_dict()}

    # -- optimisation -------------------------------------------------------

    @app.post("/batteries/{battery_id}/optimise", tags=["optimisation"])
    def optimise(battery_id: str, request: OptimiseRequest) -> dict[str, Any]:
        try:
            managed = state.require(battery_id)
        except ConfigurationError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc

        demand = (
            Demand(power_w=request.demand_w, firm=request.firm)
            if request.demand_w is not None
            else None
        )
        engine = managed.engine
        previous_method = engine.method
        if request.method:
            engine.method = request.method
        try:
            with state.lock:
                recommendation = engine.optimise_state(
                    managed.twin.state,
                    demand=demand,
                    objective=request.objective,
                    horizon_s=request.horizon_s,
                    dt_s=request.dt_s,
                    ambient_c=request.ambient_c,
                )
        except SafetyViolation as exc:
            # A refusal on safety grounds is a correct result, not a server
            # fault: 409 Conflict so callers can distinguish it from a bug.
            raise HTTPException(
                status_code=409,
                detail={
                    "error": "safety_violation",
                    "message": str(exc),
                    "violations": [v.as_dict() for v in exc.violations],
                },
            ) from exc
        except InfeasibleProblem as exc:
            raise HTTPException(
                status_code=422,
                detail={"error": "infeasible", "message": str(exc), "limiting": exc.limiting},
            ) from exc
        except OptimisationError as exc:
            raise HTTPException(
                status_code=422, detail={"error": "optimisation_failed", "message": str(exc)}
            ) from exc
        finally:
            engine.method = previous_method
        return recommendation.as_dict()

    @app.get("/batteries/{battery_id}/pareto", tags=["optimisation"])
    def pareto(
        battery_id: str,
        horizon_s: float = Query(900.0, gt=0),
        dt_s: float = Query(60.0, gt=0),
        demand_w: float | None = None,
    ) -> dict[str, Any]:
        try:
            managed = state.require(battery_id)
        except ConfigurationError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        problem = managed.engine.build_problem(
            managed.twin.state,
            demand=Demand(power_w=demand_w, firm=False) if demand_w is not None else None,
            horizon_s=horizon_s,
            dt_s=dt_s,
        )
        with state.lock:
            front = managed.engine.pareto(problem)
        return front.as_dict()

    @app.get("/batteries/{battery_id}/recommendation", tags=["optimisation"])
    def latest_recommendation(battery_id: str) -> dict[str, Any]:
        try:
            managed = state.require(battery_id)
        except ConfigurationError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        recommendation = managed.pipeline.latest_recommendation
        if recommendation is None:
            raise HTTPException(status_code=404, detail="no recommendation has been produced yet")
        return recommendation.as_dict()

    @app.get("/runs/{digest}", tags=["optimisation"])
    def get_run(digest: str) -> dict[str, Any]:
        record = state.repository.find_run(digest)
        if record is None:
            raise HTTPException(status_code=404, detail=f"no optimisation run with digest {digest}")
        return record.as_dict()

    # -- dashboard ----------------------------------------------------------

    @app.get("/", response_class=HTMLResponse, include_in_schema=False)
    def index() -> HTMLResponse:
        ids = state.ids()
        if not ids:
            return HTMLResponse(
                render_error(
                    "No batteries registered. POST to /batteries to add one, or run "
                    "`batteryopt serve --demo` to start with a simulated battery."
                ),
                status_code=404,
            )
        return dashboard(ids[0])

    @app.get("/dashboard/{battery_id}", response_class=HTMLResponse, include_in_schema=False)
    def dashboard(battery_id: str) -> HTMLResponse:
        managed = state.get(battery_id)
        if managed is None:
            return HTMLResponse(render_error(f"Unknown battery {battery_id!r}."), status_code=404)
        arrays = managed.twin.history.as_arrays()
        history = {
            "soc": arrays["soc"][-120:].tolist(),
            "temperature_c": arrays["temperature_c"][-120:].tolist(),
            "power_w": arrays["power_w"][-120:].tolist(),
        }
        html = render_dashboard(
            battery_label=managed.label,
            snapshot=managed.twin.snapshot(),
            recommendation=managed.pipeline.latest_recommendation,
            history=history,
            pipeline_health=managed.pipeline.health(),
        )
        return HTMLResponse(html)

    # -- error handling -----------------------------------------------------

    @app.exception_handler(TelemetryError)
    def telemetry_error_handler(_request: Any, exc: TelemetryError) -> JSONResponse:
        return JSONResponse(status_code=422, content={"error": "telemetry", "message": str(exc)})

    return app


def serve(
    *,
    host: str = "127.0.0.1",
    port: int = 8000,
    demo: bool = False,
    log_level: str = "info",
) -> None:  # pragma: no cover - process entry point
    """Run the service with uvicorn, optionally seeding a demo battery."""
    if not have("fastapi"):
        raise ConfigurationError(
            "Install the API extra to serve: pip install 'batteryopt[api]'"
        )
    import uvicorn

    if demo:
        seed_demo(SERVICE)
    uvicorn.run(create_app(SERVICE), host=host, port=port, log_level=log_level)


def seed_demo(service: ServiceState) -> None:
    """Register a simulated EV battery and feed it a few minutes of telemetry."""
    from ..telemetry.sources.simulated import SimulatedSource, drive_cycle

    battery = Battery.aged(
        Battery.build(
            chemistry="nmc",
            cells_series=96,
            cells_parallel=4,
            battery_id="demo-ev",
            name="Demo EV pack",
            max_charge_power_w=110_000,
            max_discharge_power_w=250_000,
        ),
        years=2.0,
        equivalent_full_cycles=420.0,
    )
    managed = service.register(
        battery,
        objective="ev",
        tariff=Tariff.time_of_use(peak_price=0.42, off_peak_price=0.09),
        initial_soc=0.62,
        initial_temperature_c=24.0,
        optimise_interval_s=30.0,
        horizon_s=900.0,
        dt_s=60.0,
        label="Demo EV pack",
    )
    source = SimulatedSource(
        battery,
        initial_soc=0.68,
        dt_s=2.0,
        duty_cycle=drive_cycle(peak_w=55_000),
        n_cell_sensors=12,
        seed=7,
    )
    managed.pipeline.demand = lambda _state: 35_000.0
    managed.pipeline.run_sync(source.frames(150))


__all__ = ["create_app", "serve", "seed_demo"]
