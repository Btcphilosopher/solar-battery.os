"""Shared service state: the batteries this process is managing.

One :class:`ManagedBattery` per battery, each owning its twin, engine, pipeline
and telemetry source. The API layer holds a registry of them and does nothing
else -- all the logic lives in the layers below, which is what keeps the HTTP
surface thin enough to be obviously correct.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from typing import Any

from ..core.versioning import version_report
from ..economics.engine import EconomicConfig, EconomicEngine
from ..economics.prices import Tariff
from ..models.battery import Battery
from ..optimisation.constraints import ConstraintSet
from ..optimisation.engine import OptimisationEngine
from ..persistence.repository import Repository, open_repository
from ..telemetry.pipeline import TelemetryPipeline
from ..telemetry.sources.network import RESTSource
from ..telemetry.validation import TelemetryValidator
from ..twin.twin import DigitalTwin


@dataclass(slots=True)
class ManagedBattery:
    """Everything the service knows about one battery."""

    battery: Battery
    twin: DigitalTwin
    engine: OptimisationEngine
    pipeline: TelemetryPipeline
    rest_source: RESTSource = field(default_factory=RESTSource)
    label: str = ""

    @property
    def battery_id(self) -> str:
        return self.battery.battery_id

    def snapshot(self) -> dict[str, Any]:
        return self.pipeline.snapshot()


class ServiceState:
    """Registry of managed batteries, safe for concurrent request handling.

    A lock guards registration and the optimisation path. Optimisation mutates
    the twin's estimator state, and two concurrent requests interleaving inside
    a Kalman update would corrupt it -- a class of bug that is very hard to see
    in testing and very easy to prevent here.
    """

    def __init__(self, *, repository: Repository | None = None) -> None:
        self._batteries: dict[str, ManagedBattery] = {}
        self._lock = threading.RLock()
        self.repository = repository or open_repository()

    # -- registration -------------------------------------------------------

    def register(
        self,
        battery: Battery,
        *,
        objective: str = "balanced",
        tariff: Tariff | None = None,
        economics: EconomicConfig | None = None,
        constraints: ConstraintSet | None = None,
        initial_soc: float = 0.5,
        initial_temperature_c: float = 25.0,
        optimise_interval_s: float = 60.0,
        horizon_s: float = 900.0,
        dt_s: float = 60.0,
        label: str = "",
    ) -> ManagedBattery:
        with self._lock:
            twin = DigitalTwin(
                battery,
                initial_soc=initial_soc,
                initial_temperature_c=initial_temperature_c,
            )
            engine = OptimisationEngine(
                battery,
                objective=objective,
                constraints=constraints,
                economics=EconomicEngine(battery, economics) if economics else None,
                tariff=tariff,
            )
            pipeline = TelemetryPipeline(
                twin,
                engine,
                validator=TelemetryValidator(battery),
                optimise_interval_s=optimise_interval_s,
                horizon_s=horizon_s,
                dt_s=dt_s,
                repository=self.repository,
            )
            managed = ManagedBattery(
                battery=battery,
                twin=twin,
                engine=engine,
                pipeline=pipeline,
                label=label or battery.name or battery.battery_id,
            )
            self._batteries[battery.battery_id] = managed
            return managed

    def unregister(self, battery_id: str) -> bool:
        with self._lock:
            return self._batteries.pop(battery_id, None) is not None

    # -- access -------------------------------------------------------------

    def get(self, battery_id: str) -> ManagedBattery | None:
        return self._batteries.get(battery_id)

    def require(self, battery_id: str) -> ManagedBattery:
        managed = self.get(battery_id)
        if managed is None:
            from ..core.exceptions import ConfigurationError

            raise ConfigurationError(
                f"battery {battery_id!r} is not registered; known batteries: "
                f"{', '.join(sorted(self._batteries)) or '(none)'}"
            )
        return managed

    def ids(self) -> list[str]:
        return sorted(self._batteries)

    def all(self) -> list[ManagedBattery]:
        return [self._batteries[k] for k in self.ids()]

    @property
    def lock(self) -> threading.RLock:
        return self._lock

    def summary(self) -> dict[str, Any]:
        return {
            "versions": dict(version_report()),
            "batteries": [
                {
                    "battery_id": m.battery_id,
                    "label": m.label,
                    "chemistry": m.battery.chemistry_name,
                    "soc": m.twin.state.soc,
                    "soh": m.twin.state.soh_capacity,
                    "frames": m.pipeline.stats.frames_in,
                }
                for m in self.all()
            ],
        }


#: Process-wide service state. The FastAPI app binds to this.
SERVICE = ServiceState()


__all__ = ["ServiceState", "ManagedBattery", "SERVICE"]
