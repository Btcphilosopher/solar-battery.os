"""HTTP service and dashboard."""

from .dashboard import render_dashboard, render_error
from .state import ManagedBattery, ServiceState

__all__ = ["render_dashboard", "render_error", "ServiceState", "ManagedBattery"]


def create_app(*args, **kwargs):  # pragma: no cover - thin re-export
    """Build the FastAPI app (imports FastAPI lazily)."""
    from .app import create_app as _create_app

    return _create_app(*args, **kwargs)
