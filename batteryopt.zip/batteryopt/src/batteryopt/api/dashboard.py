"""The industrial dashboard (specification section 32).

The brief is unusual and worth taking literally: *"The dashboard should
emphasise **why** the optimiser selected a particular operating point."* Most
battery dashboards show state. This one shows state, then spends most of its
area on the reasoning -- the objective in force, the term-by-term breakdown of
the score, the constraint that bound, and the alternatives that were rejected
and by how much.

Design decisions:

* **Numbers, not gauges.** The headline values are hero numbers on stat tiles.
  A radial gauge for a state of charge occupies twenty times the pixels of the
  number it encodes and is read less accurately.
* **Sparklines carry history, one series each.** A single-series line needs no
  legend: the tile's own label names it.
* **The rejected alternatives are a bar chart, sorted, direct-labelled.** "Why
  not the fast option?" is the question operators actually ask, and it deserves
  a chart rather than a footnote.
* **Provenance is on the page.** Every value is tagged measured, estimated,
  simulated or optimised, because a dashboard that presents a simulated
  degradation figure as if it were measured is exactly the failure mode
  specification section 34 warns about.

The page is a single self-contained HTML document with no external requests,
so it works on an isolated industrial network.
"""

from __future__ import annotations

import html
import json
from typing import Any, Sequence

from ..core.provenance import Provenance
from ..optimisation.problem import Recommendation
from ..twin.twin import TwinSnapshot

# --- palette ---------------------------------------------------------------
# Dark-mode categorical slots 1-3 and the fixed status palette, validated
# against the #1a1a19 surface (all-pairs CVD dE 9.4, normal-vision 20.9,
# contrast >= 3:1). Do not re-order or substitute without re-validating.
PALETTE = {
    "surface": "#1a1a19",
    "page": "#0d0d0d",
    "raised": "#242422",
    "line": "#33332f",
    "text": "#ffffff",
    "text_secondary": "#c3c2b7",
    "text_muted": "#8a8a80",
    "soc": "#3987e5",
    "temperature": "#d95926",
    "power": "#199e70",
    "good": "#0ca30c",
    "warning": "#fab219",
    "serious": "#ec835a",
    "critical": "#d03b3b",
}

PROVENANCE_LABEL = {
    Provenance.MEASURED: "measured",
    Provenance.ESTIMATED: "estimated",
    Provenance.PREDICTED: "predicted",
    Provenance.SIMULATED: "simulated",
    Provenance.MODELLED: "modelled",
    Provenance.OPTIMISED: "optimised",
}


def _e(value: Any) -> str:
    return html.escape(str(value), quote=True)


def _sparkline(
    values: Sequence[float],
    *,
    colour: str,
    width: int = 240,
    height: int = 44,
    label: str = "",
) -> str:
    """A single-series sparkline. 2px stroke, no axes, no legend."""
    points = [float(v) for v in values if v == v]
    if len(points) < 2:
        return (
            f'<svg class="spark" viewBox="0 0 {width} {height}" role="img" '
            f'aria-label="{_e(label)}: not enough history"></svg>'
        )
    lo, hi = min(points), max(points)
    span = (hi - lo) or 1.0
    n = len(points)
    pad = 3
    coords = [
        (
            pad + i * (width - 2 * pad) / (n - 1),
            height - pad - (v - lo) / span * (height - 2 * pad),
        )
        for i, v in enumerate(points)
    ]
    path = " ".join(f"{'M' if i == 0 else 'L'}{x:.1f},{y:.1f}" for i, (x, y) in enumerate(coords))
    area = (
        f"M{coords[0][0]:.1f},{height - pad:.1f} "
        + " ".join(f"L{x:.1f},{y:.1f}" for x, y in coords)
        + f" L{coords[-1][0]:.1f},{height - pad:.1f} Z"
    )
    last_x, last_y = coords[-1]
    return (
        f'<svg class="spark" viewBox="0 0 {width} {height}" preserveAspectRatio="none" '
        f'role="img" aria-label="{_e(label)} over the recent window, '
        f'{lo:.4g} to {hi:.4g}">'
        f'<path d="{area}" fill="{colour}" opacity="0.13"/>'
        f'<path d="{path}" fill="none" stroke="{colour}" stroke-width="2" '
        f'stroke-linejoin="round" stroke-linecap="round"/>'
        f'<circle cx="{last_x:.1f}" cy="{last_y:.1f}" r="3.2" fill="{colour}" '
        f'stroke="{PALETTE["surface"]}" stroke-width="2"/>'
        "</svg>"
    )


def _tile(
    label: str,
    value: str,
    *,
    unit: str = "",
    provenance: Provenance = Provenance.ESTIMATED,
    spark: str = "",
    status: str | None = None,
    note: str = "",
) -> str:
    status_html = ""
    if status:
        colour = PALETTE.get(status, PALETTE["text_secondary"])
        icon = {"good": "OK", "warning": "!", "serious": "!!", "critical": "X"}.get(status, "")
        status_html = (
            f'<span class="status" style="color:{colour};border-color:{colour}">'
            f"{_e(icon)}</span>"
        )
    return f"""
      <div class="tile">
        <div class="tile-head">
          <span class="tile-label">{_e(label)}</span>
          {status_html}
        </div>
        <div class="tile-value">{_e(value)}<span class="tile-unit">{_e(unit)}</span></div>
        <div class="tile-meta">{_e(PROVENANCE_LABEL.get(provenance, 'estimated'))}{
            ' &middot; ' + _e(note) if note else ''}</div>
        {spark}
      </div>
    """


def _term_bars(recommendation: Recommendation) -> str:
    """Term-by-term objective breakdown: what actually decided the answer."""
    value = recommendation.objective_value
    if value is None:
        return '<p class="empty">No objective breakdown available.</p>'
    terms = sorted(value.weighted_terms.items(), key=lambda kv: abs(kv[1]), reverse=True)
    terms = [(k, v) for k, v in terms if abs(v) > 1e-9][:8]
    if not terms:
        return '<p class="empty">Every objective term evaluated to zero.</p>'
    scale = max(abs(v) for _, v in terms) or 1.0
    rows = []
    for name, amount in terms:
        pct = abs(amount) / scale * 50.0
        positive = amount >= 0
        colour = PALETTE["power"] if positive else PALETTE["temperature"]
        left = 50.0 if positive else 50.0 - pct
        rows.append(
            f"""
            <div class="bar-row">
              <div class="bar-label">{_e(name)}</div>
              <div class="bar-track">
                <div class="bar-zero"></div>
                <div class="bar-fill" style="left:{left:.2f}%;width:{pct:.2f}%;
                     background:{colour}"></div>
              </div>
              <div class="bar-value" style="color:{colour}">{amount:+.3f}</div>
            </div>
            """
        )
    return (
        f'<div class="bars">{"".join(rows)}</div>'
        f'<p class="axis-note">Contribution to the score in {_e(value.currency)}. '
        "Positive is value gained, negative is value given up.</p>"
    )


def _alternatives(recommendation: Recommendation, *, limit: int = 6) -> str:
    """The rejected candidates, with the margin by which they lost."""
    alternatives = list(recommendation.alternatives)[:limit]
    if not alternatives:
        return '<p class="empty">No alternatives were recorded for this run.</p>'
    chosen_score = (
        recommendation.objective_value.total if recommendation.objective_value else 0.0
    )
    rows = []
    for alt in alternatives:
        label = alt.get("scenario", {}).get("label") or (
            f"{alt.get('power_w', 0.0) / 1000.0:.1f} kW"
            + (f" @ cooling {alt.get('cooling', 0.0) * 100:.0f}%" if "cooling" in alt else "")
        )
        score = alt.get("score", alt.get("objective", {}).get("total", 0.0))
        feasible = alt.get("feasible", True)
        margin = chosen_score - float(score) if score == score else float("inf")
        if not feasible:
            detail = "rejected: violates a hard constraint"
            colour = PALETTE["critical"]
        else:
            detail = f"worse by {margin:.3f}"
            colour = PALETTE["text_muted"]
        rows.append(
            f"""
            <tr>
              <td>{_e(label)}</td>
              <td class="num">{'' if score != score else f'{float(score):+.3f}'}</td>
              <td style="color:{colour}">{_e(detail)}</td>
            </tr>
            """
        )
    return f"""
      <table class="alt-table">
        <thead><tr><th>Alternative considered</th><th class="num">Score</th>
        <th>Outcome</th></tr></thead>
        <tbody>{''.join(rows)}</tbody>
      </table>
    """


def _limits_panel(snapshot: TwinSnapshot) -> str:
    capability = snapshot.diagnostics.capability
    if capability is None:
        return ""
    rows = []
    for name, watts in sorted(
        capability.discharge_limits_w.items(), key=lambda kv: kv[1]
    )[:5]:
        binding = name == capability.discharge_limiting
        colour = PALETTE["warning"] if binding else PALETTE["text_muted"]
        rows.append(
            f'<tr><td style="color:{colour}">{_e(name.replace("_", " "))}</td>'
            f'<td class="num">{watts / 1000.0:.1f} kW</td>'
            f'<td>{"binding" if binding else ""}</td></tr>'
        )
    return f"""
      <table class="alt-table">
        <thead><tr><th>Discharge limit</th><th class="num">Value</th><th></th></tr></thead>
        <tbody>{''.join(rows)}</tbody>
      </table>
    """


def render_dashboard(
    *,
    battery_label: str,
    snapshot: TwinSnapshot,
    recommendation: Recommendation | None,
    history: dict[str, list[float]] | None = None,
    pipeline_health: dict[str, Any] | None = None,
    refresh_seconds: int = 10,
) -> str:
    """Render the whole dashboard as one self-contained HTML document."""
    state = snapshot.state
    history = history or {}
    soc_hist = history.get("soc", [])
    temp_hist = history.get("temperature_c", [])
    power_hist = history.get("power_w", [])

    temp_status = (
        "critical"
        if state.temperature_max_c > 50
        else "warning"
        if state.temperature_max_c > 40
        else "good"
    )
    soh_status = (
        "critical"
        if state.soh_capacity < 0.7
        else "warning"
        if state.soh_capacity < 0.8
        else "good"
    )

    tiles = [
        _tile(
            "State of charge",
            f"{state.soc * 100:.1f}",
            unit="%",
            provenance=state.provenance_of("soc"),
            spark=_sparkline(soc_hist, colour=PALETTE["soc"], label="State of charge"),
        ),
        _tile(
            "State of health",
            f"{state.soh_capacity * 100:.1f}",
            unit="%",
            provenance=state.provenance_of("soh_capacity"),
            status=soh_status,
            note=f"resistance +{(state.soh_resistance - 1.0) * 100:.0f}%",
        ),
        _tile(
            "Temperature",
            f"{state.temperature_c:.1f}",
            unit="degC",
            provenance=state.provenance_of("temperature_c"),
            status=temp_status,
            spark=_sparkline(temp_hist, colour=PALETTE["temperature"], label="Temperature"),
            note=f"hottest cell {state.temperature_max_c:.1f} degC",
        ),
        _tile(
            "Power",
            f"{state.power_w / 1000.0:.1f}",
            unit="kW",
            provenance=state.provenance_of("power_w"),
            spark=_sparkline(power_hist, colour=PALETTE["power"], label="Power"),
            note=state.mode,
        ),
        _tile(
            "Terminal voltage",
            f"{state.voltage_v:.1f}",
            unit="V",
            provenance=state.provenance_of("voltage_v"),
        ),
        _tile(
            "Cell imbalance",
            f"{state.cell_imbalance_v * 1000:.0f}",
            unit="mV",
            provenance=state.provenance_of("cell_imbalance_v"),
        ),
    ]

    if recommendation is not None:
        objective_name = (
            recommendation.objective_value.as_dict()["terms"] if recommendation.objective_value else {}
        )
        recommended = f"""
          <div class="hero">
            <div class="hero-label">RECOMMENDED OPERATING POINT</div>
            <div class="hero-number">{abs(recommendation.recommended_power_w) / 1000.0:.1f}
              <span class="hero-unit">kW {_e(recommendation.mode)}</span></div>
            <div class="hero-sub">
              cooling {recommendation.cooling_requirement * 100:.0f}% &middot;
              target SOC {recommendation.target_soc * 100:.1f}% &middot;
              confidence {recommendation.confidence * 100:.0f}%
            </div>
            <div class="hero-meta">optimised &middot; method {_e(recommendation.method)}
              &middot; {recommendation.solve_seconds * 1000:.0f} ms</div>
          </div>
          <div class="detail-grid">
            <div><span class="k">Estimated efficiency</span>
              <span class="v">{recommendation.estimated_efficiency * 100:.2f}%</span></div>
            <div><span class="k">Estimated degradation</span>
              <span class="v">{recommendation.estimated_degradation * 100:.5f}%</span></div>
            <div><span class="k">Estimated cost</span>
              <span class="v">{recommendation.estimated_cost:.3f}
              {_e(recommendation.currency)}</span></div>
            <div><span class="k">Limiting constraint</span>
              <span class="v">{_e(recommendation.limiting_constraint or 'none binding')}</span></div>
          </div>
          <div class="why">
            <div class="why-head">WHY THIS OPERATING POINT</div>
            {_term_bars(recommendation)}
            <p class="reason">{_e(recommendation.reason)}</p>
          </div>
          <div class="why">
            <div class="why-head">ALTERNATIVES CONSIDERED</div>
            {_alternatives(recommendation)}
          </div>
        """
    else:
        recommended = (
            '<div class="hero"><div class="hero-label">RECOMMENDED OPERATING POINT</div>'
            '<div class="hero-number">--</div>'
            '<div class="hero-sub">No recommendation yet: the engine has not run since '
            "the last telemetry frame.</div></div>"
        )

    life = snapshot.life
    life_html = ""
    if life is not None:
        band = life.quantiles_years
        life_html = f"""
          <div class="panel">
            <div class="panel-head">REMAINING USEFUL LIFE</div>
            <div class="hero-number small">{life.remaining_years:.1f}
              <span class="hero-unit">years</span></div>
            <div class="hero-sub">P10-P90 {band.p10:.1f}-{band.p90:.1f} years &middot;
              limited by {_e(life.limiting_mechanism)} &middot;
              confidence {life.confidence * 100:.0f}%</div>
            <div class="hero-meta">predicted &mdash; a model projection, not a measurement</div>
          </div>
        """

    health_html = ""
    if pipeline_health:
        items = "".join(
            f'<div><span class="k">{_e(k.replace("_", " "))}</span>'
            f'<span class="v">{_e(round(v, 3) if isinstance(v, float) else v)}</span></div>'
            for k, v in pipeline_health.items()
        )
        health_html = f'<div class="panel"><div class="panel-head">PIPELINE</div>' \
                      f'<div class="detail-grid">{items}</div></div>'

    return f"""<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="refresh" content="{int(refresh_seconds)}">
<title>BatteryOpt &mdash; {_e(battery_label)}</title>
<style>
  :root {{
    color-scheme: dark;
    --surface: {PALETTE['surface']};
    --page: {PALETTE['page']};
    --raised: {PALETTE['raised']};
    --line: {PALETTE['line']};
    --text: {PALETTE['text']};
    --text-2: {PALETTE['text_secondary']};
    --muted: {PALETTE['text_muted']};
  }}
  * {{ box-sizing: border-box; }}
  body {{
    margin: 0; background: var(--page); color: var(--text);
    font: 14px/1.5 ui-monospace, "SF Mono", "Cascadia Mono", Menlo, Consolas, monospace;
    letter-spacing: 0.01em;
  }}
  header {{
    display: flex; justify-content: space-between; align-items: baseline;
    padding: 18px 24px; border-bottom: 1px solid var(--line); background: var(--surface);
  }}
  header h1 {{ margin: 0; font-size: 15px; font-weight: 600; letter-spacing: 0.16em; }}
  header .sub {{ color: var(--muted); font-size: 12px; }}
  main {{ padding: 20px 24px 48px; max-width: 1180px; margin: 0 auto; }}
  .tiles {{
    display: grid; gap: 12px; margin-bottom: 20px;
    grid-template-columns: repeat(auto-fit, minmax(176px, 1fr));
  }}
  .tile {{
    background: var(--surface); border: 1px solid var(--line); border-radius: 6px;
    padding: 14px 16px 10px;
  }}
  .tile-head {{ display: flex; justify-content: space-between; align-items: center; }}
  .tile-label {{ color: var(--text-2); font-size: 11px; letter-spacing: 0.13em;
                 text-transform: uppercase; }}
  .status {{ font-size: 10px; border: 1px solid; border-radius: 3px; padding: 0 5px; }}
  .tile-value {{ font-size: 30px; font-weight: 600; margin: 6px 0 2px;
                 font-variant-numeric: tabular-nums; }}
  .tile-unit {{ font-size: 13px; color: var(--text-2); margin-left: 6px; font-weight: 400; }}
  .tile-meta {{ color: var(--muted); font-size: 11px; }}
  .spark {{ width: 100%; height: 44px; margin-top: 8px; display: block; }}
  .hero {{
    background: var(--surface); border: 1px solid var(--line); border-left: 3px solid
    {PALETTE['power']}; border-radius: 6px; padding: 20px 22px; margin-bottom: 12px;
  }}
  .hero-label, .panel-head, .why-head {{
    color: var(--text-2); font-size: 11px; letter-spacing: 0.18em; margin-bottom: 8px;
  }}
  .hero-number {{ font-size: 46px; font-weight: 650; font-variant-numeric: tabular-nums; }}
  .hero-number.small {{ font-size: 32px; }}
  .hero-unit {{ font-size: 15px; color: var(--text-2); font-weight: 400; margin-left: 8px; }}
  .hero-sub {{ color: var(--text-2); margin-top: 6px; font-size: 13px; }}
  .hero-meta {{ color: var(--muted); margin-top: 4px; font-size: 11px; }}
  .detail-grid {{
    display: grid; gap: 8px 24px; grid-template-columns: repeat(auto-fit, minmax(236px, 1fr));
  }}
  .detail-grid > div {{ display: flex; justify-content: space-between; gap: 16px;
    border-bottom: 1px dotted var(--line); padding: 4px 0; }}
  .k {{ color: var(--text-2); }}
  .v {{ font-variant-numeric: tabular-nums; }}
  .panel, .why {{
    background: var(--surface); border: 1px solid var(--line); border-radius: 6px;
    padding: 16px 20px; margin-bottom: 12px;
  }}
  .bars {{ display: grid; gap: 6px; }}
  .bar-row {{ display: grid; grid-template-columns: 130px 1fr 82px; align-items: center;
              gap: 10px; }}
  .bar-label {{ color: var(--text-2); font-size: 12px; }}
  .bar-track {{ position: relative; height: 14px; background: var(--raised);
                border-radius: 3px; }}
  .bar-zero {{ position: absolute; left: 50%; top: -2px; bottom: -2px; width: 1px;
               background: var(--line); }}
  .bar-fill {{ position: absolute; top: 0; bottom: 0; border-radius: 3px; }}
  .bar-value {{ text-align: right; font-variant-numeric: tabular-nums; font-size: 12px; }}
  .axis-note, .reason {{ color: var(--muted); font-size: 12px; margin: 10px 0 0; }}
  .reason {{ color: var(--text-2); line-height: 1.6; }}
  .alt-table {{ width: 100%; border-collapse: collapse; font-size: 12px; }}
  .alt-table th {{ text-align: left; color: var(--text-2); font-weight: 500;
                   border-bottom: 1px solid var(--line); padding: 6px 8px 6px 0; }}
  .alt-table td {{ padding: 5px 8px 5px 0; border-bottom: 1px dotted var(--line); }}
  .alt-table .num {{ text-align: right; font-variant-numeric: tabular-nums; }}
  .empty {{ color: var(--muted); font-size: 12px; }}
  footer {{ color: var(--muted); font-size: 11px; padding: 0 24px 32px;
            max-width: 1180px; margin: 0 auto; }}
</style>
</head>
<body>
<header>
  <h1>BATTERYOPT</h1>
  <div class="sub">{_e(battery_label)} &middot; {_e(snapshot.battery.get('chemistry', ''))}
    &middot; {_e(snapshot.battery.get('nominal_energy_kwh', ''))} kWh nameplate</div>
</header>
<main>
  <div class="tiles">{''.join(tiles)}</div>
  {recommended}
  {life_html}
  <div class="panel">
    <div class="panel-head">POWER CAPABILITY</div>
    {_limits_panel(snapshot)}
  </div>
  {health_html}
</main>
<footer>
  Values are tagged with their provenance. Simulated and optimised figures are model
  outputs, not measurements, and must not be presented as evidence of physical
  performance. BatteryOpt advises; it does not replace independent BMS protection.
</footer>
</body>
</html>"""


def render_error(message: str) -> str:
    """A minimal error page in the same visual language."""
    return f"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<title>BatteryOpt</title><style>
body{{background:{PALETTE['page']};color:{PALETTE['text']};
font:14px ui-monospace,Menlo,monospace;padding:48px}}
.msg{{border-left:3px solid {PALETTE['critical']};padding:12px 18px;
background:{PALETTE['surface']}}}</style></head>
<body><h1 style="font-size:15px;letter-spacing:.16em">BATTERYOPT</h1>
<div class="msg">{_e(message)}</div></body></html>"""


__all__ = ["render_dashboard", "render_error", "PALETTE"]
