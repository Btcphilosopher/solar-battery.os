"""Candidate strategy generators.

The scenario engine compares whatever it is given; this module decides what it
is given. Generators come in three families:

* **Archetypes** -- FAST, NORMAL, ECO, HOLD and so on. Named strategies that
  correspond to how operators actually talk about the choice, and which give
  the comparison table its readable rows.
* **Sweeps** -- a grid across the feasible power interval, which is what a
  brute-force optimiser searches and what a Pareto front is drawn from.
* **Shaped profiles** -- charging profiles that vary over the horizon
  (constant-current/constant-voltage, tapered, preconditioned), because the
  best charging strategy is rarely a constant power.

Every generator returns candidates already clipped to the feasible power
interval, so an infeasible candidate in the results means the *trajectory*
went out of bounds, not that the first step did.
"""

from __future__ import annotations

import numpy as np

from ..core.numerics import EPS, clamp
from ..optimisation.problem import OptimisationProblem
from .engine import Scenario


def _bounds(problem: OptimisationProblem, include_soft: bool = False):
    return problem.constraints.bounds(
        problem.state, problem.dt_s, include_soft=include_soft
    )



def charge_storage_fraction(
    problem: OptimisationProblem, *, power_w: float, soc: float, temperature_c: float
) -> float:
    """Fraction of terminal charge energy that actually reaches the store.

    On charge the terminal voltage sits *above* the open-circuit voltage by the
    ohmic and diffusion drop, so terminal energy exceeds stored energy by the
    ratio ``V/OCV``. Integrating a candidate profile as though every terminal
    watt-hour lands in the store makes the shaped strategies believe they hit
    the target several steps before they do -- and the scenario engine, which
    simulates them properly, then reports a plan that misses. Reading the
    fraction off the model costs one equivalent-circuit evaluation.
    """
    battery = problem.constraints.battery
    if abs(power_w) <= EPS:
        return 1.0
    try:
        current = battery.electrical.current_for_power(
            -abs(power_w), soc=soc, temperature_c=temperature_c
        )
        response = battery.electrical.evaluate(
            current_a=current, soc=soc, temperature_c=temperature_c
        )
        if response.voltage_v <= EPS or response.ocv_v <= EPS:
            return 0.93
        return float(clamp(response.ocv_v / response.voltage_v, 0.5, 1.0))
    except Exception:  # noqa: BLE001 - a failed probe must not break candidate generation
        return 0.93


def constant_power(
    problem: OptimisationProblem,
    power_w: float,
    *,
    label: str,
    cooling: float = 0.0,
    description: str = "",
    tags: tuple[str, ...] = (),
) -> Scenario:
    """A single constant terminal power held across the horizon."""
    n = problem.n_steps
    bounds = _bounds(problem)
    p, _ = bounds.clamp(power_w)
    return Scenario(
        label=label,
        power_w=(float(p),) * n,
        cooling=(clamp(cooling, 0.0, 1.0),) * n,
        description=description,
        tags=tags,
    )


def power_sweep(
    problem: OptimisationProblem,
    *,
    n: int = 21,
    cooling: float = 0.0,
    include_soft_bounds: bool = False,
) -> list[Scenario]:
    """A uniform grid of constant powers across the feasible interval."""
    bounds = _bounds(problem, include_soft_bounds)
    if bounds.width_w <= EPS:
        return [constant_power(problem, 0.0, label="rest", cooling=cooling, tags=("rest",))]
    grid = np.linspace(bounds.min_power_w, bounds.max_power_w, n)
    out: list[Scenario] = []
    for p in grid:
        kw = p / 1000.0
        mode = "charge" if p < 0 else ("discharge" if p > 0 else "rest")
        out.append(
            constant_power(
                problem,
                float(p),
                label=f"{mode} {abs(kw):.1f} kW",
                cooling=cooling,
                description=f"Constant {abs(kw):.2f} kW {mode} for the whole horizon.",
                tags=("sweep", mode),
            )
        )
    return out


def archetypes(problem: OptimisationProblem) -> list[Scenario]:
    """The named strategies used in the specification's comparison examples."""
    bounds = _bounds(problem)
    demand = problem.demand_profile()
    demand_peak = float(np.max(demand)) if demand.size else 0.0
    out: list[Scenario] = []

    def add(label: str, power: float, cooling: float, description: str, *tags: str) -> None:
        out.append(
            constant_power(
                problem, power, label=label, cooling=cooling, description=description, tags=tags
            )
        )

    add("HOLD", 0.0, 0.0, "Rest: no power exchange, passive cooling only.", "hold")
    if demand_peak > 0.0:
        add(
            "FOLLOW DEMAND",
            demand_peak,
            0.35,
            "Serve the load exactly as requested.",
            "follow",
        )
    add(
        "FAST",
        bounds.max_power_w,
        1.0,
        "Maximum admissible discharge with full cooling.",
        "fast",
        "discharge",
    )
    add(
        "NORMAL",
        0.6 * bounds.max_power_w,
        0.4,
        "Moderate discharge with partial cooling.",
        "normal",
        "discharge",
    )
    add(
        "ECO",
        0.3 * bounds.max_power_w,
        0.1,
        "Gentle discharge: lowest loss and degradation per kWh.",
        "eco",
        "discharge",
    )
    add(
        "FAST CHARGE",
        bounds.min_power_w,
        1.0,
        "Maximum admissible charge with full cooling.",
        "fast",
        "charge",
    )
    add(
        "NORMAL CHARGE",
        0.6 * bounds.min_power_w,
        0.4,
        "Moderate charge.",
        "normal",
        "charge",
    )
    add(
        "ECO CHARGE",
        0.3 * bounds.min_power_w,
        0.1,
        "Gentle charge: minimum plating risk and degradation.",
        "eco",
        "charge",
    )
    return out


def cooling_sweep(
    problem: OptimisationProblem, power_w: float, *, fractions: tuple[float, ...] = (0.0, 0.25, 0.45, 0.7, 1.0)
) -> list[Scenario]:
    """Hold the power fixed and vary cooling -- the section 9 trade-off."""
    return [
        constant_power(
            problem,
            power_w,
            label=f"cooling {f * 100:.0f}%",
            cooling=f,
            description=(
                f"Constant {power_w / 1000.0:.1f} kW with cooling at {f * 100:.0f} % effort."
            ),
            tags=("cooling", f"{f:.2f}"),
        )
        for f in fractions
    ]


def tapered_charge(
    problem: OptimisationProblem,
    *,
    peak_power_w: float | None = None,
    taper_start_soc: float = 0.7,
    label: str = "TAPERED CHARGE",
    cooling: float = 0.6,
) -> Scenario:
    """A constant-current/constant-voltage-style charge profile.

    Real chargers do not hold constant power to 100 %: they taper once the
    cells approach their voltage limit. Modelling that explicitly matters,
    because a candidate that assumes constant power to full will always look
    faster than it can actually be.
    """
    n = problem.n_steps
    bounds = _bounds(problem)
    peak = peak_power_w if peak_power_w is not None else bounds.min_power_w
    battery = problem.constraints.battery
    soc = problem.state.soc
    capacity_wh = max(battery.energy_wh, EPS)

    powers: list[float] = []
    for _ in range(n):
        if soc <= taper_start_soc:
            p = peak
        else:
            # Linear taper to 8 % of peak at the SOC ceiling, which
            # approximates the constant-voltage tail closely enough for
            # planning without solving the full CV problem every step.
            span = max(battery.envelope.soc_max - taper_start_soc, EPS)
            frac = clamp(1.0 - (soc - taper_start_soc) / span, 0.08, 1.0)
            p = peak * frac
        p, _ = bounds.clamp(p)
        powers.append(float(p))
        eta = charge_storage_fraction(
            problem, power_w=p, soc=soc, temperature_c=problem.state.temperature_c
        )
        soc = clamp(soc + abs(p) * eta * problem.dt_s / 3600.0 / capacity_wh, 0.0, 1.0)

    return Scenario(
        label=label,
        power_w=tuple(powers),
        cooling=(clamp(cooling, 0.0, 1.0),) * n,
        description="Constant power to the taper point, then a linear taper to the ceiling.",
        tags=("charge", "tapered"),
    )


def preconditioned_charge(
    problem: OptimisationProblem,
    *,
    precondition_steps: int | None = None,
    target_c: float | None = None,
    target_soc: float | None = None,
    taper_start_soc: float = 0.7,
    label: str = "PRECONDITION THEN CHARGE",
) -> Scenario:
    """Warm the pack first, then charge -- the correct cold-weather strategy.

    Charging a cold cell plates lithium metal on the anode: permanent, and
    disproportionately damaging. Spending a few minutes and a few hundred watt-
    hours on the heater first is very often the cheaper path, and the optimiser
    can only discover that if the option is on the table.
    """
    n = problem.n_steps
    bounds = _bounds(problem)
    battery = problem.constraints.battery
    target = target_c if target_c is not None else battery.thermal_limits.t_min_charge_c + 8.0
    if precondition_steps is None:
        deficit = max(0.0, target - problem.state.temperature_c)
        thermal = battery.thermal
        heat_w = max(thermal.heater_heat(1.0), EPS)
        seconds = deficit * thermal.heat_capacity_j_k / heat_w
        precondition_steps = int(min(n - 1, max(0, round(seconds / problem.dt_s))))

    # The charge power must be taken from the bounds at the *warmed* state, not
    # the present one. Evaluated cold, the charge bound is exactly zero -- the
    # low-temperature charge constraint is binding -- so a scenario built from
    # it would dutifully heat the pack and then charge at 0 kW, which is the
    # one outcome preconditioning is supposed to avoid.
    from dataclasses import replace as _replace

    warmed = _replace(problem.state, temperature_c=max(problem.state.temperature_c, target))
    warm_bounds = problem.constraints.bounds(warmed, problem.dt_s)

    # The charge phase is tapered and it stops at the target. Holding the warm
    # maximum flat to the end of the horizon fails twice over: it over-volts as
    # the cells approach their limit -- there is a constant-voltage tail whether
    # the plan acknowledges it or not -- and it overshoots to 100 %. Either one
    # gets the scenario rejected as a hard violation, which would take the only
    # sensible cold-weather strategy off the table for entirely the wrong reason.
    peak = warm_bounds.min_power_w
    ceiling = target_soc if target_soc is not None else battery.envelope.soc_max
    taper_start = max(0.0, min(taper_start_soc, ceiling - 0.02))
    capacity_wh = max(battery.energy_wh, EPS)
    soc = problem.state.soc

    powers: list[float] = []
    heating: list[float] = []
    cooling: list[float] = []
    charge_steps = 0
    for k in range(n):
        if k < precondition_steps:
            powers.append(0.0)
            heating.append(1.0)
            cooling.append(0.0)
            continue
        if soc >= ceiling - 1e-4:
            # Target reached: hold, rather than continuing to push.
            powers.append(0.0)
            heating.append(0.0)
            cooling.append(0.0)
            continue
        if soc <= taper_start:
            p = peak
        else:
            span = max(ceiling - taper_start, EPS)
            frac = clamp(1.0 - (soc - taper_start) / span, 0.08, 1.0)
            p = peak * frac
        p, _ = warm_bounds.clamp(p)
        powers.append(float(p))
        heating.append(0.0)
        cooling.append(0.2)
        charge_steps += 1
        eta = charge_storage_fraction(problem, power_w=p, soc=soc, temperature_c=target)
        soc = clamp(soc + abs(p) * eta * problem.dt_s / 3600.0 / capacity_wh, 0.0, 1.0)

    return Scenario(
        label=label,
        power_w=tuple(powers),
        cooling=tuple(cooling),
        heating=tuple(heating),
        description=(
            f"Heat the pack to about {target:.0f} degC over {precondition_steps} steps, "
            f"then charge with a taper to {ceiling * 100:.0f} % over {charge_steps} steps."
        ),
        tags=("charge", "precondition"),
        meta={
            "precondition_steps": precondition_steps,
            "charge_steps": charge_steps,
            "target_c": target,
            "target_soc": ceiling,
        },
    )


def default_candidates(problem: OptimisationProblem, *, sweep: int = 15) -> list[Scenario]:
    """The standard candidate set: archetypes, a sweep and shaped profiles."""
    out = archetypes(problem)
    out.extend(power_sweep(problem, n=sweep, cooling=0.3))
    out.append(tapered_charge(problem))
    if problem.state.temperature_c < problem.constraints.battery.thermal_limits.t_min_charge_c + 10.0:
        out.append(preconditioned_charge(problem))
    return out


__all__ = [
    "charge_storage_fraction",
    "constant_power",
    "power_sweep",
    "archetypes",
    "cooling_sweep",
    "tapered_charge",
    "preconditioned_charge",
    "default_candidates",
]
