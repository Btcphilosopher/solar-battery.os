"""The scenario engine (specification section 15).

.. code-block:: text

    CURRENT STATE
          |
     +----+----+----+
     v    v    v    v
    FAST NORMAL ECO ...
     |    |    |    |
        SIMULATE
     |    |    |    |
        COMPARE
     +----+----+----+
          |
      BEST STRATEGY

The engine's job is to make candidate strategies *comparable*. Each candidate
is a complete action sequence over the horizon; each is simulated through the
same plant; each is reduced to the same :class:`~batteryopt.optimisation.objective.Outcome`
record; each is scored by the same objective. Nothing about a candidate's
provenance -- whether it came from a heuristic, a sweep or a solver -- gives it
any advantage in the comparison.

Two things this engine does that a naive implementation would not:

* **Shortfall is computed against the demand, not assumed.** A candidate that
  cannot serve a firm load accrues an explicit energy shortfall, which the
  objective prices. Without this, "discharge less" always looks better.
* **Infeasible candidates are kept and marked, not silently dropped.** Knowing
  that the fast option was rejected because it would have breached a voltage
  limit is more useful than never seeing it.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Sequence

import numpy as np

from ..core.numerics import EPS
from ..core.units import SECONDS_PER_HOUR
from ..models.battery import Battery
from ..models.plant import Action, BatteryPlant, Trajectory
from ..optimisation.constraints import ConstraintKind, Violation
from ..optimisation.objective import ObjectiveValue, Outcome
from ..optimisation.problem import OptimisationProblem


@dataclass(frozen=True, slots=True)
class Scenario:
    """One complete candidate strategy over the planning horizon."""

    label: str
    #: Terminal power per step, W, positive = discharge.
    power_w: tuple[float, ...]
    #: Cooling command per step, 0-1.
    cooling: tuple[float, ...] = ()
    #: Heating command per step, 0-1.
    heating: tuple[float, ...] = ()
    #: Balancing current per step, A.
    balancing_a: tuple[float, ...] = ()
    description: str = ""
    #: Free-form tags used by the presentation layer ("fast", "eco", ...).
    tags: tuple[str, ...] = ()
    meta: dict[str, Any] = field(default_factory=dict)

    def __len__(self) -> int:
        return len(self.power_w)

    def actions(self) -> list[Action]:
        n = len(self.power_w)
        cool = self.cooling or (0.0,) * n
        heat = self.heating or (0.0,) * n
        bal = self.balancing_a or (0.0,) * n
        return [
            Action(
                power_w=p,
                cooling_fraction=c,
                heating_fraction=h,
                balancing_current_a=b,
            )
            for p, c, h, b in zip(self.power_w, cool, heat, bal)
        ]

    @property
    def first_power_w(self) -> float:
        return self.power_w[0] if self.power_w else 0.0

    @property
    def first_cooling(self) -> float:
        return self.cooling[0] if self.cooling else 0.0

    def as_dict(self) -> dict[str, Any]:
        return {
            "label": self.label,
            "description": self.description,
            "tags": list(self.tags),
            "first_power_w": self.first_power_w,
            "first_cooling": self.first_cooling,
            "steps": len(self.power_w),
        }


@dataclass(slots=True)
class ScenarioResult:
    """A simulated, scored candidate."""

    scenario: Scenario
    trajectory: Trajectory
    outcome: Outcome
    value: ObjectiveValue
    hard_violations: list[Violation] = field(default_factory=list)
    soft_violations: list[Violation] = field(default_factory=list)
    simulate_seconds: float = 0.0

    @property
    def feasible(self) -> bool:
        return not self.hard_violations

    @property
    def score(self) -> float:
        """Objective score; infeasible candidates score minus infinity."""
        return self.value.total if self.feasible else float("-inf")

    def as_dict(self) -> dict[str, Any]:
        return {
            "scenario": self.scenario.as_dict(),
            "outcome": self.outcome.as_dict(),
            "score": self.score,
            "feasible": self.feasible,
            "objective": self.value.as_dict(),
            "hard_violations": [v.as_dict() for v in self.hard_violations],
            "soft_violations": [v.as_dict() for v in self.soft_violations],
        }

    def summary(self) -> str:
        flag = "" if self.feasible else "  INFEASIBLE"
        return (
            f"{self.scenario.label:<22} "
            f"{self.outcome.energy_discharged_wh / 1000.0:7.2f} kWh out  "
            f"eff {self.outcome.mean_efficiency * 100:5.2f}%  "
            f"fade {self.outcome.capacity_fade * 100:.5f}%  "
            f"peak {self.outcome.peak_temperature_c:5.1f} degC  "
            f"score {self.score:+9.3f}{flag}"
        )


class ScenarioEngine:
    """Simulates and compares candidate strategies against one problem."""

    __slots__ = ("battery", "plant")

    def __init__(self, battery: Battery, plant: BatteryPlant | None = None) -> None:
        self.battery = battery
        self.plant = plant or BatteryPlant(battery)

    # -- evaluation ---------------------------------------------------------

    def simulate(self, problem: OptimisationProblem, scenario: Scenario) -> Trajectory:
        n = len(scenario)
        ambient = problem.ambient_profile()
        if ambient.size != n:
            ambient = np.resize(ambient, n)
        return self.plant.simulate(
            problem.state.as_simulated(),
            scenario.actions(),
            problem.dt_s,
            ambient_c=ambient,
        )

    def to_outcome(
        self, problem: OptimisationProblem, scenario: Scenario, trajectory: Trajectory
    ) -> Outcome:
        """Reduce a simulated trajectory to the record the objective consumes."""
        metrics = trajectory.metrics()
        delivered = np.clip(trajectory.power_w[1:], 0.0, None)
        # A scenario may be *shorter* than the problem it is evaluated against --
        # the held-action safety check deliberately builds one over just the
        # commitment window. Align the profiles to what was actually simulated
        # rather than assuming they match, or the shapes disagree and the check
        # that exists to catch unsafe plans is the thing that crashes.
        steps = int(delivered.size)
        demand = problem.demand_profile()[:steps]
        solar = problem.solar_profile()[:steps]

        # Net load the battery is expected to cover, after any local generation.
        net_demand = np.clip(demand - solar, 0.0, None)
        shortfall_w = np.clip(net_demand - delivered, 0.0, None)
        firm = problem.demand.firm if problem.demand is not None else False
        shortfall_wh = (
            float(np.sum(shortfall_w) * problem.dt_s / SECONDS_PER_HOUR) if firm else 0.0
        )

        nameplate = max(self.battery.nameplate_capacity_ah, EPS)
        throughput_ah = float(
            np.sum(np.abs(trajectory.current_a[1:])) * problem.dt_s / SECONDS_PER_HOUR
        )
        efc = throughput_ah / (2.0 * nameplate)

        final_state = trajectory.final_state
        residual_power = final_state.power_limit_discharge_w
        if residual_power <= 0.0:
            from ..estimation.sop import PowerCapabilityEstimator

            residual_power = PowerCapabilityEstimator(self.battery).estimate(
                final_state, horizon_s=max(problem.dt_s, 10.0)
            ).discharge_w

        return Outcome(
            energy_discharged_wh=float(metrics["energy_discharged_wh"]),
            energy_charged_wh=float(metrics["energy_charged_wh"]),
            net_energy_delivered_wh=float(metrics["net_energy_delivered_wh"]),
            losses_wh=float(metrics["losses_wh"]),
            auxiliary_wh=float(metrics["auxiliary_wh"]),
            capacity_fade=float(metrics["capacity_fade"]),
            resistance_growth=float(metrics["resistance_growth"]),
            peak_temperature_c=float(metrics["peak_temperature_c"]),
            mean_temperature_c=float(np.mean(trajectory.temperature_c)),
            duration_s=float(metrics["duration_s"]),
            start_soc=float(trajectory.soc[0]),
            end_soc=float(trajectory.soc[-1]),
            equivalent_full_cycles=efc,
            shortfall_wh=shortfall_wh,
            mean_efficiency=float(metrics["mean_efficiency"]),
            residual_power_capability_w=residual_power,
            curtailed=bool(metrics["curtailed"]),
            limiting_constraint=metrics["limiting_constraint"],  # type: ignore[arg-type]
            label=scenario.label,
            meta={"tags": list(scenario.tags)},
        )

    def evaluate(self, problem: OptimisationProblem, scenario: Scenario) -> ScenarioResult:
        """Simulate, check and score one candidate."""
        started = time.perf_counter()
        trajectory = self.simulate(problem, scenario)
        outcome = self.to_outcome(problem, scenario, trajectory)
        value = problem.objective.evaluate(
            outcome,
            start_time_s=problem.state.timestamp,
            future_energy_value_per_kwh=problem.terminal_energy_value_per_kwh,
        )
        violations = problem.constraints.check_trajectory(trajectory.states)
        return ScenarioResult(
            scenario=scenario,
            trajectory=trajectory,
            outcome=outcome,
            value=value,
            hard_violations=[v for v in violations if v.constraint.kind is ConstraintKind.HARD],
            soft_violations=[v for v in violations if v.constraint.kind is ConstraintKind.SOFT],
            simulate_seconds=time.perf_counter() - started,
        )

    def compare(
        self, problem: OptimisationProblem, scenarios: Sequence[Scenario]
    ) -> list[ScenarioResult]:
        """Evaluate every candidate and return them best-first.

        Infeasible candidates are retained at the end of the list with their
        violations attached, because "why was the fast option rejected?" is a
        question operators ask constantly.
        """
        results = [self.evaluate(problem, s) for s in scenarios]
        results.sort(key=lambda r: (r.feasible, r.score), reverse=True)
        return results

    def best(
        self, problem: OptimisationProblem, scenarios: Sequence[Scenario]
    ) -> ScenarioResult | None:
        ranked = self.compare(problem, scenarios)
        return next((r for r in ranked if r.feasible), None)

    # -- reporting ----------------------------------------------------------

    @staticmethod
    def comparison_table(results: Sequence[ScenarioResult]) -> str:
        """Fixed-width comparison, in the style of the specification examples."""
        lines = [
            f"{'STRATEGY':<22} {'ENERGY':>11} {'EFFICIENCY':>11} {'DEGRADATION':>13} "
            f"{'PEAK T':>8} {'SCORE':>10}",
            "-" * 80,
        ]
        for r in results:
            flag = "" if r.feasible else "  <- infeasible"
            lines.append(
                f"{r.scenario.label:<22} "
                f"{r.outcome.energy_discharged_wh / 1000.0:8.2f} kWh "
                f"{r.outcome.mean_efficiency * 100:10.2f}% "
                f"{r.outcome.capacity_fade * 100:12.5f}% "
                f"{r.outcome.peak_temperature_c:7.1f}C "
                f"{r.score:+10.3f}{flag}"
            )
        return "\n".join(lines)


__all__ = ["Scenario", "ScenarioResult", "ScenarioEngine"]
