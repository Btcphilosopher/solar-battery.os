"""Domain forecasters: load, price, generation and temperature.

Each wraps the generic statistical machinery with the structure that is known
in advance for that signal. Encoding what is *known* -- that PV is zero at
night, that price has a daily and weekly shape, that ambient temperature is
bounded and smooth -- is worth more than any amount of model capacity, and it
is why these beat a generic learner on the horizons that matter.
"""

from __future__ import annotations

from typing import Any

import numpy as np

from ..core.numerics import EPS, clamp
from ..core.provenance import Quantiles
from ..core.units import SECONDS_PER_DAY, SECONDS_PER_HOUR
from .base import BaseForecaster, Forecast, ensemble
from .statistical import (
    ExponentialSmoothingForecaster,
    HarmonicRegressionForecaster,
    SeasonalNaiveForecaster,
    non_negative,
)


class LoadForecaster(BaseForecaster):
    """Site or vehicle load.

    Load is strongly daily-periodic with a weekday/weekend split, and it is
    non-negative. A harmonic regression blended with a seasonal-naive forecast
    captures both the shape and the recent level, and the blend is what stops
    the regression smoothing away a genuine step change.
    """

    name = "load"

    def __init__(self, *, weights: tuple[float, float] = (0.6, 0.4), **kw: Any) -> None:
        super().__init__(**kw)
        self._harmonic = HarmonicRegressionForecaster(daily_harmonics=4, weekly=True)
        self._seasonal = SeasonalNaiveForecaster(season_s=SECONDS_PER_DAY)
        self.weights = weights

    def fit(self, times_s: np.ndarray, values: np.ndarray) -> "LoadForecaster":
        super().fit(times_s, values)
        self._harmonic.fit(times_s, values)
        self._seasonal.fit(times_s, values)
        return self

    def predict(self, horizon_s: float, dt_s: float, *, origin_s: float = 0.0) -> Forecast:
        members = [
            self._harmonic.predict(horizon_s, dt_s, origin_s=origin_s),
            self._seasonal.predict(horizon_s, dt_s, origin_s=origin_s),
        ]
        combined = ensemble(members, self.weights)
        combined.unit = "W"
        combined.source = self.name
        return non_negative(combined)


class PriceForecaster(BaseForecaster):
    """Wholesale or retail electricity price.

    Price can legitimately go negative, so it is *not* clipped. It has a strong
    daily shape and a weaker weekly one, and it is heteroscedastic: evening
    peaks are far more volatile than overnight troughs. The band therefore
    scales with the local level of the daily shape rather than being uniform,
    which is what makes a P90 evening price meaningfully wider than a P90
    overnight one.
    """

    name = "price"

    def __init__(self, **kw: Any) -> None:
        super().__init__(prior_relative_width=0.4, **kw)
        self._harmonic = HarmonicRegressionForecaster(daily_harmonics=5, weekly=True)

    def fit(self, times_s: np.ndarray, values: np.ndarray) -> "PriceForecaster":
        super().fit(times_s, values)
        self._harmonic.fit(times_s, values)
        return self

    def predict(self, horizon_s: float, dt_s: float, *, origin_s: float = 0.0) -> Forecast:
        base = self._harmonic.predict(horizon_s, dt_s, origin_s=origin_s)
        # Heteroscedastic widening: volatility tracks the level of the signal.
        level = np.abs(base.p50)
        scale = level / max(float(np.mean(level)), EPS)
        centre = base.p50
        return Forecast(
            times_s=base.times_s,
            p50=centre,
            p10=centre - (centre - base.p10) * scale,
            p90=centre + (base.p90 - centre) * scale,
            unit="currency/kWh",
            source=self.name,
            uncertainty_method=base.uncertainty_method + "+heteroscedastic",
            meta=dict(base.meta),
        )

    def to_price_curve(self, forecast: Forecast, *, currency: str = "GBP"):
        """Convert a forecast into a :class:`~batteryopt.economics.prices.PriceCurve`."""
        from ..economics.prices import PriceCurve

        return PriceCurve(
            times_s=forecast.times_s,
            prices=forecast.p50,
            currency=currency,
            name=f"forecast:{forecast.source}",
        )


class SolarForecaster(BaseForecaster):
    """Photovoltaic generation.

    Two pieces of physics do most of the work and neither needs to be learned:
    generation is zero outside daylight, and the clear-sky envelope is a known
    function of the time of day. What is left to forecast is the *clear-sky
    index* -- the fraction of the envelope actually achieved -- which is much
    better behaved than the raw signal and is what this forecaster models.

    Uncertainty is deliberately asymmetric. Generation can fall far below the
    forecast when cloud arrives, but cannot exceed the clear-sky envelope, so a
    symmetric band would be wrong in both directions at once.
    """

    name = "solar"

    def __init__(
        self,
        *,
        capacity_w: float,
        sunrise_hour: float = 6.0,
        sunset_hour: float = 18.0,
        **kw: Any,
    ) -> None:
        super().__init__(prior_relative_width=0.5, **kw)
        self.capacity_w = capacity_w
        self.sunrise_hour = sunrise_hour
        self.sunset_hour = sunset_hour
        self._index = ExponentialSmoothingForecaster(alpha=0.25, beta=0.02, phi=0.8)

    def clear_sky(self, t_s: float | np.ndarray) -> np.ndarray:
        """Clear-sky generation envelope, W."""
        hod = np.asarray(t_s, dtype=float) / SECONDS_PER_HOUR % 24.0
        day = self.sunset_hour - self.sunrise_hour
        phase = np.clip((hod - self.sunrise_hour) / max(day, EPS), 0.0, 1.0)
        shape = np.where((hod >= self.sunrise_hour) & (hod <= self.sunset_hour),
                         np.sin(np.pi * phase) ** 1.3, 0.0)
        return self.capacity_w * shape

    def fit(self, times_s: np.ndarray, values: np.ndarray) -> "SolarForecaster":
        super().fit(times_s, values)
        envelope = self.clear_sky(times_s)
        mask = envelope > 0.02 * self.capacity_w
        if np.any(mask):
            index = np.asarray(values, dtype=float)[mask] / envelope[mask]
            self._index.fit(np.asarray(times_s, dtype=float)[mask], np.clip(index, 0.0, 1.2))
        return self

    def predict(self, horizon_s: float, dt_s: float, *, origin_s: float = 0.0) -> Forecast:
        n = max(1, int(round(horizon_s / dt_s)))
        grid = origin_s + np.arange(n + 1) * dt_s
        envelope = self.clear_sky(grid)
        if self._index.has_history:
            index_forecast = self._index.predict(horizon_s, dt_s, origin_s=origin_s)
            index = np.clip(index_forecast.p50, 0.0, 1.0)
            index_lo = np.clip(index_forecast.p10, 0.0, 1.0)
        else:
            index = np.full_like(envelope, 0.7)
            index_lo = np.full_like(envelope, 0.25)
        median = envelope * index
        return Forecast(
            times_s=grid,
            p50=median,
            # Cloud can take generation to near zero; nothing can push it above
            # the clear-sky envelope. The band reflects that asymmetry.
            p10=envelope * np.minimum(index_lo, index) * 0.4,
            p90=np.minimum(envelope * np.minimum(1.0, index * 1.25 + 0.1), envelope),
            unit="W",
            source=self.name,
            uncertainty_method="clear-sky index, asymmetric",
            meta={"capacity_w": self.capacity_w},
        )


class TemperatureForecaster(BaseForecaster):
    """Ambient temperature: smooth, daily-periodic, slowly trending."""

    name = "temperature"

    def __init__(self, **kw: Any) -> None:
        super().__init__(prior_relative_width=0.12, **kw)
        self._harmonic = HarmonicRegressionForecaster(daily_harmonics=2, weekly=False)

    def fit(self, times_s: np.ndarray, values: np.ndarray) -> "TemperatureForecaster":
        super().fit(times_s, values)
        self._harmonic.fit(times_s, values)
        return self

    def predict(self, horizon_s: float, dt_s: float, *, origin_s: float = 0.0) -> Forecast:
        base = self._harmonic.predict(horizon_s, dt_s, origin_s=origin_s)
        base.unit = "degC"
        base.source = self.name
        return base


class MissionEnergyForecaster(BaseForecaster):
    """Energy a mission will consume, from history of similar missions.

    Learns consumption per unit of distance from past journeys and applies the
    ambient-temperature correction from
    :func:`~batteryopt.applications.mission.temperature_energy_factor`. The
    output is quantiles, because mission planning needs a reliability statement
    and a point estimate cannot provide one.
    """

    name = "mission_energy"

    def __init__(self, *, default_wh_per_km: float = 190.0, **kw: Any) -> None:
        super().__init__(**kw)
        #: Prior consumption, used before any history exists.
        self.default_wh_per_km = default_wh_per_km
        self._distances: list[float] = []
        self._energies: list[float] = []

    def observe_mission(self, *, distance_km: float, energy_wh: float, ambient_c: float = 20.0) -> None:
        """Record a completed mission, normalised to 20 degC."""
        from ..applications.mission import temperature_energy_factor

        if distance_km <= EPS:
            return
        normalised = energy_wh / max(temperature_energy_factor(ambient_c), EPS)
        self._distances.append(float(distance_km))
        self._energies.append(float(normalised))
        if len(self._distances) > self.history_limit:
            self._distances.pop(0)
            self._energies.pop(0)

    @property
    def wh_per_km(self) -> float:
        if not self._distances:
            return self.default_wh_per_km
        return float(np.sum(self._energies) / max(np.sum(self._distances), EPS))

    def estimate(self, *, distance_km: float, ambient_c: float = 20.0) -> Quantiles:
        """Quantiles of the energy a journey of this distance will take."""
        from ..applications.mission import temperature_energy_factor

        base = self.wh_per_km * distance_km
        if len(self._distances) >= 5:
            rates = np.asarray(self._energies) / np.asarray(self._distances)
            lo = float(np.quantile(rates, 0.10)) * distance_km
            hi = float(np.quantile(rates, 0.90)) * distance_km
        else:
            # Prior spread: journeys vary by roughly +/-15 % driver to driver.
            lo, hi = base * 0.85, base * 1.18
        factor = temperature_energy_factor(ambient_c)
        return Quantiles(lo * factor, base * factor, hi * factor)

    def predict(self, horizon_s: float, dt_s: float, *, origin_s: float = 0.0) -> Forecast:
        n = max(1, int(round(horizon_s / dt_s)))
        grid = origin_s + np.arange(n + 1) * dt_s
        value = self.wh_per_km
        return self._make(grid, np.full(n + 1, value), unit="Wh/km")


__all__ = [
    "LoadForecaster",
    "PriceForecaster",
    "SolarForecaster",
    "TemperatureForecaster",
    "MissionEnergyForecaster",
]
