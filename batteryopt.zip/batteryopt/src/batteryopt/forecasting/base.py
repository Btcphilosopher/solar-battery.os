"""Forecasting interfaces and uncertainty (specification sections 21 and 22).

Two rules shape this package, both taken directly from the specification:

* **The optimiser must remain functional without machine learning.** Every
  forecaster here is a statistical or physical method with no learned
  parameters. The optional torch backend in
  :mod:`batteryopt.forecasting.learned` is a *residual* model layered on top of
  one of these, never a replacement for it, so removing PyTorch degrades
  accuracy and nothing else.
* **Every important prediction carries uncertainty.** A forecast is a
  :class:`Forecast`, which is a P10/P50/P90 band over a time grid, not a line.
  Optimisation that matters -- mission reliability, reserve sizing -- consumes
  the band, because planning to the median means missing half the time.

Uncertainty is produced by the method that is honest for each forecaster:
residual quantiles from backtesting where history exists, and a documented
prior width where it does not. Which one was used is recorded on the forecast.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol, Sequence, runtime_checkable

import numpy as np

from ..core.numerics import EPS
from ..core.provenance import Provenance, Quantiles


@dataclass(slots=True)
class Forecast:
    """A predictive band over a time grid."""

    #: Seconds from the forecast origin.
    times_s: np.ndarray
    p50: np.ndarray
    p10: np.ndarray
    p90: np.ndarray
    unit: str = ""
    source: str = ""
    #: How the uncertainty was derived: ``"backtest"``, ``"prior"`` or
    #: ``"ensemble"``. Recorded so a consumer can tell a measured interval
    #: from an assumed one.
    uncertainty_method: str = "prior"
    provenance: Provenance = Provenance.PREDICTED
    meta: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        n = self.times_s.size
        if not (self.p50.size == self.p10.size == self.p90.size == n):
            raise ValueError("forecast arrays must all match the time grid")
        # Enforce ordering rather than trusting the producer: a crossed band is
        # a silent corruption that only shows up much later as a bad decision.
        lo = np.minimum(np.minimum(self.p10, self.p50), self.p90)
        hi = np.maximum(np.maximum(self.p10, self.p50), self.p90)
        mid = self.p10 + self.p50 + self.p90 - lo - hi
        self.p10, self.p50, self.p90 = lo, mid, hi

    def __len__(self) -> int:
        return int(self.times_s.size)

    def at(self, t_s: float | np.ndarray, *, quantile: str = "p50") -> np.ndarray:
        values = getattr(self, quantile)
        return np.interp(t_s, self.times_s, values)

    def quantiles_at(self, t_s: float) -> Quantiles:
        return Quantiles(
            float(self.at(t_s, quantile="p10")),
            float(self.at(t_s, quantile="p50")),
            float(self.at(t_s, quantile="p90")),
        )

    def total(self, *, quantile: str = "p50") -> float:
        """Integral over the horizon, in unit-hours (e.g. W -> Wh)."""
        values = getattr(self, quantile)
        if values.size < 2:
            return float(values.sum())
        return float(np.trapezoid(values, self.times_s) / 3600.0)

    @property
    def horizon_s(self) -> float:
        return float(self.times_s[-1] - self.times_s[0]) if self.times_s.size > 1 else 0.0

    @property
    def mean_relative_width(self) -> float:
        """Mean band width relative to the median: a one-number sharpness score."""
        denom = np.maximum(np.abs(self.p50), EPS)
        return float(np.mean((self.p90 - self.p10) / denom))

    def scaled(self, factor: float) -> "Forecast":
        return Forecast(
            times_s=self.times_s,
            p50=self.p50 * factor,
            p10=self.p10 * factor,
            p90=self.p90 * factor,
            unit=self.unit,
            source=self.source,
            uncertainty_method=self.uncertainty_method,
            provenance=self.provenance,
            meta=dict(self.meta),
        )

    def as_dict(self) -> dict[str, Any]:
        return {
            "times_s": self.times_s.tolist(),
            "p10": self.p10.tolist(),
            "p50": self.p50.tolist(),
            "p90": self.p90.tolist(),
            "unit": self.unit,
            "source": self.source,
            "uncertainty_method": self.uncertainty_method,
            "provenance": self.provenance.value,
            "mean_relative_width": self.mean_relative_width,
        }


@runtime_checkable
class Forecaster(Protocol):
    """Anything that can produce a :class:`Forecast`."""

    name: str

    def fit(self, times_s: np.ndarray, values: np.ndarray) -> "Forecaster":
        """Absorb history. Must be safe to call repeatedly."""
        ...

    def predict(self, horizon_s: float, dt_s: float, *, origin_s: float = 0.0) -> Forecast:
        """Forecast forward from ``origin_s``."""
        ...


class BaseForecaster:
    """Shared machinery: history buffer, backtest residuals, band construction."""

    name = "base"

    def __init__(self, *, history_limit: int = 20_000, prior_relative_width: float = 0.25) -> None:
        self._times: list[float] = []
        self._values: list[float] = []
        self.history_limit = history_limit
        #: Band width used before any residuals are available, as a fraction of
        #: the median. Deliberately wide: an unbacktested forecast should look
        #: uncertain, because it is.
        self.prior_relative_width = prior_relative_width
        self._residual_quantiles: tuple[float, float] | None = None

    # -- history ------------------------------------------------------------

    def fit(self, times_s: np.ndarray, values: np.ndarray) -> "BaseForecaster":
        t = np.asarray(times_s, dtype=float).ravel()
        v = np.asarray(values, dtype=float).ravel()
        if t.size != v.size:
            raise ValueError("forecaster history times and values must match")
        self._times.extend(t.tolist())
        self._values.extend(v.tolist())
        if len(self._times) > self.history_limit:
            excess = len(self._times) - self.history_limit
            del self._times[:excess]
            del self._values[:excess]
        self._update_residuals()
        return self

    def observe(self, t_s: float, value: float) -> None:
        """Append a single observation, for streaming use."""
        self._times.append(float(t_s))
        self._values.append(float(value))
        if len(self._times) > self.history_limit:
            self._times.pop(0)
            self._values.pop(0)

    @property
    def history(self) -> tuple[np.ndarray, np.ndarray]:
        return np.asarray(self._times, dtype=float), np.asarray(self._values, dtype=float)

    @property
    def has_history(self) -> bool:
        return len(self._values) >= 4

    # -- uncertainty --------------------------------------------------------

    def _update_residuals(self) -> None:
        """Estimate residual quantiles by one-step-ahead backtesting.

        Uses the forecaster's own point method against its own history, which
        is the only way to get an interval that reflects *this* model's error
        rather than an assumed distribution.
        """
        t, v = self.history
        if t.size < 12:
            self._residual_quantiles = None
            return
        try:
            predictions = self._backtest(t, v)
        except NotImplementedError:  # pragma: no cover - subclass opt-out
            self._residual_quantiles = None
            return
        residuals = v[-predictions.size :] - predictions
        if residuals.size < 8:
            self._residual_quantiles = None
            return
        self._residual_quantiles = (
            float(np.quantile(residuals, 0.10)),
            float(np.quantile(residuals, 0.90)),
        )

    def _backtest(self, times: np.ndarray, values: np.ndarray) -> np.ndarray:
        """One-step-ahead in-sample predictions. Subclasses may override."""
        raise NotImplementedError

    def _band(self, median: np.ndarray, *, horizon_s: np.ndarray) -> tuple[np.ndarray, np.ndarray, str]:
        """Build a P10/P90 band around a median forecast.

        The band widens with the square root of lead time. That is the correct
        scaling for a random walk and a reasonable default for everything else;
        a band that stays the same width twelve hours out is not a forecast
        interval, it is a decoration.
        """
        lead = np.sqrt(np.maximum(horizon_s, 0.0) / max(horizon_s[-1], 1.0) + 0.05)
        if self._residual_quantiles is not None:
            lo_res, hi_res = self._residual_quantiles
            return median + lo_res * lead, median + hi_res * lead, "backtest"
        width = self.prior_relative_width * np.abs(median) * lead
        return median - width, median + width, "prior"

    def _make(
        self,
        times_s: np.ndarray,
        median: np.ndarray,
        *,
        unit: str,
        meta: dict[str, Any] | None = None,
    ) -> Forecast:
        rel = times_s - times_s[0] if times_s.size else times_s
        p10, p90, method = self._band(median, horizon_s=rel)
        return Forecast(
            times_s=times_s,
            p50=median,
            p10=p10,
            p90=p90,
            unit=unit,
            source=self.name,
            uncertainty_method=method,
            meta=meta or {},
        )


def ensemble(forecasts: Sequence[Forecast], weights: Sequence[float] | None = None) -> Forecast:
    """Combine forecasts on a common grid, widening the band by their disagreement.

    Two forecasters that agree should produce a tighter band than either alone;
    two that disagree should produce a wider one. Averaging the medians while
    keeping the narrower band -- which is what naive ensembling does -- gets
    this exactly backwards.
    """
    if not forecasts:
        raise ValueError("cannot ensemble an empty list of forecasts")
    if len(forecasts) == 1:
        return forecasts[0]
    grid = forecasts[0].times_s
    w = np.asarray(weights if weights is not None else [1.0] * len(forecasts), dtype=float)
    w = w / max(w.sum(), EPS)

    medians = np.vstack([np.interp(grid, f.times_s, f.p50) for f in forecasts])
    lows = np.vstack([np.interp(grid, f.times_s, f.p10) for f in forecasts])
    highs = np.vstack([np.interp(grid, f.times_s, f.p90) for f in forecasts])

    p50 = np.sum(medians * w[:, None], axis=0)
    spread = np.sqrt(np.sum(w[:, None] * (medians - p50) ** 2, axis=0))
    p10 = np.sum(lows * w[:, None], axis=0) - spread
    p90 = np.sum(highs * w[:, None], axis=0) + spread
    return Forecast(
        times_s=grid,
        p50=p50,
        p10=p10,
        p90=p90,
        unit=forecasts[0].unit,
        source="ensemble(" + ",".join(f.source for f in forecasts) + ")",
        uncertainty_method="ensemble",
        meta={"members": [f.source for f in forecasts], "weights": w.tolist()},
    )


__all__ = ["Forecast", "Forecaster", "BaseForecaster", "ensemble"]
