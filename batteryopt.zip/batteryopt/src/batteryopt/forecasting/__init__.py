"""Forecasting with explicit uncertainty. Statistical by default, ML optional."""

from .base import BaseForecaster, Forecast, Forecaster, ensemble
from .domain import (
    LoadForecaster,
    MissionEnergyForecaster,
    PriceForecaster,
    SolarForecaster,
    TemperatureForecaster,
)
from .learned import ResidualLearner, torch_available
from .statistical import (
    ExponentialSmoothingForecaster,
    HarmonicRegressionForecaster,
    PersistenceForecaster,
    SeasonalNaiveForecaster,
    non_negative,
)

__all__ = [
    "Forecast",
    "Forecaster",
    "BaseForecaster",
    "ensemble",
    "PersistenceForecaster",
    "SeasonalNaiveForecaster",
    "ExponentialSmoothingForecaster",
    "HarmonicRegressionForecaster",
    "non_negative",
    "LoadForecaster",
    "PriceForecaster",
    "SolarForecaster",
    "TemperatureForecaster",
    "MissionEnergyForecaster",
    "ResidualLearner",
    "torch_available",
]
