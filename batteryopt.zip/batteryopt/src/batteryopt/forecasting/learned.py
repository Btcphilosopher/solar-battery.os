"""Optional learned residual forecasting.

Specification section 21 permits machine learning "only where it materially
improves prediction", and requires the optimiser to remain functional without
it. Both conditions are enforced structurally rather than by convention:

* The learned model predicts the **residual** of a statistical forecaster, not
  the signal. Without PyTorch the residual is simply zero and the statistical
  forecast stands, so removing the dependency changes accuracy and nothing
  else -- no code path, no interface, no fallback branch in the caller.
* :meth:`ResidualLearner.improves_on_baseline` backtests the combined forecast
  against the baseline and reports whether the learned component actually
  helped. A model that fails that check should not be deployed, and the method
  exists so that the question gets asked.

The network is deliberately small -- a two-layer MLP over lagged residuals and
calendar features. Battery-relevant signals have strong known structure, most
of which the statistical layer has already removed; what is left is a modest
amount of autocorrelation, and a large model would mostly learn to overfit it.
"""

from __future__ import annotations

from typing import Any

import numpy as np

from ..core.numerics import EPS
from ..core.optional import have, try_import
from ..core.units import SECONDS_PER_DAY
from .base import BaseForecaster, Forecast


def torch_available() -> bool:
    """True when PyTorch can be imported here."""
    return have("torch")


def calendar_features(times_s: np.ndarray) -> np.ndarray:
    """Sine/cosine encodings of time of day and day of week."""
    t = np.asarray(times_s, dtype=float)
    day = t / SECONDS_PER_DAY
    return np.column_stack(
        [
            np.sin(2 * np.pi * day),
            np.cos(2 * np.pi * day),
            np.sin(2 * np.pi * day / 7.0),
            np.cos(2 * np.pi * day / 7.0),
        ]
    )


class ResidualLearner:
    """Learns the residual of a baseline forecaster. A no-op without PyTorch."""

    def __init__(
        self,
        baseline: BaseForecaster,
        *,
        lags: int = 8,
        hidden: int = 32,
        epochs: int = 200,
        learning_rate: float = 5e-3,
        seed: int = 0,
    ) -> None:
        self.baseline = baseline
        self.lags = lags
        self.hidden = hidden
        self.epochs = epochs
        self.learning_rate = learning_rate
        self.seed = seed
        self._model: Any = None
        self._mean = 0.0
        self._std = 1.0
        self._trained = False

    @property
    def enabled(self) -> bool:
        return torch_available()

    @property
    def trained(self) -> bool:
        return self._trained

    # -- training -----------------------------------------------------------

    def _features(self, times: np.ndarray, residuals: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        rows, targets = [], []
        for k in range(self.lags, residuals.size):
            rows.append(residuals[k - self.lags : k])
            targets.append(residuals[k])
        if not rows:
            return np.empty((0, self.lags)), np.empty(0)
        lag_matrix = np.asarray(rows, dtype=float)
        cal = calendar_features(times[self.lags : residuals.size])
        return np.hstack([lag_matrix, cal]), np.asarray(targets, dtype=float)

    def fit(self, times_s: np.ndarray, values: np.ndarray) -> "ResidualLearner":
        """Fit the residual model. Silently does nothing without PyTorch."""
        self.baseline.fit(times_s, values)
        torch = try_import("torch")
        if torch is None:
            return self

        times = np.asarray(times_s, dtype=float)
        values = np.asarray(values, dtype=float)
        try:
            baseline_fit = self.baseline._backtest(times, values)  # noqa: SLF001
        except NotImplementedError:
            return self
        residuals = values[-baseline_fit.size :] - baseline_fit
        features, targets = self._features(times[-baseline_fit.size :], residuals)
        if features.shape[0] < 32:
            return self

        self._mean = float(targets.mean())
        self._std = float(targets.std()) or 1.0
        torch.manual_seed(self.seed)
        model = torch.nn.Sequential(
            torch.nn.Linear(features.shape[1], self.hidden),
            torch.nn.Tanh(),
            torch.nn.Linear(self.hidden, self.hidden // 2),
            torch.nn.Tanh(),
            torch.nn.Linear(self.hidden // 2, 1),
        )
        optimiser = torch.optim.Adam(model.parameters(), lr=self.learning_rate)
        x = torch.tensor(features, dtype=torch.float32)
        y = torch.tensor((targets - self._mean) / self._std, dtype=torch.float32).unsqueeze(1)
        loss_fn = torch.nn.SmoothL1Loss()
        model.train()
        for _ in range(self.epochs):
            optimiser.zero_grad()
            loss = loss_fn(model(x), y)
            loss.backward()
            optimiser.step()
        model.eval()
        self._model = model
        self._trained = True
        return self

    # -- prediction ---------------------------------------------------------

    def predict(self, horizon_s: float, dt_s: float, *, origin_s: float = 0.0) -> Forecast:
        base = self.baseline.predict(horizon_s, dt_s, origin_s=origin_s)
        if not self._trained or self._model is None:
            return base
        torch = try_import("torch")
        if torch is None:  # pragma: no cover - torch vanished mid-process
            return base

        times, values = self.baseline.history
        try:
            fitted = self.baseline._backtest(times, values)  # noqa: SLF001
        except NotImplementedError:
            return base
        residuals = list(values[-fitted.size :] - fitted)
        if len(residuals) < self.lags:
            return base

        corrections = []
        window = residuals[-self.lags :]
        with torch.no_grad():
            for t in base.times_s:
                cal = calendar_features(np.array([t]))[0]
                features = np.concatenate([np.asarray(window), cal])
                out = self._model(torch.tensor(features, dtype=torch.float32).unsqueeze(0))
                correction = float(out.item()) * self._std + self._mean
                corrections.append(correction)
                # Feed the prediction back in: the model is autoregressive, and
                # the correction decays as it is fed its own output, which is
                # the behaviour we want far from the last observation.
                window = window[1:] + [correction * 0.5]

        delta = np.asarray(corrections)
        return Forecast(
            times_s=base.times_s,
            p50=base.p50 + delta,
            p10=base.p10 + delta,
            p90=base.p90 + delta,
            unit=base.unit,
            source=f"{base.source}+residual_mlp",
            uncertainty_method=base.uncertainty_method,
            meta={**base.meta, "residual_correction_rms": float(np.sqrt(np.mean(delta**2)))},
        )

    # -- honesty check ------------------------------------------------------

    def improves_on_baseline(
        self, times_s: np.ndarray, values: np.ndarray, *, split: float = 0.75
    ) -> dict[str, float | bool]:
        """Backtest the learned model against the baseline on held-out data.

        Returns the mean absolute error of both and a boolean verdict. The
        learned component earns its place only if it wins here; if it does not,
        the honest thing is to leave it switched off, and this method is what
        makes that decision checkable rather than assumed.
        """
        times = np.asarray(times_s, dtype=float)
        values = np.asarray(values, dtype=float)
        cut = int(len(values) * split)
        if cut < 32 or len(values) - cut < 8:
            return {"baseline_mae": float("nan"), "learned_mae": float("nan"), "improves": False}

        baseline_only = type(self.baseline)()
        baseline_only.fit(times[:cut], values[:cut])
        dt = float(np.median(np.diff(times[:cut]))) if cut > 1 else 60.0
        horizon = dt * (len(values) - cut)
        base_forecast = baseline_only.predict(horizon, dt, origin_s=times[cut])
        base_pred = np.interp(times[cut:], base_forecast.times_s, base_forecast.p50)
        base_mae = float(np.mean(np.abs(values[cut:] - base_pred)))

        if not self.enabled:
            return {"baseline_mae": base_mae, "learned_mae": base_mae, "improves": False}

        learner = ResidualLearner(
            type(self.baseline)(),
            lags=self.lags,
            hidden=self.hidden,
            epochs=self.epochs,
            seed=self.seed,
        )
        learner.fit(times[:cut], values[:cut])
        learned_forecast = learner.predict(horizon, dt, origin_s=times[cut])
        learned_pred = np.interp(times[cut:], learned_forecast.times_s, learned_forecast.p50)
        learned_mae = float(np.mean(np.abs(values[cut:] - learned_pred)))
        return {
            "baseline_mae": base_mae,
            "learned_mae": learned_mae,
            "improvement": (base_mae - learned_mae) / max(base_mae, EPS),
            "improves": learned_mae < base_mae * 0.98,
        }


__all__ = ["ResidualLearner", "torch_available", "calendar_features"]
