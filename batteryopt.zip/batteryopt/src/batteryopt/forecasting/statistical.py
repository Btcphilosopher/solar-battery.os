"""Statistical forecasters: no learned parameters, no optional dependencies.

These are the methods the optimiser falls back on, and in practice they are
also the ones it usually uses. For daily-periodic signals -- electricity price,
site load, PV generation, ambient temperature -- a harmonic regression with a
seasonal-naive fallback is difficult to beat by enough to justify a neural
network, and it has the considerable advantage of being inspectable.

Four forecasters, in increasing order of assumption:

* :class:`PersistenceForecaster` -- tomorrow looks like now. The honest
  baseline every other method must beat.
* :class:`SeasonalNaiveForecaster` -- tomorrow looks like yesterday at the same
  time of day. Strong for load and price, and immune to the trend-chasing that
  regression methods suffer from.
* :class:`ExponentialSmoothingForecaster` -- level and trend, damped. Good for
  temperature over hours.
* :class:`HarmonicRegressionForecaster` -- daily and weekly Fourier terms fitted
  by least squares. The general-purpose default for periodic signals.
"""

from __future__ import annotations

import numpy as np

from ..core.numerics import EPS, clamp
from ..core.units import SECONDS_PER_DAY, SECONDS_PER_HOUR
from .base import BaseForecaster, Forecast


class PersistenceForecaster(BaseForecaster):
    """The last observed value, held flat. The baseline to beat."""

    name = "persistence"

    def _backtest(self, times: np.ndarray, values: np.ndarray) -> np.ndarray:
        return values[:-1]

    def predict(self, horizon_s: float, dt_s: float, *, origin_s: float = 0.0) -> Forecast:
        n = max(1, int(round(horizon_s / dt_s)))
        grid = origin_s + np.arange(n + 1) * dt_s
        last = self._values[-1] if self._values else 0.0
        return self._make(grid, np.full(n + 1, last), unit="", meta={"last_value": last})


class SeasonalNaiveForecaster(BaseForecaster):
    """The value from one season ago, with a level correction.

    For a daily season this is "the same time yesterday", nudged by the recent
    difference between now and this time yesterday. That correction is what
    stops it lagging a whole day behind a step change in the level.
    """

    name = "seasonal_naive"

    def __init__(self, *, season_s: float = SECONDS_PER_DAY, level_window_s: float = 3 * SECONDS_PER_HOUR, **kw) -> None:
        super().__init__(**kw)
        self.season_s = season_s
        #: Window over which the level correction is estimated.
        self.level_window_s = level_window_s

    def _lookup(self, t: float) -> float | None:
        times, values = self.history
        if times.size == 0:
            return None
        target = t - self.season_s
        while target < times[0] and target + self.season_s <= times[-1]:
            target += self.season_s
        if target < times[0] or target > times[-1]:
            return None
        return float(np.interp(target, times, values))

    def _level_correction(self) -> float:
        times, values = self.history
        if times.size < 4:
            return 0.0
        now = times[-1]
        recent_mask = times >= now - self.level_window_s
        if not np.any(recent_mask):
            return 0.0
        recent = float(np.mean(values[recent_mask]))
        prior = [
            self._lookup(t) for t in times[recent_mask]
        ]
        prior_vals = [p for p in prior if p is not None]
        if not prior_vals:
            return 0.0
        return recent - float(np.mean(prior_vals))

    def _backtest(self, times: np.ndarray, values: np.ndarray) -> np.ndarray:
        out = []
        for t in times:
            got = self._lookup(float(t))
            out.append(got if got is not None else values[0])
        return np.asarray(out[-max(1, len(out) - 1) :], dtype=float)

    def predict(self, horizon_s: float, dt_s: float, *, origin_s: float = 0.0) -> Forecast:
        n = max(1, int(round(horizon_s / dt_s)))
        grid = origin_s + np.arange(n + 1) * dt_s
        correction = self._level_correction()
        fallback = self._values[-1] if self._values else 0.0
        median = np.array(
            [
                (self._lookup(float(t)) or fallback) + correction
                for t in grid
            ],
            dtype=float,
        )
        return self._make(
            grid,
            median,
            unit="",
            meta={"season_s": self.season_s, "level_correction": correction},
        )


class ExponentialSmoothingForecaster(BaseForecaster):
    """Holt's linear trend with damping.

    Damping matters: an undamped trend extrapolated twelve hours out produces
    negative loads and impossible temperatures. The damping factor bounds the
    total extrapolation to ``trend * phi / (1 - phi)``, which keeps the forecast
    physical without needing a clamp.
    """

    name = "exponential_smoothing"

    def __init__(self, *, alpha: float = 0.3, beta: float = 0.1, phi: float = 0.9, **kw) -> None:
        super().__init__(**kw)
        self.alpha = clamp(alpha, 0.01, 1.0)
        self.beta = clamp(beta, 0.0, 1.0)
        self.phi = clamp(phi, 0.0, 0.999)

    def _smooth(self, values: np.ndarray) -> tuple[float, float]:
        if values.size == 0:
            return 0.0, 0.0
        level = float(values[0])
        trend = float(values[1] - values[0]) if values.size > 1 else 0.0
        for v in values[1:]:
            prev_level = level
            level = self.alpha * float(v) + (1.0 - self.alpha) * (level + self.phi * trend)
            trend = self.beta * (level - prev_level) + (1.0 - self.beta) * self.phi * trend
        return level, trend

    def _backtest(self, times: np.ndarray, values: np.ndarray) -> np.ndarray:
        out = []
        level = float(values[0])
        trend = float(values[1] - values[0]) if values.size > 1 else 0.0
        for v in values[1:]:
            out.append(level + self.phi * trend)
            prev_level = level
            level = self.alpha * float(v) + (1.0 - self.alpha) * (level + self.phi * trend)
            trend = self.beta * (level - prev_level) + (1.0 - self.beta) * self.phi * trend
        return np.asarray(out, dtype=float)

    def predict(self, horizon_s: float, dt_s: float, *, origin_s: float = 0.0) -> Forecast:
        n = max(1, int(round(horizon_s / dt_s)))
        grid = origin_s + np.arange(n + 1) * dt_s
        _, values = self.history
        level, trend = self._smooth(values)
        steps = np.arange(n + 1)
        # Damped cumulative trend: sum of phi^1..phi^h.
        damping = np.array(
            [sum(self.phi ** (i + 1) for i in range(int(h))) for h in steps], dtype=float
        )
        median = level + trend * damping
        return self._make(grid, median, unit="", meta={"level": level, "trend": trend})


class HarmonicRegressionForecaster(BaseForecaster):
    """Least-squares fit of daily and weekly Fourier terms plus a linear trend.

    The design matrix is ``[1, t, sin(k w_d t), cos(k w_d t), sin(w_w t),
    cos(w_w t)]``. Fitting is a single least-squares solve, so refitting on
    every new observation is affordable, and the fitted coefficients are
    directly interpretable -- the amplitude of the first daily harmonic is the
    size of the day/night swing.

    Ridge regularisation is applied because the design matrix becomes
    ill-conditioned when the history is short relative to the longest period,
    which is exactly the situation on the first day of deployment.
    """

    name = "harmonic_regression"

    def __init__(
        self,
        *,
        daily_harmonics: int = 3,
        weekly: bool = True,
        trend: bool = True,
        ridge: float = 1e-6,
        **kw,
    ) -> None:
        super().__init__(**kw)
        self.daily_harmonics = max(1, daily_harmonics)
        self.weekly = weekly
        self.trend = trend
        self.ridge = ridge
        self._coefficients: np.ndarray | None = None
        self._origin: float = 0.0

    def _design(self, t: np.ndarray) -> np.ndarray:
        rel = (t - self._origin) / SECONDS_PER_DAY
        columns = [np.ones_like(rel)]
        if self.trend:
            columns.append(rel)
        for k in range(1, self.daily_harmonics + 1):
            columns.append(np.sin(2.0 * np.pi * k * rel))
            columns.append(np.cos(2.0 * np.pi * k * rel))
        if self.weekly:
            columns.append(np.sin(2.0 * np.pi * rel / 7.0))
            columns.append(np.cos(2.0 * np.pi * rel / 7.0))
        return np.vstack(columns).T

    def _solve(self) -> None:
        times, values = self.history
        if times.size < 8:
            self._coefficients = None
            return
        self._origin = float(times[0])
        design = self._design(times)
        gram = design.T @ design + self.ridge * np.eye(design.shape[1])
        self._coefficients = np.linalg.solve(gram, design.T @ values)

    def fit(self, times_s: np.ndarray, values: np.ndarray) -> "HarmonicRegressionForecaster":
        super().fit(times_s, values)
        self._solve()
        return self

    def _backtest(self, times: np.ndarray, values: np.ndarray) -> np.ndarray:
        if self._coefficients is None:
            self._solve()
        if self._coefficients is None:
            raise NotImplementedError
        return self._design(times) @ self._coefficients

    def predict(self, horizon_s: float, dt_s: float, *, origin_s: float = 0.0) -> Forecast:
        n = max(1, int(round(horizon_s / dt_s)))
        grid = origin_s + np.arange(n + 1) * dt_s
        if self._coefficients is None:
            self._solve()
        if self._coefficients is None:
            last = self._values[-1] if self._values else 0.0
            return self._make(grid, np.full(n + 1, last), unit="", meta={"fitted": False})
        median = self._design(grid) @ self._coefficients
        amplitude = float(
            np.hypot(
                self._coefficients[1 + int(self.trend)],
                self._coefficients[2 + int(self.trend)],
            )
        )
        return self._make(
            grid,
            median,
            unit="",
            meta={
                "fitted": True,
                "daily_amplitude": amplitude,
                "coefficients": self._coefficients.tolist(),
            },
        )


def non_negative(forecast: Forecast) -> Forecast:
    """Clip a forecast at zero, for quantities that cannot be negative.

    Applied to PV generation and to site load. Clipping the *band* as well as
    the median matters: a P10 of minus three kilowatts is not a useful lower
    bound on generation.
    """
    return Forecast(
        times_s=forecast.times_s,
        p50=np.clip(forecast.p50, 0.0, None),
        p10=np.clip(forecast.p10, 0.0, None),
        p90=np.clip(forecast.p90, 0.0, None),
        unit=forecast.unit,
        source=forecast.source,
        uncertainty_method=forecast.uncertainty_method,
        provenance=forecast.provenance,
        meta=dict(forecast.meta),
    )


__all__ = [
    "PersistenceForecaster",
    "SeasonalNaiveForecaster",
    "ExponentialSmoothingForecaster",
    "HarmonicRegressionForecaster",
    "non_negative",
]
