# Long-Life Battery Engine: R Quantitative Research Module
# Monte Carlo Fleet Simulation & Lifetime Probability Distributions
# 
# SPDX-License-Identifier: Apache-2.0

#' Run Monte Carlo Lifetime Analysis on Battery Fleet
#' @param num_simulations Number of simulations to execute.
#' @param spec List containing battery specification limits.
#' @param strategy Strategy selected ("aggressive", "balanced", "long_life").
#' @return A list containing statistical quantiles of expected lifetimes and plot data.
#' @export
run_monte_carlo_fleet <- function(num_simulations = 1000, spec, strategy) {
  # Calibrate failure rate based on strategy
  baseline_fade_rate <- switch(strategy,
                               "aggressive" = 0.045,
                               "balanced"   = 0.030,
                               "long_life"  = 0.020,
                               0.030)
  
  # Simulate Fleet Failure Lifetimes
  lifetimes <- replicate(num_simulations, {
    # Add manufacturing variability (+/- 2% initial capacity)
    capacity_noise <- rnorm(1, mean = 1.0, sd = 0.01)
    # Add ambient operational temperature variations
    temp_noise <- rnorm(1, mean = 0.0, sd = 3.0)
    # Add duty cycle demand intensity variations
    load_noise <- rlnorm(1, meanlog = 0.0, sdlog = 0.1)
    
    current_soh <- 1.0
    year <- 0
    
    # Iterate until standard End of Life (e.g. 80% SOH)
    while (current_soh > spec$target_end_of_life_soh && year < 30) {
      year <- year + 1
      thermal_stress <- 1.0 + max(0, temp_noise) * 0.035
      load_stress <- load_noise^1.4
      
      yearly_degradation <- baseline_fade_rate * capacity_noise * thermal_stress * load_stress * runif(1, 0.85, 1.15)
      current_soh <- current_soh - yearly_degradation
    }
    return(year)
  })
  
  # Quantiles calculation (Expected failures)
  quantiles <- quantile(lifetimes, probs = c(0.05, 0.25, 0.50, 0.75, 0.95))
  
  return(list(
    expected_lifetime_years = mean(lifetimes),
    percentile_5 = quantiles[1],
    median = quantiles[3],
    percentile_95 = quantiles[5],
    prob_gt_10_years = sum(lifetimes > 10) / num_simulations,
    prob_gt_15_years = sum(lifetimes > 15) / num_simulations,
    raw_lifetimes = lifetimes
  ))
}
