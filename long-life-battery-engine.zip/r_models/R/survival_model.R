# Long-Life Battery Engine: R Quantitative Research Module
# Weibull Survival Analysis & Reliability Engineering for Battery Lifetimes
# 
# SPDX-License-Identifier: Apache-2.0

library(survival)

#' Fit Weibull Survival Model on Battery Life-Testing Observations
#' @param cycle_failures Data frame containing 'cycles_to_80_soh' and 'censored' (0/1).
#' @return A fitted survreg Weibull survival model.
#' @export
fit_battery_survival <- function(cycle_failures) {
  # Surv(time, status)
  surv_obj <- Surv(cycle_failures$cycles_to_80_soh, cycle_failures$censored)
  
  # Fit Weibull parametric survival model
  weibull_fit <- survreg(surv_obj ~ temperature_c + max_c_rate, data = cycle_failures, dist = "weibull")
  
  return(weibull_fit)
}

#' Predict Remaining Useful Life Probability Curve
#' @param fit Fitted survreg Weibull model.
#' @param temperature_c Target ambient/operating temperature.
#' @param max_c_rate Target operational C-rate.
#' @param cycle_grid Grid of cycles to predict survival probability for.
#' @return Data frame of cycles vs survival probability.
#' @export
predict_survival_curve <- function(fit, temperature_c, max_c_rate, cycle_grid = seq(100, 10000, by = 100)) {
  # Predict percentiles (quantiles)
  quantiles <- seq(0.01, 0.99, by = 0.01)
  predicted_cycles <- predict(fit, newdata = data.frame(temperature_c = temperature_c, max_c_rate = max_c_rate), 
                             type = "quantile", p = quantiles)
  
  # Standard survival function values (S(t) = 1 - F(t))
  survival_prob <- 1 - quantiles
  
  return(data.frame(
    cycles = predicted_cycles,
    survival_probability = survival_prob
  ))
}
