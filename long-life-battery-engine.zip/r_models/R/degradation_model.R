# Long-Life Battery Engine: R Quantitative Research Module
# Electrochemical Degradation, Arrhenius Calibration, and Capacity Fade Modeling
# 
# SPDX-License-Identifier: Apache-2.0

#' Calibrate Arrhenius Temperature Parameters for Calendar Ageing
#' @param temperatures_c Vector of experimental temperatures in Celsius.
#' @param capacity_fade_rate Vector of daily capacity fade rates.
#' @return A list containing estimated activation energy (J/mol) and pre-exponential factor.
#' @export
calibrate_arrhenius <- function(temperatures_c, capacity_fade_rate) {
  # Universal gas constant
  R_gas <- 8.314
  temp_k <- temperatures_c + 273.15
  
  # Linearize Arrhenius: ln(k) = ln(A) - Ea / (R * T)
  ln_k <- log(capacity_fade_rate)
  inv_t <- 1 / temp_k
  
  fit <- lm(ln_k ~ inv_t)
  intercept <- coef(fit)[1]
  slope <- coef(fit)[2]
  
  # Extract physical values
  pre_exponential_A <- exp(intercept)
  activation_energy_Ea <- -slope * R_gas
  
  return(list(
    activation_energy_Ea = activation_energy_Ea,
    pre_exponential_A = pre_exponential_A,
    r_squared = summary(fit)$r.squared
  ))
}

#' Model Capacity Fade and Anode Thickness SEI Layer growth (sqrt(time) diffusion)
#' @param days Vector of days.
#' @param temp_c Operating temperature.
#' @param soc State of charge.
#' @param Ea Activation energy.
#' @param A_factor Pre-exponential factor.
#' @return Vector of capacity retention values.
#' @export
predict_capacity_fade <- function(days, temp_c, soc, Ea = 48000, A_factor = 0.00035) {
  R_gas <- 8.314
  temp_k <- temp_c + 273.15
  
  # Stress factors
  arrhenius <- exp(-Ea / (R_gas * temp_k)) / exp(-Ea / (R_gas * (25 + 273.15)))
  soc_stress <- exp(1.2 * (soc - 0.5))
  
  # Diffusion limited SEI growth follows t^0.5
  fade <- A_factor * arrhenius * soc_stress * sqrt(days)
  retention <- 1.0 - fade
  return(pmax(0, retention))
}
