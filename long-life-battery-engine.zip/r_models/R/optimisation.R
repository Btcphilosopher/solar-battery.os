# Long-Life Battery Engine: R Quantitative Research Module
# Operating-Envelope Boundary Discovery & Multi-Objective Lifetime Optimization
# 
# SPDX-License-Identifier: Apache-2.0

#' Discover Optimal Lifetime Operating Envelopes (Grid-Search Sweep)
#' @param spec List of battery specification constraints.
#' @param electricity_prices Vector of prices over 24 hours.
#' @return A data frame containing the discovered Pareto-optimal battery configurations.
#' @export
discover_operating_envelopes <- function(spec, electricity_prices) {
  # Grid sweep variables
  soc_mins <- seq(0.0, 0.3, by = 0.05)
  soc_maxs <- seq(0.7, 1.0, by = 0.05)
  max_c_rates <- seq(0.2, 2.0, by = 0.2)
  
  grid <- expand.grid(soc_min = soc_mins, soc_max = soc_maxs, c_rate = max_c_rates)
  
  # Calculate estimated lifetime and economic profitability for each candidate envelope
  results <- apply(grid, 1, function(row) {
    soc_min <- row[1]
    soc_max <- row[2]
    c_rate <- row[3]
    
    # Simple mathematical model of operational value vs physical degradation speed
    operational_window <- soc_max - soc_min
    
    # Calendar degradation is highly sensitive to high-SOC levels
    calendar_wear <- if (soc_max > 0.85) 1.5 else 1.0
    # Cycle wear is highly sensitive to C-rate and DoD
    cycle_wear <- (operational_window)^1.5 * (c_rate / 0.5)^1.3
    
    relative_degradation_speed <- calendar_wear * cycle_wear
    estimated_lifetime_years <- spec$target_lifetime_years / max(0.2, relative_degradation_speed)
    
    # Arbitrage value: wide SOC windows and higher C-rates capture more price variance
    arbitrage_revenue_factor <- operational_window * sqrt(c_rate) * sd(electricity_prices)
    annual_profit_usd <- arbitrage_revenue_factor * 1200 - (spec$replacement_cost_usd / estimated_lifetime_years)
    
    return(c(
      estimated_lifetime_years = estimated_lifetime_years,
      annual_profit_usd = annual_profit_usd
    ))
  })
  
  grid$estimated_lifetime_years <- results[1, ]
  grid$annual_profit_usd <- results[2, ]
  
  # Sort to identify the Pareto frontier (balancing maximum longevity and economic arbitrage profit)
  grid <- grid[order(-grid$annual_profit_usd, -grid$estimated_lifetime_years), ]
  return(grid)
}
