/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { runLongDurationSimulation, runMonteCarloAnalysis, generateOperatingEnvelopeGrid } from './src/utils/simulator';

dotenv.config();

const PORT = 3000;

// Initialize Google Gen AI on the server side
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;

if (apiKey) {
  ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

async function startServer() {
  const app = express();
  app.use(express.json());

  // 1. Simulation API Endpoints
  app.post('/api/simulate', (req, res) => {
    try {
      const { spec, strategy, durationYears, averageAmbientTempC } = req.body;
      const result = runLongDurationSimulation(spec, strategy, durationYears || 10, averageAmbientTempC || 20.0);
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/monte-carlo', (req, res) => {
    try {
      const { spec, strategy, runsCount } = req.body;
      const result = runMonteCarloAnalysis(spec, strategy, runsCount || 150);
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/envelope', (req, res) => {
    try {
      const { spec } = req.body;
      const result = generateOperatingEnvelopeGrid(spec);
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // 2. Gemini-powered Battery Scientist Assistant Route
  app.post('/api/gemini/analyze', async (req, res) => {
    try {
      const { prompt, batterySpec, simulationSummary } = req.body;

      if (!ai) {
        return res.status(503).json({
          error: 'Gemini AI API key is not configured in the workspace secrets. Please set GEMINI_API_KEY in Settings > Secrets.',
        });
      }

      const systemInstruction = `You are a world-class senior electrochemical engineer and master battery scientist. 
You are advising a customer on thermal, electrical, and degradation optimization using results from the LONG-LIFE BATTERY ENGINE.
Analyze the provided battery specification and simulation results:
- Battery Capacity: ${batterySpec?.nominalCapacityKwh} kWh, nominal voltage: ${batterySpec?.nominalVoltageV} V
- Operating Strategy: ${simulationSummary?.strategy}
- Final SOH Retained: ${(simulationSummary?.finalSoh * 100).toFixed(1)}% after ${simulationSummary?.estimatedLifetimeYears?.toFixed(1)} years
- Delivered Energy: ${simulationSummary?.totalEnergyDeliveredKwh?.toLocaleString()} kWh
- Average Temperature: ${simulationSummary?.averageTemperatureC?.toFixed(1)}°C, Max: ${simulationSummary?.maxTemperatureC?.toFixed(1)}°C
- Net Economic Value: $${simulationSummary?.netEconomicValueUsd?.toLocaleString()}

Provide rigorous, detailed, scientifically grounded suggestions to preserve battery health, optimize thermal stress, and mitigate capacity fade. 
Avoid generic fluff or hand-waving. Use specific terms like Solid Electrolyte Interphase (SEI) layer growth, lithium plating kinetics, and intercalation mechanical strain. Keep your answers concise, clear, and action-oriented.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.7-flash',
        contents: prompt || 'Analyze this battery profile and provide a recommendations summary.',
        config: {
          systemInstruction,
          temperature: 0.7,
        },
      });

      res.json({ text: response.text });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Serve static files / Vite middleware
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[LONG-LIFE BATTERY ENGINE] Server online on port http://localhost:${PORT}`);
  });
}

startServer();
