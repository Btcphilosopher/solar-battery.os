//! Main entry point for the LONG-LIFE BATTERY ENGINE.
//! Starts the high-performance computation web API.

mod error;
mod battery;
mod state;
mod electrochemical;
mod electrical;
mod thermal;
mod degradation;
mod ageing;
mod cycle;
mod efficiency;
mod optimiser;
mod simulation;
mod telemetry;
mod lifetime;

use axum::{routing::get, Router};
use tracing::info;

#[tokio::main]
async fn main() {
    tracing_subscriber::fmt::init();
    info!("Initializing LONG-LIFE BATTERY ENGINE [Rust Computational Core]");

    let app = Router::new()
        .route("/health", get(health_check));

    // Bind server to standard port (internal container environment)
    let listener = tokio::net::TcpListener::bind("0.0.0.0:3005").await.unwrap();
    info!("Computational microservice running on http://{}", listener.local_addr().unwrap());
    
    // Non-blocking background server spin (to allow preview server to bind on 3000)
    tokio::spawn(async move {
        axum::serve(listener, app).await.unwrap();
    });

    // Keep main thread alive or execute mock CLI run
    let spec = battery::BatterySpec::default_lfp();
    info!("Running nominal 10-year simulation under BALANCED strategy for verification...");
    let result = simulation::run_simulation(&spec, optimiser::OperatingStrategy::BALANCED, 10.0);
    info!("Verification complete. Final State of Health: {:.2}%", result.final_state.soh * 100.0);
    info!("Cumulative energy delivered: {:.1} MWh", result.energy_delivered_kwh / 1000.0);

    // Loop infinitely to represent running daemon
    loop {
        tokio::time::sleep(tokio::time::Duration::from_secs(3600)).await;
    }
}

async fn health_check() -> &'static str {
    "LONG-LIFE BATTERY ENGINE: Rust core online"
}
