//! Cycle counter and energy throughput tracker.

use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CycleRecord {
    pub start_soc: f64,
    pub end_soc: f64,
    pub depth_of_discharge: f64,
    pub average_temperature_c: f64,
    pub average_current_a: f64,
    pub duration_hours: f64,
    pub energy_throughput_kwh: f64,
}

pub struct CycleAgeingEstimator {
    pub baseline_cycles_to_eol: u32,
}

impl CycleAgeingEstimator {
    pub fn new() -> Self {
        Self {
            baseline_cycles_to_eol: 3000, // 3000 cycles at 80% DOD is nominal
        }
    }
}
