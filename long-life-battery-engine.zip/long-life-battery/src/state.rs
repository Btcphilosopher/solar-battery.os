//! Battery state models for the Long-Life Battery Engine.

use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BatteryState {
    pub time_hours: f64,
    pub soc: f64,
    pub soh: f64,
    pub voltage_v: f64,
    pub current_a: f64,
    pub power_kw: f64,
    pub temperature_c: f64,
    pub capacity_kwh: f64,
    pub resistance_ohm: f64,
    pub cumulative_energy_in_kwh: f64,
    pub cumulative_energy_out_kwh: f64,
    pub equivalent_full_cycles: f64,
    pub calendar_age_days: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SystemHierarchy {
    pub cell_states: Vec<BatteryState>,
    pub module_states: Vec<BatteryState>,
    pub pack_state: BatteryState,
}

impl BatteryState {
    pub fn new(capacity_kwh: f64, nominal_voltage: f64, nominal_resistance: f64) -> Self {
        Self {
            time_hours: 0.0,
            soc: 0.5,
            soh: 1.0,
            voltage_v: nominal_voltage,
            current_a: 0.0,
            power_kw: 0.0,
            temperature_c: 25.0,
            capacity_kwh,
            resistance_ohm: nominal_resistance,
            cumulative_energy_in_kwh: 0.0,
            cumulative_energy_out_kwh: 0.0,
            equivalent_full_cycles: 0.0,
            calendar_age_days: 0.0,
        }
    }
}
