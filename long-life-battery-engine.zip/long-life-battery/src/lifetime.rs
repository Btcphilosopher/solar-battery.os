//! Lifetime forecasting and survival probability calculators.

pub struct LifetimeForecast {
    pub average_lifetime_years: f64,
    pub cycle_life_capacity_fade_factor: f64,
}

impl LifetimeForecast {
    pub fn calculate(soh_now: f64, capacity_fade_per_year: f64) -> Self {
        let remaining_useful_capacity = (soh_now - 0.80).max(0.0);
        let years = if capacity_fade_per_year > 0.0 {
            remaining_useful_capacity / capacity_fade_per_year
        } else {
            50.0
        };
        
        Self {
            average_lifetime_years: years,
            cycle_life_capacity_fade_factor: capacity_fade_per_year,
        }
    }
}
