//! Specific Error definitions for the Battery computational loop.

use thiserror::Error;

#[derive(Debug, Error)]
pub enum EngineError {
    #[error("Voltage Collapse: Power demand exceeds maximum physical capability of battery")]
    VoltageCollapse,

    #[error("Physical Constraint Violation: {0}")]
    PhysicalConstraintViolation(String),

    #[error("Database persistence failure: {0}")]
    DatabaseError(String),

    #[error("R Model Interchange Error: {0}")]
    InterchangeError(String),

    #[error("Generic simulation system fault: {0}")]
    SimulationError(String),
}
