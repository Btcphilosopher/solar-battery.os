//! Dynamic coupled battery degradation system.

use crate::state::BatteryState;
use crate::battery::BatterySpec;

#[derive(Debug, Clone)]
pub struct DegradationState {
    pub calendar_fade: f64,
    pub cycle_fade: f64,
    pub thermal_fade: f64,
    pub high_soc_fade: f64,
    pub high_c_rate_fade: f64,
    pub total_capacity_fade: f64,
    pub resistance_growth: f64,
}

pub fn calculate_degradation(
    state: &BatteryState,
    spec: &BatterySpec,
    dt_hours: f64,
    c_rate: f64,
) -> (f64, f64, DegradationState) {
    let dt_days = dt_hours / 24.0;
    
    // 1. Calendar Ageing (Arrhenius SEI growth rate)
    const E_A_CAL: f64 = 48000.0;
    const R_GAS: f64 = 8.314;
    const TEMP_KELVIN_OFFSET: f64 = 273.15;
    
    let t_kelvin = state.temperature_c + TEMP_KELVIN_OFFSET;
    let arrhenius_factor = ((-E_A_CAL) / (R_GAS * t_kelvin)).exp() / ((-E_A_CAL) / (R_GAS * (25.0 + TEMP_KELVIN_OFFSET))).exp();
    
    let mut soc_stress = 1.0;
    if state.soc > 0.7 {
        soc_stress = 1.0 + 3.0 * ((state.soc - 0.7) / 0.3).powi(2);
    } else if state.soc < 0.2 {
        soc_stress = 1.0 + 0.5 * ((0.2 - state.soc) / 0.2).powf(1.5);
    }

    let age_days_reg = state.calendar_age_days.max(0.1);
    let cal_fade_rate = 0.00035 * arrhenius_factor * soc_stress;
    let delta_cal_fade = cal_fade_rate * (0.5 / age_days_reg.sqrt()) * dt_days;

    // 2. Cycle Ageing (volume expansion fatigue, DoD effects, plating)
    let nominal_ah = (spec.nominal_capacity_kwh * 1000.0) / spec.nominal_voltage_v;
    let delta_efc = (state.current_a.abs() * dt_hours) / (2.0 * nominal_ah);

    let thermal_cycle_factor = if state.temperature_c > 25.0 {
        1.0 + 0.03 * (state.temperature_c - 25.0)
    } else {
        1.0
    };

    let plating_stress = if state.current_a < 0.0 && state.temperature_c < 15.0 {
        1.0 + 5.0 * ((15.0 - state.temperature_c) / 15.0).powi(2) * c_rate.abs().powf(1.5)
    } else {
        1.0
    };

    let c_rate_factor = (c_rate.abs() / 0.5).max(1.0).powf(1.3);
    let dod_stress = (state.soc - 0.5).powi(2) * 4.0;

    let delta_cyc_fade = 0.000067 * delta_efc * thermal_cycle_factor * plating_stress * c_rate_factor * (1.0 + dod_stress);

    // Total incremental fade
    let capacity_fade = delta_cal_fade + delta_cyc_fade;
    let resistance_growth = capacity_fade * 1.6 * (1.0 + 0.05 * (state.temperature_c - 35.0).max(0.0));

    let debug = DegradationState {
        calendar_fade: delta_cal_fade,
        cycle_fade: delta_cyc_fade,
        thermal_fade: if state.temperature_c > 35.0 { capacity_fade * 0.25 } else { 0.0 },
        high_soc_fade: if state.soc > 0.8 { capacity_fade * 0.35 } else { 0.0 },
        high_c_rate_fade: if c_rate.abs() > 1.0 { capacity_fade * 0.2 } else { 0.0 },
        total_capacity_fade: capacity_fade,
        resistance_growth,
    };

    (capacity_fade, resistance_growth, debug)
}
