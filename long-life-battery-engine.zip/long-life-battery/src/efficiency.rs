//! Conversion efficiency calculations and power loss metrics.

pub fn calculate_round_trip_efficiency(energy_in_kwh: f64, energy_out_kwh: f64) -> f64 {
    if energy_in_kwh <= 0.0 {
        1.0
    } else {
        (energy_out_kwh / energy_in_kwh).clamp(0.0, 1.0)
    }
}
