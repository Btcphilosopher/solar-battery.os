//! Core structures for calendar and thermal aging calculations.

pub struct CalendarAgingConfig {
    pub activation_energy_j_mol: f64,
    pub pre_exponential_factor: f64,
}

impl Default for CalendarAgingConfig {
    fn default() -> Self {
        Self {
            activation_energy_j_mol: 48000.0,
            pre_exponential_factor: 0.00035,
        }
    }
}
