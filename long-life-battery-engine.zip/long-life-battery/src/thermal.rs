//! Physically-interpretable Battery Thermal Mass Model.

use crate::battery::BatterySpec;

pub struct ThermalModel {
    pub convective_cooling_coeff_w_k: f64, // heat transfer coefficient (h)
    pub thermal_mass_j_k: f64,            // heat capacity of cells & hardware (C_th)
}

impl ThermalModel {
    pub fn new(spec: &BatterySpec) -> Self {
        // Approximate standard thermal capacity scaled by size of pack
        let capacity_scaling = spec.nominal_capacity_kwh / 2.5;
        Self {
            convective_cooling_coeff_w_k: 25.0, // Active balanced cooling default
            thermal_mass_j_k: 85000.0 * capacity_scaling,
        }
    }

    pub fn calculate_step_temperature_c(
        &self,
        ambient_temp_c: f64,
        joule_heating_w: f64,
        current_temp_c: f64,
        dt_seconds: f64,
    ) -> f64 {
        let q_rejected = self.convective_cooling_coeff_w_k * (current_temp_c - ambient_temp_c);
        let net_heat_w = joule_heating_w - q_rejected;
        
        let dT_dt = net_heat_w / self.thermal_mass_j_k;
        let next_temp = current_temp_c + dT_dt * dt_seconds;
        
        // Return physical bounds
        next_temp.clamp(-40.0, 85.0)
    }
}
