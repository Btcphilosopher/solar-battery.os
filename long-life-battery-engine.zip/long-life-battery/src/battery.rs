//! Battery specifications and chemistry-agnostic structures.

use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BatterySpec {
    pub nominal_capacity_kwh: f64,
    pub nominal_voltage_v: f64,
    pub max_charge_power_kw: f64,
    pub max_discharge_power_kw: f64,
    pub min_soc: f64,
    pub max_soc: f64,
    pub min_temperature_c: f64,
    pub max_temperature_c: f64,
    pub nominal_resistance_ohm: f64,
    pub target_lifetime_years: f64,
    pub target_end_of_life_soh: f64,
    pub replacement_cost_usd: f64,
}

impl BatterySpec {
    pub fn default_lfp() -> Self {
        Self {
            nominal_capacity_kwh: 100.0,
            nominal_voltage_v: 350.0,
            max_charge_power_kw: 100.0,
            max_discharge_power_kw: 200.0,
            min_soc: 0.05,
            max_soc: 0.95,
            min_temperature_c: -10.0,
            max_temperature_c: 55.0,
            nominal_resistance_ohm: 0.045,
            target_lifetime_years: 15.0,
            target_end_of_life_soh: 0.80,
            replacement_cost_usd: 15000.0,
        }
    }
}
