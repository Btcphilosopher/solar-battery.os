//! Long-duration battery simulation engine.

use crate::battery::BatterySpec;
use crate::state::BatteryState;
use crate::optimiser::{optimize_operation, OperatingStrategy};
use crate::electrical::{solve_electrical_point, calculate_ocv};
use crate::thermal::ThermalModel;
use crate::degradation::calculate_degradation;

pub struct SimulationResult {
    pub final_state: BatteryState,
    pub total_cycles: f64,
    pub energy_delivered_kwh: f64,
}

pub fn run_simulation(
    spec: &BatterySpec,
    strategy: OperatingStrategy,
    years: f64,
) -> SimulationResult {
    let mut state = BatteryState::new(spec.nominal_capacity_kwh, spec.nominal_voltage_v, spec.nominal_resistance_ohm);
    let thermal_model = ThermalModel::new(spec);
    
    let total_days = (years * 365.0) as usize;
    let dt_hours = 6.0; // Milestones sampling: 4 points per day
    let dt_secs = dt_hours * 3600.0;
    
    let mut energy_delivered = 0.0;
    
    for day in 0..total_days {
        state.calendar_age_days = day as f64;
        
        for period in 0..4 {
            let hour = period as f64 * 6.0;
            // Diurnal temperature profile
            let ambient = 18.0 + 6.0 * (2.0 * std::f64::consts::PI * hour / 24.0).sin();
            
            // Standard industrial demand schedule
            let demand = if hour >= 7.0 && hour <= 10.0 {
                spec.max_discharge_power_kw * 0.75
            } else if hour >= 17.0 && hour <= 20.0 {
                spec.max_discharge_power_kw * 0.9
            } else if hour >= 1.0 && hour <= 5.0 {
                -spec.max_charge_power_kw * 0.6
            } else {
                spec.max_discharge_power_kw * 0.1
            };

            let opt = optimize_operation(demand, &state, spec, strategy);
            
            if let Ok(elec) = solve_electrical_point(opt.battery_power_kw, &state, spec) {
                let next_temp = thermal_model.calculate_step_temperature_c(ambient, elec.joule_heating_w, state.temperature_c, dt_secs);
                
                let energy_exchanged = elec.current_a.abs() * elec.voltage_v * dt_hours / 1000.0;
                let nominal_ah = (spec.nominal_capacity_kwh * 1000.0) / spec.nominal_voltage_v;
                let c_rate = elec.current_a / nominal_ah;

                let delta_soc = if opt.battery_power_kw < 0.0 {
                    (energy_exchanged * elec.efficiency) / spec.nominal_capacity_kwh
                } else {
                    -energy_exchanged / (spec.nominal_capacity_kwh * elec.efficiency)
                };

                state.soc = (state.soc + delta_soc).clamp(0.0, 1.0);
                state.temperature_c = next_temp;
                state.voltage_v = elec.voltage_v;
                state.current_a = elec.current_a;
                state.power_kw = opt.battery_power_kw;

                if opt.battery_power_kw > 0.0 {
                    energy_delivered += energy_exchanged;
                    state.cumulative_energy_out_kwh += energy_exchanged;
                } else {
                    state.cumulative_energy_in_kwh += energy_exchanged;
                }

                let (fade, r_growth, _) = calculate_degradation(&state, spec, dt_hours, c_rate);
                state.soh = (state.soh - fade).max(0.0);
                state.capacity_kwh = spec.nominal_capacity_kwh * state.soh;
                state.resistance_ohm = spec.nominal_resistance_ohm * (1.0 + r_growth);
            }
        }

        if state.soh <= spec.target_end_of_life_soh {
            break;
        }
    }

    SimulationResult {
        final_state: state.clone(),
        total_cycles: state.equivalent_full_cycles,
        energy_delivered_kwh: energy_delivered,
    }
}
