//! Real-time telemetry log structures.

use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TelemetryRecord {
    pub timestamp_sec: u64,
    pub cell_id: String,
    pub voltage_v: f32,
    pub current_a: f32,
    pub temperature_c: f32,
    pub estimated_soc: f32,
}
