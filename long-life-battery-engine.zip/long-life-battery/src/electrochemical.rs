//! Electrochemical model details.

#[derive(Debug, Clone)]
pub struct ElectrochemicalParams {
    pub exchange_current_density: f64,
    pub diffusion_coefficient: f64,
    pub sei_layer_molar_volume: f64,
    pub charge_transfer_coefficient: f64,
}

impl Default for ElectrochemicalParams {
    fn default() -> Self {
        Self {
            exchange_current_density: 1.5,
            diffusion_coefficient: 1e-14,
            sei_layer_molar_volume: 2.4e-5,
            charge_transfer_coefficient: 0.5,
        }
    }
}
