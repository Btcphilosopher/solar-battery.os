//! Battery electrical model and power/voltage relationship solvers.

use crate::battery::BatterySpec;
use crate::state::BatteryState;
use crate::error::EngineError;

pub struct ElectricalModelResult {
    pub voltage_v: f64,
    pub current_a: f64,
    pub joule_heating_w: f64,
    pub efficiency: f64,
}

pub fn calculate_ocv(soc: f64, spec: &BatterySpec) -> f64 {
    let s = soc.clamp(0.0, 1.0);
    // Typical NMC open-circuit potential curve fitted with high-precision double dual-insertion potentials
    let base_ocv = 3.43 
        + 0.68 * s 
        - 0.54 * s.powi(2) 
        + 1.83 * s.powi(3) 
        - 2.15 * s.powi(4) 
        + 0.95 * s.powi(5);
    
    let scale = spec.nominal_voltage_v / 3.7;
    base_ocv * scale
}

pub fn solve_electrical_point(
    power_kw: f64,
    state: &BatteryState,
    spec: &BatterySpec,
) -> Result<ElectricalModelResult, EngineError> {
    let ocv = calculate_ocv(state.soc, spec);
    let r = state.resistance_ohm;

    if r <= 0.0 {
        return Err(EngineError::PhysicalConstraintViolation("Resistance must be greater than zero".to_string()));
    }

    let p_watts = power_kw * 1000.0;
    let discriminant = ocv * ocv - 4.0 * r * p_watts;

    if discriminant < 0.0 {
        return Err(EngineError::VoltageCollapse);
    }

    // Solve quadratic R*I^2 - Voc*I + P = 0 for physical current
    let current_a = (ocv - discriminant.sqrt()) / (2.0 * r);
    let voltage_v = ocv - current_a * r;
    let joule_heating_w = current_a * current_a * r;

    let efficiency = if current_a == 0.0 {
        1.0
    } else {
        let chem_power = ocv * current_a;
        if current_a > 0.0 {
            (voltage_v * current_a) / chem_power
        } else {
            chem_power / (voltage_v * current_a)
        }
    };

    Ok(ElectricalModelResult {
        voltage_v,
        current_a,
        joule_heating_w,
        efficiency: efficiency.clamp(0.0, 1.0),
    })
}
