//! Lifetime battery optimizer and operating strategy envelope arbitrator.

use crate::state::BatteryState;
use crate::battery::BatterySpec;

#[derive(Debug, Clone, Copy, serde::Serialize, serde::Deserialize)]
pub enum OperatingStrategy {
    AGGRESSIVE,
    BALANCED,
    LONGLIFE,
    ULTRALONGLIFE,
    ECONOMIC,
}

pub struct OptimizationDecision {
    pub battery_power_kw: f64,
    pub grid_power_kw: f64,
    pub expected_degradation_cost_usd: f64,
}

pub fn optimize_operation(
    requested_power_kw: f64,
    state: &BatteryState,
    spec: &BatterySpec,
    strategy: OperatingStrategy,
) -> OptimizationDecision {
    // 1. Establish strategic bounds based on selection
    let (mut max_p_discharge, mut max_p_charge, cooling_intensity) = match strategy {
        OperatingStrategy::ULTRALONGLIFE => {
            (spec.max_discharge_power_kw * 0.4, spec.max_charge_power_kw * 0.3, 45.0)
        }
        OperatingStrategy::LONGLIFE => {
            (spec.max_discharge_power_kw * 0.65, spec.max_charge_power_kw * 0.5, 35.0)
        }
        OperatingStrategy::ECONOMIC => {
            (spec.max_discharge_power_kw * 0.9, spec.max_charge_power_kw * 0.9, 25.0)
        }
        OperatingStrategy::AGGRESSIVE => {
            (spec.max_discharge_power_kw, spec.max_charge_power_kw, 15.0)
        }
        OperatingStrategy::BALANCED => {
            (spec.max_discharge_power_kw * 0.85, spec.max_charge_power_kw * 0.85, 25.0)
        }
    };

    // 2. BMS Safety Envelopes
    if state.temperature_c > spec.max_temperature_c - 8.0 {
        let throttle = ((spec.max_temperature_c - state.temperature_c) / 8.0).max(0.0);
        max_p_discharge *= throttle;
        max_p_charge *= throttle;
    }

    if state.soc >= spec.max_soc - 0.05 {
        let throttle = ((spec.max_soc - state.soc) / 0.05).max(0.0);
        max_p_charge *= throttle;
    } else if state.soc <= spec.min_soc + 0.05 {
        let throttle = ((state.soc - spec.min_soc) / 0.05).max(0.0);
        max_p_discharge *= throttle;
    }

    // Solve power allocation
    let battery_power_kw = if requested_power_kw > 0.0 {
        requested_power_kw.min(max_p_discharge)
    } else {
        requested_power_kw.max(-max_p_charge)
    };

    let grid_power_kw = requested_power_kw - battery_power_kw;

    // Linearized approximation of immediate physical degradation cost
    let expected_degradation_cost_usd = if battery_power_kw == 0.0 {
        0.0
    } else {
        let wear_fraction = battery_power_kw.abs() * 0.000000055;
        wear_fraction * spec.replacement_cost_usd
    };

    OptimizationDecision {
        battery_power_kw,
        grid_power_kw,
        expected_degradation_cost_usd,
    }
}
