/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Hard-tech electrochemical, thermal, and degradation physics library
 * for the LONG-LIFE BATTERY ENGINE.
 */

import { BatterySpec, BatteryState, DegradationState, OperatingStrategy, CycleRecord } from '../types';

// Constants
const R_GAS = 8.314; // Universal gas constant J/(mol*K)
const TEMP_KELVIN_OFFSET = 273.15;

/**
 * Calculates Open Circuit Voltage (OCV) using a typical NMC (Lithium-ion) 
 * state-of-charge curve.
 */
export function calculateOcv(soc: number, spec: BatterySpec): number {
  const s = Math.max(0.0, Math.min(1.0, soc));
  
  // High-fidelity polynomial fit representing dual-insertion chemistry OCV curve
  // Nominal voltage around 3.7V, minimum around 3.0V, maximum around 4.2V
  let ocv = 3.43 
    + 0.68 * s 
    - 0.54 * Math.pow(s, 2) 
    + 1.83 * Math.pow(s, 3) 
    - 2.15 * Math.pow(s, 4) 
    + 0.95 * Math.pow(s, 5);

  // Add low-SOC logarithmic sag for chemical potential depletion
  if (s < 0.1) {
    ocv += 0.115 * Math.log(s * 10 + 0.001);
  }
  // Add high-SOC exponential tail
  if (s > 0.9) {
    ocv += 0.05 * Math.exp((s - 0.9) * 10) - 0.05;
  }

  // Scale curve linearly to match battery specifications limits
  const ocvMin = 3.0;
  const ocvMax = 4.2;
  const scaledOcv = spec.nominalVoltageV * (ocv / 3.7);
  
  return Math.max(spec.nominalVoltageV * 0.8, Math.min(spec.nominalVoltageV * 1.15, scaledOcv));
}

/**
 * Calculates the electrical state of the battery for a given power demand.
 * Power can be positive (discharging) or negative (charging).
 */
export function calculateElectricalState(
  powerKw: number,
  state: BatteryState,
  spec: BatterySpec
): { voltageV: number; currentA: number; efficiency: number; jouleHeatingW: number; limitedPowerKw: number } {
  const ocv = calculateOcv(state.soc, spec);
  const R = state.resistanceOhm;
  
  // Physical maximum discharge power (voltage sag cannot drop below V_min)
  // V_min is 80% of nominal voltage
  const vMin = spec.nominalVoltageV * 0.8;
  const maxDischargeI = (ocv - vMin) / R;
  const maxDischargeKw = (vMin * maxDischargeI) / 1000.0;
  
  // Physical maximum charge power (voltage rise cannot exceed V_max)
  // V_max is 115% of nominal voltage
  const vMax = spec.nominalVoltageV * 1.15;
  const maxChargeI = (vMax - ocv) / R; // Current entering battery is negative
  const maxChargeKw = (vMax * maxChargeI) / 1000.0; // Negative power

  let targetPowerKw = powerKw;
  // Apply strategic envelopes and safety limits
  if (targetPowerKw > spec.maxDischargePowerKw) targetPowerKw = spec.maxDischargePowerKw;
  if (targetPowerKw < -spec.maxChargePowerKw) targetPowerKw = -spec.maxChargePowerKw;

  // Clamp power to physical boundaries (electrical capability limit)
  if (targetPowerKw > maxDischargeKw) {
    targetPowerKw = maxDischargeKw;
  } else if (targetPowerKw < -maxChargeKw) {
    targetPowerKw = -maxChargeKw;
  }

  // Solve quadratic: R*I^2 - ocv*I + P_watts = 0
  const P_watts = targetPowerKw * 1000.0;
  const discriminant = ocv * ocv - 4.0 * R * P_watts;

  let currentA = 0;
  let voltageV = ocv;

  if (discriminant >= 0 && R > 0) {
    if (targetPowerKw >= 0) {
      // Discharging (current is positive)
      currentA = (ocv - Math.sqrt(discriminant)) / (2.0 * R);
    } else {
      // Charging (current is negative)
      currentA = (ocv - Math.sqrt(discriminant)) / (2.0 * R);
    }
    voltageV = ocv - currentA * R;
  } else if (R > 0) {
    // Voltage collapse condition - fall back to short-circuit limits
    currentA = ocv / (2.0 * R);
    voltageV = ocv / 2.0;
    targetPowerKw = (voltageV * currentA) / 1000.0;
  }

  // Joule heating losses (I^2 * R)
  const jouleHeatingW = currentA * currentA * R;

  // Thermodynamic efficiency
  let efficiency = 1.0;
  if (currentA !== 0) {
    const chemicalPowerW = ocv * currentA;
    if (currentA > 0) {
      // Discharging: useful power out divided by chemical potential drop
      efficiency = (voltageV * currentA) / chemicalPowerW;
    } else {
      // Charging: chemical potential stored divided by power input
      efficiency = chemicalPowerW / (voltageV * currentA);
    }
  }
  efficiency = Math.max(0.0, Math.min(1.0, efficiency));

  return {
    voltageV,
    currentA,
    efficiency,
    jouleHeatingW,
    limitedPowerKw: targetPowerKw
  };
}

/**
 * Calculates thermal behavior over a given time step.
 * Uses a Lumped Thermal Mass model: Q_in - Q_out = C_th * dT/dt
 */
export function calculateThermalStep(
  ambientTempC: number,
  jouleHeatingW: number,
  currentTempC: number,
  coolingCoeffWK: number, // Heat transfer coefficient h (W/K)
  dtHours: number,
  spec: BatterySpec
): number {
  const dtSeconds = dtHours * 3600.0;
  
  // Approximate thermal mass for a cell module: 85000 J/K per 2.5 kWh pack-module equivalent
  const kwhScale = spec.nominalCapacityKwh / 2.5;
  const thermalMassJK = Math.max(10000, 85000 * kwhScale);

  // Net heat flow in Watts (Joule heating minus heat rejected to environment)
  const qRejectedW = coolingCoeffWK * (currentTempC - ambientTempC);
  const netHeatW = jouleHeatingW - qRejectedW;

  // Temperature derivative (K/s or C/s)
  const dTdt = netHeatW / thermalMassJK;

  const newTempC = currentTempC + dTdt * dtSeconds;
  
  // Strict physical thermal boundaries
  return Math.max(-40.0, Math.min(85.0, newTempC));
}

/**
 * Incremental degradation calculator (models coupled calendar and cycle ageing).
 */
export function calculateDegradationStep(
  state: BatteryState,
  spec: BatterySpec,
  strategy: OperatingStrategy,
  dtHours: number,
  lastCurrentA: number,
  cRate: number
): { capacityFade: number; resistanceGrowth: number; debug: DegradationState } {
  const dtDays = dtHours / 24.0;
  
  // 1. CALENDAR AGEING (Arrhenius reaction rate + high-SOC oxidation stress)
  // Activation energy for SEI growth is typically ~50,000 J/mol
  const e_a_cal = 48000.0;
  const tKelvin = state.temperatureC + TEMP_KELVIN_OFFSET;
  
  // Base pre-exponential factor calibrated to ~1.8% capacity loss per year at 25C and 50% SOC
  const K_cal_base = 0.00035; 
  const arrheniusFactor = Math.exp(-e_a_cal / (R_GAS * tKelvin)) / Math.exp(-e_a_cal / (R_GAS * (25 + TEMP_KELVIN_OFFSET)));
  
  // High-SOC voltage stress factor (accelerates oxidation at high potentials)
  let socStress = 1.0;
  if (state.soc > 0.7) {
    socStress = 1.0 + 3.0 * Math.pow((state.soc - 0.7) / 0.3, 2);
  } else if (state.soc < 0.2) {
    // Low-SOC stress (minor calendar anode degradation)
    socStress = 1.0 + 0.5 * Math.pow((0.2 - state.soc) / 0.2, 1.5);
  }

  // Calendar capacity fade increment (diffusion-limited SEI growth follows sqrt(t))
  // dC_cal = K * dt / (2 * sqrt(t))
  const ageDaysReg = Math.max(state.calendarAgeDays, 0.1);
  const calFadeRate = K_cal_base * arrheniusFactor * socStress;
  const deltaCalFade = calFadeRate * (0.5 / Math.sqrt(ageDaysReg)) * dtDays;

  // 2. CYCLE AGEING
  // Mechanical strain due to volume expansion (intercalation stress)
  // DoD effect: proportional to DoD^1.6
  // Temperature stress: high temperatures reduce mechanical strength, low temperatures trigger lithium plating
  
  const absCurrent = Math.abs(state.currentA);
  const absCRate = Math.abs(cRate);
  
  // Equivalent full cycles completed in this step
  const deltaEfc = (absCurrent * dtHours) / (2.0 * (spec.nominalCapacityKwh * 1000.0 / spec.nominalVoltageV));
  
  // Baseline cycle degradation (calibrated to 3000 EFC to 80% SOH at 25C, 0.5C, 80% DoD)
  const K_cyc_base = 0.000067; 
  
  // Temperature cycle acceleration factor
  let thermalCycleFactor = 1.0;
  if (state.temperatureC > 25.0) {
    thermalCycleFactor = 1.0 + 0.03 * (state.temperatureC - 25.0);
  }
  
  // Lithium plating hazard at low temperatures when charging
  let platingStress = 1.0;
  if (state.currentA < 0 && state.temperatureC < 15.0) {
    // Severe acceleration under high C-rates at cold temps
    platingStress = 1.0 + 5.0 * Math.pow((15.0 - state.temperatureC) / 15.0, 2) * Math.pow(absCRate, 1.5);
  }

  // C-rate mechanical fatigue factor
  const cRateFactor = Math.pow(Math.max(1.0, absCRate / 0.5), 1.3);

  // Depth-of-discharge stress factor
  // Track continuous depth-of-discharge estimation based on active SOC deviations
  const doDStress = Math.pow(state.soc - 0.5, 2) * 4.0; // max 1.0 stress for full range
  
  const deltaCycFade = K_cyc_base * deltaEfc * thermalCycleFactor * platingStress * cRateFactor * (1.0 + doDStress);

  // Total Capacity Fade in this step
  const capacityFade = deltaCalFade + deltaCycFade;

  // 3. RESISTANCE GROWTH
  // Dynamic resistance growth feedback: SEI layer thickening directly scales resistance.
  // SEI growth resistance factor is highly correlated with capacity fade
  const deltaResistanceGrowth = capacityFade * 1.6 * (1.0 + 0.05 * Math.max(0.0, state.temperatureC - 35.0));

  const debug: DegradationState = {
    calendarFade: deltaCalFade,
    cycleFade: deltaCycFade,
    thermalFade: state.temperatureC > 35.0 ? capacityFade * 0.25 : 0.0,
    highSocFade: state.soc > 0.8 ? capacityFade * 0.35 : 0.0,
    highCRateFade: absCRate > 1.0 ? capacityFade * 0.2 : 0.0,
    totalCapacityFade: capacityFade,
    resistanceGrowth: deltaResistanceGrowth
  };

  return {
    capacityFade,
    resistanceGrowth: deltaResistanceGrowth,
    debug
  };
}

/**
 * Implements the core Optimization Engine decisions.
 * Given a target power demand, evaluates operating strategies to calculate an
 * optimal operating point (safety envelope compliance, thermal protection, lifetime preservation).
 */
export function optimizeOperatingPoint(
  requestedPowerKw: number,
  state: BatteryState,
  spec: BatterySpec,
  strategy: OperatingStrategy,
  gridElectricityCostUsd: number = 0.15
): { batteryPowerKw: number; gridPowerKw: number; expectedDegradationCostUsd: number; totalCostUsd: number } {
  
  // Power limits per strategy
  let allowedMaxDischargePower = spec.maxDischargePowerKw;
  let allowedMaxChargePower = spec.maxChargePowerKw;
  let coolingCoeffWK = 20.0; // Default cooling capacity

  // Strategic Operating Envelope adjustments
  switch (strategy) {
    case 'ULTRA_LONG_LIFE':
      // Heavily throttle C-rates and clamp SOC windows to 25%-75%
      allowedMaxDischargePower = spec.maxDischargePowerKw * 0.4;
      allowedMaxChargePower = spec.maxChargePowerKw * 0.3;
      coolingCoeffWK = 45.0; // Max active cooling
      break;
    case 'LONG_LIFE':
      // Moderate C-rates and clamp SOC windows to 20%-85%
      allowedMaxDischargePower = spec.maxDischargePowerKw * 0.65;
      allowedMaxChargePower = spec.maxChargePowerKw * 0.5;
      coolingCoeffWK = 35.0; // High active cooling
      break;
    case 'ECONOMIC':
      // Dynamic optimisation considering grid costs vs battery degradation costs
      allowedMaxDischargePower = spec.maxDischargePowerKw * 0.9;
      allowedMaxChargePower = spec.maxChargePowerKw * 0.9;
      coolingCoeffWK = 25.0;
      break;
    case 'BALANCED':
    default:
      // Standard manufacturer limits
      allowedMaxDischargePower = spec.maxDischargePowerKw * 0.85;
      allowedMaxChargePower = spec.maxChargePowerKw * 0.85;
      coolingCoeffWK = 25.0;
      break;
  }

  // Safety Envelope Override (BMS protection)
  // Thermal protection: clamp power if temperature approaches limits
  if (state.temperatureC > spec.maxTempC - 8.0) {
    const scale = Math.max(0.0, (spec.maxTempC - state.temperatureC) / 8.0);
    allowedMaxDischargePower *= scale;
    allowedMaxChargePower *= scale;
  } else if (state.temperatureC < spec.minTempC + 5.0) {
    const scale = Math.max(0.0, (state.temperatureC - spec.minTempC) / 5.0);
    allowedMaxChargePower *= scale; // Throttle charging specifically to prevent plating
  }

  // SOC boundary protection: clamp power to prevent overdischarge / overcharge
  if (state.soc >= spec.maxSoc - 0.05) {
    const scale = Math.max(0.0, (spec.maxSoc - state.soc) / 0.05);
    allowedMaxChargePower *= scale;
  } else if (state.soc <= spec.minSoc + 0.05) {
    const scale = Math.max(0.0, (state.soc - spec.minSoc) / 0.05);
    allowedMaxDischargePower *= scale;
  }

  // Calculate battery share vs grid share
  let batteryPowerKw = requestedPowerKw;
  if (batteryPowerKw > 0) {
    // Discharging
    batteryPowerKw = Math.min(batteryPowerKw, allowedMaxDischargePower);
  } else {
    // Charging
    batteryPowerKw = Math.max(batteryPowerKw, -allowedMaxChargePower);
  }

  // Remaining power must go to/from the Grid
  const gridPowerKw = requestedPowerKw - batteryPowerKw;

  // 4. ECONOMIC DEGRADATION COST EVALUATION
  // Calculate potential SOH degradation of this operation step (assuming 1 hour equivalent)
  const fakeStateForEvaluation = { ...state, powerKw: batteryPowerKw };
  // Find current representing this power
  const elec = calculateElectricalState(batteryPowerKw, state, spec);
  fakeStateForEvaluation.currentA = elec.currentA;
  fakeStateForEvaluation.voltageV = elec.voltageV;
  
  const cRate = Math.abs(elec.currentA) / (spec.nominalCapacityKwh * 1000.0 / spec.nominalVoltageV);
  const degResult = calculateDegradationStep(fakeStateForEvaluation, spec, strategy, 1.0, state.currentA, cRate);
  
  // Cost = (Capacity loss / Nominal Capacity) * Battery Replacement Cost
  const capLossFraction = degResult.capacityFade;
  const expectedDegradationCostUsd = capLossFraction * spec.replacementCostUsd;

  // Cost of importing energy from grid
  const gridCostUsd = gridPowerKw > 0 ? gridPowerKw * 1.0 * gridElectricityCostUsd : 0.0;
  
  // Total economic cost (direct grid cost + long-term battery physical degradation cost)
  const totalCostUsd = gridCostUsd + expectedDegradationCostUsd;

  // If strategy is economic, we can dynamically reduce battery power output further
  // if degradation cost exceeds the price of grid electricity!
  let optimalBatteryPowerKw = batteryPowerKw;
  let optimalGridPowerKw = gridPowerKw;
  let optimalDegCost = expectedDegradationCostUsd;
  let optimalTotalCost = totalCostUsd;

  if (strategy === 'ECONOMIC' && requestedPowerKw > 0) {
    // If the degradation cost of outputting the final 50kW is higher than purchasing from grid:
    // Let's check 3 operating points: full battery, half-grid, full-grid
    const gridOnlyCost = requestedPowerKw * 1.0 * gridElectricityCostUsd;
    if (gridOnlyCost < totalCostUsd) {
      optimalBatteryPowerKw = 0;
      optimalGridPowerKw = requestedPowerKw;
      optimalDegCost = 0;
      optimalTotalCost = gridOnlyCost;
    }
  }

  return {
    batteryPowerKw: optimalBatteryPowerKw,
    gridPowerKw: optimalGridPowerKw,
    expectedDegradationCostUsd: optimalDegCost,
    totalCostUsd: optimalTotalCost
  };
}
