/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface BatterySpec {
  nominalCapacityKwh: number;
  nominalVoltageV: number;
  maxChargePowerKw: number;
  maxDischargePowerKw: number;
  minSoc: number; // e.g. 0.0
  maxSoc: number; // e.g. 1.0
  minTempC: number;
  maxTempC: number;
  nominalResistanceOhm: number;
  targetLifetimeYears: number;
  targetEndofLifeSoh: number; // e.g. 0.80
  replacementCostUsd: number;
}

export interface BatteryState {
  timeHours: number;
  soc: number;
  soh: number; // Overall State of Health (0.0 to 1.0)
  sohCapacity: number; // State of Health based on capacity fade (0.0 to 1.0)
  sohResistance: number; // State of Health based on resistance growth (0.0 to 1.0)
  voltageV: number;
  currentA: number;
  powerKw: number;
  temperatureC: number;
  capacityKwh: number;
  resistanceOhm: number;
  cumulativeEnergyInKwh: number;
  cumulativeEnergyOutKwh: number;
  equivalentFullCycles: number;
  calendarAgeDays: number;
}

export interface CycleRecord {
  startSoc: number;
  endSoc: number;
  depthOfDischarge: number;
  averageTemperatureC: number;
  averageCurrentA: number;
  durationHours: number;
  energyThroughputKwh: number;
}

export interface DegradationState {
  calendarFade: number;
  cycleFade: number;
  thermalFade: number;
  highSocFade: number;
  highCRateFade: number;
  totalCapacityFade: number;
  resistanceGrowth: number;
}

export type OperatingStrategy =
  | 'AGGRESSIVE'
  | 'BALANCED'
  | 'LONG_LIFE'
  | 'ULTRA_LONG_LIFE'
  | 'ECONOMIC';

export interface SimulationStep {
  timeHours: number;
  soc: number;
  soh: number;
  voltageV: number;
  currentA: number;
  powerKw: number;
  temperatureC: number;
  capacityKwh: number;
  resistanceOhm: number;
  calendarFade: number;
  cycleFade: number;
  totalCapacityFade: number;
  resistanceGrowth: number;
  cumulativeEnergyOutKwh: number;
}

export interface SimulationSummary {
  strategy: OperatingStrategy;
  totalEnergyDeliveredKwh: number;
  totalCycles: number;
  finalSoh: number;
  finalResistanceOhm: number;
  averageTemperatureC: number;
  maxTemperatureC: number;
  estimatedLifetimeYears: number;
  lifetimeEnergyYield: number; // delivered_kwh / initial_capacity_kwh
  energyPerUnitDegradation: number; // delivered_kwh / capacity_loss_kwh
  netEconomicValueUsd: number; // Revenue minus energy purchase cost and degradation replacement cost
}

export interface MonteCarloRun {
  runId: number;
  lifetimeYears: number;
  totalEnergyKwh: number;
  sohTimeline: { year: number; soh: number }[];
}

export interface MonteCarloStats {
  expectedLifetimeYears: number;
  medianLifetimeYears: number;
  percentile5LifetimeYears: number;
  percentile95LifetimeYears: number;
  probSohGt80After10Years: number;
  probSohGt80After15Years: number;
  probSohGt80After20Years: number;
}
