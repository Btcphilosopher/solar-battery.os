/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Interactive Scientific Dashboard for the LONG-LIFE BATTERY ENGINE.
 * Immersive UI Dark Cybernetic Theme.
 */

import { useState, useEffect, useRef } from 'react';
import { 
  Zap, 
  Thermometer, 
  Activity, 
  RotateCcw, 
  TrendingUp, 
  Compass, 
  HelpCircle, 
  ArrowRight, 
  ShieldCheck, 
  DollarSign, 
  Layers, 
  AlertTriangle,
  Cpu,
  RefreshCw,
  Send,
  Terminal
} from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid
} from 'recharts';
import { BatterySpec, SimulationStep, SimulationSummary, OperatingStrategy, MonteCarloRun, MonteCarloStats } from './types';

// Default Nominal Battery Parameters
const DEFAULT_SPEC: BatterySpec = {
  nominalCapacityKwh: 120.0,
  nominalVoltageV: 380.0,
  maxChargePowerKw: 80.0,
  maxDischargePowerKw: 160.0,
  minSoc: 0.0,
  maxSoc: 1.0,
  minTempC: -15.0,
  maxTempC: 60.0,
  nominalResistanceOhm: 0.035,
  targetLifetimeYears: 15.0,
  targetEndofLifeSoh: 0.80,
  replacementCostUsd: 18000.0,
};

export default function App() {
  // Config State
  const [spec, setSpec] = useState<BatterySpec>(DEFAULT_SPEC);
  const [strategy, setStrategy] = useState<OperatingStrategy>('LONG_LIFE');
  const [durationYears, setDurationYears] = useState<number>(10);
  const [ambientTempC, setAmbientTempC] = useState<number>(20.0);
  
  // Dashboard Metrics & Simulation State
  const [activeTab, setActiveTab] = useState<'simulation' | 'montecarlo' | 'envelope' | 'assistant'>('simulation');
  const [loading, setLoading] = useState<boolean>(false);
  const [steps, setSteps] = useState<SimulationStep[]>([]);
  const [summary, setSummary] = useState<SimulationSummary | null>(null);
  
  // Monte Carlo State
  const [mcRuns, setMcRuns] = useState<MonteCarloRun[]>([]);
  const [mcStats, setMcStats] = useState<MonteCarloStats | null>(null);
  const [mcLoading, setMcLoading] = useState<boolean>(false);

  // Operating Envelope Hotspots
  const [envelopeGrid, setEnvelopeGrid] = useState<{ soc: number; temp: number; hourlyFadePpm: number; risk: string }[]>([]);
  const [envelopeLoading, setEnvelopeLoading] = useState<boolean>(false);

  // AI Assistant Chat State
  const [chatInput, setChatInput] = useState<string>('');
  const [chatHistory, setChatHistory] = useState<{ role: 'user' | 'assistant'; text: string }[]>([
    {
      role: 'assistant',
      text: "Greetings. I am your AI Electrochemical Consultant. Ask me any hard-tech questions regarding lithium-plating kinetics, SEI passivation layer growth, thermal management stress, or optimal operational windows based on your simulation run."
    }
  ]);
  const [aiLoading, setAiLoading] = useState<boolean>(false);

  // Live Telemetry Rolling Terminal State
  const [terminalLogs, setTerminalLogs] = useState<string[]>([
    "[SYS] Engine core bootstrapped.",
    "[SYS] Models R_CAP_FADE and THERMO_COUPLING loaded.",
    "[SYS] Ready to compute physical cell kinetics."
  ]);
  const terminalEndRef = useRef<HTMLDivElement>(null);

  // Dynamic log pushing function
  const pushLog = (message: string) => {
    const timestamp = new Date().toLocaleTimeString();
    setTerminalLogs(prev => [...prev, `[${timestamp}] ${message}`].slice(-25));
  };

  // Auto-scroll terminal log to bottom
  useEffect(() => {
    terminalEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [terminalLogs]);

  // Periodic random raw telemetry logs to make the terminal feel alive
  useEffect(() => {
    const interval = setInterval(() => {
      const cellId = Math.floor(Math.random() * 96) + 1;
      const v = (3.7 + Math.random() * 0.4).toFixed(3);
      const temp = (ambientTempC + (Math.random() * 8)).toFixed(1);
      const isSohOk = summary ? (summary.finalSoh > 0.85) : true;
      const logs = [
        `[TEL] Cell #${cellId} voltage state: ${v} V, temp: ${temp} °C`,
        `[TEL] Module #${Math.floor(Math.random() * 8) + 1} monitoring link heartbeat ok`,
        `[SYS] SOH calculation loop active: status ${isSohOk ? 'NOMINAL' : 'DEGRADATION_ALARM'}`
      ];
      pushLog(logs[Math.floor(Math.random() * logs.length)]);
    }, 8000);
    return () => clearInterval(interval);
  }, [ambientTempC, summary]);

  // Trigger initial simulation run on load
  useEffect(() => {
    handleRunSimulation();
  }, []);

  const handleRunSimulation = async () => {
    setLoading(true);
    pushLog(`[SIM] Initializing dynamic ${durationYears}-year simulation run at ${ambientTempC}°C...`);
    try {
      const response = await fetch('/api/simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          spec,
          strategy,
          durationYears,
          averageAmbientTempC: ambientTempC,
        }),
      });
      const data = await response.json();
      if (data.steps) {
        setSteps(data.steps);
        setSummary(data.summary);
        pushLog(`[SYS] Solver complete. SOH retained: ${(data.summary.finalSoh * 100).toFixed(1)}%. Net profit: $${Math.round(data.summary.netEconomicValueUsd).toLocaleString()}`);
      }
    } catch (e) {
      console.error('Simulation execution failed:', e);
      pushLog('[ERROR] Simulation core reported error resolving ODEs.');
    } finally {
      setLoading(false);
    }
  };

  const handleRunMonteCarlo = async () => {
    setMcLoading(true);
    pushLog("[MC] Initiating 150 stochastically jittered simulation profiles...");
    try {
      const response = await fetch('/api/monte-carlo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          spec,
          strategy,
          runsCount: 150,
        }),
      });
      const data = await response.json();
      if (data.runs) {
        setMcRuns(data.runs);
        setMcStats(data.stats);
        pushLog(`[MC] Statistics loaded. Median survival: ${data.stats.medianLifetimeYears.toFixed(1)} years. 90% confidence range established.`);
      }
    } catch (e) {
      console.error('Monte Carlo execution failed:', e);
      pushLog('[ERROR] Monte Carlo solver engine timed out.');
    } finally {
      setMcLoading(false);
    }
  };

  const handleLoadEnvelope = async () => {
    setEnvelopeLoading(true);
    pushLog("[SYS] Resolving 100-point operating envelope matrix (SOC × Temp)...");
    try {
      const response = await fetch('/api/envelope', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ spec }),
      });
      const data = await response.json();
      if (Array.isArray(data)) {
        setEnvelopeGrid(data);
        pushLog("[SYS] Surface grid solved. Anode risk boundaries categorized.");
      }
    } catch (e) {
      console.error('Operating Envelope discovery failed:', e);
      pushLog('[ERROR] Local search algorithm reported convergence failure.');
    } finally {
      setEnvelopeLoading(false);
    }
  };

  // Run extra tabs calculations on tab switch
  const handleTabChange = (tab: 'simulation' | 'montecarlo' | 'envelope' | 'assistant') => {
    setActiveTab(tab);
    pushLog(`[SYS] Workspace viewpoint switched to: Tab #${tab.toUpperCase()}`);
    if (tab === 'montecarlo' && mcRuns.length === 0) {
      handleRunMonteCarlo();
    } else if (tab === 'envelope' && envelopeGrid.length === 0) {
      handleLoadEnvelope();
    }
  };

  const handleSendChatMessage = async () => {
    if (!chatInput.trim()) return;
    const userMessage = chatInput;
    setChatInput('');
    setChatHistory(prev => [...prev, { role: 'user', text: userMessage }]);
    setAiLoading(true);
    pushLog(`[AI] Transmitting custom profile parameters to Gemini core...`);

    try {
      const response = await fetch('/api/gemini/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: userMessage,
          batterySpec: spec,
          simulationSummary: summary,
        }),
      });
      const data = await response.json();
      if (data.text) {
        setChatHistory(prev => [...prev, { role: 'assistant', text: data.text }]);
        pushLog(`[AI] Response synthesized successfully.`);
      } else if (data.error) {
        setChatHistory(prev => [...prev, { role: 'assistant', text: `Consultation Unavailable: ${data.error}` }]);
        pushLog(`[WARN] Gemini AI model returned a workspace access error.`);
      }
    } catch (e) {
      setChatHistory(prev => [...prev, { role: 'assistant', text: 'Connection failed. Please verify server is online.' }]);
      pushLog(`[ERROR] AI handshake aborted. Network timeout.`);
    } finally {
      setAiLoading(false);
    }
  };

  const handlePresetQuery = (query: string) => {
    setChatInput(query);
    pushLog(`[SYS] Formulating template diagnostic query.`);
  };

  // Physical parameter adjust handlers
  const updateSpecField = (field: keyof BatterySpec, val: number) => {
    setSpec(prev => ({
      ...prev,
      [field]: val
    }));
    pushLog(`[SYS] Adjusted core electrochemical parameter [${field}] to: ${val}`);
  };

  return (
    <div className="min-h-screen bg-[#050608] text-slate-300 flex flex-col font-sans p-6 overflow-hidden">
      {/* Immersive Theme Header */}
      <header className="flex flex-col sm:flex-row justify-between items-start sm:items-end border-b border-white/10 pb-4 mb-6">
        <div>
          <h1 className="text-xs tracking-[0.3em] uppercase text-cyan-500 font-bold mb-1">Scientific Optimization Engine</h1>
          <p className="text-3xl font-light tracking-tighter text-white">
            LONG-LIFE <span className="font-bold text-cyan-400">BATTERY ENGINE</span>
          </p>
        </div>
        <div className="flex gap-8 mt-4 sm:mt-0 text-left sm:text-right font-mono">
          <div>
            <p className="text-[10px] uppercase tracking-widest text-slate-500 mb-1">Engine Status</p>
            <p className={`text-sm font-mono ${loading ? 'text-amber-400 animate-pulse' : 'text-emerald-400'}`}>
              {loading ? 'SOLVING_SYSTEM' : 'NOMINAL_OP_ENV'}
            </p>
          </div>
          <div>
            <p className="text-[10px] uppercase tracking-widest text-slate-500 mb-1">Compute Load</p>
            <p className="text-sm text-white">14.2 GFLOPs</p>
          </div>
        </div>
      </header>

      {/* Main Multi-Column Grid */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-6 min-h-0 overflow-y-auto lg:overflow-hidden">
        
        {/* COLUMN 1: CONTROLS & SPECIFICATION ENVELOPE */}
        <aside className="lg:col-span-3 flex flex-col gap-6 overflow-y-auto pr-1">
          {/* Strategy Selection block */}
          <div className="bg-white/5 border border-white/10 p-4 rounded-lg flex flex-col gap-3">
            <div>
              <p className="text-[10px] uppercase tracking-widest text-cyan-500 font-bold mb-1">Operating Envelope Options</p>
              <p className="text-[11px] text-slate-400">Adjust the power limits and voltage cutoffs to balance wear.</p>
            </div>
            
            <div className="space-y-2">
              {[
                { id: 'ULTRA_LONG_LIFE', title: 'ULTRA_LONG_LIFE', desc: 'Slightly constrained performance, minimal SEI degradation' },
                { id: 'LONG_LIFE', title: 'LONG_LIFE', desc: 'Recommended: balance thermal kinetics & charge cycles' },
                { id: 'BALANCED', title: 'BALANCED_STATE', desc: 'Manufacturer nominal parameters, default wear parameters' },
                { id: 'ECONOMIC', title: 'ECONOMIC_ARBITRAGE', desc: 'Continuous price tracking vs long-term degradation costs' },
                { id: 'AGGRESSIVE', title: 'AGGRESSIVE_C_RATE', desc: 'Maximum power delivery, accelerated lithium-plating kinetics' }
              ].map(opt => (
                <button
                  key={opt.id}
                  onClick={() => {
                    setStrategy(opt.id as OperatingStrategy);
                    pushLog(`[OPT] Operating Strategy set to ${opt.id}`);
                  }}
                  className={`w-full text-left p-3 rounded-lg border transition-all ${
                    strategy === opt.id 
                      ? 'border-cyan-500/40 bg-cyan-500/10 shadow-[inset_0_0_12px_rgba(6,182,212,0.15)]' 
                      : 'border-white/5 bg-white/5 hover:bg-white/10'
                  }`}
                >
                  <div className="flex justify-between items-center mb-0.5">
                    <span className={`text-[11px] font-mono font-bold ${strategy === opt.id ? 'text-cyan-400' : 'text-white'}`}>
                      {opt.title}
                    </span>
                    {strategy === opt.id && <span className="h-2 w-2 bg-cyan-400 rounded-full shadow-[0_0_8px_rgba(6,182,212,0.8)]"></span>}
                  </div>
                  <span className="text-[10px] text-slate-400 block leading-tight">{opt.desc}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Model Calibration / Spec Parameters block */}
          <div className="bg-white/5 border border-white/10 p-4 rounded-lg flex flex-col gap-4">
            <p className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">Calibration Parameters</p>
            <div className="space-y-3.5">
              <div>
                <p className="text-[10px] text-slate-500 mb-1 font-mono uppercase">NOMINAL_CAP (kWh)</p>
                <input
                  type="number"
                  value={spec.nominalCapacityKwh}
                  onChange={(e) => updateSpecField('nominalCapacityKwh', Number(e.target.value))}
                  className="w-full text-xs px-3 py-2 bg-black/40 border border-white/10 rounded text-white focus:outline-none focus:border-cyan-500 font-mono"
                />
              </div>
              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <p className="text-[10px] text-slate-500 mb-1 font-mono uppercase">VOLTAGE_V</p>
                  <input
                    type="number"
                    value={spec.nominalVoltageV}
                    onChange={(e) => updateSpecField('nominalVoltageV', Number(e.target.value))}
                    className="w-full text-xs px-3 py-2 bg-black/40 border border-white/10 rounded text-white focus:outline-none focus:border-cyan-500 font-mono"
                  />
                </div>
                <div>
                  <p className="text-[10px] text-slate-500 mb-1 font-mono uppercase">MAX_POWER_KW</p>
                  <input
                    type="number"
                    value={spec.maxDischargePowerKw}
                    onChange={(e) => updateSpecField('maxDischargePowerKw', Number(e.target.value))}
                    className="w-full text-xs px-3 py-2 bg-black/40 border border-white/10 rounded text-white focus:outline-none focus:border-cyan-500 font-mono"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <p className="text-[10px] text-slate-500 mb-1 font-mono uppercase">TARGET_SOH_EOL</p>
                  <input
                    type="number"
                    step="0.05"
                    value={spec.targetEndofLifeSoh}
                    onChange={(e) => updateSpecField('targetEndofLifeSoh', Number(e.target.value))}
                    className="w-full text-xs px-3 py-2 bg-black/40 border border-white/10 rounded text-white focus:outline-none focus:border-cyan-500 font-mono"
                  />
                </div>
                <div>
                  <p className="text-[10px] text-slate-500 mb-1 font-mono uppercase">REPLACEMENT_USD</p>
                  <input
                    type="number"
                    value={spec.replacementCostUsd}
                    onChange={(e) => updateSpecField('replacementCostUsd', Number(e.target.value))}
                    className="w-full text-xs px-3 py-2 bg-black/40 border border-white/10 rounded text-white focus:outline-none focus:border-cyan-500 font-mono"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Environmental Stress Parameters block */}
          <div className="bg-white/5 border border-white/10 p-4 rounded-lg flex flex-col gap-4">
            <p className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">Environmental Stress Fields</p>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-[10px] font-mono text-slate-400 mb-1">
                  <span>AMBIENT_TEMP</span>
                  <span className="text-white font-bold">{ambientTempC}°C</span>
                </div>
                <input
                  type="range"
                  min="-5"
                  max="45"
                  step="1"
                  value={ambientTempC}
                  onChange={(e) => {
                    setAmbientTempC(Number(e.target.value));
                    pushLog(`[SYS] Ambient temperature adjusted to: ${e.target.value}°C`);
                  }}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>
              <div>
                <div className="flex justify-between text-[10px] font-mono text-slate-400 mb-1">
                  <span>TIMELINE_WINDOW</span>
                  <span className="text-white font-bold">{durationYears} Years</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="20"
                  step="1"
                  value={durationYears}
                  onChange={(e) => {
                    setDurationYears(Number(e.target.value));
                    pushLog(`[SYS] Timeline projection window adjusted to: ${e.target.value} years`);
                  }}
                  className="w-full accent-cyan-400 cursor-pointer"
                />
              </div>
            </div>
          </div>

          {/* Core Solver Exec Button */}
          <div>
            <button
              onClick={handleRunSimulation}
              disabled={loading}
              className="w-full bg-cyan-500 hover:bg-cyan-400 disabled:bg-slate-800 disabled:text-slate-500 text-black font-extrabold py-3.5 px-4 rounded-lg text-xs tracking-widest uppercase transition-all shadow-[0_0_12px_rgba(6,182,212,0.3)] flex items-center justify-center gap-2 cursor-pointer"
            >
              {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Activity className="w-4 h-4" />}
              Solve System Lifecycle
            </button>
          </div>
        </aside>

        {/* COLUMN 2: MAIN WORKSPACE TAB PANELS */}
        <main className="lg:col-span-6 flex flex-col gap-6 min-h-0">
          
          {/* Scientific Tab bar Navigation */}
          <nav className="flex border-b border-white/10 gap-2 overflow-x-auto">
            {[
              { id: 'simulation', label: 'LIFETIME SIMULATION', icon: Activity },
              { id: 'montecarlo', label: 'MONTE CARLO FORECASTS', icon: TrendingUp },
              { id: 'envelope', label: 'OPERATING ENVELOPES', icon: Layers },
              { id: 'assistant', label: 'AI SCIENTIST ASSISTANT', icon: HelpCircle }
            ].map(tab => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => handleTabChange(tab.id as any)}
                  className={`flex items-center gap-2 px-5 py-3.5 text-xs font-mono font-bold tracking-tight border-b-2 transition-all whitespace-nowrap cursor-pointer ${
                    activeTab === tab.id 
                      ? 'border-cyan-500 text-cyan-400 bg-white/5' 
                      : 'border-transparent text-slate-400 hover:text-white'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  {tab.label}
                </button>
              );
            })}
          </nav>

          {/* Core Dynamic Content display window */}
          <div className="flex-1 overflow-y-auto space-y-6">
            
            {/* TAB 1: LIFETIME SIMULATION OUTPUT */}
            {activeTab === 'simulation' && (
              <div className="space-y-6">
                
                {/* 4 Immersive Metric Card Blocks */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <div className="bg-black/40 border border-white/10 rounded-lg p-4 relative overflow-hidden">
                    <div className="absolute inset-0 opacity-5 pointer-events-none" style={{ backgroundImage: 'radial-gradient(#ffffff 1px, transparent 1px)', backgroundSize: '16px 16px' }}></div>
                    <p className="text-[10px] uppercase tracking-wider text-slate-500 font-mono">ENERGY_DELIVERED</p>
                    <p className="text-xl font-bold text-white mt-1">
                      {summary ? (summary.totalEnergyDeliveredKwh / 1000.0).toFixed(2) : '0.00'} <span className="text-xs text-cyan-400">MWh</span>
                    </p>
                    <p className="text-[9px] text-slate-500 mt-1">Lifetime throughput yield</p>
                  </div>
                  
                  <div className="bg-black/40 border border-white/10 rounded-lg p-4 relative overflow-hidden">
                    <div className="absolute inset-0 opacity-5 pointer-events-none" style={{ backgroundImage: 'radial-gradient(#ffffff 1px, transparent 1px)', backgroundSize: '16px 16px' }}></div>
                    <p className="text-[10px] uppercase tracking-wider text-slate-500 font-mono">FINAL_SOH</p>
                    <p className="text-xl font-bold text-emerald-400 mt-1">
                      {summary ? (summary.finalSoh * 100.0).toFixed(1) : '0.0'}<span className="text-xs text-emerald-400">%</span>
                    </p>
                    <p className="text-[9px] text-slate-500 mt-1">Capacity retention limit</p>
                  </div>

                  <div className="bg-black/40 border border-white/10 rounded-lg p-4 relative overflow-hidden">
                    <div className="absolute inset-0 opacity-5 pointer-events-none" style={{ backgroundImage: 'radial-gradient(#ffffff 1px, transparent 1px)', backgroundSize: '16px 16px' }}></div>
                    <p className="text-[10px] uppercase tracking-wider text-slate-500 font-mono">CYCLE_COUNT</p>
                    <p className="text-xl font-bold text-white mt-1">
                      {summary ? Math.round(summary.totalCycles).toLocaleString() : '0'}<span className="text-xs text-slate-500"> EFC</span>
                    </p>
                    <p className="text-[9px] text-slate-500 mt-1">Full nominal cycles run</p>
                  </div>

                  <div className="bg-black/40 border border-white/10 rounded-lg p-4 relative overflow-hidden">
                    <div className="absolute inset-0 opacity-5 pointer-events-none" style={{ backgroundImage: 'radial-gradient(#ffffff 1px, transparent 1px)', backgroundSize: '16px 16px' }}></div>
                    <p className="text-[10px] uppercase tracking-wider text-slate-500 font-mono">NET_VALUE</p>
                    <p className="text-xl font-bold text-cyan-400 mt-1">
                      {summary ? `$${Math.round(summary.netEconomicValueUsd).toLocaleString()}` : '$0'}
                    </p>
                    <p className="text-[9px] text-slate-500 mt-1">Arbitrage minus wear costs</p>
                  </div>
                </div>

                {/* Simulated Charts Displays */}
                <div className="space-y-6">
                  {/* Chart A: Capacity Fade & Resistance */}
                  <div className="bg-black/40 border border-white/10 rounded-lg p-5">
                    <div className="mb-4">
                      <p className="text-[10px] uppercase tracking-widest text-cyan-400 font-bold font-mono">Capacity Decay & Impedance Rise</p>
                      <p className="text-[11px] text-slate-400">Simulates active capacity retention (SOH) matched with internal impedance feedback loops.</p>
                    </div>
                    <div className="h-64 w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={steps}>
                          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                          <XAxis 
                            dataKey="timeHours" 
                            tickFormatter={(v) => `${(v / 8760).toFixed(0)}y`}
                            tick={{ fontSize: 10, fill: '#94a3b8' }}
                          />
                          <YAxis 
                            yAxisId="left" 
                            domain={[0.7, 1.02]} 
                            tickFormatter={(v) => `${(v * 100).toFixed(0)}%`}
                            tick={{ fontSize: 10, fill: '#94a3b8' }}
                          />
                          <YAxis 
                            yAxisId="right" 
                            orientation="right" 
                            domain={[0, 100]} 
                            tickFormatter={(v) => `+${v.toFixed(0)}%`}
                            tick={{ fontSize: 10, fill: '#94a3b8' }}
                          />
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#0b0f19', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '6px' }}
                            labelStyle={{ color: '#ffffff', fontSize: '11px', fontFamily: 'monospace' }}
                            itemStyle={{ fontSize: '11px' }}
                            formatter={(value: any, name: any) => {
                              if (name === 'soh') return [`${(value * 100).toFixed(1)}%`, 'Capacity (SOH)'];
                              if (name === 'resistanceGrowth') return [`+${(value * 100).toFixed(1)}%`, 'Resistance Growth'];
                              return [value, name];
                            }}
                            labelFormatter={(v) => `PROJECTION_POINT: ${(Number(v) / 8760).toFixed(1)} Years`}
                          />
                          <Legend wrapperStyle={{ fontSize: '10px', marginTop: '10px' }} />
                          <Line yAxisId="left" type="monotone" dataKey="soh" stroke="#06b6d4" strokeWidth={2} dot={false} name="soh" />
                          <Line yAxisId="right" type="monotone" dataKey="resistanceGrowth" stroke="#f59e0b" strokeWidth={1.8} dot={false} name="resistanceGrowth" />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  {/* Chart B: Contributions */}
                  <div className="bg-black/40 border border-white/10 rounded-lg p-5">
                    <div className="mb-4">
                      <p className="text-[10px] uppercase tracking-widest text-emerald-400 font-bold font-mono">Electrochemical Wear Allocation</p>
                      <p className="text-[11px] text-slate-400">Compares degradation kinetics: Arrhenius-based Calendar wear vs Current-driven Cycle wear.</p>
                    </div>
                    <div className="h-64 w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={steps}>
                          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                          <XAxis 
                            dataKey="timeHours" 
                            tickFormatter={(v) => `${(v / 8760).toFixed(0)}y`}
                            tick={{ fontSize: 10, fill: '#94a3b8' }}
                          />
                          <YAxis 
                            tickFormatter={(v) => `${(v * 100).toFixed(2)}%`}
                            tick={{ fontSize: 10, fill: '#94a3b8' }}
                          />
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#0b0f19', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '6px' }}
                            labelStyle={{ color: '#ffffff', fontSize: '11px', fontFamily: 'monospace' }}
                            itemStyle={{ fontSize: '11px' }}
                            formatter={(value: any, name: any) => [`${(value * 100).toFixed(3)}%`, name]}
                            labelFormatter={(v) => `PROJECTION_POINT: ${(Number(v) / 8760).toFixed(1)} Years`}
                          />
                          <Legend wrapperStyle={{ fontSize: '10px', marginTop: '10px' }} />
                          <Line type="monotone" dataKey="calendarFade" stroke="#0284c7" strokeWidth={1.8} dot={false} name="Calendar wear rate (yr)" />
                          <Line type="monotone" dataKey="cycleFade" stroke="#10b981" strokeWidth={1.8} dot={false} name="Cycle fatigue wear rate (yr)" />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                </div>

                {/* Insights Panel */}
                <div className="bg-cyan-500/10 border border-cyan-500/20 rounded-lg p-5 relative overflow-hidden">
                  <div className="absolute inset-0 opacity-5 pointer-events-none" style={{ backgroundImage: 'radial-gradient(#ffffff 1px, transparent 1px)', backgroundSize: '24px 24px' }}></div>
                  <h4 className="text-[11px] font-bold uppercase tracking-wider text-cyan-400 mb-2 flex items-center gap-1.5 font-mono">
                    <Cpu className="w-4 h-4 text-cyan-400" /> SYSTEM_DEGRADATION_ANALYSIS
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs text-slate-300">
                    <div>
                      <p className="font-bold text-white mb-1 uppercase font-mono text-[10px]">LIFETIME_YIELD</p>
                      <p className="leading-relaxed text-slate-400">
                        This pack delivered <span className="font-bold text-cyan-400">{summary ? Math.round(summary.lifetimeEnergyYield) : '--'} equivalent nominal capacities</span> of useful energy over its active lifespan. Operating at {strategy} achieved a significantly higher cumulative energy yield than aggressive cycles.
                      </p>
                    </div>
                    <div>
                      <p className="font-bold text-white mb-1 uppercase font-mono text-[10px]">THERMODYNAMICS</p>
                      <p className="leading-relaxed text-slate-400">
                        Average cell core temperature remained at <span className="font-bold text-cyan-400">{summary ? summary.averageTemperatureC.toFixed(1) : '--'}°C</span>, with maximum peaks capped at <span className="font-bold text-cyan-400">{summary ? summary.maxTemperatureC.toFixed(1) : '--'}°C</span>. Lower internal temperatures effectively mitigated SEI passivation layer decomposition.
                      </p>
                    </div>
                    <div>
                      <p className="font-bold text-white mb-1 uppercase font-mono text-[10px]">ECONOMIC_BOUNDS</p>
                      <p className="leading-relaxed text-slate-400">
                        Each equivalent full cycle under this strategy costs approx <span className="font-bold text-cyan-400">${summary ? (summary.totalCycles > 0 ? (spec.replacementCostUsd * (1 - summary.finalSoh) / summary.totalCycles).toFixed(2) : '0') : '--'}</span> in localized physical degradation wear, justified dynamically against grid arbitrage opportunities.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 2: MONTE CARLO PROBABILITY FORECASTS */}
            {activeTab === 'montecarlo' && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="bg-black/40 border border-white/10 rounded-lg p-5 text-center">
                    <p className="text-[10px] text-slate-500 uppercase font-mono mb-1">Expected Survival Lifespan</p>
                    <div className="text-2xl font-bold text-white">
                      {mcStats ? `${mcStats.expectedLifetimeYears.toFixed(1)} Yrs` : 'Calculating...'}
                    </div>
                    <p className="text-[10px] text-slate-400 mt-1">Median survival threshold: {mcStats ? mcStats.medianLifetimeYears.toFixed(1) : '--'} years</p>
                  </div>
                  
                  <div className="bg-black/40 border border-white/10 rounded-lg p-5 text-center">
                    <p className="text-[10px] text-slate-500 uppercase font-mono mb-1">Confidence Range (P5 - P95)</p>
                    <div className="text-xl font-bold text-cyan-400 mt-1">
                      {mcStats ? `${mcStats.percentile5LifetimeYears.toFixed(1)} - ${mcStats.percentile95LifetimeYears.toFixed(1)} Yrs` : 'Calculating...'}
                    </div>
                    <p className="text-[10px] text-slate-400 mt-1">90% confidence statistical bounds</p>
                  </div>

                  <div className="bg-black/40 border border-white/10 rounded-lg p-5 text-center">
                    <p className="text-[10px] text-slate-500 uppercase font-mono mb-1">Probability SOH &gt; 80% @ 15 yr</p>
                    <div className="text-2xl font-bold text-white">
                      {mcStats ? `${(mcStats.probSohGt80After15Years * 100).toFixed(0)}%` : 'Calculating...'}
                    </div>
                    <p className="text-[10px] text-slate-400 mt-1">Survival probability at 10 yrs: {mcStats ? `${(mcStats.probSohGt80After10Years * 100).toFixed(0)}%` : '--'}</p>
                  </div>
                </div>

                {/* Monte Carlo Timelines Chart */}
                <div className="bg-black/40 border border-white/10 rounded-lg p-5">
                  <div className="flex justify-between items-center mb-4">
                    <div>
                      <p className="text-[10px] uppercase tracking-widest text-cyan-400 font-bold font-mono">Probabilistic SOH Decay Distribution (Ensembles)</p>
                      <p className="text-[11px] text-slate-400">Simulates 150 unique operating paths with randomized temperature spikes and demand profiles.</p>
                    </div>
                    <button
                      onClick={handleRunMonteCarlo}
                      disabled={mcLoading}
                      className="px-3 py-1.5 border border-cyan-500/40 hover:bg-cyan-500/10 text-cyan-400 rounded text-[10px] font-mono tracking-wider uppercase transition-colors cursor-pointer"
                    >
                      {mcLoading ? 'RE-RUNNING...' : 'RE-RUN FLEET MC'}
                    </button>
                  </div>

                  <div className="h-72 w-full">
                    {mcLoading ? (
                      <div className="w-full h-full flex flex-col items-center justify-center text-xs text-slate-400 gap-2">
                        <RefreshCw className="w-6 h-6 animate-spin text-cyan-400" />
                        <span className="font-mono text-[10px]">SOLVING STOCHASTIC EQUATIONS...</span>
                      </div>
                    ) : (
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart>
                          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                          <XAxis 
                            type="number" 
                            domain={[0, 25]} 
                            dataKey="year" 
                            name="Year"
                            tick={{ fontSize: 10, fill: '#94a3b8' }}
                          />
                          <YAxis 
                            domain={[0.7, 1.0]} 
                            tickFormatter={(v) => `${(v * 100).toFixed(0)}%`}
                            tick={{ fontSize: 10, fill: '#94a3b8' }}
                          />
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#0b0f19', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '6px' }}
                            labelStyle={{ color: '#ffffff', fontSize: '11px', fontFamily: 'monospace' }}
                            itemStyle={{ fontSize: '11px' }}
                            labelFormatter={(v) => `SIM_YEAR: ${v}`} 
                          />
                          {mcRuns.map((run, idx) => (
                            <Line 
                              key={run.runId} 
                              data={run.sohTimeline} 
                              type="monotone" 
                              dataKey="soh" 
                              stroke={idx === 0 ? '#06b6d4' : idx === 1 ? '#10b981' : '#64748b'} 
                              strokeWidth={idx === 0 ? 2 : 1.2} 
                              strokeOpacity={idx === 0 ? 0.9 : 0.35}
                              dot={false} 
                              name={`Ensemble Run #${run.runId}`} 
                            />
                          ))}
                        </LineChart>
                      </ResponsiveContainer>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* TAB 3: OPERATING ENVELOPES HOTSPOTS GRID */}
            {activeTab === 'envelope' && (
              <div className="space-y-6">
                <div className="bg-black/40 border border-white/10 rounded-lg p-5">
                  <div className="flex justify-between items-center mb-4">
                    <div>
                      <p className="text-[10px] uppercase tracking-widest text-cyan-400 font-bold font-mono">Multi-Dimensional Degradation Risk Matrix (SOC × Temp)</p>
                      <p className="text-[11px] text-slate-400">Hourly chemical degradation rates in Parts-Per-Million (PPM) of capacity lost.</p>
                    </div>
                    <button
                      onClick={handleLoadEnvelope}
                      disabled={envelopeLoading}
                      className="px-3 py-1.5 border border-white/10 hover:bg-white/10 text-white rounded text-[10px] font-mono cursor-pointer"
                    >
                      REFRESH MATRIX
                    </button>
                  </div>

                  {envelopeLoading ? (
                    <div className="h-64 w-full flex flex-col items-center justify-center text-xs text-slate-400 gap-2">
                      <RefreshCw className="w-6 h-6 animate-spin text-cyan-400" />
                      <span className="font-mono text-[10px]">RESOLVING ELECTROCHEMICAL SURFACE GRID...</span>
                    </div>
                  ) : (
                    <div className="grid grid-cols-10 gap-1.5 max-w-4xl mx-auto border border-white/10 p-4.5 rounded-lg bg-black/60 shadow-[0_0_24px_rgba(0,0,0,0.5)]">
                      {envelopeGrid.map((cell, idx) => {
                        let bg = 'rgba(16, 185, 129, 0.15)'; // safe
                        let border = 'border-emerald-500/20';
                        let text = 'text-emerald-400';
                        
                        if (cell.risk === 'critical') {
                          bg = 'rgba(239, 68, 68, 0.3)';
                          border = 'border-red-500/40';
                          text = 'text-red-400';
                        } else if (cell.risk === 'high') {
                          bg = 'rgba(249, 115, 22, 0.25)';
                          border = 'border-orange-500/30';
                          text = 'text-orange-400';
                        } else if (cell.risk === 'medium') {
                          bg = 'rgba(245, 158, 11, 0.2)';
                          border = 'border-yellow-500/25';
                          text = 'text-yellow-400';
                        }
                        
                        return (
                          <div
                            key={idx}
                            className={`aspect-square rounded flex flex-col items-center justify-center p-1 transition-all hover:scale-110 cursor-pointer border ${border}`}
                            style={{ backgroundColor: bg }}
                            title={`SOC: ${cell.soc}%, Temp: ${cell.temp}°C, Rate: ${cell.hourlyFadePpm} PPM/hr`}
                          >
                            <span className={`text-[10px] font-mono font-bold ${text}`}>{cell.hourlyFadePpm}</span>
                            <span className="text-[7px] text-slate-500">{cell.temp}°C</span>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  <div className="mt-6 grid grid-cols-1 md:grid-cols-4 gap-4 text-xs font-mono">
                    <div className="flex items-center gap-2.5 p-3 rounded bg-white/5 border border-emerald-500/20 text-emerald-400">
                      <span className="h-2 w-2 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.8)]"></span>
                      <div>
                        <div className="font-bold text-[10px]">Safe Zone (&lt;1.0)</div>
                        <div className="text-[9px] text-slate-400 leading-tight">Stable chemistry bounds</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2.5 p-3 rounded bg-white/5 border border-yellow-500/20 text-yellow-400">
                      <span className="h-2 w-2 rounded-full bg-yellow-500 shadow-[0_0_8px_rgba(245,158,11,0.8)]"></span>
                      <div>
                        <div className="font-bold text-[10px]">Moderate Wear (1-2.2)</div>
                        <div className="text-[9px] text-slate-400 leading-tight">Elevated temperature limits</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2.5 p-3 rounded bg-white/5 border border-orange-500/20 text-orange-400">
                      <span className="h-2 w-2 rounded-full bg-orange-500 shadow-[0_0_8px_rgba(249,115,22,0.8)]"></span>
                      <div>
                        <div className="font-bold text-[10px]">Accelerated Wear (&gt;2.2)</div>
                        <div className="text-[9px] text-slate-400 leading-tight">Anode film oxidation</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2.5 p-3 rounded bg-white/5 border border-red-500/20 text-red-400">
                      <span className="h-2 w-2 rounded-full bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.8)]"></span>
                      <div>
                        <div className="font-bold text-[10px]">Critical Zone (&gt;4.5)</div>
                        <div className="text-[9px] text-slate-400 leading-tight">Voltage stress risk</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 4: AI BATTERY SCIENTIST CONSULTATION */}
            {activeTab === 'assistant' && (
              <div className="space-y-6">
                <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
                  {/* Chat logs card */}
                  <div className="xl:col-span-3 bg-black/40 border border-white/10 rounded-lg flex flex-col h-[500px]">
                    {/* Message list */}
                    <div className="flex-1 p-6 overflow-y-auto space-y-4">
                      {chatHistory.map((msg, idx) => (
                        <div
                          key={idx}
                          className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                        >
                          <div
                            className={`max-w-[85%] rounded-lg px-4 py-3 text-xs leading-relaxed ${
                              msg.role === 'user'
                                ? 'bg-cyan-500 text-black rounded-tr-none font-medium'
                                : 'bg-white/5 text-slate-300 rounded-tl-none border border-white/10'
                            }`}
                          >
                            {msg.text}
                          </div>
                        </div>
                      ))}
                      {aiLoading && (
                        <div className="flex justify-start">
                          <div className="bg-white/5 text-slate-400 rounded-lg rounded-tl-none px-4 py-3 text-xs flex items-center gap-2 border border-white/10 font-mono">
                            <RefreshCw className="w-3.5 h-3.5 animate-spin text-cyan-400" />
                            <span>ANALYZING THERMAL AND CHEMICAL CYCLES...</span>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Chat inputs */}
                    <div className="p-4 border-t border-white/10 flex items-center gap-2">
                      <input
                        type="text"
                        placeholder="Inquire about mechanical volume strain, lithium plating triggers, etc."
                        value={chatInput}
                        onChange={(e) => setChatInput(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleSendChatMessage()}
                        className="flex-1 bg-black/40 border border-white/10 text-white rounded-lg px-4 py-3 text-xs focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400/20"
                      />
                      <button
                        onClick={handleSendChatMessage}
                        disabled={aiLoading}
                        className="bg-cyan-500 text-black hover:bg-cyan-400 p-3 rounded-lg transition-colors disabled:bg-slate-800 disabled:text-slate-500 flex items-center justify-center cursor-pointer"
                      >
                        <Send className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Scientific Diagnostic Shortcuts templates */}
                  <div className="xl:col-span-1 space-y-3.5">
                    <p className="text-[10px] font-bold uppercase tracking-widest text-cyan-400 font-mono">Preset Diagnostics</p>
                    <p className="text-[11px] text-slate-400">Inquire instantly on complex physical degradation issues:</p>
                    
                    {[
                      {
                        title: "Thermal Runaway & SOH",
                        query: "Explain the electrochemical relation between SOH capacity retention and high temperature thermal wear. Why does resistance growth accelerate?"
                      },
                      {
                        title: "Lithium Plating Kinetics",
                        query: "What cold temperature charging conditions trigger severe lithium plating? How does our platingStress factor protect the anode?"
                      },
                      {
                        title: "Optimal Window Strategy",
                        query: "Suggest an optimal restricted SOC operating window (e.g., 20% to 80%) to maximize useful energy yield over 15 years."
                      },
                      {
                        title: "Economic vs Wear Costs",
                        query: "How should I calculate if executing a 160 kW peak discharge is economically viable when compared to long-term battery degradation replacement costs?"
                      }
                    ].map((preset, idx) => (
                      <button
                        key={idx}
                        onClick={() => handlePresetQuery(preset.query)}
                        className="w-full text-left p-3.5 bg-white/5 border border-white/5 rounded-lg hover:bg-cyan-500/10 hover:border-cyan-500/30 transition-all block cursor-pointer"
                      >
                        <span className="text-xs font-mono font-bold text-white block mb-1 flex items-center gap-1.5">
                          <Compass className="w-3.5 h-3.5 text-cyan-400" /> {preset.title}
                        </span>
                        <span className="text-[10px] text-slate-400 line-clamp-2 leading-snug">{preset.query}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </main>

        {/* COLUMN 3: STATE OF HEALTH HUD & LIVE TELEMETRY terminal */}
        <aside className="lg:col-span-3 flex flex-col gap-6 shrink-0 min-h-0">
          
          {/* Prominent SOH Display Block matching template */}
          <div className="bg-cyan-500 text-black p-5 rounded-lg flex flex-col justify-between shadow-[0_0_16px_rgba(6,182,212,0.4)]">
            <div>
              <p className="text-[10px] uppercase font-bold tracking-widest mb-1 opacity-70 font-mono">State of Health (SOH)</p>
              <p className="text-5xl font-black tracking-tighter">
                {summary ? (summary.finalSoh * 100.0).toFixed(1) : '98.5'}<span className="text-xl">%</span>
              </p>
            </div>
            <div className="flex justify-between mt-4 text-[10px] font-bold border-t border-black/20 pt-2 font-mono">
              <span>SOH_RETENTION</span>
              <span>{summary ? (summary.lifetimeEnergyYield).toFixed(1) : '0.982'} CAP_W</span>
            </div>
          </div>

          {/* 4 grid metrics display HUD */}
          <div className="grid grid-cols-2 gap-3 font-mono">
            <div className="bg-white/5 border border-white/10 p-3 rounded-lg">
              <p className="text-[9px] text-slate-500 uppercase mb-0.5">Core Temp</p>
              <p className="text-base font-bold text-white">
                {summary ? summary.averageTemperatureC.toFixed(1) : '27.4'}°C
              </p>
            </div>
            <div className="bg-white/5 border border-white/10 p-3 rounded-lg">
              <p className="text-[9px] text-slate-500 uppercase mb-0.5">Internal Res</p>
              <p className="text-base font-bold text-white">
                {summary ? (summary.finalResistanceOhm * 1000).toFixed(1) : '12.4'}mΩ
              </p>
            </div>
            <div className="bg-white/5 border border-white/10 p-3 rounded-lg">
              <p className="text-[9px] text-slate-500 uppercase mb-0.5">Cycle Count</p>
              <p className="text-base font-bold text-white">
                {summary ? Math.round(summary.totalCycles).toLocaleString() : '1,842'}
              </p>
            </div>
            <div className="bg-white/5 border border-white/10 p-3 rounded-lg">
              <p className="text-[9px] text-slate-500 uppercase mb-0.5">Stress Load</p>
              <p className="text-base font-bold text-white">
                {strategy === 'AGGRESSIVE' ? '1.8 C' : strategy === 'BALANCED' ? '1.0 C' : strategy === 'ECONOMIC' ? '0.7 C' : '0.4 C'}
              </p>
            </div>
          </div>

          {/* Live Telemetry Terminal view */}
          <div className="flex-1 bg-black border border-white/10 rounded-lg p-4 font-mono text-[10px] overflow-hidden flex flex-col justify-between min-h-[220px]">
            <div className="flex justify-between items-center pb-2 border-b border-white/5 mb-2 shrink-0">
              <span className="text-slate-500 text-[9px] uppercase tracking-wider font-bold flex items-center gap-1">
                <Terminal className="w-3.5 h-3.5 text-cyan-400" /> Telemetry Live Stream
              </span>
              <span className="h-1.5 w-1.5 rounded-full bg-cyan-400 animate-ping"></span>
            </div>
            
            <div className="flex-1 overflow-y-auto space-y-1.5 text-slate-400 scrollbar-none pr-1">
              {terminalLogs.map((log, index) => {
                let color = 'text-slate-400';
                if (log.includes('[SYS]')) color = 'text-cyan-400';
                if (log.includes('[TEL]')) color = 'text-emerald-400';
                if (log.includes('[OPT]')) color = 'text-purple-400 font-bold';
                if (log.includes('[SIM]')) color = 'text-sky-300';
                if (log.includes('[ERROR]')) color = 'text-red-400 font-bold animate-pulse';
                if (log.includes('[WARN]')) color = 'text-amber-400';
                return (
                  <p key={index} className={`leading-relaxed text-[10px] break-all ${color}`}>
                    {log}
                  </p>
                );
              })}
              <div ref={terminalEndRef} />
            </div>
          </div>

        </aside>

      </div>
    </div>
  );
}
