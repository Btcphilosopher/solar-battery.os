-- ============================================================================
-- LONG-LIFE BATTERY ENGINE
-- PostgreSQL Production Schema Migration (Reproducibility & Statistical Ledger)
-- ============================================================================

-- Enable standard spatial and UUID extensions if available
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Battery System Specifications and Chemistries
CREATE TABLE battery_specifications (
    spec_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    chemistry_class VARCHAR(50) NOT NULL, -- NMC, LFP, LTO, SolidState
    nominal_capacity_kwh DOUBLE PRECISION NOT NULL,
    nominal_voltage_v DOUBLE PRECISION NOT NULL,
    max_charge_power_kw DOUBLE PRECISION NOT NULL,
    max_discharge_power_kw DOUBLE PRECISION NOT NULL,
    min_soc_boundary DOUBLE PRECISION DEFAULT 0.0,
    max_soc_boundary DOUBLE PRECISION DEFAULT 1.0,
    min_temp_c DOUBLE PRECISION DEFAULT -20.0,
    max_temp_c DOUBLE PRECISION DEFAULT 65.0,
    nominal_resistance_ohm DOUBLE PRECISION NOT NULL,
    target_lifetime_years INT NOT NULL,
    target_eol_soh DOUBLE PRECISION DEFAULT 0.80,
    replacement_cost_usd DOUBLE PRECISION NOT NULL,
    manufacturer VARCHAR(100),
    calibration_status VARCHAR(30) DEFAULT 'CALIBRATION_REQUIRED',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 2. Battery Assets (Hierarchy: Pack -> Module -> Cell)
CREATE TABLE battery_assets (
    asset_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    serial_number VARCHAR(100) UNIQUE NOT NULL,
    spec_id UUID REFERENCES battery_specifications(spec_id),
    hierarchy_level VARCHAR(20) NOT NULL CHECK (hierarchy_level IN ('pack', 'module', 'cell')),
    parent_asset_id UUID REFERENCES battery_assets(asset_id),
    commissioned_date DATE NOT NULL,
    current_status VARCHAR(30) DEFAULT 'active' CHECK (current_status IN ('active', 'degraded', 'retired', 'maintenance')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 3. Telemetry Ledger (Multi-scale high-speed ingestion)
CREATE TABLE battery_telemetry (
    telemetry_id BIGSERIAL PRIMARY KEY,
    asset_id UUID REFERENCES battery_assets(asset_id) ON DELETE CASCADE,
    timestamp_utc TIMESTAMP WITH TIME ZONE NOT NULL,
    soc DOUBLE PRECISION NOT NULL CHECK (soc >= 0.0 AND soc <= 1.0),
    soh DOUBLE PRECISION NOT NULL CHECK (soh >= 0.0 AND soh <= 1.0),
    voltage_v DOUBLE PRECISION NOT NULL,
    current_a DOUBLE PRECISION NOT NULL,
    power_kw DOUBLE PRECISION NOT NULL,
    temperature_c DOUBLE PRECISION NOT NULL,
    internal_resistance_ohm DOUBLE PRECISION NOT NULL,
    cumulative_energy_in_kwh DOUBLE PRECISION DEFAULT 0.0,
    cumulative_energy_out_kwh DOUBLE PRECISION DEFAULT 0.0
);

-- Create continuous timeseries indices for partition scaling
CREATE INDEX idx_telemetry_asset_time ON battery_telemetry(asset_id, timestamp_utc DESC);

-- 4. Deep-Cycle History Registry
CREATE TABLE cycle_history (
    cycle_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    asset_id UUID REFERENCES battery_assets(asset_id) ON DELETE CASCADE,
    start_timestamp TIMESTAMP WITH TIME ZONE NOT NULL,
    end_timestamp TIMESTAMP WITH TIME ZONE NOT NULL,
    start_soc DOUBLE PRECISION NOT NULL,
    end_soc DOUBLE PRECISION NOT NULL,
    depth_of_discharge DOUBLE PRECISION NOT NULL,
    average_temperature_c DOUBLE PRECISION NOT NULL,
    average_current_a DOUBLE PRECISION NOT NULL,
    duration_hours DOUBLE PRECISION NOT NULL,
    energy_throughput_kwh DOUBLE PRECISION NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 5. Physical Degradation Observations (Chemical Slices)
CREATE TABLE degradation_observations (
    observation_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    asset_id UUID REFERENCES battery_assets(asset_id) ON DELETE CASCADE,
    timestamp_utc TIMESTAMP WITH TIME ZONE NOT NULL,
    capacity_fade_fraction DOUBLE PRECISION NOT NULL,
    resistance_growth_fraction DOUBLE PRECISION NOT NULL,
    sei_thickness_nm DOUBLE PRECISION,
    lithium_plating_index DOUBLE PRECISION,
    measurement_method VARCHAR(50), -- EIS (Spectroscopy), Galvanic, Destructive, Estimator
    analyst_email VARCHAR(100)
);

-- 6. Simulation & Numerical Arbitrage Runs
CREATE TABLE simulation_runs (
    run_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    spec_id UUID REFERENCES battery_specifications(spec_id),
    strategy VARCHAR(30) NOT NULL, -- AGGRESSIVE, BALANCED, LONG_LIFE, ULTRA_LONG_LIFE, ECONOMIC
    duration_years DOUBLE PRECISION NOT NULL,
    ambient_temp_avg_c DOUBLE PRECISION NOT NULL,
    final_soh DOUBLE PRECISION NOT NULL,
    final_resistance_ohm DOUBLE PRECISION NOT NULL,
    total_energy_delivered_kwh DOUBLE PRECISION NOT NULL,
    total_cycles DOUBLE PRECISION NOT NULL,
    net_economic_value_usd DOUBLE PRECISION NOT NULL,
    lifetime_energy_yield DOUBLE PRECISION NOT NULL,
    software_version VARCHAR(50) NOT NULL,
    random_seed INT NOT NULL,
    completed_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 7. Lifetime Forecast Ledger (Monte Carlo & Survival Percentiles)
CREATE TABLE lifetime_predictions (
    prediction_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    asset_id UUID REFERENCES battery_assets(asset_id),
    strategy VARCHAR(30) NOT NULL,
    expected_lifetime_years DOUBLE PRECISION NOT NULL,
    median_lifetime_years DOUBLE PRECISION NOT NULL,
    p5_lifetime_years DOUBLE PRECISION NOT NULL,
    p95_lifetime_years DOUBLE PRECISION NOT NULL,
    prob_soh_gt_80_after_10yr DOUBLE PRECISION NOT NULL,
    prob_soh_gt_80_after_20yr DOUBLE PRECISION NOT NULL,
    forecast_model_hash VARCHAR(64) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
