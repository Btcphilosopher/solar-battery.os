# Heat Pump Thermal Recovery Maximiser

A physics-first thermal optimisation engine that maximises **useful energy
recovered from low- and medium-temperature waste heat using heat pumps** —
primarily data-centre waste heat, with support for industrial waste heat,
district heating, refrigeration and wastewater sources.

This is not a generic digital twin and not an economic simulator. Every
number the engine reports traces back to a measurable thermodynamic
quantity, computed from validated fluid properties (CoolProp), real
vapour-compression cycle physics, and Second-Law (exergy) accounting — not
a lookup table or a rule of thumb.

```
DATA CENTRE / INDUSTRIAL PROCESS -> WASTE HEAT -> HEAT EXCHANGER
    -> LOW-TEMPERATURE LOOP -> HEAT PUMP -> HIGH-TEMPERATURE LOOP
    -> HOT WATER / PROCESS HEAT / STEAM -> (TURBINE -> ELECTRICITY)
```

## Design principles

1. **Physics first** — thermodynamic reality always overrides optimisation.
2. **Net energy** — optimise useful output *after* parasitic consumption.
3. **Marginal gains** — continuously search for small improvements, not just
   large redesigns.
4. **Adaptive operation** — the optimal operating point changes with source
   conditions and demand.
5. **No free energy** — every joule has an identifiable physical origin.

## Quick start

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# Run the default plant and print the optimisation report
python main.py

# Sweep delivery temperature (section 9) and rank marginal-gain opportunities (section 22)
python main.py --sweep --marginal-gains

# Compare every built-in scenario (section 23)
python main.py --all-scenarios

# Save an interactive HTML dashboard
python main.py --dashboard out.html

# Run the test suite
pytest -q

# Serve the API
uvicorn api.server:app --reload
```

## Architecture

```
heatpump_maximiser/
├── core/            engine.py (the central "resolve one operating point" function),
│                    simulation_loop.py (MEASURE→UNDERSTAND→CALCULATE→PREDICT→
│                    OPTIMISE→CONTROL→MEASURE loop), state.py, timestep.py, events.py
├── heat_source/     waste-heat stream physics; data-centre and industrial converters
├── heat_exchanger/  effectiveness-NTU, pressure drop, fouling
├── heat_pump/       full vapour-compression cycle (CoolProp), evaporator/condenser/
│                    compressor/expansion-valve components, single- and multi-stage
│                    cascade
├── thermodynamics/  CoolProp property access, enthalpy/entropy, exergy, energy balance
├── thermal_network/ low/high-temperature loops, thermal storage, distribution,
│                    downstream steam/turbine/generator pathway
├── optimisation/    COP / heat-recovery / compressor / temperature-lift / storage
│                    optimisers, weighted multi-objective + Pareto frontier,
│                    automatic marginal-gain search
├── forecasting/     transparent persistence/trend forecasts (physics stays authoritative)
├── scenarios/       the section-23 scenario set + runner
├── economics/       optional cost/value overlay (never the default objective)
├── validation/      energy-balance, thermodynamic-limit and sanity checks
├── visualisation/   COP maps, heat-flow Sankey, exergy waterfall, optimisation curves
├── api/             FastAPI surface (/simulate, /optimise, /heat-source, /heat-pump,
│                    /thermodynamics, /exergy, /storage, /forecast, /scenario, /status)
├── config/          Pydantic plant configuration + default.yaml example
└── tests/           energy/mass conservation, COP, refrigerant properties, heat
                    exchanger, compressor, temperature lift, pressure limits, storage,
                    optimisation convergence, boundary conditions
```

## How an operating point is resolved

`core.engine.evaluate_operating_point` is the single function every
optimiser and the real-time loop calls. Given a measured source state and a
chosen (evaporating temperature, condensing temperature, loop flow):

1. Solves the source-side heat exchanger (approach-temperature limited —
   never extracts more than the technically recoverable heat, section 6).
2. Solves the full refrigerant cycle through CoolProp (evaporator →
   compressor → condenser → expansion valve), clipped to whichever of
   compressor power or source heat availability binds first.
3. Solves the delivery loop and, where configured, the downstream
   steam/turbine/generator pathway — reporting **net** electrical output,
   never gross.
4. Builds the plant-wide exergy-loss waterfall (section 14): source → heat
   exchanger → evaporator → compressor/expansion valve → condenser, ranked
   by where useful work potential is actually being destroyed.
5. Validates the result: energy balance closes within tolerance, COP never
   exceeds the Carnot limit for the temperature lift, every pressure and
   temperature stays inside the refrigerant's and the equipment's valid
   envelope. A violation raises rather than silently reporting a bad number.

## Example report

```
$ python main.py --config config/default.yaml
============================================================
                    HEAT-PUMP MAXIMISER
============================================================

SOURCE
  Temperature:            35.0 degC
  Available heat:        12.54 MW
  Flow:                    300 kg/s

OPTIMAL SETPOINT
  Delivery temperature:   85.2 degC
  Temperature lift:       64.2 K
  Heat recovery:           3.76 MW
  Heat delivered:          5.66 MW
  Electrical input:        2.00 MW
  COP:                     2.83
  Net thermal output:      5.66 MW

EXERGY
  Exergy destroyed:        1.14 MW
  Exergy (2nd-law) eff:   49.4 %

SYSTEM
  Heat exchanger:         50.0 %
  Compressor:             75.0 %
  System efficiency:      45.2 %

STATUS
  OPTIMAL
```

## Notes on scope

- Python 3.11 is used in this environment (the spec asked for 3.12+; the
  codebase has no 3.12-only syntax and runs unchanged on 3.12).
- PyTorch is deliberately **not** used: nothing in this engine benefits from
  a learned model over the validated physics + scipy optimisation already
  in place (design principle: physics first). The forecasting package is
  structured so a PyTorch model could be dropped in later if a genuine
  predictive need emerges, without touching the physics core.
- Rust migration path: the computationally hot paths (thermodynamic cycle
  solves, the optimiser's inner-loop evaluations) are isolated behind plain
  functions with explicit numeric inputs/outputs in `heat_pump/`,
  `heat_exchanger/` and `thermodynamics/` — the natural boundary for moving
  them to Rust (e.g. via PyO3) without touching the orchestration layer in
  `core/` and `optimisation/`.
