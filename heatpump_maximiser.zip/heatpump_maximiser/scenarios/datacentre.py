"""Data-centre load scenarios (section 23): HIGH / LOW IT load, built from the default plant configuration."""

from __future__ import annotations

from config.system_config import DataCentreSourceConfig, default_config
from heat_source.datacentre import DataCentreSource

HIGH_LOAD = DataCentreSourceConfig(
    it_load_mw=18.0, server_utilisation=0.92, gpu_load_fraction=0.6, cpu_load_fraction=0.35,
    network_load_fraction=0.05, heat_capture_fraction=0.70, coolant_supply_temperature_c=38.0,
    coolant_flow_kg_s=420.0,
)

LOW_LOAD = DataCentreSourceConfig(
    it_load_mw=18.0, server_utilisation=0.25, gpu_load_fraction=0.1, cpu_load_fraction=0.7,
    network_load_fraction=0.2, heat_capture_fraction=0.55, coolant_supply_temperature_c=29.0,
    coolant_flow_kg_s=420.0,
)


def build_scenario(dc_config: DataCentreSourceConfig):
    """Returns (PlantConfig, WasteHeatStream) for a given data-centre load configuration."""
    config = default_config()
    config = config.model_copy(update={"datacentre_source": dc_config})
    source = DataCentreSource(dc_config, min_return_temperature_c=config.heat_source.min_return_temperature_c)
    config = config.model_copy(update={"heat_source": source.to_heat_source_config()})
    return config, source.to_waste_heat_stream()


def high_load_scenario():
    return build_scenario(HIGH_LOAD)


def low_load_scenario():
    return build_scenario(LOW_LOAD)
