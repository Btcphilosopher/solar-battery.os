"""
Ambient-condition scenarios (section 23): HOT / COLD ambient affects the
exergy reference (dead-state) temperature directly, and — for an
air-cooled or ambient-influenced plant — the achievable sink/condenser
performance indirectly. This engine's default condenser sinks to a water
loop rather than ambient air, so the direct effect modelled here is on the
exergy reference state; a site with air-cooled condensing can additionally
tighten `heat_pump.max_sink_temperature_c` for the hot-ambient case.
"""

from __future__ import annotations

from config.system_config import PlantConfig

HOT_AMBIENT_C = 32.0
COLD_AMBIENT_C = -5.0
NOMINAL_AMBIENT_C = 15.0


def apply_hot_ambient(config: PlantConfig) -> PlantConfig:
    new_env = config.environment.model_copy(update={"ambient_temperature_c": HOT_AMBIENT_C})
    return config.model_copy(update={"environment": new_env})


def apply_cold_ambient(config: PlantConfig) -> PlantConfig:
    new_env = config.environment.model_copy(update={"ambient_temperature_c": COLD_AMBIENT_C})
    return config.model_copy(update={"environment": new_env})
