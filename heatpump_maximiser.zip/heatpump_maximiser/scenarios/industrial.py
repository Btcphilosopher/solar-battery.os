"""Industrial waste-heat scenarios: HIGH / LOW source temperature examples built on heat_source.industrial_source."""

from __future__ import annotations

from config.system_config import default_config
from heat_source.industrial_source import IndustrialProcessType, IndustrialSource

HIGH_SOURCE_TEMPERATURE = IndustrialSource(
    process_type=IndustrialProcessType.REFRIGERATION_CONDENSER,
    fluid="Water", temperature_c=48.0, flow_kg_s=150.0, configured_min_return_temperature_c=20.0,
)

LOW_SOURCE_TEMPERATURE = IndustrialSource(
    process_type=IndustrialProcessType.WASTEWATER,
    fluid="Water", temperature_c=22.0, flow_kg_s=150.0, configured_min_return_temperature_c=10.0,
)


def build_scenario(industrial_source: IndustrialSource):
    config = default_config()
    # Size the heat pump's minimum source temperature to the process, not the
    # data-centre default: a plant actually specified for a 22 degC
    # wastewater stream would be rated to draw from it.
    min_source_c = min(config.heat_pump.min_source_temperature_c, industrial_source.temperature_c - 15.0)
    new_heat_pump = config.heat_pump.model_copy(update={"min_source_temperature_c": min_source_c})
    config = config.model_copy(update={
        "heat_source": industrial_source.to_heat_source_config(),
        "datacentre_source": None,
        "heat_pump": new_heat_pump,
    })
    return config, industrial_source.to_waste_heat_stream()


def high_source_temperature_scenario():
    return build_scenario(HIGH_SOURCE_TEMPERATURE)


def low_source_temperature_scenario():
    return build_scenario(LOW_SOURCE_TEMPERATURE)
