"""
Scenario engine (section 23): runs the optimiser across a named set of
operating scenarios so different source/demand/electricity/storage
conditions can be compared side by side.
"""

from __future__ import annotations

from dataclasses import dataclass

from config.system_config import PlantConfig
from core.state import PlantState, SourceState
from heat_source.waste_heat import WasteHeatStream
from optimisation.temperature_optimizer import find_optimal_delivery_temperature
from scenarios import ambient, datacentre, industrial


def apply_high_heat_demand(config: PlantConfig) -> PlantConfig:
    new_demand = config.demand.model_copy(update={"heat_demand_mw": 12.0})
    return config.model_copy(update={"demand": new_demand})


def apply_low_heat_demand(config: PlantConfig) -> PlantConfig:
    new_demand = config.demand.model_copy(update={"heat_demand_mw": 2.0})
    return config.model_copy(update={"demand": new_demand})


def apply_high_electricity_availability(config: PlantConfig) -> PlantConfig:
    new_hp = config.heat_pump.model_copy(update={"max_power_mw": config.heat_pump.max_power_mw * 2.0})
    return config.model_copy(update={"heat_pump": new_hp})


def apply_low_electricity_availability(config: PlantConfig) -> PlantConfig:
    new_hp = config.heat_pump.model_copy(update={"max_power_mw": config.heat_pump.max_power_mw * 0.35})
    return config.model_copy(update={"heat_pump": new_hp})


def apply_storage_available(config: PlantConfig) -> PlantConfig:
    new_storage = config.thermal_storage.model_copy(update={"enabled": True})
    return config.model_copy(update={"thermal_storage": new_storage})


def apply_no_storage(config: PlantConfig) -> PlantConfig:
    new_storage = config.thermal_storage.model_copy(update={"enabled": False})
    return config.model_copy(update={"thermal_storage": new_storage})


@dataclass(frozen=True)
class Scenario:
    name: str
    config: PlantConfig
    source: WasteHeatStream


def _base_scenario(name: str) -> Scenario:
    config, source = datacentre.build_scenario(datacentre.DataCentreSourceConfig(
        it_load_mw=10.0, server_utilisation=0.7, gpu_load_fraction=0.4, cpu_load_fraction=0.5,
        network_load_fraction=0.1, heat_capture_fraction=0.65, coolant_supply_temperature_c=35.0,
        coolant_flow_kg_s=300.0,
    ))
    return Scenario(name, config, source)


def build_scenarios() -> dict[str, Scenario]:
    """The full section-23 scenario set."""
    scenarios: dict[str, Scenario] = {}

    dc_high_config, dc_high_source = datacentre.high_load_scenario()
    scenarios["high_datacentre_load"] = Scenario("HIGH DATA-CENTRE LOAD", dc_high_config, dc_high_source)

    dc_low_config, dc_low_source = datacentre.low_load_scenario()
    scenarios["low_datacentre_load"] = Scenario("LOW DATA-CENTRE LOAD", dc_low_config, dc_low_source)

    base = _base_scenario("base")
    scenarios["hot_ambient"] = Scenario("HOT AMBIENT", ambient.apply_hot_ambient(base.config), base.source)
    scenarios["cold_ambient"] = Scenario("COLD AMBIENT", ambient.apply_cold_ambient(base.config), base.source)

    high_t_config, high_t_source = industrial.high_source_temperature_scenario()
    scenarios["high_source_temperature"] = Scenario("HIGH SOURCE TEMPERATURE", high_t_config, high_t_source)

    low_t_config, low_t_source = industrial.low_source_temperature_scenario()
    scenarios["low_source_temperature"] = Scenario("LOW SOURCE TEMPERATURE", low_t_config, low_t_source)

    scenarios["high_heat_demand"] = Scenario("HIGH HEAT DEMAND", apply_high_heat_demand(base.config), base.source)
    scenarios["low_heat_demand"] = Scenario("LOW HEAT DEMAND", apply_low_heat_demand(base.config), base.source)

    scenarios["high_electricity_availability"] = Scenario(
        "HIGH ELECTRICITY AVAILABILITY", apply_high_electricity_availability(base.config), base.source
    )
    scenarios["low_electricity_availability"] = Scenario(
        "LOW ELECTRICITY AVAILABILITY", apply_low_electricity_availability(base.config), base.source
    )

    scenarios["thermal_storage_available"] = Scenario(
        "THERMAL STORAGE AVAILABLE", apply_storage_available(base.config), base.source
    )
    scenarios["no_storage"] = Scenario("NO STORAGE", apply_no_storage(base.config), base.source)

    return scenarios


@dataclass
class ScenarioResult:
    scenario: Scenario
    plant_state: PlantState | None
    evaporating_temperature_k: float
    delivery_temperature_k: float


def run_scenario(scenario: Scenario, extra_margin_k: float = 3.0) -> ScenarioResult:
    """
    Resolve the optimal delivery temperature for one scenario at a
    representative evaporating temperature: as high as the equipment allows
    (best COP) while leaving a small buffer below the point where the heat
    exchanger's own approach-temperature limit would zero out its duty
    (evaporator pinch + heat-exchanger approach + a small safety margin).
    """
    source_state: SourceState = scenario.source.to_source_state()
    required_offset_k = (
        scenario.config.heat_pump.evaporator_pinch_k
        + scenario.config.heat_exchanger.approach_temperature_k
        + extra_margin_k
    )
    evap_temp_k = source_state.temperature_k - required_offset_k

    result = find_optimal_delivery_temperature(
        scenario.config,
        source_state,
        evaporating_temperature_k=evap_temp_k,
        loop_flow_kg_s=scenario.source.flow_kg_s,
        delivery_temperature_min_c=max(scenario.config.optimisation.delivery_temperature_search_min_c, 5.0),
        delivery_temperature_max_c=min(
            scenario.config.optimisation.delivery_temperature_search_max_c,
            scenario.config.heat_pump.max_sink_temperature_c - scenario.config.heat_pump.condenser_pinch_k,
        ),
    )
    return ScenarioResult(
        scenario=scenario,
        plant_state=result.plant_state,
        evaporating_temperature_k=evap_temp_k,
        delivery_temperature_k=result.delivery_temperature_k,
    )


def run_all_scenarios() -> list[ScenarioResult]:
    return [run_scenario(scenario) for scenario in build_scenarios().values()]
