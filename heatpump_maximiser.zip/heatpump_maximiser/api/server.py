"""
FastAPI surface over the engine (section 27).

Every endpoint returns structured, validated engineering results — the
underlying dataclasses produced by the physics engine, serialised as-is
(via FastAPI's jsonable_encoder) rather than through a hand-rolled or lossy
summary. Run with:

    uvicorn api.server:app --reload
"""

from __future__ import annotations

from dataclasses import asdict
from typing import Any

import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.encoders import jsonable_encoder
from pydantic import BaseModel, Field

from config.system_config import PlantConfig
from core.engine import InfeasibleOperatingPointError, evaluate_operating_point
from core.state import SourceState
from forecasting.heat_load import bounded_forecast
from heat_pump.heat_pump import HeatPump
from heat_source.waste_heat import WasteHeatStream
from core.simulation_loop import OBJECTIVE_SCORES
from optimisation.marginal_gain import search_marginal_gains
from optimisation.multiobjective import optimise_weighted
from optimisation.temperature_optimizer import find_optimal_delivery_temperature
from scenarios.scenario_runner import build_scenarios, run_scenario
from thermal_network.thermal_storage import ThermalStorage
from thermodynamics.properties import c_to_k, density, enthalpy_tp, entropy_tp, specific_heat

app = FastAPI(
    title="Heat Pump Thermal Recovery Maximiser",
    description="Physics-first thermal optimisation engine for waste-heat recovery via heat pumps.",
    version="0.1.0",
)


def _dc(obj: Any) -> Any:
    """Serialise a (possibly nested) dataclass instance to a JSON-safe dict."""
    return jsonable_encoder(asdict(obj))


# --------------------------------------------------------------------------- /status

@app.get("/status")
def status() -> dict:
    return {
        "status": "OK",
        "engine": "heatpump_maximiser",
        "version": app.version,
        "design_principles": [
            "PHYSICS FIRST", "NET ENERGY", "MARGINAL GAINS", "ADAPTIVE OPERATION", "NO FREE ENERGY",
        ],
    }


# --------------------------------------------------------------------------- /heat-source

class HeatSourceRequest(BaseModel):
    fluid: str = "Water"
    temperature_c: float
    flow_kg_s: float = Field(..., gt=0)
    min_return_temperature_c: float
    max_extraction_rate_mw: float | None = None
    target_return_temperature_c: float | None = None


@app.post("/heat-source")
def heat_source(req: HeatSourceRequest) -> dict:
    stream = WasteHeatStream(
        fluid=req.fluid, temperature_c=req.temperature_c, flow_kg_s=req.flow_kg_s,
        min_return_temperature_c=req.min_return_temperature_c, max_extraction_rate_mw=req.max_extraction_rate_mw,
    )
    return {
        "total_available_heat_mw": stream.total_available_heat_w() / 1e6,
        "recoverable_heat_mw": stream.megawatts_thermal(req.target_return_temperature_c),
        "rejected_heat_mw": stream.rejected_heat_w(req.target_return_temperature_c) / 1e6,
        "specific_heat_j_kgk": stream.specific_heat_j_kgk(),
        "density_kg_m3": stream.density_kg_m3(),
    }


# --------------------------------------------------------------------------- /heat-pump

class HeatPumpRequest(BaseModel):
    config: PlantConfig
    low_temp_loop_in_c: float
    low_temp_loop_flow_kg_s: float = Field(..., gt=0)
    evaporating_temperature_c: float
    sink_loop_in_c: float
    condensing_temperature_c: float


@app.post("/heat-pump")
def heat_pump(req: HeatPumpRequest) -> dict:
    hp = HeatPump(req.config.heat_pump)
    try:
        result = hp.operate(
            low_temp_loop_fluid="Water", low_temp_loop_in_k=c_to_k(req.low_temp_loop_in_c),
            low_temp_loop_flow_kg_s=req.low_temp_loop_flow_kg_s, low_temp_loop_pressure_pa=200_000.0,
            evaporating_temperature_k=c_to_k(req.evaporating_temperature_c),
            sink_loop_fluid="Water", sink_loop_in_k=c_to_k(req.sink_loop_in_c), sink_loop_pressure_pa=400_000.0,
            condensing_temperature_k=c_to_k(req.condensing_temperature_c),
        )
    except Exception as exc:  # noqa: BLE001 - surfaced to the API caller as a 422
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return {
        "operating_point": _dc(result.operating_point),
        "compressor_limited": result.compressor_limited,
        "source_limited": result.source_limited,
    }


# --------------------------------------------------------------------------- /thermodynamics

class ThermoRequest(BaseModel):
    fluid: str
    temperature_c: float
    pressure_pa: float


@app.post("/thermodynamics")
def thermodynamics(req: ThermoRequest) -> dict:
    t_k = c_to_k(req.temperature_c)
    try:
        return {
            "temperature_k": t_k,
            "pressure_pa": req.pressure_pa,
            "specific_heat_j_kgk": specific_heat(req.fluid, t_k, req.pressure_pa),
            "density_kg_m3": density(req.fluid, t_k, req.pressure_pa),
            "enthalpy_j_kg": enthalpy_tp(req.fluid, t_k, req.pressure_pa),
            "entropy_j_kgk": entropy_tp(req.fluid, t_k, req.pressure_pa),
        }
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=422, detail=str(exc)) from exc


# --------------------------------------------------------------------------- /simulate, /optimise, /exergy

class OperatingPointRequest(BaseModel):
    config: PlantConfig
    source_temperature_c: float
    source_flow_kg_s: float = Field(..., gt=0)
    source_min_return_temperature_c: float
    evaporating_temperature_c: float
    condensing_temperature_c: float
    low_temp_loop_flow_kg_s: float = Field(..., gt=0)
    sink_loop_return_c: float | None = None


def _build_source(req: OperatingPointRequest) -> SourceState:
    t_k = c_to_k(req.source_temperature_c)
    cp = specific_heat(req.config.heat_source.fluid, t_k, 200_000.0)
    available_w = req.source_flow_kg_s * cp * (req.source_temperature_c - req.source_min_return_temperature_c)
    return SourceState(
        fluid=req.config.heat_source.fluid, temperature_k=t_k, flow_kg_s=req.source_flow_kg_s,
        pressure_pa=200_000.0, specific_heat_j_kgk=cp, min_return_temperature_k=c_to_k(req.source_min_return_temperature_c),
        available_heat_w=max(available_w, 0.0),
    )


@app.post("/simulate")
def simulate(req: OperatingPointRequest) -> dict:
    source = _build_source(req)
    sink_return_k = c_to_k(req.sink_loop_return_c) if req.sink_loop_return_c is not None else None
    try:
        state = evaluate_operating_point(
            req.config, source, c_to_k(req.evaporating_temperature_c), c_to_k(req.condensing_temperature_c),
            req.low_temp_loop_flow_kg_s, sink_return_k,
        )
    except InfeasibleOperatingPointError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return _dc(state)


class OptimiseRequest(BaseModel):
    config: PlantConfig
    source_temperature_c: float
    source_flow_kg_s: float = Field(..., gt=0)
    source_min_return_temperature_c: float
    evaporating_temperature_c: float
    low_temp_loop_flow_kg_s: float = Field(..., gt=0)
    delivery_temperature_min_c: float = 40.0
    delivery_temperature_max_c: float = 90.0
    objective: str = "maximum_net_energy"


@app.post("/optimise")
def optimise(req: OptimiseRequest) -> dict:
    source = _build_source(OperatingPointRequest(
        config=req.config, source_temperature_c=req.source_temperature_c, source_flow_kg_s=req.source_flow_kg_s,
        source_min_return_temperature_c=req.source_min_return_temperature_c,
        evaporating_temperature_c=req.evaporating_temperature_c, condensing_temperature_c=req.delivery_temperature_min_c,
        low_temp_loop_flow_kg_s=req.low_temp_loop_flow_kg_s,
    ))

    if req.objective == "weighted_multiobjective":
        evap_k = c_to_k(req.evaporating_temperature_c)
        cond_bounds = (c_to_k(req.delivery_temperature_min_c), c_to_k(req.delivery_temperature_max_c))
        result = optimise_weighted(req.config, source, (evap_k - 1.0, evap_k), cond_bounds, req.low_temp_loop_flow_kg_s)
        if result.plant_state is None:
            raise HTTPException(status_code=422, detail="No feasible operating point found")
        return {"objective": req.objective, "score": result.score, "plant_state": _dc(result.plant_state)}

    score_fn = OBJECTIVE_SCORES.get(req.objective)
    if score_fn is None:
        raise HTTPException(status_code=400, detail=f"Unknown objective '{req.objective}'")

    result = find_optimal_delivery_temperature(
        req.config, source, c_to_k(req.evaporating_temperature_c), req.low_temp_loop_flow_kg_s,
        req.delivery_temperature_min_c, req.delivery_temperature_max_c, score_fn=score_fn,
    )
    if result.plant_state is None:
        raise HTTPException(status_code=422, detail="No feasible operating point found across the search range")
    return {"objective": req.objective, "score": result.score, "plant_state": _dc(result.plant_state)}


@app.post("/exergy")
def exergy(req: OperatingPointRequest) -> dict:
    source = _build_source(req)
    sink_return_k = c_to_k(req.sink_loop_return_c) if req.sink_loop_return_c is not None else None
    try:
        state = evaluate_operating_point(
            req.config, source, c_to_k(req.evaporating_temperature_c), c_to_k(req.condensing_temperature_c),
            req.low_temp_loop_flow_kg_s, sink_return_k,
        )
    except InfeasibleOperatingPointError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return {
        "waterfall": _dc(state.exergy),
        "ranked_opportunities": [s.name for s in state.exergy.ranked_opportunities()],
        "overall_second_law_efficiency": state.exergy.overall_second_law_efficiency,
    }


@app.post("/marginal-gains")
def marginal_gains(req: OperatingPointRequest) -> dict:
    source = _build_source(req)
    candidates = search_marginal_gains(
        req.config, source, c_to_k(req.evaporating_temperature_c), c_to_k(req.condensing_temperature_c),
        req.low_temp_loop_flow_kg_s,
    )
    return {"candidates": [
        {"name": c.name, "description": c.description, "expected_improvement_pct": c.expected_improvement_fraction * 100}
        for c in candidates
    ]}


# --------------------------------------------------------------------------- /storage

class StorageRequest(BaseModel):
    config: PlantConfig
    initial_state_of_charge: float | None = None
    power_request_w: float
    dt_hours: float = Field(..., gt=0)
    temperature_c: float = 60.0


@app.post("/storage")
def storage(req: StorageRequest) -> dict:
    tank = ThermalStorage(req.config.thermal_storage, state_of_charge=req.initial_state_of_charge)
    try:
        result = tank.step(req.power_request_w, req.dt_hours, c_to_k(req.temperature_c))
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return _dc(result)


# --------------------------------------------------------------------------- /forecast

class ForecastRequest(BaseModel):
    history: list[float]
    horizon_steps: int = Field(..., gt=0)
    lower_bound: float = 0.0
    upper_bound: float | None = None


@app.post("/forecast")
def forecast(req: ForecastRequest) -> dict:
    series = pd.Series(req.history)
    upper = req.upper_bound if req.upper_bound is not None else float("inf")
    result = bounded_forecast(series, req.horizon_steps, req.lower_bound, upper)
    return {"forecast": result.tolist()}


# --------------------------------------------------------------------------- /scenario

@app.get("/scenario")
def list_scenarios() -> dict:
    return {"scenarios": list(build_scenarios().keys())}


@app.get("/scenario/{name}")
def run_named_scenario(name: str) -> dict:
    scenarios = build_scenarios()
    if name not in scenarios:
        raise HTTPException(status_code=404, detail=f"Unknown scenario '{name}'. Available: {list(scenarios.keys())}")
    result = run_scenario(scenarios[name])
    if result.plant_state is None:
        return {"scenario": name, "feasible": False}
    return {"scenario": name, "feasible": True, "plant_state": _dc(result.plant_state)}
