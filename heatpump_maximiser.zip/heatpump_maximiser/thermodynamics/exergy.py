"""
Exergy (available-work) analysis.

Energy accounting (thermodynamics/energy_balance.py) tells you that nothing
was created or destroyed. It cannot tell you that 2 MW of heat at 40 degC is
worth far less than 2 MW of heat at 90 degC, or that a 1234ze(E) compressor
lift from 35 to 55 degC destroys more useful-work potential than a lift from
55 to 65 degC delivering the same duty. Exergy answers that question, and is
the basis of the exergy-loss waterfall (section 14 of the design spec) that
tells the marginal-gain search where the *real* opportunities are.

Sign convention: all exergy quantities returned here are >= 0 by
construction (they are potentials relative to the reference environment);
"exergy destroyed" is always non-negative for any physically valid process.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from thermodynamics.properties import ReferenceEnvironment, DEFAULT_ENVIRONMENT, enthalpy_tp, entropy_tp


def flow_exergy(
    fluid: str,
    temperature_k: float,
    pressure_pa: float,
    environment: ReferenceEnvironment = DEFAULT_ENVIRONMENT,
) -> float:
    """
    Specific physical (thermomechanical) flow exergy, J/kg, of a stream
    relative to the reference environment:

        ex = (h - h0) - T0 * (s - s0)

    Chemical exergy is not modelled (no combustion or chemical reaction is
    present in a heat-recovery plant).
    """
    h = enthalpy_tp(fluid, temperature_k, pressure_pa)
    s = entropy_tp(fluid, temperature_k, pressure_pa)
    h0 = enthalpy_tp(fluid, environment.temperature_k, environment.pressure_pa)
    s0 = entropy_tp(fluid, environment.temperature_k, environment.pressure_pa)
    return (h - h0) - environment.temperature_k * (s - s0)


def stream_exergy_rate(
    mass_flow_kg_s: float,
    fluid: str,
    temperature_k: float,
    pressure_pa: float,
    environment: ReferenceEnvironment = DEFAULT_ENVIRONMENT,
) -> float:
    """Exergy flow rate of a stream, W."""
    if mass_flow_kg_s < 0:
        raise ValueError("mass_flow_kg_s must be non-negative")
    return mass_flow_kg_s * flow_exergy(fluid, temperature_k, pressure_pa, environment)


def exergy_of_heat(
    heat_rate_w: float,
    delivery_temperature_k: float,
    environment: ReferenceEnvironment = DEFAULT_ENVIRONMENT,
) -> float:
    """
    Carnot (thermal) exergy content of a heat flow delivered at a fixed
    temperature above the environment, W:

        Ex = Q * (1 - T0 / T_delivery)

    This is the standard way to value "how much is 1 MW of 80 degC heat
    worth" versus 1 MW of 45 degC heat: the higher-temperature heat carries
    more exergy (more theoretical work potential) per unit of energy, which
    is precisely why a fixed downstream heat *demand* at a required
    temperature, not raw MW, should drive delivery-temperature selection.
    """
    if delivery_temperature_k <= 0:
        raise ValueError("delivery_temperature_k must be a positive absolute temperature")
    if heat_rate_w < 0:
        raise ValueError("heat_rate_w must be non-negative; use the sign of the caller's convention externally")
    carnot_factor = 1.0 - environment.temperature_k / delivery_temperature_k
    return heat_rate_w * carnot_factor


def exergy_destruction_from_entropy_generation(
    entropy_generation_rate_w_k: float,
    environment: ReferenceEnvironment = DEFAULT_ENVIRONMENT,
) -> float:
    """
    Gouy-Stodola theorem: exergy destroyed, W, equals the dead-state
    temperature times the entropy generation rate.

        Ex_destroyed = T0 * S_gen
    """
    if entropy_generation_rate_w_k < -1e-9:
        raise ValueError("Second Law violation: entropy generation rate cannot be negative")
    return environment.temperature_k * max(entropy_generation_rate_w_k, 0.0)


def second_law_efficiency(exergy_delivered_w: float, exergy_supplied_w: float) -> float:
    """
    Second-law (exergetic) efficiency: the fraction of supplied exergy that
    ends up as useful delivered exergy. Bounded in [0, 1] for a physically
    valid process; a value > 1 indicates an accounting error upstream.
    """
    if exergy_supplied_w <= 0:
        return 0.0
    efficiency = exergy_delivered_w / exergy_supplied_w
    if efficiency > 1.0 + 1e-6:
        raise ValueError(
            f"Second Law violation: second-law efficiency {efficiency:.4f} exceeds 1.0 "
            "(delivered exergy cannot exceed supplied exergy)"
        )
    return min(efficiency, 1.0)


@dataclass
class ExergyWaterfallStage:
    """One stage of the plant-wide exergy-loss waterfall."""

    name: str
    exergy_in_w: float
    exergy_destroyed_w: float
    exergy_out_w: float
    note: str = ""

    @property
    def loss_fraction_of_inlet(self) -> float:
        if self.exergy_in_w <= 0:
            return 0.0
        return self.exergy_destroyed_w / self.exergy_in_w


@dataclass
class ExergyWaterfall:
    """
    Ordered, stage-by-stage exergy account for the whole recovery chain:

        source -> heat exchanger -> heat pump (evaporator/compressor/condenser)
        -> delivery -> (optional) downstream steam/turbine

    Ranking `stages` by `exergy_destroyed_w` answers section 14's question
    directly: "where is useful work potential being destroyed the most?"
    """

    source_exergy_in_w: float
    stages: list[ExergyWaterfallStage] = field(default_factory=list)
    exogenous_exergy_in_w: float = 0.0  # e.g. compressor electrical work fed into the chain part-way through

    def add_stage(
        self, name: str, exergy_in_w: float, exergy_out_w: float, note: str = "", exergy_added_w: float = 0.0
    ) -> ExergyWaterfallStage:
        """
        Add one stage. `exergy_in_w`/`exergy_out_w` are this stage's own flow
        exergy in and out; `exergy_added_w` is any *exogenous* exergy
        injected at this stage (electrical work, not carried over from the
        previous stage's outlet) — it is folded into the destruction
        calculation here and also tallied into `exogenous_exergy_in_w` so
        the plant-wide second-law efficiency correctly treats it as a
        supplied input, not as if it appeared for free.
        """
        total_in = exergy_in_w + exergy_added_w
        destroyed = max(total_in - exergy_out_w, 0.0)
        stage = ExergyWaterfallStage(
            name=name, exergy_in_w=total_in, exergy_destroyed_w=destroyed, exergy_out_w=exergy_out_w, note=note
        )
        self.stages.append(stage)
        self.exogenous_exergy_in_w += exergy_added_w
        return stage

    @property
    def total_exergy_destroyed_w(self) -> float:
        return sum(stage.exergy_destroyed_w for stage in self.stages)

    @property
    def final_exergy_out_w(self) -> float:
        return self.stages[-1].exergy_out_w if self.stages else self.source_exergy_in_w

    @property
    def total_exergy_supplied_w(self) -> float:
        """Every exergy input to the chain: the source stream plus any exogenous work (e.g. compressor electricity)."""
        return self.source_exergy_in_w + self.exogenous_exergy_in_w

    @property
    def overall_second_law_efficiency(self) -> float:
        return second_law_efficiency(self.final_exergy_out_w, self.total_exergy_supplied_w)

    def ranked_opportunities(self) -> list[ExergyWaterfallStage]:
        """Stages ordered from the largest exergy-destruction opportunity to the smallest."""
        return sorted(self.stages, key=lambda s: s.exergy_destroyed_w, reverse=True)
