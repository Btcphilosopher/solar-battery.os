"""
Entropy generation accounting.

Entropy is the bridge between the First Law (energy balance, always
satisfied trivially by bookkeeping) and the Second Law (which tells you
whether a proposed state is *physically achievable* and how much useful
work potential a process throws away). Every exergy-destruction number in
thermodynamics/exergy.py is computed from an entropy generation rate here.
"""

from __future__ import annotations

import math

from thermodynamics.properties import entropy_tp


def stream_entropy_rate(mass_flow_kg_s: float, fluid: str, temperature_k: float, pressure_pa: float) -> float:
    """Entropy flow rate carried by a stream, W/K."""
    if mass_flow_kg_s < 0:
        raise ValueError("mass_flow_kg_s must be non-negative")
    return mass_flow_kg_s * entropy_tp(fluid, temperature_k, pressure_pa)


def entropy_generation_heat_transfer(
    heat_rate_w: float,
    hot_side_temperature_k: float,
    cold_side_temperature_k: float,
) -> float:
    """
    Entropy generated, W/K, by transferring heat_rate_w across a finite
    temperature difference between a hot reservoir/stream and a cold one.

        S_gen = Q * (1/T_cold - 1/T_hot)

    This is strictly >= 0 for heat flowing from hot to cold (T_hot >= T_cold),
    which is the only direction the Second Law permits without work input.
    Used throughout the heat-exchanger and heat-pump models to quantify the
    irreversibility of finite-approach-temperature heat transfer.
    """
    if hot_side_temperature_k <= 0 or cold_side_temperature_k <= 0:
        raise ValueError("Absolute temperatures must be positive (Kelvin)")
    if heat_rate_w < 0:
        raise ValueError("heat_rate_w must be non-negative; supply direction via argument order")
    s_gen = heat_rate_w * (1.0 / cold_side_temperature_k - 1.0 / hot_side_temperature_k)
    return s_gen


def entropy_generation_throttling(
    mass_flow_kg_s: float,
    fluid: str,
    pressure_in_pa: float,
    pressure_out_pa: float,
    enthalpy_j_kg: float,
) -> float:
    """
    Entropy generated, W/K, by an isenthalpic throttling process (the
    expansion valve). Enthalpy is conserved (h_in = h_out); entropy strictly
    increases because the process is irreversible.
    """
    from thermodynamics.properties import state_from_ph

    state_in = state_from_ph(fluid, pressure_in_pa, enthalpy_j_kg)
    state_out = state_from_ph(fluid, pressure_out_pa, enthalpy_j_kg)
    delta_s = state_out.entropy_j_kgk - state_in.entropy_j_kgk
    if delta_s < -1e-6:
        raise ValueError(
            "Second Law violation: throttling from high to low pressure must not decrease entropy "
            f"(delta_s={delta_s:.6f} J/(kg K))"
        )
    return mass_flow_kg_s * max(delta_s, 0.0)


def isentropic_efficiency_entropy_penalty(
    ideal_entropy_j_kgk: float,
    actual_entropy_j_kgk: float,
) -> float:
    """Entropy increase, J/(kg K), of a real (non-isentropic) compression step versus its ideal isentropic path."""
    penalty = actual_entropy_j_kgk - ideal_entropy_j_kgk
    if penalty < -1e-6:
        raise ValueError("A real compression step cannot have lower entropy than the ideal isentropic step")
    return max(penalty, 0.0)


def carnot_entropy_check(temperature_hot_k: float, temperature_cold_k: float) -> None:
    """Raise if the pair of temperatures cannot define a valid heat engine/pump cycle."""
    if temperature_hot_k <= temperature_cold_k:
        raise ValueError(
            f"Invalid temperature pair for a thermodynamic cycle: hot ({temperature_hot_k:.2f} K) "
            f"must exceed cold ({temperature_cold_k:.2f} K)"
        )
    if math.isnan(temperature_hot_k) or math.isnan(temperature_cold_k):
        raise ValueError("Temperatures must be finite, real numbers")
