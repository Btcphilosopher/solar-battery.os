"""
First-Law (energy conservation) bookkeeping and checking.

This module is deliberately boring: it adds numbers up and complains loudly
when they do not add up. That boringness is the point (design principle
"NO FREE ENERGY" — every joule must have an identifiable physical origin).
Every timestep of the simulation loop is expected to pass
`check_energy_balance` before its results are trusted; validation/energy_balance.py
wraps this for the plant-wide validation pass.
"""

from __future__ import annotations

from dataclasses import dataclass


class EnergyBalanceError(RuntimeError):
    """Raised when energy in does not equal energy out within tolerance."""


@dataclass(frozen=True)
class EnergyBalanceResult:
    energy_in_w: float
    energy_recovered_w: float
    energy_rejected_w: float
    energy_stored_w: float
    losses_w: float
    residual_w: float
    relative_residual: float
    is_balanced: bool
    tolerance_fraction: float

    def summary(self) -> str:
        status = "BALANCED" if self.is_balanced else "IMBALANCED"
        return (
            f"[{status}] in={self.energy_in_w / 1e6:.4f} MW  "
            f"recovered={self.energy_recovered_w / 1e6:.4f} MW  "
            f"rejected={self.energy_rejected_w / 1e6:.4f} MW  "
            f"stored={self.energy_stored_w / 1e6:.4f} MW  "
            f"losses={self.losses_w / 1e6:.4f} MW  "
            f"residual={self.residual_w / 1e3:.4f} kW ({self.relative_residual * 100:.4f} %)"
        )


def check_energy_balance(
    energy_in_w: float,
    energy_recovered_w: float,
    energy_rejected_w: float,
    energy_stored_w: float = 0.0,
    losses_w: float = 0.0,
    tolerance_fraction: float = 1e-3,
    raise_on_failure: bool = True,
) -> EnergyBalanceResult:
    """
    Verify:

        energy_in == energy_recovered + energy_rejected + energy_stored + losses

    within a relative tolerance (default 0.1%) of the larger side of the
    balance. `energy_stored_w` may be negative (discharging storage
    contributes energy rather than absorbing it).
    """
    energy_out_total = energy_recovered_w + energy_rejected_w + energy_stored_w + losses_w
    residual = energy_in_w - energy_out_total
    scale = max(abs(energy_in_w), abs(energy_out_total), 1.0)
    relative_residual = abs(residual) / scale
    is_balanced = relative_residual <= tolerance_fraction

    result = EnergyBalanceResult(
        energy_in_w=energy_in_w,
        energy_recovered_w=energy_recovered_w,
        energy_rejected_w=energy_rejected_w,
        energy_stored_w=energy_stored_w,
        losses_w=losses_w,
        residual_w=residual,
        relative_residual=relative_residual,
        is_balanced=is_balanced,
        tolerance_fraction=tolerance_fraction,
    )
    if not is_balanced and raise_on_failure:
        raise EnergyBalanceError(
            "Energy balance violated: "
            f"in={energy_in_w:.3f} W, out(recovered+rejected+stored+losses)={energy_out_total:.3f} W, "
            f"residual={residual:.3f} W ({relative_residual * 100:.4f} % of scale). {result.summary()}"
        )
    return result


def heat_pump_energy_balance(
    heat_absorbed_w: float,
    compressor_work_w: float,
    heat_rejected_w: float,
    tolerance_fraction: float = 1e-3,
    raise_on_failure: bool = True,
) -> EnergyBalanceResult:
    """
    Vapour-compression cycle energy balance:

        Q_evaporator + W_compressor == Q_condenser

    Framed through check_energy_balance with the compressor work folded in
    as additional "energy_in" (electricity is a real energy input to the
    cycle, not free).
    """
    return check_energy_balance(
        energy_in_w=heat_absorbed_w + compressor_work_w,
        energy_recovered_w=heat_rejected_w,
        energy_rejected_w=0.0,
        energy_stored_w=0.0,
        losses_w=0.0,
        tolerance_fraction=tolerance_fraction,
        raise_on_failure=raise_on_failure,
    )


def net_output(gross_output_w: float, auxiliary_consumption_w: float) -> float:
    """
    Net useful output after parasitic loads (design principle "NET ENERGY").
    Never allow the result to be reported as though the auxiliary load did
    not happen.
    """
    if auxiliary_consumption_w < 0:
        raise ValueError("auxiliary_consumption_w must be non-negative")
    return gross_output_w - auxiliary_consumption_w
