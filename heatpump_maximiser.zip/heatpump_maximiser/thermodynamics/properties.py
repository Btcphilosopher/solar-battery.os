"""
Validated thermophysical property access.

Every property used anywhere in the engine — refrigerant, water, glycol,
air, steam — is obtained from CoolProp. No refrigerant-property equation is
invented in this codebase: CoolProp's HEOS (Helmholtz-energy equation of
state) backend is authoritative.

All functions in this module use strict SI units internally:
    temperature   -> K
    pressure      -> Pa
    enthalpy      -> J/kg
    entropy       -> J/(kg K)
    specific heat -> J/(kg K)
    density       -> kg/m^3
    mass flow     -> kg/s

Convenience Celsius/Kelvin converters are provided because plant engineers
think in Celsius; the physics core never does.
"""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache

from CoolProp.CoolProp import PropsSI

CELSIUS_TO_KELVIN_OFFSET = 273.15


def c_to_k(temperature_c: float) -> float:
    """Convert Celsius to Kelvin."""
    return temperature_c + CELSIUS_TO_KELVIN_OFFSET


def k_to_c(temperature_k: float) -> float:
    """Convert Kelvin to Celsius."""
    return temperature_k - CELSIUS_TO_KELVIN_OFFSET


class PropertyError(RuntimeError):
    """Raised when CoolProp cannot resolve a valid thermodynamic state."""


@dataclass(frozen=True)
class ReferenceEnvironment:
    """
    The dead-state (T0, P0) used for exergy accounting.

    Defaults to a standard ambient reference (15 degC, 1 atm). This should be
    set to the actual site ambient condition for correct exergy analysis
    (see thermodynamics/exergy.py).
    """

    temperature_k: float = c_to_k(15.0)
    pressure_pa: float = 101_325.0

    @property
    def temperature_c(self) -> float:
        return k_to_c(self.temperature_k)


DEFAULT_ENVIRONMENT = ReferenceEnvironment()


def _safe_propssi(output: str, name1: str, value1: float, name2: str, value2: float, fluid: str) -> float:
    try:
        result = PropsSI(output, name1, value1, name2, value2, fluid)
    except ValueError as exc:  # CoolProp raises ValueError on invalid states
        raise PropertyError(
            f"CoolProp could not resolve '{output}' for {fluid} at "
            f"{name1}={value1}, {name2}={value2}: {exc}"
        ) from exc
    if result is None or (isinstance(result, float) and (result != result)):  # NaN check
        raise PropertyError(f"CoolProp returned an invalid value for '{output}' on {fluid}")
    return float(result)


def specific_heat(fluid: str, temperature_k: float, pressure_pa: float) -> float:
    """Specific heat capacity at constant pressure, J/(kg K)."""
    return _safe_propssi("C", "T", temperature_k, "P", pressure_pa, fluid)


def density(fluid: str, temperature_k: float, pressure_pa: float) -> float:
    """Density, kg/m^3."""
    return _safe_propssi("D", "T", temperature_k, "P", pressure_pa, fluid)


def enthalpy_tp(fluid: str, temperature_k: float, pressure_pa: float) -> float:
    """Specific enthalpy at (T, P), J/kg."""
    return _safe_propssi("H", "T", temperature_k, "P", pressure_pa, fluid)


def entropy_tp(fluid: str, temperature_k: float, pressure_pa: float) -> float:
    """Specific entropy at (T, P), J/(kg K)."""
    return _safe_propssi("S", "T", temperature_k, "P", pressure_pa, fluid)


def enthalpy_pq(fluid: str, pressure_pa: float, quality: float) -> float:
    """Specific enthalpy at (P, vapour quality Q in [0, 1]), J/kg."""
    return _safe_propssi("H", "P", pressure_pa, "Q", quality, fluid)


def entropy_pq(fluid: str, pressure_pa: float, quality: float) -> float:
    """Specific entropy at (P, vapour quality Q in [0, 1]), J/(kg K)."""
    return _safe_propssi("S", "P", pressure_pa, "Q", quality, fluid)


def saturation_temperature(fluid: str, pressure_pa: float) -> float:
    """Saturation temperature at given pressure, K."""
    return _safe_propssi("T", "P", pressure_pa, "Q", 0.0, fluid)


def saturation_pressure(fluid: str, temperature_k: float) -> float:
    """Saturation (bubble-point) pressure at given temperature, Pa."""
    return _safe_propssi("P", "T", temperature_k, "Q", 0.0, fluid)


def critical_temperature(fluid: str) -> float:
    """Critical temperature, K."""
    return float(PropsSI("Tcrit", fluid))


def critical_pressure(fluid: str) -> float:
    """Critical pressure, Pa."""
    return float(PropsSI("Pcrit", fluid))


def state_from_tp(fluid: str, temperature_k: float, pressure_pa: float) -> "FluidState":
    """Build a fully-resolved FluidState from temperature and pressure."""
    h = enthalpy_tp(fluid, temperature_k, pressure_pa)
    s = entropy_tp(fluid, temperature_k, pressure_pa)
    d = density(fluid, temperature_k, pressure_pa)
    try:
        q = _safe_propssi("Q", "T", temperature_k, "P", pressure_pa, fluid)
    except PropertyError:
        q = -1.0  # single phase, not physically in the two-phase dome
    return FluidState(fluid=fluid, temperature_k=temperature_k, pressure_pa=pressure_pa,
                       enthalpy_j_kg=h, entropy_j_kgk=s, density_kg_m3=d, quality=q)


def state_from_ph(fluid: str, pressure_pa: float, enthalpy_j_kg: float) -> "FluidState":
    """Build a fully-resolved FluidState from pressure and enthalpy."""
    t = _safe_propssi("T", "P", pressure_pa, "H", enthalpy_j_kg, fluid)
    s = _safe_propssi("S", "P", pressure_pa, "H", enthalpy_j_kg, fluid)
    d = _safe_propssi("D", "P", pressure_pa, "H", enthalpy_j_kg, fluid)
    try:
        q = _safe_propssi("Q", "P", pressure_pa, "H", enthalpy_j_kg, fluid)
    except PropertyError:
        q = -1.0
    return FluidState(fluid=fluid, temperature_k=t, pressure_pa=pressure_pa,
                       enthalpy_j_kg=enthalpy_j_kg, entropy_j_kgk=s, density_kg_m3=d, quality=q)


def state_from_ps(fluid: str, pressure_pa: float, entropy_j_kgk: float) -> "FluidState":
    """Build a fully-resolved FluidState from pressure and entropy (used for isentropic legs)."""
    t = _safe_propssi("T", "P", pressure_pa, "S", entropy_j_kgk, fluid)
    h = _safe_propssi("H", "P", pressure_pa, "S", entropy_j_kgk, fluid)
    d = _safe_propssi("D", "P", pressure_pa, "S", entropy_j_kgk, fluid)
    try:
        q = _safe_propssi("Q", "P", pressure_pa, "S", entropy_j_kgk, fluid)
    except PropertyError:
        q = -1.0
    return FluidState(fluid=fluid, temperature_k=t, pressure_pa=pressure_pa,
                       enthalpy_j_kg=h, entropy_j_kgk=entropy_j_kgk, density_kg_m3=d, quality=q)


@dataclass(frozen=True)
class FluidState:
    """A fully-resolved single-phase or two-phase thermodynamic state point."""

    fluid: str
    temperature_k: float
    pressure_pa: float
    enthalpy_j_kg: float
    entropy_j_kgk: float
    density_kg_m3: float
    quality: float  # -1 when outside the two-phase dome (subcooled liquid or superheated vapour)

    @property
    def temperature_c(self) -> float:
        return k_to_c(self.temperature_k)

    @property
    def is_two_phase(self) -> bool:
        return 0.0 <= self.quality <= 1.0


@lru_cache(maxsize=64)
def fluid_limits(fluid: str) -> tuple[float, float, float, float]:
    """(T_min [K], T_max [K], P_min [Pa], P_max [Pa]) validity envelope for a fluid, per CoolProp."""
    t_min = float(PropsSI("Tmin", fluid))
    t_max = float(PropsSI("Tmax", fluid))
    p_max = float(PropsSI("pmax", fluid))
    p_min = 1.0  # CoolProp does not expose a universal pmin; 1 Pa is a safe physical floor
    return t_min, t_max, p_min, p_max
