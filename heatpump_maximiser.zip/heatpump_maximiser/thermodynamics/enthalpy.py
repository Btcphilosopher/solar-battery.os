"""
Stream-level enthalpy accounting.

These helpers sit one layer above raw CoolProp calls (thermodynamics.properties)
and express the energy-balance quantities the rest of the engine actually
needs: sensible heat of a flowing stream, latent heat of a phase change, and
the mixed-stream enthalpy of two merging flows.
"""

from __future__ import annotations

from thermodynamics.properties import (
    density,
    enthalpy_pq,
    enthalpy_tp,
    specific_heat,
)


def sensible_heat_rate(mass_flow_kg_s: float, cp_j_kgk: float, delta_t_k: float) -> float:
    """
    Sensible heat rate of a flowing stream, W.

        Q_dot = m_dot * cp * delta_T

    This is the single most important equation in the whole engine: every
    "available heat" and "recovered heat" number in the system traces back
    to this.
    """
    if mass_flow_kg_s < 0:
        raise ValueError("mass_flow_kg_s must be non-negative: mass cannot be created or destroyed")
    return mass_flow_kg_s * cp_j_kgk * delta_t_k


def stream_enthalpy_rate(mass_flow_kg_s: float, fluid: str, temperature_k: float, pressure_pa: float) -> float:
    """Absolute enthalpy flow rate of a stream referenced to CoolProp's internal datum, W."""
    if mass_flow_kg_s < 0:
        raise ValueError("mass_flow_kg_s must be non-negative")
    return mass_flow_kg_s * enthalpy_tp(fluid, temperature_k, pressure_pa)


def latent_heat_of_vaporisation(fluid: str, pressure_pa: float) -> float:
    """Latent heat of vaporisation at the saturation pressure given, J/kg."""
    h_liquid = enthalpy_pq(fluid, pressure_pa, 0.0)
    h_vapour = enthalpy_pq(fluid, pressure_pa, 1.0)
    return h_vapour - h_liquid


def mixed_stream_temperature(
    mass_flow_a_kg_s: float,
    temperature_a_k: float,
    mass_flow_b_kg_s: float,
    temperature_b_k: float,
    fluid: str = "Water",
    pressure_pa: float = 101_325.0,
) -> float:
    """
    Adiabatic mixing temperature of two streams of the same fluid, via an
    enthalpy balance (not a naive mass-weighted temperature average, which is
    only exact for constant-cp fluids).

        m_a*h_a + m_b*h_b = (m_a + m_b)*h_mix
    """
    total_flow = mass_flow_a_kg_s + mass_flow_b_kg_s
    if total_flow <= 0:
        raise ValueError("total mass flow must be positive to define a mixed state")
    h_a = enthalpy_tp(fluid, temperature_a_k, pressure_pa)
    h_b = enthalpy_tp(fluid, temperature_b_k, pressure_pa)
    h_mix = (mass_flow_a_kg_s * h_a + mass_flow_b_kg_s * h_b) / total_flow
    from thermodynamics.properties import _safe_propssi  # local import to avoid widening public API

    return _safe_propssi("T", "P", pressure_pa, "H", h_mix, fluid)


def volumetric_flow(mass_flow_kg_s: float, fluid: str, temperature_k: float, pressure_pa: float) -> float:
    """Volumetric flow rate, m^3/s, from mass flow and density."""
    rho = density(fluid, temperature_k, pressure_pa)
    return mass_flow_kg_s / rho
