"""
Multi-objective optimisation (section 17): weighted-sum optimisation across
heat recovery, COP, net energy output and exergy efficiency, plus
Pareto-frontier analysis so a human (or a downstream policy) can see the
actual trade-off curve rather than a single collapsed number.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np
from scipy.optimize import differential_evolution

from config.system_config import PlantConfig
from core.engine import InfeasibleOperatingPointError, evaluate_operating_point
from core.state import PlantState, SourceState

ObjectiveFn = Callable[[PlantState], float]

DEFAULT_OBJECTIVES: dict[str, ObjectiveFn] = {
    "heat_recovery": lambda s: s.metrics.heat_recovered_w,
    "cop": lambda s: s.metrics.cop,
    "net_output": lambda s: s.metrics.net_thermal_output_w,
    "exergy_efficiency": lambda s: s.metrics.exergy_efficiency,
}


@dataclass
class Normalizers:
    """Reference scales used to make heterogeneous objectives commensurable before weighting."""

    heat_recovery_w: float
    cop: float = 12.0  # a generous upper bound on realistic heat-pump COP
    net_output_w: float = 0.0  # defaults to heat_recovery_w if left at 0
    exergy_efficiency: float = 1.0

    def __post_init__(self) -> None:
        if self.net_output_w <= 0:
            self.net_output_w = self.heat_recovery_w


def weighted_score(state: PlantState, weights: dict[str, float], normalizers: Normalizers) -> float:
    normalized = {
        "heat_recovery": state.metrics.heat_recovered_w / normalizers.heat_recovery_w if normalizers.heat_recovery_w > 0 else 0.0,
        "cop": state.metrics.cop / normalizers.cop if normalizers.cop > 0 else 0.0,
        "net_output": state.metrics.net_thermal_output_w / normalizers.net_output_w if normalizers.net_output_w > 0 else 0.0,
        "exergy_efficiency": state.metrics.exergy_efficiency / normalizers.exergy_efficiency if normalizers.exergy_efficiency > 0 else 0.0,
    }
    return sum(weights.get(key, 0.0) * value for key, value in normalized.items())


@dataclass
class WeightedOptimizationResult:
    plant_state: PlantState | None
    score: float
    evaporating_temperature_k: float
    condensing_temperature_k: float
    converged: bool
    evaluations: int


def optimise_weighted(
    config: PlantConfig,
    source: SourceState,
    evap_bounds_k: tuple[float, float],
    cond_bounds_k: tuple[float, float],
    loop_flow_kg_s: float,
    weights: dict[str, float] | None = None,
    sink_loop_return_k: float | None = None,
) -> WeightedOptimizationResult:
    """
    Two-dimensional search (evaporating temperature, condensing temperature)
    via differential evolution — a global, derivative-free method well
    suited to a search space that can have flat or discontinuous regions
    (infeasible points are penalised, not smoothly differentiable).
    """
    weights = weights or config.optimisation.weights
    normalizers = Normalizers(heat_recovery_w=source.available_heat_w)

    evaluations = 0
    best_state: PlantState | None = None
    best_score = float("-inf")

    def objective(x: np.ndarray) -> float:
        nonlocal evaluations, best_state, best_score
        evaluations += 1
        evap_k, cond_k = x
        if cond_k <= evap_k:
            return 1e6
        try:
            state = evaluate_operating_point(config, source, evap_k, cond_k, loop_flow_kg_s, sink_loop_return_k)
        except InfeasibleOperatingPointError:
            return 1e6
        score = weighted_score(state, weights, normalizers)
        if score > best_score:
            best_score = score
            best_state = state
        return -score

    result = differential_evolution(
        objective, bounds=[evap_bounds_k, cond_bounds_k], seed=42, maxiter=40, popsize=12, tol=1e-4, polish=False
    )

    return WeightedOptimizationResult(
        plant_state=best_state,
        score=best_score,
        evaporating_temperature_k=best_state.heat_pump.evaporating_temperature_k if best_state else float("nan"),
        condensing_temperature_k=best_state.heat_pump.condensing_temperature_k if best_state else float("nan"),
        converged=bool(result.success),
        evaluations=evaluations,
    )


def generate_candidates(
    config: PlantConfig,
    source: SourceState,
    evap_bounds_k: tuple[float, float],
    cond_bounds_k: tuple[float, float],
    loop_flow_kg_s: float,
    sink_loop_return_k: float | None = None,
    n_evap: int = 8,
    n_cond: int = 8,
) -> list[PlantState]:
    """Grid of feasible plant states across the (evap_temp, cond_temp) design space, for Pareto analysis."""
    candidates: list[PlantState] = []
    for evap_k in np.linspace(evap_bounds_k[0], evap_bounds_k[1], n_evap):
        for cond_k in np.linspace(cond_bounds_k[0], cond_bounds_k[1], n_cond):
            if cond_k <= evap_k:
                continue
            try:
                state = evaluate_operating_point(config, source, float(evap_k), float(cond_k), loop_flow_kg_s, sink_loop_return_k)
            except InfeasibleOperatingPointError:
                continue
            if state.metrics.heat_recovered_w <= 0:
                continue
            candidates.append(state)
    return candidates


def pareto_frontier(
    candidates: list[PlantState],
    objective_a: ObjectiveFn = DEFAULT_OBJECTIVES["net_output"],
    objective_b: ObjectiveFn = DEFAULT_OBJECTIVES["exergy_efficiency"],
) -> list[PlantState]:
    """
    Non-dominated set under (objective_a, objective_b), both maximised. A
    candidate is dominated (excluded) if another candidate is at least as
    good on both objectives and strictly better on at least one.
    """
    scored = [(state, objective_a(state), objective_b(state)) for state in candidates]
    frontier = []
    for state, a, b in scored:
        dominated = any(
            (other_a >= a and other_b >= b) and (other_a > a or other_b > b)
            for _, other_a, other_b in scored
            if not (other_a == a and other_b == b)
        )
        if not dominated:
            frontier.append(state)
    frontier.sort(key=lambda s: objective_a(s))
    return frontier
