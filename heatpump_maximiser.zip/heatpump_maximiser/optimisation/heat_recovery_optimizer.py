"""
Heat-recovery maximiser (sections 1 and 6): finds the evaporating
temperature (i.e., how hard the low-temperature loop is cooled) that
maximises *technically recoverable* heat for a fixed delivery temperature.

This deliberately answers only "how much can I recover", not "how much
should I recover" — pairing this with cop_optimizer's output, or running
optimisation.multiobjective, is what answers the "should" question (section
1: "Do not assume that maximising heat extraction automatically maximises
useful energy").
"""

from __future__ import annotations

from dataclasses import dataclass

from scipy.optimize import minimize_scalar

from config.system_config import PlantConfig
from core.engine import InfeasibleOperatingPointError, evaluate_operating_point
from core.state import PlantState, SourceState
from heat_pump.evaporator import max_feasible_evaporating_temperature
from thermodynamics.properties import c_to_k


@dataclass
class HeatRecoveryOptimizationResult:
    plant_state: PlantState | None
    evaporating_temperature_k: float
    heat_recovered_w: float
    converged: bool
    evaluations: int


def maximize_heat_recovery(
    config: PlantConfig,
    source: SourceState,
    low_temp_loop_in_k: float,
    condensing_temperature_k: float,
    loop_flow_kg_s: float,
    sink_loop_return_k: float | None = None,
) -> HeatRecoveryOptimizationResult:
    evap_min_k = c_to_k(config.heat_pump.min_source_temperature_c)
    evap_max_k = max_feasible_evaporating_temperature(low_temp_loop_in_k, config.heat_pump.evaporator_pinch_k)
    if evap_max_k <= evap_min_k:
        return HeatRecoveryOptimizationResult(None, evap_min_k, 0.0, False, 0)

    evaluations = 0
    best_state: PlantState | None = None

    def objective(evaporating_temperature_k: float) -> float:
        nonlocal evaluations, best_state
        evaluations += 1
        try:
            state = evaluate_operating_point(
                config, source, evaporating_temperature_k, condensing_temperature_k,
                loop_flow_kg_s, sink_loop_return_k,
            )
        except InfeasibleOperatingPointError:
            return 1e6
        if best_state is None or state.metrics.heat_recovered_w > best_state.metrics.heat_recovered_w:
            best_state = state
        return -state.metrics.heat_recovered_w

    result = minimize_scalar(objective, bounds=(evap_min_k, evap_max_k), method="bounded")

    if best_state is None:
        return HeatRecoveryOptimizationResult(None, evap_min_k, 0.0, False, evaluations)

    return HeatRecoveryOptimizationResult(
        plant_state=best_state,
        evaporating_temperature_k=best_state.heat_pump.evaporating_temperature_k,
        heat_recovered_w=best_state.metrics.heat_recovered_w,
        converged=bool(result.success),
        evaluations=evaluations,
    )
