"""
COP maximiser (section 8): finds the operating point of highest coefficient
of performance *subject to* a required delivery-temperature band.

COP alone is not a sufficient objective (see the design spec's Operating
Point A/B example — a lower-COP point can deliver far more useful energy):
this optimizer exists to answer the narrower, still useful question "within
the temperature band I am required to deliver, what is the best COP
achievable", which downstream reporting and the multiobjective optimizer
both consume as one input among several.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.optimize import minimize_scalar

from config.system_config import PlantConfig
from core.engine import InfeasibleOperatingPointError, evaluate_operating_point
from core.state import PlantState, SourceState


@dataclass
class CopOptimizationResult:
    plant_state: PlantState | None
    condensing_temperature_k: float
    cop: float
    converged: bool
    evaluations: int


def maximize_cop(
    config: PlantConfig,
    source: SourceState,
    evaporating_temperature_k: float,
    loop_flow_kg_s: float,
    delivery_temperature_min_k: float,
    delivery_temperature_max_k: float,
    sink_loop_return_k: float | None = None,
) -> CopOptimizationResult:
    """
    Search condensing temperature within the band that delivers an
    acceptable temperature, for the COP-maximising point. Because COP
    decreases monotonically with temperature lift in this cycle model, the
    optimum is typically at the low end of the band — `minimize_scalar`
    (bounded, Brent-derived) is used rather than assuming that a priori, so
    the result stays correct if a non-monotonic compressor map is plugged in
    later.
    """
    pinch = config.heat_pump.condenser_pinch_k
    cond_min_k = delivery_temperature_min_k + pinch
    cond_max_k = delivery_temperature_max_k + pinch

    evaluations = 0
    best_state: PlantState | None = None

    def objective(condensing_temperature_k: float) -> float:
        nonlocal evaluations, best_state
        evaluations += 1
        try:
            state = evaluate_operating_point(
                config, source, evaporating_temperature_k, condensing_temperature_k,
                loop_flow_kg_s, sink_loop_return_k,
            )
        except InfeasibleOperatingPointError:
            return 1e6  # heavily penalise infeasible points, keep the search inside the feasible region
        if best_state is None or state.metrics.cop > best_state.metrics.cop:
            best_state = state
        return -state.metrics.cop

    result = minimize_scalar(objective, bounds=(cond_min_k, cond_max_k), method="bounded")

    if best_state is None:
        return CopOptimizationResult(None, float(result.x), 0.0, False, evaluations)

    return CopOptimizationResult(
        plant_state=best_state,
        condensing_temperature_k=best_state.heat_pump.condensing_temperature_k,
        cop=best_state.metrics.cop,
        converged=bool(result.success),
        evaluations=evaluations,
    )
