"""
Compressor loading optimiser (section 15/16): searches compressor speed
(expressed as a fraction of the plant's rated electrical capacity) for the
operating point that maximises net useful output, rather than always
running the compressor flat out.

Running at full available capacity is not automatically optimal once
auxiliary/parasitic loads are considered: pump power in this engine's model
is set by loop flow, not thermal duty, so above the point where COP starts
falling faster than duty rises, throttling back the compressor can improve
net output per unit of electricity even though gross heat recovered falls.
"""

from __future__ import annotations

from dataclasses import dataclass

from scipy.optimize import minimize_scalar

from config.system_config import PlantConfig
from core.engine import InfeasibleOperatingPointError, evaluate_operating_point
from core.state import PlantState, SourceState


@dataclass
class CompressorOptimizationResult:
    plant_state: PlantState | None
    load_fraction: float
    net_thermal_output_w: float
    converged: bool
    evaluations: int


def _config_at_load(config: PlantConfig, load_fraction: float) -> PlantConfig:
    capped_power_mw = config.heat_pump.max_power_mw * load_fraction
    new_heat_pump = config.heat_pump.model_copy(update={"max_power_mw": max(capped_power_mw, 1e-6)})
    return config.model_copy(update={"heat_pump": new_heat_pump})


def maximize_net_output_over_loading(
    config: PlantConfig,
    source: SourceState,
    evaporating_temperature_k: float,
    condensing_temperature_k: float,
    loop_flow_kg_s: float,
    sink_loop_return_k: float | None = None,
    min_load_fraction: float = 0.1,
) -> CompressorOptimizationResult:
    evaluations = 0
    best_state: PlantState | None = None

    def objective(load_fraction: float) -> float:
        nonlocal evaluations, best_state
        evaluations += 1
        try:
            state = evaluate_operating_point(
                _config_at_load(config, load_fraction), source, evaporating_temperature_k,
                condensing_temperature_k, loop_flow_kg_s, sink_loop_return_k,
            )
        except InfeasibleOperatingPointError:
            return 1e6
        if best_state is None or state.metrics.net_thermal_output_w > best_state.metrics.net_thermal_output_w:
            best_state = state
        return -state.metrics.net_thermal_output_w

    result = minimize_scalar(objective, bounds=(min_load_fraction, 1.0), method="bounded")

    if best_state is None:
        return CompressorOptimizationResult(None, 1.0, 0.0, False, evaluations)

    return CompressorOptimizationResult(
        plant_state=best_state,
        load_fraction=float(result.x),
        net_thermal_output_w=best_state.metrics.net_thermal_output_w,
        converged=bool(result.success),
        evaluations=evaluations,
    )
