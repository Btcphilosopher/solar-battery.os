"""
Thermal storage charge/hold/discharge optimiser (section 11).

Two policies are provided:

- `greedy_dispatch`: a fast, always-available rule — charge with any
  recovered-heat surplus above current demand (when the source is
  currently generous), discharge to cover a shortfall (when it is not),
  otherwise hold. This is what the real-time control loop
  (core.simulation_loop) uses every timestep.
- `optimise_horizon`: a look-ahead linear program over a forecast horizon
  (recovered-heat and demand forecasts) that chooses the charge/discharge
  schedule minimising unmet demand and curtailed surplus, for scenarios
  where storage should be pre-charged ahead of a known future shortfall.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy.optimize import linprog


@dataclass
class DispatchDecision:
    power_request_w: float  # positive = charge, negative = discharge
    reason: str


def greedy_dispatch(
    heat_recovered_w: float,
    heat_demand_w: float,
    storage_energy_content_mwh: float,
    storage_min_mwh: float,
    storage_max_mwh: float,
) -> DispatchDecision:
    surplus_w = heat_recovered_w - heat_demand_w
    if surplus_w > 0:
        if storage_energy_content_mwh < storage_max_mwh:
            return DispatchDecision(surplus_w, "Charging with recovered-heat surplus above current demand")
        return DispatchDecision(0.0, "Surplus available but storage is full: holding (surplus will be curtailed)")
    if surplus_w < 0:
        if storage_energy_content_mwh > storage_min_mwh:
            return DispatchDecision(surplus_w, "Discharging to cover shortfall between recovered heat and demand")
        return DispatchDecision(0.0, "Shortfall exists but storage is empty: holding (demand will be unmet)")
    return DispatchDecision(0.0, "Recovered heat matches demand: holding")


@dataclass
class HorizonDispatchResult:
    charge_power_w: np.ndarray
    discharge_power_w: np.ndarray
    unmet_demand_w: np.ndarray
    curtailed_w: np.ndarray
    feasible: bool


def optimise_horizon(
    forecast_heat_recovered_w: np.ndarray,
    forecast_heat_demand_w: np.ndarray,
    dt_hours: float,
    capacity_mwh: float,
    max_charge_w: float,
    max_discharge_w: float,
    initial_energy_mwh: float,
    min_energy_mwh: float,
    max_energy_mwh: float,
) -> HorizonDispatchResult:
    """
    Minimise total unmet demand plus curtailed surplus over the horizon,
    subject to the storage energy balance, via a linear program (scipy
    linprog, HiGHS backend).

    Decision variables per timestep t: [charge_t, discharge_t, unmet_t, curtailed_t]
    """
    n = len(forecast_heat_recovered_w)
    if len(forecast_heat_demand_w) != n:
        raise ValueError("forecast arrays must be the same length")

    n_vars = 4 * n
    # Objective: minimise unmet demand and curtailed surplus (equally weighted); charge/discharge are free.
    c = np.zeros(n_vars)
    for t in range(n):
        c[4 * t + 2] = 1.0  # unmet
        c[4 * t + 3] = 1.0  # curtailed

    bounds = []
    for _ in range(n):
        bounds.append((0, max_charge_w))
        bounds.append((0, max_discharge_w))
        bounds.append((0, None))  # unmet
        bounds.append((0, None))  # curtailed

    # Equality constraints: recovered_t - demand_t = charge_t - discharge_t - unmet_t + curtailed_t
    # (surplus goes to charge or curtailment; shortfall is met by discharge or left unmet)
    a_eq = np.zeros((n, n_vars))
    b_eq = np.zeros(n)
    for t in range(n):
        net = forecast_heat_recovered_w[t] - forecast_heat_demand_w[t]
        a_eq[t, 4 * t + 0] = -1.0  # -charge
        a_eq[t, 4 * t + 1] = 1.0  # +discharge
        a_eq[t, 4 * t + 2] = 1.0  # +unmet
        a_eq[t, 4 * t + 3] = -1.0  # -curtailed
        b_eq[t] = -net

    # Inequality constraints: cumulative energy content stays within [min, max] at every timestep.
    a_ub = []
    b_ub = []
    for t in range(n):
        row_upper = np.zeros(n_vars)
        row_lower = np.zeros(n_vars)
        for tau in range(t + 1):
            row_upper[4 * tau + 0] = dt_hours / 1e6
            row_upper[4 * tau + 1] = -dt_hours / 1e6
            row_lower[4 * tau + 0] = -dt_hours / 1e6
            row_lower[4 * tau + 1] = dt_hours / 1e6
        a_ub.append(row_upper)
        b_ub.append(max_energy_mwh - initial_energy_mwh)
        a_ub.append(row_lower)
        b_ub.append(initial_energy_mwh - min_energy_mwh)

    result = linprog(c, A_ub=np.array(a_ub), b_ub=np.array(b_ub), A_eq=a_eq, b_eq=b_eq, bounds=bounds, method="highs")

    if not result.success:
        return HorizonDispatchResult(
            np.zeros(n), np.zeros(n), np.full(n, np.nan), np.full(n, np.nan), feasible=False
        )

    x = result.x.reshape(n, 4)
    return HorizonDispatchResult(
        charge_power_w=x[:, 0], discharge_power_w=x[:, 1], unmet_demand_w=x[:, 2], curtailed_w=x[:, 3], feasible=True
    )
