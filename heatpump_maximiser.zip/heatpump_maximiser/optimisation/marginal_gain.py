"""
Automatic marginal-gain search (section 22): continuously asks "where is
the next 1% of system efficiency available?" by testing small, physically
grounded perturbations to the current operating point and configuration,
then ranking them by expected physical benefit.

Each candidate perturbation is evaluated by literally re-solving the whole
plant (core.engine.evaluate_operating_point) with the perturbation applied —
never by an analytic sensitivity estimate — so the ranking is exactly as
trustworthy as the physics engine itself.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from config.system_config import PlantConfig
from core.engine import InfeasibleOperatingPointError, evaluate_operating_point
from core.state import PlantState, SourceState

MetricFn = Callable[[PlantState], float]


def default_metric(state: PlantState) -> float:
    """The metric marginal gains are measured against: net useful thermal output."""
    return state.metrics.net_thermal_output_w


@dataclass
class MarginalGainCandidate:
    name: str
    description: str
    expected_improvement_fraction: float  # e.g. 0.017 == "+1.7%"
    baseline_metric: float
    candidate_metric: float
    plant_state: PlantState | None = None


@dataclass
class Perturbation:
    name: str
    apply: Callable[[PlantConfig, float, float], tuple[PlantConfig, float, float]]
    describe: Callable[[PlantConfig, PlantConfig], str]


def _perturb_hx_effectiveness(step: float = 0.02, cap: float = 0.99) -> Perturbation:
    def apply(config: PlantConfig, evap_k: float, cond_k: float):
        new_value = min(config.heat_exchanger.effectiveness + step, cap)
        new_hx = config.heat_exchanger.model_copy(update={"effectiveness": new_value})
        return config.model_copy(update={"heat_exchanger": new_hx}), evap_k, cond_k

    def describe(before: PlantConfig, after: PlantConfig) -> str:
        return (
            f"Increase heat exchanger effectiveness from {before.heat_exchanger.effectiveness * 100:.0f}% "
            f"to {after.heat_exchanger.effectiveness * 100:.0f}%"
        )

    return Perturbation("heat_exchanger_effectiveness", apply, describe)


def _perturb_compressor_efficiency(step: float = 0.02, cap: float = 0.92) -> Perturbation:
    def apply(config: PlantConfig, evap_k: float, cond_k: float):
        new_value = min(config.heat_pump.isentropic_efficiency + step, cap)
        new_hp = config.heat_pump.model_copy(update={"isentropic_efficiency": new_value})
        return config.model_copy(update={"heat_pump": new_hp}), evap_k, cond_k

    def describe(before: PlantConfig, after: PlantConfig) -> str:
        return (
            f"Improve compressor isentropic efficiency from {before.heat_pump.isentropic_efficiency * 100:.0f}% "
            f"to {after.heat_pump.isentropic_efficiency * 100:.0f}%"
        )

    return Perturbation("compressor_isentropic_efficiency", apply, describe)


def _perturb_reduce_lift(step_k: float = 2.5) -> Perturbation:
    def apply(config: PlantConfig, evap_k: float, cond_k: float):
        return config, evap_k, max(cond_k - step_k, evap_k + 1.0)

    def describe(before: PlantConfig, after: PlantConfig) -> str:
        return f"Reduce compressor lift by {step_k:.1f} degC (accept a lower delivery temperature where demand allows)"

    return Perturbation("reduce_compressor_lift", apply, describe)


def _perturb_fouling_cleaning() -> Perturbation:
    def apply(config: PlantConfig, evap_k: float, cond_k: float):
        new_hx = config.heat_exchanger.model_copy(update={"fouling_factor_m2k_w": 0.0})
        return config.model_copy(update={"heat_exchanger": new_hx}), evap_k, cond_k

    def describe(before: PlantConfig, after: PlantConfig) -> str:
        return (
            f"Clean the source-side heat exchanger "
            f"(remove {before.heat_exchanger.fouling_factor_m2k_w:.2e} m^2 K/W of accumulated fouling resistance)"
        )

    return Perturbation("clean_heat_exchanger", apply, describe)


def _perturb_motor_efficiency(step: float = 0.01, cap: float = 0.98) -> Perturbation:
    def apply(config: PlantConfig, evap_k: float, cond_k: float):
        new_value = min(config.heat_pump.motor_mechanical_efficiency + step, cap)
        new_hp = config.heat_pump.model_copy(update={"motor_mechanical_efficiency": new_value})
        return config.model_copy(update={"heat_pump": new_hp}), evap_k, cond_k

    def describe(before: PlantConfig, after: PlantConfig) -> str:
        return (
            f"Upgrade compressor motor/drive from {before.heat_pump.motor_mechanical_efficiency * 100:.1f}% "
            f"to {after.heat_pump.motor_mechanical_efficiency * 100:.1f}% mechanical efficiency"
        )

    return Perturbation("motor_efficiency", apply, describe)


DEFAULT_PERTURBATIONS: list[Perturbation] = [
    _perturb_hx_effectiveness(),
    _perturb_compressor_efficiency(),
    _perturb_reduce_lift(),
    _perturb_fouling_cleaning(),
    _perturb_motor_efficiency(),
]


def search_marginal_gains(
    config: PlantConfig,
    source: SourceState,
    baseline_evaporating_temperature_k: float,
    baseline_condensing_temperature_k: float,
    loop_flow_kg_s: float,
    sink_loop_return_k: float | None = None,
    metric_fn: MetricFn = default_metric,
    flow_increase_fraction: float = 0.05,
) -> list[MarginalGainCandidate]:
    """
    Evaluate every registered perturbation against the current baseline
    operating point and return candidates ranked by expected fractional
    improvement, largest first — directly answering section 22's "where is
    the next 1% of system efficiency available?".
    """
    try:
        baseline_state = evaluate_operating_point(
            config, source, baseline_evaporating_temperature_k, baseline_condensing_temperature_k,
            loop_flow_kg_s, sink_loop_return_k,
        )
    except InfeasibleOperatingPointError:
        return []

    baseline_metric = metric_fn(baseline_state)
    candidates: list[MarginalGainCandidate] = []

    for perturbation in DEFAULT_PERTURBATIONS:
        new_config, new_evap_k, new_cond_k = perturbation.apply(
            config, baseline_evaporating_temperature_k, baseline_condensing_temperature_k
        )
        try:
            candidate_state = evaluate_operating_point(
                new_config, source, new_evap_k, new_cond_k, loop_flow_kg_s, sink_loop_return_k
            )
        except InfeasibleOperatingPointError:
            continue
        candidate_metric = metric_fn(candidate_state)
        if baseline_metric == 0:
            continue
        improvement = (candidate_metric - baseline_metric) / abs(baseline_metric)
        candidates.append(MarginalGainCandidate(
            name=perturbation.name,
            description=perturbation.describe(config, new_config),
            expected_improvement_fraction=improvement,
            baseline_metric=baseline_metric,
            candidate_metric=candidate_metric,
            plant_state=candidate_state,
        ))

    # Loop-flow increase is a call-time argument, not a config field, so it's
    # evaluated directly here rather than through the Perturbation interface.
    increased_flow = loop_flow_kg_s * (1.0 + flow_increase_fraction)
    try:
        flow_state = evaluate_operating_point(
            config, source, baseline_evaporating_temperature_k, baseline_condensing_temperature_k,
            increased_flow, sink_loop_return_k,
        )
        flow_metric = metric_fn(flow_state)
        if baseline_metric != 0:
            candidates.append(MarginalGainCandidate(
                name="increase_loop_flow",
                description=f"Increase low-temperature loop flow by {flow_increase_fraction * 100:.0f}%",
                expected_improvement_fraction=(flow_metric - baseline_metric) / abs(baseline_metric),
                baseline_metric=baseline_metric,
                candidate_metric=flow_metric,
                plant_state=flow_state,
            ))
    except InfeasibleOperatingPointError:
        pass

    candidates.sort(key=lambda c: c.expected_improvement_fraction, reverse=True)
    return candidates
