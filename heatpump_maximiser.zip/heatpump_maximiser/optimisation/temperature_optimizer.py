"""
Temperature-lift optimiser (section 9): sweeps delivery temperature at a
fixed source/evaporating temperature and reports how COP, compressor power
and useful heat change — then finds the true optimum against a chosen
scoring function (default: net thermal output) rather than assuming a fixed
delivery temperature.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import pandas as pd
from scipy.optimize import minimize_scalar

from config.system_config import PlantConfig
from core.engine import InfeasibleOperatingPointError, evaluate_operating_point
from core.state import PlantState, SourceState
from thermodynamics.properties import c_to_k, k_to_c

ScoreFn = Callable[[PlantState], float]


def default_score(state: PlantState) -> float:
    return state.metrics.net_thermal_output_w


def sweep_delivery_temperature(
    config: PlantConfig,
    source: SourceState,
    evaporating_temperature_k: float,
    loop_flow_kg_s: float,
    delivery_temperatures_c: list[float],
    sink_loop_return_k: float | None = None,
) -> pd.DataFrame:
    """Section 9's table: for each candidate delivery temperature, resolve the plant state."""
    pinch = config.heat_pump.condenser_pinch_k
    rows = []
    for delivery_c in delivery_temperatures_c:
        condensing_temperature_k = c_to_k(delivery_c) + pinch
        try:
            state = evaluate_operating_point(
                config, source, evaporating_temperature_k, condensing_temperature_k,
                loop_flow_kg_s, sink_loop_return_k,
            )
        except InfeasibleOperatingPointError as exc:
            rows.append({
                "delivery_temperature_c": delivery_c, "feasible": False, "reason": str(exc),
                "cop": None, "compressor_power_mw": None, "heat_recovered_mw": None,
                "heat_delivered_mw": None, "net_thermal_output_mw": None, "exergy_efficiency": None,
            })
            continue
        rows.append({
            "delivery_temperature_c": delivery_c,
            "feasible": True,
            "reason": "",
            "cop": state.metrics.cop,
            "compressor_power_mw": state.metrics.electrical_input_w / 1e6,
            "heat_recovered_mw": state.metrics.heat_recovered_w / 1e6,
            "heat_delivered_mw": state.metrics.heat_delivered_w / 1e6,
            "net_thermal_output_mw": state.metrics.net_thermal_output_w / 1e6,
            "exergy_efficiency": state.metrics.exergy_efficiency,
        })
    return pd.DataFrame(rows)


@dataclass
class TemperatureOptimizationResult:
    plant_state: PlantState | None
    delivery_temperature_k: float
    score: float
    converged: bool
    evaluations: int


def find_optimal_delivery_temperature(
    config: PlantConfig,
    source: SourceState,
    evaporating_temperature_k: float,
    loop_flow_kg_s: float,
    delivery_temperature_min_c: float,
    delivery_temperature_max_c: float,
    sink_loop_return_k: float | None = None,
    score_fn: ScoreFn = default_score,
) -> TemperatureOptimizationResult:
    """Find the delivery temperature that maximises `score_fn`, via bounded 1-D search (not just the grid sweep)."""
    pinch = config.heat_pump.condenser_pinch_k
    evaluations = 0
    best_state: PlantState | None = None
    best_score = float("-inf")

    def objective(delivery_temperature_c: float) -> float:
        nonlocal evaluations, best_state, best_score
        evaluations += 1
        condensing_temperature_k = c_to_k(delivery_temperature_c) + pinch
        try:
            state = evaluate_operating_point(
                config, source, evaporating_temperature_k, condensing_temperature_k,
                loop_flow_kg_s, sink_loop_return_k,
            )
        except InfeasibleOperatingPointError:
            return 1e12
        score = score_fn(state)
        if score > best_score:
            best_score = score
            best_state = state
        return -score

    result = minimize_scalar(
        objective, bounds=(delivery_temperature_min_c, delivery_temperature_max_c), method="bounded"
    )

    if best_state is None:
        return TemperatureOptimizationResult(None, c_to_k(delivery_temperature_min_c), float("-inf"), False, evaluations)

    return TemperatureOptimizationResult(
        plant_state=best_state,
        delivery_temperature_k=best_state.metrics.delivery_temperature_k,
        score=best_score,
        converged=bool(result.success),
        evaluations=evaluations,
    )
