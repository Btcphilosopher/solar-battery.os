"""
Plant configuration.

The entire plant — waste-heat source, heat exchanger, heat pump, thermal
storage, downstream steam cycle, and the optimiser itself — is described by
data, never hard-coded. `PlantConfig` is the single Pydantic model that
represents one plant description; it can be built in Python, loaded from
YAML/JSON, or received as a JSON body over the API (api/server.py).
"""

from __future__ import annotations

from pathlib import Path
from typing import Literal

import yaml
from pydantic import BaseModel, Field, model_validator


class EnvironmentConfig(BaseModel):
    """Ambient / dead-state reference used throughout exergy analysis."""

    ambient_temperature_c: float = 15.0
    ambient_pressure_pa: float = 101_325.0


class HeatSourceConfig(BaseModel):
    """Waste-heat stream available for recovery."""

    kind: Literal["generic", "datacentre", "industrial"] = "generic"
    fluid: str = "Water"
    temperature_c: float = Field(..., description="Waste-heat stream supply temperature, degC")
    flow_kg_s: float = Field(..., gt=0, description="Mass flow rate of the source stream, kg/s")
    pressure_pa: float = 200_000.0
    min_return_temperature_c: float = Field(
        20.0, description="Coldest the source may be returned to the process (fouling/freezing/process limits)"
    )
    max_extraction_rate_mw: float | None = Field(
        None, description="Hard cap on extractable thermal power regardless of what temperatures allow"
    )

    @model_validator(mode="after")
    def _check_return_temperature(self) -> "HeatSourceConfig":
        if self.min_return_temperature_c >= self.temperature_c:
            raise ValueError(
                "min_return_temperature_c must be below the source supply temperature_c "
                "(there must be a positive delta-T available to extract)"
            )
        return self


class DataCentreSourceConfig(BaseModel):
    """Data-centre specific inputs, converted into a HeatSourceConfig by heat_source/datacentre.py."""

    it_load_mw: float = Field(..., ge=0)
    cooling_load_mw: float | None = None
    server_utilisation: float = Field(0.6, ge=0, le=1)
    gpu_load_fraction: float = Field(0.0, ge=0, le=1)
    cpu_load_fraction: float = Field(0.6, ge=0, le=1)
    network_load_fraction: float = Field(0.1, ge=0, le=1)
    heat_capture_fraction: float = Field(
        0.65, ge=0, le=1,
        description="Fraction of IT electrical load actually captured as usable waste heat at a recoverable "
                    "temperature (never 1.0: casing/room losses, low-grade air paths, and unrecovered exhaust exist)",
    )
    coolant_fluid: str = "Water"
    coolant_supply_temperature_c: float = 35.0
    coolant_flow_kg_s: float = Field(..., gt=0)


class HeatExchangerConfig(BaseModel):
    """Waste-heat side heat exchanger between the source loop and the heat-pump evaporator loop."""

    ua_w_k: float | None = Field(None, description="Overall UA, W/K; if omitted, effectiveness is used directly")
    effectiveness: float = Field(0.90, gt=0, le=1)
    fouling_factor_m2k_w: float = Field(0.0, ge=0, description="Additional fouling thermal resistance, m^2 K/W")
    approach_temperature_k: float = Field(3.0, ge=0, description="Minimum approach temperature, K")
    pressure_drop_design_pa: float = Field(40_000.0, ge=0)


class HeatPumpConfig(BaseModel):
    """Vapour-compression heat pump plant limits and refrigerant selection."""

    refrigerant: str = "R1234ze(E)"
    max_power_mw: float = Field(..., gt=0, description="Maximum compressor electrical input, MW")
    min_power_mw: float = Field(0.0, ge=0)
    min_source_temperature_c: float = -10.0
    max_sink_temperature_c: float = 90.0
    isentropic_efficiency: float = Field(0.75, gt=0, le=1)
    volumetric_efficiency: float = Field(0.95, gt=0, le=1)
    motor_mechanical_efficiency: float = Field(0.95, gt=0, le=1)
    evaporator_superheat_k: float = Field(5.0, ge=0)
    condenser_subcooling_k: float = Field(3.0, ge=0)
    evaporator_pinch_k: float = Field(4.0, ge=0, description="Source-to-refrigerant pinch at the evaporator, K")
    condenser_pinch_k: float = Field(4.0, ge=0, description="Refrigerant-to-sink pinch at the condenser, K")
    max_pressure_ratio: float = Field(6.0, gt=1)
    stages: int = Field(1, ge=1, le=3, description="Number of cascaded compression stages")

    @model_validator(mode="after")
    def _check_temperature_range(self) -> "HeatPumpConfig":
        if self.max_sink_temperature_c <= self.min_source_temperature_c:
            raise ValueError("max_sink_temperature_c must exceed min_source_temperature_c")
        return self


class ThermalStorageConfig(BaseModel):
    """Sensible hot-water / phase-change thermal buffer."""

    enabled: bool = True
    kind: Literal["hot_water", "phase_change"] = "hot_water"
    capacity_mwh: float = Field(4.0, ge=0)
    max_charge_mw: float = Field(2.0, ge=0)
    max_discharge_mw: float = Field(2.0, ge=0)
    standing_loss_fraction_per_hour: float = Field(0.005, ge=0, le=1)
    min_state_of_charge: float = Field(0.05, ge=0, le=1)
    max_state_of_charge: float = Field(0.98, ge=0, le=1)
    initial_state_of_charge: float = Field(0.5, ge=0, le=1)
    phase_change_temperature_c: float | None = Field(
        None, description="Melt/freeze temperature for phase_change storage; ignored for hot_water"
    )


class SteamCycleConfig(BaseModel):
    """Optional downstream steam-generation / turbine / generator pathway."""

    enabled: bool = False
    steam_pressure_pa: float = 400_000.0
    turbine_isentropic_efficiency: float = Field(0.80, gt=0, le=1)
    generator_efficiency: float = Field(0.97, gt=0, le=1)
    condenser_pressure_pa: float = 10_000.0
    minimum_delivery_temperature_c: float = Field(
        130.0, description="Hot-water temperature below which steam generation is not attempted"
    )


class OptimisationConfig(BaseModel):
    """Optimiser objective, weights, search method, and control interval."""

    objective: Literal[
        "maximum_heat_recovery",
        "maximum_cop",
        "minimum_electricity",
        "maximum_net_energy",
        "maximum_exergy_efficiency",
        "maximum_useful_value",
        "weighted_multiobjective",
    ] = "maximum_net_energy"
    weights: dict[str, float] = Field(
        default_factory=lambda: {
            "heat_recovery": 0.25,
            "cop": 0.15,
            "net_output": 0.35,
            "exergy_efficiency": 0.25,
        }
    )
    method: Literal["L-BFGS-B", "SLSQP", "differential_evolution", "least_squares"] = "SLSQP"
    interval_seconds: float = Field(60.0, gt=0)
    delivery_temperature_search_min_c: float = 40.0
    delivery_temperature_search_max_c: float = 90.0
    delivery_temperature_search_step_c: float = 5.0

    @model_validator(mode="after")
    def _check_weights(self) -> "OptimisationConfig":
        if self.objective == "weighted_multiobjective" and abs(sum(self.weights.values()) - 1.0) > 1e-6:
            raise ValueError(f"weights must sum to 1.0, got {sum(self.weights.values()):.6f}")
        return self


class EconomicsConfig(BaseModel):
    """Optional economic layer — never the optimisation objective by default, only a reporting overlay."""

    enabled: bool = False
    electricity_price_per_mwh: float = 90.0
    heat_value_per_mwh: float = 45.0
    export_electricity_price_per_mwh: float = 60.0


class DemandConfig(BaseModel):
    """Downstream heat demand the plant is trying to serve."""

    required_delivery_temperature_c: float = 60.0
    heat_demand_mw: float | None = Field(None, description="If set, caps useful recovery at this demand")


class PlantConfig(BaseModel):
    """Top-level configuration for one complete plant."""

    name: str = "heatpump_maximiser plant"
    environment: EnvironmentConfig = Field(default_factory=EnvironmentConfig)
    heat_source: HeatSourceConfig
    datacentre_source: DataCentreSourceConfig | None = None
    heat_exchanger: HeatExchangerConfig = Field(default_factory=HeatExchangerConfig)
    heat_pump: HeatPumpConfig
    thermal_storage: ThermalStorageConfig = Field(default_factory=ThermalStorageConfig)
    steam_cycle: SteamCycleConfig = Field(default_factory=SteamCycleConfig)
    demand: DemandConfig = Field(default_factory=DemandConfig)
    optimisation: OptimisationConfig = Field(default_factory=OptimisationConfig)
    economics: EconomicsConfig = Field(default_factory=EconomicsConfig)

    model_config = {"extra": "forbid"}


def load_config(path: str | Path) -> PlantConfig:
    """Load a PlantConfig from a YAML or JSON file."""
    path = Path(path)
    text = path.read_text()
    if path.suffix.lower() in (".yaml", ".yml"):
        data = yaml.safe_load(text)
    else:
        import json

        data = json.loads(text)
    return PlantConfig.model_validate(data)


def save_config(config: PlantConfig, path: str | Path) -> None:
    """Serialise a PlantConfig to YAML."""
    path = Path(path)
    path.write_text(yaml.safe_dump(config.model_dump(mode="json"), sort_keys=False))


def default_config() -> PlantConfig:
    """A representative data-centre waste-heat recovery plant, used as the out-of-the-box example."""
    return PlantConfig(
        heat_source=HeatSourceConfig(
            kind="datacentre",
            temperature_c=35.0,
            flow_kg_s=300.0,
            min_return_temperature_c=25.0,
        ),
        datacentre_source=DataCentreSourceConfig(
            it_load_mw=10.0,
            server_utilisation=0.7,
            gpu_load_fraction=0.4,
            cpu_load_fraction=0.5,
            network_load_fraction=0.1,
            heat_capture_fraction=0.65,
            coolant_supply_temperature_c=35.0,
            coolant_flow_kg_s=300.0,
        ),
        heat_exchanger=HeatExchangerConfig(effectiveness=0.90, approach_temperature_k=3.0),
        heat_pump=HeatPumpConfig(
            refrigerant="R1234ze(E)",
            max_power_mw=2.0,
            min_source_temperature_c=15.0,
            max_sink_temperature_c=90.0,
        ),
        thermal_storage=ThermalStorageConfig(enabled=True, capacity_mwh=4.0),
        steam_cycle=SteamCycleConfig(enabled=False),
        demand=DemandConfig(required_delivery_temperature_c=62.5),
        optimisation=OptimisationConfig(objective="maximum_net_energy", interval_seconds=60.0),
    )
