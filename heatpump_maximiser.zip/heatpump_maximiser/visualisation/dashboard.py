"""
Engineering dashboard (section 26): assembles the COP map, heat-flow
diagram, exergy waterfall, and optimisation curves for one resolved plant
state (plus optional sweep/candidate data) into a single self-contained
HTML report.
"""

from __future__ import annotations

from pathlib import Path

import plotly.graph_objects as go
from plotly.subplots import make_subplots

from core.state import PlantState
from visualisation.thermal_graphs import plot_exergy_waterfall, plot_heat_flow_sankey, plot_temperature_profile


def build_dashboard(
    state: PlantState,
    sweep_df=None,
    candidates: list[PlantState] | None = None,
    marginal_gains=None,
) -> go.Figure:
    """Compose the core figures into one multi-panel dashboard figure."""
    rows, cols = 2, 2
    fig = make_subplots(
        rows=rows, cols=cols,
        specs=[[{"type": "sankey"}, {"type": "waterfall"}], [{"type": "scatter"}, {"type": "scatter"}]],
        subplot_titles=("Heat flow", "Exergy-loss waterfall", "Temperature profile", "COP vs delivery temperature"),
    )

    sankey = plot_heat_flow_sankey(state)
    for trace in sankey.data:
        fig.add_trace(trace, row=1, col=1)

    waterfall = plot_exergy_waterfall(state)
    for trace in waterfall.data:
        fig.add_trace(trace, row=1, col=2)

    temp_profile = plot_temperature_profile(state)
    for trace in temp_profile.data:
        fig.add_trace(trace, row=2, col=1)

    if sweep_df is not None:
        feasible = sweep_df[sweep_df["feasible"]]
        fig.add_trace(
            go.Scatter(x=feasible["delivery_temperature_c"], y=feasible["cop"], mode="lines+markers", name="COP"),
            row=2, col=2,
        )

    fig.update_layout(height=900, width=1200, title_text="Heat Pump Thermal Recovery Maximiser — Dashboard", showlegend=False)
    return fig


def save_dashboard_html(state: PlantState, path: str | Path, sweep_df=None) -> Path:
    fig = build_dashboard(state, sweep_df=sweep_df)
    path = Path(path)
    fig.write_html(str(path), include_plotlyjs="cdn")
    return path
