"""
COP map and COP-related plots (section 26).
"""

from __future__ import annotations

import matplotlib.figure
import numpy as np
import plotly.graph_objects as go

from config.system_config import PlantConfig
from core.engine import InfeasibleOperatingPointError, evaluate_operating_point
from core.state import SourceState


def compute_cop_map(
    config: PlantConfig,
    source: SourceState,
    loop_flow_kg_s: float,
    evap_range_k: tuple[float, float],
    lift_range_k: tuple[float, float],
    n: int = 25,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Grid of COP over (evaporating temperature, temperature lift). Returns (evap_temps_k, lifts_k, cop_grid)."""
    evap_temps = np.linspace(*evap_range_k, n)
    lifts = np.linspace(*lift_range_k, n)
    cop_grid = np.full((n, n), np.nan)
    for i, evap_k in enumerate(evap_temps):
        for j, lift_k in enumerate(lifts):
            cond_k = evap_k + lift_k
            try:
                state = evaluate_operating_point(config, source, float(evap_k), float(cond_k), loop_flow_kg_s)
            except InfeasibleOperatingPointError:
                continue
            if state.metrics.heat_recovered_w > 0:
                cop_grid[j, i] = state.metrics.cop
    return evap_temps, lifts, cop_grid


def plot_cop_map_matplotlib(evap_temps_k: np.ndarray, lifts_k: np.ndarray, cop_grid: np.ndarray) -> matplotlib.figure.Figure:
    fig = matplotlib.figure.Figure(figsize=(7, 5))
    ax = fig.add_subplot(111)
    mesh = ax.pcolormesh(evap_temps_k - 273.15, lifts_k, cop_grid, shading="auto", cmap="viridis")
    fig.colorbar(mesh, ax=ax, label="COP")
    ax.set_xlabel("Evaporating temperature (degC)")
    ax.set_ylabel("Temperature lift (K)")
    ax.set_title("COP map")
    return fig


def plot_cop_map_plotly(evap_temps_k: np.ndarray, lifts_k: np.ndarray, cop_grid: np.ndarray) -> go.Figure:
    fig = go.Figure(data=go.Heatmap(
        z=cop_grid, x=evap_temps_k - 273.15, y=lifts_k, colorscale="Viridis", colorbar={"title": "COP"},
    ))
    fig.update_layout(
        title="COP map", xaxis_title="Evaporating temperature (degC)", yaxis_title="Temperature lift (K)",
    )
    return fig


def plot_cop_vs_delivery_temperature(sweep_df) -> go.Figure:
    """sweep_df: output of optimisation.temperature_optimizer.sweep_delivery_temperature."""
    feasible = sweep_df[sweep_df["feasible"]]
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=feasible["delivery_temperature_c"], y=feasible["cop"], mode="lines+markers", name="COP"))
    fig.update_layout(title="COP vs delivery temperature", xaxis_title="Delivery temperature (degC)", yaxis_title="COP")
    return fig
