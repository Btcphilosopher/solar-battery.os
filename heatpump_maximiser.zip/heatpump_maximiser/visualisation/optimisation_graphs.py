"""
Optimisation-curve visualisation (section 26): COP vs delivery temperature,
net useful energy vs compressor power, exergy efficiency vs temperature lift.
"""

from __future__ import annotations

import plotly.graph_objects as go

from core.state import PlantState


def plot_net_energy_vs_compressor_power(states: list[PlantState]) -> go.Figure:
    x = [s.metrics.electrical_input_w / 1e6 for s in states]
    y = [s.metrics.net_thermal_output_w / 1e6 for s in states]
    order = sorted(range(len(x)), key=lambda i: x[i])
    fig = go.Figure(go.Scatter(x=[x[i] for i in order], y=[y[i] for i in order], mode="lines+markers"))
    fig.update_layout(
        title="Net useful energy vs compressor power",
        xaxis_title="Compressor electrical power (MW)",
        yaxis_title="Net thermal output (MW)",
    )
    return fig


def plot_exergy_efficiency_vs_lift(states: list[PlantState]) -> go.Figure:
    x = [s.heat_pump.temperature_lift_k for s in states]
    y = [s.metrics.exergy_efficiency for s in states]
    order = sorted(range(len(x)), key=lambda i: x[i])
    fig = go.Figure(go.Scatter(x=[x[i] for i in order], y=[y[i] for i in order], mode="lines+markers"))
    fig.update_layout(
        title="Exergy efficiency vs temperature lift",
        xaxis_title="Temperature lift (K)",
        yaxis_title="Exergy (second-law) efficiency",
    )
    return fig


def plot_pareto_frontier(states: list[PlantState]) -> go.Figure:
    x = [s.metrics.net_thermal_output_w / 1e6 for s in states]
    y = [s.metrics.exergy_efficiency for s in states]
    fig = go.Figure(go.Scatter(x=x, y=y, mode="markers+lines", marker={"size": 9}))
    fig.update_layout(
        title="Pareto frontier: net output vs exergy efficiency",
        xaxis_title="Net thermal output (MW)",
        yaxis_title="Exergy efficiency",
    )
    return fig


def plot_marginal_gains(candidates) -> go.Figure:
    """candidates: list[optimisation.marginal_gain.MarginalGainCandidate], ranked."""
    names = [c.description for c in candidates]
    values = [c.expected_improvement_fraction * 100 for c in candidates]
    fig = go.Figure(go.Bar(x=values, y=names, orientation="h"))
    fig.update_layout(
        title="Marginal-gain ranking", xaxis_title="Expected improvement (%)", yaxis={"autorange": "reversed"},
    )
    return fig
