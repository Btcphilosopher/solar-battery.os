"""
Heat-flow (Sankey-style) and exergy-waterfall visualisation (sections 14, 26).
"""

from __future__ import annotations

import plotly.graph_objects as go

from core.state import PlantState


def plot_heat_flow_sankey(state: PlantState) -> go.Figure:
    """
    DATA CENTRE -> HEAT EXCHANGER -> HEAT PUMP -> HOT WATER, with rejected /
    curtailed heat and auxiliary consumption shown as their own terminal nodes.
    """
    labels = [
        "Waste heat source", "Heat exchanger", "Heat pump", "Hot water delivery",
        "Rejected (unrecovered) heat", "Compressor electrical input", "Auxiliary loads",
    ]
    source_available_mw = state.source.available_heat_w / 1e6
    recovered_mw = state.metrics.heat_recovered_w / 1e6
    rejected_mw = max(source_available_mw - recovered_mw, 0.0)
    delivered_mw = state.metrics.heat_delivered_w / 1e6
    electrical_mw = state.metrics.electrical_input_w / 1e6
    aux_mw = state.auxiliary.total_w / 1e6

    fig = go.Figure(data=go.Sankey(
        node=dict(label=labels, pad=20, thickness=18),
        link=dict(
            source=[0, 0, 1, 2, 5, 2],
            target=[1, 4, 2, 3, 2, 6],
            value=[source_available_mw, rejected_mw, recovered_mw, delivered_mw, electrical_mw, aux_mw],
        ),
    ))
    fig.update_layout(title_text="Waste-heat recovery flow (MW)", font_size=12)
    return fig


def plot_exergy_waterfall(state: PlantState) -> go.Figure:
    """Section 14's exergy-loss waterfall: cumulative exergy destroyed at each stage of the chain."""
    stages = state.exergy.stages
    names = [s.name for s in stages]
    destroyed_kw = [s.exergy_destroyed_w / 1e3 for s in stages]

    fig = go.Figure(go.Waterfall(
        name="Exergy destroyed",
        orientation="v",
        measure=["relative"] * len(stages),
        x=names,
        y=[-d for d in destroyed_kw],
        base=state.exergy.total_exergy_supplied_w / 1e3,
        decreasing={"marker": {"color": "#d1495b"}},
        connector={"line": {"color": "#999999"}},
    ))
    fig.update_layout(
        title="Exergy-loss waterfall",
        yaxis_title="Exergy (kW)",
        showlegend=False,
    )
    return fig


def plot_temperature_profile(state: PlantState) -> go.Figure:
    """Source -> low-temp loop -> evaporator -> condenser -> delivery temperature profile."""
    stages = ["Source", "HX cold out / evap in", "Evaporating", "Condensing", "Delivery"]
    temps_c = [
        state.source.temperature_c,
        state.heat_exchanger.cold_out_k - 273.15,
        state.heat_pump.evaporating_temperature_k - 273.15,
        state.heat_pump.condensing_temperature_k - 273.15,
        state.metrics.delivery_temperature_k - 273.15,
    ]
    fig = go.Figure(go.Scatter(x=stages, y=temps_c, mode="lines+markers"))
    fig.update_layout(title="Temperature profile through the plant", yaxis_title="Temperature (degC)")
    return fig
