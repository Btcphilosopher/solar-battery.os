"""
The real-time optimisation loop (sections 2 and 18):

    MEASURE -> UNDERSTAND -> CALCULATE -> PREDICT -> OPTIMISE -> CONTROL -> MEASURE AGAIN

`run_timestep` executes one full cycle of that loop for one measured source
condition; `run_simulation` drives it across a time series at a configurable
control interval.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import pandas as pd

from config.system_config import PlantConfig
from core.engine import evaluate_operating_point
from core.events import EventLog
from core.state import PlantState, SourceState, utc_now
from optimisation.multiobjective import optimise_weighted, weighted_score
from optimisation.storage_optimizer import greedy_dispatch
from optimisation.temperature_optimizer import (
    ScoreFn,
    default_score,
    find_optimal_delivery_temperature,
)
from thermal_network.thermal_storage import ThermalStorage
from thermodynamics.properties import c_to_k

OBJECTIVE_SCORES: dict[str, ScoreFn] = {
    "maximum_heat_recovery": lambda s: s.metrics.heat_recovered_w,
    "maximum_cop": lambda s: s.metrics.cop,
    "minimum_electricity": lambda s: -s.metrics.electrical_input_w,
    "maximum_net_energy": lambda s: s.metrics.net_thermal_output_w,
    "maximum_exergy_efficiency": lambda s: s.metrics.exergy_efficiency,
    "maximum_useful_value": lambda s: s.metrics.net_thermal_output_w,  # economics overlay applied by the caller if enabled
}


def evaporator_offset_k(config: PlantConfig, extra_margin_k: float = 3.0) -> float:
    """How far below the low-temperature loop's inlet the evaporating temperature must sit to draw any duty at all."""
    return config.heat_pump.evaporator_pinch_k + config.heat_exchanger.approach_temperature_k + extra_margin_k


@dataclass
class TimestepResult:
    plant_state: PlantState
    storage_reason: str
    events: EventLog


def run_timestep(
    config: PlantConfig,
    source: SourceState,
    dt_hours: float,
    storage: ThermalStorage | None = None,
    sink_loop_return_k: float | None = None,
    events: EventLog | None = None,
) -> TimestepResult:
    """One MEASURE -> ... -> CONTROL cycle."""
    events = events if events is not None else EventLog()

    # --- UNDERSTAND / CALCULATE: feasible evaporating temperature ---
    evap_temp_k = source.temperature_k - evaporator_offset_k(config)
    evap_temp_k = max(evap_temp_k, c_to_k(config.heat_pump.min_source_temperature_c))

    loop_flow_kg_s = source.flow_kg_s

    delivery_min_c = config.optimisation.delivery_temperature_search_min_c
    delivery_max_c = min(
        config.optimisation.delivery_temperature_search_max_c,
        config.heat_pump.max_sink_temperature_c - config.heat_pump.condenser_pinch_k,
    )

    # --- OPTIMISE: pick the setpoint per the configured objective ---
    if config.optimisation.objective == "weighted_multiobjective":
        evap_bounds = (c_to_k(config.heat_pump.min_source_temperature_c), evap_temp_k)
        cond_bounds = (c_to_k(delivery_min_c) + config.heat_pump.condenser_pinch_k,
                       c_to_k(delivery_max_c) + config.heat_pump.condenser_pinch_k)
        weighted_result = optimise_weighted(
            config, source, evap_bounds, cond_bounds, loop_flow_kg_s, sink_loop_return_k=sink_loop_return_k,
        )
        best_state = weighted_result.plant_state
        if best_state is None:
            events.critical("optimiser", "No feasible operating point found for weighted multi-objective search")
            raise RuntimeError("No feasible operating point found")
    else:
        score_fn = OBJECTIVE_SCORES.get(config.optimisation.objective, default_score)
        result = find_optimal_delivery_temperature(
            config, source, evap_temp_k, loop_flow_kg_s, delivery_min_c, delivery_max_c,
            sink_loop_return_k=sink_loop_return_k, score_fn=score_fn,
        )
        best_state = result.plant_state
        if best_state is None:
            events.critical("optimiser", "No feasible operating point found across the delivery-temperature search range")
            raise RuntimeError("No feasible operating point found")

    # --- CONTROL: dispatch thermal storage against the chosen setpoint, then
    # re-resolve the plant state once more so storage's effect on the report
    # (and on the energy balance) is captured consistently ---
    storage_reason = "Thermal storage disabled or unavailable"
    if storage is not None and config.thermal_storage.enabled:
        demand_w = (config.demand.heat_demand_mw or 0.0) * 1e6
        decision = greedy_dispatch(
            heat_recovered_w=best_state.metrics.heat_delivered_w,
            heat_demand_w=demand_w,
            storage_energy_content_mwh=storage.energy_content_mwh,
            storage_min_mwh=config.thermal_storage.min_state_of_charge * config.thermal_storage.capacity_mwh,
            storage_max_mwh=config.thermal_storage.max_state_of_charge * config.thermal_storage.capacity_mwh,
        )
        storage_reason = decision.reason
        best_state = evaluate_operating_point(
            config, source, best_state.heat_pump.evaporating_temperature_k, best_state.heat_pump.condensing_temperature_k,
            loop_flow_kg_s, sink_loop_return_k, storage=storage, dt_hours=dt_hours,
            storage_power_request_w=decision.power_request_w, events=events,
        )

    return TimestepResult(plant_state=best_state, storage_reason=storage_reason, events=events)


def run_simulation(
    config: PlantConfig,
    source_timeseries: pd.DataFrame,
    dt_hours: float,
    storage: ThermalStorage | None = None,
    fluid: str = "Water",
    pressure_pa: float = 200_000.0,
) -> pd.DataFrame:
    """
    Drive run_timestep across a time series of measured source conditions.

    `source_timeseries` must have columns: timestamp, temperature_c,
    flow_kg_s, and optionally min_return_temperature_c, available_heat_mw.
    """
    from thermodynamics.properties import specific_heat

    rows = []
    for _, row in source_timeseries.iterrows():
        temperature_k = c_to_k(row["temperature_c"])
        flow_kg_s = float(row["flow_kg_s"])
        min_return_c = row.get("min_return_temperature_c", row["temperature_c"] - 10.0)
        cp = specific_heat(fluid, temperature_k, pressure_pa)
        available_heat_w = flow_kg_s * cp * (row["temperature_c"] - min_return_c)
        if "available_heat_mw" in row and pd.notna(row["available_heat_mw"]):
            available_heat_w = row["available_heat_mw"] * 1e6

        source = SourceState(
            fluid=fluid, temperature_k=temperature_k, flow_kg_s=flow_kg_s, pressure_pa=pressure_pa,
            specific_heat_j_kgk=cp, min_return_temperature_k=c_to_k(min_return_c),
            available_heat_w=max(available_heat_w, 0.0),
        )
        try:
            result = run_timestep(config, source, dt_hours, storage=storage)
        except RuntimeError:
            rows.append({"timestamp": row.get("timestamp", utc_now()), "feasible": False})
            continue

        m = result.plant_state.metrics
        rows.append({
            "timestamp": row.get("timestamp", utc_now()),
            "feasible": True,
            "status": result.plant_state.status,
            "source_temperature_c": row["temperature_c"],
            "delivery_temperature_c": m.delivery_temperature_k - 273.15,
            "cop": m.cop,
            "heat_recovered_mw": m.heat_recovered_w / 1e6,
            "heat_delivered_mw": m.heat_delivered_w / 1e6,
            "electrical_input_mw": m.electrical_input_w / 1e6,
            "net_thermal_output_mw": m.net_thermal_output_w / 1e6,
            "net_electrical_output_mw": m.net_electrical_output_w / 1e6,
            "exergy_efficiency": m.exergy_efficiency,
            "system_efficiency": m.system_efficiency,
            "storage_soc": result.plant_state.storage.state_of_charge if result.plant_state.storage else None,
            "storage_reason": result.storage_reason,
        })

    return pd.DataFrame(rows)
