"""
Shared runtime state model.

Every module in the engine reads and/or produces one of these dataclasses.
Keeping them centralised (rather than letting each module invent its own
loose dict/tuple) is what makes the "traceable back to measurable
thermodynamic quantities" requirement possible: any number in a report can
be traced to the field of a state object that produced it.

Plain (mutable where useful) dataclasses are used here rather than Pydantic:
this is the hot path of the simulation loop / optimiser inner loop, and
these objects are constructed thousands of times per optimisation call, so
validation is enforced explicitly (see validation/) rather than on every
field assignment.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone

from thermodynamics.exergy import ExergyWaterfall


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


@dataclass
class SourceState:
    """The waste-heat stream as measured/estimated at a timestep."""

    fluid: str
    temperature_k: float
    flow_kg_s: float
    pressure_pa: float
    specific_heat_j_kgk: float
    min_return_temperature_k: float
    available_heat_w: float
    max_extraction_rate_w: float | None = None

    @property
    def temperature_c(self) -> float:
        return self.temperature_k - 273.15


@dataclass
class HeatExchangerState:
    """Result of solving the source-side heat exchanger for one operating point."""

    hot_in_k: float
    hot_out_k: float
    cold_in_k: float
    cold_out_k: float
    duty_w: float
    effectiveness: float
    ntu: float
    pressure_drop_pa: float
    fouling_factor_m2k_w: float


@dataclass
class RefrigerantCyclePoint:
    """One labelled state point around the vapour-compression cycle."""

    label: str
    temperature_k: float
    pressure_pa: float
    enthalpy_j_kg: float
    entropy_j_kgk: float
    quality: float


@dataclass
class HeatPumpOperatingPoint:
    """A fully resolved heat-pump operating point: every cycle state plus the resulting performance numbers."""

    refrigerant: str
    evaporating_temperature_k: float
    condensing_temperature_k: float
    refrigerant_mass_flow_kg_s: float
    compressor_power_w: float
    heat_absorbed_w: float
    heat_rejected_w: float
    cop_heating: float
    cop_cooling: float
    isentropic_efficiency: float
    pressure_ratio: float
    delivery_temperature_k: float
    source_temperature_k: float
    carnot_cop: float
    second_law_efficiency: float
    states: list[RefrigerantCyclePoint] = field(default_factory=list)

    @property
    def temperature_lift_k(self) -> float:
        return self.condensing_temperature_k - self.evaporating_temperature_k


@dataclass
class ThermalStorageState:
    """Hot buffer / thermal store state."""

    state_of_charge: float
    energy_content_mwh: float
    capacity_mwh: float
    temperature_k: float
    mode: str  # "charge" | "hold" | "discharge"
    charge_power_w: float = 0.0
    discharge_power_w: float = 0.0
    standing_loss_w: float = 0.0


@dataclass
class SteamCycleState:
    """Downstream steam generator / turbine / generator state, when engaged."""

    engaged: bool
    steam_mass_flow_kg_s: float
    steam_pressure_pa: float
    steam_temperature_k: float
    steam_quality: float
    turbine_isentropic_efficiency: float
    gross_electrical_power_w: float
    generator_efficiency: float
    net_electrical_power_w: float
    thermal_input_w: float
    cycle_efficiency: float


@dataclass
class AuxiliaryLoads:
    """Parasitic electrical consumption, tracked separately so it can never be silently dropped."""

    source_pump_w: float = 0.0
    refrigerant_pump_w: float = 0.0
    condenser_fan_w: float = 0.0
    cooling_system_w: float = 0.0
    controls_w: float = 0.0

    @property
    def total_w(self) -> float:
        return (
            self.source_pump_w
            + self.refrigerant_pump_w
            + self.condenser_fan_w
            + self.cooling_system_w
            + self.controls_w
        )


@dataclass
class PerformanceMetrics:
    """Section-20 performance metrics, computed once per timestep/operating point."""

    heat_recovered_w: float
    heat_delivered_w: float
    cop: float
    electrical_input_w: float
    net_thermal_output_w: float
    net_electrical_output_w: float
    source_temperature_k: float
    delivery_temperature_k: float
    temperature_lift_k: float
    mass_flow_kg_s: float
    exergy_efficiency: float
    exergy_destroyed_w: float
    heat_exchanger_effectiveness: float
    compressor_efficiency: float
    pump_consumption_w: float
    system_efficiency: float
    motor_losses_w: float = 0.0

    @property
    def specific_electricity_kwh_per_mwh_heat(self) -> float:
        """kWh electricity consumed per MWh useful heat delivered."""
        if self.heat_delivered_w <= 0:
            return float("inf")
        return (self.electrical_input_w / 1000.0) / (self.heat_delivered_w / 1e6)

    @property
    def useful_heat_fraction_of_available(self) -> float:
        """MWh useful heat per MWh waste heat available — filled in by the caller who knows available heat."""
        return float("nan")


@dataclass
class PlantState:
    """The complete, validated state of the plant at one instant."""

    timestamp: datetime
    source: SourceState
    heat_exchanger: HeatExchangerState
    heat_pump: HeatPumpOperatingPoint
    storage: ThermalStorageState | None
    steam_cycle: SteamCycleState | None
    auxiliary: AuxiliaryLoads
    metrics: PerformanceMetrics
    exergy: ExergyWaterfall
    status: str = "OPTIMAL"
    warnings: list[str] = field(default_factory=list)


@dataclass
class OptimisationResult:
    """The output of one optimisation cycle: the chosen setpoint plus the state it produces."""

    objective_name: str
    objective_value: float
    plant_state: PlantState
    delivery_temperature_k: float
    compressor_power_w: float
    converged: bool
    iterations: int
    candidate_count: int
    all_candidates: list[PlantState] = field(default_factory=list)
