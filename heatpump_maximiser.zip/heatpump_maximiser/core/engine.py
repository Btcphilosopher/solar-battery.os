"""
The engine: turns a decision (evaporating temperature, condensing
temperature, and the low-temperature loop flow) plus a measured source
state into one fully resolved, physically validated PlantState.

This is the single function every optimiser in optimisation/ calls
repeatedly (thousands of times in an inner loop), and the function
core.simulation_loop drives once per timestep with the optimiser's chosen
setpoint. Keeping it here — rather than duplicated inside each
optimiser — is what makes every reported number traceable back to the same
physics no matter which code path produced it.
"""

from __future__ import annotations

from dataclasses import dataclass

from config.system_config import PlantConfig
from core.events import EventLog
from core.state import (
    AuxiliaryLoads,
    PerformanceMetrics,
    PlantState,
    SourceState,
    ThermalStorageState,
    utc_now,
)
from heat_exchanger.exchanger import HeatExchanger
from heat_exchanger.pressure_drop import pumping_power
from heat_pump.heat_pump import HeatPump, HeatPumpLimitError
from thermal_network.cold_loop import solve_cold_loop
from thermal_network.hot_loop import solve_hot_loop
from thermal_network.steam_cycle import evaluate_pathway
from thermal_network.thermal_storage import ThermalStorage
from thermodynamics.enthalpy import volumetric_flow
from thermodynamics.exergy import ExergyWaterfall, exergy_of_heat, second_law_efficiency
from thermodynamics.properties import DEFAULT_ENVIRONMENT, PropertyError, ReferenceEnvironment, c_to_k
from validation.energy_balance import validate_plant_energy_balance
from validation.thermodynamic_limits import check_heat_pump_limits, check_refrigerant_envelope


class InfeasibleOperatingPointError(RuntimeError):
    """Raised when a requested (evap_temp, cond_temp) pair cannot produce any valid plant state."""


@dataclass
class Decision:
    """The optimiser's chosen setpoint for one timestep."""

    evaporating_temperature_k: float
    condensing_temperature_k: float
    low_temp_loop_flow_kg_s: float
    storage_power_request_w: float = 0.0


def build_exergy_waterfall(
    source: SourceState,
    cold_loop_duty_w: float,
    cold_loop_supply_k: float,
    evaporating_temperature_k: float,
    heat_absorbed_w: float,
    compressor_power_w: float,
    condensing_temperature_k: float,
    heat_rejected_w: float,
    delivery_temperature_k: float,
    hot_loop_duty_w: float,
    environment: ReferenceEnvironment = DEFAULT_ENVIRONMENT,
) -> ExergyWaterfall:
    """Section 14: the stage-by-stage exergy-loss waterfall for one operating point."""
    source_exergy = exergy_of_heat(cold_loop_duty_w, source.temperature_k, environment)
    waterfall = ExergyWaterfall(source_exergy_in_w=source_exergy)

    hx_exergy_out = exergy_of_heat(cold_loop_duty_w, cold_loop_supply_k, environment)
    waterfall.add_stage("Heat exchanger", source_exergy, hx_exergy_out, note="Finite-approach heat transfer loss")

    evap_exergy_out = exergy_of_heat(heat_absorbed_w, evaporating_temperature_k, environment)
    waterfall.add_stage("Evaporator", hx_exergy_out, evap_exergy_out, note="Evaporator pinch loss")

    condenser_exergy_out = exergy_of_heat(heat_rejected_w, condensing_temperature_k, environment)
    waterfall.add_stage(
        "Compressor + expansion valve", evap_exergy_out, condenser_exergy_out,
        exergy_added_w=compressor_power_w,  # electricity is pure exergy, injected here
        note="Irreversible compression and isenthalpic throttling",
    )

    delivery_exergy_out = exergy_of_heat(hot_loop_duty_w, delivery_temperature_k, environment)
    waterfall.add_stage("Condenser / delivery", condenser_exergy_out, delivery_exergy_out, note="Condenser pinch loss")

    return waterfall


def evaluate_operating_point(
    config: PlantConfig,
    source: SourceState,
    evaporating_temperature_k: float,
    condensing_temperature_k: float,
    low_temp_loop_flow_kg_s: float,
    sink_loop_return_k: float | None = None,
    storage: ThermalStorage | None = None,
    dt_hours: float = 1.0 / 60.0,
    storage_power_request_w: float = 0.0,
    events: EventLog | None = None,
) -> PlantState:
    """Resolve one complete, physically validated plant state from a chosen operating point."""
    events = events if events is not None else EventLog()
    environment = ReferenceEnvironment(
        temperature_k=c_to_k(config.environment.ambient_temperature_c),
        pressure_pa=config.environment.ambient_pressure_pa,
    )

    # Reject configuration-level equipment-envelope violations immediately,
    # before any property lookup is attempted with the requested
    # temperature: a wildly out-of-range evaporating temperature can put the
    # low-temperature loop below the loop fluid's freezing point, which
    # should surface as "this operating point is infeasible", not as a raw
    # property-solver crash.
    min_evap_k = c_to_k(config.heat_pump.min_source_temperature_c)
    max_cond_k = c_to_k(config.heat_pump.max_sink_temperature_c)
    if evaporating_temperature_k < min_evap_k - 1e-6:
        raise InfeasibleOperatingPointError(
            f"evaporating_temperature_k {evaporating_temperature_k:.2f} K is below the configured "
            f"minimum source temperature {min_evap_k:.2f} K"
        )
    if condensing_temperature_k > max_cond_k + 1e-6:
        raise InfeasibleOperatingPointError(
            f"condensing_temperature_k {condensing_temperature_k:.2f} K exceeds the configured "
            f"maximum sink temperature {max_cond_k:.2f} K"
        )
    if condensing_temperature_k <= evaporating_temperature_k:
        raise InfeasibleOperatingPointError("condensing_temperature_k must exceed evaporating_temperature_k")

    if sink_loop_return_k is None:
        # Default: assume the delivery network returns roughly the demand's
        # required temperature minus a typical network delta-T, but never
        # above what this specific operating point can actually deliver
        # (a network serving a lower delivery temperature necessarily
        # returns cooler too).
        nominal_return_k = c_to_k(config.demand.required_delivery_temperature_c) - 15.0
        max_feasible_return_k = condensing_temperature_k - config.heat_pump.condenser_pinch_k - 5.0
        sink_loop_return_k = min(nominal_return_k, max_feasible_return_k)

    heat_exchanger = HeatExchanger(config.heat_exchanger, design_flow_kg_s=source.flow_kg_s)
    try:
        cold_loop = solve_cold_loop(
            source=source,
            heat_exchanger=heat_exchanger,
            loop_fluid="Water",
            loop_flow_kg_s=low_temp_loop_flow_kg_s,
            loop_pressure_pa=200_000.0,
            evaporating_temperature_k=evaporating_temperature_k,
            evaporator_pinch_k=config.heat_pump.evaporator_pinch_k,
        )
    except PropertyError as exc:
        # The requested operating point puts the low-temperature loop fluid
        # outside its valid property range (e.g. below freezing) — a
        # property-solver failure here means "infeasible", not "crash".
        raise InfeasibleOperatingPointError(str(exc)) from exc

    heat_pump = HeatPump(config.heat_pump)

    envelope_check = check_refrigerant_envelope(heat_pump.refrigerant, evaporating_temperature_k, condensing_temperature_k)
    if not envelope_check.passed:
        raise InfeasibleOperatingPointError("; ".join(envelope_check.violations))

    try:
        hp_result = heat_pump.operate(
            low_temp_loop_fluid="Water",
            low_temp_loop_in_k=cold_loop.loop_supply_k,
            low_temp_loop_flow_kg_s=low_temp_loop_flow_kg_s,
            low_temp_loop_pressure_pa=200_000.0,
            evaporating_temperature_k=evaporating_temperature_k,
            sink_loop_fluid="Water",
            sink_loop_in_k=sink_loop_return_k,
            sink_loop_pressure_pa=400_000.0,
            condensing_temperature_k=condensing_temperature_k,
        )
    except HeatPumpLimitError as exc:
        raise InfeasibleOperatingPointError(str(exc)) from exc

    limit_check = check_heat_pump_limits(hp_result.operating_point, config.heat_pump.max_pressure_ratio)
    for violation in limit_check.violations:
        events.warning("heat_pump", violation)

    if hp_result.compressor_limited:
        events.info("heat_pump", "Operating point is compressor-power-limited")
    if hp_result.source_limited and not hp_result.compressor_limited:
        events.info("heat_pump", "Operating point is source-heat-limited")

    hot_loop = solve_hot_loop(
        fluid="Water",
        return_temperature_k=sink_loop_return_k,
        delivery_temperature_k=hp_result.operating_point.delivery_temperature_k,
        duty_w=hp_result.cycle.heat_rejected_w,
        pressure_pa=400_000.0,
    )

    # --- Auxiliary / parasitic loads ---
    v_flow = volumetric_flow(low_temp_loop_flow_kg_s, "Water", source.temperature_k, 200_000.0)
    source_pump_w = pumping_power(cold_loop.heat_exchanger_state.pressure_drop_pa, v_flow, pump_efficiency=0.7)
    controls_w = 2_000.0  # fixed housekeeping load: controllers, instrumentation
    auxiliary = AuxiliaryLoads(source_pump_w=source_pump_w, controls_w=controls_w)

    # --- Thermal storage ---
    storage_state: ThermalStorageState | None = None
    if storage is not None and config.thermal_storage.enabled:
        storage_state = storage.step(storage_power_request_w, dt_hours, hot_loop.delivery_temperature_k)

    # --- Optional downstream steam pathway ---
    # Steam-side auxiliaries (feedwater/condensate pumps, cooling) are not
    # separately modelled; whole-plant auxiliary load is netted once, below,
    # against total plant electricity — so the pathway itself is evaluated
    # against zero additional load to avoid double-subtracting `auxiliary`.
    steam_state = None
    if config.steam_cycle.enabled:
        pathway = evaluate_pathway(
            config.steam_cycle,
            hot_water_temperature_k=hot_loop.delivery_temperature_k,
            hot_water_flow_kg_s=hot_loop.flow_kg_s,
            hot_water_pressure_pa=400_000.0,
            auxiliary_loads=AuxiliaryLoads(),
        )
        steam_state = pathway.state
        if pathway.state.engaged and not pathway.worthwhile:
            events.info("steam_cycle", pathway.reason)

    # Heat actually processed by the cycle — this may be less than the loop's
    # potential duty (cold_loop.duty_w) when the compressor is the binding
    # constraint (compressor_limited). Use the actual figure everywhere so
    # First-Law bookkeeping stays exact; cold_loop.duty_w remains available
    # on the HeatExchangerState as the loop's raw (unconstrained) potential.
    actual_recovered_w = hp_result.cycle.heat_absorbed_w

    # --- Exergy waterfall ---
    waterfall = build_exergy_waterfall(
        source=source,
        cold_loop_duty_w=actual_recovered_w,
        cold_loop_supply_k=cold_loop.loop_supply_k,
        evaporating_temperature_k=evaporating_temperature_k,
        heat_absorbed_w=hp_result.cycle.heat_absorbed_w,
        compressor_power_w=hp_result.operating_point.compressor_power_w,
        condensing_temperature_k=condensing_temperature_k,
        heat_rejected_w=hp_result.cycle.heat_rejected_w,
        delivery_temperature_k=hot_loop.delivery_temperature_k,
        hot_loop_duty_w=hot_loop.duty_w,
        environment=environment,
    )

    # --- Net-energy accounting (design principle: NET ENERGY) ---
    electrical_input_w = hp_result.operating_point.compressor_power_w
    steam_gross_electrical_w = (
        steam_state.gross_electrical_power_w if steam_state and steam_state.engaged else 0.0
    )
    # Whole-plant net electrical position: generation (steam turbine, if any)
    # minus every electrical consumer (compressor + pumps/controls), netted
    # exactly once.
    net_electrical_w = steam_gross_electrical_w - electrical_input_w - auxiliary.total_w
    net_thermal_output_w = hot_loop.duty_w - (storage_state.charge_power_w if storage_state else 0.0)

    system_efficiency = 0.0
    if source.available_heat_w > 0:
        system_efficiency = hot_loop.duty_w / source.available_heat_w

    # Motor electrical-to-shaft conversion loss: drawn from the grid but not
    # delivered to the refrigerant, so it must appear as a loss (not
    # recovered heat) in the plant-wide energy balance rather than vanish.
    motor_losses_w = (
        hp_result.cycle.compressor.electrical_power_w - hp_result.cycle.compressor.shaft_power_w
    )

    metrics = PerformanceMetrics(
        heat_recovered_w=actual_recovered_w,
        heat_delivered_w=hot_loop.duty_w,
        cop=hp_result.operating_point.cop_heating,
        electrical_input_w=electrical_input_w,
        net_thermal_output_w=net_thermal_output_w,
        net_electrical_output_w=net_electrical_w,
        source_temperature_k=source.temperature_k,
        delivery_temperature_k=hot_loop.delivery_temperature_k,
        temperature_lift_k=hp_result.operating_point.temperature_lift_k,
        mass_flow_kg_s=hp_result.operating_point.refrigerant_mass_flow_kg_s,
        exergy_efficiency=waterfall.overall_second_law_efficiency,
        exergy_destroyed_w=waterfall.total_exergy_destroyed_w,
        heat_exchanger_effectiveness=cold_loop.heat_exchanger_state.effectiveness,
        compressor_efficiency=hp_result.operating_point.isentropic_efficiency,
        pump_consumption_w=auxiliary.total_w,
        system_efficiency=system_efficiency,
        motor_losses_w=motor_losses_w,
    )

    state = PlantState(
        timestamp=utc_now(),
        source=source,
        heat_exchanger=cold_loop.heat_exchanger_state,
        heat_pump=hp_result.operating_point,
        storage=storage_state,
        steam_cycle=steam_state,
        auxiliary=auxiliary,
        metrics=metrics,
        exergy=waterfall,
        status="OPTIMAL" if limit_check.passed else "WARNING",
        warnings=list(limit_check.violations),
    )

    balance = validate_plant_energy_balance(state)
    if not balance.is_balanced:
        events.warning("energy_balance", balance.summary())
        state.status = "WARNING"
        state.warnings.append(balance.summary())

    return state
