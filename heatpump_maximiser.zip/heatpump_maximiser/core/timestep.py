"""
Timestep context: what the engine knows "right now".
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from core.state import utc_now


@dataclass(frozen=True)
class TimestepContext:
    timestamp: datetime = field(default_factory=utc_now)
    dt_hours: float = 1.0 / 60.0  # default: 1-minute control interval

    def __post_init__(self) -> None:
        if self.dt_hours <= 0:
            raise ValueError("dt_hours must be positive")


CONTROL_INTERVALS_SECONDS: dict[str, float] = {
    "1s": 1.0,
    "10s": 10.0,
    "1min": 60.0,
    "5min": 300.0,
    "15min": 900.0,
    "1hour": 3600.0,
}


def interval_to_dt_hours(interval_seconds: float) -> float:
    if interval_seconds <= 0:
        raise ValueError("interval_seconds must be positive")
    return interval_seconds / 3600.0
