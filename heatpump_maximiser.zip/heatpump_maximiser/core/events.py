"""
Plant event log: safety-limit trips, infeasible operating points, storage
saturation, and other conditions worth surfacing without stopping the
simulation loop.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

from core.state import utc_now


class EventSeverity(str, Enum):
    INFO = "INFO"
    WARNING = "WARNING"
    CRITICAL = "CRITICAL"


@dataclass(frozen=True)
class PlantEvent:
    timestamp: datetime
    severity: EventSeverity
    source: str
    message: str


@dataclass
class EventLog:
    events: list[PlantEvent] = field(default_factory=list)

    def record(self, severity: EventSeverity, source: str, message: str, timestamp: datetime | None = None) -> PlantEvent:
        event = PlantEvent(timestamp=timestamp or utc_now(), severity=severity, source=source, message=message)
        self.events.append(event)
        return event

    def info(self, source: str, message: str) -> PlantEvent:
        return self.record(EventSeverity.INFO, source, message)

    def warning(self, source: str, message: str) -> PlantEvent:
        return self.record(EventSeverity.WARNING, source, message)

    def critical(self, source: str, message: str) -> PlantEvent:
        return self.record(EventSeverity.CRITICAL, source, message)

    def has_critical(self) -> bool:
        return any(e.severity == EventSeverity.CRITICAL for e in self.events)

    def recent(self, n: int = 20) -> list[PlantEvent]:
        return self.events[-n:]
