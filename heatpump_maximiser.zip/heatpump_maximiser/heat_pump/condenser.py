"""
Condenser: the interface between the refrigerant circuit and the
high-temperature delivery loop (hot water / process heat / steam-generator
feed).

Symmetric to heat_pump.evaporator: the refrigerant condenses at an
approximately constant saturation temperature `T_cond`; the pinch is taken
at the loop's hottest point, where the loop stream leaves the condenser
having been heated to within `condenser_pinch_k` of `T_cond`:

    loop_out_k (= delivery temperature) = T_cond - pinch_k
"""

from __future__ import annotations

from dataclasses import dataclass

from heat_exchanger.effectiveness import capacity_rate
from thermodynamics.properties import specific_heat


@dataclass
class CondenserResult:
    condensing_temperature_k: float
    loop_in_k: float
    loop_out_k: float
    duty_w: float
    loop_capacity_rate_w_k: float


def solve_condenser(
    loop_fluid: str,
    loop_in_k: float,
    loop_flow_kg_s: float,
    loop_pressure_pa: float,
    condensing_temperature_k: float,
    pinch_k: float,
) -> CondenserResult:
    if loop_flow_kg_s <= 0:
        raise ValueError("loop_flow_kg_s must be positive")
    if pinch_k < 0:
        raise ValueError("pinch_k must be non-negative")

    cp = specific_heat(loop_fluid, loop_in_k, loop_pressure_pa)
    c_loop = capacity_rate(loop_flow_kg_s, cp)

    loop_out_k = condensing_temperature_k - pinch_k
    if loop_out_k <= loop_in_k:
        # The condensing temperature is not high enough above the loop return
        # to deliver any useful temperature rise.
        return CondenserResult(
            condensing_temperature_k=condensing_temperature_k,
            loop_in_k=loop_in_k,
            loop_out_k=loop_in_k,
            duty_w=0.0,
            loop_capacity_rate_w_k=c_loop,
        )

    duty = c_loop * (loop_out_k - loop_in_k)
    return CondenserResult(
        condensing_temperature_k=condensing_temperature_k,
        loop_in_k=loop_in_k,
        loop_out_k=loop_out_k,
        duty_w=duty,
        loop_capacity_rate_w_k=c_loop,
    )


def required_flow_for_delivery(
    loop_fluid: str,
    loop_in_k: float,
    loop_pressure_pa: float,
    target_delivery_k: float,
    duty_w: float,
) -> float:
    """Loop flow rate, kg/s, required to hit a target delivery temperature at a given duty."""
    if target_delivery_k <= loop_in_k:
        raise ValueError("target_delivery_k must exceed loop_in_k")
    cp = specific_heat(loop_fluid, loop_in_k, loop_pressure_pa)
    return duty_w / (cp * (target_delivery_k - loop_in_k))


def min_condensing_temperature(target_delivery_k: float, pinch_k: float) -> float:
    """The lowest condensing temperature that can still deliver the target temperature."""
    return target_delivery_k + pinch_k
