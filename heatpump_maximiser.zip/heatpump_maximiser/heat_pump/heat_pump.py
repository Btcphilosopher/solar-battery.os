"""
HeatPump: the top-level, config-bound heat-pump plant model.

Wraps evaporator / condenser / compressor / expansion-valve / cycle physics
behind a single `operate(...)` call that the optimiser drives. Two
independent decision variables define an operating point (consistent with
section 16 of the design spec, "evaporator pressure" / "condenser
pressure"):

    evaporating_temperature_k  - how far the low-temperature loop is cooled
    condensing_temperature_k   - the delivery temperature (plus pinch)

`operate` enforces every equipment limit in HeatPumpConfig (source/sink
temperature bounds, compressor power, pressure ratio) and returns a fully
resolved HeatPumpOperatingPoint plus the raw component results for
downstream exergy/validation use.
"""

from __future__ import annotations

from dataclasses import dataclass

from config.system_config import HeatPumpConfig
from core.state import HeatPumpOperatingPoint
from heat_pump.condenser import CondenserResult, min_condensing_temperature, solve_condenser
from heat_pump.cycle import CycleResult, solve_cycle, solve_cycle_for_compressor_power
from heat_pump.errors import HeatPumpPhysicsError
from heat_pump.evaporator import EvaporatorResult, max_feasible_evaporating_temperature, solve_evaporator
from heat_pump.refrigerant import Refrigerant
from thermodynamics.properties import c_to_k


class HeatPumpLimitError(RuntimeError):
    """Raised when a requested operating point violates a configured equipment limit."""


@dataclass
class HeatPumpOperationResult:
    operating_point: HeatPumpOperatingPoint
    cycle: CycleResult
    evaporator: EvaporatorResult
    condenser: CondenserResult
    compressor_limited: bool
    source_limited: bool


class HeatPump:
    def __init__(self, config: HeatPumpConfig):
        self.config = config
        self.refrigerant = Refrigerant(config.refrigerant)

    def feasible_evaporating_temperature_range(self, low_temp_loop_in_k: float) -> tuple[float, float]:
        lower = c_to_k(self.config.min_source_temperature_c)
        upper = max_feasible_evaporating_temperature(low_temp_loop_in_k, self.config.evaporator_pinch_k)
        return lower, upper

    def feasible_condensing_temperature_range(self, sink_loop_in_k: float, target_delivery_k: float) -> tuple[float, float]:
        lower = min_condensing_temperature(target_delivery_k, self.config.condenser_pinch_k)
        upper = c_to_k(self.config.max_sink_temperature_c)
        return lower, upper

    def operate(
        self,
        low_temp_loop_fluid: str,
        low_temp_loop_in_k: float,
        low_temp_loop_flow_kg_s: float,
        low_temp_loop_pressure_pa: float,
        evaporating_temperature_k: float,
        sink_loop_fluid: str,
        sink_loop_in_k: float,
        sink_loop_pressure_pa: float,
        condensing_temperature_k: float,
    ) -> HeatPumpOperationResult:
        # --- Equipment-limit validation (section 24: reject the physically/
        # configurationally impossible before any solve is attempted) ---
        t_min_k = c_to_k(self.config.min_source_temperature_c)
        t_max_k = c_to_k(self.config.max_sink_temperature_c)
        if evaporating_temperature_k < t_min_k - 1e-6:
            raise HeatPumpLimitError(
                f"evaporating_temperature_k {evaporating_temperature_k:.2f} K is below the configured "
                f"minimum source temperature {t_min_k:.2f} K"
            )
        if condensing_temperature_k > t_max_k + 1e-6:
            raise HeatPumpLimitError(
                f"condensing_temperature_k {condensing_temperature_k:.2f} K exceeds the configured "
                f"maximum sink temperature {t_max_k:.2f} K"
            )
        if condensing_temperature_k <= evaporating_temperature_k:
            raise HeatPumpLimitError("condensing_temperature_k must exceed evaporating_temperature_k")

        # --- Evaporator: how much heat the low-temperature loop can actually give up ---
        evap_result = solve_evaporator(
            loop_fluid=low_temp_loop_fluid,
            loop_in_k=low_temp_loop_in_k,
            loop_flow_kg_s=low_temp_loop_flow_kg_s,
            loop_pressure_pa=low_temp_loop_pressure_pa,
            evaporating_temperature_k=evaporating_temperature_k,
            pinch_k=self.config.evaporator_pinch_k,
        )

        # --- Solve the refrigerant cycle at full available duty, then clip to compressor capacity ---
        max_power_w = self.config.max_power_mw * 1e6
        source_limited = False
        compressor_limited = False
        try:
            cycle = solve_cycle(
                refrigerant=self.refrigerant,
                evaporating_temperature_k=evaporating_temperature_k,
                condensing_temperature_k=condensing_temperature_k,
                evaporator_duty_w=evap_result.duty_w,
                superheat_k=self.config.evaporator_superheat_k,
                subcooling_k=self.config.condenser_subcooling_k,
                isentropic_efficiency=self.config.isentropic_efficiency,
                mechanical_efficiency=self.config.motor_mechanical_efficiency,
                max_pressure_ratio=self.config.max_pressure_ratio,
            )
        except HeatPumpPhysicsError:
            cycle = None

        if cycle is not None and cycle.compressor.electrical_power_w > max_power_w + 1.0:
            compressor_limited = True
            try:
                cycle = solve_cycle_for_compressor_power(
                    refrigerant=self.refrigerant,
                    evaporating_temperature_k=evaporating_temperature_k,
                    condensing_temperature_k=condensing_temperature_k,
                    compressor_power_w=max_power_w,
                    superheat_k=self.config.evaporator_superheat_k,
                    subcooling_k=self.config.condenser_subcooling_k,
                    isentropic_efficiency=self.config.isentropic_efficiency,
                    mechanical_efficiency=self.config.motor_mechanical_efficiency,
                    max_pressure_ratio=self.config.max_pressure_ratio,
                )
            except HeatPumpPhysicsError:
                cycle = None

            if cycle is not None:
                # Re-derive the evaporator state consistent with the clipped duty
                evap_result = solve_evaporator(
                    loop_fluid=low_temp_loop_fluid,
                    loop_in_k=low_temp_loop_in_k,
                    loop_flow_kg_s=low_temp_loop_flow_kg_s,
                    loop_pressure_pa=low_temp_loop_pressure_pa,
                    evaporating_temperature_k=evaporating_temperature_k,
                    pinch_k=self.config.evaporator_pinch_k,
                )
                if cycle.heat_absorbed_w > evap_result.duty_w + 1.0:
                    # Compressor could in principle draw more heat than the loop can
                    # actually supply at this evap temperature: fall back to the
                    # source-limited (loop-capacity) solution.
                    source_limited = True
                    try:
                        cycle = solve_cycle(
                            refrigerant=self.refrigerant,
                            evaporating_temperature_k=evaporating_temperature_k,
                            condensing_temperature_k=condensing_temperature_k,
                            evaporator_duty_w=evap_result.duty_w,
                            superheat_k=self.config.evaporator_superheat_k,
                            subcooling_k=self.config.condenser_subcooling_k,
                            isentropic_efficiency=self.config.isentropic_efficiency,
                            mechanical_efficiency=self.config.motor_mechanical_efficiency,
                            max_pressure_ratio=self.config.max_pressure_ratio,
                        )
                    except HeatPumpPhysicsError:
                        cycle = None
        else:
            source_limited = evap_result.duty_w > 0

        if cycle is None:
            raise HeatPumpLimitError("No feasible cycle could be solved for the requested operating point")

        condenser_result = solve_condenser(
            loop_fluid=sink_loop_fluid,
            loop_in_k=sink_loop_in_k,
            loop_flow_kg_s=1.0,  # informational: real sink flow is sized by condenser.required_flow_for_delivery
            loop_pressure_pa=sink_loop_pressure_pa,
            condensing_temperature_k=condensing_temperature_k,
            pinch_k=self.config.condenser_pinch_k,
        )
        delivery_temperature_k = condensing_temperature_k - self.config.condenser_pinch_k

        operating_point = cycle.to_operating_point(
            source_temperature_k=low_temp_loop_in_k, delivery_temperature_k=delivery_temperature_k
        )

        return HeatPumpOperationResult(
            operating_point=operating_point,
            cycle=cycle,
            evaporator=evap_result,
            condenser=condenser_result,
            compressor_limited=compressor_limited,
            source_limited=source_limited,
        )


@dataclass
class CascadeStageResult:
    stage_index: int
    result: HeatPumpOperationResult


@dataclass
class CascadeResult:
    stages: list[CascadeStageResult]

    @property
    def total_compressor_power_w(self) -> float:
        return sum(s.result.operating_point.compressor_power_w for s in self.stages)

    @property
    def total_heat_recovered_w(self) -> float:
        """Heat originally drawn from the waste-heat source (the first stage's evaporator duty)."""
        return self.stages[0].result.cycle.heat_absorbed_w if self.stages else 0.0

    @property
    def final_delivery_temperature_k(self) -> float:
        return self.stages[-1].result.operating_point.delivery_temperature_k

    @property
    def overall_cop(self) -> float:
        """Overall system COP: total useful heat delivered by the final stage / total electrical input across all stages."""
        if not self.stages or self.total_compressor_power_w <= 0:
            return 0.0
        return self.stages[-1].result.cycle.heat_rejected_w / self.total_compressor_power_w


def operate_cascade(
    stage_pumps: list[HeatPump],
    low_temp_loop_fluid: str,
    low_temp_loop_in_k: float,
    low_temp_loop_flow_kg_s: float,
    low_temp_loop_pressure_pa: float,
    evaporating_temperatures_k: list[float],
    sink_loop_fluid: str,
    sink_loop_pressure_pa: float,
    condensing_temperatures_k: list[float],
) -> CascadeResult:
    """
    Solve N heat-pump stages in series (section 10):

        WASTE HEAT -> HP1 -> intermediate hot loop -> HP2 -> ... -> final delivery

    Stage i's condenser output (the loop, heated to `condensing_temperatures_k[i] - pinch`)
    becomes stage i+1's low-temperature loop input. The first stage draws
    from the real waste-heat loop; every later stage draws from the loop
    already lifted by the previous stage.
    """
    n = len(stage_pumps)
    if not (len(evaporating_temperatures_k) == len(condensing_temperatures_k) == n):
        raise ValueError("stage_pumps, evaporating_temperatures_k and condensing_temperatures_k must be the same length")
    if n == 0:
        raise ValueError("At least one stage is required")

    stages: list[CascadeStageResult] = []
    loop_in_k = low_temp_loop_in_k
    loop_flow = low_temp_loop_flow_kg_s
    for i, pump in enumerate(stage_pumps):
        result = pump.operate(
            low_temp_loop_fluid=low_temp_loop_fluid if i == 0 else sink_loop_fluid,
            low_temp_loop_in_k=loop_in_k,
            low_temp_loop_flow_kg_s=loop_flow,
            low_temp_loop_pressure_pa=low_temp_loop_pressure_pa if i == 0 else sink_loop_pressure_pa,
            evaporating_temperature_k=evaporating_temperatures_k[i],
            sink_loop_fluid=sink_loop_fluid,
            sink_loop_in_k=loop_in_k,
            sink_loop_pressure_pa=sink_loop_pressure_pa,
            condensing_temperature_k=condensing_temperatures_k[i],
        )
        stages.append(CascadeStageResult(stage_index=i, result=result))
        # The next stage draws from this stage's delivery loop.
        loop_in_k = result.operating_point.delivery_temperature_k

    return CascadeResult(stages=stages)
