"""Shared exception hierarchy for the heat_pump package."""

from __future__ import annotations


class HeatPumpPhysicsError(RuntimeError):
    """
    Raised whenever a requested operating point cannot be realised by the
    refrigerant cycle: an impossible pressure ratio, a non-positive specific
    enthalpy rise, or any other condition that makes the cycle physically
    unsolvable at the requested setpoint. Callers (heat_pump.heat_pump,
    core.engine) treat this uniformly as "this operating point is
    infeasible", not as a bug.
    """
