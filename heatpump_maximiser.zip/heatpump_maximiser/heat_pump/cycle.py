"""
The full single-stage vapour-compression cycle solver.

    EVAPORATOR -> COMPRESSOR -> CONDENSER -> EXPANSION DEVICE -> (back to EVAPORATOR)

Given the two saturation temperatures (evaporating, condensing — themselves
set by the loop temperatures and pinches in heat_pump.evaporator /
heat_pump.condenser) plus superheat, subcooling and compressor efficiency,
this resolves every state point around the cycle and the resulting COP.

State point numbering (standard refrigeration convention):
    1 = compressor suction   (evaporator outlet, superheated vapour)
    2 = compressor discharge (condenser inlet, superheated vapour)
    3 = condenser outlet     (subcooled liquid)
    4 = evaporator inlet     (post-expansion, two-phase)
"""

from __future__ import annotations

from dataclasses import dataclass

from core.state import HeatPumpOperatingPoint, RefrigerantCyclePoint
from heat_pump.compressor import CompressorResult, compress
from heat_pump.errors import HeatPumpPhysicsError
from heat_pump.expansion_valve import ExpansionResult, throttle
from heat_pump.refrigerant import Refrigerant
from thermodynamics.energy_balance import EnergyBalanceResult, heat_pump_energy_balance
from thermodynamics.entropy import carnot_entropy_check
from thermodynamics.properties import FluidState


class CycleInfeasibleError(HeatPumpPhysicsError):
    """Raised when the requested evaporating/condensing temperatures cannot form a valid cycle."""


@dataclass
class CycleResult:
    refrigerant: Refrigerant
    state_1_suction: FluidState
    state_2_discharge: FluidState
    state_3_liquid: FluidState
    state_4_expanded: FluidState
    evaporating_temperature_k: float
    condensing_temperature_k: float
    mass_flow_kg_s: float
    heat_absorbed_w: float
    heat_rejected_w: float
    compressor: CompressorResult
    expansion: ExpansionResult
    energy_balance: EnergyBalanceResult
    cop_heating: float
    cop_cooling: float
    carnot_cop_heating: float
    second_law_efficiency: float

    def to_operating_point(self, source_temperature_k: float, delivery_temperature_k: float) -> HeatPumpOperatingPoint:
        states = [
            RefrigerantCyclePoint("1_suction", self.state_1_suction.temperature_k, self.state_1_suction.pressure_pa,
                                   self.state_1_suction.enthalpy_j_kg, self.state_1_suction.entropy_j_kgk,
                                   self.state_1_suction.quality),
            RefrigerantCyclePoint("2_discharge", self.state_2_discharge.temperature_k, self.state_2_discharge.pressure_pa,
                                   self.state_2_discharge.enthalpy_j_kg, self.state_2_discharge.entropy_j_kgk,
                                   self.state_2_discharge.quality),
            RefrigerantCyclePoint("3_liquid", self.state_3_liquid.temperature_k, self.state_3_liquid.pressure_pa,
                                   self.state_3_liquid.enthalpy_j_kg, self.state_3_liquid.entropy_j_kgk,
                                   self.state_3_liquid.quality),
            RefrigerantCyclePoint("4_expanded", self.state_4_expanded.temperature_k, self.state_4_expanded.pressure_pa,
                                   self.state_4_expanded.enthalpy_j_kg, self.state_4_expanded.entropy_j_kgk,
                                   self.state_4_expanded.quality),
        ]
        return HeatPumpOperatingPoint(
            refrigerant=self.refrigerant.name,
            evaporating_temperature_k=self.evaporating_temperature_k,
            condensing_temperature_k=self.condensing_temperature_k,
            refrigerant_mass_flow_kg_s=self.mass_flow_kg_s,
            compressor_power_w=self.compressor.electrical_power_w,
            heat_absorbed_w=self.heat_absorbed_w,
            heat_rejected_w=self.heat_rejected_w,
            cop_heating=self.cop_heating,
            cop_cooling=self.cop_cooling,
            isentropic_efficiency=self.compressor.isentropic_efficiency,
            pressure_ratio=self.compressor.pressure_ratio,
            delivery_temperature_k=delivery_temperature_k,
            source_temperature_k=source_temperature_k,
            carnot_cop=self.carnot_cop_heating,
            second_law_efficiency=self.second_law_efficiency,
            states=states,
        )


def solve_cycle(
    refrigerant: Refrigerant,
    evaporating_temperature_k: float,
    condensing_temperature_k: float,
    evaporator_duty_w: float,
    superheat_k: float = 5.0,
    subcooling_k: float = 3.0,
    isentropic_efficiency: float = 0.75,
    mechanical_efficiency: float = 0.95,
    max_pressure_ratio: float = 6.0,
) -> CycleResult:
    """
    Solve the full cycle for a target evaporator duty (the duty the
    evaporator/heat-exchanger chain has determined is available to absorb).
    """
    carnot_entropy_check(condensing_temperature_k, evaporating_temperature_k)
    if evaporator_duty_w < 0:
        raise ValueError("evaporator_duty_w must be non-negative")
    if superheat_k < 0 or subcooling_k < 0:
        raise ValueError("superheat_k and subcooling_k must be non-negative")

    refrigerant.check_operating_envelope(evaporating_temperature_k, refrigerant.saturation_pressure_pa(evaporating_temperature_k))
    refrigerant.check_operating_envelope(condensing_temperature_k, refrigerant.saturation_pressure_pa(condensing_temperature_k))

    p_evap = refrigerant.saturation_pressure_pa(evaporating_temperature_k)
    p_cond = refrigerant.saturation_pressure_pa(condensing_temperature_k)

    t_suction = evaporating_temperature_k + superheat_k
    state_1 = refrigerant.state_tp(t_suction, p_evap)

    t_liquid = condensing_temperature_k - subcooling_k
    state_3 = refrigerant.state_tp(t_liquid, p_cond)

    # Isenthalpic expansion is what fixes state 4's enthalpy; solve it first
    # (independent of mass flow) so mass flow can be derived from the
    # evaporator's actual absorption window (h1 - h4).
    expansion_probe = throttle(refrigerant, state_3, p_evap, mass_flow_kg_s=1.0)
    state_4 = expansion_probe.outlet_state

    specific_absorption = state_1.enthalpy_j_kg - state_4.enthalpy_j_kg
    if specific_absorption <= 0:
        raise CycleInfeasibleError(
            "Cycle infeasible: evaporator specific enthalpy rise is non-positive "
            f"(h1={state_1.enthalpy_j_kg:.0f} J/kg, h4={state_4.enthalpy_j_kg:.0f} J/kg) — "
            "check superheat/subcooling and the evaporating/condensing temperature pair"
        )

    if evaporator_duty_w == 0:
        mass_flow = 0.0
    else:
        mass_flow = evaporator_duty_w / specific_absorption

    expansion = throttle(refrigerant, state_3, p_evap, mass_flow_kg_s=mass_flow)

    compressor_result = compress(
        refrigerant=refrigerant,
        suction_state=state_1,
        discharge_pressure_pa=p_cond,
        mass_flow_kg_s=mass_flow,
        isentropic_efficiency=isentropic_efficiency,
        mechanical_efficiency=mechanical_efficiency,
        max_pressure_ratio=max_pressure_ratio,
    )
    state_2 = compressor_result.actual_discharge_state

    heat_absorbed = mass_flow * specific_absorption
    heat_rejected = mass_flow * (state_2.enthalpy_j_kg - state_3.enthalpy_j_kg)

    balance = heat_pump_energy_balance(
        heat_absorbed_w=heat_absorbed,
        compressor_work_w=compressor_result.shaft_power_w,
        heat_rejected_w=heat_rejected,
    )

    cop_heating = heat_rejected / compressor_result.electrical_power_w if compressor_result.electrical_power_w > 0 else 0.0
    cop_cooling = heat_absorbed / compressor_result.electrical_power_w if compressor_result.electrical_power_w > 0 else 0.0
    carnot_cop = condensing_temperature_k / (condensing_temperature_k - evaporating_temperature_k)
    second_law_efficiency = cop_heating / carnot_cop if carnot_cop > 0 else 0.0

    return CycleResult(
        refrigerant=refrigerant,
        state_1_suction=state_1,
        state_2_discharge=state_2,
        state_3_liquid=state_3,
        state_4_expanded=state_4,
        evaporating_temperature_k=evaporating_temperature_k,
        condensing_temperature_k=condensing_temperature_k,
        mass_flow_kg_s=mass_flow,
        heat_absorbed_w=heat_absorbed,
        heat_rejected_w=heat_rejected,
        compressor=compressor_result,
        expansion=expansion,
        energy_balance=balance,
        cop_heating=cop_heating,
        cop_cooling=cop_cooling,
        carnot_cop_heating=carnot_cop,
        second_law_efficiency=second_law_efficiency,
    )


def solve_cycle_for_compressor_power(
    refrigerant: Refrigerant,
    evaporating_temperature_k: float,
    condensing_temperature_k: float,
    compressor_power_w: float,
    superheat_k: float = 5.0,
    subcooling_k: float = 3.0,
    isentropic_efficiency: float = 0.75,
    mechanical_efficiency: float = 0.95,
    max_pressure_ratio: float = 6.0,
) -> CycleResult:
    """
    Solve the cycle for a target *electrical* compressor power rather than a
    target evaporator duty — used when compressor capacity, not source heat,
    is the binding constraint.
    """
    if compressor_power_w < 0:
        raise ValueError("compressor_power_w must be non-negative")

    # Solve with a unit evaporator duty to get the specific (per-kg) work,
    # then rescale mass flow linearly (compressor specific work is
    # independent of mass flow for a fixed pressure ratio and efficiency).
    probe = solve_cycle(
        refrigerant, evaporating_temperature_k, condensing_temperature_k, evaporator_duty_w=1.0,
        superheat_k=superheat_k, subcooling_k=subcooling_k, isentropic_efficiency=isentropic_efficiency,
        mechanical_efficiency=mechanical_efficiency, max_pressure_ratio=max_pressure_ratio,
    )
    # Compressor specific work (J/kg refrigerant, electrical) is independent
    # of mass flow for a fixed pressure ratio and efficiency, so it can be
    # read directly off the unit-duty probe and used to size the real flow.
    specific_work_j_kg = probe.compressor.actual_work_j_kg / probe.compressor.mechanical_efficiency
    if specific_work_j_kg <= 0:
        raise CycleInfeasibleError("Cycle infeasible: non-positive specific compressor work")

    mass_flow = compressor_power_w / specific_work_j_kg
    evaporator_duty_w = mass_flow * (probe.state_1_suction.enthalpy_j_kg - probe.state_4_expanded.enthalpy_j_kg)

    return solve_cycle(
        refrigerant, evaporating_temperature_k, condensing_temperature_k, evaporator_duty_w=evaporator_duty_w,
        superheat_k=superheat_k, subcooling_k=subcooling_k, isentropic_efficiency=isentropic_efficiency,
        mechanical_efficiency=mechanical_efficiency, max_pressure_ratio=max_pressure_ratio,
    )
