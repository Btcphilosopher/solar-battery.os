"""
Expansion device: isenthalpic throttling from condenser (subcooled liquid)
pressure down to evaporator pressure.

Real expansion valves (thermostatic or electronic) are, to a very good
approximation, isenthalpic (no work extracted, negligible heat loss). The
process is irreversible — entropy strictly increases — which is exactly
where a meaningful chunk of the cycle's exergy destruction occurs (see
thermodynamics/exergy.py and the exergy waterfall).
"""

from __future__ import annotations

from dataclasses import dataclass

from heat_pump.refrigerant import Refrigerant
from thermodynamics.entropy import entropy_generation_throttling
from thermodynamics.properties import FluidState


@dataclass
class ExpansionResult:
    inlet_state: FluidState
    outlet_state: FluidState
    mass_flow_kg_s: float
    entropy_generated_w_k: float


def throttle(
    refrigerant: Refrigerant,
    inlet_state: FluidState,
    outlet_pressure_pa: float,
    mass_flow_kg_s: float,
) -> ExpansionResult:
    if outlet_pressure_pa >= inlet_state.pressure_pa:
        raise ValueError("outlet_pressure_pa must be below the inlet pressure for an expansion device")
    if mass_flow_kg_s < 0:
        raise ValueError("mass_flow_kg_s must be non-negative")

    outlet_state = refrigerant.state_ph(outlet_pressure_pa, inlet_state.enthalpy_j_kg)

    s_gen_rate = entropy_generation_throttling(
        mass_flow_kg_s=mass_flow_kg_s,
        fluid=refrigerant.name,
        pressure_in_pa=inlet_state.pressure_pa,
        pressure_out_pa=outlet_pressure_pa,
        enthalpy_j_kg=inlet_state.enthalpy_j_kg,
    )

    return ExpansionResult(
        inlet_state=inlet_state,
        outlet_state=outlet_state,
        mass_flow_kg_s=mass_flow_kg_s,
        entropy_generated_w_k=s_gen_rate,
    )
