"""
Configurable refrigerant access via CoolProp.

The heat-pump model never hard-codes a refrigerant's thermophysical
behaviour: any fluid name CoolProp's HEOS backend recognises (R1234ze(E),
R1234yf, R290 (propane), R717 (ammonia), R744 (CO2), R32, R134a, ...) can be
selected through configuration (config.system_config.HeatPumpConfig.refrigerant).
"""

from __future__ import annotations

from dataclasses import dataclass

from thermodynamics.properties import (
    FluidState,
    PropertyError,
    critical_pressure,
    critical_temperature,
    fluid_limits,
    saturation_pressure,
    saturation_temperature,
    state_from_ph,
    state_from_ps,
    state_from_tp,
)


@dataclass(frozen=True)
class Refrigerant:
    """Thin, validated handle onto one CoolProp refrigerant."""

    name: str

    def __post_init__(self) -> None:
        try:
            critical_temperature(self.name)
        except (PropertyError, ValueError) as exc:
            raise ValueError(f"'{self.name}' is not a refrigerant CoolProp recognises: {exc}") from exc

    @property
    def critical_temperature_k(self) -> float:
        return critical_temperature(self.name)

    @property
    def critical_pressure_pa(self) -> float:
        return critical_pressure(self.name)

    @property
    def limits(self) -> tuple[float, float, float, float]:
        """(T_min, T_max, P_min, P_max) validity envelope."""
        return fluid_limits(self.name)

    def saturation_pressure_pa(self, temperature_k: float) -> float:
        if temperature_k >= self.critical_temperature_k:
            raise ValueError(
                f"{self.name}: saturation is undefined at or above the critical temperature "
                f"({self.critical_temperature_k:.2f} K); requested {temperature_k:.2f} K"
            )
        return saturation_pressure(self.name, temperature_k)

    def saturation_temperature_k(self, pressure_pa: float) -> float:
        if pressure_pa >= self.critical_pressure_pa:
            raise ValueError(
                f"{self.name}: saturation is undefined at or above the critical pressure "
                f"({self.critical_pressure_pa:.0f} Pa); requested {pressure_pa:.0f} Pa"
            )
        return saturation_temperature(self.name, pressure_pa)

    def state_tp(self, temperature_k: float, pressure_pa: float) -> FluidState:
        return state_from_tp(self.name, temperature_k, pressure_pa)

    def state_ph(self, pressure_pa: float, enthalpy_j_kg: float) -> FluidState:
        return state_from_ph(self.name, pressure_pa, enthalpy_j_kg)

    def state_ps(self, pressure_pa: float, entropy_j_kgk: float) -> FluidState:
        return state_from_ps(self.name, pressure_pa, entropy_j_kgk)

    def check_operating_envelope(self, temperature_k: float, pressure_pa: float) -> None:
        t_min, t_max, p_min, p_max = self.limits
        if not (t_min <= temperature_k <= t_max):
            raise ValueError(
                f"{self.name}: temperature {temperature_k:.2f} K outside CoolProp validity range "
                f"[{t_min:.2f}, {t_max:.2f}] K"
            )
        if not (p_min <= pressure_pa <= p_max):
            raise ValueError(
                f"{self.name}: pressure {pressure_pa:.0f} Pa outside CoolProp validity range "
                f"[{p_min:.0f}, {p_max:.0f}] Pa"
            )
