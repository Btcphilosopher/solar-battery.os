"""
Compressor: the sole electrical energy input to the vapour-compression
cycle, and the component whose speed/pressure ratio the optimiser actually
controls.

Real (irreversible) compression is modelled via a fixed isentropic
efficiency:

    h_2,actual = h_1 + (h_2,isentropic - h_1) / eta_isentropic

which is standard practice for a plant-level optimisation engine; the
`isentropic_efficiency` itself can be replaced with a speed/pressure-ratio
map when compressor-specific test data is available (the interface here
does not assume a constant map).
"""

from __future__ import annotations

from dataclasses import dataclass

from heat_pump.errors import HeatPumpPhysicsError
from heat_pump.refrigerant import Refrigerant
from thermodynamics.entropy import isentropic_efficiency_entropy_penalty
from thermodynamics.properties import FluidState


@dataclass
class CompressorResult:
    suction_state: FluidState
    isentropic_discharge_state: FluidState
    actual_discharge_state: FluidState
    pressure_ratio: float
    mass_flow_kg_s: float
    isentropic_work_j_kg: float
    actual_work_j_kg: float
    shaft_power_w: float
    electrical_power_w: float
    isentropic_efficiency: float
    mechanical_efficiency: float
    entropy_generated_w_k: float


def compress(
    refrigerant: Refrigerant,
    suction_state: FluidState,
    discharge_pressure_pa: float,
    mass_flow_kg_s: float,
    isentropic_efficiency: float,
    mechanical_efficiency: float = 0.95,
    max_pressure_ratio: float = 6.0,
) -> CompressorResult:
    if mass_flow_kg_s < 0:
        raise ValueError("mass_flow_kg_s must be non-negative")
    if not (0.0 < isentropic_efficiency <= 1.0):
        raise ValueError("isentropic_efficiency must be in (0, 1]")
    if discharge_pressure_pa <= suction_state.pressure_pa:
        raise ValueError("discharge_pressure_pa must exceed the suction pressure for a compressor")

    pressure_ratio = discharge_pressure_pa / suction_state.pressure_pa
    if pressure_ratio > max_pressure_ratio:
        raise HeatPumpPhysicsError(
            f"Required pressure ratio {pressure_ratio:.2f} exceeds the equipment limit "
            f"{max_pressure_ratio:.2f} — stage the compression (see heat_pump cascading) instead"
        )

    isentropic_discharge = refrigerant.state_ps(discharge_pressure_pa, suction_state.entropy_j_kgk)
    isentropic_work = isentropic_discharge.enthalpy_j_kg - suction_state.enthalpy_j_kg
    if isentropic_work < 0:
        raise ValueError("Second Law violation: isentropic compression work must be non-negative")

    actual_work = isentropic_work / isentropic_efficiency
    actual_discharge_enthalpy = suction_state.enthalpy_j_kg + actual_work
    actual_discharge = refrigerant.state_ph(discharge_pressure_pa, actual_discharge_enthalpy)

    entropy_penalty = isentropic_efficiency_entropy_penalty(
        isentropic_discharge.entropy_j_kgk, actual_discharge.entropy_j_kgk
    )

    shaft_power = mass_flow_kg_s * actual_work
    electrical_power = shaft_power / mechanical_efficiency

    return CompressorResult(
        suction_state=suction_state,
        isentropic_discharge_state=isentropic_discharge,
        actual_discharge_state=actual_discharge,
        pressure_ratio=pressure_ratio,
        mass_flow_kg_s=mass_flow_kg_s,
        isentropic_work_j_kg=isentropic_work,
        actual_work_j_kg=actual_work,
        shaft_power_w=shaft_power,
        electrical_power_w=electrical_power,
        isentropic_efficiency=isentropic_efficiency,
        mechanical_efficiency=mechanical_efficiency,
        entropy_generated_w_k=mass_flow_kg_s * entropy_penalty,
    )
