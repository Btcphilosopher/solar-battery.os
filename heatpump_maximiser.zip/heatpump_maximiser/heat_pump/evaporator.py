"""
Evaporator: the interface between the low-temperature loop (fed by the
source-side heat exchanger) and the refrigerant circuit.

The refrigerant evaporates at an approximately constant saturation
temperature `T_evap`; the pinch point is taken (conservatively, and
consistently with heat_exchanger.exchanger's approach-temperature
convention) at the loop's coldest point, where the loop stream leaves the
evaporator having been cooled to within `evaporator_pinch_k` of `T_evap`:

    loop_out_k = T_evap + pinch_k

This is a pinch-limited design assumption rather than a full NTU solve: it
is the right level of fidelity for a plant-level optimisation engine, and it
degrades gracefully to "no duty" if the loop is already too cold to reach
that pinch.
"""

from __future__ import annotations

from dataclasses import dataclass

from heat_exchanger.effectiveness import capacity_rate
from thermodynamics.properties import specific_heat


@dataclass
class EvaporatorResult:
    evaporating_temperature_k: float
    loop_in_k: float
    loop_out_k: float
    duty_w: float
    loop_capacity_rate_w_k: float


def solve_evaporator(
    loop_fluid: str,
    loop_in_k: float,
    loop_flow_kg_s: float,
    loop_pressure_pa: float,
    evaporating_temperature_k: float,
    pinch_k: float,
) -> EvaporatorResult:
    if loop_flow_kg_s <= 0:
        raise ValueError("loop_flow_kg_s must be positive")
    if pinch_k < 0:
        raise ValueError("pinch_k must be non-negative")

    cp = specific_heat(loop_fluid, loop_in_k, loop_pressure_pa)
    c_loop = capacity_rate(loop_flow_kg_s, cp)

    loop_out_k = evaporating_temperature_k + pinch_k
    if loop_out_k >= loop_in_k:
        # The loop is already too cold to reach the required pinch: no duty.
        return EvaporatorResult(
            evaporating_temperature_k=evaporating_temperature_k,
            loop_in_k=loop_in_k,
            loop_out_k=loop_in_k,
            duty_w=0.0,
            loop_capacity_rate_w_k=c_loop,
        )

    duty = c_loop * (loop_in_k - loop_out_k)
    return EvaporatorResult(
        evaporating_temperature_k=evaporating_temperature_k,
        loop_in_k=loop_in_k,
        loop_out_k=loop_out_k,
        duty_w=duty,
        loop_capacity_rate_w_k=c_loop,
    )


def max_feasible_evaporating_temperature(loop_in_k: float, pinch_k: float) -> float:
    """The highest evaporating temperature that still permits any duty at all: just under loop_in_k - pinch_k."""
    return loop_in_k - pinch_k
