"""
The waste-heat source stream: the physical starting point of the whole
engine (section 5 of the design spec).

`WasteHeatStream` turns raw measurements (temperature, flow, fluid) into a
physically consistent thermal source, and distinguishes the four heat
"tiers" from section 6:

    TOTAL WASTE HEAT
        -> TECHNICALLY RECOVERABLE HEAT      (limited by min return temperature / flow)
        -> THERMODYNAMICALLY USEFUL HEAT     (limited by what the heat pump/HX chain can lift)
        -> ECONOMICALLY USEFUL HEAT          (optimisation/ + economics/ layer, not here)

This module never invents heat: recoverable heat is always <= total
available heat by construction (see `recoverable_heat_w`).
"""

from __future__ import annotations

from dataclasses import dataclass

from core.state import SourceState
from thermodynamics.enthalpy import sensible_heat_rate
from thermodynamics.properties import c_to_k, density, specific_heat


@dataclass
class WasteHeatStream:
    """A waste-heat source stream at one instant."""

    fluid: str
    temperature_c: float
    flow_kg_s: float
    pressure_pa: float = 200_000.0
    min_return_temperature_c: float = 20.0
    max_extraction_rate_mw: float | None = None

    def __post_init__(self) -> None:
        if self.flow_kg_s < 0:
            raise ValueError("flow_kg_s must be non-negative: mass flow cannot be created or destroyed")
        if self.min_return_temperature_c >= self.temperature_c:
            raise ValueError("min_return_temperature_c must be below the source temperature")

    @property
    def temperature_k(self) -> float:
        return c_to_k(self.temperature_c)

    def specific_heat_j_kgk(self) -> float:
        return specific_heat(self.fluid, self.temperature_k, self.pressure_pa)

    def density_kg_m3(self) -> float:
        return density(self.fluid, self.temperature_k, self.pressure_pa)

    def total_available_heat_w(self) -> float:
        """
        TOTAL WASTE HEAT: sensible heat available if the stream were cooled
        all the way to the reference/ambient return temperature. This is a
        theoretical ceiling, not a claim that it is all recoverable.
        """
        cp = self.specific_heat_j_kgk()
        delta_t = self.temperature_c - self.min_return_temperature_c
        return sensible_heat_rate(self.flow_kg_s, cp, delta_t)

    def recoverable_heat_w(self, target_return_temperature_c: float | None = None) -> float:
        """
        TECHNICALLY RECOVERABLE HEAT: heat available down to whichever is
        higher of (a) the caller's proposed return temperature and (b) the
        hard minimum return temperature the process/source will tolerate,
        further capped by any hard extraction-rate limit.

        Never exceeds `total_available_heat_w()`.
        """
        floor_c = self.min_return_temperature_c
        return_temp_c = floor_c if target_return_temperature_c is None else max(target_return_temperature_c, floor_c)
        if return_temp_c >= self.temperature_c:
            return 0.0
        cp = self.specific_heat_j_kgk()
        heat_w = sensible_heat_rate(self.flow_kg_s, cp, self.temperature_c - return_temp_c)
        if self.max_extraction_rate_mw is not None:
            heat_w = min(heat_w, self.max_extraction_rate_mw * 1e6)
        return min(heat_w, self.total_available_heat_w())

    def rejected_heat_w(self, target_return_temperature_c: float | None = None) -> float:
        """Heat that remains in the stream after the technically recoverable portion is extracted."""
        return self.total_available_heat_w() - self.recoverable_heat_w(target_return_temperature_c)

    def to_source_state(self, target_return_temperature_c: float | None = None) -> SourceState:
        cp = self.specific_heat_j_kgk()
        return SourceState(
            fluid=self.fluid,
            temperature_k=self.temperature_k,
            flow_kg_s=self.flow_kg_s,
            pressure_pa=self.pressure_pa,
            specific_heat_j_kgk=cp,
            min_return_temperature_k=c_to_k(self.min_return_temperature_c),
            available_heat_w=self.total_available_heat_w(),
            max_extraction_rate_w=(self.max_extraction_rate_mw * 1e6 if self.max_extraction_rate_mw else None),
        )

    def megawatts_thermal(self, target_return_temperature_c: float | None = None) -> float:
        return self.recoverable_heat_w(target_return_temperature_c) / 1e6

    def megawatt_hours_thermal(self, duration_hours: float, target_return_temperature_c: float | None = None) -> float:
        return self.megawatts_thermal(target_return_temperature_c) * duration_hours
