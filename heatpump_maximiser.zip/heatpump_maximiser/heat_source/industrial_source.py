"""
Generic industrial waste-heat source (compressed air, refrigeration
condensers, furnace flue economisers, wastewater, process cooling loops).

Unlike the data-centre source, industrial processes are described directly
in thermal terms (there is no "IT load" proxy), so this is a thinner
wrapper: it mainly exists to (a) apply process-specific extraction limits
(minimum condensation temperature for flue gas to avoid acid dew point,
minimum wastewater discharge temperature for downstream biological
treatment, etc.) and (b) give the same typed entry point as
`heat_source.datacentre.DataCentreSource` for the scenario/config layer.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from config.system_config import HeatSourceConfig
from heat_source.waste_heat import WasteHeatStream


class IndustrialProcessType(str, Enum):
    COMPRESSED_AIR = "compressed_air"
    REFRIGERATION_CONDENSER = "refrigeration_condenser"
    FLUE_GAS = "flue_gas"
    WASTEWATER = "wastewater"
    PROCESS_COOLING = "process_cooling"
    GENERIC = "generic"


# Physically-motivated floors on how far a stream may be cooled, independent
# of whatever the user configures as min_return_temperature_c. These are
# *raised*, never lowered, against the configured floor.
_PROCESS_FLOOR_C: dict[IndustrialProcessType, float] = {
    IndustrialProcessType.COMPRESSED_AIR: 15.0,
    IndustrialProcessType.REFRIGERATION_CONDENSER: 10.0,
    IndustrialProcessType.FLUE_GAS: 55.0,  # stay above acid dew point for sulphur-bearing fuels
    IndustrialProcessType.WASTEWATER: 10.0,  # downstream biological treatment tolerance
    IndustrialProcessType.PROCESS_COOLING: 15.0,
    IndustrialProcessType.GENERIC: 5.0,
}


@dataclass
class IndustrialSource:
    """Builds a WasteHeatStream from an industrial process description."""

    process_type: IndustrialProcessType
    fluid: str
    temperature_c: float
    flow_kg_s: float
    pressure_pa: float = 200_000.0
    configured_min_return_temperature_c: float = 20.0
    max_extraction_rate_mw: float | None = None

    @property
    def effective_min_return_temperature_c(self) -> float:
        process_floor = _PROCESS_FLOOR_C[self.process_type]
        return max(self.configured_min_return_temperature_c, process_floor)

    def to_waste_heat_stream(self) -> WasteHeatStream:
        return WasteHeatStream(
            fluid=self.fluid,
            temperature_c=self.temperature_c,
            flow_kg_s=self.flow_kg_s,
            pressure_pa=self.pressure_pa,
            min_return_temperature_c=self.effective_min_return_temperature_c,
            max_extraction_rate_mw=self.max_extraction_rate_mw,
        )

    def to_heat_source_config(self) -> HeatSourceConfig:
        return HeatSourceConfig(
            kind="industrial",
            fluid=self.fluid,
            temperature_c=self.temperature_c,
            flow_kg_s=self.flow_kg_s,
            pressure_pa=self.pressure_pa,
            min_return_temperature_c=self.effective_min_return_temperature_c,
            max_extraction_rate_mw=self.max_extraction_rate_mw,
        )
