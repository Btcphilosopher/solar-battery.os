"""
Time-varying source (and ambient) temperature models.

These are intentionally simple, transparent physical/statistical models —
diurnal cycles, linear drift, measured time series — used to drive scenario
and forecasting inputs. They are not a substitute for real sensor data:
`from_series` is the path used whenever real measurements are available.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class DiurnalTemperatureModel:
    """A mean temperature plus a sinusoidal diurnal swing, in degC."""

    mean_c: float
    amplitude_c: float = 0.0
    peak_hour: float = 15.0  # hour of day (0-24) at which the temperature peaks

    def at(self, hours_since_midnight: float) -> float:
        phase = 2.0 * np.pi * (hours_since_midnight - self.peak_hour) / 24.0
        return self.mean_c + self.amplitude_c * np.cos(phase)

    def series(self, timestamps: pd.DatetimeIndex) -> pd.Series:
        hours = timestamps.hour + timestamps.minute / 60.0 + timestamps.second / 3600.0
        values = self.mean_c + self.amplitude_c * np.cos(2.0 * np.pi * (hours - self.peak_hour) / 24.0)
        return pd.Series(values, index=timestamps, name="temperature_c")


@dataclass(frozen=True)
class LinearDriftTemperatureModel:
    """A starting temperature drifting linearly at a fixed rate, degC/hour."""

    start_c: float
    drift_c_per_hour: float

    def at(self, hours_elapsed: float) -> float:
        return self.start_c + self.drift_c_per_hour * hours_elapsed


def from_series(series: pd.Series) -> pd.Series:
    """Pass-through for a real measured temperature time series, degC, indexed by timestamp."""
    if series.isnull().any():
        raise ValueError("Measured temperature series contains missing values; fill or drop before use")
    return series.rename("temperature_c")


def clamp_physical(temperature_c: float, minimum_c: float = -50.0, maximum_c: float = 400.0) -> float:
    """Reject temperature readings outside any physically plausible plant range (sensor-fault guard)."""
    if not (minimum_c <= temperature_c <= maximum_c):
        raise ValueError(f"Temperature reading {temperature_c} degC outside plausible range [{minimum_c}, {maximum_c}]")
    return temperature_c
