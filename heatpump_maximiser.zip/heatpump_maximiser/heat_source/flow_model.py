"""
Time-varying source mass-flow models, and flow <-> load conversions.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class ConstantFlowModel:
    flow_kg_s: float

    def at(self, _hours_elapsed: float) -> float:
        return self.flow_kg_s


@dataclass(frozen=True)
class LoadProportionalFlowModel:
    """Flow that scales linearly with a load fraction between a minimum (idle/standby) and design flow."""

    design_flow_kg_s: float
    minimum_flow_fraction: float = 0.25

    def at(self, load_fraction: float) -> float:
        load_fraction = float(np.clip(load_fraction, 0.0, 1.0))
        fraction = self.minimum_flow_fraction + (1.0 - self.minimum_flow_fraction) * load_fraction
        return self.design_flow_kg_s * fraction


def required_flow_for_duty(
    duty_w: float, specific_heat_j_kgk: float, delta_t_k: float, max_flow_kg_s: float | None = None
) -> float:
    """
    Mass flow, kg/s, required to deliver a given thermal duty across a fixed
    temperature difference:

        m_dot = Q / (cp * delta_T)
    """
    if delta_t_k <= 0:
        raise ValueError("delta_t_k must be positive: cannot deliver duty across a zero or negative delta-T")
    if duty_w < 0:
        raise ValueError("duty_w must be non-negative")
    flow = duty_w / (specific_heat_j_kgk * delta_t_k)
    if max_flow_kg_s is not None:
        flow = min(flow, max_flow_kg_s)
    return flow


def flow_restriction_factor(measured_flow_kg_s: float, design_flow_kg_s: float) -> float:
    """Fraction of design flow actually available (fouled strainers, partial pump trip, throttled valve, etc.)."""
    if design_flow_kg_s <= 0:
        raise ValueError("design_flow_kg_s must be positive")
    return float(np.clip(measured_flow_kg_s / design_flow_kg_s, 0.0, 1.0))


def resample_flow_series(series: pd.Series, target_index: pd.DatetimeIndex) -> pd.Series:
    """Interpolate a measured/forecast flow series onto a target timestamp grid."""
    return series.reindex(series.index.union(target_index)).interpolate("time").reindex(target_index)
