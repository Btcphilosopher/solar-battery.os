"""
Data-centre waste-heat source (section 5).

Converts IT-load style inputs (IT_LOAD, COOLING_LOAD, SERVER_UTILISATION,
GPU_LOAD, CPU_LOAD, NETWORK_LOAD) into a physically consistent
`WasteHeatStream`.

Physical model, deliberately conservative:

1. First Law: essentially all electrical energy consumed by IT equipment is
   ultimately rejected as heat (a data centre does no significant net
   mechanical or chemical work), so the *total* heat generated is bounded
   by `it_load_mw * server_utilisation`.
2. NOT all of that heat is recoverable at a useful temperature. A
   significant fraction leaves via low-grade air paths, casing losses, and
   unrecovered CRAC/CRAH exhaust that never reaches the liquid-cooling loop
   the heat pump draws from. `heat_capture_fraction` (< 1 by construction,
   validated in config) represents this split — this is the single most
   important "do not assume 100% of data-centre electricity becomes
   recoverable heat" guard required by the spec.
3. Workload composition (GPU/CPU/network) affects *where* heat is captured:
   GPU-heavy workloads are increasingly direct-liquid-cooled and yield
   higher, more consistently recoverable coolant temperatures; network and
   general CPU load is more often air-cooled and harder to recover. This is
   expressed as a temperature/capture credit, not a change to the First Law
   bound.
"""

from __future__ import annotations

from dataclasses import dataclass

from config.system_config import DataCentreSourceConfig, HeatSourceConfig
from heat_source.waste_heat import WasteHeatStream

# Empirical credit: fraction-point boost to heat_capture_fraction per unit of
# GPU load fraction, reflecting the higher prevalence of direct-liquid-cooling
# on GPU-dense racks. Capped so capture fraction can never exceed 0.95 (some
# casing/ambient loss is always present).
GPU_CAPTURE_CREDIT_PER_UNIT = 0.15
MAX_HEAT_CAPTURE_FRACTION = 0.95


@dataclass
class DataCentreHeatBreakdown:
    """Traceable breakdown of a data-centre thermal source calculation."""

    it_electrical_load_mw: float
    active_it_load_mw: float
    total_heat_generated_mw: float
    effective_capture_fraction: float
    recoverable_heat_mw: float
    unrecovered_heat_mw: float


class DataCentreSource:
    """Builds a WasteHeatStream from data-centre operating parameters."""

    def __init__(self, config: DataCentreSourceConfig, min_return_temperature_c: float = 20.0):
        self.config = config
        self.min_return_temperature_c = min_return_temperature_c

    def breakdown(self) -> DataCentreHeatBreakdown:
        cfg = self.config
        active_load_mw = cfg.it_load_mw * cfg.server_utilisation
        # Nearly all active electrical load becomes heat (First Law); a small
        # allowance (2%) is made for energy leaving as network/optical signal
        # power and stored battery charging, which is not thermal.
        total_heat_mw = active_load_mw * 0.98

        gpu_credit = min(cfg.gpu_load_fraction * GPU_CAPTURE_CREDIT_PER_UNIT, 0.20)
        effective_capture = min(cfg.heat_capture_fraction + gpu_credit, MAX_HEAT_CAPTURE_FRACTION)

        recoverable_mw = total_heat_mw * effective_capture
        return DataCentreHeatBreakdown(
            it_electrical_load_mw=cfg.it_load_mw,
            active_it_load_mw=active_load_mw,
            total_heat_generated_mw=total_heat_mw,
            effective_capture_fraction=effective_capture,
            recoverable_heat_mw=recoverable_mw,
            unrecovered_heat_mw=total_heat_mw - recoverable_mw,
        )

    def to_waste_heat_stream(self) -> WasteHeatStream:
        cfg = self.config
        breakdown = self.breakdown()
        return WasteHeatStream(
            fluid=cfg.coolant_fluid,
            temperature_c=cfg.coolant_supply_temperature_c,
            flow_kg_s=cfg.coolant_flow_kg_s,
            min_return_temperature_c=self.min_return_temperature_c,
            max_extraction_rate_mw=breakdown.recoverable_heat_mw,
        )

    def to_heat_source_config(self) -> HeatSourceConfig:
        cfg = self.config
        breakdown = self.breakdown()
        return HeatSourceConfig(
            kind="datacentre",
            fluid=cfg.coolant_fluid,
            temperature_c=cfg.coolant_supply_temperature_c,
            flow_kg_s=cfg.coolant_flow_kg_s,
            min_return_temperature_c=self.min_return_temperature_c,
            max_extraction_rate_mw=breakdown.recoverable_heat_mw,
        )
