"""
The low-temperature loop: the closed water/glycol circuit between the
source-side heat exchanger and the heat pump's evaporator.

    SOURCE --(hot side)--> HEAT EXCHANGER --(cold side, warm)--> EVAPORATOR --(cooled)--> back to HEAT EXCHANGER

At steady state this loop is fully determined by one decision variable,
`evaporating_temperature_k` (chosen by the optimiser), because the loop's
*return* temperature (the cold side entering the heat exchanger) is fixed by
the evaporator pinch:

    T_loop_return = evaporating_temperature_k + evaporator_pinch_k

Feeding that fixed return temperature into the heat exchanger gives its
cold-side outlet, which becomes the evaporator's inlet — and, by
construction (see the derivation in this module's tests), the duty computed
by the heat exchanger and the duty the evaporator subsequently sees are
exactly consistent, with no iteration required.
"""

from __future__ import annotations

from dataclasses import dataclass

from core.state import HeatExchangerState, SourceState
from heat_exchanger.exchanger import HeatExchanger


@dataclass
class ColdLoopState:
    loop_fluid: str
    loop_flow_kg_s: float
    loop_pressure_pa: float
    loop_return_k: float  # entering the heat exchanger (coldest point)
    loop_supply_k: float  # leaving the heat exchanger, entering the evaporator (warmest point)
    duty_w: float
    heat_exchanger_state: HeatExchangerState


def solve_cold_loop(
    source: SourceState,
    heat_exchanger: HeatExchanger,
    loop_fluid: str,
    loop_flow_kg_s: float,
    loop_pressure_pa: float,
    evaporating_temperature_k: float,
    evaporator_pinch_k: float,
) -> ColdLoopState:
    loop_return_k = evaporating_temperature_k + evaporator_pinch_k
    if loop_return_k >= source.temperature_k:
        # No usable delta-T left: the loop return is already as warm as the source.
        hx_state = HeatExchangerState(
            hot_in_k=source.temperature_k, hot_out_k=source.temperature_k,
            cold_in_k=loop_return_k, cold_out_k=loop_return_k,
            duty_w=0.0, effectiveness=0.0, ntu=float("nan"),
            pressure_drop_pa=0.0, fouling_factor_m2k_w=heat_exchanger.config.fouling_factor_m2k_w,
        )
        return ColdLoopState(
            loop_fluid=loop_fluid, loop_flow_kg_s=loop_flow_kg_s, loop_pressure_pa=loop_pressure_pa,
            loop_return_k=loop_return_k, loop_supply_k=loop_return_k, duty_w=0.0, heat_exchanger_state=hx_state,
        )

    hx_state = heat_exchanger.solve(
        hot_fluid=source.fluid,
        hot_in_k=source.temperature_k,
        hot_flow_kg_s=source.flow_kg_s,
        hot_pressure_pa=source.pressure_pa,
        cold_fluid=loop_fluid,
        cold_in_k=loop_return_k,
        cold_flow_kg_s=loop_flow_kg_s,
        cold_pressure_pa=loop_pressure_pa,
    )

    # Respect the source's own extraction limits (never draw more than the
    # waste-heat stream can technically give up — see heat_source.waste_heat).
    duty = hx_state.duty_w
    if source.max_extraction_rate_w is not None:
        duty = min(duty, source.max_extraction_rate_w)
    duty = min(duty, source.available_heat_w)

    return ColdLoopState(
        loop_fluid=loop_fluid,
        loop_flow_kg_s=loop_flow_kg_s,
        loop_pressure_pa=loop_pressure_pa,
        loop_return_k=loop_return_k,
        loop_supply_k=hx_state.cold_out_k,
        duty_w=duty,
        heat_exchanger_state=hx_state,
    )
