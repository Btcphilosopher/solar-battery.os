"""
The high-temperature (delivery) loop: carries the heat pump's condenser
output to hot water, process heat, and (optionally) steam-generation
offtakes (thermal_network.distribution).

    HEAT PUMP CONDENSER --(delivery_temperature)--> [ HOT WATER | PROCESS HEAT | STEAM GEN ] --(return_temperature)--> back to condenser

The loop return temperature is a network/operating parameter (set by
whatever mix of downstream consumers is connected and how much they cool
the water before sending it back) rather than something this module solves
self-consistently against demand; `thermal_network.distribution` allocates
duty across the offtakes, and the scenario/demand configuration sets the
assumed return temperature.
"""

from __future__ import annotations

from dataclasses import dataclass

from heat_pump.condenser import required_flow_for_delivery


@dataclass
class HotLoopState:
    fluid: str
    return_temperature_k: float
    delivery_temperature_k: float
    duty_w: float
    flow_kg_s: float

    @property
    def temperature_rise_k(self) -> float:
        return self.delivery_temperature_k - self.return_temperature_k


def solve_hot_loop(
    fluid: str,
    return_temperature_k: float,
    delivery_temperature_k: float,
    duty_w: float,
    pressure_pa: float = 400_000.0,
) -> HotLoopState:
    if duty_w < 0:
        raise ValueError("duty_w must be non-negative")
    flow = 0.0
    if duty_w > 0:
        flow = required_flow_for_delivery(
            loop_fluid=fluid,
            loop_in_k=return_temperature_k,
            loop_pressure_pa=pressure_pa,
            target_delivery_k=delivery_temperature_k,
            duty_w=duty_w,
        )
    return HotLoopState(
        fluid=fluid,
        return_temperature_k=return_temperature_k,
        delivery_temperature_k=delivery_temperature_k,
        duty_w=duty_w,
        flow_kg_s=flow,
    )
