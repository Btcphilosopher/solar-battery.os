"""
Thermal storage (section 11): hot-water sensible buffer or phase-change
buffer, operated in CHARGE / HOLD / DISCHARGE modes.

A single energy-balance state-of-charge model is used for both storage
kinds; the practical difference (sensible vs latent) shows up only in how
`temperature_k` should be interpreted by the caller (a phase-change store
sits near-isothermal at `phase_change_temperature_k` while charge/discharge
is under way, whereas a hot-water tank's temperature genuinely tracks state
of charge). This module tracks energy content, which is well-defined for
both.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from config.system_config import ThermalStorageConfig
from core.state import ThermalStorageState


class StorageMode(str, Enum):
    CHARGE = "charge"
    HOLD = "hold"
    DISCHARGE = "discharge"


class StorageLimitError(RuntimeError):
    """Raised when a requested charge/discharge would violate a storage limit."""


@dataclass
class ThermalStorage:
    config: ThermalStorageConfig
    state_of_charge: float | None = None

    def __post_init__(self) -> None:
        if self.state_of_charge is None:
            self.state_of_charge = self.config.initial_state_of_charge
        if not (0.0 <= self.state_of_charge <= 1.0):
            raise ValueError("state_of_charge must be in [0, 1]")

    @property
    def energy_content_mwh(self) -> float:
        return self.state_of_charge * self.config.capacity_mwh

    @property
    def usable_charge_headroom_mwh(self) -> float:
        return max((self.config.max_state_of_charge - self.state_of_charge) * self.config.capacity_mwh, 0.0)

    @property
    def usable_discharge_mwh(self) -> float:
        return max((self.state_of_charge - self.config.min_state_of_charge) * self.config.capacity_mwh, 0.0)

    def step(self, requested_power_w: float, dt_hours: float, temperature_k: float) -> ThermalStorageState:
        """
        Advance the storage by one timestep.

        `requested_power_w` > 0 charges the store; < 0 discharges it. The
        request is clipped to the configured max charge/discharge power and
        to the remaining headroom/reserve, and standing losses are applied
        regardless of mode (a store still leaks heat while "holding").
        """
        if not self.config.enabled:
            raise StorageLimitError("Thermal storage is disabled in configuration")
        if dt_hours <= 0:
            raise ValueError("dt_hours must be positive")

        standing_loss_w = (
            self.energy_content_mwh * 1e6 * self.config.standing_loss_fraction_per_hour
        )

        if requested_power_w >= 0:
            max_charge_w = self.config.max_charge_mw * 1e6
            headroom_w = self.usable_charge_headroom_mwh * 1e6 / dt_hours
            charge_power_w = min(requested_power_w, max_charge_w, headroom_w)
            discharge_power_w = 0.0
            mode = StorageMode.CHARGE if charge_power_w > 1e-6 else StorageMode.HOLD
        else:
            max_discharge_w = self.config.max_discharge_mw * 1e6
            available_w = self.usable_discharge_mwh * 1e6 / dt_hours
            discharge_power_w = min(-requested_power_w, max_discharge_w, available_w)
            charge_power_w = 0.0
            mode = StorageMode.DISCHARGE if discharge_power_w > 1e-6 else StorageMode.HOLD

        net_power_w = charge_power_w - discharge_power_w - standing_loss_w
        delta_energy_mwh = net_power_w * dt_hours / 1e6
        new_energy_mwh = max(min(self.energy_content_mwh + delta_energy_mwh, self.config.capacity_mwh), 0.0)
        self.state_of_charge = new_energy_mwh / self.config.capacity_mwh if self.config.capacity_mwh > 0 else 0.0

        return ThermalStorageState(
            state_of_charge=self.state_of_charge,
            energy_content_mwh=new_energy_mwh,
            capacity_mwh=self.config.capacity_mwh,
            temperature_k=temperature_k,
            mode=mode.value,
            charge_power_w=charge_power_w,
            discharge_power_w=discharge_power_w,
            standing_loss_w=standing_loss_w,
        )
