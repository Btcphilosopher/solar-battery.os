"""
Downstream steam generation / turbine / generator pathway (sections 12-13).

    HOT WATER -> STEAM GENERATOR -> STEAM -> TURBINE -> GENERATOR -> ELECTRICITY

This is deliberately gated: `evaluate_pathway` computes the whole chain and
returns a NET electrical output (gross turbine/generator output minus every
parasitic load handed to it), and callers (the optimiser) must check
`worthwhile` before committing recovered heat to this path — high-grade heat
converted to steam and then to a small net-positive electrical trickle is
not obviously better than delivering the same heat directly as hot water,
and low delivery temperatures cannot form steam at all.

All steam/water properties come from CoolProp ('Water'), not an invented
steam-table fit.
"""

from __future__ import annotations

from dataclasses import dataclass

from config.system_config import SteamCycleConfig
from core.state import AuxiliaryLoads, SteamCycleState
from thermodynamics.properties import (
    enthalpy_pq,
    enthalpy_tp,
    entropy_pq,
    saturation_temperature,
    state_from_ph,
    state_from_ps,
    specific_heat,
)

STEAM_FLUID = "Water"

# Below this quality at turbine exhaust, liquid droplet erosion of the last
# blade stages becomes a real concern; used only as a validity/status flag,
# not to alter the thermodynamic result.
MIN_ACCEPTABLE_EXHAUST_QUALITY = 0.88

# Minimum practical pinch between the hot water supply and the steam
# saturation temperature for the steam generator to raise any steam at all.
STEAM_GENERATOR_PINCH_K = 8.0


@dataclass
class SteamGenerationResult:
    feasible: bool
    saturation_temperature_k: float
    steam_mass_flow_kg_s: float
    steam_enthalpy_j_kg: float
    hot_water_outlet_k: float
    thermal_input_w: float


def generate_steam(
    hot_water_temperature_k: float,
    hot_water_flow_kg_s: float,
    hot_water_pressure_pa: float,
    steam_pressure_pa: float,
    feedwater_temperature_k: float = 373.15,
) -> SteamGenerationResult:
    """
    Raise saturated steam at `steam_pressure_pa` from hot water, cooling the
    hot water stream down to (at best) `feedwater_temperature_k` + pinch.
    """
    t_sat = saturation_temperature(STEAM_FLUID, steam_pressure_pa)
    if hot_water_temperature_k < t_sat + STEAM_GENERATOR_PINCH_K:
        return SteamGenerationResult(
            feasible=False, saturation_temperature_k=t_sat, steam_mass_flow_kg_s=0.0,
            steam_enthalpy_j_kg=0.0, hot_water_outlet_k=hot_water_temperature_k, thermal_input_w=0.0,
        )

    h_steam = enthalpy_pq(STEAM_FLUID, steam_pressure_pa, 1.0)  # saturated vapour
    h_feed = enthalpy_tp(STEAM_FLUID, feedwater_temperature_k, steam_pressure_pa)
    specific_duty_j_kg_steam = h_steam - h_feed
    if specific_duty_j_kg_steam <= 0:
        return SteamGenerationResult(
            feasible=False, saturation_temperature_k=t_sat, steam_mass_flow_kg_s=0.0,
            steam_enthalpy_j_kg=h_steam, hot_water_outlet_k=hot_water_temperature_k, thermal_input_w=0.0,
        )

    cp_water = specific_heat(STEAM_FLUID, hot_water_temperature_k, hot_water_pressure_pa)
    hot_water_outlet_k = max(t_sat + STEAM_GENERATOR_PINCH_K, feedwater_temperature_k)
    available_duty_w = hot_water_flow_kg_s * cp_water * (hot_water_temperature_k - hot_water_outlet_k)
    if available_duty_w <= 0:
        return SteamGenerationResult(
            feasible=False, saturation_temperature_k=t_sat, steam_mass_flow_kg_s=0.0,
            steam_enthalpy_j_kg=h_steam, hot_water_outlet_k=hot_water_temperature_k, thermal_input_w=0.0,
        )

    steam_flow = available_duty_w / specific_duty_j_kg_steam
    return SteamGenerationResult(
        feasible=True,
        saturation_temperature_k=t_sat,
        steam_mass_flow_kg_s=steam_flow,
        steam_enthalpy_j_kg=h_steam,
        hot_water_outlet_k=hot_water_outlet_k,
        thermal_input_w=available_duty_w,
    )


@dataclass
class TurbineResult:
    inlet_enthalpy_j_kg: float
    isentropic_outlet_enthalpy_j_kg: float
    actual_outlet_enthalpy_j_kg: float
    outlet_quality: float
    specific_work_j_kg: float
    shaft_power_w: float
    exhaust_erosion_risk: bool


def expand_turbine(
    steam_mass_flow_kg_s: float,
    steam_pressure_pa: float,
    condenser_pressure_pa: float,
    isentropic_efficiency: float,
) -> TurbineResult:
    if condenser_pressure_pa >= steam_pressure_pa:
        raise ValueError("condenser_pressure_pa must be below steam_pressure_pa")
    if not (0.0 < isentropic_efficiency <= 1.0):
        raise ValueError("isentropic_efficiency must be in (0, 1]")

    s_in = entropy_pq(STEAM_FLUID, steam_pressure_pa, 1.0)
    h_in = enthalpy_pq(STEAM_FLUID, steam_pressure_pa, 1.0)
    isentropic_outlet = state_from_ps(STEAM_FLUID, condenser_pressure_pa, s_in)
    isentropic_work = h_in - isentropic_outlet.enthalpy_j_kg
    if isentropic_work < 0:
        raise ValueError("Second Law violation: isentropic turbine work must be non-negative")

    actual_work = isentropic_work * isentropic_efficiency
    h_out_actual = h_in - actual_work
    outlet_state = state_from_ph(STEAM_FLUID, condenser_pressure_pa, h_out_actual)

    return TurbineResult(
        inlet_enthalpy_j_kg=h_in,
        isentropic_outlet_enthalpy_j_kg=isentropic_outlet.enthalpy_j_kg,
        actual_outlet_enthalpy_j_kg=h_out_actual,
        outlet_quality=outlet_state.quality,
        specific_work_j_kg=actual_work,
        shaft_power_w=steam_mass_flow_kg_s * actual_work,
        exhaust_erosion_risk=(0.0 <= outlet_state.quality < MIN_ACCEPTABLE_EXHAUST_QUALITY),
    )


@dataclass
class SteamPathwayEvaluation:
    state: SteamCycleState
    worthwhile: bool
    reason: str


def evaluate_pathway(
    config: SteamCycleConfig,
    hot_water_temperature_k: float,
    hot_water_flow_kg_s: float,
    hot_water_pressure_pa: float,
    auxiliary_loads: AuxiliaryLoads,
) -> SteamPathwayEvaluation:
    """
    Run the full steam/turbine/generator chain and decide whether it is
    thermodynamically and energetically worthwhile: net electrical output
    must be positive after every parasitic load, and the delivery
    temperature must actually clear the steam generator's pinch.
    """
    if not config.enabled:
        state = SteamCycleState(
            engaged=False, steam_mass_flow_kg_s=0.0, steam_pressure_pa=config.steam_pressure_pa,
            steam_temperature_k=0.0, steam_quality=0.0, turbine_isentropic_efficiency=config.turbine_isentropic_efficiency,
            gross_electrical_power_w=0.0, generator_efficiency=config.generator_efficiency,
            net_electrical_power_w=0.0, thermal_input_w=0.0, cycle_efficiency=0.0,
        )
        return SteamPathwayEvaluation(state=state, worthwhile=False, reason="Steam cycle disabled in configuration")

    steam_gen = generate_steam(
        hot_water_temperature_k=hot_water_temperature_k,
        hot_water_flow_kg_s=hot_water_flow_kg_s,
        hot_water_pressure_pa=hot_water_pressure_pa,
        steam_pressure_pa=config.steam_pressure_pa,
    )
    if not steam_gen.feasible:
        state = SteamCycleState(
            engaged=False, steam_mass_flow_kg_s=0.0, steam_pressure_pa=config.steam_pressure_pa,
            steam_temperature_k=steam_gen.saturation_temperature_k, steam_quality=1.0,
            turbine_isentropic_efficiency=config.turbine_isentropic_efficiency,
            gross_electrical_power_w=0.0, generator_efficiency=config.generator_efficiency,
            net_electrical_power_w=0.0, thermal_input_w=0.0, cycle_efficiency=0.0,
        )
        return SteamPathwayEvaluation(
            state=state, worthwhile=False,
            reason=(
                f"Delivery temperature {hot_water_temperature_k - 273.15:.1f} degC is below the steam generator's "
                f"pinch-limited minimum ({steam_gen.saturation_temperature_k - 273.15 + STEAM_GENERATOR_PINCH_K:.1f} degC)"
            ),
        )

    turbine = expand_turbine(
        steam_mass_flow_kg_s=steam_gen.steam_mass_flow_kg_s,
        steam_pressure_pa=config.steam_pressure_pa,
        condenser_pressure_pa=config.condenser_pressure_pa,
        isentropic_efficiency=config.turbine_isentropic_efficiency,
    )
    gross_electrical_w = turbine.shaft_power_w * config.generator_efficiency
    net_electrical_w = gross_electrical_w - auxiliary_loads.total_w

    cycle_efficiency = gross_electrical_w / steam_gen.thermal_input_w if steam_gen.thermal_input_w > 0 else 0.0

    state = SteamCycleState(
        engaged=True,
        steam_mass_flow_kg_s=steam_gen.steam_mass_flow_kg_s,
        steam_pressure_pa=config.steam_pressure_pa,
        steam_temperature_k=steam_gen.saturation_temperature_k,
        steam_quality=1.0,
        turbine_isentropic_efficiency=config.turbine_isentropic_efficiency,
        gross_electrical_power_w=gross_electrical_w,
        generator_efficiency=config.generator_efficiency,
        net_electrical_power_w=net_electrical_w,
        thermal_input_w=steam_gen.thermal_input_w,
        cycle_efficiency=cycle_efficiency,
    )

    worthwhile = net_electrical_w > 0
    reason = (
        f"Net electrical output {net_electrical_w / 1e3:.1f} kW after {auxiliary_loads.total_w / 1e3:.1f} kW auxiliary load"
        if worthwhile
        else (
            f"Gross electrical output {gross_electrical_w / 1e3:.1f} kW does not clear auxiliary load "
            f"{auxiliary_loads.total_w / 1e3:.1f} kW: steam pathway destroys more exergy than it recovers as electricity"
        )
    )
    if turbine.exhaust_erosion_risk:
        reason += f" [warning: turbine exhaust quality {turbine.outlet_quality:.3f} below erosion-risk threshold]"

    return SteamPathwayEvaluation(state=state, worthwhile=worthwhile, reason=reason)
