"""
Distribution: allocates the hot loop's delivered duty across downstream
offtakes — hot water, direct process heat, and (where temperature permits)
steam generation.

This module does not decide *how much* heat to recover (that is the
optimiser's job); it decides where a given delivered duty goes once it
exists, and reports any duty that could not be placed (curtailed / sent to
storage / rejected) so nothing is silently lost from the energy balance.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class DistributionAllocation:
    hot_water_w: float
    process_heat_w: float
    steam_generator_w: float
    storage_charge_w: float
    curtailed_w: float

    @property
    def total_allocated_w(self) -> float:
        return self.hot_water_w + self.process_heat_w + self.steam_generator_w + self.storage_charge_w + self.curtailed_w


def allocate(
    delivered_duty_w: float,
    delivery_temperature_k: float,
    hot_water_demand_w: float,
    process_heat_demand_w: float,
    steam_minimum_temperature_k: float | None,
    steam_demand_w: float,
    storage_charge_headroom_w: float,
) -> DistributionAllocation:
    """
    Greedy priority allocation: hot water demand first (typically the
    least-flexible, highest-priority consumer), then process heat, then
    steam generation (only if the delivery temperature clears the steam
    generator's minimum), then any remaining duty goes to thermal storage,
    and whatever is left after that is curtailed (rejected) rather than
    silently disappearing from the energy balance.
    """
    if delivered_duty_w < 0:
        raise ValueError("delivered_duty_w must be non-negative")

    remaining = delivered_duty_w

    hot_water = min(remaining, max(hot_water_demand_w, 0.0))
    remaining -= hot_water

    process_heat = min(remaining, max(process_heat_demand_w, 0.0))
    remaining -= process_heat

    steam = 0.0
    if steam_minimum_temperature_k is not None and delivery_temperature_k >= steam_minimum_temperature_k:
        steam = min(remaining, max(steam_demand_w, 0.0))
        remaining -= steam

    storage = min(remaining, max(storage_charge_headroom_w, 0.0))
    remaining -= storage

    curtailed = max(remaining, 0.0)

    return DistributionAllocation(
        hot_water_w=hot_water,
        process_heat_w=process_heat,
        steam_generator_w=steam,
        storage_charge_w=storage,
        curtailed_w=curtailed,
    )
