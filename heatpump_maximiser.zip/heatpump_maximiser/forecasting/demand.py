"""Downstream heat-demand forecasting, plus a simple diurnal demand-shape helper for scenarios without measured history."""

from __future__ import annotations

import numpy as np
import pandas as pd

from forecasting.heat_load import bounded_forecast


def forecast_heat_demand(history_w: pd.Series, horizon_steps: int, lookback: int = 12) -> pd.Series:
    return bounded_forecast(history_w, horizon_steps, lower_bound=0.0, upper_bound=float("inf"), lookback=lookback)


def diurnal_demand_shape(base_demand_w: float, peak_multiplier: float, peak_hour: float, hours: np.ndarray) -> np.ndarray:
    """A simple day-shaped demand profile (e.g. district heating morning/evening peaks) for scenario generation."""
    phase = 2.0 * np.pi * (hours - peak_hour) / 24.0
    return base_demand_w * (1.0 + (peak_multiplier - 1.0) * np.maximum(np.cos(phase), 0.0))
