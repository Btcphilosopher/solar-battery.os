"""Electricity price / availability forecasting — used by the optimiser only as an optional overlay (economics.value_model), never as the primary physical objective."""

from __future__ import annotations

import pandas as pd

from forecasting.heat_load import bounded_forecast


def forecast_electricity_price(history_per_mwh: pd.Series, horizon_steps: int, lookback: int = 24) -> pd.Series:
    return bounded_forecast(history_per_mwh, horizon_steps, lower_bound=0.0, upper_bound=float("inf"), lookback=lookback)


def forecast_grid_capacity(history_mw: pd.Series, horizon_steps: int, lookback: int = 24) -> pd.Series:
    return bounded_forecast(history_mw, horizon_steps, lower_bound=0.0, upper_bound=float("inf"), lookback=lookback)
