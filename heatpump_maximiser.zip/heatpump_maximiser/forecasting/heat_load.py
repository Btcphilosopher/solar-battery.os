"""
Waste-heat availability forecasting.

Design principle "physics must remain authoritative": these forecasts feed
the optimiser's look-ahead (e.g. thermal storage pre-charge decisions), but
every timestep's *actual* operating point is still computed from measured
conditions through the full physics engine — a forecast never substitutes
for a measurement in the energy balance.

A short persistence-with-trend model is used by default; it is intentionally
simple and swappable (see forecasting.electricity for the pattern extended
with a seasonal/ML-ready hook).
"""

from __future__ import annotations

import numpy as np
import pandas as pd


def persistence_forecast(history: pd.Series, horizon_steps: int) -> pd.Series:
    """Naive persistence: the last observed value, repeated forward. Always available, always a valid baseline."""
    if history.empty:
        raise ValueError("history must contain at least one observation")
    last_value = history.iloc[-1]
    index = pd.RangeIndex(len(history), len(history) + horizon_steps)
    return pd.Series(np.full(horizon_steps, last_value), index=index, name=history.name)


def linear_trend_forecast(history: pd.Series, horizon_steps: int, lookback: int = 12) -> pd.Series:
    """
    Least-squares linear trend fit over the last `lookback` observations,
    extrapolated forward — captures a ramping data-centre load or a warming
    source stream better than pure persistence, while remaining transparent
    (no black-box model).
    """
    if len(history) < 2:
        return persistence_forecast(history, horizon_steps)
    window = history.iloc[-lookback:]
    x = np.arange(len(window))
    slope, intercept = np.polyfit(x, window.values, 1)
    forecast_x = np.arange(len(window), len(window) + horizon_steps)
    values = slope * forecast_x + intercept
    index = pd.RangeIndex(len(history), len(history) + horizon_steps)
    return pd.Series(values, index=index, name=history.name)


def bounded_forecast(
    history: pd.Series, horizon_steps: int, lower_bound: float, upper_bound: float, lookback: int = 12
) -> pd.Series:
    """Linear-trend forecast clipped to a physically plausible range (never forecast a negative heat load, etc.)."""
    forecast = linear_trend_forecast(history, horizon_steps, lookback)
    return forecast.clip(lower=lower_bound, upper=upper_bound)
