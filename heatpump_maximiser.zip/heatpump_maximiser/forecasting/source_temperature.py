"""Source (and ambient) temperature forecasting — thin, physically-bounded wrappers over forecasting.heat_load."""

from __future__ import annotations

import pandas as pd

from forecasting.heat_load import bounded_forecast

ABSOLUTE_MIN_PLAUSIBLE_C = -50.0
ABSOLUTE_MAX_PLAUSIBLE_C = 400.0


def forecast_source_temperature(
    history_c: pd.Series, horizon_steps: int, min_plausible_c: float = ABSOLUTE_MIN_PLAUSIBLE_C,
    max_plausible_c: float = ABSOLUTE_MAX_PLAUSIBLE_C, lookback: int = 12,
) -> pd.Series:
    return bounded_forecast(history_c, horizon_steps, min_plausible_c, max_plausible_c, lookback)


def forecast_ambient_temperature(history_c: pd.Series, horizon_steps: int, lookback: int = 24) -> pd.Series:
    return bounded_forecast(history_c, horizon_steps, ABSOLUTE_MIN_PLAUSIBLE_C, ABSOLUTE_MAX_PLAUSIBLE_C, lookback)
