"""
Fast, cheap sanity checks applied to raw values before they are trusted
anywhere else in the engine (section 24). These are the first line of
defence — deliberately simple and deliberately not physics-aware beyond
"is this a legitimate number for this quantity" (deeper Second-Law and
energy-balance checks live in thermodynamic_limits.py / energy_balance.py).
"""

from __future__ import annotations


class PhysicalSanityError(RuntimeError):
    """Raised when a raw measured/computed value cannot represent anything physically real."""


def check_positive_temperature_k(value_k: float, name: str = "temperature") -> float:
    if value_k <= 0 or value_k != value_k:  # NaN check
        raise PhysicalSanityError(f"{name} must be a positive absolute temperature (Kelvin), got {value_k}")
    return value_k


def check_non_negative(value: float, name: str) -> float:
    if value < 0 or value != value:
        raise PhysicalSanityError(f"{name} must be non-negative, got {value}")
    return value


def check_positive(value: float, name: str) -> float:
    if value <= 0 or value != value:
        raise PhysicalSanityError(f"{name} must be strictly positive, got {value}")
    return value


def check_fraction(value: float, name: str) -> float:
    if not (0.0 <= value <= 1.0) or value != value:
        raise PhysicalSanityError(f"{name} must be a fraction in [0, 1], got {value}")
    return value


def check_no_mass_creation(mass_in_kg_s: float, mass_out_kg_s: float, tolerance_kg_s: float = 1e-6) -> None:
    """Mass balance: what flows in must flow out (steady-state, no accumulation modelled here)."""
    if abs(mass_in_kg_s - mass_out_kg_s) > tolerance_kg_s:
        raise PhysicalSanityError(
            f"Mass balance violated: in={mass_in_kg_s:.6f} kg/s, out={mass_out_kg_s:.6f} kg/s "
            f"(difference {abs(mass_in_kg_s - mass_out_kg_s):.6f} kg/s exceeds tolerance {tolerance_kg_s:.6f} kg/s)"
        )


def check_no_negative_flow(flow_kg_s: float, name: str = "mass flow") -> float:
    return check_non_negative(flow_kg_s, name)


def check_realistic_cop(cop: float, carnot_cop: float, name: str = "COP", margin: float = 1e-3) -> float:
    """A real cycle's COP can never exceed its own Carnot-limit COP."""
    if cop < 0 or cop != cop:
        raise PhysicalSanityError(f"{name} must be non-negative, got {cop}")
    if cop > carnot_cop * (1.0 + margin):
        raise PhysicalSanityError(
            f"{name} ({cop:.3f}) exceeds the Carnot-limit COP ({carnot_cop:.3f}) for this temperature lift — "
            "impossible without violating the Second Law"
        )
    return cop
