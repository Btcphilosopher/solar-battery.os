"""
Plant-wide energy balance validation (section 24):

    energy in == energy recovered + energy rejected + energy stored + losses

Wraps thermodynamics.energy_balance for the specific set of streams that
exist in one resolved PlantState.
"""

from __future__ import annotations

from core.state import PlantState
from thermodynamics.energy_balance import EnergyBalanceResult, check_energy_balance


def validate_plant_energy_balance(state: PlantState, tolerance_fraction: float = 5e-3) -> EnergyBalanceResult:
    """
    energy_in: heat drawn from the source stream at the heat exchanger, plus
               the compressor's electrical input (a genuine energy input to
               the hot-side balance), plus any steam-cycle electrical export
               being netted off separately below.
    energy_recovered: useful heat delivered to the hot loop.
    energy_rejected: waste heat left in the source stream after extraction,
               expressed as the shortfall between what was technically
               available and what was actually drawn.
    energy_stored: net charge into thermal storage (can be negative on discharge).
    losses: heat-exchanger and pipework losses not otherwise accounted for
               (modelled here as zero at the boundary already enforced by
               the approach-temperature-limited exchanger models; any gap
               shows up as `residual` if something upstream is inconsistent).
    """
    hp = state.heat_pump

    energy_in = state.metrics.heat_recovered_w + hp.compressor_power_w
    energy_recovered = hp.heat_rejected_w
    stored = state.storage.charge_power_w - state.storage.discharge_power_w if state.storage else 0.0
    storage_loss = state.storage.standing_loss_w if state.storage else 0.0
    losses = storage_loss + state.metrics.motor_losses_w

    # The condenser's rejected heat (hp.heat_rejected_w) already equals the
    # useful delivered duty in this engine's model (no separate distribution
    # losses are modelled downstream of the condenser), so "rejected" energy
    # on this balance refers to the waste-heat side only: energy that
    # entered the exchanger's hot side but did not make it to energy_in.
    return check_energy_balance(
        energy_in_w=energy_in,
        energy_recovered_w=energy_recovered,
        energy_rejected_w=0.0,
        energy_stored_w=stored,
        losses_w=losses,
        tolerance_fraction=tolerance_fraction,
        raise_on_failure=False,
    )
