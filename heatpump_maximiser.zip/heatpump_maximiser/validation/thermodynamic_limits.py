"""
Second-Law / equipment-envelope validation of a resolved operating point
(section 24). Where sanity_checks.py asks "is this number legitimate at
all", this module asks "is this specific *thermodynamic state* achievable".
"""

from __future__ import annotations

from dataclasses import dataclass

from core.state import HeatPumpOperatingPoint
from heat_pump.refrigerant import Refrigerant
from validation.sanity_checks import PhysicalSanityError, check_realistic_cop


@dataclass(frozen=True)
class LimitCheckResult:
    passed: bool
    violations: list[str]


def check_heat_pump_limits(operating_point: HeatPumpOperatingPoint, max_pressure_ratio: float) -> LimitCheckResult:
    violations: list[str] = []

    try:
        check_realistic_cop(operating_point.cop_heating, operating_point.carnot_cop)
    except PhysicalSanityError as exc:
        violations.append(str(exc))

    if operating_point.temperature_lift_k <= 0:
        violations.append(
            f"Non-physical temperature lift: {operating_point.temperature_lift_k:.2f} K "
            "(condensing temperature must exceed evaporating temperature)"
        )

    if operating_point.pressure_ratio > max_pressure_ratio * (1.0 + 1e-6):
        violations.append(
            f"Pressure ratio {operating_point.pressure_ratio:.2f} exceeds equipment limit {max_pressure_ratio:.2f}"
        )

    if not (0.0 <= operating_point.second_law_efficiency <= 1.0 + 1e-6):
        violations.append(
            f"Second-law efficiency {operating_point.second_law_efficiency:.4f} outside the physically valid range [0, 1]"
        )

    for point in operating_point.states:
        if point.temperature_k <= 0:
            violations.append(f"State '{point.label}': non-physical absolute temperature {point.temperature_k:.2f} K")
        if point.pressure_pa <= 0:
            violations.append(f"State '{point.label}': non-physical pressure {point.pressure_pa:.0f} Pa")

    return LimitCheckResult(passed=len(violations) == 0, violations=violations)


def check_refrigerant_envelope(
    refrigerant: Refrigerant, evaporating_temperature_k: float, condensing_temperature_k: float
) -> LimitCheckResult:
    violations: list[str] = []
    t_min, t_max, _, _ = refrigerant.limits
    if not (t_min <= evaporating_temperature_k <= t_max):
        violations.append(
            f"Evaporating temperature {evaporating_temperature_k:.2f} K outside {refrigerant.name}'s valid range "
            f"[{t_min:.2f}, {t_max:.2f}] K"
        )
    if not (t_min <= condensing_temperature_k <= t_max):
        violations.append(
            f"Condensing temperature {condensing_temperature_k:.2f} K outside {refrigerant.name}'s valid range "
            f"[{t_min:.2f}, {t_max:.2f}] K"
        )
    if condensing_temperature_k >= refrigerant.critical_temperature_k:
        violations.append(
            f"Condensing temperature {condensing_temperature_k:.2f} K is at or above {refrigerant.name}'s critical "
            f"temperature ({refrigerant.critical_temperature_k:.2f} K): subcritical condensation is not possible"
        )
    return LimitCheckResult(passed=len(violations) == 0, violations=violations)


def check_temperature_bounds(temperature_k: float, min_k: float, max_k: float, name: str) -> LimitCheckResult:
    if temperature_k < min_k - 1e-6:
        return LimitCheckResult(False, [f"{name} {temperature_k:.2f} K is below the minimum allowed {min_k:.2f} K"])
    if temperature_k > max_k + 1e-6:
        return LimitCheckResult(False, [f"{name} {temperature_k:.2f} K is above the maximum allowed {max_k:.2f} K"])
    return LimitCheckResult(True, [])
