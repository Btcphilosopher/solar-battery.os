import pytest

from heat_source.datacentre import DataCentreSource
from heat_source.waste_heat import WasteHeatStream
from config.system_config import DataCentreSourceConfig


def test_recoverable_heat_never_exceeds_total_available():
    stream = WasteHeatStream(fluid="Water", temperature_c=35.0, flow_kg_s=300.0, min_return_temperature_c=25.0)
    assert stream.recoverable_heat_w() <= stream.total_available_heat_w() + 1e-6


def test_recoverable_heat_capped_by_extraction_limit():
    stream = WasteHeatStream(
        fluid="Water", temperature_c=35.0, flow_kg_s=300.0, min_return_temperature_c=25.0,
        max_extraction_rate_mw=1.0,
    )
    assert stream.recoverable_heat_w() <= 1.0e6 + 1.0


def test_rejects_return_temperature_above_supply():
    with pytest.raises(ValueError):
        WasteHeatStream(fluid="Water", temperature_c=30.0, flow_kg_s=100.0, min_return_temperature_c=35.0)


def test_rejects_negative_flow():
    with pytest.raises(ValueError):
        WasteHeatStream(fluid="Water", temperature_c=30.0, flow_kg_s=-1.0, min_return_temperature_c=20.0)


def test_datacentre_heat_capture_fraction_is_never_total():
    """Section 5: do not assume 100% of data-centre electricity becomes recoverable heat."""
    config = DataCentreSourceConfig(
        it_load_mw=10.0, server_utilisation=1.0, gpu_load_fraction=0.0, cpu_load_fraction=1.0,
        network_load_fraction=0.0, heat_capture_fraction=0.65, coolant_flow_kg_s=300.0,
    )
    source = DataCentreSource(config)
    breakdown = source.breakdown()
    assert breakdown.recoverable_heat_mw < breakdown.total_heat_generated_mw
    assert breakdown.recoverable_heat_mw < config.it_load_mw  # strictly less than the raw electrical load
