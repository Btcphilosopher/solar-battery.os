import pytest

from validation.sanity_checks import (
    PhysicalSanityError,
    check_fraction,
    check_no_mass_creation,
    check_non_negative,
    check_positive_temperature_k,
    check_realistic_cop,
)


def test_rejects_non_positive_absolute_temperature():
    with pytest.raises(PhysicalSanityError):
        check_positive_temperature_k(-5.0)
    with pytest.raises(PhysicalSanityError):
        check_positive_temperature_k(0.0)


def test_rejects_negative_mass_flow():
    with pytest.raises(PhysicalSanityError):
        check_non_negative(-1.0, "mass_flow_kg_s")


def test_rejects_fraction_outside_unit_interval():
    with pytest.raises(PhysicalSanityError):
        check_fraction(1.5, "effectiveness")


def test_mass_balance_check_passes_for_equal_flows():
    check_no_mass_creation(10.0, 10.0)  # should not raise


def test_mass_balance_check_rejects_mass_creation():
    with pytest.raises(PhysicalSanityError):
        check_no_mass_creation(10.0, 15.0)


def test_cop_above_carnot_limit_is_rejected():
    with pytest.raises(PhysicalSanityError):
        check_realistic_cop(cop=20.0, carnot_cop=9.0)


def test_cop_within_carnot_limit_is_accepted():
    assert check_realistic_cop(cop=5.5, carnot_cop=9.0) == 5.5
