import pytest

from thermodynamics.energy_balance import EnergyBalanceError, check_energy_balance, heat_pump_energy_balance
from thermodynamics.entropy import (
    carnot_entropy_check,
    entropy_generation_heat_transfer,
    entropy_generation_throttling,
)
from thermodynamics.exergy import ExergyWaterfall, exergy_of_heat, second_law_efficiency
from thermodynamics.properties import c_to_k, k_to_c, specific_heat


def test_c_to_k_and_back():
    assert c_to_k(0.0) == pytest.approx(273.15)
    assert k_to_c(c_to_k(37.5)) == pytest.approx(37.5)


def test_energy_balance_accepts_balanced_case():
    result = check_energy_balance(energy_in_w=100.0, energy_recovered_w=80.0, energy_rejected_w=20.0)
    assert result.is_balanced


def test_energy_balance_rejects_imbalanced_case():
    with pytest.raises(EnergyBalanceError):
        check_energy_balance(energy_in_w=100.0, energy_recovered_w=50.0, energy_rejected_w=10.0)


def test_heat_pump_energy_balance_first_law():
    # Q_evap + W_compressor == Q_cond
    result = heat_pump_energy_balance(heat_absorbed_w=7.0e6, compressor_work_w=1.5e6, heat_rejected_w=8.5e6)
    assert result.is_balanced


def test_entropy_generation_heat_transfer_non_negative_for_hot_to_cold():
    s_gen = entropy_generation_heat_transfer(heat_rate_w=1000.0, hot_side_temperature_k=310.0, cold_side_temperature_k=300.0)
    assert s_gen > 0


def test_entropy_generation_throttling_r1234ze():
    s_gen_rate = entropy_generation_throttling(
        mass_flow_kg_s=1.0, fluid="R1234ze(E)", pressure_in_pa=1_000_000.0, pressure_out_pa=400_000.0,
        enthalpy_j_kg=250_000.0,
    )
    assert s_gen_rate >= 0


def test_carnot_entropy_check_rejects_inverted_temperatures():
    with pytest.raises(ValueError):
        carnot_entropy_check(temperature_hot_k=300.0, temperature_cold_k=310.0)


def test_exergy_of_heat_increases_with_temperature():
    from thermodynamics.properties import DEFAULT_ENVIRONMENT

    low = exergy_of_heat(1_000_000.0, c_to_k(45.0))
    high = exergy_of_heat(1_000_000.0, c_to_k(90.0))
    assert high > low
    assert low > 0  # both above ambient (15 degC default), so both carry positive exergy


def test_exergy_of_heat_at_ambient_is_zero():
    from thermodynamics.properties import DEFAULT_ENVIRONMENT

    ex = exergy_of_heat(1_000_000.0, DEFAULT_ENVIRONMENT.temperature_k)
    assert ex == pytest.approx(0.0, abs=1e-6)


def test_second_law_efficiency_bounded():
    assert second_law_efficiency(50.0, 100.0) == pytest.approx(0.5)
    with pytest.raises(ValueError):
        second_law_efficiency(150.0, 100.0)


def test_exergy_waterfall_accounts_for_exogenous_work():
    waterfall = ExergyWaterfall(source_exergy_in_w=100.0)
    waterfall.add_stage("stage_with_work", exergy_in_w=100.0, exergy_out_w=150.0, exergy_added_w=80.0)
    # 100 (source) + 80 (exogenous work) supplied; 150 delivered -> efficiency < 1 and well-defined
    assert waterfall.total_exergy_supplied_w == pytest.approx(180.0)
    eff = waterfall.overall_second_law_efficiency
    assert 0.0 <= eff <= 1.0


def test_specific_heat_water_is_physically_reasonable():
    cp = specific_heat("Water", c_to_k(30.0), 200_000.0)
    assert 4000.0 < cp < 4300.0
