import pytest

from optimisation.temperature_optimizer import find_optimal_delivery_temperature, sweep_delivery_temperature
from optimisation.multiobjective import generate_candidates, pareto_frontier
from thermodynamics.properties import c_to_k


def test_delivery_temperature_sweep_returns_expected_rows(plant_config, source_state):
    df = sweep_delivery_temperature(
        plant_config, source_state, c_to_k(22.0), 312.0, [45, 55, 65, 75],
    )
    assert len(df) == 4
    assert df["feasible"].any()


def test_optimizer_converges_to_a_feasible_state(plant_config, source_state):
    result = find_optimal_delivery_temperature(
        plant_config, source_state, c_to_k(22.0), 312.0, 40.0, 85.0,
    )
    assert result.plant_state is not None
    assert result.plant_state.status in ("OPTIMAL", "WARNING")
    assert result.evaluations > 0


def test_optimizer_respects_search_bounds(plant_config, source_state):
    result = find_optimal_delivery_temperature(
        plant_config, source_state, c_to_k(22.0), 312.0, 50.0, 60.0,
    )
    assert result.plant_state is not None
    delivery_c = result.delivery_temperature_k - 273.15
    assert 50.0 - 1.0 <= delivery_c <= 60.0 + 1.0


def test_pareto_frontier_is_non_dominated(plant_config, source_state):
    candidates = generate_candidates(
        plant_config, source_state, (c_to_k(16), c_to_k(28)), (c_to_k(48), c_to_k(85)), 312.0,
        n_evap=4, n_cond=5,
    )
    assert len(candidates) > 0
    frontier = pareto_frontier(candidates)
    # No frontier member should be dominated by any other candidate.
    for state in frontier:
        for other in candidates:
            if other is state:
                continue
            dominates = (
                other.metrics.net_thermal_output_w >= state.metrics.net_thermal_output_w
                and other.metrics.exergy_efficiency >= state.metrics.exergy_efficiency
                and (
                    other.metrics.net_thermal_output_w > state.metrics.net_thermal_output_w
                    or other.metrics.exergy_efficiency > state.metrics.exergy_efficiency
                )
            )
            assert not dominates
