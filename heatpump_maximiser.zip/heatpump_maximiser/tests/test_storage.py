import pytest

from config.system_config import ThermalStorageConfig
from thermal_network.thermal_storage import StorageLimitError, ThermalStorage


@pytest.fixture
def storage_config():
    return ThermalStorageConfig(
        enabled=True, capacity_mwh=4.0, max_charge_mw=2.0, max_discharge_mw=2.0,
        standing_loss_fraction_per_hour=0.0, min_state_of_charge=0.05, max_state_of_charge=0.95,
        initial_state_of_charge=0.5,
    )


def test_charging_increases_state_of_charge(storage_config):
    storage = ThermalStorage(storage_config)
    state = storage.step(requested_power_w=1.0e6, dt_hours=1.0, temperature_k=333.15)
    assert state.mode == "charge"
    assert state.state_of_charge > 0.5


def test_discharging_decreases_state_of_charge(storage_config):
    storage = ThermalStorage(storage_config)
    state = storage.step(requested_power_w=-1.0e6, dt_hours=1.0, temperature_k=333.15)
    assert state.mode == "discharge"
    assert state.state_of_charge < 0.5


def test_cannot_charge_above_max_state_of_charge(storage_config):
    storage = ThermalStorage(storage_config, state_of_charge=0.94)
    state = storage.step(requested_power_w=10.0e6, dt_hours=1.0, temperature_k=333.15)
    assert state.state_of_charge <= storage_config.max_state_of_charge + 1e-6


def test_cannot_discharge_below_min_state_of_charge(storage_config):
    storage = ThermalStorage(storage_config, state_of_charge=0.06)
    state = storage.step(requested_power_w=-10.0e6, dt_hours=1.0, temperature_k=333.15)
    assert state.state_of_charge >= storage_config.min_state_of_charge - 1e-6


def test_charge_power_respects_max_charge_limit(storage_config):
    storage = ThermalStorage(storage_config)
    state = storage.step(requested_power_w=10.0e6, dt_hours=0.01, temperature_k=333.15)
    assert state.charge_power_w <= storage_config.max_charge_mw * 1e6 + 1.0


def test_standing_loss_reduces_energy_even_while_holding():
    config = ThermalStorageConfig(
        enabled=True, capacity_mwh=4.0, max_charge_mw=2.0, max_discharge_mw=2.0,
        standing_loss_fraction_per_hour=0.05, initial_state_of_charge=0.5,
    )
    storage = ThermalStorage(config)
    state = storage.step(requested_power_w=0.0, dt_hours=1.0, temperature_k=333.15)
    assert state.mode == "hold"
    assert state.state_of_charge < 0.5


def test_disabled_storage_raises_on_step():
    config = ThermalStorageConfig(enabled=False)
    storage = ThermalStorage(config)
    with pytest.raises(StorageLimitError):
        storage.step(requested_power_w=1.0, dt_hours=1.0, temperature_k=333.15)


def test_mass_energy_never_created_by_storage(storage_config):
    """No more energy should leave storage over a discharge step than it held (mass/energy conservation)."""
    storage = ThermalStorage(storage_config, state_of_charge=0.1)
    initial_mwh = storage.energy_content_mwh
    state = storage.step(requested_power_w=-100.0e6, dt_hours=1.0, temperature_k=333.15)
    discharged_mwh = state.discharge_power_w * 1.0 / 1e6
    assert discharged_mwh <= initial_mwh + 1e-6
