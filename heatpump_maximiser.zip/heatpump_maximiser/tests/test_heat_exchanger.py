import pytest

from config.system_config import HeatExchangerConfig
from heat_exchanger.effectiveness import (
    duty_from_effectiveness,
    effectiveness_counterflow,
    ntu,
    outlet_temperatures,
)
from heat_exchanger.exchanger import HeatExchanger
from heat_exchanger.pressure_drop import pressure_drop_at_flow
from thermodynamics.properties import c_to_k


def test_effectiveness_bounded_in_unit_interval():
    eff = effectiveness_counterflow(ntu_value=3.0, capacity_ratio=0.5)
    assert 0.0 < eff < 1.0


def test_effectiveness_increases_with_ntu():
    low = effectiveness_counterflow(ntu_value=0.5, capacity_ratio=0.5)
    high = effectiveness_counterflow(ntu_value=5.0, capacity_ratio=0.5)
    assert high > low


def test_never_extracts_more_than_thermodynamically_possible():
    """Section 6: never extract more heat than physically exists."""
    duty = duty_from_effectiveness(effectiveness=0.95, c_min_w_k=1000.0, hot_in_k=310.0, cold_in_k=300.0)
    q_max = 1000.0 * (310.0 - 300.0)
    assert duty <= q_max


def test_outlet_temperatures_respect_second_law():
    hot_out, cold_out = outlet_temperatures(duty_w=5000.0, hot_in_k=310.0, cold_in_k=300.0, c_hot_w_k=1000.0, c_cold_w_k=1000.0)
    assert hot_out >= cold_out - 1e-9
    with pytest.raises(ValueError):
        outlet_temperatures(duty_w=50_000.0, hot_in_k=310.0, cold_in_k=300.0, c_hot_w_k=1000.0, c_cold_w_k=1000.0)


def test_exchanger_zero_duty_when_below_approach_temperature():
    config = HeatExchangerConfig(effectiveness=0.9, approach_temperature_k=3.0)
    hx = HeatExchanger(config, design_flow_kg_s=300.0)
    state = hx.solve(
        hot_fluid="Water", hot_in_k=c_to_k(34.8), hot_flow_kg_s=300.0, hot_pressure_pa=200_000.0,
        cold_fluid="Water", cold_in_k=c_to_k(32.5), cold_flow_kg_s=300.0, cold_pressure_pa=200_000.0,
    )
    # Only ~2.3 K available versus a 3 K approach limit: no duty should be possible.
    assert state.duty_w == pytest.approx(0.0, abs=1.0)


def test_exchanger_produces_duty_with_adequate_delta_t():
    config = HeatExchangerConfig(effectiveness=0.9, approach_temperature_k=3.0)
    hx = HeatExchanger(config, design_flow_kg_s=300.0)
    state = hx.solve(
        hot_fluid="Water", hot_in_k=c_to_k(35.0), hot_flow_kg_s=300.0, hot_pressure_pa=200_000.0,
        cold_fluid="Water", cold_in_k=c_to_k(28.0), cold_flow_kg_s=300.0, cold_pressure_pa=200_000.0,
    )
    assert state.duty_w > 0
    assert state.hot_out_k >= state.cold_in_k


def test_pressure_drop_scales_with_square_of_flow_ratio():
    dp_full = pressure_drop_at_flow(design_pressure_drop_pa=40_000.0, design_flow_kg_s=300.0, actual_flow_kg_s=300.0)
    dp_half = pressure_drop_at_flow(design_pressure_drop_pa=40_000.0, design_flow_kg_s=300.0, actual_flow_kg_s=150.0)
    assert dp_full == pytest.approx(40_000.0)
    assert dp_half == pytest.approx(10_000.0)  # quarter of design duty at half flow
