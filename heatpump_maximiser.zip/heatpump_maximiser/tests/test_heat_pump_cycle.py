import pytest

from heat_pump.compressor import compress
from heat_pump.cycle import solve_cycle
from heat_pump.errors import HeatPumpPhysicsError
from heat_pump.refrigerant import Refrigerant
from thermodynamics.properties import c_to_k


@pytest.fixture
def refrigerant():
    return Refrigerant("R1234ze(E)")


def test_refrigerant_rejects_unknown_fluid():
    with pytest.raises(ValueError):
        Refrigerant("NotARealRefrigerant")


def test_cycle_cop_below_carnot_limit(refrigerant):
    result = solve_cycle(
        refrigerant, evaporating_temperature_k=c_to_k(28.0), condensing_temperature_k=c_to_k(65.5),
        evaporator_duty_w=7.18e6,
    )
    assert result.cop_heating > 0
    assert result.cop_heating < result.carnot_cop_heating  # Second Law: real COP is always below the Carnot limit


def test_cycle_energy_balance_holds(refrigerant):
    result = solve_cycle(
        refrigerant, evaporating_temperature_k=c_to_k(28.0), condensing_temperature_k=c_to_k(65.5),
        evaporator_duty_w=7.18e6,
    )
    assert result.energy_balance.is_balanced
    # Q_evap + W_shaft == Q_cond, independently re-checked here
    residual = (result.heat_absorbed_w + result.compressor.shaft_power_w) - result.heat_rejected_w
    assert abs(residual) < 1.0  # watts


def test_cop_decreases_as_temperature_lift_increases(refrigerant):
    """Section 9: increasing delivery temperature at fixed source should reduce COP."""
    cops = []
    for delivery_c in (45, 55, 65, 75):
        result = solve_cycle(
            refrigerant, evaporating_temperature_k=c_to_k(28.0), condensing_temperature_k=c_to_k(delivery_c),
            evaporator_duty_w=5.0e6,
        )
        cops.append(result.cop_heating)
    assert cops == sorted(cops, reverse=True)


def test_zero_duty_gives_zero_mass_flow_and_zero_power(refrigerant):
    result = solve_cycle(
        refrigerant, evaporating_temperature_k=c_to_k(20.0), condensing_temperature_k=c_to_k(60.0),
        evaporator_duty_w=0.0,
    )
    assert result.mass_flow_kg_s == 0.0
    assert result.compressor.electrical_power_w == 0.0


def test_pressure_ratio_limit_is_enforced(refrigerant):
    """An excessive single-stage lift should raise, not silently exceed the equipment envelope."""
    with pytest.raises(HeatPumpPhysicsError):
        solve_cycle(
            refrigerant, evaporating_temperature_k=c_to_k(0.0), condensing_temperature_k=c_to_k(90.0),
            evaporator_duty_w=1.0e6, max_pressure_ratio=6.0,
        )


def test_compressor_rejects_reversed_pressure_gradient(refrigerant):
    # A superheated suction state (5 K above saturation), not a raw saturation
    # T/P pair (which is thermodynamically ambiguous without a quality).
    p_sat = refrigerant.saturation_pressure_pa(c_to_k(20.0))
    suction = refrigerant.state_tp(c_to_k(25.0), p_sat)
    with pytest.raises(ValueError):
        compress(refrigerant, suction, discharge_pressure_pa=suction.pressure_pa * 0.5, mass_flow_kg_s=1.0,
                 isentropic_efficiency=0.75)


def test_condensing_above_critical_temperature_is_rejected(refrigerant):
    with pytest.raises(ValueError):
        refrigerant.saturation_pressure_pa(refrigerant.critical_temperature_k + 5.0)
