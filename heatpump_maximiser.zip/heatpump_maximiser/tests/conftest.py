import pytest

from config.system_config import default_config
from core.state import SourceState
from thermodynamics.properties import c_to_k


@pytest.fixture
def plant_config():
    return default_config()


@pytest.fixture
def source_state():
    return SourceState(
        fluid="Water",
        temperature_k=c_to_k(34.8),
        flow_kg_s=312.0,
        pressure_pa=200_000.0,
        specific_heat_j_kgk=4180.0,
        min_return_temperature_k=c_to_k(25.0),
        available_heat_w=8.42e6,
        max_extraction_rate_w=8.42e6,
    )
