import pytest
from pydantic import ValidationError

from config.system_config import HeatPumpConfig, HeatSourceConfig, OptimisationConfig, default_config


def test_default_config_is_valid():
    config = default_config()
    assert config.heat_pump.refrigerant == "R1234ze(E)"


def test_heat_source_rejects_return_temperature_above_supply():
    with pytest.raises(ValidationError):
        HeatSourceConfig(temperature_c=30.0, flow_kg_s=100.0, min_return_temperature_c=35.0)


def test_heat_pump_rejects_inverted_temperature_range():
    with pytest.raises(ValidationError):
        HeatPumpConfig(max_power_mw=1.0, min_source_temperature_c=90.0, max_sink_temperature_c=20.0)


def test_heat_pump_rejects_negative_power():
    with pytest.raises(ValidationError):
        HeatPumpConfig(max_power_mw=-1.0)


def test_optimisation_config_requires_weights_summing_to_one():
    with pytest.raises(ValidationError):
        OptimisationConfig(objective="weighted_multiobjective", weights={"heat_recovery": 0.5, "cop": 0.6})


def test_optimisation_config_accepts_normalised_weights():
    config = OptimisationConfig(
        objective="weighted_multiobjective",
        weights={"heat_recovery": 0.25, "cop": 0.25, "net_output": 0.25, "exergy_efficiency": 0.25},
    )
    assert config.objective == "weighted_multiobjective"


def test_config_round_trips_through_json():
    config = default_config()
    restored = config.model_validate_json(config.model_dump_json())
    assert restored == config
