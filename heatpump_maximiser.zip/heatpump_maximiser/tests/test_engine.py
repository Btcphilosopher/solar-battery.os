import pytest

from core.engine import InfeasibleOperatingPointError, evaluate_operating_point
from thermodynamics.properties import c_to_k
from validation.energy_balance import validate_plant_energy_balance


def test_evaluate_operating_point_is_energy_balanced(plant_config, source_state):
    state = evaluate_operating_point(
        plant_config, source_state,
        evaporating_temperature_k=c_to_k(22.0), condensing_temperature_k=c_to_k(66.5),
        low_temp_loop_flow_kg_s=312.0, sink_loop_return_k=c_to_k(45.0),
    )
    assert state.status == "OPTIMAL"
    balance = validate_plant_energy_balance(state)
    assert balance.is_balanced


def test_evaluate_operating_point_never_exceeds_source_available_heat(plant_config, source_state):
    state = evaluate_operating_point(
        plant_config, source_state,
        evaporating_temperature_k=c_to_k(22.0), condensing_temperature_k=c_to_k(66.5),
        low_temp_loop_flow_kg_s=312.0, sink_loop_return_k=c_to_k(45.0),
    )
    assert state.metrics.heat_recovered_w <= source_state.available_heat_w + 1.0


def test_cop_never_exceeds_carnot_limit(plant_config, source_state):
    state = evaluate_operating_point(
        plant_config, source_state,
        evaporating_temperature_k=c_to_k(22.0), condensing_temperature_k=c_to_k(66.5),
        low_temp_loop_flow_kg_s=312.0, sink_loop_return_k=c_to_k(45.0),
    )
    assert state.metrics.cop <= state.heat_pump.carnot_cop


def test_infeasible_source_temperature_below_equipment_minimum_raises(plant_config, source_state):
    with pytest.raises(InfeasibleOperatingPointError):
        evaluate_operating_point(
            plant_config, source_state,
            evaporating_temperature_k=c_to_k(-50.0),  # far below the configured equipment minimum
            condensing_temperature_k=c_to_k(66.5), low_temp_loop_flow_kg_s=312.0,
        )


def test_condensing_below_evaporating_is_infeasible(plant_config, source_state):
    with pytest.raises(InfeasibleOperatingPointError):
        evaluate_operating_point(
            plant_config, source_state,
            evaporating_temperature_k=c_to_k(30.0), condensing_temperature_k=c_to_k(20.0),
            low_temp_loop_flow_kg_s=312.0,
        )


def test_net_thermal_output_never_exceeds_gross_delivered(plant_config, source_state):
    state = evaluate_operating_point(
        plant_config, source_state,
        evaporating_temperature_k=c_to_k(22.0), condensing_temperature_k=c_to_k(66.5),
        low_temp_loop_flow_kg_s=312.0, sink_loop_return_k=c_to_k(45.0),
    )
    assert state.metrics.net_thermal_output_w <= state.metrics.heat_delivered_w + 1.0
