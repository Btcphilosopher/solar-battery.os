#!/usr/bin/env python3
"""
Heat Pump Thermal Recovery Maximiser — command-line entry point.

    python main.py                          run the default plant, print the optimisation report
    python main.py --config plant.yaml       run a specific plant configuration
    python main.py --scenario high_datacentre_load
    python main.py --all-scenarios           compare every section-23 scenario
    python main.py --marginal-gains          also print the marginal-gain ranking
    python main.py --dashboard out.html      also save an interactive HTML dashboard
    python main.py --sweep                   print the section-9 delivery-temperature sweep table
"""

from __future__ import annotations

import argparse
import sys

from config.system_config import PlantConfig, default_config, load_config
from core.state import SourceState
from optimisation.marginal_gain import search_marginal_gains
from optimisation.temperature_optimizer import find_optimal_delivery_temperature, sweep_delivery_temperature
from scenarios.scenario_runner import build_scenarios, run_scenario
from thermodynamics.properties import c_to_k


def build_default_source(config: PlantConfig) -> SourceState:
    """Resolve a SourceState from a plant's heat_source (and datacentre_source, if present) configuration."""
    if config.datacentre_source is not None:
        from heat_source.datacentre import DataCentreSource

        dc = DataCentreSource(config.datacentre_source, min_return_temperature_c=config.heat_source.min_return_temperature_c)
        stream = dc.to_waste_heat_stream()
    else:
        from heat_source.waste_heat import WasteHeatStream

        stream = WasteHeatStream(
            fluid=config.heat_source.fluid, temperature_c=config.heat_source.temperature_c,
            flow_kg_s=config.heat_source.flow_kg_s, pressure_pa=config.heat_source.pressure_pa,
            min_return_temperature_c=config.heat_source.min_return_temperature_c,
            max_extraction_rate_mw=config.heat_source.max_extraction_rate_mw,
        )
    return stream.to_source_state()


def evaporator_offset_k(config: PlantConfig, extra_margin_k: float = 3.0) -> float:
    return config.heat_pump.evaporator_pinch_k + config.heat_exchanger.approach_temperature_k + extra_margin_k


def format_report(config: PlantConfig, source: SourceState, state) -> str:
    m = state.metrics
    lines = [
        "=" * 60,
        "HEAT-PUMP MAXIMISER".center(60),
        "=" * 60,
        "",
        "SOURCE",
        f"  Temperature:          {source.temperature_c:6.1f} degC",
        f"  Available heat:       {source.available_heat_w / 1e6:6.2f} MW",
        f"  Flow:                 {source.flow_kg_s:6.0f} kg/s",
        "",
        "OPTIMAL SETPOINT",
        f"  Delivery temperature: {m.delivery_temperature_k - 273.15:6.1f} degC",
        f"  Temperature lift:     {m.temperature_lift_k:6.1f} K",
        f"  Heat recovery:        {m.heat_recovered_w / 1e6:6.2f} MW",
        f"  Heat delivered:       {m.heat_delivered_w / 1e6:6.2f} MW",
        f"  Electrical input:     {m.electrical_input_w / 1e6:6.2f} MW",
        f"  COP:                  {m.cop:6.2f}",
        f"  Net thermal output:   {m.net_thermal_output_w / 1e6:6.2f} MW",
        f"  Net electrical:       {m.net_electrical_output_w / 1e6:+6.2f} MW",
        "",
        "EXERGY",
        f"  Exergy supplied:      {state.exergy.total_exergy_supplied_w / 1e6:6.2f} MW",
        f"  Exergy delivered:     {state.exergy.final_exergy_out_w / 1e6:6.2f} MW",
        f"  Exergy destroyed:     {m.exergy_destroyed_w / 1e6:6.2f} MW",
        f"  Exergy (2nd-law) eff: {m.exergy_efficiency * 100:6.1f} %",
        "",
        "SYSTEM",
        f"  Heat exchanger:       {m.heat_exchanger_effectiveness * 100:6.1f} %",
        f"  Compressor:           {m.compressor_efficiency * 100:6.1f} %",
        f"  Pump consumption:     {m.pump_consumption_w / 1e6:6.3f} MW",
        f"  System efficiency:    {m.system_efficiency * 100:6.1f} %",
        f"  kWh elec / MWh heat:  {m.specific_electricity_kwh_per_mwh_heat:6.1f}",
        "",
        "STATUS",
        f"  {state.status}",
    ]
    if state.warnings:
        lines.append("")
        lines.append("WARNINGS")
        for w in state.warnings:
            lines.append(f"  - {w}")
    lines.append("=" * 60)
    return "\n".join(lines)


def run_default_optimisation(config: PlantConfig):
    source = build_default_source(config)
    evap_k = max(
        source.temperature_k - evaporator_offset_k(config),
        c_to_k(config.heat_pump.min_source_temperature_c),
    )
    delivery_max_c = min(
        config.optimisation.delivery_temperature_search_max_c,
        config.heat_pump.max_sink_temperature_c - config.heat_pump.condenser_pinch_k,
    )
    result = find_optimal_delivery_temperature(
        config, source, evap_k, source.flow_kg_s,
        config.optimisation.delivery_temperature_search_min_c, delivery_max_c,
    )
    return source, evap_k, result


def main() -> int:
    parser = argparse.ArgumentParser(description="Heat Pump Thermal Recovery Maximiser")
    parser.add_argument("--config", type=str, default=None, help="Path to a plant configuration YAML/JSON file")
    parser.add_argument("--scenario", type=str, default=None, help="Run one named scenario instead of the default plant")
    parser.add_argument("--all-scenarios", action="store_true", help="Run and compare every built-in scenario")
    parser.add_argument("--sweep", action="store_true", help="Print the delivery-temperature sweep table")
    parser.add_argument("--marginal-gains", action="store_true", help="Print the marginal-gain ranking")
    parser.add_argument("--dashboard", type=str, default=None, help="Save an interactive HTML dashboard to this path")
    args = parser.parse_args()

    if args.all_scenarios:
        print("SCENARIO COMPARISON".center(70, "="))
        for key, scenario in build_scenarios().items():
            result = run_scenario(scenario)
            if result.plant_state is None:
                print(f"{scenario.name:30s} INFEASIBLE")
                continue
            m = result.plant_state.metrics
            print(
                f"{scenario.name:30s} delivery={m.delivery_temperature_k - 273.15:5.1f}C  "
                f"COP={m.cop:5.2f}  net={m.net_thermal_output_w / 1e6:6.2f} MW  "
                f"exergy_eff={m.exergy_efficiency * 100:5.1f}%"
            )
        return 0

    if args.scenario:
        scenarios = build_scenarios()
        if args.scenario not in scenarios:
            print(f"Unknown scenario '{args.scenario}'. Available: {list(scenarios.keys())}", file=sys.stderr)
            return 1
        scenario = scenarios[args.scenario]
        config, source_stream = scenario.config, scenario.source
        source = source_stream.to_source_state()
        result = run_scenario(scenario)
        if result.plant_state is None:
            print(f"Scenario '{args.scenario}' is INFEASIBLE with the current configuration.")
            return 1
        print(format_report(config, source, result.plant_state))
        evap_k = result.evaporating_temperature_k
    else:
        config = load_config(args.config) if args.config else default_config()
        source, evap_k, result = run_default_optimisation(config)
        if result.plant_state is None:
            print("No feasible operating point found for the default configuration.", file=sys.stderr)
            return 1
        print(format_report(config, source, result.plant_state))

    if args.sweep:
        print()
        print("DELIVERY TEMPERATURE SWEEP".center(70, "="))
        df = sweep_delivery_temperature(
            config, source, evap_k, source.flow_kg_s,
            [45, 50, 55, 60, 65, 70, 75, 80],
        )
        print(df.to_string(index=False))

    if args.marginal_gains:
        print()
        print("MARGINAL-GAIN SEARCH".center(70, "="))
        gains = search_marginal_gains(
            config, source, evap_k, result.plant_state.heat_pump.condensing_temperature_k, source.flow_kg_s,
        )
        if not gains:
            print("  No marginal-gain candidates could be evaluated.")
        for g in gains:
            print(f"  {g.expected_improvement_fraction * 100:+6.2f}%  {g.description}")

    if args.dashboard:
        from visualisation.dashboard import save_dashboard_html

        df = sweep_delivery_temperature(config, source, evap_k, source.flow_kg_s, [45, 50, 55, 60, 65, 70, 75, 80])
        path = save_dashboard_html(result.plant_state, args.dashboard, sweep_df=df)
        print(f"\nDashboard saved to {path}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
