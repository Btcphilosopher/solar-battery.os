"""
Effectiveness-NTU heat exchanger relations (standard textbook correlations —
Incropera & DeWitt / Kays & London — not invented here).

Used to relate a physical exchanger (UA, flow capacity rates) to its
effectiveness, and to compute actual duty and outlet temperatures without
needing to solve a detailed 2D thermal-hydraulic model.
"""

from __future__ import annotations

import math


def capacity_rate(mass_flow_kg_s: float, specific_heat_j_kgk: float) -> float:
    """Heat capacity rate C = m_dot * cp, W/K."""
    if mass_flow_kg_s < 0:
        raise ValueError("mass_flow_kg_s must be non-negative")
    return mass_flow_kg_s * specific_heat_j_kgk


def ntu(ua_w_k: float, c_min_w_k: float) -> float:
    """Number of Transfer Units, NTU = UA / C_min."""
    if c_min_w_k <= 0:
        raise ValueError("c_min_w_k must be positive")
    return ua_w_k / c_min_w_k


def effectiveness_counterflow(ntu_value: float, capacity_ratio: float) -> float:
    """
    Effectiveness of a counter-flow heat exchanger.

        Cr = 1:   eff = NTU / (1 + NTU)
        Cr != 1:  eff = (1 - exp(-NTU*(1-Cr))) / (1 - Cr*exp(-NTU*(1-Cr)))
    """
    if ntu_value < 0:
        raise ValueError("ntu_value must be non-negative")
    if not (0.0 <= capacity_ratio <= 1.0):
        raise ValueError("capacity_ratio must be in [0, 1]")
    if abs(capacity_ratio - 1.0) < 1e-9:
        return ntu_value / (1.0 + ntu_value)
    exponent = math.exp(-ntu_value * (1.0 - capacity_ratio))
    return (1.0 - exponent) / (1.0 - capacity_ratio * exponent)


def effectiveness_to_ntu_counterflow(effectiveness: float, capacity_ratio: float) -> float:
    """Inverse of effectiveness_counterflow: solve for NTU given a target effectiveness."""
    if not (0.0 < effectiveness < 1.0):
        raise ValueError("effectiveness must be strictly between 0 and 1")
    if not (0.0 <= capacity_ratio <= 1.0):
        raise ValueError("capacity_ratio must be in [0, 1]")
    if abs(capacity_ratio - 1.0) < 1e-9:
        return effectiveness / (1.0 - effectiveness)
    numerator = math.log((1.0 - effectiveness * capacity_ratio) / (1.0 - effectiveness))
    return numerator / (1.0 - capacity_ratio)


def evaporating_condensing_effectiveness(ntu_value: float) -> float:
    """
    Effectiveness when one side undergoes an isothermal phase change
    (Cr -> 0), e.g. a refrigerant evaporating against the waste-heat stream:

        eff = 1 - exp(-NTU)
    """
    if ntu_value < 0:
        raise ValueError("ntu_value must be non-negative")
    return 1.0 - math.exp(-ntu_value)


def duty_from_effectiveness(
    effectiveness: float,
    c_min_w_k: float,
    hot_in_k: float,
    cold_in_k: float,
) -> float:
    """
    Actual heat duty, W, from effectiveness and the maximum thermodynamically
    possible duty:

        Q = eff * C_min * (T_hot_in - T_cold_in)
    """
    if hot_in_k <= cold_in_k:
        raise ValueError("hot_in_k must exceed cold_in_k for heat to flow from hot to cold")
    if not (0.0 < effectiveness <= 1.0):
        raise ValueError("effectiveness must be in (0, 1]")
    q_max = c_min_w_k * (hot_in_k - cold_in_k)
    return effectiveness * q_max


def outlet_temperatures(
    duty_w: float,
    hot_in_k: float,
    cold_in_k: float,
    c_hot_w_k: float,
    c_cold_w_k: float,
) -> tuple[float, float]:
    """Outlet temperatures (hot_out_k, cold_out_k) for a given duty and capacity rates."""
    if c_hot_w_k <= 0 or c_cold_w_k <= 0:
        raise ValueError("capacity rates must be positive")
    hot_out = hot_in_k - duty_w / c_hot_w_k
    cold_out = cold_in_k + duty_w / c_cold_w_k
    if hot_out < cold_in_k - 1e-6:
        raise ValueError("Second Law violation: hot outlet temperature would fall below cold inlet temperature")
    return hot_out, cold_out
