"""
The waste-heat side heat exchanger: the physical link between the waste-heat
loop and the heat pump's low-temperature (evaporator) loop.

    WASTE HEAT (hot side, source stream)
            |
       HEAT EXCHANGER   <- this module
            |
    LOW-TEMPERATURE LOOP (cold side, feeds the evaporator)

Two solve modes are supported:

- `solve_from_effectiveness`: given both flows, apply the configured (or
  fouling-degraded) effectiveness directly — the fast path used inside the
  optimiser's inner loop.
- `solve_from_ua`: given both flows and a physical UA (degraded for
  fouling), derive effectiveness from NTU — used when UA is known from
  design data rather than an assumed effectiveness.

Both paths enforce the approach-temperature limit and Second Law validity
(hot outlet cannot cross the cold inlet).
"""

from __future__ import annotations

from config.system_config import HeatExchangerConfig
from core.state import HeatExchangerState
from heat_exchanger.effectiveness import (
    capacity_rate,
    duty_from_effectiveness,
    effectiveness_counterflow,
    ntu as ntu_of,
    outlet_temperatures,
)
from heat_exchanger.pressure_drop import pressure_drop_at_flow
from thermodynamics.properties import specific_heat


class HeatExchanger:
    def __init__(self, config: HeatExchangerConfig, design_flow_kg_s: float):
        self.config = config
        self.design_flow_kg_s = design_flow_kg_s

    def _effective_effectiveness(self, requested: float | None = None) -> float:
        eff = requested if requested is not None else self.config.effectiveness
        # Fouling degrades effectiveness: a crude but conservative correction
        # proportional to the pressure-drop multiplier's excess over 1.0,
        # capped so effectiveness never drops below 50% of the clean value.
        from heat_exchanger.pressure_drop import fouling_pressure_drop_multiplier

        degradation = fouling_pressure_drop_multiplier(self.config.fouling_factor_m2k_w) - 1.0
        derated = eff * max(1.0 - 0.15 * degradation, 0.5)
        return min(derated, 0.999)

    def solve(
        self,
        hot_fluid: str,
        hot_in_k: float,
        hot_flow_kg_s: float,
        hot_pressure_pa: float,
        cold_fluid: str,
        cold_in_k: float,
        cold_flow_kg_s: float,
        cold_pressure_pa: float,
    ) -> HeatExchangerState:
        if hot_in_k <= cold_in_k:
            raise ValueError(
                f"No heat can flow: hot inlet {hot_in_k:.2f} K is not above cold inlet {cold_in_k:.2f} K"
            )
        if hot_flow_kg_s <= 0 or cold_flow_kg_s <= 0:
            raise ValueError("Both hot_flow_kg_s and cold_flow_kg_s must be positive")

        cp_hot = specific_heat(hot_fluid, hot_in_k, hot_pressure_pa)
        cp_cold = specific_heat(cold_fluid, cold_in_k, cold_pressure_pa)
        c_hot = capacity_rate(hot_flow_kg_s, cp_hot)
        c_cold = capacity_rate(cold_flow_kg_s, cp_cold)
        c_min = min(c_hot, c_cold)
        c_max = max(c_hot, c_cold)
        capacity_ratio = c_min / c_max

        if self.config.ua_w_k is not None:
            # config.ua_w_k is the as-new (clean) UA; degrade it for accumulated
            # fouling using the same pressure-drop-derived severity factor as
            # the effectiveness path, keeping the two solve modes consistent.
            from heat_exchanger.pressure_drop import fouling_pressure_drop_multiplier

            severity = fouling_pressure_drop_multiplier(self.config.fouling_factor_m2k_w) - 1.0
            ua = self.config.ua_w_k * max(1.0 - 0.15 * severity, 0.5)
            ntu_value = ntu_of(ua, c_min)
            effectiveness = effectiveness_counterflow(ntu_value, capacity_ratio)
        else:
            effectiveness = self._effective_effectiveness()
            ntu_value = None

        # Enforce the minimum approach temperature: effectiveness cannot push
        # the pinch below the physical/economic approach limit set in config.
        max_duty_for_approach = c_min * (hot_in_k - cold_in_k - self.config.approach_temperature_k)
        q_max = c_min * (hot_in_k - cold_in_k)
        duty = min(duty_from_effectiveness(effectiveness, c_min, hot_in_k, cold_in_k), max(max_duty_for_approach, 0.0))
        duty = max(duty, 0.0)
        achieved_effectiveness = duty / q_max if q_max > 0 else 0.0

        hot_out_k, cold_out_k = outlet_temperatures(duty, hot_in_k, cold_in_k, c_hot, c_cold)

        dp = pressure_drop_at_flow(self.config.pressure_drop_design_pa, self.design_flow_kg_s, hot_flow_kg_s)

        return HeatExchangerState(
            hot_in_k=hot_in_k,
            hot_out_k=hot_out_k,
            cold_in_k=cold_in_k,
            cold_out_k=cold_out_k,
            duty_w=duty,
            effectiveness=achieved_effectiveness,
            ntu=ntu_value if ntu_value is not None else float("nan"),
            pressure_drop_pa=dp,
            fouling_factor_m2k_w=self.config.fouling_factor_m2k_w,
        )

    def required_cold_flow_for_duty(
        self,
        target_duty_w: float,
        hot_fluid: str,
        hot_in_k: float,
        hot_flow_kg_s: float,
        hot_pressure_pa: float,
        cold_fluid: str,
        cold_in_k: float,
        cold_pressure_pa: float,
        max_cold_flow_kg_s: float,
    ) -> float:
        """
        Cold-side (evaporator loop) flow rate needed to absorb a target duty
        at a given cold inlet temperature, respecting the approach-temperature
        limit and a maximum available flow. Used by the optimiser when the
        evaporator loop flow is a free variable rather than fixed.
        """
        cp_hot = specific_heat(hot_fluid, hot_in_k, hot_pressure_pa)
        c_hot = capacity_rate(hot_flow_kg_s, cp_hot)
        max_possible_duty = c_hot * (hot_in_k - cold_in_k - self.config.approach_temperature_k)
        duty = min(target_duty_w, max(max_possible_duty, 0.0))
        if duty <= 0:
            return 0.0

        cp_cold = specific_heat(cold_fluid, cold_in_k, cold_pressure_pa)
        # Allow up to a generous rise on the cold side (approach-limited), then
        # solve m_dot = Q / (cp * delta_T) with delta_T bounded by the pinch.
        max_cold_rise_k = max(hot_in_k - cold_in_k - self.config.approach_temperature_k, 1.0)
        required_flow = duty / (cp_cold * max_cold_rise_k)
        return min(required_flow, max_cold_flow_kg_s)
