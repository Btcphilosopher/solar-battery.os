"""
Fouling degradation of heat-exchanger performance over time.

Fouling adds thermal resistance in series with the clean-surface resistance,
which directly reduces overall UA:

    1/U_fouled = 1/U_clean + R_f

This module also provides a simple linear-with-time fouling growth model
(asymptotic fouling curves exist but require empirical fitting per fluid;
a conservative linear model is used as the default and can be swapped for a
fitted asymptotic model once operating data exists).
"""

from __future__ import annotations

from dataclasses import dataclass


def fouled_ua(clean_ua_w_k: float, area_m2: float, fouling_factor_m2k_w: float) -> float:
    """
    Overall UA, W/K, degraded by a fouling resistance.

    `clean_ua_w_k` is the as-new UA; `area_m2` is required because fouling
    resistance is expressed per unit area (m^2 K/W) and must be converted to
    an absolute thermal resistance before combining in series.
    """
    if clean_ua_w_k <= 0 or area_m2 <= 0:
        raise ValueError("clean_ua_w_k and area_m2 must be positive")
    if fouling_factor_m2k_w < 0:
        raise ValueError("fouling_factor_m2k_w must be non-negative")
    r_clean = area_m2 / clean_ua_w_k  # K/W
    r_fouling = fouling_factor_m2k_w / area_m2  # K/W
    r_total = r_clean + r_fouling
    return area_m2 / r_total


@dataclass(frozen=True)
class LinearFoulingModel:
    """Fouling factor growing linearly with operating time since last clean."""

    clean_fouling_factor_m2k_w: float
    growth_rate_m2k_w_per_year: float

    def at(self, years_since_clean: float) -> float:
        if years_since_clean < 0:
            raise ValueError("years_since_clean must be non-negative")
        return self.clean_fouling_factor_m2k_w + self.growth_rate_m2k_w_per_year * years_since_clean


def cleaning_recommended(fouling_factor_m2k_w: float, threshold_m2k_w: float) -> bool:
    """Whether accumulated fouling has crossed the maintenance threshold."""
    return fouling_factor_m2k_w >= threshold_m2k_w
