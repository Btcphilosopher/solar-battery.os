"""
Pressure-drop modelling for the source-side heat exchanger.

A single Darcy-Weisbach-style correlation is used, calibrated through a
design-point pressure drop rather than requiring detailed exchanger
geometry (which is rarely known at the optimisation-engine level). The
exchanger is assumed turbulent (Re > 4000, true for essentially all
commercial plate/shell-and-tube exchangers at design flow), so pressure
drop scales with the square of the flow ratio:

    dP = dP_design * (m_dot / m_dot_design)^2

This is the standard affinity-law scaling used for pump/exchanger
system-curve estimation.
"""

from __future__ import annotations


def pressure_drop_at_flow(
    design_pressure_drop_pa: float,
    design_flow_kg_s: float,
    actual_flow_kg_s: float,
) -> float:
    if design_flow_kg_s <= 0:
        raise ValueError("design_flow_kg_s must be positive")
    if actual_flow_kg_s < 0:
        raise ValueError("actual_flow_kg_s must be non-negative")
    if design_pressure_drop_pa < 0:
        raise ValueError("design_pressure_drop_pa must be non-negative")
    ratio = actual_flow_kg_s / design_flow_kg_s
    return design_pressure_drop_pa * ratio ** 2


def pumping_power(pressure_drop_pa: float, volumetric_flow_m3_s: float, pump_efficiency: float = 0.7) -> float:
    """Hydraulic pumping power required to overcome a pressure drop, W."""
    if not (0.0 < pump_efficiency <= 1.0):
        raise ValueError("pump_efficiency must be in (0, 1]")
    if pressure_drop_pa < 0 or volumetric_flow_m3_s < 0:
        raise ValueError("pressure_drop_pa and volumetric_flow_m3_s must be non-negative")
    hydraulic_power = pressure_drop_pa * volumetric_flow_m3_s
    return hydraulic_power / pump_efficiency


def fouling_pressure_drop_multiplier(fouling_factor_m2k_w: float, reference_fouling_m2k_w: float = 1e-4) -> float:
    """
    Empirical multiplier on pressure drop as fouling accumulates: fouled
    surfaces narrow the flow passage, increasing velocity and friction loss.
    Linear in fouling factor above the reference (clean) value, capped at a
    physically sane 3x design pressure drop (beyond which the exchanger
    should be flagged for cleaning, not simulated).
    """
    if fouling_factor_m2k_w < 0:
        raise ValueError("fouling_factor_m2k_w must be non-negative")
    excess = max(fouling_factor_m2k_w - reference_fouling_m2k_w, 0.0)
    multiplier = 1.0 + excess / reference_fouling_m2k_w
    return min(multiplier, 3.0)
