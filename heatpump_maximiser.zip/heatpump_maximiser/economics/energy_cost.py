"""
Energy cost accounting — a reporting overlay, never the optimisation
objective by default (design philosophy: physics first). Only used when
config.economics.enabled is True and/or the optimiser objective explicitly
asks for an economic overlay.
"""

from __future__ import annotations

from config.system_config import EconomicsConfig


def electricity_cost(electrical_input_w: float, dt_hours: float, config: EconomicsConfig) -> float:
    """Cost, in currency units, of the electricity consumed over one timestep."""
    mwh = electrical_input_w / 1e6 * dt_hours
    return mwh * config.electricity_price_per_mwh


def heat_value(heat_delivered_w: float, dt_hours: float, config: EconomicsConfig) -> float:
    """Value, in currency units, of the useful heat delivered over one timestep (avoided alternative-fuel cost)."""
    mwh = heat_delivered_w / 1e6 * dt_hours
    return mwh * config.heat_value_per_mwh


def electricity_export_revenue(net_electrical_export_w: float, dt_hours: float, config: EconomicsConfig) -> float:
    """Revenue from any net electricity exported (e.g. a worthwhile downstream steam/turbine pathway)."""
    if net_electrical_export_w <= 0:
        return 0.0
    mwh = net_electrical_export_w / 1e6 * dt_hours
    return mwh * config.export_electricity_price_per_mwh
