"""Operating cost roll-up for one resolved plant state — electricity cost net of any steam-pathway export revenue."""

from __future__ import annotations

from dataclasses import dataclass

from config.system_config import EconomicsConfig
from core.state import PlantState
from economics.energy_cost import electricity_cost, electricity_export_revenue, heat_value


@dataclass(frozen=True)
class OperatingCostBreakdown:
    electricity_cost: float
    heat_value_delivered: float
    export_revenue: float
    net_cost: float


def compute_operating_cost(state: PlantState, dt_hours: float, config: EconomicsConfig) -> OperatingCostBreakdown:
    elec_cost = electricity_cost(state.metrics.electrical_input_w, dt_hours, config)
    value = heat_value(state.metrics.heat_delivered_w, dt_hours, config)
    export_electrical_w = state.steam_cycle.net_electrical_power_w if state.steam_cycle and state.steam_cycle.engaged else 0.0
    export_revenue = electricity_export_revenue(export_electrical_w, dt_hours, config)
    return OperatingCostBreakdown(
        electricity_cost=elec_cost,
        heat_value_delivered=value,
        export_revenue=export_revenue,
        net_cost=elec_cost - export_revenue,
    )
