"""
Section 17's "maximum useful energy value" objective: an optional economic
weighting used only when explicitly requested (`optimisation.objective ==
"maximum_useful_value"` or the caller opts in), never substituted silently
for the physical objectives.
"""

from __future__ import annotations

from config.system_config import EconomicsConfig
from core.state import PlantState
from economics.operating_cost import compute_operating_cost


def useful_energy_value(state: PlantState, dt_hours: float, config: EconomicsConfig) -> float:
    """
    Net value delivered by this operating point, currency units: heat value
    delivered plus any export revenue, minus electricity cost. Positive
    means the operating point is economically as well as physically
    beneficial; this is deliberately just a reporting/ranking lens, not a
    replacement for the physics-first objectives in optimisation/.
    """
    breakdown = compute_operating_cost(state, dt_hours, config)
    return breakdown.heat_value_delivered + breakdown.export_revenue - breakdown.electricity_cost
