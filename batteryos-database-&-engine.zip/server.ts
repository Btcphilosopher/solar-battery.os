import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

import { engineService } from "./src/server/batteryEngine.js";
import { MIGRATIONS } from "./src/server/sqlSchemaDDL.js";
import { R_ANALYTICS_PACKAGE_DOCS } from "./src/server/rAnalyticsCode.js";

dotenv.config();

// Initialize Gemini Client Lazily if GEMINI_API_KEY is available
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      throw new Error("GEMINI_API_KEY environment variable is missing.");
    }
    aiClient = new GoogleGenAI({ apiKey: key });
  }
  return aiClient;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "10mb" }));

  // ==========================================
  // BATTERY OS REST API ROUTES
  // ==========================================

  // Fleet Summary & Aggregations
  app.get("/api/fleet/summary", (req, res) => {
    res.json(engineService.getFleetSummary());
  });

  // Battery Systems & Packs
  app.get("/api/batteries", (req, res) => {
    res.json(engineService.getSystems());
  });

  app.get("/api/batteries/:id", (req, res) => {
    const pack = engineService.getPack(req.params.id);
    if (!pack) {
      return res.status(404).json({ error: "Battery Pack not found" });
    }
    res.json(pack);
  });

  app.get("/api/batteries/:id/state", (req, res) => {
    const pack = engineService.getPack(req.params.id);
    if (!pack) {
      return res.status(404).json({ error: "Battery Pack not found" });
    }
    res.json({
      packId: pack.id,
      packSerial: pack.packSerial,
      status: pack.status,
      soc: pack.soc,
      soh: pack.soh,
      voltage: pack.voltage,
      current: pack.current,
      powerKW: pack.powerKW,
      energyKWhRemaining: pack.energyKWhRemaining,
      temperatureAvgC: pack.temperatureAvgC,
      temperatureMaxC: pack.temperatureMaxC,
      cellDeltaMV: pack.cellDeltaMV,
      internalResistanceAvgmOhm: pack.internalResistanceAvgmOhm,
      cycleCount: pack.cycleCount,
      activeFaultCount: pack.activeFaultCount,
      lastUpdated: new Date().toISOString()
    });
  });

  app.get("/api/batteries/:id/telemetry", (req, res) => {
    res.json(engineService.getTelemetry(req.params.id));
  });

  app.get("/api/batteries/:id/rul", (req, res) => {
    res.json(engineService.getRULPrediction(req.params.id));
  });

  app.get("/api/faults", (req, res) => {
    res.json(engineService.getFaults(req.query.packId as string));
  });

  app.get("/api/events", (req, res) => {
    res.json(engineService.getAuditEvents());
  });

  app.get("/api/configs", (req, res) => {
    res.json(engineService.getSafetyConfigs());
  });

  app.get("/api/rust-pipeline", (req, res) => {
    res.json(engineService.getRustPipelineStatus());
  });

  app.get("/api/benchmarks", (req, res) => {
    res.json(engineService.getBenchmarkMetrics());
  });

  app.get("/api/data-quality", (req, res) => {
    res.json(engineService.getDataQualityLogs());
  });

  app.get("/api/sql/migrations", (req, res) => {
    res.json(MIGRATIONS);
  });

  app.get("/api/r-package/docs", (req, res) => {
    res.json(R_ANALYTICS_PACKAGE_DOCS);
  });

  // Batch Telemetry Ingestion Endpoint
  app.post("/api/telemetry", (req, res) => {
    const batch = req.body;
    if (!Array.isArray(batch)) {
      return res.status(400).json({ error: "Expected JSON array of telemetry readings" });
    }
    const result = engineService.ingesteBatchTelemetry(batch);
    res.json(result);
  });

  // Server-Side Gemini Diagnostic Endpoint
  app.post("/api/ai/diagnose", async (req, res) => {
    try {
      const { packId, prompt } = req.body;
      const pack = engineService.getPack(packId || "pack-packnmc800v003");
      const faults = engineService.getFaults(packId);

      const systemInstruction = `You are BatteryOS AI Diagnostic Assistant, a principal BMS system engineer and battery safety specialist.
Provide concise, technical, actionable insights on battery health, thermal anomalies, degradation trends, and safety mitigation steps.`;

      const userPrompt = `Battery Pack Context:
Serial: ${pack?.packSerial || "PACK-NMC-800V-003"}
Chemistry: ${pack?.chemistry}
SOH: ${pack?.soh}%
SOC: ${pack?.soc}%
Voltage: ${pack?.voltage}V
Current: ${pack?.current}A
Temp Avg/Max: ${pack?.temperatureAvgC}C / ${pack?.temperatureMaxC}C
Cell Delta: ${pack?.cellDeltaMV}mV
Active Faults: ${JSON.stringify(faults)}

User Query: ${prompt || "Analyze this battery's current thermal and health status and recommend mitigation steps."}`;

      const ai = getGeminiClient();
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: [
          { role: "user", parts: [{ text: `${systemInstruction}\n\n${userPrompt}` }] }
        ]
      });

      res.json({ reply: response.text });
    } catch (error: any) {
      console.error("Gemini Diagnosis Error:", error);
      res.status(500).json({ error: error.message || "Failed to generate AI diagnosis" });
    }
  });

  // ==========================================
  // VITE DEVELOPMENT MIDDLEWARE / PRODUCTION STATIC
  // ==========================================
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`BatteryOS Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
