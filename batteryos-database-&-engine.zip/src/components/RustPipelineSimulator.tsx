import React, { useState } from 'react';
import {
  RustPipelineStatus,
  DataQualityEvent
} from '../types';
import {
  Cpu,
  Zap,
  Activity,
  CheckCircle2,
  AlertTriangle,
  Play,
  Settings,
  Database,
  ArrowRight,
  Filter
} from 'lucide-react';

interface RustPipelineSimulatorProps {
  pipelineStatus: RustPipelineStatus;
  dataQualityLogs: DataQualityEvent[];
  onTriggerBatchIngest: (batchSize: number, introduceAnomalies: boolean) => void;
}

export const RustPipelineSimulator: React.FC<RustPipelineSimulatorProps> = ({
  pipelineStatus,
  dataQualityLogs,
  onTriggerBatchIngest
}) => {
  const [batchSize, setBatchSize] = useState<number>(1000);
  const [introduceAnomalies, setIntroduceAnomalies] = useState<boolean>(true);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [simulationResult, setSimulationResult] = useState<any>(null);

  const handleSimulate = () => {
    setIsSimulating(true);
    setTimeout(() => {
      onTriggerBatchIngest(batchSize, introduceAnomalies);
      setSimulationResult({
        received: batchSize,
        validated: introduceAnomalies ? Math.round(batchSize * 0.98) : batchSize,
        rejected: introduceAnomalies ? Math.round(batchSize * 0.02) : 0,
        flushTimeMs: (Math.random() * 1.5 + 1.2).toFixed(2)
      });
      setIsSimulating(false);
    }, 600);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
            <Cpu className="w-5 h-5 text-orange-400" />
            <span>Rust Async Ingestion Engine & Service Pipeline</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Built with <span className="font-mono text-slate-200">Tokio • SQLx • Serde • Chrono • Tracing</span> for zero-copy high-throughput sensor telemetry.
          </p>
        </div>

        <div className="flex items-center space-x-3 text-xs font-mono">
          <div className="bg-slate-950 p-2 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Active Threads</span>
            <span className="text-emerald-400 font-bold">{pipelineStatus.activeThreads} Tokio Workers</span>
          </div>
          <div className="bg-slate-950 p-2 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Buffer Flush Interval</span>
            <span className="text-cyan-400 font-bold">{pipelineStatus.flushIntervalMs} ms</span>
          </div>
          <div className="bg-slate-950 p-2 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Pipeline Throughput</span>
            <span className="text-orange-400 font-bold">{(pipelineStatus.processedPerSec / 1000).toFixed(1)}k ops/sec</span>
          </div>
        </div>
      </div>

      {/* Rust Service Pipeline Flow Diagram */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg space-y-4">
        <h3 className="text-sm font-bold text-slate-100 flex items-center justify-between">
          <span>6-Stage Async Telemetry Processing Pipeline</span>
          <span className="text-xs text-emerald-400 font-mono">SENSOR ➔ RUST ➔ VALIDATION ➔ NORMALISATION ➔ POSTGRES ➔ R</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {pipelineStatus.pipelineSteps.map((step, idx) => (
            <div key={step.name} className="bg-slate-950 border border-slate-800 p-3 rounded-lg space-y-2 relative">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono text-slate-400">Step {idx + 1}</span>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              </div>

              <div className="text-xs font-bold text-slate-100 font-mono">{step.name}</div>

              <div className="space-y-1 text-[10px] font-mono border-t border-slate-800/80 pt-2">
                <div className="flex justify-between text-slate-400">
                  <span>Throughput:</span>
                  <span className="text-slate-200">{(step.throughputPerSec / 1000).toFixed(1)}k/s</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Latency:</span>
                  <span className="text-emerald-400">{step.latencyMs} ms</span>
                </div>
              </div>

              {idx < 5 && (
                <div className="hidden lg:block absolute -right-2.5 top-1/2 -translate-y-1/2 z-10 bg-slate-900 border border-slate-700 rounded-full p-0.5 text-slate-400">
                  <ArrowRight className="w-3 h-3" />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Batch Simulator & Data Quality Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Interactive Batch Simulator */}
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg space-y-4">
          <h3 className="text-sm font-bold text-slate-100 flex items-center space-x-2 border-b border-slate-800 pb-2">
            <Zap className="w-4 h-4 text-emerald-400" />
            <span>High-Volume Telemetry Generator</span>
          </h3>

          <div className="space-y-3 text-xs">
            <div>
              <label className="text-slate-400 block mb-1 font-medium">Batch Ingest Volume (Readings)</label>
              <select
                value={batchSize}
                onChange={(e) => setBatchSize(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 text-slate-100 font-mono text-xs p-2 rounded focus:outline-none focus:border-emerald-500"
              >
                <option value={500}>500 Sensor Readings / batch</option>
                <option value={1000}>1,000 Sensor Readings / batch</option>
                <option value={5000}>5,000 Sensor Readings / batch</option>
                <option value={10000}>10,000 Sensor Readings / batch</option>
              </select>
            </div>

            <div className="flex items-center space-x-2 pt-1">
              <input
                type="checkbox"
                id="anomaliesCheck"
                checked={introduceAnomalies}
                onChange={(e) => setIntroduceAnomalies(e.target.checked)}
                className="rounded border-slate-700 bg-slate-950 text-emerald-500 focus:ring-emerald-500"
              />
              <label htmlFor="anomaliesCheck" className="text-slate-300 font-medium">
                Inject Sensor Spikes & Out-of-Order Anomalies
              </label>
            </div>

            <button
              onClick={handleSimulate}
              disabled={isSimulating}
              className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold py-2 px-4 rounded text-xs transition-all flex items-center justify-center space-x-2 shadow-md disabled:opacity-50"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>{isSimulating ? 'Processing Batch in Rust...' : 'Push Batch to Rust Pipeline'}</span>
            </button>

            {simulationResult && (
              <div className="bg-slate-950 border border-emerald-500/30 p-3 rounded text-xs space-y-1.5 font-mono">
                <div className="text-emerald-400 font-bold flex items-center justify-between">
                  <span>Batch Flush Success</span>
                  <span>{simulationResult.flushTimeMs} ms</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Readings Ingested:</span>
                  <span className="text-slate-100">{simulationResult.validated.toLocaleString()}</span>
                </div>
                {simulationResult.rejected > 0 && (
                  <div className="flex justify-between text-red-400">
                    <span>Quarantined Anomalies:</span>
                    <span className="font-bold">{simulationResult.rejected}</span>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Data Quality Event Quarantine Log */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 p-4 rounded-lg space-y-3">
          <h3 className="text-sm font-bold text-slate-100 flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="flex items-center space-x-2">
              <Filter className="w-4 h-4 text-amber-400" />
              <span>Data Quality Validation & Quarantine Log</span>
            </span>
            <span className="text-xs text-slate-400 font-mono">Never Silently Discards Invalid Data</span>
          </h3>

          <div className="space-y-2 max-h-64 overflow-y-auto pr-1 text-xs">
            {dataQualityLogs.length === 0 ? (
              <div className="text-slate-500 italic py-6 text-center">
                No data quality anomalies detected in buffer. Run batch simulation with anomalies enabled to test validation.
              </div>
            ) : (
              dataQualityLogs.map((log) => (
                <div key={log.id} className="bg-slate-950 border border-slate-800 p-2.5 rounded font-mono space-y-1">
                  <div className="flex items-center justify-between text-[10px]">
                    <span className="text-red-400 font-bold flex items-center">
                      <AlertTriangle className="w-3 h-3 mr-1" />
                      {log.eventType}
                    </span>
                    <span className="text-slate-500">{log.timestamp.slice(11, 19)}</span>
                  </div>
                  <div className="text-slate-300 text-[11px]">{log.details}</div>
                  <div className="flex justify-between text-[10px] text-slate-500 pt-0.5">
                    <span>Pack: {log.batteryPackId}</span>
                    <span className="text-amber-400 font-semibold">{log.actionTaken}</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
