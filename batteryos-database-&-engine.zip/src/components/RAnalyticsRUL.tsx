import React, { useState } from 'react';
import { RULPrediction } from '../types';
import { R_ANALYTICS_PACKAGE_DOCS, RFunctionDoc } from '../server/rAnalyticsCode';
import {
  BarChart2,
  TrendingUp,
  Activity,
  Code2,
  Play,
  CheckCircle2,
  FileCode,
  Sliders,
  ShieldCheck
} from 'lucide-react';
import {
  ResponsiveContainer,
  ComposedChart,
  Line,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid
} from 'recharts';

interface RAnalyticsRULProps {
  rulPrediction: RULPrediction;
  selectedPackId: string;
}

export const RAnalyticsRUL: React.FC<RAnalyticsRULProps> = ({
  rulPrediction,
  selectedPackId
}) => {
  const [selectedRFunction, setSelectedRFunction] = useState<RFunctionDoc>(
    R_ANALYTICS_PACKAGE_DOCS[1] // forecast_capacity default
  );
  const [isExecutingR, setIsExecutingR] = useState<boolean>(false);
  const [rExecutionLog, setRExecutionLog] = useState<string | null>(null);

  const handleRunRModel = () => {
    setIsExecutingR(true);
    setRExecutionLog('Executing R environment (R v4.3.2)...');
    setTimeout(() => {
      setRExecutionLog(
        `> library(batteryos.analytics)\n> forecast_capacity(current_soh=${rulPrediction.currentSohPct}, chemistry="LFP")\n\n[SUCCESS] R model execution finished in 18.5ms.\nEstimated RUL: ${rulPrediction.predictedRemainingCycles} cycles (${rulPrediction.predictedRemainingDays} days)\nConfidence Interval: 87% (p < 0.001)`
      );
      setIsExecutingR(false);
    }, 500);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
            <BarChart2 className="w-5 h-5 text-indigo-400" />
            <span>R Analytics & Remaining Useful Life (RUL) Model</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Authoritative statistical package <span className="font-mono text-indigo-300 font-bold">batteryos.analytics</span> for degradation decomposition, dQ/dV fitting, and capacity forecasting.
          </p>
        </div>

        <div className="flex items-center space-x-3 text-xs font-mono">
          <div className="bg-slate-950 p-2 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Model Version</span>
            <span className="text-indigo-400 font-bold">{rulPrediction.modelVersion}</span>
          </div>
          <div className="bg-slate-950 p-2 rounded border border-slate-800">
            <span className="text-slate-400 block text-[10px]">Statistical Confidence</span>
            <span className="text-emerald-400 font-bold">{rulPrediction.confidencePct}% CI</span>
          </div>
        </div>
      </div>

      {/* RUL Prediction Curve & Forecast Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* RUL Forecast Graph */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 p-4 rounded-lg space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 className="text-sm font-bold text-slate-100 flex items-center space-x-2">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              <span>SOH Degradation Trajectory & RUL Projection Curve</span>
            </h3>
            <span className="text-xs text-slate-400 font-mono">Power-Law & Arrhenius Kinetics</span>
          </div>

          <div className="h-72 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={rulPrediction.projections}>
                <defs>
                  <linearGradient id="confidenceBand" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0.05} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="cycles" stroke="#64748b" label={{ value: 'Cycle Count', position: 'insideBottom', offset: -5, fill: '#64748b', fontSize: 10 }} />
                <YAxis domain={[60, 100]} stroke="#64748b" label={{ value: 'SOH (%)', angle: -90, position: 'insideLeft', fill: '#64748b', fontSize: 10 }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '0.375rem', color: '#f8fafc' }}
                />
                <Area type="monotone" dataKey="upperBoundPct" stroke="none" fill="url(#confidenceBand)" />
                <Line type="monotone" dataKey="predictedSohPct" name="Predicted SOH (%)" stroke="#10b981" strokeWidth={3} dot={{ r: 4 }} />
                <Line type="monotone" dataKey="lowerBoundPct" name="95% Lower Bound" stroke="#818cf8" strokeDasharray="3 3" />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* RUL Key Predictions */}
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg space-y-4 flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-100 border-b border-slate-800 pb-2 flex items-center justify-between">
              <span>Remaining Useful Life (RUL)</span>
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
            </h3>

            <div className="mt-4 space-y-3 font-mono">
              <div className="bg-slate-950 p-3 rounded border border-slate-800">
                <span className="text-xs text-slate-400 block">Current SOH</span>
                <span className="text-2xl font-bold text-emerald-400">{rulPrediction.currentSohPct}%</span>
              </div>

              <div className="bg-slate-950 p-3 rounded border border-slate-800">
                <span className="text-xs text-slate-400 block">Predicted Remaining Cycles</span>
                <span className="text-2xl font-bold text-indigo-400">{rulPrediction.predictedRemainingCycles.toLocaleString()} cycles</span>
                <span className="text-[10px] text-slate-500 block mt-0.5">To 70.0% End-of-Life SOH Threshold</span>
              </div>

              <div className="bg-slate-950 p-3 rounded border border-slate-800">
                <span className="text-xs text-slate-400 block">Estimated Remaining Days</span>
                <span className="text-xl font-bold text-slate-100">~{rulPrediction.predictedRemainingDays} days</span>
                <span className="text-[10px] text-slate-500 block mt-0.5">Based on 1.4 full charge cycles / day</span>
              </div>
            </div>
          </div>

          <button
            onClick={handleRunRModel}
            disabled={isExecutingR}
            className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-2 px-4 rounded text-xs transition-all flex items-center justify-center space-x-2 shadow-md disabled:opacity-50 mt-4"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>{isExecutingR ? 'Executing R Script...' : 'Run R Analytics Inference'}</span>
          </button>
        </div>
      </div>

      {/* R Package Function Documentation & Source Code Viewer */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
          <h3 className="text-sm font-bold text-slate-100 flex items-center space-x-2">
            <Code2 className="w-4 h-4 text-indigo-400" />
            <span>batteryos.analytics R Package Function Reference</span>
          </h3>

          <div className="flex items-center space-x-2 overflow-x-auto">
            {R_ANALYTICS_PACKAGE_DOCS.map((doc) => (
              <button
                key={doc.name}
                onClick={() => setSelectedRFunction(doc)}
                className={`px-3 py-1 rounded text-xs font-mono transition-colors ${
                  selectedRFunction.name === doc.name
                    ? 'bg-indigo-600 text-white font-bold'
                    : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                {doc.name}()
              </button>
            ))}
          </div>
        </div>

        {/* Selected R Function Documentation */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="space-y-3 text-xs">
            <div>
              <span className="text-slate-400 text-[10px] block font-mono">FUNCTION SIGNATURE</span>
              <div className="font-mono bg-slate-950 text-indigo-300 p-2 rounded border border-slate-800 font-semibold mt-1">
                {selectedRFunction.signature}
              </div>
            </div>

            <div>
              <span className="text-slate-400 text-[10px] block font-mono">DESCRIPTION</span>
              <p className="text-slate-300 leading-relaxed mt-1">{selectedRFunction.description}</p>
            </div>

            <div>
              <span className="text-slate-400 text-[10px] block font-mono">PARAMETERS</span>
              <div className="space-y-1 mt-1 font-mono text-[11px]">
                {selectedRFunction.parameters.map((p) => (
                  <div key={p.name} className="bg-slate-950/60 p-1.5 rounded border border-slate-800/80 flex justify-between">
                    <span className="text-emerald-400 font-bold">{p.name} ({p.type})</span>
                    <span className="text-slate-400">{p.description}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* R Code Viewer */}
          <div className="space-y-2">
            <span className="text-slate-400 text-[10px] block font-mono">R SOURCE CODE</span>
            <pre className="bg-slate-950 text-slate-200 font-mono text-[11px] p-3 rounded border border-slate-800 overflow-x-auto max-h-64 scrollbar-thin">
              {selectedRFunction.rCode}
            </pre>
          </div>
        </div>

        {rExecutionLog && (
          <div className="bg-slate-950 border border-indigo-500/30 p-3 rounded text-xs font-mono text-emerald-400 space-y-1">
            <div className="text-slate-400 text-[10px]">R EXECUTION OUTPUT LOG:</div>
            <pre className="whitespace-pre-wrap">{rExecutionLog}</pre>
          </div>
        )}
      </div>
    </div>
  );
};
