import React, { useState } from 'react';
import { MIGRATIONS, SQLMigration } from '../server/sqlSchemaDDL';
import { BenchmarkMetrics } from '../types';
import {
  Database,
  Code2,
  Copy,
  Check,
  Zap,
  Activity,
  Layers,
  Table,
  Play
} from 'lucide-react';

interface PostgresSchemaExplorerProps {
  benchmarks: BenchmarkMetrics;
}

export const PostgresSchemaExplorer: React.FC<PostgresSchemaExplorerProps> = ({ benchmarks }) => {
  const [selectedMigration, setSelectedMigration] = useState<SQLMigration>(MIGRATIONS[0]);
  const [copied, setCopied] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'ddl' | 'erd' | 'benchmarks'>('ddl');

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedMigration.sql);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
            <Database className="w-5 h-5 text-cyan-400" />
            <span>PostgreSQL & TimescaleDB Core DDL Architecture</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Authoritative persistent storage schema, TimescaleDB hypertables, composite indexing, and domain check constraints.
          </p>
        </div>

        <div className="flex items-center space-x-2 bg-slate-950 p-1 rounded border border-slate-800 text-xs font-mono">
          <button
            onClick={() => setActiveTab('ddl')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeTab === 'ddl' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            SQL Migrations DDL
          </button>
          <button
            onClick={() => setActiveTab('erd')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeTab === 'erd' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Hierarchy & ERD
          </button>
          <button
            onClick={() => setActiveTab('benchmarks')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeTab === 'benchmarks' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            SQL Benchmarks
          </button>
        </div>
      </div>

      {activeTab === 'ddl' && (
        <div className="space-y-4">
          {/* Migration Selector Tabs */}
          <div className="flex items-center space-x-2 overflow-x-auto pb-1 scrollbar-none">
            {MIGRATIONS.map((m) => (
              <button
                key={m.version}
                onClick={() => setSelectedMigration(m)}
                className={`px-3 py-1.5 rounded text-xs font-mono transition-all whitespace-nowrap ${
                  selectedMigration.version === m.version
                    ? 'bg-cyan-500 text-slate-950 font-bold shadow-md'
                    : 'bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-800'
                }`}
              >
                {m.name}
              </button>
            ))}
          </div>

          {/* Migration SQL Viewer Card */}
          <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div>
                <h3 className="text-sm font-bold text-slate-100 font-mono">{selectedMigration.name}.sql</h3>
                <p className="text-xs text-slate-400 mt-0.5">{selectedMigration.description}</p>
              </div>

              <button
                onClick={handleCopy}
                className="bg-slate-950 hover:bg-slate-800 text-slate-200 border border-slate-700 px-3 py-1.5 rounded text-xs transition-colors flex items-center space-x-1.5 font-mono"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied!' : 'Copy SQL'}</span>
              </button>
            </div>

            <pre className="bg-slate-950 text-cyan-300 font-mono text-xs p-4 rounded border border-slate-800 overflow-x-auto max-h-[500px] scrollbar-thin leading-relaxed">
              {selectedMigration.sql}
            </pre>
          </div>
        </div>
      )}

      {activeTab === 'erd' && (
        <div className="bg-slate-900 border border-slate-800 p-6 rounded-lg space-y-6">
          <h3 className="text-sm font-bold text-slate-100 border-b border-slate-800 pb-2">
            PostgreSQL Relational Hierarchy & TimescaleDB Hypertables
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 font-mono text-xs">
            <div className="bg-slate-950 p-4 rounded border border-slate-800 space-y-2">
              <div className="text-emerald-400 font-bold">1. SYSTEMS</div>
              <p className="text-slate-400 text-[11px]">Top-level container for large physical grid storage, EV bus fleets, or microgrids.</p>
              <div className="text-slate-500 text-[10px]">PK: id (UUID)</div>
            </div>

            <div className="bg-slate-950 p-4 rounded border border-slate-800 space-y-2">
              <div className="text-cyan-400 font-bold">2. PACKS</div>
              <p className="text-slate-400 text-[11px]">Individual battery packs containing real-time projected state & models.</p>
              <div className="text-slate-500 text-[10px]">FK: system_id, model_id</div>
            </div>

            <div className="bg-slate-950 p-4 rounded border border-slate-800 space-y-2">
              <div className="text-indigo-400 font-bold">3. MODULES</div>
              <p className="text-slate-400 text-[11px]">Physical submodule sub-assemblies grouping sets of series/parallel cells.</p>
              <div className="text-slate-500 text-[10px]">FK: pack_id</div>
            </div>

            <div className="bg-slate-950 p-4 rounded border border-slate-800 space-y-2">
              <div className="text-orange-400 font-bold">4. CELLS</div>
              <p className="text-slate-400 text-[11px]">Individual lithium/sodium battery cells monitored for voltage, temp, & balancing.</p>
              <div className="text-slate-500 text-[10px]">FK: module_id, pack_id</div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'benchmarks' && (
        <div className="bg-slate-900 border border-slate-800 p-6 rounded-lg space-y-6 font-mono text-xs">
          <h3 className="text-sm font-bold text-slate-100 border-b border-slate-800 pb-2">
            PostgreSQL & Rust Engine Database Benchmarks
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="bg-slate-950 p-4 rounded border border-slate-800">
              <span className="text-slate-400 block text-[10px]">Batch Insertion Ops</span>
              <span className="text-2xl font-bold text-emerald-400">{benchmarks.batchIngestionOpsSec.toLocaleString()} ops/sec</span>
              <span className="text-slate-500 text-[10px] block mt-1">Multi-row UNNEST / COPY binary protocol</span>
            </div>

            <div className="bg-slate-950 p-4 rounded border border-slate-800">
              <span className="text-slate-400 block text-[10px]">Batch Flush Latency</span>
              <span className="text-2xl font-bold text-cyan-400">{benchmarks.batchFlushLatencyMs} ms</span>
              <span className="text-slate-500 text-[10px] block mt-1">1,000 sensor readings buffer flush</span>
            </div>

            <div className="bg-slate-950 p-4 rounded border border-slate-800">
              <span className="text-slate-400 block text-[10px]">Latest-State Query</span>
              <span className="text-2xl font-bold text-slate-100">{benchmarks.latestStateQueryLatencyMs} ms</span>
              <span className="text-slate-500 text-[10px] block mt-1">Single pack fast projection read</span>
            </div>

            <div className="bg-slate-950 p-4 rounded border border-slate-800">
              <span className="text-slate-400 block text-[10px]">Timescale Hypertable Range</span>
              <span className="text-2xl font-bold text-indigo-400">{benchmarks.timescaleHypertableQueryMs} ms</span>
              <span className="text-slate-500 text-[10px] block mt-1">24h 1-second cell telemetry filter</span>
            </div>

            <div className="bg-slate-950 p-4 rounded border border-slate-800">
              <span className="text-slate-400 block text-[10px]">Fleet Aggregation Latency</span>
              <span className="text-2xl font-bold text-orange-400">{benchmarks.fleetAggregationLatencyMs} ms</span>
              <span className="text-slate-500 text-[10px] block mt-1">Multi-system view fleet summary</span>
            </div>

            <div className="bg-slate-950 p-4 rounded border border-slate-800">
              <span className="text-slate-400 block text-[10px]">RUL Inference Latency</span>
              <span className="text-2xl font-bold text-emerald-400">{benchmarks.rulInferenceLatencyMs} ms</span>
              <span className="text-slate-500 text-[10px] block mt-1">R degradation model execution</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
