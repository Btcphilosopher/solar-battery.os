import React from 'react';
import {
  Activity,
  Cpu,
  Database,
  BarChart2,
  Zap,
  ShieldAlert,
  Flame,
  Settings,
  Bot,
  Layers,
  Radio,
  CheckCircle2
} from 'lucide-react';

interface NavbarHeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  activeFaultsCount: number;
  ingestionRateSec: number;
}

export const NavbarHeader: React.FC<NavbarHeaderProps> = ({
  activeTab,
  setActiveTab,
  activeFaultsCount,
  ingestionRateSec
}) => {
  const tabs = [
    { id: 'fleet', label: 'Fleet Overview', icon: Layers },
    { id: 'inspector', label: 'Pack & Cell Inspector', icon: Zap },
    { id: 'rust-pipeline', label: 'Rust Ingestion Engine', icon: Cpu },
    { id: 'r-analytics', label: 'R Analytics & RUL', icon: BarChart2 },
    { id: 'charging-thermal', label: 'Charging & Thermal', icon: Flame },
    { id: 'postgres-ddl', label: 'PostgreSQL Schema', icon: Database },
    { id: 'events-config', label: 'Events & Configs', icon: Settings },
    { id: 'faults', label: 'Faults & Alerts', icon: ShieldAlert, badge: activeFaultsCount },
    { id: 'ai-assistant', label: 'AI Diagnostic', icon: Bot }
  ];

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-slate-100 sticky top-0 z-50 shadow-md">
      {/* Top Banner Status Bar */}
      <div className="bg-slate-950 px-4 py-1.5 border-b border-slate-800/80 text-xs flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-1.5 text-emerald-400 font-medium">
            <Radio className="w-3.5 h-3.5 animate-pulse text-emerald-400" />
            <span>BatteryOS Runtime v3.8</span>
          </div>

          <div className="hidden sm:flex items-center space-x-3 text-slate-400 border-l border-slate-800 pl-3">
            <span className="flex items-center space-x-1">
              <Cpu className="w-3 h-3 text-orange-400" />
              <span className="text-slate-300">Rust Engine:</span>
              <span className="text-emerald-400 font-mono">{(ingestionRateSec / 1000).toFixed(1)}k ops/s</span>
            </span>

            <span className="flex items-center space-x-1">
              <Database className="w-3 h-3 text-cyan-400" />
              <span className="text-slate-300">PostgreSQL:</span>
              <span className="text-cyan-400 font-mono">Connected (0.8ms)</span>
            </span>

            <span className="flex items-center space-x-1">
              <BarChart2 className="w-3 h-3 text-indigo-400" />
              <span className="text-slate-300">R Package:</span>
              <span className="text-indigo-400 font-mono">batteryos.analytics</span>
            </span>
          </div>
        </div>

        <div className="flex items-center space-x-3 text-slate-400 text-xs">
          <span className="bg-slate-800 px-2 py-0.5 rounded text-slate-300 font-mono">
            5 Packs | 216 Cells Monitored
          </span>
          <span className="flex items-center text-emerald-400">
            <CheckCircle2 className="w-3 h-3 mr-1" />
            Telemetry Authoritative
          </span>
        </div>
      </div>

      {/* Main App Title & Navigation Tabs */}
      <div className="px-4 py-2.5 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-tr from-emerald-500 to-cyan-500 flex items-center justify-center shadow-lg shadow-emerald-500/20">
            <Activity className="w-5 h-5 text-slate-950 font-bold" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-slate-100 leading-tight tracking-tight flex items-center space-x-2">
              <span>BatteryOS</span>
              <span className="text-xs bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 px-1.5 py-0.5 rounded font-mono font-normal">
                SYSTEMS & DB
              </span>
            </h1>
            <p className="text-xs text-slate-400">
              Rust Telemetry Ingestion • PostgreSQL Hypertables • R Degradation Analytics
            </p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex items-center space-x-1 overflow-x-auto py-1 scrollbar-none">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-emerald-500 text-slate-950 shadow-md font-semibold'
                    : 'text-slate-300 hover:text-slate-100 hover:bg-slate-800/80'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-slate-950' : 'text-slate-400'}`} />
                <span>{tab.label}</span>
                {tab.badge !== undefined && tab.badge > 0 && (
                  <span
                    className={`ml-1 px-1.5 py-0.2 rounded-full text-[10px] font-bold font-mono ${
                      isActive ? 'bg-slate-950 text-red-400' : 'bg-red-500/20 text-red-400 border border-red-500/30'
                    }`}
                  >
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
