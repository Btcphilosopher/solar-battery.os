import React, { useState } from 'react';
import { BatteryPack } from '../types';
import {
  Bot,
  Send,
  Sparkles,
  Zap,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

interface AIBatteryAdvisorProps {
  packs: BatteryPack[];
  selectedPackId: string;
}

export const AIBatteryAdvisor: React.FC<AIBatteryAdvisorProps> = ({ packs, selectedPackId }) => {
  const [prompt, setPrompt] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [messages, setMessages] = useState<Array<{ role: 'user' | 'assistant'; text: string }>>([
    {
      role: 'assistant',
      text: `Hello! I am your BatteryOS AI Diagnostic Assistant. I monitor real-time pack telemetry, cell imbalances, dQ/dV degradation curves, and safety fault logs. How can I assist with your fleet diagnosis or charging optimization today?`
    }
  ]);

  const currentPack = packs.find(p => p.id === selectedPackId) || packs[0];

  const handleSend = async () => {
    if (!prompt.trim() || loading) return;

    const userText = prompt;
    setPrompt('');
    setMessages(prev => [...prev, { role: 'user', text: userText }]);
    setLoading(true);

    try {
      const res = await fetch('/api/ai/diagnose', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ packId: currentPack.id, prompt: userText })
      });
      const data = await res.json();
      if (data.reply) {
        setMessages(prev => [...prev, { role: 'assistant', text: data.reply }]);
      } else {
        setMessages(prev => [
          ...prev,
          { role: 'assistant', text: `Error: ${data.error || 'Failed to generate response'}` }
        ]);
      }
    } catch (err: any) {
      setMessages(prev => [
        ...prev,
        { role: 'assistant', text: `Network error: ${err.message || 'Server unreachable'}` }
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded bg-gradient-to-tr from-cyan-500 to-indigo-500 flex items-center justify-center">
            <Bot className="w-4 h-4 text-slate-950 font-bold" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-100 flex items-center space-x-2">
              <span>BatteryOS AI Diagnostic Assistant</span>
              <span className="text-[10px] bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 px-2 py-0.2 rounded font-mono">
                Server-Side Gemini 2.5
              </span>
            </h2>
            <p className="text-xs text-slate-400">Inspecting active pack context: <span className="text-slate-200 font-mono font-bold">{currentPack.packSerial}</span></p>
          </div>
        </div>
      </div>

      {/* Chat Messages Log */}
      <div className="space-y-3 max-h-96 overflow-y-auto p-2 scrollbar-thin">
        {messages.map((m, idx) => (
          <div
            key={idx}
            className={`p-3 rounded text-xs space-y-1 font-mono leading-relaxed ${
              m.role === 'user'
                ? 'bg-emerald-950/40 border border-emerald-500/30 text-emerald-100 ml-8'
                : 'bg-slate-950 border border-slate-800 text-slate-200 mr-8'
            }`}
          >
            <div className="text-[10px] text-slate-500 flex items-center space-x-1">
              <Sparkles className="w-3 h-3 text-cyan-400" />
              <span>{m.role === 'user' ? 'Operator' : 'BatteryOS AI Engine'}</span>
            </div>
            <div className="whitespace-pre-wrap">{m.text}</div>
          </div>
        ))}

        {loading && (
          <div className="bg-slate-950 border border-slate-800 p-3 rounded text-xs font-mono text-cyan-400 animate-pulse mr-8">
            Analyzing telemetry, cell voltages, and thermal gradients via Gemini...
          </div>
        )}
      </div>

      {/* Prompt Bar */}
      <div className="flex items-center space-x-2 border-t border-slate-800 pt-3">
        <input
          type="text"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder={`Ask about ${currentPack.packSerial} thermal gradient, degradation rate, or charging optimization...`}
          className="flex-1 bg-slate-950 border border-slate-700 text-slate-100 text-xs p-2.5 rounded focus:outline-none focus:border-cyan-500 font-mono"
        />
        <button
          onClick={handleSend}
          disabled={loading || !prompt.trim()}
          className="bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold px-4 py-2.5 rounded text-xs transition-colors flex items-center space-x-1 disabled:opacity-50"
        >
          <Send className="w-3.5 h-3.5" />
          <span>Ask AI</span>
        </button>
      </div>
    </div>
  );
};
