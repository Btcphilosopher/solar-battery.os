import React from 'react';
import {
  FleetSummary,
  BatterySystem,
  BatteryPack
} from '../types';
import {
  Zap,
  Activity,
  Layers,
  ShieldAlert,
  Flame,
  ArrowUpRight,
  TrendingUp,
  Cpu,
  CheckCircle2,
  AlertTriangle,
  Globe,
  BatteryCharging
} from 'lucide-react';

interface FleetOverviewProps {
  summary: FleetSummary;
  systems: BatterySystem[];
  onSelectPack: (packId: string) => void;
  onOpenFaults: () => void;
}

export const FleetOverview: React.FC<FleetOverviewProps> = ({
  summary,
  systems,
  onSelectPack,
  onOpenFaults
}) => {
  return (
    <div className="space-y-6">
      {/* KPI Highlights Row */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Total Systems</span>
            <Layers className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-xl font-bold text-slate-100 mt-1 font-mono">{summary.totalSystems}</div>
          <div className="text-[11px] text-slate-400 mt-0.5">{summary.totalPacks} Active Packs</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Fleet Energy</span>
            <Zap className="w-4 h-4 text-yellow-400" />
          </div>
          <div className="text-xl font-bold text-slate-100 mt-1 font-mono">{summary.totalCapacityMWh} MWh</div>
          <div className="text-[11px] text-slate-400 mt-0.5">{summary.totalCells.toLocaleString()} Total Cells</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Average SOH</span>
            <TrendingUp className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-xl font-bold text-emerald-400 mt-1 font-mono">{summary.avgSohPct}%</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Degradation &lt;0.02%/cycle</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Average SOC</span>
            <BatteryCharging className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-xl font-bold text-slate-100 mt-1 font-mono">{summary.avgSocPct}%</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Fleet Charge Balanced</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Ingestion Rate</span>
            <Cpu className="w-4 h-4 text-orange-400" />
          </div>
          <div className="text-xl font-bold text-slate-100 mt-1 font-mono">
            {(summary.ingestionRatePerSec / 1000).toFixed(1)}k <span className="text-xs font-normal text-slate-400">/s</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">{summary.totalTelemetryRecordsToday.toLocaleString()} today</div>
        </div>

        <div
          onClick={onOpenFaults}
          className="bg-slate-900 border border-slate-800 hover:border-red-500/50 p-3.5 rounded-lg cursor-pointer transition-all group"
        >
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Active Faults</span>
            <ShieldAlert className="w-4 h-4 text-red-400 group-hover:scale-110 transition-transform" />
          </div>
          <div className="text-xl font-bold text-red-400 mt-1 font-mono">{summary.activeFaultsCount}</div>
          <div className="text-[11px] text-red-400/80 mt-0.5 flex items-center">
            <span>Click to inspect</span>
            <ArrowUpRight className="w-3 h-3 ml-0.5" />
          </div>
        </div>
      </div>

      {/* Chemistries & Health Distribution Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Supported Battery Chemistries */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 p-4 rounded-lg">
          <h2 className="text-sm font-semibold text-slate-100 mb-3 flex items-center justify-between">
            <span>Supported Battery Chemistries & Fleet Allocation</span>
            <span className="text-xs text-slate-400 font-mono font-normal">Configurable Limits</span>
          </h2>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {summary.chemistriesBreakdown.map((chem) => (
              <div key={chem.name} className="bg-slate-950/60 border border-slate-800/80 p-3 rounded-lg">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-bold text-slate-200">{chem.name}</span>
                  <span className="text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-1.5 py-0.2 rounded font-mono">
                    {chem.count} Packs
                  </span>
                </div>
                <div className="text-lg font-mono font-bold text-slate-100">{chem.totalMWh} MWh</div>
                <div className="text-[10px] text-slate-400 mt-1 space-y-0.5 font-mono">
                  <div>
                    {chem.name === 'LFP'
                      ? '3.2V Nom | 3,500 Cycles'
                      : chem.name === 'NMC'
                      ? '3.7V Nom | 2,000 Cycles'
                      : chem.name === 'Sodium-Ion'
                      ? '3.1V Nom | 4,000 Cycles'
                      : '3.6V Nom | 1,800 Cycles'}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Fleet Health Distribution */}
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col justify-between">
          <div>
            <h2 className="text-sm font-semibold text-slate-100 mb-3 flex items-center justify-between">
              <span>Fleet Health Distribution (SOH)</span>
              <Activity className="w-4 h-4 text-emerald-400" />
            </h2>

            <div className="space-y-2.5 text-xs">
              {summary.healthDistribution.map((item) => (
                <div key={item.rating}>
                  <div className="flex justify-between text-slate-300 mb-1 font-mono text-[11px]">
                    <span>{item.rating}</span>
                    <span className="text-slate-400">{item.count} packs ({item.percentage}%)</span>
                  </div>
                  <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
                    <div
                      className={`h-full rounded-full ${
                        item.rating.includes('Optimal')
                          ? 'bg-emerald-500'
                          : item.rating.includes('Good')
                          ? 'bg-cyan-500'
                          : item.rating.includes('Degraded')
                          ? 'bg-amber-500'
                          : 'bg-red-500'
                      }`}
                      style={{ width: `${Math.max(item.percentage, 5)}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800/80 text-[11px] text-slate-400 flex items-center justify-between">
            <span>Authoritative SOH via dQ/dV R Engine</span>
            <span className="text-emerald-400 font-mono">99.4% Model Confidence</span>
          </div>
        </div>
      </div>

      {/* Battery Systems & Packs Detailed Hierarchy List */}
      <div className="space-y-4">
        <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
          <Globe className="w-4 h-4 text-emerald-400" />
          <span>Battery Systems Hierarchy & Active Pack Status</span>
        </h2>

        {systems.map((sys) => (
          <div key={sys.id} className="bg-slate-900 border border-slate-800 rounded-lg overflow-hidden">
            {/* System Header */}
            <div className="bg-slate-950 px-4 py-3 border-b border-slate-800 flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center space-x-3">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                <div>
                  <h3 className="text-sm font-bold text-slate-100">{sys.name}</h3>
                  <div className="text-xs text-slate-400 flex items-center space-x-2 mt-0.5">
                    <span>{sys.location}</span>
                    <span>•</span>
                    <span className="font-mono text-slate-300">{sys.systemType}</span>
                    <span>•</span>
                    <span>{sys.totalCapacityMWh} MWh Total</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center space-x-3 text-xs">
                <span className="text-slate-400">
                  Avg System SOH: <span className="text-emerald-400 font-bold font-mono">{sys.avgSoh}%</span>
                </span>
                <span className="bg-slate-800 text-slate-200 px-2.5 py-1 rounded text-xs font-mono font-medium border border-slate-700">
                  {sys.packs.length} Monitored Packs
                </span>
              </div>
            </div>

            {/* Packs Grid */}
            <div className="p-4 grid grid-cols-1 md:grid-cols-2 gap-3">
              {sys.packs.map((pack) => (
                <div
                  key={pack.id}
                  onClick={() => onSelectPack(pack.id)}
                  className="bg-slate-950/70 hover:bg-slate-800/50 border border-slate-800 hover:border-emerald-500/50 p-3.5 rounded-lg cursor-pointer transition-all space-y-3 group"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="text-sm font-bold text-slate-100 font-mono group-hover:text-emerald-400 transition-colors">
                          {pack.packSerial}
                        </span>
                        <span className="text-[10px] bg-slate-800 text-slate-300 border border-slate-700 px-1.5 py-0.2 rounded font-mono">
                          {pack.chemistry}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 mt-0.5">{pack.modelName} • {pack.manufacturerName}</p>
                    </div>

                    <div className="flex items-center space-x-1.5">
                      {pack.status === 'NORMAL' ? (
                        <span className="flex items-center text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded font-mono">
                          <CheckCircle2 className="w-3 h-3 mr-1" />
                          NORMAL
                        </span>
                      ) : (
                        <span className="flex items-center text-[10px] bg-amber-500/10 text-amber-400 border border-amber-500/30 px-2 py-0.5 rounded font-mono">
                          <AlertTriangle className="w-3 h-3 mr-1" />
                          {pack.status}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Core Electrical State Indicators */}
                  <div className="grid grid-cols-4 gap-2 text-xs bg-slate-900/80 p-2.5 rounded border border-slate-800 font-mono">
                    <div>
                      <div className="text-[10px] text-slate-400">SOC</div>
                      <div className="font-bold text-emerald-400">{pack.soc}%</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-slate-400">SOH</div>
                      <div className="font-bold text-cyan-400">{pack.soh}%</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-slate-400">Voltage</div>
                      <div className="font-bold text-slate-200">{pack.voltage}V</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-slate-400">Power</div>
                      <div className="font-bold text-slate-200">{pack.powerKW}kW</div>
                    </div>
                  </div>

                  {/* Thermal, Cell Spread & Cycles */}
                  <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 font-mono">
                    <span className="flex items-center">
                      <Flame className="w-3 h-3 mr-1 text-orange-400" />
                      Temp: <span className="text-slate-200 ml-1">{pack.temperatureAvgC}°C</span>
                    </span>
                    <span>
                      Cell Spread: <span className="text-slate-200">{pack.cellDeltaMV}mV</span>
                    </span>
                    <span>
                      Cycles: <span className="text-slate-200">{pack.cycleCount}</span>
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
