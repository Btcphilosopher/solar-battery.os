import React, { useState } from 'react';
import {
  Fault,
  AuditEvent,
  SafetyConfiguration
} from '../types';
import {
  ShieldAlert,
  History,
  Settings,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Plus,
  Save,
  Check
} from 'lucide-react';

interface FaultsEventSourcingProps {
  faults: Fault[];
  events: AuditEvent[];
  safetyConfigs: SafetyConfiguration[];
}

export const FaultsEventSourcing: React.FC<FaultsEventSourcingProps> = ({
  faults: initialFaults,
  events,
  safetyConfigs
}) => {
  const [faultList, setFaultList] = useState<Fault[]>(initialFaults);
  const [selectedFault, setSelectedFault] = useState<Fault | null>(initialFaults[0] || null);
  const [activeSubTab, setActiveSubTab] = useState<'faults' | 'events' | 'configs'>('faults');

  const handleAcknowledge = (id: string) => {
    setFaultList(prev =>
      prev.map(f => (f.id === id ? { ...f, status: 'ACKNOWLEDGED' } : f))
    );
    if (selectedFault?.id === id) {
      setSelectedFault(prev => (prev ? { ...prev, status: 'ACKNOWLEDGED' } : null));
    }
  };

  const handleResolve = (id: string) => {
    setFaultList(prev =>
      prev.map(f => (f.id === id ? { ...f, status: 'RESOLVED', resolutionNotes: 'Resolved by operator intervention.' } : f))
    );
    if (selectedFault?.id === id) {
      setSelectedFault(prev => (prev ? { ...prev, status: 'RESOLVED', resolutionNotes: 'Resolved by operator intervention.' } : null));
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Navigation */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <ShieldAlert className="w-5 h-5 text-red-400" />
          <div>
            <h2 className="text-base font-bold text-slate-100">Faults, Audit Event Ledger & Configuration History</h2>
            <p className="text-xs text-slate-400 mt-0.5">Structured safety faults, immutable event sourcing timeline, and versioned safety parameters.</p>
          </div>
        </div>

        <div className="flex items-center space-x-2 bg-slate-950 p-1 rounded border border-slate-800 text-xs font-mono">
          <button
            onClick={() => setActiveSubTab('faults')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeSubTab === 'faults' ? 'bg-red-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Faults Center ({faultList.filter(f => f.status === 'ACTIVE').length})
          </button>
          <button
            onClick={() => setActiveSubTab('events')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeSubTab === 'events' ? 'bg-red-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Event Sourcing Ledger
          </button>
          <button
            onClick={() => setActiveSubTab('configs')}
            className={`px-3 py-1.5 rounded transition-colors ${
              activeSubTab === 'configs' ? 'bg-red-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Safety Limits Configs
          </button>
        </div>
      </div>

      {activeSubTab === 'faults' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Faults Table */}
          <div className="lg:col-span-2 bg-slate-900 border border-slate-800 p-4 rounded-lg space-y-3">
            <h3 className="text-sm font-bold text-slate-100 border-b border-slate-800 pb-2">
              Structured Fault Records
            </h3>

            <div className="space-y-2">
              {faultList.map((f) => (
                <div
                  key={f.id}
                  onClick={() => setSelectedFault(f)}
                  className={`p-3 rounded border font-mono text-xs cursor-pointer transition-all space-y-1.5 ${
                    selectedFault?.id === f.id
                      ? 'bg-slate-950 border-red-500/80 shadow-md ring-1 ring-red-500/50'
                      : 'bg-slate-950/60 border-slate-800 hover:bg-slate-800/50'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          f.severity === 'CRITICAL' || f.severity === 'EMERGENCY'
                            ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                            : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                        }`}
                      >
                        {f.code}
                      </span>
                      <span className="text-slate-100 font-bold">{f.batteryPackSerial}</span>
                    </div>

                    <span
                      className={`text-[10px] font-bold ${
                        f.status === 'ACTIVE'
                          ? 'text-red-400'
                          : f.status === 'ACKNOWLEDGED'
                          ? 'text-amber-400'
                          : 'text-emerald-400'
                      }`}
                    >
                      {f.status}
                    </span>
                  </div>

                  <p className="text-slate-300 text-[11px] line-clamp-1">{f.evidence}</p>

                  <div className="text-[10px] text-slate-500 flex justify-between pt-1">
                    <span>First: {f.firstOccurrence.slice(0, 10)}</span>
                    <span>Last: {f.lastOccurrence.slice(11, 19)}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Fault Resolution Workflow Panel */}
          <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg space-y-4">
            <h3 className="text-sm font-bold text-slate-100 border-b border-slate-800 pb-2">
              Fault Inspector & Workflow
            </h3>

            {selectedFault ? (
              <div className="space-y-3 font-mono text-xs">
                <div>
                  <span className="text-slate-400 text-[10px] block">FAULT CODE</span>
                  <span className="text-red-400 font-bold text-sm">{selectedFault.code}</span>
                </div>

                <div>
                  <span className="text-slate-400 text-[10px] block">AFFECTED PACK</span>
                  <span className="text-slate-200">{selectedFault.batteryPackSerial}</span>
                </div>

                <div>
                  <span className="text-slate-400 text-[10px] block">EVIDENCE & ROOT CAUSE</span>
                  <p className="text-slate-300 bg-slate-950 p-2.5 rounded border border-slate-800 mt-1 leading-relaxed">
                    {selectedFault.evidence}
                  </p>
                </div>

                {selectedFault.resolutionNotes && (
                  <div>
                    <span className="text-slate-400 text-[10px] block">RESOLUTION NOTES</span>
                    <p className="text-emerald-400 bg-slate-950 p-2.5 rounded border border-slate-800 mt-1">
                      {selectedFault.resolutionNotes}
                    </p>
                  </div>
                )}

                <div className="space-y-2 pt-2">
                  {selectedFault.status === 'ACTIVE' && (
                    <button
                      onClick={() => handleAcknowledge(selectedFault.id)}
                      className="w-full bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold py-2 rounded transition-colors text-xs"
                    >
                      Acknowledge Fault
                    </button>
                  )}

                  {selectedFault.status !== 'RESOLVED' && (
                    <button
                      onClick={() => handleResolve(selectedFault.id)}
                      className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold py-2 rounded transition-colors text-xs"
                    >
                      Mark Resolved
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <div className="text-xs text-slate-500 italic">Select a fault to view details.</div>
            )}
          </div>
        </div>
      )}

      {activeSubTab === 'events' && (
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg space-y-4 font-mono text-xs">
          <h3 className="text-sm font-bold text-slate-100 border-b border-slate-800 pb-2 flex items-center justify-between">
            <span className="flex items-center space-x-2">
              <History className="w-4 h-4 text-emerald-400" />
              <span>Immutable Event Sourcing Ledger</span>
            </span>
            <span className="text-slate-400 text-[11px]">Append-Only Audit Log</span>
          </h3>

          <div className="space-y-3">
            {events.map((evt) => (
              <div key={evt.id} className="bg-slate-950 p-3 rounded border border-slate-800 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-emerald-400 font-bold">{evt.eventType}</span>
                  <span className="text-slate-500">{evt.timestamp.slice(0, 19).replace('T', ' ')}</span>
                </div>
                <p className="text-slate-300 text-[11px]">{evt.details}</p>
                <div className="text-slate-500 text-[10px] pt-1">
                  Actor: <span className="text-slate-400">{evt.actor}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeSubTab === 'configs' && (
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg space-y-4 font-mono text-xs">
          <h3 className="text-sm font-bold text-slate-100 border-b border-slate-800 pb-2">
            Versioned Safety Limit Configurations
          </h3>

          <div className="space-y-3">
            {safetyConfigs.map((cfg) => (
              <div key={cfg.id} className="bg-slate-950 p-4 rounded border border-slate-800 space-y-2">
                <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                  <div className="flex items-center space-x-2">
                    <span className="font-bold text-slate-100">{cfg.modelCode}</span>
                    <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 px-2 py-0.2 rounded text-[10px]">
                      Version {cfg.version}
                    </span>
                  </div>
                  <span className="text-slate-500">{cfg.createdAt.slice(0, 10)}</span>
                </div>

                <p className="text-slate-300 text-[11px] italic">{cfg.description}</p>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] pt-1">
                  <div className="bg-slate-900/80 p-2 rounded border border-slate-800">
                    <span className="text-slate-400 block text-[10px]">Voltage Limits</span>
                    <span className="text-slate-200 font-bold">{cfg.voltageLowerLimitV}V - {cfg.voltageUpperLimitV}V</span>
                  </div>
                  <div className="bg-slate-900/80 p-2 rounded border border-slate-800">
                    <span className="text-slate-400 block text-[10px]">Max Current</span>
                    <span className="text-slate-200 font-bold">{cfg.currentMaxChargeA}A Charge</span>
                  </div>
                  <div className="bg-slate-900/80 p-2 rounded border border-slate-800">
                    <span className="text-slate-400 block text-[10px]">Max Temperature</span>
                    <span className="text-orange-400 font-bold">{cfg.tempUpperLimitC} °C</span>
                  </div>
                  <div className="bg-slate-900/80 p-2 rounded border border-slate-800">
                    <span className="text-slate-400 block text-[10px]">Max Cell Delta</span>
                    <span className="text-emerald-400 font-bold">{cfg.maxCellDeltaMV} mV</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
