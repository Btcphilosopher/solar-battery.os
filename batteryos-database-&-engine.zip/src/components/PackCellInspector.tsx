import React, { useState } from 'react';
import {
  BatteryPack,
  Cell,
  TelemetryReading
} from '../types';
import {
  Zap,
  Flame,
  Activity,
  CheckCircle2,
  AlertTriangle,
  ChevronRight,
  TrendingUp,
  Cpu
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid
} from 'recharts';

interface PackCellInspectorProps {
  packs: BatteryPack[];
  selectedPackId: string;
  onSelectPack: (packId: string) => void;
  telemetryHistory: TelemetryReading[];
}

export const PackCellInspector: React.FC<PackCellInspectorProps> = ({
  packs,
  selectedPackId,
  onSelectPack,
  telemetryHistory
}) => {
  const currentPack = packs.find(p => p.id === selectedPackId) || packs[0];
  const [selectedCell, setSelectedCell] = useState<Cell | null>(
    currentPack?.modules[0]?.cells[0] || null
  );
  const [viewMode, setViewMode] = useState<'voltage' | 'temperature' | 'soh'>('voltage');

  if (!currentPack) {
    return <div className="text-slate-400">No pack selected.</div>;
  }

  // Flatten all cells for matrix calculation
  const allCells: Cell[] = [];
  currentPack.modules.forEach(m => allCells.push(...m.cells));

  const minCellVoltage = Math.min(...allCells.map(c => c.voltage));
  const maxCellVoltage = Math.max(...allCells.map(c => c.voltage));
  const minCellTemp = Math.min(...allCells.map(c => c.temperatureC));
  const maxCellTemp = Math.max(...allCells.map(c => c.temperatureC));

  // Get cell matrix color gradient based on viewMode
  const getCellBgColor = (cell: Cell) => {
    if (viewMode === 'voltage') {
      if (cell.faultState === 'OVERVOLTAGE') return 'bg-red-500 text-slate-950 font-bold';
      if (cell.faultState === 'UNDERVOLTAGE') return 'bg-amber-500 text-slate-950 font-bold';
      const pct = (cell.voltage - minCellVoltage) / (maxCellVoltage - minCellVoltage || 1);
      if (pct > 0.8) return 'bg-emerald-500/90 text-slate-950';
      if (pct > 0.4) return 'bg-emerald-600/70 text-slate-100';
      return 'bg-emerald-800/50 text-slate-200';
    } else if (viewMode === 'temperature') {
      if (cell.temperatureC > 45) return 'bg-red-500 text-slate-950 font-bold animate-pulse';
      if (cell.temperatureC > 38) return 'bg-orange-500 text-slate-950 font-bold';
      if (cell.temperatureC > 32) return 'bg-yellow-500 text-slate-950';
      return 'bg-blue-600/70 text-slate-100';
    } else {
      if (cell.soh > 95) return 'bg-emerald-500/90 text-slate-950';
      if (cell.soh > 90) return 'bg-cyan-600/80 text-slate-100';
      return 'bg-amber-600/80 text-slate-100';
    }
  };

  return (
    <div className="space-y-6">
      {/* Pack Selection Header Bar */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <Zap className="w-5 h-5 text-emerald-400" />
          <div>
            <label className="text-xs text-slate-400 block font-medium">Select Active Battery Pack</label>
            <select
              value={currentPack.id}
              onChange={(e) => {
                onSelectPack(e.target.value);
                const nextPack = packs.find(p => p.id === e.target.value);
                if (nextPack) {
                  setSelectedCell(nextPack.modules[0]?.cells[0] || null);
                }
              }}
              className="bg-slate-950 border border-slate-700 text-slate-100 font-mono font-bold text-sm px-3 py-1.5 rounded focus:outline-none focus:border-emerald-500 mt-0.5"
            >
              {packs.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.packSerial} ({p.chemistry} • {p.modelName})
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="flex items-center space-x-4 text-xs font-mono">
          <div className="text-right">
            <span className="text-slate-400 block text-[10px]">Pack Location</span>
            <span className="text-slate-200 font-bold">{currentPack.location}</span>
          </div>
          <div className="text-right border-l border-slate-800 pl-4">
            <span className="text-slate-400 block text-[10px]">Firmware Version</span>
            <span className="text-emerald-400 font-bold">{currentPack.firmwareVersion}</span>
          </div>
          <div className="text-right border-l border-slate-800 pl-4">
            <span className="text-slate-400 block text-[10px]">Chemistry</span>
            <span className="text-cyan-400 font-bold">{currentPack.chemistry}</span>
          </div>
        </div>
      </div>

      {/* Fast Current State Projection Card */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg space-y-3">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <h2 className="text-sm font-bold text-slate-100 flex items-center space-x-2">
            <Activity className="w-4 h-4 text-emerald-400" />
            <span>Fast Projection State ({currentPack.packSerial})</span>
          </h2>
          <span className="text-xs text-slate-400 font-mono">
            Updated: <span className="text-emerald-400">Just Now (Real-time stream)</span>
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3 font-mono">
          <div className="bg-slate-950/70 p-2.5 rounded border border-slate-800">
            <div className="text-[10px] text-slate-400">SOC</div>
            <div className="text-lg font-bold text-emerald-400">{currentPack.soc}%</div>
          </div>

          <div className="bg-slate-950/70 p-2.5 rounded border border-slate-800">
            <div className="text-[10px] text-slate-400">SOH</div>
            <div className="text-lg font-bold text-cyan-400">{currentPack.soh}%</div>
          </div>

          <div className="bg-slate-950/70 p-2.5 rounded border border-slate-800">
            <div className="text-[10px] text-slate-400">Voltage</div>
            <div className="text-lg font-bold text-slate-100">{currentPack.voltage} V</div>
          </div>

          <div className="bg-slate-950/70 p-2.5 rounded border border-slate-800">
            <div className="text-[10px] text-slate-400">Current</div>
            <div className={`text-lg font-bold ${currentPack.current >= 0 ? 'text-emerald-400' : 'text-amber-400'}`}>
              {currentPack.current} A
            </div>
          </div>

          <div className="bg-slate-950/70 p-2.5 rounded border border-slate-800">
            <div className="text-[10px] text-slate-400">Power</div>
            <div className="text-lg font-bold text-slate-100">{currentPack.powerKW} kW</div>
          </div>

          <div className="bg-slate-950/70 p-2.5 rounded border border-slate-800">
            <div className="text-[10px] text-slate-400">Temp Avg / Max</div>
            <div className="text-lg font-bold text-orange-400">
              {currentPack.temperatureAvgC}° / {currentPack.temperatureMaxC}°C
            </div>
          </div>

          <div className="bg-slate-950/70 p-2.5 rounded border border-slate-800">
            <div className="text-[10px] text-slate-400">Cell Delta</div>
            <div className={`text-lg font-bold ${currentPack.cellDeltaMV > 30 ? 'text-amber-400' : 'text-emerald-400'}`}>
              {currentPack.cellDeltaMV} mV
            </div>
          </div>

          <div className="bg-slate-950/70 p-2.5 rounded border border-slate-800">
            <div className="text-[10px] text-slate-400">Resistance Avg</div>
            <div className="text-lg font-bold text-slate-100">{currentPack.internalResistanceAvgmOhm} mΩ</div>
          </div>
        </div>
      </div>

      {/* Module & Cell Heatmap Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 p-4 rounded-lg space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-slate-100 flex items-center space-x-2">
              <Cpu className="w-4 h-4 text-emerald-400" />
              <span>Cell Matrix Grid ({allCells.length} Individual Cells Monitored)</span>
            </h3>

            {/* View Mode Toggle */}
            <div className="flex items-center bg-slate-950 border border-slate-800 rounded p-0.5 text-xs">
              <button
                onClick={() => setViewMode('voltage')}
                className={`px-2.5 py-1 rounded transition-colors font-medium ${
                  viewMode === 'voltage' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Voltage
              </button>
              <button
                onClick={() => setViewMode('temperature')}
                className={`px-2.5 py-1 rounded transition-colors font-medium ${
                  viewMode === 'temperature' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Temperature
              </button>
              <button
                onClick={() => setViewMode('soh')}
                className={`px-2.5 py-1 rounded transition-colors font-medium ${
                  viewMode === 'soh' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                SOH
              </button>
            </div>
          </div>

          {/* Module-by-Module Cell Matrix */}
          <div className="space-y-4">
            {currentPack.modules.map((mod) => (
              <div key={mod.id} className="bg-slate-950/60 border border-slate-800/80 p-3 rounded-lg space-y-2">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="font-bold text-slate-200 flex items-center space-x-2">
                    <ChevronRight className="w-3.5 h-3.5 text-emerald-400" />
                    <span>{mod.name}</span>
                  </span>
                  <span className="text-slate-400">
                    Voltage: <span className="text-slate-200">{mod.voltage}V</span> • Max Temp:{' '}
                    <span className="text-orange-400">{mod.temperatureMax}°C</span>
                  </span>
                </div>

                {/* Cells Grid */}
                <div className="grid grid-cols-6 sm:grid-cols-12 gap-1.5">
                  {mod.cells.map((cell) => {
                    const isSelected = selectedCell?.id === cell.id;
                    const bgClass = getCellBgColor(cell);

                    return (
                      <button
                        key={cell.id}
                        onClick={() => setSelectedCell(cell)}
                        className={`p-1.5 rounded text-[10px] font-mono transition-all flex flex-col items-center justify-center border ${bgClass} ${
                          isSelected
                            ? 'ring-2 ring-white border-white scale-105 z-10 shadow-lg'
                            : 'border-transparent hover:scale-105'
                        }`}
                      >
                        <span className="opacity-80 font-semibold">#{cell.cellIndex}</span>
                        <span className="font-bold">
                          {viewMode === 'voltage'
                            ? `${cell.voltage}V`
                            : viewMode === 'temperature'
                            ? `${cell.temperatureC}°`
                            : `${cell.soh}%`}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Selected Cell Inspector & Equalization Panel */}
        <div className="space-y-4">
          <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg space-y-4">
            <h3 className="text-sm font-bold text-slate-100 flex items-center justify-between border-b border-slate-800 pb-2">
              <span>Selected Cell Detail</span>
              {selectedCell && (
                <span className="text-xs bg-slate-950 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded font-mono">
                  {selectedCell.cellCode}
                </span>
              )}
            </h3>

            {selectedCell ? (
              <div className="space-y-3 font-mono text-xs">
                <div className="grid grid-cols-2 gap-2">
                  <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Cell Voltage</span>
                    <span className="text-base font-bold text-slate-100">{selectedCell.voltage} V</span>
                  </div>

                  <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Temperature</span>
                    <span className={`text-base font-bold ${selectedCell.temperatureC > 40 ? 'text-red-400' : 'text-orange-400'}`}>
                      {selectedCell.temperatureC} °C
                    </span>
                  </div>

                  <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Internal Resistance</span>
                    <span className="text-base font-bold text-cyan-400">{selectedCell.internalResistancemOhm} mΩ</span>
                  </div>

                  <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
                    <span className="text-[10px] text-slate-400 block">Cell SOH</span>
                    <span className="text-base font-bold text-emerald-400">{selectedCell.soh}%</span>
                  </div>
                </div>

                <div className="bg-slate-950 p-3 rounded border border-slate-800 space-y-2">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Balancing State:</span>
                    <span
                      className={`font-bold ${
                        selectedCell.balancingState !== 'IDLE' ? 'text-amber-400' : 'text-slate-300'
                      }`}
                    >
                      {selectedCell.balancingState}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Balancing Current:</span>
                    <span className="text-slate-200">{selectedCell.balancingCurrentmA} mA</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Fault State:</span>
                    <span
                      className={`font-bold ${
                        selectedCell.faultState !== 'HEALTHY' ? 'text-red-400' : 'text-emerald-400'
                      }`}
                    >
                      {selectedCell.faultState}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Cycle Count:</span>
                    <span className="text-slate-200">{selectedCell.cycleCount} cycles</span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-xs text-slate-400 italic">Click any cell in the matrix to view telemetry.</div>
            )}
          </div>
        </div>
      </div>

      {/* Real-time Telemetry History Chart */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg space-y-3">
        <h3 className="text-sm font-bold text-slate-100 flex items-center justify-between">
          <span className="flex items-center space-x-2">
            <TrendingUp className="w-4 h-4 text-emerald-400" />
            <span>High-Frequency Telemetry Stream ({currentPack.packSerial})</span>
          </span>
          <span className="text-xs text-slate-400 font-mono">Voltage (V) & Current (A)</span>
        </h3>

        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={telemetryHistory}>
              <defs>
                <linearGradient id="voltageGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                </linearGradient>
                <linearGradient id="currentGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#06b6d4" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="timestamp" stroke="#64748b" tickFormatter={(ts) => ts.slice(11, 19)} />
              <YAxis yAxisId="left" stroke="#10b981" domain={['auto', 'auto']} />
              <YAxis yAxisId="right" orientation="right" stroke="#06b6d4" domain={['auto', 'auto']} />
              <Tooltip
                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '0.375rem', color: '#f8fafc' }}
              />
              <Area yAxisId="left" type="monotone" dataKey="voltage" name="Voltage (V)" stroke="#10b981" fillOpacity={1} fill="url(#voltageGrad)" />
              <Area yAxisId="right" type="monotone" dataKey="current" name="Current (A)" stroke="#06b6d4" fillOpacity={1} fill="url(#currentGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
