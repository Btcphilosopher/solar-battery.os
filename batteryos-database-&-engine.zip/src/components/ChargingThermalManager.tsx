import React from 'react';
import { ChargingSession, BatteryPack } from '../types';
import {
  Flame,
  Zap,
  Activity,
  CheckCircle2,
  TrendingUp,
  Thermometer,
  Wind
} from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid
} from 'recharts';

interface ChargingThermalManagerProps {
  currentPack: BatteryPack;
}

export const ChargingThermalManager: React.FC<ChargingThermalManagerProps> = ({ currentPack }) => {
  // Mock profile curve for CC-CV charging
  const profileData = [
    { timeMin: 0, currentA: 180, voltageV: 360, tempC: 25, socPct: 20 },
    { timeMin: 10, currentA: 180, voltageV: 372, tempC: 28, socPct: 35 },
    { timeMin: 20, currentA: 180, voltageV: 388, tempC: 32, socPct: 50 },
    { timeMin: 30, currentA: 160, voltageV: 396, tempC: 35, socPct: 68 },
    { timeMin: 40, currentA: 110, voltageV: 402, tempC: 37, socPct: 82 },
    { timeMin: 50, currentA: 45, voltageV: 405, tempC: 36, socPct: 92 },
    { timeMin: 60, currentA: 12, voltageV: 408, tempC: 33, socPct: 98 }
  ];

  return (
    <div className="space-y-6">
      {/* Thermal & Coolant System Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 font-mono">
        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Max Thermal Gradient</span>
            <Flame className="w-4 h-4 text-orange-400" />
          </div>
          <div className="text-xl font-bold text-slate-100 mt-1">2.4 °C</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Cell-to-Cell Delta</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Coolant Inlet Temp</span>
            <Thermometer className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-xl font-bold text-cyan-400 mt-1">22.8 °C</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Outlet: 26.1 °C</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Coolant Flow Rate</span>
            <Wind className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-xl font-bold text-slate-100 mt-1">18.5 LPM</div>
          <div className="text-[11px] text-emerald-400 mt-0.5">Active Pump Active</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-3.5 rounded-lg">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Cell Balancing Delta</span>
            <Zap className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-xl font-bold text-emerald-400 mt-1">{currentPack.cellDeltaMV} mV</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Threshold: 15.0 mV</div>
        </div>
      </div>

      {/* Charging Profile Curve Chart */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg space-y-3">
        <h3 className="text-sm font-bold text-slate-100 flex items-center justify-between">
          <span className="flex items-center space-x-2">
            <Zap className="w-4 h-4 text-emerald-400" />
            <span>Fast DC 350kW Charging Session Profile (CC-CV Transition)</span>
          </span>
          <span className="text-xs text-slate-400 font-mono">Pack: {currentPack.packSerial}</span>
        </h3>

        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={profileData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
              <XAxis dataKey="timeMin" stroke="#64748b" label={{ value: 'Duration (Minutes)', position: 'insideBottom', offset: -5, fill: '#64748b', fontSize: 10 }} />
              <YAxis yAxisId="left" stroke="#10b981" />
              <YAxis yAxisId="right" orientation="right" stroke="#f97316" />
              <Tooltip
                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '0.375rem', color: '#f8fafc' }}
              />
              <Line yAxisId="left" type="monotone" dataKey="currentA" name="Current (A)" stroke="#10b981" strokeWidth={2} />
              <Line yAxisId="left" type="monotone" dataKey="voltageV" name="Voltage (V)" stroke="#06b6d4" strokeWidth={2} />
              <Line yAxisId="right" type="monotone" dataKey="tempC" name="Temp (°C)" stroke="#f97316" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Recent Charging Logs Table */}
      <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg space-y-3">
        <h3 className="text-sm font-bold text-slate-100 border-b border-slate-800 pb-2">
          Historical Charging & Discharging Sessions
        </h3>

        <div className="overflow-x-auto text-xs font-mono">
          <table className="w-full text-left text-slate-300">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px]">
              <tr>
                <th className="p-2.5">Session ID</th>
                <th className="p-2.5">Charger Type</th>
                <th className="p-2.5">Start / End SOC</th>
                <th className="p-2.5">Energy Delivered</th>
                <th className="p-2.5">Max Current</th>
                <th className="p-2.5">Max Temp</th>
                <th className="p-2.5">Fast Charge Exp.</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              <tr className="hover:bg-slate-800/50">
                <td className="p-2.5 text-slate-100 font-bold">CHG-2026-0814-01</td>
                <td className="p-2.5 text-cyan-400">FAST_DC_350KW</td>
                <td className="p-2.5">20% ➔ 98%</td>
                <td className="p-2.5 text-emerald-400 font-bold">312.4 kWh</td>
                <td className="p-2.5">180 A</td>
                <td className="p-2.5 text-orange-400">37.0 °C</td>
                <td className="p-2.5 text-slate-300">12.4%</td>
              </tr>
              <tr className="hover:bg-slate-800/50">
                <td className="p-2.5 text-slate-100 font-bold">CHG-2026-0813-04</td>
                <td className="p-2.5 text-slate-300">SOLAR_DC_GRID</td>
                <td className="p-2.5">45% ➔ 95%</td>
                <td className="p-2.5 text-emerald-400 font-bold">185.0 kWh</td>
                <td className="p-2.5">85 A</td>
                <td className="p-2.5 text-slate-300">29.5 °C</td>
                <td className="p-2.5 text-slate-300">0.0%</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
