/**
 * BatteryOS - High Performance Battery Management & Database Types
 */

export type ChemistryType = 'LFP' | 'NMC' | 'NCA' | 'Sodium-Ion' | 'Solid-State' | 'Li-Po';

export type SystemStatus = 'NORMAL' | 'WARNING' | 'CRITICAL' | 'MAINTENANCE' | 'OFFLINE';

export type FaultSeverity = 'INFO' | 'WARNING' | 'CRITICAL' | 'EMERGENCY';

export type FaultStatus = 'ACTIVE' | 'ACKNOWLEDGED' | 'RESOLVED' | 'MUTED';

export type SOCAlgorithm = 'SOC_COULOMB_COUNTING' | 'SOC_MODEL_ESTIMATE' | 'SOC_FUSED_ESTIMATE' | 'SOC_KALMAN';

export interface BatteryChemistry {
  id: string;
  name: ChemistryType;
  description: string;
  nominalCellVoltage: number; // Volts
  maxCellVoltage: number;
  minCellVoltage: number;
  maxCChargeRate: number;
  maxCDischargeRate: number;
  optimalTempMin: number; // Celsius
  optimalTempMax: number;
  maxSafeTemp: number;
  energyDensityWhKg: number;
  typicalCycleLife: number; // cycles to 80% SOH
}

export interface BatteryManufacturer {
  id: string;
  name: string;
  country: string;
  website: string;
}

export interface BatteryModel {
  id: string;
  manufacturerId: string;
  manufacturerName: string;
  modelCode: string;
  chemistry: ChemistryType;
  nominalVoltage: number; // V
  nominalCapacityAh: number; // Ah
  nominalEnergyKWh: number; // kWh
  maxContinuousCurrentA: number; // A
  maxPeakCurrentA: number; // A
  maxVoltage: number;
  minVoltage: number;
  maxTemperatureC: number;
  minTemperatureC: number;
  cellsSeries: number;
  cellsParallel: number;
  totalCells: number;
}

export interface Cell {
  id: string;
  uuid: string;
  moduleId: string;
  packId: string;
  cellIndex: number; // 1 to totalCells
  cellCode: string;
  voltage: number; // Volts
  temperatureC: number; // Celsius
  internalResistancemOhm: number; // mOhm
  cycleCount: number;
  soc: number; // 0-100%
  soh: number; // 0-100%
  balancingState: 'IDLE' | 'PASSIVE_BALANCING' | 'ACTIVE_BALANCING';
  balancingCurrentmA: number;
  faultState: 'HEALTHY' | 'OVERVOLTAGE' | 'UNDERVOLTAGE' | 'OVERTEMP' | 'HIGH_RESISTANCE';
  lastUpdated: string;
}

export interface Module {
  id: string;
  uuid: string;
  packId: string;
  moduleIndex: number;
  name: string;
  cellCount: number;
  voltage: number;
  temperatureAvg: number;
  temperatureMax: number;
  cells: Cell[];
}

export interface BatteryPack {
  id: string;
  uuid: string;
  systemId: string;
  packSerial: string;
  modelId: string;
  modelName: string;
  chemistry: ChemistryType;
  manufacturerName: string;
  installedCapacityAh: number;
  nominalVoltage: number;
  status: SystemStatus;
  location: string;
  vehicleOrApp: string;
  productionDate: string;
  installationDate: string;
  firmwareVersion: string;

  // Real-time Current State Projection
  soc: number; // %
  soh: number; // %
  voltage: number; // V
  current: number; // A (positive charging, negative discharging)
  powerKW: number; // kW
  energyKWhRemaining: number;
  temperatureAvgC: number;
  temperatureMaxC: number;
  cellDeltaMV: number; // Cell voltage spread in mV
  internalResistanceAvgmOhm: number;
  cycleCount: number;
  activeFaultCount: number;

  modules: Module[];
}

export interface BatterySystem {
  id: string;
  uuid: string;
  name: string;
  systemType: 'GRID_STORAGE' | 'EV_FLEET' | 'COMMERCIAL_ESS' | 'MICROGRID';
  location: string;
  totalPacks: number;
  totalCapacityMWh: number;
  status: SystemStatus;
  avgSoh: number;
  packs: BatteryPack[];
}

export interface TelemetryReading {
  id?: string;
  uuid?: string;
  batteryPackId: string;
  timestamp: string;
  voltage: number;
  current: number;
  powerKW: number;
  soc: number;
  soh: number;
  tempAvg: number;
  tempMax: number;
  cellSpreadMV: number;
  energyDeliveredKWh: number;
  chargingState: 'DISCHARGING' | 'CHARGING_CC' | 'CHARGING_CV' | 'IDLE' | 'BALANCING';
  validationPassed: boolean;
  validationFlags: string[];
}

export interface DataQualityEvent {
  id: string;
  timestamp: string;
  batteryPackId: string;
  eventType: 'MISSING_VALUE' | 'IMPOSSIBLE_VOLTAGE' | 'IMPOSSIBLE_TEMP' | 'SENSOR_SPIKE' | 'DUPLICATE_TIMESTAMP' | 'OUT_OF_ORDER' | 'SENSOR_DISCONNECTED';
  rawPayload: string;
  actionTaken: 'FLAGGED' | 'INTERPOLATED' | 'DISCARDED_TO_QUARANTINE';
  details: string;
}

export interface SOCEstimate {
  timestamp: string;
  algorithm: SOCAlgorithm;
  estimatePct: number;
  confidencePct: number;
  inputVersion: string;
  modelVersion: string;
}

export interface SOHEstimate {
  timestamp: string;
  sohPct: number;
  capacityAhEstimate: number;
  internalResistancemOhmEstimate: number;
  cycleCount: number;
  modelVersion: string;
  confidencePct: number;
}

export interface RULPrediction {
  timestamp: string;
  batteryPackId: string;
  currentSohPct: number;
  predictedRemainingCycles: number;
  predictedRemainingDays: number;
  confidencePct: number;
  modelVersion: string;
  projections: {
    cycles: number;
    predictedSohPct: number;
    lowerBoundPct: number;
    upperBoundPct: number;
  }[];
}

export interface ChargingSession {
  id: string;
  uuid: string;
  batteryPackId: string;
  startTime: string;
  endTime?: string;
  durationMinutes: number;
  energyDeliveredKWh: number;
  startSocPct: number;
  endSocPct: number;
  maxCurrentA: number;
  maxTempC: number;
  chargerType: 'FAST_DC_350KW' | 'STANDARD_AC_22KW' | 'REGEN_BRAKING' | 'SOLAR_DC';
  location: string;
  fastChargeExposurePct: number;
  profileCurve: { timeMin: number; currentA: number; voltageV: number; tempC: number; socPct: number }[];
}

export interface Fault {
  id: string;
  uuid: string;
  batteryPackId: string;
  batteryPackSerial: string;
  code: 'CELL_OVERVOLTAGE' | 'CELL_UNDERVOLTAGE' | 'OVER_TEMPERATURE' | 'OVER_CURRENT' | 'CELL_IMBALANCE' | 'SENSOR_FAILURE' | 'COMMUNICATION_FAILURE' | 'THERMAL_ANOMALY';
  severity: FaultSeverity;
  firstOccurrence: string;
  lastOccurrence: string;
  status: FaultStatus;
  moduleId?: string;
  cellId?: string;
  cellIndex?: number;
  evidence: string;
  resolutionNotes?: string;
}

export interface AuditEvent {
  id: string;
  uuid: string;
  timestamp: string;
  batteryPackId?: string;
  eventType: 'BATTERY_CONNECTED' | 'BATTERY_STARTED' | 'CHARGING_STARTED' | 'CHARGING_COMPLETED' | 'FAULT_DETECTED' | 'FAULT_CLEARED' | 'FIRMWARE_UPDATED' | 'CELL_REPLACED' | 'PACK_SERVICED' | 'SAFETY_CONFIG_UPDATED';
  actor: string;
  details: string;
  previousState?: string;
  newState?: string;
}

export interface SafetyConfiguration {
  id: string;
  version: number;
  createdAt: string;
  batteryModelId: string;
  modelCode: string;
  voltageUpperLimitV: number;
  voltageLowerLimitV: number;
  currentMaxChargeA: number;
  currentMaxDischargeA: number;
  tempUpperLimitC: number;
  tempLowerLimitC: number;
  maxCellDeltaMV: number;
  balancingThresholdMV: number;
  description: string;
}

export interface FleetSummary {
  totalSystems: number;
  totalPacks: number;
  totalCells: number;
  totalCapacityMWh: number;
  activePacks: number;
  avgSohPct: number;
  avgSocPct: number;
  totalTelemetryRecordsToday: number;
  ingestionRatePerSec: number;
  activeFaultsCount: number;
  chemistriesBreakdown: { name: ChemistryType; count: number; totalMWh: number }[];
  healthDistribution: { rating: string; count: number; percentage: number }[];
}

export interface RustPipelineStatus {
  bufferSize: number;
  maxBufferSize: number;
  flushIntervalMs: number;
  processedPerSec: number;
  validationDropRatePct: number;
  activeThreads: number;
  pipelineSteps: {
    name: 'TelemetryReceiver' | 'TelemetryValidator' | 'TelemetryProcessor' | 'DatabaseWriter' | 'EventProcessor' | 'StateEstimator';
    status: 'ACTIVE' | 'IDLE' | 'BUSY';
    throughputPerSec: number;
    latencyMs: number;
  }[];
}

export interface BenchmarkMetrics {
  batchIngestionOpsSec: number;
  batchFlushLatencyMs: number;
  latestStateQueryLatencyMs: number;
  timescaleHypertableQueryMs: number;
  fleetAggregationLatencyMs: number;
  rulInferenceLatencyMs: number;
}
