/**
 * BatteryOS - In-Memory Core Engine, Rust Telemetry Pipeline & Fleet State Manager
 */

import {
  BatterySystem,
  BatteryPack,
  Module,
  Cell,
  TelemetryReading,
  DataQualityEvent,
  Fault,
  AuditEvent,
  SafetyConfiguration,
  FleetSummary,
  RustPipelineStatus,
  BenchmarkMetrics,
  ChemistryType,
  RULPrediction
} from '../types.js';

import { MIGRATIONS } from './sqlSchemaDDL.js';
import { R_ANALYTICS_PACKAGE_DOCS } from './rAnalyticsCode.js';

class BatteryEngineService {
  private systems: BatterySystem[] = [];
  private packsMap: Map<string, BatteryPack> = new Map();
  private telemetryHistory: Map<string, TelemetryReading[]> = new Map();
  private dataQualityLogs: DataQualityEvent[] = [];
  private faults: Fault[] = [];
  private auditEvents: AuditEvent[] = [];
  private safetyConfigs: SafetyConfiguration[] = [];

  // Rust Ingestion Pipeline Buffer & State
  private telemetryBuffer: TelemetryReading[] = [];
  private totalTelemetryIngestedToday = 142850;
  private bufferSize = 42;
  private maxBufferSize = 500;
  private flushIntervalMs = 100;
  private validationDropRatePct = 0.04;
  private pipelineThroughputSec = 48500;

  constructor() {
    this.seedInitialFleet();
    this.seedDefaultSafetyConfigs();
    this.seedInitialAuditLog();
    this.seedInitialFaults();
    this.startLiveTelemetrySimulator();
  }

  private seedInitialFleet() {
    const chemistries: ChemistryType[] = ['LFP', 'NMC', 'Sodium-Ion', 'NCA'];

    // System 1: European Grid Energy Storage Project Alpha
    const pack1 = this.createPack('PACK-LFP-800V-001', 'LFP', 'CATL-ESS-500K', 'CATL', 'Grid Storage Alpha', 'Frankfurt Grid Station', 400, 800, 94.8, 78.4, 392.4, 18.2, 31.4, 18, 12, 1420);
    const pack2 = this.createPack('PACK-NMC-400V-002', 'NMC', 'LG-CHEM-RES-100', 'LG Energy', 'Grid Storage Alpha', 'Frankfurt Grid Station', 250, 400, 91.2, 64.1, 388.1, 45.0, 34.8, 32, 14, 2180);
    
    const sys1: BatterySystem = {
      id: 'sys-001',
      uuid: 'a1b2c3d4-e5f6-7890-abcd-ef1234567890',
      name: 'Frankfurt Central Grid ESS Alpha',
      systemType: 'GRID_STORAGE',
      location: 'Frankfurt, Germany',
      totalPacks: 2,
      totalCapacityMWh: 1.2,
      status: 'NORMAL',
      avgSoh: 93.0,
      packs: [pack1, pack2]
    };

    // System 2: EV Commercial Bus Fleet North
    const pack3 = this.createPack('PACK-NMC-800V-003', 'NMC', 'BYD-BUS-PACK-800', 'BYD', 'Commercial EV Fleet', 'Depot North London', 300, 800, 88.4, 82.5, 784.2, -120.4, 38.2, 45, 22, 3110);
    const pack4 = this.createPack('PACK-SODIUM-400V-004', 'Sodium-Ion', 'CATL-NA-BUFFER', 'HiNa Battery', 'Commercial EV Fleet', 'Depot North London', 180, 400, 97.2, 55.0, 390.0, 0.0, 26.5, 12, 8, 480);

    const sys2: BatterySystem = {
      id: 'sys-002',
      uuid: 'b2c3d4e5-f6a7-8901-bcde-f12345678901',
      name: 'London Metropolitan Bus Depot ESS',
      systemType: 'EV_FLEET',
      location: 'London, United Kingdom',
      totalPacks: 2,
      totalCapacityMWh: 0.85,
      status: 'WARNING',
      avgSoh: 92.8,
      packs: [pack3, pack4]
    };

    // System 3: Microgrid Solar Buffer California
    const pack5 = this.createPack('PACK-LFP-600V-005', 'LFP', 'TESLA-MEGAPACK-2', 'Tesla Energy', 'Solar Buffer West', 'Mojave Microgrid', 600, 600, 96.1, 91.0, 612.0, 185.0, 29.8, 15, 10, 890);

    const sys3: BatterySystem = {
      id: 'sys-003',
      uuid: 'c3d4e5f6-a7b8-9012-cdef-123456789012',
      name: 'Mojave Solar Microgrid Station',
      systemType: 'MICROGRID',
      location: 'California, USA',
      totalPacks: 1,
      totalCapacityMWh: 2.4,
      status: 'NORMAL',
      avgSoh: 96.1,
      packs: [pack5]
    };

    this.systems = [sys1, sys2, sys3];

    for (const sys of this.systems) {
      for (const pack of sys.packs) {
        this.packsMap.set(pack.id, pack);
        this.seedTelemetryHistory(pack);
      }
    }
  }

  private createPack(
    serial: string,
    chemistry: ChemistryType,
    modelName: string,
    manufacturer: string,
    vehicleOrApp: string,
    location: string,
    capacityAh: number,
    nominalVoltage: number,
    soh: number,
    soc: number,
    voltage: number,
    current: number,
    temp: number,
    cellDeltaMV: number,
    modulesCount: number,
    cycleCount: number
  ): BatteryPack {
    const packId = `pack-${serial.toLowerCase().replace(/[^a-z0-9]/g, '')}`;
    const packUuid = `f81d4fae-7dec-11d0-a765-00a0c91e6${Math.floor(1000 + Math.random() * 9000)}`;

    const modules: Module[] = [];
    let cellIndexCounter = 1;

    for (let m = 1; m <= modulesCount; m++) {
      const cells: Cell[] = [];
      const cellsInModule = 12;
      for (let c = 1; c <= cellsInModule; c++) {
        // Introduce small voltage variance per cell to simulate real telemetry
        const jitter = (Math.random() - 0.5) * (cellDeltaMV / 1000);
        const cellVoltage = Number((nominalVoltage / (modulesCount * cellsInModule) + jitter).toFixed(3));
        const cellTemp = Number((temp + (Math.random() - 0.5) * 2).toFixed(1));
        const isHotCell = c === 4 && m === 2 && packId.includes('003'); // Hotspot simulation

        cells.push({
          id: `cell-${packId}-${m}-${c}`,
          uuid: `123e4567-e89b-12d3-a456-${cellIndexCounter.toString().padStart(12, '0')}`,
          moduleId: `mod-${packId}-${m}`,
          packId,
          cellIndex: cellIndexCounter,
          cellCode: `C-${m.toString().padStart(2, '0')}-${c.toString().padStart(2, '0')}`,
          voltage: cellVoltage,
          temperatureC: isHotCell ? 48.5 : cellTemp,
          internalResistancemOhm: Number((0.85 + (100 - soh) * 0.015 + Math.random() * 0.05).toFixed(3)),
          cycleCount,
          soc,
          soh,
          balancingState: cellDeltaMV > 30 && c % 3 === 0 ? 'PASSIVE_BALANCING' : 'IDLE',
          balancingCurrentmA: cellDeltaMV > 30 && c % 3 === 0 ? 120 : 0,
          faultState: isHotCell ? 'OVERTEMP' : 'HEALTHY',
          lastUpdated: new Date().toISOString()
        });
        cellIndexCounter++;
      }

      modules.push({
        id: `mod-${packId}-${m}`,
        uuid: `223e4567-e89b-12d3-a456-${m.toString().padStart(12, '0')}`,
        packId,
        moduleIndex: m,
        name: `Module M${m}`,
        cellCount: cellsInModule,
        voltage: Number((voltage / modulesCount).toFixed(2)),
        temperatureAvg: temp,
        temperatureMax: Math.max(...cells.map(c => c.temperatureC)),
        cells
      });
    }

    const powerKW = Number(((voltage * current) / 1000).toFixed(2));

    return {
      id: packId,
      uuid: packUuid,
      systemId: 'sys-001',
      packSerial: serial,
      modelId: `model-${chemistry.toLowerCase()}`,
      modelName,
      chemistry,
      manufacturerName: manufacturer,
      installedCapacityAh: capacityAh,
      nominalVoltage,
      status: soh < 90 || cellDeltaMV > 40 ? 'WARNING' : 'NORMAL',
      location,
      vehicleOrApp,
      productionDate: '2024-03-15',
      installationDate: '2024-05-01',
      firmwareVersion: 'v3.8.4-rust',
      soc,
      soh,
      voltage,
      current,
      powerKW,
      energyKWhRemaining: Number(((capacityAh * voltage * (soc / 100)) / 1000).toFixed(2)),
      temperatureAvgC: temp,
      temperatureMaxC: Number((temp + 4.2).toFixed(1)),
      cellDeltaMV,
      internalResistanceAvgmOhm: Number((0.88 + (100 - soh) * 0.012).toFixed(3)),
      cycleCount,
      activeFaultCount: cellDeltaMV > 40 ? 1 : 0,
      modules
    };
  }

  private seedTelemetryHistory(pack: BatteryPack) {
    const readings: TelemetryReading[] = [];
    const now = Date.now();
    for (let i = 60; i >= 0; i--) {
      const ts = new Date(now - i * 60 * 1000).toISOString();
      const noise = (Math.random() - 0.5) * 1.5;
      readings.push({
        batteryPackId: pack.id,
        timestamp: ts,
        voltage: Number((pack.voltage + noise * 0.5).toFixed(2)),
        current: Number((pack.current + noise * 2).toFixed(2)),
        powerKW: Number((((pack.voltage + noise) * (pack.current + noise * 2)) / 1000).toFixed(2)),
        soc: Number((pack.soc + (i * 0.05) % 3).toFixed(1)),
        soh: pack.soh,
        tempAvgC: Number((pack.temperatureAvgC + noise * 0.2).toFixed(1)),
        tempMaxC: Number((pack.temperatureMaxC + noise * 0.3).toFixed(1)),
        cellSpreadMV: pack.cellDeltaMV,
        energyDeliveredKWh: 142.8,
        chargingState: pack.current > 0 ? 'CHARGING_CC' : pack.current < 0 ? 'DISCHARGING' : 'IDLE',
        validationPassed: true,
        validationFlags: []
      });
    }
    this.telemetryHistory.set(pack.id, readings);
  }

  private seedDefaultSafetyConfigs() {
    this.safetyConfigs = [
      {
        id: 'cfg-001',
        version: 1,
        createdAt: '2024-01-10T00:00:00Z',
        batteryModelId: 'model-lfp',
        modelCode: 'CATL-ESS-500K',
        voltageUpperLimitV: 876.0,
        voltageLowerLimitV: 680.0,
        currentMaxChargeA: 350.0,
        currentMaxDischargeA: 500.0,
        tempUpperLimitC: 55.0,
        tempLowerLimitC: -10.0,
        maxCellDeltaMV: 50.0,
        balancingThresholdMV: 15.0,
        description: 'Initial Factory Safety Matrix Baseline'
      },
      {
        id: 'cfg-002',
        version: 2,
        createdAt: '2024-06-20T00:00:00Z',
        batteryModelId: 'model-nmc',
        modelCode: 'BYD-BUS-PACK-800',
        voltageUpperLimitV: 880.0,
        voltageLowerLimitV: 640.0,
        currentMaxChargeA: 400.0,
        currentMaxDischargeA: 600.0,
        tempUpperLimitC: 50.0,
        tempLowerLimitC: -15.0,
        maxCellDeltaMV: 40.0,
        balancingThresholdMV: 12.0,
        description: 'Updated Fast-Charge Peak Thermal Safety Threshold'
      }
    ];
  }

  private seedInitialAuditLog() {
    this.auditEvents = [
      {
        id: 'evt-001',
        uuid: '00000000-0000-0000-0000-000000000001',
        timestamp: new Date(Date.now() - 86400000 * 3).toISOString(),
        batteryPackId: 'pack-packnmc800v003',
        eventType: 'BATTERY_CONNECTED',
        actor: 'RustTelemetryDaemon',
        details: 'Pack initialized and connected to Rust Telemetry Pipeline via CAN-Bus socket.'
      },
      {
        id: 'evt-002',
        uuid: '00000000-0000-0000-0000-000000000002',
        timestamp: new Date(Date.now() - 86400000 * 2).toISOString(),
        batteryPackId: 'pack-packnmc800v003',
        eventType: 'FAULT_DETECTED',
        actor: 'TelemetryValidator',
        details: 'Thermal hotspot detected on Module M2 Cell 4 (48.5 C vs avg 38.2 C).'
      },
      {
        id: 'evt-003',
        uuid: '00000000-0000-0000-0000-000000000003',
        timestamp: new Date(Date.now() - 86400000 * 1).toISOString(),
        batteryPackId: 'pack-packlfp800v001',
        eventType: 'SAFETY_CONFIG_UPDATED',
        actor: 'SystemAdmin (admin@batteryos.io)',
        details: 'Updated max balancing threshold from 20mV to 15mV for high precision equalization.'
      }
    ];
  }

  private seedInitialFaults() {
    this.faults = [
      {
        id: 'flt-001',
        uuid: '777e4567-e89b-12d3-a456-426614174001',
        batteryPackId: 'pack-packnmc800v003',
        batteryPackSerial: 'PACK-NMC-800V-003',
        code: 'THERMAL_ANOMALY',
        severity: 'WARNING',
        firstOccurrence: new Date(Date.now() - 86400000 * 2).toISOString(),
        lastOccurrence: new Date().toISOString(),
        status: 'ACTIVE',
        moduleId: 'mod-pack-packnmc800v003-2',
        cellId: 'cell-pack-packnmc800v003-2-4',
        cellIndex: 16,
        evidence: 'Cell 16 temperature reading 48.5 C exceeds module mean 38.2 C by 10.3 C (Z-score: 3.42).'
      },
      {
        id: 'flt-002',
        uuid: '777e4567-e89b-12d3-a456-426614174002',
        batteryPackId: 'pack-packnmc400v002',
        batteryPackSerial: 'PACK-NMC-400V-002',
        code: 'CELL_IMBALANCE',
        severity: 'WARNING',
        firstOccurrence: new Date(Date.now() - 86400000 * 4).toISOString(),
        lastOccurrence: new Date(Date.now() - 3600000).toISOString(),
        status: 'ACKNOWLEDGED',
        evidence: 'Pack cell voltage spread delta 32 mV exceeds threshold 25 mV during CV charge phase.'
      }
    ];
  }

  private startLiveTelemetrySimulator() {
    setInterval(() => {
      this.totalTelemetryIngestedToday += Math.floor(100 + Math.random() * 50);
      this.bufferSize = Math.floor(20 + Math.random() * 60);

      // Simulate minor real-time fluctuations across packs
      for (const [id, pack] of this.packsMap.entries()) {
        const noiseV = (Math.random() - 0.5) * 0.4;
        const noiseI = (Math.random() - 0.5) * 1.2;
        pack.voltage = Number((pack.voltage + noiseV).toFixed(2));
        pack.current = Number((pack.current + noiseI).toFixed(2));
        pack.powerKW = Number(((pack.voltage * pack.current) / 1000).toFixed(2));

        // Add to history
        const list = this.telemetryHistory.get(id) || [];
        list.push({
          batteryPackId: pack.id,
          timestamp: new Date().toISOString(),
          voltage: pack.voltage,
          current: pack.current,
          powerKW: pack.powerKW,
          soc: pack.soc,
          soh: pack.soh,
          tempAvgC: pack.temperatureAvgC,
          tempMaxC: pack.temperatureMaxC,
          cellSpreadMV: pack.cellDeltaMV,
          energyDeliveredKWh: 142.8,
          chargingState: pack.current > 0 ? 'CHARGING_CC' : pack.current < 0 ? 'DISCHARGING' : 'IDLE',
          validationPassed: true,
          validationFlags: []
        });

        if (list.length > 100) {
          list.shift();
        }
      }
    }, 2000);
  }

  // API Methods
  public getFleetSummary(): FleetSummary {
    let totalCells = 0;
    let totalMWh = 0;

    for (const sys of this.systems) {
      totalMWh += sys.totalCapacityMWh;
      for (const pack of sys.packs) {
        for (const mod of pack.modules) {
          totalCells += mod.cellCount;
        }
      }
    }

    const chemistryCounts: Record<ChemistryType, { count: number; mwh: number }> = {
      'LFP': { count: 0, mwh: 0 },
      'NMC': { count: 0, mwh: 0 },
      'Sodium-Ion': { count: 0, mwh: 0 },
      'NCA': { count: 0, mwh: 0 },
      'Solid-State': { count: 0, mwh: 0 },
      'Li-Po': { count: 0, mwh: 0 }
    };

    for (const pack of this.packsMap.values()) {
      if (!chemistryCounts[pack.chemistry]) {
        chemistryCounts[pack.chemistry] = { count: 0, mwh: 0 };
      }
      chemistryCounts[pack.chemistry].count++;
      chemistryCounts[pack.chemistry].mwh += (pack.installedCapacityAh * pack.nominalVoltage) / 1000000;
    }

    const chemistriesBreakdown = Object.entries(chemistryCounts)
      .map(([name, data]) => ({ name: name as ChemistryType, count: data.count, totalMWh: Number(data.mwh.toFixed(2)) }))
      .filter(c => c.count > 0);

    return {
      totalSystems: this.systems.length,
      totalPacks: this.packsMap.size,
      totalCells,
      totalCapacityMWh: Number(totalMWh.toFixed(2)),
      activePacks: Array.from(this.packsMap.values()).filter(p => p.status !== 'OFFLINE').length,
      avgSohPct: Number((Array.from(this.packsMap.values()).reduce((a, b) => a + b.soh, 0) / this.packsMap.size).toFixed(1)),
      avgSocPct: Number((Array.from(this.packsMap.values()).reduce((a, b) => a + b.soc, 0) / this.packsMap.size).toFixed(1)),
      totalTelemetryRecordsToday: this.totalTelemetryIngestedToday,
      ingestionRatePerSec: this.pipelineThroughputSec,
      activeFaultsCount: this.faults.filter(f => f.status === 'ACTIVE').length,
      chemistriesBreakdown,
      healthDistribution: [
        { rating: 'Optimal (>95% SOH)', count: 3, percentage: 60.0 },
        { rating: 'Good (90-95% SOH)', count: 1, percentage: 20.0 },
        { rating: 'Degraded (80-90% SOH)', count: 1, percentage: 20.0 },
        { rating: 'Critical (<80% SOH)', count: 0, percentage: 0.0 }
      ]
    };
  }

  public getSystems(): BatterySystem[] {
    return this.systems;
  }

  public getPack(id: string): BatteryPack | undefined {
    return this.packsMap.get(id);
  }

  public getTelemetry(packId: string): TelemetryReading[] {
    return this.telemetryHistory.get(packId) || [];
  }

  public getFaults(packId?: string): Fault[] {
    if (packId) {
      return this.faults.filter(f => f.batteryPackId === packId);
    }
    return this.faults;
  }

  public getAuditEvents(): AuditEvent[] {
    return this.auditEvents;
  }

  public getSafetyConfigs(): SafetyConfiguration[] {
    return this.safetyConfigs;
  }

  public getRustPipelineStatus(): RustPipelineStatus {
    return {
      bufferSize: this.bufferSize,
      maxBufferSize: this.maxBufferSize,
      flushIntervalMs: this.flushIntervalMs,
      processedPerSec: this.pipelineThroughputSec,
      validationDropRatePct: this.validationDropRatePct,
      activeThreads: 16,
      pipelineSteps: [
        { name: 'TelemetryReceiver', status: 'ACTIVE', throughputPerSec: 52000, latencyMs: 0.2 },
        { name: 'TelemetryValidator', status: 'ACTIVE', throughputPerSec: 51200, latencyMs: 0.4 },
        { name: 'TelemetryProcessor', status: 'ACTIVE', throughputPerSec: 50800, latencyMs: 0.8 },
        { name: 'DatabaseWriter', status: 'BUSY', throughputPerSec: 49500, latencyMs: 2.1 },
        { name: 'EventProcessor', status: 'ACTIVE', throughputPerSec: 48500, latencyMs: 1.1 },
        { name: 'StateEstimator', status: 'ACTIVE', throughputPerSec: 48500, latencyMs: 1.5 }
      ]
    };
  }

  public getBenchmarkMetrics(): BenchmarkMetrics {
    return {
      batchIngestionOpsSec: 52400,
      batchFlushLatencyMs: 2.4,
      latestStateQueryLatencyMs: 0.8,
      timescaleHypertableQueryMs: 4.2,
      fleetAggregationLatencyMs: 12.1,
      rulInferenceLatencyMs: 18.5
    };
  }

  public getRULPrediction(packId: string): RULPrediction {
    const pack = this.packsMap.get(packId);
    const soh = pack ? pack.soh : 94.8;
    const cycles = pack ? pack.cycleCount : 1420;

    return {
      timestamp: new Date().toISOString(),
      batteryPackId: packId,
      currentSohPct: soh,
      predictedRemainingCycles: Math.round(1184 * (soh / 94.8)),
      predictedRemainingDays: Math.round((1184 * (soh / 94.8)) / 1.4),
      confidencePct: 87.0,
      modelVersion: 'v2.1-arrhenius-powerlaw',
      projections: [
        { cycles: cycles, predictedSohPct: soh, lowerBoundPct: soh, upperBoundPct: soh },
        { cycles: cycles + 300, predictedSohPct: Number((soh - 3.2).toFixed(1)), lowerBoundPct: Number((soh - 4.5).toFixed(1)), upperBoundPct: Number((soh - 2.1).toFixed(1)) },
        { cycles: cycles + 600, predictedSohPct: Number((soh - 6.8).toFixed(1)), lowerBoundPct: Number((soh - 8.9).toFixed(1)), upperBoundPct: Number((soh - 5.0).toFixed(1)) },
        { cycles: cycles + 900, predictedSohPct: Number((soh - 10.9).toFixed(1)), lowerBoundPct: Number((soh - 13.8).toFixed(1)), upperBoundPct: Number((soh - 8.2).toFixed(1)) },
        { cycles: cycles + 1200, predictedSohPct: Number((soh - 15.5).toFixed(1)), lowerBoundPct: Number((soh - 19.2).toFixed(1)), upperBoundPct: Number((soh - 12.1).toFixed(1)) },
        { cycles: cycles + 1500, predictedSohPct: Number((soh - 20.8).toFixed(1)), lowerBoundPct: Number((soh - 25.1).toFixed(1)), upperBoundPct: Number((soh - 16.5).toFixed(1)) }
      ]
    };
  }

  public ingesteBatchTelemetry(telemetryBatch: any[]) {
    let droppedCount = 0;
    for (const item of telemetryBatch) {
      // Validate bounds
      if (item.voltage > 1000 || item.voltage < 0 || item.tempAvg > 120 || item.tempAvg < -40) {
        droppedCount++;
        this.dataQualityLogs.unshift({
          id: `dq-${Date.now()}-${Math.random()}`,
          timestamp: new Date().toISOString(),
          batteryPackId: item.batteryPackId || 'pack-lfp-800v-001',
          eventType: item.voltage > 1000 ? 'IMPOSSIBLE_VOLTAGE' : 'IMPOSSIBLE_TEMP',
          rawPayload: JSON.stringify(item),
          actionTaken: 'FLAGGED',
          details: `Rejected telemetry: Voltage ${item.voltage}V, Temp ${item.tempAvg}C`
        });
      }
    }

    if (this.dataQualityLogs.length > 50) {
      this.dataQualityLogs = this.dataQualityLogs.slice(0, 50);
    }

    return {
      received: telemetryBatch.length,
      ingested: telemetryBatch.length - droppedCount,
      dropped: droppedCount,
      flushTimeMs: 2.1
    };
  }

  public getDataQualityLogs(): DataQualityEvent[] {
    return this.dataQualityLogs;
  }
}

export const engineService = new BatteryEngineService();
