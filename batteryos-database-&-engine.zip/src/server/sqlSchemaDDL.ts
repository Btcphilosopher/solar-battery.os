/**
 * BatteryOS - PostgreSQL & TimescaleDB Core DDL Schema & Migrations
 * Authoritative Database Architecture
 */

export interface SQLMigration {
  version: string;
  name: string;
  description: string;
  sql: string;
}

export const MIGRATIONS: SQLMigration[] = [
  {
    version: '001',
    name: '001_initial_schema',
    description: 'PostgreSQL extensions, UUID generation, core domains, database roles & baseline tables',
    sql: `-- ====================================================================
-- BATTERY OS MIGRATION 001: INITIAL SCHEMA & SECURITY ROLES
-- ====================================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_stat_statements";

-- Create Database Security Roles (Least Privilege Principle)
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'batteryos_read') THEN
        CREATE ROLE batteryos_read;
    END IF;
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'batteryos_write') THEN
        CREATE ROLE batteryos_write;
    END IF;
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'batteryos_analytics') THEN
        CREATE ROLE batteryos_analytics;
    END IF;
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'batteryos_admin') THEN
        CREATE ROLE batteryos_admin;
    END IF;
END $$;

-- Domain Definitions for Safe Type Verification
CREATE DOMAIN soc_percentage AS NUMERIC(5,2) CHECK (VALUE >= 0.00 AND VALUE <= 100.00);
CREATE DOMAIN soh_percentage AS NUMERIC(5,2) CHECK (VALUE >= 0.00 AND VALUE <= 100.00);
CREATE DOMAIN celsius_temp AS NUMERIC(5,2) CHECK (VALUE >= -50.00 AND VALUE <= 150.00);

-- Users & Authentication
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    role VARCHAR(50) NOT NULL CHECK (role IN ('ADMIN', 'ENGINEER', 'OPERATOR', 'ANALYST', 'READONLY')),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    last_login_at TIMESTAMPTZ
);

-- Audit Events Table (Immutable Log)
CREATE TABLE IF NOT EXISTS audit_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    timestamp TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    user_id UUID REFERENCES users(id),
    event_type VARCHAR(100) NOT NULL,
    target_entity VARCHAR(100) NOT NULL,
    target_id UUID,
    actor_ip VARCHAR(45),
    previous_state JSONB,
    new_state JSONB,
    details TEXT
);
CREATE INDEX idx_audit_events_ts ON audit_events(timestamp DESC);
CREATE INDEX idx_audit_events_entity ON audit_events(target_entity, target_id);`
  },
  {
    version: '002',
    name: '002_battery_hierarchy',
    description: 'Battery Chemistries, Manufacturers, Models, Systems, Packs, Modules and Individual Cells',
    sql: `-- ====================================================================
-- BATTERY OS MIGRATION 002: BATTERY PHYSICAL HIERARCHY
-- ====================================================================

-- Battery Chemistries
CREATE TABLE IF NOT EXISTS battery_chemistries (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    code VARCHAR(50) UNIQUE NOT NULL, -- e.g. LFP, NMC, NCA, SODIUM_ION
    display_name VARCHAR(100) NOT NULL,
    nominal_cell_voltage NUMERIC(6,3) NOT NULL,
    max_cell_voltage NUMERIC(6,3) NOT NULL,
    min_cell_voltage NUMERIC(6,3) NOT NULL,
    max_c_charge NUMERIC(6,2) NOT NULL,
    max_c_discharge NUMERIC(6,2) NOT NULL,
    optimal_temp_min_c NUMERIC(5,2) NOT NULL,
    optimal_temp_max_c NUMERIC(5,2) NOT NULL,
    max_safe_temp_c NUMERIC(5,2) NOT NULL,
    typical_cycle_life INT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Manufacturers
CREATE TABLE IF NOT EXISTS manufacturers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(150) NOT NULL UNIQUE,
    country VARCHAR(100) NOT NULL,
    website VARCHAR(255),
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Battery Models (Hardware Specs)
CREATE TABLE IF NOT EXISTS models (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    manufacturer_id UUID NOT NULL REFERENCES manufacturers(id),
    chemistry_id UUID NOT NULL REFERENCES battery_chemistries(id),
    model_code VARCHAR(100) NOT NULL UNIQUE,
    nominal_voltage NUMERIC(8,2) NOT NULL,
    nominal_capacity_ah NUMERIC(8,2) NOT NULL,
    nominal_energy_kwh NUMERIC(10,3) NOT NULL,
    max_continuous_current_a NUMERIC(8,2) NOT NULL,
    max_peak_current_a NUMERIC(8,2) NOT NULL,
    max_voltage NUMERIC(8,2) NOT NULL,
    min_voltage NUMERIC(8,2) NOT NULL,
    max_temperature_c NUMERIC(5,2) NOT NULL,
    min_temperature_c NUMERIC(5,2) NOT NULL,
    cells_in_series INT NOT NULL,
    cells_in_parallel INT NOT NULL,
    total_cells INT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Battery Systems (Highest Hierarchy: e.g. Grid Storage Station, EV Fleet)
CREATE TABLE IF NOT EXISTS systems (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(150) NOT NULL,
    system_type VARCHAR(50) NOT NULL CHECK (system_type IN ('GRID_STORAGE', 'EV_FLEET', 'COMMERCIAL_ESS', 'MICROGRID')),
    location VARCHAR(255) NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'NORMAL',
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Battery Packs
CREATE TABLE IF NOT EXISTS packs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    system_id UUID NOT NULL REFERENCES systems(id),
    model_id UUID NOT NULL REFERENCES models(id),
    serial_number VARCHAR(100) UNIQUE NOT NULL,
    firmware_version VARCHAR(50) NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'NORMAL',
    production_date DATE NOT NULL,
    installation_date DATE NOT NULL,
    current_soc soc_percentage,
    current_soh soh_percentage,
    current_voltage NUMERIC(8,2),
    current_current_a NUMERIC(8,2),
    current_temp_c celsius_temp,
    current_cycle_count INT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_packs_system ON packs(system_id);
CREATE INDEX idx_packs_serial ON packs(serial_number);

-- Modules
CREATE TABLE IF NOT EXISTS modules (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    pack_id UUID NOT NULL REFERENCES packs(id) ON DELETE CASCADE,
    module_index INT NOT NULL,
    module_code VARCHAR(100) NOT NULL,
    cell_count INT NOT NULL,
    voltage NUMERIC(8,2),
    temperature_avg_c celsius_temp,
    UNIQUE(pack_id, module_index)
);

-- Individual Cells
CREATE TABLE IF NOT EXISTS cells (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    module_id UUID NOT NULL REFERENCES modules(id) ON DELETE CASCADE,
    pack_id UUID NOT NULL REFERENCES packs(id) ON DELETE CASCADE,
    cell_index INT NOT NULL,
    cell_code VARCHAR(100) NOT NULL,
    voltage NUMERIC(6,3),
    temperature_c celsius_temp,
    internal_resistance_mohm NUMERIC(6,3),
    cycle_count INT DEFAULT 0,
    soc soc_percentage,
    soh soh_percentage,
    balancing_state VARCHAR(50) DEFAULT 'IDLE',
    fault_state VARCHAR(50) DEFAULT 'HEALTHY',
    UNIQUE(pack_id, cell_index)
);
CREATE INDEX idx_cells_pack ON cells(pack_id);
CREATE INDEX idx_cells_module ON cells(module_id);`
  },
  {
    version: '003',
    name: '003_telemetry',
    description: 'Append-oriented high-frequency telemetry, cell telemetry, pack telemetry, thermal telemetry with TimescaleDB hypertables',
    sql: `-- ====================================================================
-- BATTERY OS MIGRATION 003: APPEND-ONLY TELEMETRY & TIMESCALEDB
-- ====================================================================

-- Master Telemetry (High-Frequency Partitioned Table)
CREATE TABLE IF NOT EXISTS telemetry (
    timestamp TIMESTAMPTZ NOT NULL,
    pack_id UUID NOT NULL REFERENCES packs(id),
    voltage NUMERIC(8,2) NOT NULL,
    current NUMERIC(8,2) NOT NULL,
    power_kw NUMERIC(10,3) NOT NULL,
    soc soc_percentage NOT NULL,
    soh soh_percentage NOT NULL,
    temp_avg_c celsius_temp NOT NULL,
    temp_max_c celsius_temp NOT NULL,
    cell_spread_mv NUMERIC(6,2) NOT NULL,
    energy_kwh NUMERIC(12,3) NOT NULL,
    charging_state VARCHAR(50) NOT NULL,
    validation_passed BOOLEAN NOT NULL DEFAULT TRUE,
    validation_flags TEXT[]
);

-- Cell High-Frequency Telemetry
CREATE TABLE IF NOT EXISTS cell_telemetry (
    timestamp TIMESTAMPTZ NOT NULL,
    cell_id UUID NOT NULL REFERENCES cells(id),
    pack_id UUID NOT NULL REFERENCES packs(id),
    cell_index INT NOT NULL,
    voltage NUMERIC(6,3) NOT NULL,
    temperature_c celsius_temp NOT NULL,
    balancing_state VARCHAR(50) NOT NULL,
    balancing_current_ma NUMERIC(8,2) DEFAULT 0
);

-- Thermal Telemetry (Sensors, Coolant Flow, Ambient)
CREATE TABLE IF NOT EXISTS thermal_telemetry (
    timestamp TIMESTAMPTZ NOT NULL,
    pack_id UUID NOT NULL REFERENCES packs(id),
    ambient_temp_c celsius_temp NOT NULL,
    coolant_inlet_temp_c celsius_temp NOT NULL,
    coolant_outlet_temp_c celsius_temp NOT NULL,
    coolant_flow_rate_lpm NUMERIC(6,2) NOT NULL,
    max_thermal_gradient_c NUMERIC(5,2) NOT NULL
);

-- Convert to TimescaleDB Hypertables (if TimescaleDB plugin is active)
-- SELECT create_hypertable('telemetry', 'timestamp', chunk_time_interval => INTERVAL '1 day', if_not_exists => TRUE);
-- SELECT create_hypertable('cell_telemetry', 'timestamp', chunk_time_interval => INTERVAL '1 day', if_not_exists => TRUE);

-- Primary Query Indexes
CREATE INDEX idx_telemetry_pack_ts ON telemetry(pack_id, timestamp DESC);
CREATE INDEX idx_cell_telemetry_pack_ts ON cell_telemetry(pack_id, cell_index, timestamp DESC);
CREATE INDEX idx_thermal_telemetry_pack_ts ON thermal_telemetry(pack_id, timestamp DESC);`
  },
  {
    version: '004',
    name: '004_faults',
    description: 'Structured faults, fault life cycle, evidence payloads and resolution notes',
    sql: `-- ====================================================================
-- BATTERY OS MIGRATION 004: STRUCTURED FAULT DATABASE
-- ====================================================================

CREATE TABLE IF NOT EXISTS faults (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    pack_id UUID NOT NULL REFERENCES packs(id),
    module_id UUID REFERENCES modules(id),
    cell_id UUID REFERENCES cells(id),
    code VARCHAR(100) NOT NULL, -- e.g. CELL_OVERVOLTAGE, THERMAL_ANOMALY
    severity VARCHAR(20) NOT NULL CHECK (severity IN ('INFO', 'WARNING', 'CRITICAL', 'EMERGENCY')),
    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE' CHECK (status IN ('ACTIVE', 'ACKNOWLEDGED', 'RESOLVED', 'MUTED')),
    first_occurrence TIMESTAMPTZ NOT NULL,
    last_occurrence TIMESTAMPTZ NOT NULL,
    evidence TEXT NOT NULL,
    resolution_notes TEXT,
    resolved_by_user_id UUID REFERENCES users(id),
    resolved_at TIMESTAMPTZ
);

CREATE INDEX idx_faults_pack_status ON faults(pack_id, status);
CREATE INDEX idx_faults_severity ON faults(severity) WHERE status = 'ACTIVE';`
  },
  {
    version: '005',
    name: '005_charging',
    description: 'Charging and discharging sessions, profile curves, fast charge exposure tracking',
    sql: `-- ====================================================================
-- BATTERY OS MIGRATION 005: CHARGING & DISCHARGING SESSIONS
-- ====================================================================

CREATE TABLE IF NOT EXISTS charging_sessions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    pack_id UUID NOT NULL REFERENCES packs(id),
    start_time TIMESTAMPTZ NOT NULL,
    end_time TIMESTAMPTZ,
    duration_minutes INT,
    energy_delivered_kwh NUMERIC(10,3) NOT NULL,
    start_soc soc_percentage NOT NULL,
    end_soc soc_percentage,
    max_current_a NUMERIC(8,2) NOT NULL,
    max_temp_c celsius_temp NOT NULL,
    charger_type VARCHAR(50) NOT NULL,
    location VARCHAR(255),
    profile_curve JSONB
);

CREATE TABLE IF NOT EXISTS discharging_sessions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    pack_id UUID NOT NULL REFERENCES packs(id),
    start_time TIMESTAMPTZ NOT NULL,
    end_time TIMESTAMPTZ,
    energy_discharged_kwh NUMERIC(10,3) NOT NULL,
    start_soc soc_percentage NOT NULL,
    end_soc soc_percentage,
    peak_current_a NUMERIC(8,2) NOT NULL,
    avg_power_kw NUMERIC(10,3) NOT NULL
);

CREATE INDEX idx_charging_pack_start ON charging_sessions(pack_id, start_time DESC);`
  },
  {
    version: '006',
    name: '006_degradation',
    description: 'State of Health, State of Charge estimates, degradation models, remaining useful life predictions',
    sql: `-- ====================================================================
-- BATTERY OS MIGRATION 006: SOH, SOC & DEGRADATION MODELS
-- ====================================================================

CREATE TABLE IF NOT EXISTS state_estimates (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    pack_id UUID NOT NULL REFERENCES packs(id),
    timestamp TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    algorithm VARCHAR(50) NOT NULL, -- e.g. SOC_COULOMB_COUNTING, SOC_KALMAN
    soc_estimate soc_percentage NOT NULL,
    confidence_pct NUMERIC(5,2) NOT NULL,
    input_version VARCHAR(50) NOT NULL,
    model_version VARCHAR(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS health_estimates (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    pack_id UUID NOT NULL REFERENCES packs(id),
    timestamp TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    soh_estimate soh_percentage NOT NULL,
    capacity_estimate_ah NUMERIC(8,2) NOT NULL,
    resistance_estimate_mohm NUMERIC(6,3) NOT NULL,
    cycle_count INT NOT NULL,
    model_version VARCHAR(50) NOT NULL,
    confidence_pct NUMERIC(5,2) NOT NULL
);

CREATE TABLE IF NOT EXISTS degradation_models (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    pack_id UUID NOT NULL REFERENCES packs(id),
    prediction_timestamp TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    current_soh soh_percentage NOT NULL,
    predicted_rul_cycles INT NOT NULL,
    predicted_rul_days INT NOT NULL,
    confidence_pct NUMERIC(5,2) NOT NULL,
    model_version VARCHAR(50) NOT NULL,
    projections_json JSONB NOT NULL
);

CREATE INDEX idx_state_est_pack ON state_estimates(pack_id, timestamp DESC);
CREATE INDEX idx_health_est_pack ON health_estimates(pack_id, timestamp DESC);`
  },
  {
    version: '007',
    name: '007_fleet',
    description: 'Configurations, limits versioning, maintenance records and fleet aggregations views',
    sql: `-- ====================================================================
-- BATTERY OS MIGRATION 007: CONFIGURATION VERSIONING & FLEET VIEWS
-- ====================================================================

CREATE TABLE IF NOT EXISTS configurations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    model_id UUID NOT NULL REFERENCES models(id),
    version INT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    created_by_user_id UUID REFERENCES users(id),
    voltage_upper_limit_v NUMERIC(8,2) NOT NULL,
    voltage_lower_limit_v NUMERIC(8,2) NOT NULL,
    current_max_charge_a NUMERIC(8,2) NOT NULL,
    current_max_discharge_a NUMERIC(8,2) NOT NULL,
    temp_upper_limit_c celsius_temp NOT NULL,
    temp_lower_limit_c celsius_temp NOT NULL,
    max_cell_delta_mv NUMERIC(6,2) NOT NULL,
    description TEXT,
    UNIQUE(model_id, version)
);

CREATE TABLE IF NOT EXISTS maintenance_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    pack_id UUID NOT NULL REFERENCES packs(id),
    module_id UUID REFERENCES modules(id),
    cell_id UUID REFERENCES cells(id),
    performed_at TIMESTAMPTZ NOT NULL,
    technician_name VARCHAR(150) NOT NULL,
    action_type VARCHAR(100) NOT NULL, -- e.g. CELL_REPLACED, MODULE_REBALANCED
    notes TEXT NOT NULL
);

-- High Performance Fleet Summary View
CREATE OR REPLACE VIEW view_fleet_summary AS
SELECT 
    s.id AS system_id,
    s.name AS system_name,
    COUNT(p.id) AS total_packs,
    AVG(p.current_soh) AS avg_soh,
    AVG(p.current_soc) AS avg_soc,
    SUM(m.nominal_energy_kwh) / 1000.0 AS total_capacity_mwh,
    COUNT(f.id) FILTER (WHERE f.status = 'ACTIVE') AS active_faults
FROM systems s
LEFT JOIN packs p ON p.system_id = s.id
LEFT JOIN models m ON p.model_id = m.id
LEFT JOIN faults f ON f.pack_id = p.id
GROUP BY s.id, s.name;`
  }
];
