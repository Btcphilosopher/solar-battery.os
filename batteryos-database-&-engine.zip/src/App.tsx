import React, { useEffect, useState } from 'react';
import {
  FleetSummary,
  BatterySystem,
  BatteryPack,
  TelemetryReading,
  RustPipelineStatus,
  BenchmarkMetrics,
  DataQualityEvent,
  Fault,
  AuditEvent,
  SafetyConfiguration,
  RULPrediction
} from './types';

import { NavbarHeader } from './components/NavbarHeader';
import { FleetOverview } from './components/FleetOverview';
import { PackCellInspector } from './components/PackCellInspector';
import { RustPipelineSimulator } from './components/RustPipelineSimulator';
import { RAnalyticsRUL } from './components/RAnalyticsRUL';
import { ChargingThermalManager } from './components/ChargingThermalManager';
import { PostgresSchemaExplorer } from './components/PostgresSchemaExplorer';
import { FaultsEventSourcing } from './components/FaultsEventSourcing';
import { AIBatteryAdvisor } from './components/AIBatteryAdvisor';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('fleet');
  const [summary, setSummary] = useState<FleetSummary | null>(null);
  const [systems, setSystems] = useState<BatterySystem[]>([]);
  const [selectedPackId, setSelectedPackId] = useState<string>('pack-packlfp800v001');
  const [telemetryHistory, setTelemetryHistory] = useState<TelemetryReading[]>([]);
  const [pipelineStatus, setPipelineStatus] = useState<RustPipelineStatus | null>(null);
  const [benchmarks, setBenchmarks] = useState<BenchmarkMetrics | null>(null);
  const [dataQualityLogs, setDataQualityLogs] = useState<DataQualityEvent[]>([]);
  const [faults, setFaults] = useState<Fault[]>([]);
  const [auditEvents, setAuditEvents] = useState<AuditEvent[]>([]);
  const [safetyConfigs, setSafetyConfigs] = useState<SafetyConfiguration[]>([]);
  const [rulPrediction, setRulPrediction] = useState<RULPrediction | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  // Fetch initial system state from Express backend
  const fetchState = async () => {
    try {
      const [
        sumRes,
        sysRes,
        pipeRes,
        benchRes,
        dqRes,
        fltRes,
        evtRes,
        cfgRes
      ] = await Promise.all([
        fetch('/api/fleet/summary').then(r => r.json()),
        fetch('/api/batteries').then(r => r.json()),
        fetch('/api/rust-pipeline').then(r => r.json()),
        fetch('/api/benchmarks').then(r => r.json()),
        fetch('/api/data-quality').then(r => r.json()),
        fetch('/api/faults').then(r => r.json()),
        fetch('/api/events').then(r => r.json()),
        fetch('/api/configs').then(r => r.json())
      ]);

      setSummary(sumRes);
      setSystems(sysRes);
      setPipelineStatus(pipeRes);
      setBenchmarks(benchRes);
      setDataQualityLogs(dqRes);
      setFaults(fltRes);
      setAuditEvents(evtRes);
      setSafetyConfigs(cfgRes);

      // Default pack fallback
      if (sysRes[0]?.packs[0]?.id && !selectedPackId) {
        setSelectedPackId(sysRes[0].packs[0].id);
      }
    } catch (e) {
      console.error('Failed to load initial BatteryOS state:', e);
    } finally {
      setLoading(false);
    }
  };

  // Fetch telemetry & RUL whenever selected pack changes
  useEffect(() => {
    if (!selectedPackId) return;

    fetch(`/api/batteries/${selectedPackId}/telemetry`)
      .then(r => r.json())
      .then(data => setTelemetryHistory(data))
      .catch(console.error);

    fetch(`/api/batteries/${selectedPackId}/rul`)
      .then(r => r.json())
      .then(data => setRulPrediction(data))
      .catch(console.error);
  }, [selectedPackId]);

  useEffect(() => {
    fetchState();

    // Poll live stream telemetry & system summary every 3 seconds
    const interval = setInterval(() => {
      fetch('/api/fleet/summary').then(r => r.json()).then(setSummary).catch(() => {});
      fetch('/api/batteries').then(r => r.json()).then(setSystems).catch(() => {});
      if (selectedPackId) {
        fetch(`/api/batteries/${selectedPackId}/telemetry`)
          .then(r => r.json())
          .then(setTelemetryHistory)
          .catch(() => {});
      }
    }, 3000);

    return () => clearInterval(interval);
  }, [selectedPackId]);

  // Extract all packs across all systems for easy selector
  const allPacks: BatteryPack[] = [];
  systems.forEach(s => allPacks.push(...s.packs));

  const activePack = allPacks.find(p => p.id === selectedPackId) || allPacks[0];

  const handleTriggerBatchIngest = async (batchSize: number, introduceAnomalies: boolean) => {
    // Generate simulated readings batch
    const batch = Array.from({ length: batchSize }).map((_, idx) => ({
      batteryPackId: selectedPackId,
      timestamp: new Date().toISOString(),
      voltage: introduceAnomalies && idx % 40 === 0 ? 1250 : 392.4, // 1250V is impossible spike
      current: 42.1,
      tempAvg: introduceAnomalies && idx % 70 === 0 ? 145 : 31.4, // 145C is impossible temp
      cellSpreadMV: 18
    }));

    await fetch('/api/telemetry', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(batch)
    });

    // Refresh data quality logs and summary
    const dqRes = await fetch('/api/data-quality').then(r => r.json());
    setDataQualityLogs(dqRes);
    const sumRes = await fetch('/api/fleet/summary').then(r => r.json());
    setSummary(sumRes);
  };

  if (loading || !summary || !pipelineStatus || !benchmarks || !rulPrediction) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-center space-y-4 font-mono">
        <div className="w-10 h-10 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
        <div className="text-sm font-bold text-emerald-400 animate-pulse">
          Initializing BatteryOS Engine & PostgreSQL Telemetry Service...
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans antialiased selection:bg-emerald-500 selection:text-slate-950">
      {/* Top Header Navbar */}
      <NavbarHeader
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        activeFaultsCount={summary.activeFaultsCount}
        ingestionRateSec={summary.ingestionRatePerSec}
      />

      {/* Main App Content View Container */}
      <main className="max-w-7xl mx-auto px-4 py-6">
        {activeTab === 'fleet' && (
          <FleetOverview
            summary={summary}
            systems={systems}
            onSelectPack={(id) => {
              setSelectedPackId(id);
              setActiveTab('inspector');
            }}
            onOpenFaults={() => setActiveTab('faults')}
          />
        )}

        {activeTab === 'inspector' && (
          <PackCellInspector
            packs={allPacks}
            selectedPackId={selectedPackId}
            onSelectPack={setSelectedPackId}
            telemetryHistory={telemetryHistory}
          />
        )}

        {activeTab === 'rust-pipeline' && (
          <RustPipelineSimulator
            pipelineStatus={pipelineStatus}
            dataQualityLogs={dataQualityLogs}
            onTriggerBatchIngest={handleTriggerBatchIngest}
          />
        )}

        {activeTab === 'r-analytics' && (
          <RAnalyticsRUL
            rulPrediction={rulPrediction}
            selectedPackId={selectedPackId}
          />
        )}

        {activeTab === 'charging-thermal' && (
          <ChargingThermalManager currentPack={activePack} />
        )}

        {activeTab === 'postgres-ddl' && (
          <PostgresSchemaExplorer benchmarks={benchmarks} />
        )}

        {activeTab === 'events-config' && (
          <FaultsEventSourcing
            faults={faults}
            events={auditEvents}
            safetyConfigs={safetyConfigs}
          />
        )}

        {activeTab === 'faults' && (
          <FaultsEventSourcing
            faults={faults}
            events={auditEvents}
            safetyConfigs={safetyConfigs}
          />
        )}

        {activeTab === 'ai-assistant' && (
          <AIBatteryAdvisor
            packs={allPacks}
            selectedPackId={selectedPackId}
          />
        )}
      </main>
    </div>
  );
}
