-- Database schema migration for BATTERYPERFORM
-- Replicable battery Specifications and Optimization Decisions

CREATE TABLE IF NOT EXISTS battery_specifications (
    battery_id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    chemistry VARCHAR(50) NOT NULL,
    nominal_capacity_ah DOUBLE PRECISION NOT NULL,
    cells_in_series INT NOT NULL,
    cells_in_parallel INT NOT NULL,
    max_voltage_v DOUBLE PRECISION NOT NULL,
    min_voltage_v DOUBLE PRECISION NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS optimization_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    timestamp TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    battery_id VARCHAR(50) NOT NULL,
    model_version VARCHAR(20) NOT NULL,
    
    -- Input States
    input_soc DOUBLE PRECISION NOT NULL,
    input_voltage_v DOUBLE PRECISION NOT NULL,
    input_temperature_c DOUBLE PRECISION NOT NULL,
    input_resistance_ohm DOUBLE PRECISION NOT NULL,
    power_demand_kw DOUBLE PRECISION NOT NULL,
    
    -- Chosen Operating Point
    selected_current_a DOUBLE PRECISION NOT NULL,
    predicted_power_kw DOUBLE PRECISION NOT NULL,
    predicted_efficiency DOUBLE PRECISION NOT NULL,
    expected_heat_generation_w DOUBLE PRECISION NOT NULL,
    performance_index DOUBLE PRECISION NOT NULL,
    
    -- Meta
    rationale TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_opt_history_battery ON optimization_history(battery_id, timestamp DESC);
