#' Dynamic Battery System Efficiency Modeller
#'
#' @description Evaluates instantaneous conversion and transmission efficiencies.
#' @param terminal_voltage Numeric. Pack voltage (V)
#' @param current_a Numeric. Load current (A)
#' @param internal_r Numeric. Dynamic resistance (Ohms)
#' @param cabling_r Numeric. Busbar and contactor resistance (Ohms)
#' @return A list of loss metrics and net efficiencies.
#' @export
efficiency_model <- function(terminal_voltage, current_a, internal_r, cabling_r = 0.0008) {
  power_electrical <- abs(terminal_voltage * current_a)
  
  # Joule losses: I^2 * R
  loss_internal <- current_a^2 * internal_r
  loss_cabling <- current_a^2 * cabling_r
  loss_total <- loss_internal + loss_cabling
  
  # Inverter parasitic conversion losses (estimated 1.5% fixed plus variable)
  loss_inverter <- 0.015 * power_electrical
  
  net_efficiency <- (power_electrical) / (power_electrical + loss_total + loss_inverter + 0.0001)
  
  return(list(
    efficiency = min(max(net_efficiency, 0.0), 1.0),
    joule_loss_internal = loss_internal,
    joule_loss_cabling = loss_cabling,
    joule_loss_inverter = loss_inverter
  ))
}
