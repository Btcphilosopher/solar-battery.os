#' Battery Health and Parameter Forecaster
#'
#' @description Fits historical degradation data (capacity and resistance growth) to project future state of health and available power limits.
#' @param cycle_history Numeric vector. Historical cycle numbers.
#' @param soh_history Numeric vector. Historical State of Health values.
#' @param horizon_cycles Integer. Number of future cycles to forecast.
#' @return A list containing the fitted model and forecasted future SOH.
#' @export
forecast_battery_state <- function(cycle_history, soh_history, horizon_cycles = 500) {
  # Empirical power-law degradation fit: SOH ~ 1 - a * cycles^b
  # Convert to logarithmic linear regression: log(1 - SOH) ~ log(a) + b * log(cycles)
  
  df <- data.frame(Cycles = cycle_history, SOH = soh_history)
  # Filter out initial state or non-degraded cycles to avoid negative log
  df_filtered <- df[df$SOH < 1.0 & df$Cycles > 0, ]
  
  if (nrow(df_filtered) < 3) {
    # Fallback to simple linear regression
    fit <- lm(SOH ~ Cycles, data = df)
    future_cycles <- max(cycle_history) + (1:horizon_cycles)
    forecast_soh <- predict(fit, newdata = data.frame(Cycles = future_cycles))
  } else {
    df_filtered$Y <- log(1.0 - df_filtered$SOH)
    df_filtered$logX <- log(df_filtered$Cycles)
    
    fit <- lm(Y ~ logX, data = df_filtered)
    
    future_cycles <- max(cycle_history) + (1:horizon_cycles)
    predicted_log_y <- predict(fit, newdata = data.frame(logX = log(future_cycles)))
    forecast_soh <- 1.0 - exp(predicted_log_y)
  }
  
  # Clamp forecasted SOH to physically valid bounds [0, 1]
  forecast_soh <- pmin(pmax(forecast_soh, 0.0), 1.0)
  
  return(list(
    degradation_model = fit,
    forecasted_cycles = future_cycles,
    forecasted_soh = forecast_soh
  ))
}
