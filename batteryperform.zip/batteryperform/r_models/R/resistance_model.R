#' Arrhenius Temperature and Aging Resistance Modeller
#'
#' @description Models dynamic cell internal resistance based on operating temperature and aging factors.
#' @param temperature_c Numeric. Cell temperature in °C
#' @param soh Numeric. State of Health (0-1)
#' @param r_ref Numeric. Reference resistance at 25°C (Ohms)
#' @param activation_energy Numeric. Arrhenius activation energy (J/mol)
#' @return Estimated dynamic internal resistance in Ohms.
#' @export
resistance_model <- function(temperature_c, soh, r_ref = 0.012, activation_energy = 22000.0) {
  r_gas <- 8.314 # J/(mol*K)
  temp_k <- temperature_c + 273.15
  temp_ref_k <- 298.15 # 25°C
  
  # Arrhenius scaling factor
  arrhenius <- exp((activation_energy / r_gas) * (1.0 / temp_k - 1.0 / temp_ref_k))
  
  # Aging factor: exponential resistance growth near end of life
  aging_factor <- 1.0 + 1.8 * (1.0 - soh)^2
  
  estimated_resistance <- r_ref * arrhenius * aging_factor
  return(estimated_resistance)
}
