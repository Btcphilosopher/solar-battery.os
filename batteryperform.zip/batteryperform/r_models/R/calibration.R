#' Electrochemical Parameter Calibration Engine
#'
#' @description Fits empirical battery test datasets using non-linear least squares to estimate reference resistances and activation energy.
#' @param temperatures Numeric vector. Measured temperatures (°C)
#' @param resistances Numeric vector. Measured internal resistances (Ohms)
#' @return A list of fitted coefficients and residual standard errors.
#' @export
calibrate_parameters <- function(temperatures, resistances) {
  # Convert temperatures to Kelvin
  temp_k <- temperatures + 273.15
  temp_ref_k <- 298.15
  r_gas <- 8.314
  
  # Set up data frame
  df <- data.frame(Tk = temp_k, R = resistances)
  
  # Arrhenius non-linear least squares fit: R ~ r_ref * exp((Ea/Rg) * (1/Tk - 1/Tref))
  # Starting values
  start_list <- list(r_ref = 0.010, Ea = 22000.0)
  
  fit <- tryCatch({
    nls(R ~ r_ref * exp((Ea / r_gas) * (1.0 / Tk - 1.0 / temp_ref_k)), 
        data = df, 
        start = start_list)
  }, error = function(e) {
    # Fallback to linear log fit if nls fails to converge
    log_r <- log(resistances)
    inv_t <- 1.0 / temp_k - 1.0 / temp_ref_k
    l_fit <- lm(log_r ~ inv_t)
    return(l_fit)
  })
  
  summary_fit <- summary(fit)
  
  return(list(
    fit_summary = summary_fit,
    success = TRUE,
    fitted_model = fit
  ))
}
