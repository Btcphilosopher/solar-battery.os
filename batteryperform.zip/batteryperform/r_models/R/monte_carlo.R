#' Monte Carlo Battery Performance Uncertainty Analyzer
#'
#' @description Conducts thousands of stochastic scenario evaluations by injecting noise into battery resistances, temperatures, and load demands.
#' @param base_voltage Numeric. Base open-circuit voltage (V)
#' @param base_resistance Numeric. Base internal resistance (Ohms)
#' @param base_temperature Numeric. Base pack temperature (°C)
#' @param iterations Integer. Number of Monte Carlo samples
#' @return A data frame containing simulated outputs.
#' @export
run_monte_carlo_sim <- function(base_voltage, base_resistance, base_temperature, iterations = 1000) {
  set.seed(42) # Reproducible results
  
  # Inject normal noise into inputs
  sim_r <- rnorm(iterations, mean = base_resistance, sd = base_resistance * 0.1)
  sim_temp <- rnorm(iterations, mean = base_temperature, sd = 2.0)
  sim_voltage <- rnorm(iterations, mean = base_voltage, sd = 1.0)
  sim_demand <- rnorm(iterations, mean = 250.0, sd = 25.0) # kW
  
  results_df <- data.frame(
    id = 1:iterations,
    resistance = sim_r,
    temperature = sim_temp,
    voltage = sim_voltage,
    demand = sim_demand,
    optimal_current = numeric(iterations),
    predicted_power = numeric(iterations),
    predicted_efficiency = numeric(iterations),
    thermal_risk = logical(iterations)
  )
  
  for (i in 1:iterations) {
    opt <- optimise_operating_point(
      voltage = results_df$voltage[i],
      resistance = results_df$resistance[i],
      temperature = results_df$temperature[i],
      demand = results_df$demand[i]
    )
    results_df$optimal_current[i] <- opt$optimal_current_a
    results_df$predicted_power[i] <- opt$predicted_power_kw
    results_df$predicted_efficiency[i] <- opt$predicted_efficiency
    results_df$thermal_risk[i] <- results_df$temperature[i] > 40.0
  }
  
  return(results_df)
}
