#' Coupled Electro-Thermal State Modeller
#'
#' @description Simulates heat generation and dissipation profiles under high currents.
#' @param current_a Numeric. Current flow (A)
#' @param internal_r Numeric. Dynamic internal resistance (Ohms)
#' @param initial_temp_c Numeric. Cell initial temperature (°C)
#' @param coolant_temp_c Numeric. Liquid coolant entrance temperature (°C)
#' @param coolant_flow_l_s Numeric. Coolant pump flow rate (L/s)
#' @param time_step_s Numeric. Integration step size (s)
#' @param thermal_capacity Numeric. Cell heat capacity (J/K)
#' @return The predicted final cell temperature (°C) and total heat produced (J).
#' @export
thermal_model <- function(current_a, internal_r, initial_temp_c, coolant_temp_c, 
                          coolant_flow_l_s, time_step_s = 1.0, thermal_capacity = 80.0) {
  # Irreversible Joule heating: Q_gen = I^2 * R
  heat_generated_w <- (current_a^2) * internal_r
  
  # Heat removed by cooling system (approximating dynamic heat transfer coefficient)
  h_coefficient <- 10.0 + 8.0 * sqrt(coolant_flow_l_s) # W/K
  heat_removed_w <- h_coefficient * (initial_temp_c - coolant_temp_c)
  
  # Net thermal energy rate
  net_thermal_power_w <- heat_generated_w - heat_removed_w
  
  # T_next = T_prev + dt * Q_net / C_thermal
  temp_delta <- (net_thermal_power_w * time_step_s) / thermal_capacity
  final_temp_c <- initial_temp_c + temp_delta
  
  return(list(
    final_temperature_c = final_temp_c,
    heat_generated_joules = heat_generated_w * time_step_s,
    heat_removed_joules = heat_removed_w * time_step_s
  ))
}
