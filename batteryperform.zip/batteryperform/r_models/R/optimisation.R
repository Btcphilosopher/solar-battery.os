#' Multi-Objective Battery Operating Point Optimizer
#'
#' @description Searches candidate operating currents to maximize net electrical power output while restricting safety violations.
#' @param voltage Numeric. Current pack open-circuit voltage (V)
#' @param resistance Numeric. Estimated internal resistance (Ohms)
#' @param temperature Numeric. Pack maximum temperature (°C)
#' @param demand Numeric. Power demand request (kW)
#' @param current_limits Numeric vector. Max charge/discharge boundaries (A)
#' @return A list containing the optimal current, power, and efficiency metrics.
#' @export
optimise_operating_point <- function(voltage, resistance, temperature, demand, current_limits = c(-400, 400)) {
  # Candidate currents grid search
  candidates <- seq(current_limits[1], current_limits[2], length.out = 100)
  
  best_current <- 0.0
  best_efficiency <- 0.0
  best_power <- 0.0
  best_score <- -Inf
  
  for (i in 1:length(candidates)) {
    c_current <- candidates[i]
    
    # Kirchhoff drop
    terminal_v <- voltage + (c_current * resistance)
    power_kw <- (terminal_v * c_current) / 1000.0
    
    # Calculate losses
    joule_loss <- c_current^2 * resistance
    
    # Instantaneous efficiency
    eff <- if (c_current < 0.0) {
      abs(power_kw) / ((voltage * abs(c_current)) / 1000.0 + 1e-5)
    } else if (c_current > 0.0) {
      ((voltage * c_current) / 1000.0) / (power_kw + 1e-5)
    } else {
      1.0
    }
    eff <- min(max(eff, 0.0), 1.0)
    
    # Score function: penalise high temperatures, reward power delivery matching demand, reward efficiency
    demand_penalty <- (abs(power_kw) - abs(demand))^2
    temp_penalty <- if (temperature > 45.0) { (temperature - 45.0)^2 * 10 } else { 0.0 }
    loss_penalty <- joule_loss * 0.01
    
    score <- -demand_penalty - temp_penalty - loss_penalty + (eff * 500)
    
    if (score > best_score) {
      best_score <- score
      best_current <- c_current
      best_power <- power_kw
      best_efficiency <- eff
    }
  }
  
  return(list(
    optimal_current_a = best_current,
    predicted_power_kw = best_power,
    predicted_efficiency = best_efficiency,
    score_metric = best_score
  ))
}
