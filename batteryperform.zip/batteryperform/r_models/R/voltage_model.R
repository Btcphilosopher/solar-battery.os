#' Dynamic Voltage Sag and Recovery Modeller
#'
#' @description Computes terminal voltage and dynamic voltage sags under various discharge currents.
#' @param soc Numeric. State of Charge (0-1)
#' @param current_a Numeric. Load current (A). Negative is discharging.
#' @param r_internal Numeric. Internal resistance (Ohms).
#' @param ocv_coefficients Numeric vector. Polynomial coefficients for OCV-SOC.
#' @return A list with OCV, terminal voltage, and calculated voltage sag.
#' @export
voltage_model <- function(soc, current_a, r_internal, ocv_coefficients = c(3.4, 0.6, 0.1, 0.05, -0.05)) {
  # Clip SOC to valid range
  clipped_soc <- min(max(soc, 0.001), 0.999)
  
  # Polynomial OCV calculation
  ocv <- ocv_coefficients[1] + 
         ocv_coefficients[2] * clipped_soc + 
         ocv_coefficients[3] * (clipped_soc^2) + 
         ocv_coefficients[4] * log(clipped_soc) + 
         ocv_coefficients[5] * log(1.0 - clipped_soc)
         
  # KVL terminal voltage
  terminal_v <- ocv + (current_a * r_internal)
  
  # Sag
  sag <- max(ocv - terminal_v, 0.0)
  
  return(list(
    open_circuit_voltage = ocv,
    terminal_voltage = terminal_v,
    voltage_sag = sag
  ))
}
