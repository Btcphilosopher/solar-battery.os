#' Battery Performance Index Calculator
#'
#' @description Computes a normalized composite index (0-1) representing overall battery operational capability.
#' @param power_delivered Numeric. Power output (kW)
#' @param efficiency Numeric. Operating efficiency (0-1)
#' @param temperature Numeric. Cell temperature (°C)
#' @param voltage_sag Numeric. Voltage drop under load (V)
#' @return A list containing the composite index and its subcomponents.
#' @export
performance_model <- function(power_delivered, efficiency, temperature, voltage_sag) {
  # Normalize power output (relative to nominal 350 kW maximum)
  power_score <- min(max(abs(power_delivered) / 350.0, 0.0), 1.0)
  
  # Efficiency is already in 0-1 range
  eff_score <- min(max(efficiency, 0.0), 1.0)
  
  # Temperature score: optimal window is 20-30°C. Penalty applied outside this range.
  temp_deviation <- abs(temperature - 25.0)
  temp_score <- max(1.0 - (temp_deviation / 35.0), 0.0)
  
  # Voltage stability score: lower sag is better. Max allowable transient sag is 15.0V
  sag_score <- max(1.0 - (voltage_sag / 15.0), 0.0)
  
  # Weighted composite index
  composite_index <- (power_score * 0.25) + (eff_score * 0.35) + (temp_score * 0.20) + (sag_score * 0.20)
  
  return(list(
    composite_index = composite_index,
    power_score = power_score,
    efficiency_score = eff_score,
    thermal_score = temp_score,
    stability_score = sag_score
  ))
}
