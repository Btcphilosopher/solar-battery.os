/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

use serde::{Serialize, Deserialize};

/// Models external cabling and connection terminal losses.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CablingLossConfig {
    pub contactor_resistance_ohm: f64,
    pub busbar_resistance_ohm_per_cell: f64,
    pub auxiliary_load_w: f64, // Constant power consumed by BMS & pumps
}

impl Default for CablingLossConfig {
    fn default() -> Self {
        Self {
            contactor_resistance_ohm: 0.0005, // 0.5 mΩ
            busbar_resistance_ohm_per_cell: 0.00005, // 50 µΩ
            auxiliary_load_w: 120.0, // 120 Watts for coolant pump & sensors
        }
    }
}

/// Dynamic response voltage sag and recovery tracker.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct ElectricalTelemetry {
    pub terminal_voltage_v: f64,
    pub current_a: f64,
    pub power_w: f64,
    pub internal_joule_losses_w: f64,
    pub dynamic_voltage_sag_v: f64,
}

/// Calculate overall system loss including internal resistance and cabling.
pub fn calculate_system_losses(
    pack_current_a: f64,
    pack_internal_resistance_ohm: f64,
    total_cells: usize,
    config: &CablingLossConfig
) -> f64 {
    let internal_joule_losses = pack_current_a.powi(2) * pack_internal_resistance_ohm;
    let busbar_losses = pack_current_a.powi(2) * (config.busbar_resistance_ohm_per_cell * total_cells as f64);
    let contactor_losses = pack_current_a.powi(2) * config.contactor_resistance_ohm;

    internal_joule_losses + busbar_losses + contactor_losses + config.auxiliary_load_w
}
