/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

use serde::{Serialize, Deserialize};
use crate::error::{BatteryError, Result};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SafetyEnvelope {
    pub absolute_max_voltage_v: f64,
    pub absolute_min_voltage_v: f64,
    pub absolute_max_current_charge_a: f64,
    pub absolute_max_current_discharge_a: f64,
    pub absolute_max_temp_c: f64,
    pub absolute_min_temp_c: f64,
}

impl Default for SafetyEnvelope {
    fn default() -> Self {
        Self {
            absolute_max_voltage_v: 4.25,
            absolute_min_voltage_v: 2.70,
            absolute_max_current_charge_a: 25.0,
            absolute_max_current_discharge_a: 75.0,
            absolute_max_temp_c: 60.0,
            absolute_min_temp_c: -10.0,
        }
    }
}

/// Verify cell voltages and pack current against safety thresholds
pub fn check_safety_violations(
    cell_voltages: &[f64],
    pack_current_a: f64,
    cell_temperatures: &[f64],
    envelope: &SafetyEnvelope,
) -> Result<()> {
    // 1. Current checks
    if pack_current_a > envelope.absolute_max_current_charge_a {
        return Err(BatteryError::CurrentOutOfBounds {
            current: pack_current_a,
            max_c: envelope.absolute_max_current_charge_a,
        });
    }
    if pack_current_a.abs() > envelope.absolute_max_current_discharge_a && pack_current_a < 0.0 {
        return Err(BatteryError::CurrentOutOfBounds {
            current: pack_current_a.abs(),
            max_c: envelope.absolute_max_current_discharge_a,
        });
    }

    // 2. Cell voltage checks
    for (idx, &v) in cell_voltages.iter().enumerate() {
        if v > envelope.absolute_max_voltage_v || v < envelope.absolute_min_voltage_v {
            return Err(BatteryError::VoltageOutOfBounds {
                cell_id: idx + 1,
                voltage: v,
                min_v: envelope.absolute_min_voltage_v,
                max_v: envelope.absolute_max_voltage_v,
            });
        }
    }

    // 3. Thermal checks
    for &t in cell_temperatures {
        if t > envelope.absolute_max_temp_c {
            return Err(BatteryError::ThermalRunaway(t));
        }
        if t < envelope.absolute_min_temp_c {
            return Err(BatteryError::SafetyViolation(format!(
                "Cell temperature {}°C is below absolute freezing limit of {}°C",
                t, envelope.absolute_min_temp_c
            )));
        }
    }

    Ok(())
}
