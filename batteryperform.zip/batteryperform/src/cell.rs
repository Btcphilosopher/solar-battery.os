/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

use serde::{Serialize, Deserialize};
use crate::error::{BatteryError, Result};

/// Configuration parameters for a single electrochemical cell.
/// Allows customization of the electrochemical behavior.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CellConfig {
    pub nominal_capacity_ah: f64,    // Units: Ah (Ampere-hours)
    pub max_voltage_v: f64,          // Units: V (Volts)
    pub min_voltage_v: f64,          // Units: V (Volts)
    pub max_current_charge_a: f64,   // Units: A (Amperes)
    pub max_current_discharge_a: f64,// Units: A (Amperes)
    pub thermal_capacity_j_k: f64,   // Thermal mass, Units: J/K
    pub ocv_coefficients: [f64; 5],  // Empirical OCV-SOC polynomial coeffs
    pub r0_reference_ohm: f64,       // Ref resistance, Units: Ohms
    pub activation_energy_j_mol: f64, // Arrhenius activation energy, J/mol
}

impl Default for CellConfig {
    fn default() -> Self {
        Self {
            nominal_capacity_ah: 5.0,
            max_voltage_v: 4.2,
            min_voltage_v: 2.8,
            max_current_charge_a: 15.0,
            max_current_discharge_a: 50.0,
            thermal_capacity_j_k: 80.0,
            // Coefficients of polynomial: V_ocv(soc) = c0 + c1*soc + c2*soc^2 + c3*ln(soc) + c4*ln(1-soc)
            ocv_coefficients: [3.4, 0.6, 0.1, 0.05, -0.05],
            r0_reference_ohm: 0.012,
            activation_energy_j_mol: 25000.0, // Standard lithium-ion Arrhenius factor
        }
    }
}

/// Represents the dynamic physical and electrochemical state of a single Cell.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Cell {
    pub id: usize,
    pub config: CellConfig,
    pub soc: f64,                  // State of Charge, Units: Ratio [0.0, 1.0]
    pub soh: f64,                  // State of Health, Units: Ratio [0.0, 1.0]
    pub temperature_c: f64,        // Cell Temperature, Units: °C
    pub cumulative_charge_ah: f64, // Lifetime accumulated charge, Units: Ah
    pub active_polarization_v: f64, // Double-layer polarization voltage sag, V
}

impl Cell {
    pub fn new(id: usize, config: CellConfig) -> Self {
        Self {
            id,
            config,
            soc: 0.6, // Start at 60% SOC
            soh: 1.0, // Start with 100% SOH
            temperature_c: 25.0, // Ambient reference 25°C
            cumulative_charge_ah: 0.0,
            active_polarization_v: 0.0,
        }
    }

    /// Scientific Equation: Open Circuit Voltage (OCV) Model
    ///
    /// ## Assumptions
    /// * Neglects hysteresis effects during rapid switching between charge/discharge.
    /// * Empirical approximation using polynomial + logarithmic terms for phase transitions in graphite/LFP/NMC.
    ///
    /// ## Units
    /// * Return value: Volts (V)
    /// * Inputs: State of Charge (Ratio, 0.0 - 1.0)
    ///
    /// ## Range of Validity
    /// * SOC must be strictly in range [0.01, 0.99] to avoid logarithmic singularities. Bound checking is enforced.
    pub fn calculate_ocv(&self, soc: f64) -> f64 {
        let clipped_soc = soc.clamp(0.001, 0.999);
        let c = &self.config.ocv_coefficients;
        
        // Empirical OCV approximation
        c[0] + c[1] * clipped_soc 
             + c[2] * clipped_soc.powi(2) 
             + c[3] * clipped_soc.ln() 
             + c[4] * (1.0 - clipped_soc).ln()
    }

    /// Scientific Equation: Arrhenius Temperature-Dependent & SOC-Dependent Internal Resistance (R)
    ///
    /// ## Assumptions
    /// * Obeys Arrhenius law for rate of charge-transfer kinetics.
    /// * Resistance increases at low SOC and low temperatures due to reduced ion diffusion.
    ///
    /// ## Units
    /// * Return value: Ohms (Ω)
    pub fn calculate_resistance(&self) -> f64 {
        let r_gas = 8.314; // Universal gas constant, J/(mol*K)
        let temp_k = self.temperature_c + 273.15; // °C to Kelvin
        let temp_ref_k = 298.15; // 25°C reference in Kelvin
        
        // Arrhenius scale factor
        let arrhenius = ((self.config.activation_energy_j_mol / r_gas) * (1.0 / temp_k - 1.0 / temp_ref_k)).exp();
        
        // SOC dependence: resistance increases at lower state of charge
        let soc_factor = 1.0 + 0.3 * (1.0 - self.soc).powi(3);

        // Health dependency: resistance grows as SOH degrades
        let soh_factor = 1.0 + 1.5 * (1.0 - self.soh);

        self.config.r0_reference_ohm * arrhenius * soc_factor * soh_factor
    }

    /// Scientific Equation: Dynamic Terminal Voltage ($V_t$)
    ///
    /// ## Physical Law
    /// * Kirchhoff's Voltage Law: V_terminal = V_ocv - I * R_int - V_polarization
    ///
    /// ## Units
    /// * Return value: Volts (V)
    /// * current_a: Amperes (A) (positive = charging, negative = discharging)
    pub fn calculate_terminal_voltage(&self, current_a: f64) -> f64 {
        let ocv = self.calculate_ocv(self.soc);
        let resistance = self.calculate_resistance();
        
        // V = OCV + I * R (charging increases terminal voltage, discharging drops it)
        ocv + (current_a * resistance) - self.active_polarization_v
    }

    /// Scientific Equation: Bernardi Heat Generation Rate ($\dot{Q}_{\text{gen}}$)
    ///
    /// ## Physical Law
    /// * $\dot{Q} = I(V_{\text{ocv}} - V_t) - I T \frac{d V_{\text{ocv}}}{d T}$
    /// * Simplifies to Joule losses plus entropic heat generation under normal operation.
    ///
    /// ## Units
    /// * Return value: Watts (W) (Joules per second)
    pub fn calculate_heat_generation(&self, current_a: f64) -> f64 {
        let terminal_v = self.calculate_terminal_voltage(current_a);
        let ocv = self.calculate_ocv(self.soc);
        
        // Irreversible Joule heating
        let joule_heating = (current_a * (terminal_v - ocv)).abs();
        
        // Reversible entropic heating (approximation: dVocv/dT is typically negative)
        let entropic_coefficient = -0.0001; // V/K
        let temp_k = self.temperature_c + 273.15;
        let entropic_heating = current_a * temp_k * entropic_coefficient;

        // Total rate of thermal generation
        (joule_heating + entropic_heating).max(0.0)
    }

    /// State Update: Coulomb Counting and Dynamic Transient Polarization Integration
    pub fn update_state(&mut self, current_a: f64, dt_seconds: f64) -> Result<()> {
        // Integrate current to update state of charge (Coulomb Counting)
        // I = dQ/dt => Q = Q_0 + I * dt
        let capacity_as = self.config.nominal_capacity_ah * 3600.0; // Ah to Ampere-seconds
        let coulombic_efficiency = if current_a > 0.0 { 0.99 } else { 1.0 }; // minor charging loss
        
        let delta_soc = (current_a * coulombic_efficiency * dt_seconds) / capacity_as;
        self.soc = (self.soc + delta_soc).clamp(0.0, 1.0);

        // Update lifetime cumulative throughput
        self.cumulative_charge_ah += (current_a * dt_seconds).abs() / 3600.0;

        // Dynamic polarization relaxation (RC voltage-sag recovery approximation)
        let time_constant_rc = 20.0; // 20-second double-layer transient time constant
        let target_polarization = (current_a * 0.002).abs(); // dynamic polarization scaling
        self.active_polarization_v += (target_polarization - self.active_polarization_v) * (dt_seconds / time_constant_rc).min(1.0);

        // Update SOH periodically (degradation model)
        // Empirical resistance growth & capacity loss based on cumulative charge throughput
        let throughput_cycles = self.cumulative_charge_ah / self.config.nominal_capacity_ah;
        let degradation_rate = 0.00002; // SOH loss per equivalent full cycle
        self.soh = (1.0 - (throughput_cycles * degradation_rate)).clamp(0.0, 1.0);

        Ok(())
    }
}
