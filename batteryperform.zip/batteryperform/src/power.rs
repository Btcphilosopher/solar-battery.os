/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PowerEnvelope {
    pub theoretical_power_kw: f64,
    pub physically_available_power_kw: f64,
    pub thermally_available_power_kw: f64,
    pub safely_available_power_kw: f64,
    pub optimal_power_kw: f64,
}

/// Calculate multi-criteria power boundaries.
/// Distinguishes physical, thermal, safety and optimal power.
///
/// ## Physical Law
/// * P = V * I. Max physical power is limited by the maximum continuous discharge current and terminal voltage.
pub fn calculate_power_envelope(
    voltage_v: f64,
    min_voltage_v: f64,
    resistance_ohm: f64,
    current_limit_a: f64,
    temperature_c: f64,
    soc: f64,
) -> PowerEnvelope {
    // 1. Theoretical maximum power (matched load theorem, P_max = V_ocv^2 / 4R)
    let theoretical = (voltage_v.powi(2) / (4.0 * resistance_ohm)) / 1000.0;

    // 2. Physically available power (restricted by current limit and voltage sag cutoff)
    // Terminal voltage must not drop below min_voltage_v
    // I_max_voltage_limit = (V_ocv - V_min) / R
    let max_current_by_voltage = (voltage_v - min_voltage_v) / resistance_ohm;
    let physical_current = current_limit_a.min(max_current_by_voltage);
    let physical_v = voltage_v - (physical_current * resistance_ohm);
    let physically_available = (physical_v * physical_current) / 1000.0;

    // 3. Thermally available power (reduces limit if temperature is high to prevent overheating)
    let thermal_factor = if temperature_c > 50.0 {
        0.1 // Severe restriction
    } else if temperature_c > 40.0 {
        1.0 - (temperature_c - 40.0) / 10.0 // Linear scale-down
    } else {
        1.0
    };
    let thermally_available = physically_available * thermal_factor;

    // 4. Safely available power (accounts for SOC buffer and safety margins)
    let safety_margin = if soc < 0.15 {
        0.3 // Low reserve power
    } else if soc > 0.95 {
        0.8 // Limit charging stress at topmost ceiling
    } else {
        0.95
    };
    let safely_available = thermally_available * safety_margin;

    // 5. Optimal power (the point of maximum electrical efficiency, which is usually around 30% of peak)
    let optimal = safely_available * 0.70;

    PowerEnvelope {
        theoretical_power_kw: theoretical,
        physically_available_power_kw: physically_available,
        thermally_available_power_kw: thermally_available,
        safely_available_power_kw: safely_available,
        optimal_power_kw: optimal,
    }
}
