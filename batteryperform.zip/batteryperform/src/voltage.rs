/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

use serde::{Serialize, Deserialize};

/// Mathematical model of cell voltage recovery.
/// Voltage recovery is transient: V(t) = V_ocv - I*R_int - V_pol * exp(-t / tau)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VoltageRecoveryProfile {
    pub time_constant_seconds: f64,
    pub residual_sag_v: f64,
}

impl Default for VoltageRecoveryProfile {
    fn default() -> Self {
        Self {
            time_constant_seconds: 15.0,
            residual_sag_v: 0.0,
        }
    }
}

/// Calculate dynamic voltage sag.
/// Sag is the difference between Open-Circuit Voltage and actual Terminal Voltage.
///
/// ## Assumptions
/// * Purely ohmic drop plus double-layer polarisation.
/// * Linear superposition of current steps.
///
/// ## Units
/// * Return value: Volts (V)
pub fn calculate_voltage_sag(ocv_v: f64, terminal_v: f64) -> f64 {
    (ocv_v - terminal_v).max(0.0)
}

/// Estimate recovery voltage after load removal.
pub fn estimate_voltage_recovery(
    initial_sag_v: f64,
    elapsed_time_seconds: f64,
    profile: &VoltageRecoveryProfile
) -> f64 {
    initial_sag_v * (-elapsed_time_seconds / profile.time_constant_seconds).exp()
}
