/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TelemetryPayload {
    pub timestamp: i64,
    pub battery_id: String,
    pub soc: f64,
    pub soh: f64,
    pub terminal_voltage_v: f64,
    pub current_a: f64,
    pub average_temperature_c: f64,
    pub internal_resistance_ohm: f64,
    pub optimization_index: f64,
    pub selected_current_a: f64,
}
