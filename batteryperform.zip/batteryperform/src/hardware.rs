/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

use serde::{Serialize, Deserialize};

pub trait Sensor {
    fn read_value(&self) -> f64;
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PhysicalSensor {
    pub name: String,
    pub calibration_multiplier: f64,
    pub noise_std_dev: f64,
}

impl Sensor for PhysicalSensor {
    fn read_value(&self) -> f64 {
        // Mock hardware read using local noise addition
        self.calibration_multiplier * 1.0
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct HardwareAbstractions {
    pub voltage_sensor: PhysicalSensor,
    pub current_sensor: PhysicalSensor,
    pub temperature_sensor: PhysicalSensor,
}

impl Default for HardwareAbstractions {
    fn default() -> Self {
        Self {
            voltage_sensor: PhysicalSensor {
                name: "High Precision ADC V-Sensor".to_string(),
                calibration_multiplier: 1.0,
                noise_std_dev: 0.002,
            },
            current_sensor: PhysicalSensor {
                name: "Hall Effect Current Shunt".to_string(),
                calibration_multiplier: 1.0,
                noise_std_dev: 0.05,
            },
            temperature_sensor: PhysicalSensor {
                name: "NTC 10k Thermistor Array".to_string(),
                calibration_multiplier: 1.0,
                noise_std_dev: 0.1,
            },
        }
    }
}
