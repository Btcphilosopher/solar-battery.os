/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExtendedKalmanFilterState {
    pub x_soc: f64,              // Estimated State of Charge [0..1]
    pub p_covariance: f64,       // Estimation covariance matrix element
    pub r_measurement_noise: f64, // Voltage measurement noise variance
    pub q_process_noise: f64,     // Current integration process noise variance
}

impl Default for ExtendedKalmanFilterState {
    fn default() -> Self {
        Self {
            x_soc: 0.6,
            p_covariance: 0.01,
            r_measurement_noise: 0.005,
            q_process_noise: 0.0001,
        }
    }
}

/// Dynamic EKF Step.
/// Corrects Coulomb-counted SOC using measured terminal voltage.
///
/// ## Assumptions
/// * Cell is in local quasi-equilibrium.
/// * OCV curve derivative dVocv/dSOC is locally linear.
pub fn predict_and_correct_ekf(
    ekf: &mut ExtendedKalmanFilterState,
    measured_v: f64,
    current_a: f64,
    dt_seconds: f64,
    nominal_capacity_as: f64,
    ocv_by_soc_fn: fn(f64) -> f64,
    docv_dsoc_fn: fn(f64) -> f64,
    internal_resistance_ohm: f64,
) {
    // 1. Time Update (Prediction)
    // x_hat_minus = x + (I * dt) / Cap
    let delta_soc = (current_a * dt_seconds) / nominal_capacity_as;
    let mut x_hat = (ekf.x_soc + delta_soc).clamp(0.0, 1.0);
    
    // P_minus = P + Q
    let mut p_cov = ekf.p_covariance + ekf.q_process_noise;

    // 2. Measurement Update (Correction)
    // h(x) = V_ocv(x) + I * R
    let predicted_v = ocv_by_soc_fn(x_hat) + (current_a * internal_resistance_ohm);
    
    // H = d h(x) / d x = d V_ocv / d SOC
    let h_jacobian = docv_dsoc_fn(x_hat);

    // K = P * H' * inv(H * P * H' + R)
    let s_innovation_covariance = h_jacobian * p_cov * h_jacobian + ekf.r_measurement_noise;
    let kalman_gain = (p_cov * h_jacobian) / s_innovation_covariance;

    // x_hat = x_hat + K * (measured_v - predicted_v)
    let innovation = measured_v - predicted_v;
    x_hat = (x_hat + kalman_gain * innovation).clamp(0.0, 1.0);

    // P = (1 - K * H) * P
    p_cov = (1.0 - kalman_gain * h_jacobian) * p_cov;

    ekf.x_soc = x_hat;
    ekf.p_covariance = p_cov;
}
