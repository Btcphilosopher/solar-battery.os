/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DynamicResistanceModel {
    pub base_resistance_ohm: f64,
    pub temperature_reference_k: f64,
    pub activation_energy_j_mol: f64,
}

impl Default for DynamicResistanceModel {
    fn default() -> Self {
        Self {
            base_resistance_ohm: 0.015,
            temperature_reference_k: 298.15, // 25°C
            activation_energy_j_mol: 22000.0,
        }
    }
}

/// Calculate dynamic cell resistance based on temperature and State of Health.
/// Uses Arrhenius chemical kinetics approximation.
///
/// ## Units
/// * Return value: Ohms (Ω)
pub fn calculate_dynamic_resistance(
    temp_c: f64,
    soh: f64,
    model: &DynamicResistanceModel
) -> f64 {
    let r_gas = 8.314;
    let temp_k = temp_c + 273.15;
    
    // Arrhenius equation
    let exponential = ((model.activation_energy_j_mol / r_gas) 
        * (1.0 / temp_k - 1.0 / model.temperature_reference_k)).exp();
    
    // Resistance growth as health degrades (exponential trend near end-of-life)
    let degradation_multiplier = 1.0 + 2.0 * (1.0 - soh).powi(2);

    model.base_resistance_ohm * exponential * degradation_multiplier
}
