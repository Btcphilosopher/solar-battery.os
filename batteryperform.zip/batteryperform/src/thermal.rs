/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ThermalSystemConfig {
    pub ambient_temp_c: f64,
    pub heat_transfer_coeff_w_m2k: f64,
    pub active_coolant_temp_c: f64,
    pub coolant_specific_heat_j_kgk: f64,
    pub coolant_pump_power_w: f64,
}

impl Default for ThermalSystemConfig {
    fn default() -> Self {
        Self {
            ambient_temp_c: 25.0,
            heat_transfer_coeff_w_m2k: 15.0, // Forced air cooling
            active_coolant_temp_c: 20.0,
            coolant_specific_heat_j_kgk: 4184.0, // Water
            coolant_pump_power_w: 150.0, // Consumed pump power
        }
    }
}

/// Calculate the thermal-electrical coupling feedback.
/// As temperature rises, cell resistance drops, reducing heat generation.
/// But high temperature triggers cooling energy, which reduces net system efficiency.
pub fn calculate_thermal_equilibrium(
    cell_temp_c: f64,
    heat_gen_w: f64,
    coolant_flow_rate_l_s: f64,
    config: &ThermalSystemConfig
) -> (f64, f64) {
    // Heat removed by coolant = flow * density * specific_heat * (T_cell - T_cool)
    let density_water = 1.0; // kg/L
    let thermal_conductance = coolant_flow_rate_l_s * density_water * config.coolant_specific_heat_j_kgk * 0.05; // effective thermal exchange factor
    let heat_removed_w = thermal_conductance * (cell_temp_c - config.active_coolant_temp_c);
    
    let net_heat_w = heat_gen_w - heat_removed_w;
    
    // Net energy penalty of running the cooling system
    let pump_parasitic_w = config.coolant_pump_power_w * (coolant_flow_rate_l_s / 2.0).powi(3); // cubic relationship for pumping losses

    (net_heat_w, pump_parasitic_w)
}
