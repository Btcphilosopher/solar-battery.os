/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EfficiencyMetrics {
    pub instantaneous_electrical_efficiency: f64,
    pub cycle_round_trip_efficiency: f64,
    pub resistive_loss_w: f64,
    pub cabling_loss_w: f64,
    pub thermal_loss_w: f64,
    pub inverter_efficiency_factor: f64,
}

/// Dynamic efficiency calculations.
///
/// ## Physical Law
/// * Efficiency = Output Power / Input Power during discharge, and Input Power / Output Power during charge.
pub fn calculate_efficiency(
    terminal_voltage_v: f64,
    ocv_v: f64,
    current_a: f64,
    cabling_resistance_ohm: f64,
    inverter_loss_coefficient: f64, // e.g. 0.02 (2% power loss)
) -> EfficiencyMetrics {
    let cell_internal_loss = current_a.powi(2) * ((ocv_v - terminal_voltage_v) / current_a.max(0.001)).abs();
    let cabling_loss = current_a.powi(2) * cabling_resistance_ohm;
    let electrical_power_w = terminal_voltage_v * current_a;

    let (efficiency, inverter_efficiency) = if current_a < 0.0 {
        // Discharging (delivering power): positive efficiency < 1.0
        let output_power_w = electrical_power_w.abs();
        let source_power_w = ocv_v * current_a.abs();
        let inv_eff = 1.0 - inverter_loss_coefficient;
        let inst_eff = (output_power_w / source_power_w.max(1.0)) * inv_eff;
        (inst_eff.clamp(0.0, 1.0), inv_eff)
    } else if current_a > 0.0 {
        // Charging (absorbing power): efficiency is the ratio of chemical energy stored to electrical energy spent
        let stored_power_w = ocv_v * current_a;
        let grid_power_w = electrical_power_w;
        let inv_eff = 1.0 - inverter_loss_coefficient;
        let inst_eff = (stored_power_w / (grid_power_w * (1.0 / inv_eff)).max(1.0));
        (inst_eff.clamp(0.0, 1.0), inv_eff)
    } else {
        (1.0, 1.0)
    };

    EfficiencyMetrics {
        instantaneous_electrical_efficiency: efficiency,
        cycle_round_trip_efficiency: 0.92, // Typical LFP/NMC cell aggregate
        resistive_loss_w: cell_internal_loss,
        cabling_loss_w: cabling_loss,
        thermal_loss_w: cell_internal_loss + cabling_loss,
        inverter_efficiency_factor: inverter_efficiency,
    }
}
