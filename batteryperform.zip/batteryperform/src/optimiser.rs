/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum OptimisationProfile {
    MaxPower,
    MaxEfficiency,
    MaxLongevity,
    Balanced,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OptimisationInput {
    pub power_demand_kw: f64,
    pub pack_soc: f64,
    pub pack_voltage_v: f64,
    pub pack_temperature_c: f64,
    pub pack_resistance_ohm: f64,
    pub max_voltage_v: f64,
    pub min_voltage_v: f64,
    pub max_current_a: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OptimisationDecision {
    pub selected_current_a: f64,
    pub predicted_output_power_kw: f64,
    pub predicted_efficiency: f64,
    pub expected_heat_generation_w: f64,
    pub recommended_cooling_flow_l_s: f64,
    pub performance_index: f64,
    pub rationale: String,
}

/// Optimisation Engine: Maximises useful electrical output per unit loss.
pub fn run_optimisation(
    input: &OptimisationInput,
    profile: OptimisationProfile
) -> OptimisationDecision {
    // We search over candidate currents to find the optimum under the profile constraints
    let num_candidates = 50;
    let min_c = -input.max_current_a; // discharging
    let max_c = input.max_current_a;  // charging
    
    let mut best_current = 0.0;
    let mut best_score = -f64::INFINITY;
    let mut best_power = 0.0;
    let mut best_eff = 0.0;
    let mut best_heat = 0.0;
    let mut best_cool = 0.0;
    let mut best_rationale = String::new();

    for i in 0..=num_candidates {
        let fraction = i as f64 / num_candidates as f64;
        let candidate_current = min_c + fraction * (max_c - min_c);
        
        // Respect terminal voltage limits: V_terminal = V_ocv - I * R
        let terminal_voltage = input.pack_voltage_v + candidate_current * input.pack_resistance_ohm;
        if terminal_voltage < input.min_voltage_v || terminal_voltage > input.max_voltage_v {
            continue; // violates physical boundaries
        }

        // Calculate power & losses
        let power_kw = (terminal_voltage * candidate_current) / 1000.0;
        let joule_losses_w = candidate_current.powi(2) * input.pack_resistance_ohm;
        
        // Efficiency
        let efficiency = if candidate_current < 0.0 {
            // discharge
            let power_delivered_kw = power_kw.abs();
            let ocv_power_kw = (input.pack_voltage_v * candidate_current.abs()) / 1000.0;
            (power_delivered_kw / ocv_power_kw.max(0.1)).clamp(0.0, 1.0)
        } else if candidate_current > 0.0 {
            // charge
            let chemical_stored_kw = (input.pack_voltage_v * candidate_current) / 1000.0;
            (chemical_stored_kw / power_kw.max(0.1)).clamp(0.0, 1.0)
        } else {
            1.0
        };

        // Heat & cooling required
        let cooling_flow = if joule_losses_w > 500.0 {
            0.5 + (joule_losses_w - 500.0) / 1000.0
        } else {
            0.1
        }.clamp(0.1, 5.0);

        // Score formulation based on selected profile
        let score = match profile {
            OptimisationProfile::MaxPower => {
                // Heavily weight power output, minor weight on loss
                let power_utility = power_kw.abs();
                let loss_penalty = 0.001 * joule_losses_w;
                power_utility - loss_penalty
            }
            OptimisationProfile::MaxEfficiency => {
                // Heavily penalise losses, prefer currents near maximum efficiency
                let efficiency_utility = efficiency * 100.0;
                let thermal_penalty = if input.pack_temperature_c > 35.0 { 2.0 } else { 0.0 };
                efficiency_utility - thermal_penalty
            }
            OptimisationProfile::MaxLongevity => {
                // Prioritize low heat and moderate currents
                let current_penalty = 0.1 * candidate_current.abs();
                let temperature_penalty = 0.5 * (input.pack_temperature_c - 25.0).max(0.0).powi(2);
                -current_penalty - temperature_penalty
            }
            OptimisationProfile::Balanced => {
                // Balanced blend of power delivery, loss mitigation, and thermals
                let power_utility = 2.0 * power_kw.abs();
                let loss_penalty = 0.005 * joule_losses_w;
                let temperature_penalty = 0.1 * (input.pack_temperature_c - 25.0).max(0.0).powi(2);
                power_utility - loss_penalty - temperature_penalty
            }
        };

        if score > best_score {
            best_score = score;
            best_current = candidate_current;
            best_power = power_kw;
            best_eff = efficiency;
            best_heat = joule_losses_w;
            best_cool = cooling_flow;
        }
    }

    best_rationale = match profile {
        OptimisationProfile::MaxPower => {
            format!("Selected {:.1}A to maximize power output ({:.1}kW) despite high thermal losses ({:.1}W).", best_current, best_power.abs(), best_heat)
        }
        OptimisationProfile::MaxEfficiency => {
            format!("Optimized current to {:.1}A to achieve {:.1}% efficiency, reducing thermal stresses.", best_current, best_eff * 100.0)
        }
        OptimisationProfile::MaxLongevity => {
            format!("Limited current to {:.1}A to lower temperatures ({:.1}°C) and arrest resistance growth.", best_current, input.pack_temperature_c)
        }
        OptimisationProfile::Balanced => {
            format!("Balanced point chosen at {:.1}A for {:.1}kW output with safe thermal dissipation.", best_current, best_power.abs())
        }
    };

    // Composite Performance Index (0.0 to 1.0)
    let power_score = (best_power.abs() / (input.max_current_a * input.pack_voltage_v / 1000.0).max(1.0)).clamp(0.0, 1.0);
    let temp_score = (1.0 - (input.pack_temperature_c - 25.0).max(0.0) / 45.0).clamp(0.0, 1.0);
    let performance_index = (power_score * 0.3 + best_eff * 0.4 + temp_score * 0.3);

    OptimisationDecision {
        selected_current_a: best_current,
        predicted_output_power_kw: best_power,
        predicted_efficiency: best_eff,
        expected_heat_generation_w: best_heat,
        recommended_cooling_flow_l_s: best_cool,
        performance_index,
        rationale: best_rationale,
    }
}
