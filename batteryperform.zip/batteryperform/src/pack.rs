/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

use serde::{Serialize, Deserialize};
use crate::module::{Module, ModuleConfig};
use crate::cell::CellConfig;
use crate::error::Result;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PackConfig {
    pub modules_in_series: usize,
    pub pack_coolant_flow_m3_s: f64, // Cooling flow rate, m^3/s
    pub contactor_state_closed: bool,
}

impl Default for PackConfig {
    fn default() -> Self {
        Self {
            modules_in_series: 8, // 8 modules in series
            pack_coolant_flow_m3_s: 0.002, // 2 Litres per second
            contactor_state_closed: true,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Pack {
    pub config: PackConfig,
    pub modules: Vec<Module>,
    pub overall_soc: f64,
    pub overall_soh: f64,
    pub thermal_coolant_temp_c: f64, // Entrance coolant temperature
}

impl Pack {
    pub fn new(config: PackConfig, module_config: ModuleConfig, cell_config: CellConfig) -> Self {
        let mut modules = Vec::with_capacity(config.modules_in_series);
        let mut cell_start_id = 1;
        let cells_per_module = module_config.cells_in_series * module_config.cells_in_parallel;

        for i in 0..config.modules_in_series {
            modules.push(Module::new(i + 1, cell_start_id, module_config.clone(), cell_config.clone()));
            cell_start_id += cells_per_module;
        }

        Self {
            config,
            modules,
            overall_soc: 0.6,
            overall_soh: 1.0,
            thermal_coolant_temp_c: 20.0,
        }
    }

    /// Calculate combined pack voltage (series summation across modules)
    pub fn calculate_voltage(&self, current_a: f64) -> f64 {
        if !self.config.contactor_state_closed {
            return 0.0;
        }
        let mut voltage = 0.0;
        for module in &self.modules {
            voltage += module.calculate_voltage(current_a);
        }
        voltage
    }

    /// Calculate aggregate pack resistance (sum of series modules)
    pub fn calculate_resistance(&self) -> f64 {
        let mut r = 0.0;
        for module in &self.modules {
            r += module.calculate_resistance();
        }
        r
    }

    /// Update pack-level state estimation and thermal cooling flows
    pub fn update_states(&mut self, current_a: f64, dt_seconds: f64) -> Result<()> {
        if !self.config.contactor_state_closed {
            return Ok(());
        }

        // 1. Update internal cell states (current flow, SOC, degradation)
        for module in &mut self.modules {
            module.update_states(current_a, dt_seconds)?;
        }

        // 2. Perform thermal cooling integration across modules
        // Equation: T_next = T + dt * (Q_gen - Q_cool) / C_thermal
        // And coolant carries heat along the flow: T_cool increases as it flows through modules
        let mut coolant_temp = self.thermal_coolant_temp_c;
        let flow_rate = self.config.pack_coolant_flow_m3_s;
        let density_water = 1000.0; // kg/m^3
        let specific_heat_water = 4184.0; // J/(kg*K)
        let thermal_capacitance_coolant = flow_rate * density_water * specific_heat_water; // W/K

        for module in &mut self.modules {
            for cell in &mut module.cells {
                let heat_gen = cell.calculate_heat_generation(current_a);
                
                // Heat exchange with coolant
                // h * A coefficient approximated as 12.0 W/K
                let heat_transfer_coefficient_w_k = 12.0; 
                let heat_removed = heat_transfer_coefficient_w_k * (cell.temperature_c - coolant_temp);
                
                // Net heat accumulation in cell
                let net_heat = heat_gen - heat_removed;
                
                // Update cell temperature (T_next = T + dt * Q_net / C_thermal)
                let delta_t = (net_heat * dt_seconds) / cell.config.thermal_capacity_j_k;
                cell.temperature_c += delta_t;
                
                // Update coolant temperature as it picks up thermal energy
                if thermal_capacitance_coolant > 0.0 {
                    coolant_temp += heat_removed / thermal_capacitance_coolant;
                }
            }
        }

        // 3. Aggregate overall Pack SOC and SOH (weighted mean)
        let mut sum_soc = 0.0;
        let mut sum_soh = 0.0;
        let mut total_cells = 0;
        for module in &self.modules {
            for cell in &module.cells {
                sum_soc += cell.soc;
                sum_soh += cell.soh;
                total_cells += 1;
            }
        }

        if total_cells > 0 {
            self.overall_soc = sum_soc / total_cells as f64;
            self.overall_soh = sum_soh / total_cells as f64;
        }

        Ok(())
    }

    /// Identify the single absolute limiting bottleneck Cell in the pack
    pub fn get_bottleneck_cell(&self) -> (usize, usize, String) {
        let mut min_soc = 1.0;
        let mut max_temp = 0.0;
        let mut max_res = 0.0;
        
        let mut low_soc_id = (0, 0);
        let mut hot_cell_id = (0, 0);
        let mut high_res_id = (0, 0);

        for module in &self.modules {
            for cell in &module.cells {
                if cell.soc < min_soc {
                    min_soc = cell.soc;
                    low_soc_id = (module.id, cell.id);
                }
                if cell.temperature_c > max_temp {
                    max_temp = cell.temperature_c;
                    hot_cell_id = (module.id, cell.id);
                }
                let res = cell.calculate_resistance();
                if res > max_res {
                    max_res = res;
                    high_res_id = (module.id, cell.id);
                }
            }
        }

        // If pack is cold/normal, low SOC dictates discharging cutoff;
        // If pack is hot, the hottest cell restricts charging or power limits.
        if max_temp > 45.0 {
            (hot_cell_id.0, hot_cell_id.1, format!("Thermal limit reached: {}°C", max_temp))
        } else if max_res > 0.02 {
            (high_res_id.0, high_res_id.1, format!("High dynamic resistance: {:.4} Ω", max_res))
        } else {
            (low_soc_id.0, low_soc_id.1, format!("Low capacity bottleneck: {:.1}% SOC", min_soc * 100.0))
        }
    }
}
