/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

mod error;
mod cell;
mod module;
mod pack;
mod electrical;
mod voltage;
mod current;
mod resistance;
mod power;
mod thermal;
mod efficiency;
mod state_estimator;
mod optimiser;
mod controller;
mod simulation;
mod telemetry;
mod hardware;
mod safety;

use pack::{Pack, PackConfig};
use module::ModuleConfig;
use cell::CellConfig;
use simulation::{run_simulation_step, SimulationScenario};
use optimiser::OptimisationProfile;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    // 1. Initialize Logging Framework
    tracing_subscriber::fmt()
        .with_env_filter(tracing_subscriber::EnvFilter::from_default_env().add_directive(tracing::Level::INFO.into()))
        .init();

    tracing::info!("Initializing BATTERYPERFORM Optimisation Engine...");

    // 2. Load Core Batteries Configuration
    let cell_config = CellConfig::default();
    let module_config = ModuleConfig::default();
    let pack_config = PackConfig::default();

    let mut pack = Pack::new(pack_config, module_config, cell_config);

    // 3. Define the Optimisation Scenario (BALANCED optimization)
    let scenario = SimulationScenario {
        name: "Urban EV Profile Cycle".to_string(),
        step_size_s: 1.0,
        total_steps: 10,
        profile: OptimisationProfile::Balanced,
        initial_power_demand_kw: 310.0,
    };

    tracing::info!("Running scenario: {} (Profile: {:?})", scenario.name, scenario.profile);

    // 4. Run the Real-time Optimization Loop
    let mut current_demand = scenario.initial_power_demand_kw;
    for step in 1..=scenario.total_steps {
        // Vary the demand slightly to simulate dynamic accelerating loads
        let time_factor = (step as f64 * 0.5).sin();
        let step_demand = current_demand + (time_factor * 40.0);

        match run_simulation_step(&mut pack, step, &scenario, step_demand) {
            Ok(result) => {
                println!("--------------------------------------------------");
                println!("BATTERYPERFORM Step {}", result.step);
                println!("SOC                 {:.2}%", result.pack_soc * 100.0);
                println!("SOH                 {:.2}%", pack.overall_soh * 100.0);
                println!("VOLTAGE             {:.2} V", result.pack_voltage_v);
                println!("CURRENT             {:.1} A", result.pack_current_a);
                println!("POWER               {:.1} kW", result.pack_power_kw);
                println!("TEMPERATURE         {:.2}°C", result.hottest_temp_c);
                println!("RESISTANCE          {:.5} Ω", pack.calculate_resistance());
                println!("EFFICIENCY          {:.1}%", result.system_efficiency * 100.0);
                println!("VOLTAGE SAG         {:.2} V", (pack.calculate_voltage(0.0) - result.pack_voltage_v).max(0.0));
                println!("PERFORMANCE INDEX   {:.1}%", result.optimal_decision.performance_index * 100.0);
                println!("RATIONALE           {}", result.optimal_decision.rationale);
            }
            Err(e) => {
                tracing::error!("Loop calculation failure on step {}: {}", step, e);
                break;
            }
        }
    }

    tracing::info!("BATTERYPERFORM Execution completed successfully.");
    Ok(())
}
