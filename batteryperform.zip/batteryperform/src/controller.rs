/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

use serde::{Serialize, Deserialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ControllerCommand {
    pub active_balancing_channel_mask: u64,
    pub pump_speed_rpm: f64,
    pub target_charge_current_a: f64,
}

/// Dynamic charging profile controller (Multi-stage CC-CV).
pub fn compute_charging_commands(
    pack_soc: f64,
    max_cell_v: f64,
    hottest_temp_c: f64,
    nominal_capacity_ah: f64
) -> ControllerCommand {
    let mut command = ControllerCommand {
        active_balancing_channel_mask: 0,
        pump_speed_rpm: 800.0,
        target_charge_current_a: 0.0,
    };

    // Constant Current (CC) -> Constant Voltage (CV) controller logic
    if pack_soc < 0.8 && max_cell_v < 4.1 {
        // Constant Current Stage (0.5C charging)
        command.target_charge_current_a = nominal_capacity_ah * 1.5;
    } else if max_cell_v >= 4.1 && max_cell_v < 4.2 {
        // Constant Voltage Stage (reduce current exponentially)
        let voltage_headroom = 4.2 - max_cell_v;
        command.target_charge_current_a = nominal_capacity_ah * 1.5 * (voltage_headroom / 0.1).max(0.05);
    } else {
        // Trickle/Cutoff stage
        command.target_charge_current_a = nominal_capacity_ah * 0.02;
    }

    // Active Thermal management pump speed control
    if hottest_temp_c > 45.0 {
        command.pump_speed_rpm = 3000.0; // Max speed
    } else if hottest_temp_c > 35.0 {
        command.pump_speed_rpm = 1500.0 + (hottest_temp_c - 35.0) * 150.0;
    }

    command
}
