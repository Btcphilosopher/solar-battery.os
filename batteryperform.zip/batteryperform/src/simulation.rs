/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

use serde::{Serialize, Deserialize};
use crate::pack::Pack;
use crate::optimiser::{run_optimisation, OptimisationInput, OptimisationProfile, OptimisationDecision};
use crate::error::Result;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SimulationScenario {
    pub name: String,
    pub step_size_s: f64,
    pub total_steps: usize,
    pub profile: OptimisationProfile,
    pub initial_power_demand_kw: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SimulationStepResult {
    pub step: usize,
    pub pack_soc: f64,
    pub pack_voltage_v: f64,
    pub pack_current_a: f64,
    pub pack_power_kw: f64,
    pub hottest_temp_c: f64,
    pub system_efficiency: f64,
    pub optimal_decision: OptimisationDecision,
}

pub fn run_simulation_step(
    pack: &mut Pack,
    step: usize,
    scenario: &SimulationScenario,
    current_power_demand_kw: f64
) -> Result<SimulationStepResult> {
    // 1. Gather dynamic pack properties
    let resistance = pack.calculate_resistance();
    let current_v = pack.calculate_voltage(0.0);
    
    // Extract hottest temperature in pack
    let mut max_temp = -273.15;
    for m in &pack.modules {
        for c in &m.cells {
            if c.temperature_c > max_temp {
                max_temp = c.temperature_c;
            }
        }
    }

    // 2. Formulate optimization input
    let opt_input = OptimisationInput {
        power_demand_kw: current_power_demand_kw,
        pack_soc: pack.overall_soc,
        pack_voltage_v: current_v,
        pack_temperature_c: max_temp,
        pack_resistance_ohm: resistance,
        max_voltage_v: 830.0, // Upper battery limit
        min_voltage_v: 600.0, // Lower cutoff limit
        max_current_a: 400.0,
    };

    // 3. Solve the optimization problem
    let decision = run_optimisation(&opt_input, scenario.profile);

    // 4. Inject physical outcome of optimization decisions back into pack physics
    pack.update_states(decision.selected_current_a, scenario.step_size_s)?;

    // 5. Package results
    let updated_voltage = pack.calculate_voltage(decision.selected_current_a);
    let power_kw = (updated_voltage * decision.selected_current_a) / 1000.0;

    Ok(SimulationStepResult {
        step,
        pack_soc: pack.overall_soc,
        pack_voltage_v: updated_voltage,
        pack_current_a: decision.selected_current_a,
        pack_power_kw: power_kw,
        hottest_temp_c: max_temp,
        system_efficiency: decision.predicted_efficiency,
        optimal_decision: decision,
    })
}
