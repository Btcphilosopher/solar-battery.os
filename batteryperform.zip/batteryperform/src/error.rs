use thiserror::Error;

#[derive(Error, Debug)]
pub enum BatteryError {
    #[error("Safety violation: {0}")]
    SafetyViolation(String),

    #[error("Thermal runaway warning: temperature {0:.2}°C exceeds safe threshold!")]
    ThermalRunaway(f64),

    #[error("Voltage out of bounds: cell {cell_id} voltage {voltage:.3}V is outside safe range [{min_v:.2}V, {max_v:.2}V]")]
    VoltageOutOfBounds {
        cell_id: usize,
        voltage: f64,
        min_v: f64,
        max_v: f64,
    },

    #[error("Current out of bounds: {current:.2}A exceeds maximum safe current {max_c:.2}A")]
    CurrentOutOfBounds {
        current: f64,
        max_c: f64,
    },

    #[error("SOC out of bounds: state of charge {0:.2}% is invalid")]
    SocOutOfBounds(f64),

    #[error("Database error: {0}")]
    DatabaseError(String),

    #[error("Configuration error: {0}")]
    ConfigError(String),

    #[error("Optimisation failure: {0}")]
    OptimisationError(String),
}

pub type Result<T> = std::result::Result<T, BatteryError>;
