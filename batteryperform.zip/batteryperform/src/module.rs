/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

use serde::{Serialize, Deserialize};
use crate::cell::{Cell, CellConfig};
use crate::error::Result;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ModuleConfig {
    pub cells_in_series: usize,
    pub cells_in_parallel: usize,
}

impl Default for ModuleConfig {
    fn default() -> Self {
        Self {
            cells_in_series: 12, // 12S module
            cells_in_parallel: 1, // Single string by default
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Module {
    pub id: usize,
    pub config: ModuleConfig,
    pub cells: Vec<Cell>,
}

impl Module {
    pub fn new(id: usize, cell_start_id: usize, config: ModuleConfig, cell_config: CellConfig) -> Self {
        let total_cells = config.cells_in_series * config.cells_in_parallel;
        let mut cells = Vec::with_capacity(total_cells);
        for i in 0..total_cells {
            cells.push(Cell::new(cell_start_id + i, cell_config.clone()));
        }
        Self { id, config, cells }
    }

    /// Calculate combined module terminal voltage (series addition)
    pub fn calculate_voltage(&self, current_a: f64) -> f64 {
        let mut total_voltage = 0.0;
        // In a series-connected module, cell voltages add up.
        // Parallel cell groups are modeled by adjusting the configuration if needed.
        for cell in &self.cells {
            total_voltage += cell.calculate_terminal_voltage(current_a / self.config.cells_in_parallel as f64);
        }
        total_voltage
    }

    /// Calculate aggregate module resistance (combination of series/parallel)
    pub fn calculate_resistance(&self) -> f64 {
        let mut total_r = 0.0;
        for cell in &self.cells {
            total_r += cell.calculate_resistance();
        }
        total_r / (self.config.cells_in_parallel as f64)
    }

    /// Compute cell variations (imbalances) for BMS control
    pub fn get_imbalances(&self) -> ModuleImbalance {
        if self.cells.is_empty() {
            return ModuleImbalance::default();
        }
        
        let mut min_v = f64::MAX;
        let mut max_v = f64::MIN;
        let mut min_temp = f64::MAX;
        let mut max_temp = f64::MIN;
        let mut min_soc = f64::MAX;
        let mut max_soc = f64::MIN;

        for cell in &self.cells {
            let vt = cell.calculate_terminal_voltage(0.0);
            if vt < min_v { min_v = vt; }
            if vt > max_v { max_v = vt; }

            if cell.temperature_c < min_temp { min_temp = cell.temperature_c; }
            if cell.temperature_c > max_temp { max_temp = cell.temperature_c; }

            if cell.soc < min_soc { min_soc = cell.soc; }
            if cell.soc > max_soc { max_soc = cell.soc; }
        }

        ModuleImbalance {
            voltage_spread_v: max_v - min_v,
            temp_spread_c: max_temp - min_temp,
            soc_spread: max_soc - min_soc,
            weakest_cell_id: self.cells.iter()
                .min_by(|a, b| a.soc.partial_cmp(&b.soc).unwrap())
                .map(|c| c.id)
                .unwrap_or(0),
            hottest_cell_id: self.cells.iter()
                .max_by(|a, b| a.temperature_c.partial_cmp(&b.temperature_c).unwrap())
                .map(|c| c.id)
                .unwrap_or(0),
        }
    }

    pub fn update_states(&mut self, current_a: f64, dt_seconds: f64) -> Result<()> {
        let cell_current = current_a / self.config.cells_in_parallel as f64;
        for cell in &mut self.cells {
            cell.update_state(cell_current, dt_seconds)?;
        }
        Ok(())
    }
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct ModuleImbalance {
    pub voltage_spread_v: f64,
    pub temp_spread_c: f64,
    pub soc_spread: f64,
    pub weakest_cell_id: usize,
    pub hottest_cell_id: usize,
}
