/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

use serde::{Serialize, Deserialize};

/// Dynamic charge and discharge current envelopes.
/// Determined from experimental boundaries (e.g. Lithium plating threshold during charging).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DynamicCurrentEnvelope {
    pub max_continuous_charge_a: f64,
    pub max_peak_charge_a: f64,
    pub max_continuous_discharge_a: f64,
    pub max_peak_discharge_a: f64,
}

/// Scientific Equation: Lithium Plating Charging Current Safety Boundary
///
/// ## Assumptions
/// * Solid-state diffusion limits the rate of Lithium insertion into anode at low temperatures.
/// * Exceeding this boundary causes metallic Lithium plating on graphite, increasing fire risks and degradation.
///
/// ## Units
/// * Return value: Amperes (A)
pub fn calculate_safe_charge_current_limit(
    temperature_c: f64,
    soc: f64,
    nominal_capacity_ah: f64
) -> f64 {
    // Standard empirical NMC/Graphite safety curves
    let temperature_factor = if temperature_c < 0.0 {
        0.05 // Severe reduction under freezing
    } else if temperature_c < 10.0 {
        0.2
    } else if temperature_c < 25.0 {
        0.6
    } else if temperature_c < 45.0 {
        1.0 // Optimum charging temperature window
    } else {
        0.4 // Reduce at extreme heat to mitigate runaway
    };

    let soc_factor = if soc < 0.2 {
        1.0 // Can absorb high charge at low SOC
    } else if soc < 0.7 {
        0.8
    } else if soc < 0.9 {
        0.4
    } else {
        0.1 // Trickle charge at high SOC to prevent overvoltage
    };

    // Standard 3C max charge rate mapped to nominal capacity
    nominal_capacity_ah * 3.0 * temperature_factor * soc_factor
}
