/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(express.json());

const PORT = 3000;

// Lazy initialization of Gemini client
let aiClient: any = null;
function getAIClient() {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is missing. Configure it in the Secrets panel.");
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// 1. API: Electrochemical advisor endpoint
app.post("/api/gemini/explain", async (req, res) => {
  try {
    const { profile, soc, soh, voltage, current, temperature, resistance, power, efficiency, bottleneckReason } = req.body;
    
    const ai = getAIClient();
    const prompt = `
You are BATTERYPERFORM Electrochemical AI Advisor, an expert industrial energy scientist and quantitative battery modeler.
Analyze the following live telemetry from a lithium-ion battery system pack:

- Optimization Profile Preset: ${profile}
- State of Charge (SOC): ${(soc * 100).toFixed(1)}%
- State of Health (SOH): ${(soh * 100).toFixed(1)}%
- Pack Terminal Voltage: ${voltage.toFixed(1)} V
- Pack Optimized Current: ${current.toFixed(1)} A
- Pack Output Power: ${power.toFixed(1)} kW
- Hottest Cell Temperature: ${temperature.toFixed(1)} °C
- Dynamic Pack Resistance: ${resistance.toFixed(5)} Ω
- Calculated Efficiency: ${(efficiency * 100).toFixed(1)}%
- Current Bottleneck: ${bottleneckReason}

Explain in 2 short paragraphs:
1. Why this optimized current is physically and electrochemically superior to blindly pushing max current (Option A, e.g., higher current leading to rapid voltage sag, resistive heating, and degradation).
2. What operational or thermal recommendation (e.g., cooling adjustment, balancing, current limits) you advise next based on the cell state.

Maintain a professional, scientific, high-fidelity tone. Keep it concise.
`;

    const response = await ai.models.generateContent({
      model: "gemini-3.7-flash",
      contents: prompt,
    });

    res.json({ explanation: response.text });
  } catch (error: any) {
    console.error("Gemini Advisor API Error:", error);
    res.status(500).json({ error: error.message || "Failed to contact electrochemical advisor." });
  }
});

// 2. Vite Middleware configuration for development vs production
async function setupVite() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`BATTERYPERFORM server booted at http://localhost:${PORT} [ENV: ${process.env.NODE_ENV || "development"}]`);
  });
}

setupVite().catch((err) => {
  console.error("Failed to initialize server with Vite integration:", err);
});
