/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type OptimisationProfile = 'MAX_POWER' | 'MAX_EFFICIENCY' | 'MAX_LONGEVITY' | 'BALANCED';

export interface CellState {
  id: number;
  soc: number;                  // Ratio [0, 1]
  soh: number;                  // Ratio [0, 1]
  temperatureC: number;         // °C
  voltageV: number;             // V
  internalResistanceOhm: number; // Ω
  heatGenerationW: number;      // W
  polarizationV: number;        // V
  cumulativeCycles: number;     // Number of cycles
}

export interface ModuleImbalance {
  voltageSpreadV: number;
  tempSpreadC: number;
  socSpread: number;
  weakestCellId: number;
  hottestCellId: number;
}

export interface ModuleState {
  id: number;
  cells: CellState[];
  voltageV: number;
  resistanceOhm: number;
  averageTempC: number;
  averageSoc: number;
  imbalance: ModuleImbalance;
}

export interface PackState {
  overallSoc: number;
  overallSoh: number;
  totalVoltageV: number;
  currentA: number;
  dynamicResistanceOhm: number;
  performanceIndex: number;
  hottestTempC: number;
  averageTempC: number;
  bottleneckReason: string;
  bottleneckCellId: number;
  coolingFlowLS: number;
  pumpSpeedRpm: number;
  parasiticLossW: number;
  usefulPowerKw: number;
  lossesW: number;
}

export interface SimulationStep {
  timestamp: number;
  pack: PackState;
  demandKw: number;
}
