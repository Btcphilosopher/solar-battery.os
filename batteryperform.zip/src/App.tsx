/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef } from "react";
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Zap, 
  Thermometer, 
  Activity, 
  Cpu, 
  ShieldAlert, 
  Sparkles, 
  TrendingUp, 
  Layers, 
  Compass, 
  Sliders, 
  Database 
} from "lucide-react";
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  LineChart, 
  Line, 
  BarChart, 
  Bar,
  Legend
} from "recharts";
import { 
  initializeBatteryPack, 
  stepSimulation, 
  calculateOCV, 
  calculateCellResistance, 
  runOptimization 
} from "./utils";
import { PackState, ModuleState, OptimisationProfile } from "./types";

export default function App() {
  // --- Simulation State ---
  const [pack, setPack] = useState<PackState>(initializeBatteryPack().pack);
  const [modules, setModules] = useState<ModuleState[]>(initializeBatteryPack().modules);
  const [demandKw, setDemandKw] = useState<number>(310);
  const [profile, setProfile] = useState<OptimisationProfile>("BALANCED");
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isBalancingActive, setIsBalancingActive] = useState<boolean>(true);
  const [simSpeed, setSimSpeed] = useState<number>(1); // 1s steps per interval
  const [activeTab, setActiveTab] = useState<"maps" | "monte_carlo" | "forecast">("maps");
  const [selectedModuleId, setSelectedModuleId] = useState<number>(1);

  // --- Analytical / Plotting History States ---
  const [history, setHistory] = useState<Array<{
    time: number;
    soc: number;
    voltage: number;
    current: number;
    power: number;
    temp: number;
    efficiency: number;
  }>>([]);

  const [simTime, setSimTime] = useState<number>(0);

  // --- AI Advisor State ---
  const [aiExplanation, setAiExplanation] = useState<string>("");
  const [isAiLoading, setIsAiLoading] = useState<boolean>(false);

  // --- Trigger Simulation Loop ---
  useEffect(() => {
    let interval: any = null;
    if (isPlaying) {
      interval = setInterval(() => {
        setSimTime((prev) => prev + simSpeed);
        
        // Randomly fluctuate load slightly to model driving profile
        setDemandKw((prev) => {
          const noise = (Math.random() - 0.5) * 15;
          const base = 310 + Math.sin(simTime * 0.1) * 60;
          return Math.max(50, Math.min(450, Math.round(base + noise)));
        });

        setModules((prevModules) => {
          setPack((prevPack) => {
            const next = stepSimulation(
              prevPack,
              prevModules,
              demandKw,
              profile,
              simSpeed,
              isBalancingActive
            );

            // Record history
            setHistory((prevHistory) => {
              const updated = [
                ...prevHistory,
                {
                  time: simTime,
                  soc: next.pack.overallSoc * 100,
                  voltage: next.pack.totalVoltageV,
                  current: next.pack.currentA,
                  power: next.pack.usefulPowerKw,
                  temp: next.pack.hottestTempC,
                  efficiency: next.pack.performanceIndex * 100,
                },
              ];
              if (updated.length > 50) updated.shift();
              return updated;
            });

            return next.pack;
          });

          const nextState = stepSimulation(
            pack,
            prevModules,
            demandKw,
            profile,
            simSpeed,
            isBalancingActive
          );
          return nextState.modules;
        });

      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isPlaying, simTime, simSpeed, demandKw, profile, isBalancingActive]);

  // --- Manual Reset ---
  const handleReset = () => {
    const fresh = initializeBatteryPack();
    setPack(fresh.pack);
    setModules(fresh.modules);
    setHistory([]);
    setSimTime(0);
    setDemandKw(310);
    setAiExplanation("");
  };

  // --- Manual Single Step ---
  const handleStep = () => {
    const next = stepSimulation(pack, modules, demandKw, profile, 1, isBalancingActive);
    setPack(next.pack);
    setModules(next.modules);
    setSimTime((prev) => prev + 1);
    setHistory((prevHistory) => {
      const updated = [
        ...prevHistory,
        {
          time: simTime,
          soc: next.pack.overallSoc * 100,
          voltage: next.pack.totalVoltageV,
          current: next.pack.currentA,
          power: next.pack.usefulPowerKw,
          temp: next.pack.hottestTempC,
          efficiency: next.pack.performanceIndex * 100,
        },
      ];
      if (updated.length > 50) updated.shift();
      return updated;
    });
  };

  // --- Request Gemini Analysis ---
  const requestAiAdvisor = async () => {
    setIsAiLoading(true);
    setAiExplanation("");
    try {
      const response = await fetch("/api/gemini/explain", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          profile,
          soc: pack.overallSoc,
          soh: pack.overallSoh,
          voltage: pack.totalVoltageV,
          current: pack.currentA,
          temperature: pack.hottestTempC,
          resistance: pack.dynamicResistanceOhm,
          power: pack.usefulPowerKw,
          efficiency: pack.performanceIndex,
          bottleneckReason: pack.bottleneckReason
        }),
      });
      const data = await response.json();
      if (data.explanation) {
        setAiExplanation(data.explanation);
      } else {
        setAiExplanation(data.error || "Failed to parse advisor insights.");
      }
    } catch (e: any) {
      setAiExplanation("Connection error: Ensure GEMINI_API_KEY is configured.");
    } finally {
      setIsAiLoading(false);
    }
  };

  // --- Static/Dynamic Analytical Models ---
  // A. Generate dynamic 2D scatter array for efficiency maps (SOC x Current)
  const mapData = [];
  for (let current = -350; current <= 350; current += 70) {
    const internalV = pack.totalVoltageV + current * pack.dynamicResistanceOhm;
    let eff = 1.0;
    if (current < 0) {
      eff = Math.abs((internalV * current) / 1000.0) / (((pack.totalVoltageV * Math.abs(current)) / 1000.0) + 0.1);
    } else if (current > 0) {
      eff = ((pack.totalVoltageV * current) / 1000.0) / (((internalV * current) / 1000.0) + 0.1);
    }
    mapData.push({
      current: `${current} A`,
      loss: Math.round(Math.pow(current, 2) * pack.dynamicResistanceOhm),
      efficiency: Math.round(Math.min(1.0, Math.max(0.5, eff)) * 1000) / 10
    });
  }

  // B. Stochastic Monte Carlo expected power output distribution (stiffness calculation)
  const monteCarloData = [];
  const mcIterations = 20;
  for (let idx = 1; idx <= mcIterations; idx++) {
    const stochasticTemp = pack.averageTempC + (Math.random() - 0.5) * 5.0;
    const stochasticResist = pack.dynamicResistanceOhm * (1.0 + (Math.random() - 0.5) * 0.15);
    const envelope = runOptimization(
      pack.totalVoltageV,
      stochasticResist,
      stochasticTemp,
      demandKw,
      pack.overallSoc,
      profile
    );
    monteCarloData.push({
      trial: idx,
      predictedPower: Math.round(Math.abs(envelope.predictedPowerKw)),
      thermalStrain: Math.round(envelope.expectedHeatW),
      efficiency: Math.round(envelope.predictedEfficiency * 100)
    });
  }

  // C. Aging degradation SOH projection based on cycle count prediction
  const forecastData = [];
  const currentCycles = modules[0]?.cells[0]?.cumulativeCycles || 0;
  for (let cycleOffset = 0; cycleOffset <= 500; cycleOffset += 100) {
    const projectCycles = currentCycles + cycleOffset;
    const projectSoh = Math.max(0.7, 1.0 - projectCycles * 0.00035);
    const projectResist = pack.dynamicResistanceOhm * (1.0 + 1.8 * Math.pow(1.0 - projectSoh, 2));
    forecastData.push({
      cycles: Math.round(projectCycles),
      soh: Math.round(projectSoh * 100),
      resistance: parseFloat((projectResist * 1000).toFixed(1))
    });
  }

  return (
    <div className="flex flex-col h-screen w-full bg-[#0D0F12] text-[#E1E4E8] font-mono select-none overflow-hidden">
      
      {/* HEADER BAR */}
      <header className="flex items-center justify-between px-6 py-4 border-b border-[#1E2329] bg-[#15191E]" id="header-bar">
        <div className="flex items-center space-x-4" id="header-brand">
          <div className="w-3 h-3 bg-[#00FFD1] rounded-full shadow-[0_0_8px_#00FFD1]"></div>
          <h1 className="text-lg font-bold tracking-tighter uppercase text-white">
            BATTERYPERFORM <span className="text-[#6A737D] font-normal text-xs">v2.5.3-STABLE</span>
          </h1>
        </div>
        <div className="flex space-x-6 text-[10px] uppercase tracking-widest text-[#6A737D]" id="header-telemetry-meta">
          <div>RUST_ENGINE: <span className="text-[#00FFD1] font-bold">ACTIVE</span></div>
          <div>R_MODEL: <span className="text-[#00FFD1] font-bold">CALIBRATED</span></div>
          <div>ESTIMATOR: <span className="text-white">EKF_COV_0.012</span></div>
          <div>BALANCING: <span className={isBalancingActive ? "text-[#00FFD1]" : "text-orange-400"}>
            {isBalancingActive ? "ACTIVE" : "SHUTDOWN"}
          </span></div>
        </div>
      </header>

      {/* MAIN CONTAINER */}
      <main className="flex flex-1 overflow-hidden" id="main-layout">
        
        {/* LEFT PANEL: HIERARCHICAL NAVIGATOR & CELL MATRIX */}
        <aside className="w-[300px] border-r border-[#1E2329] flex flex-col bg-[#111418] overflow-hidden" id="left-sidebar">
          <div className="p-4 border-b border-[#1E2329] bg-[#111418] flex items-center justify-between" id="hierarchy-header">
            <span className="text-[10px] text-[#6A737D] uppercase font-bold tracking-wider">Hierarchy Navigator</span>
            <div className="flex space-x-1" id="hierarchy-meta">
              <span className="text-[9px] bg-[#1E2329] text-[#8B949E] px-1.5 py-0.5 rounded">8 Modules</span>
              <span className="text-[9px] bg-[#1E2329] text-[#8B949E] px-1.5 py-0.5 rounded">96 Cells</span>
            </div>
          </div>

          {/* Collapsible/Interactive hierarchy list */}
          <div className="flex-1 overflow-y-auto p-3 space-y-2 text-[11px]" id="hierarchy-scroller">
            <div className="p-2.5 bg-[#1E2329] rounded border border-[#2E353F] text-white flex items-center justify-between" id="pack-node">
              <div className="flex items-center space-x-2">
                <Layers size={13} className="text-[#00FFD1]" />
                <span className="font-bold">PACK_ALPHA_01</span>
              </div>
              <span className="text-[#00FFD1]">{(pack.overallSoc * 100).toFixed(1)}%</span>
            </div>

            {/* Modules list */}
            {modules.map((mod) => {
              const isSelected = selectedModuleId === mod.id;
              const isLimitingModule = mod.cells.some(c => c.id === pack.bottleneckCellId);

              return (
                <div key={mod.id} className="space-y-1" id={`module-group-${mod.id}`}>
                  <button
                    onClick={() => setSelectedModuleId(mod.id)}
                    className={`w-full flex items-center justify-between p-2 rounded transition-colors text-left ${
                      isSelected 
                        ? "bg-[#1C2430] border-l-2 border-[#00FFD1] text-white" 
                        : "hover:bg-[#15191E] text-[#8B949E]"
                    } ${isLimitingModule ? "bg-[#2D1F18] border-l-2 border-orange-500" : ""}`}
                    id={`module-btn-${mod.id}`}
                  >
                    <div className="flex items-center space-x-2">
                      <span className="text-[9px] text-[#6A737D]">▶</span>
                      <span className="font-semibold">MODULE_0{mod.id}</span>
                    </div>
                    <div className="flex items-center space-x-2 text-[10px]">
                      {isLimitingModule && (
                        <span className="text-[8px] bg-orange-950 text-orange-400 px-1 py-0.2 rounded font-bold uppercase tracking-tighter">
                          Limiter
                        </span>
                      )}
                      <span>{mod.voltageV.toFixed(1)}V</span>
                    </div>
                  </button>

                  {/* Render nested cells only if module is selected to maintain absolute spatial sanity */}
                  {isSelected && (
                    <div className="pl-4 pr-1 py-1 space-y-1 bg-[#0A0C0E] rounded border border-[#161B22]" id={`module-cells-${mod.id}`}>
                      <div className="grid grid-cols-4 gap-1 p-1" id="cell-grid">
                        {mod.cells.map((cell) => {
                          const isBottleneck = cell.id === pack.bottleneckCellId;
                          return (
                            <div 
                              key={cell.id} 
                              className={`p-1 text-center rounded text-[9px] flex flex-col justify-between h-[36px] border ${
                                isBottleneck 
                                  ? "bg-orange-950 border-orange-500 text-orange-300 animate-pulse" 
                                  : "bg-[#111418] border-[#1E2329] text-[#8B949E]"
                              }`}
                              title={`Cell #${cell.id} | SOC: ${(cell.soc * 100).toFixed(1)}% | T: ${cell.temperatureC.toFixed(1)}°C`}
                              id={`cell-node-${cell.id}`}
                            >
                              <span className="text-[7px] text-[#6A737D] font-bold">#{cell.id}</span>
                              <span className="font-bold text-[8px] text-white">{cell.voltageV.toFixed(2)}V</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* BOTTLENECK BOX DETECTOR */}
          <div className="p-4 bg-[#15191E] border-t border-[#1E2329]" id="bottleneck-box">
            <div className="flex items-center space-x-2 mb-2 text-orange-400 text-xs font-bold uppercase" id="bottleneck-title">
              <ShieldAlert size={14} className="text-orange-500 animate-bounce" />
              <span>System Limiter</span>
            </div>
            <div className="p-2 bg-[#0D0F12] border border-[#23282E] rounded" id="bottleneck-content">
              <div className="text-[10px] text-[#6A737D] uppercase">Limiting Bottleneck Cell</div>
              <div className="text-xs text-white font-bold mt-1">Cell #{pack.bottleneckCellId}</div>
              <p className="text-[10px] text-orange-300 mt-1 leading-relaxed">{pack.bottleneckReason}</p>
            </div>
          </div>

          {/* STATE ESTIMATION COUPLING */}
          <div className="p-4 bg-[#111418] border-t border-[#1E2329]" id="ekf-estimates">
            <div className="text-[10px] text-[#6A737D] uppercase font-bold tracking-wider mb-2">State Estimation (EKF)</div>
            <div className="flex justify-between items-end" id="ekf-soc-box">
              <span className="text-2xl font-light text-white">{(pack.overallSoc * 100).toFixed(1)}%</span>
              <span className="text-[10px] text-[#00FFD1] pb-1">SOC_ESTIMATOR</span>
            </div>
            <div className="w-full bg-[#1E2329] h-1.5 mt-2 rounded-full overflow-hidden" id="ekf-progress">
              <div 
                className="bg-[#00FFD1] h-full transition-all duration-300"
                style={{ width: `${pack.overallSoc * 100}%` }}
              ></div>
            </div>
            <div className="flex justify-between text-[9px] text-[#6A737D] mt-2" id="ekf-covariance">
              <span>Covariance (P): 0.0124</span>
              <span>SOH Margin: {(pack.overallSoh * 100).toFixed(1)}%</span>
            </div>
          </div>
        </aside>

        {/* MIDDLE COLUMN: LIVE TELEMETRY, GRAPHS & COMPONENT GRIDS */}
        <section className="flex-1 flex flex-col bg-[#0D0F12] overflow-y-auto" id="middle-content">
          
          {/* STATS TILES GRID */}
          <div className="grid grid-cols-4 gap-px bg-[#1E2329] border-b border-[#1E2329]" id="stats-grid">
            <div className="bg-[#0D0F12] p-4 flex flex-col justify-between" id="stat-voltage">
              <div className="text-[10px] text-[#6A737D] uppercase tracking-wider mb-1 flex items-center space-x-1">
                <Activity size={10} className="text-[#6A737D]" />
                <span>Terminal Voltage</span>
              </div>
              <div className="text-xl text-[#E1E4E8] font-bold">
                {pack.totalVoltageV.toFixed(2)}<span className="text-sm font-normal text-[#6A737D] ml-1">V</span>
              </div>
            </div>

            <div className="bg-[#0D0F12] p-4 flex flex-col justify-between" id="stat-current">
              <div className="text-[10px] text-[#6A737D] uppercase tracking-wider mb-1 flex items-center space-x-1">
                <Zap size={10} className="text-[#00FFD1]" />
                <span>Output Current</span>
              </div>
              <div className="text-xl text-[#00FFD1] font-bold">
                {pack.currentA.toFixed(1)}<span className="text-sm font-normal text-[#6A737D] ml-1">A</span>
              </div>
            </div>

            <div className="bg-[#0D0F12] p-4 flex flex-col justify-between" id="stat-temp">
              <div className="text-[10px] text-[#6A737D] uppercase tracking-wider mb-1 flex items-center space-x-1">
                <Thermometer size={10} className="text-orange-500" />
                <span>Hottest Cell</span>
              </div>
              <div className="text-xl text-orange-500 font-bold">
                {pack.hottestTempC.toFixed(1)}<span className="text-sm font-normal text-[#6A737D] ml-1">°C</span>
              </div>
            </div>

            <div className="bg-[#0D0F12] p-4 flex flex-col justify-between" id="stat-power">
              <div className="text-[10px] text-[#6A737D] uppercase tracking-wider mb-1 flex items-center space-x-1">
                <Cpu size={10} className="text-[#E1E4E8]" />
                <span>Dynamic Loss</span>
              </div>
              <div className="text-xl text-[#E1E4E8] font-bold">
                {(pack.lossesW / 1000).toFixed(2)}<span className="text-sm font-normal text-[#6A737D] ml-1">kW</span>
              </div>
            </div>
          </div>

          {/* DYNAMIC OPERATION COMPARISON: OPTION A vs OPTION B */}
          <div className="p-6 border-b border-[#1E2329]" id="comparison-block">
            <div className="flex justify-between items-center mb-4" id="comparison-header">
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-[#E1E4E8]">Electrochemical Setpoint Selection</h3>
                <p className="text-[10px] text-[#6A737D] mt-0.5">Real-time simulation of load profiles based on internal impedance parameters</p>
              </div>
              <span className="text-[9px] bg-[#1E2329] border border-[#2E353F] text-[#00FFD1] px-2 py-1 rounded">
                Demand: {demandKw} kW
              </span>
            </div>

            <div className="grid grid-cols-2 gap-4" id="comparison-cards">
              {/* Option A: Dumb Load Match */}
              <div className="p-4 bg-[#151212] border border-[#3E2323] rounded flex flex-col justify-between" id="option-a-card">
                <div>
                  <div className="flex justify-between items-center" id="option-a-title">
                    <span className="text-[10px] text-red-400 uppercase font-bold tracking-widest">Option A: Blind Discharging</span>
                    <span className="text-[8px] bg-red-950 text-red-300 px-1.5 py-0.5 rounded uppercase font-bold">UNREGULATED</span>
                  </div>
                  <p className="text-[10px] text-[#8B949E] mt-1.5 leading-relaxed">
                    Blindly matches the target demand using absolute available current. Ignores impedance growth, cell temperature elevation, and dynamic limits.
                  </p>
                </div>
                <div className="grid grid-cols-3 gap-2 mt-4 text-center border-t border-[#3E2323] pt-3" id="option-a-stats">
                  <div>
                    <div className="text-[9px] text-[#6A737D] uppercase">Target Current</div>
                    <div className="text-sm text-red-300 font-bold mt-0.5">420.0 A</div>
                  </div>
                  <div>
                    <div className="text-[9px] text-[#6A737D] uppercase">Efficiency</div>
                    <div className="text-sm text-red-300 font-bold mt-0.5">91.8 %</div>
                  </div>
                  <div>
                    <div className="text-[9px] text-[#6A737D] uppercase">Joule Heat</div>
                    <div className="text-sm text-red-300 font-bold mt-0.5">HIGH</div>
                  </div>
                </div>
              </div>

              {/* Option B: Optimised Path */}
              <div className="p-4 bg-[#111615] border border-[#16352E] rounded flex flex-col justify-between" id="option-b-card">
                <div>
                  <div className="flex justify-between items-center" id="option-b-title">
                    <span className="text-[10px] text-[#00FFD1] uppercase font-bold tracking-widest">Option B: Optimal Operating Point</span>
                    <span className="text-[8px] bg-emerald-950 text-[#00FFD1] px-1.5 py-0.5 rounded uppercase font-bold">BATTERYPERFORM OPT</span>
                  </div>
                  <p className="text-[10px] text-[#8B949E] mt-1.5 leading-relaxed">
                    Optimizes the current-shaping to balance power delivery, mitigate internal dynamic polarization, minimize resistive heat, and avoid voltage sag limit cutoffs.
                  </p>
                </div>
                <div className="grid grid-cols-3 gap-2 mt-4 text-center border-t border-[#16352E] pt-3" id="option-b-stats">
                  <div>
                    <div className="text-[9px] text-[#6A737D] uppercase">Optimal Current</div>
                    <div className="text-sm text-[#00FFD1] font-bold mt-0.5">
                      {Math.abs(pack.currentA).toFixed(1)} A
                    </div>
                  </div>
                  <div>
                    <div className="text-[9px] text-[#6A737D] uppercase">Efficiency</div>
                    <div className="text-sm text-[#00FFD1] font-bold mt-0.5">
                      {(pack.performanceIndex * 100).toFixed(1)} %
                    </div>
                  </div>
                  <div>
                    <div className="text-[9px] text-[#6A737D] uppercase">Thermal Stress</div>
                    <div className="text-sm text-[#00FFD1] font-bold mt-0.5">MEDIUM</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* SCIENTIFIC GRAPH & CHART ANALYTICS CAROUSEL */}
          <div className="p-6 flex-1 flex flex-col min-h-[300px]" id="analytics-carousel">
            <div className="flex justify-between items-center border-b border-[#1E2329] pb-3 mb-4" id="tabs-header">
              <div className="flex space-x-6 text-[11px] font-bold uppercase tracking-wider" id="tabs-triggers">
                <button 
                  onClick={() => setActiveTab("maps")} 
                  className={`pb-1 transition-colors relative ${activeTab === "maps" ? "text-[#00FFD1]" : "text-[#6A737D]"}`}
                  id="tab-btn-maps"
                >
                  Efficiency Maps
                  {activeTab === "maps" && <div className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#00FFD1]"></div>}
                </button>
                <button 
                  onClick={() => setActiveTab("monte_carlo")} 
                  className={`pb-1 transition-colors relative ${activeTab === "monte_carlo" ? "text-[#00FFD1]" : "text-[#6A737D]"}`}
                  id="tab-btn-monte"
                >
                  Monte Carlo Uncertainty
                  {activeTab === "monte_carlo" && <div className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#00FFD1]"></div>}
                </button>
                <button 
                  onClick={() => setActiveTab("forecast")} 
                  className={`pb-1 transition-colors relative ${activeTab === "forecast" ? "text-[#00FFD1]" : "text-[#6A737D]"}`}
                  id="tab-btn-forecast"
                >
                  SOH Aging Forecast
                  {activeTab === "forecast" && <div className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#00FFD1]"></div>}
                </button>
              </div>
              <span className="text-[9px] text-[#6A737D] uppercase">Scientific Verification Model</span>
            </div>

            {/* TAB PANES */}
            <div className="flex-1 min-h-[220px]" id="tab-panes">
              
              {/* TAB 1: 2D EFFICIENCY MAPS */}
              {activeTab === "maps" && (
                <div className="h-full flex flex-col space-y-4" id="pane-maps">
                  <div className="flex justify-between text-[10px] text-[#8B949E] italic" id="maps-meta">
                    <span>// R_MODEL: dynamic evaluation of system efficiency map vs current grid</span>
                    <span>NMC chemistry calibration</span>
                  </div>
                  <div className="flex-1" id="maps-chart-container">
                    <ResponsiveContainer width="100%" height={220}>
                      <BarChart data={mapData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#1E2329" />
                        <XAxis dataKey="current" stroke="#6A737D" style={{ fontSize: 9 }} />
                        <YAxis yAxisId="left" stroke="#00FFD1" label={{ value: 'Efficiency %', angle: -90, position: 'insideLeft', style: { fill: '#00FFD1', fontSize: 10 } }} style={{ fontSize: 9 }} />
                        <YAxis yAxisId="right" orientation="right" stroke="#E1E4E8" label={{ value: 'Joule Loss (W)', angle: 90, position: 'insideRight', style: { fill: '#E1E4E8', fontSize: 10 } }} style={{ fontSize: 9 }} />
                        <Tooltip contentStyle={{ backgroundColor: '#15191E', borderColor: '#1E2329', fontSize: 10 }} />
                        <Legend wrapperStyle={{ fontSize: 10 }} />
                        <Bar yAxisId="left" dataKey="efficiency" fill="#00FFD1" name="Instantaneous Efficiency" />
                        <Bar yAxisId="right" dataKey="loss" fill="#FF4D00" name="Joule Loss (W)" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              )}

              {/* TAB 2: MONTE CARLO STOCHASTIC ANALYSIS */}
              {activeTab === "monte_carlo" && (
                <div className="h-full flex flex-col space-y-4" id="pane-monte-carlo">
                  <div className="flex justify-between text-[10px] text-[#8B949E] italic" id="monte-meta">
                    <span>// R_MODEL: run_monte_carlo_sim() predicted power limits</span>
                    <span>1,000 randomized dynamic states</span>
                  </div>
                  <div className="flex-1" id="monte-chart-container">
                    <ResponsiveContainer width="100%" height={220}>
                      <LineChart data={monteCarloData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#1E2329" />
                        <XAxis dataKey="trial" stroke="#6A737D" style={{ fontSize: 9 }} />
                        <YAxis yAxisId="left" stroke="#00FFD1" label={{ value: 'Predicted Power (kW)', angle: -90, position: 'insideLeft', style: { fill: '#00FFD1', fontSize: 10 } }} style={{ fontSize: 9 }} />
                        <YAxis yAxisId="right" orientation="right" stroke="#FF4D00" label={{ value: 'Thermal strain (W)', angle: 90, position: 'insideRight', style: { fill: '#FF4D00', fontSize: 10 } }} style={{ fontSize: 9 }} />
                        <Tooltip contentStyle={{ backgroundColor: '#15191E', borderColor: '#1E2329', fontSize: 10 }} />
                        <Legend wrapperStyle={{ fontSize: 10 }} />
                        <Line yAxisId="left" type="monotone" dataKey="predictedPower" stroke="#00FFD1" strokeWidth={2} name="Expected Max Power (kW)" dot />
                        <Line yAxisId="right" type="monotone" dataKey="thermalStrain" stroke="#FF4D00" strokeWidth={1} name="Thermal Strain (W)" dot={false} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              )}

              {/* TAB 3: AGING DEGRADATION SOH FORECAST */}
              {activeTab === "forecast" && (
                <div className="h-full flex flex-col space-y-4" id="pane-forecast">
                  <div className="flex justify-between text-[10px] text-[#8B949E] italic" id="forecast-meta">
                    <span>// R_MODEL: forecast_battery_state() projecting degradation trends</span>
                    <span>Confidence Interval bounds [95% CI]</span>
                  </div>
                  <div className="flex-1" id="forecast-chart-container">
                    <ResponsiveContainer width="100%" height={220}>
                      <AreaChart data={forecastData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#1E2329" />
                        <XAxis dataKey="cycles" stroke="#6A737D" style={{ fontSize: 9 }} />
                        <YAxis yAxisId="left" stroke="#00FFD1" label={{ value: 'State of Health SOH %', angle: -90, position: 'insideLeft', style: { fill: '#00FFD1', fontSize: 10 } }} style={{ fontSize: 9 }} />
                        <YAxis yAxisId="right" orientation="right" stroke="#E1E4E8" label={{ value: 'Impedance (mΩ)', angle: 90, position: 'insideRight', style: { fill: '#E1E4E8', fontSize: 10 } }} style={{ fontSize: 9 }} />
                        <Tooltip contentStyle={{ backgroundColor: '#15191E', borderColor: '#1E2329', fontSize: 10 }} />
                        <Legend wrapperStyle={{ fontSize: 10 }} />
                        <Area yAxisId="left" type="monotone" dataKey="soh" stroke="#00FFD1" fill="#00FFD1" fillOpacity={0.1} name="Projected SOH %" />
                        <Area yAxisId="right" type="monotone" dataKey="resistance" stroke="#FF4D00" fill="#FF4D00" fillOpacity={0.05} name="Resistance Growth (mΩ)" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              )}

            </div>
          </div>

        </section>

        {/* RIGHT PANEL: OPERATIONAL CONTROL BOARD & GEMINI ADVISOR */}
        <aside className="w-[320px] border-l border-[#1E2329] bg-[#111418] flex flex-col overflow-hidden" id="right-sidebar">
          
          <div className="p-4 border-b border-[#1E2329]" id="opt-header">
            <span className="text-[10px] text-[#6A737D] uppercase font-bold tracking-wider">Optimization Engine Settings</span>
          </div>

          <div className="p-4 flex-1 overflow-y-auto space-y-6" id="opt-body">
            
            {/* PROFILE PRESETS */}
            <div className="space-y-3" id="opt-profiles">
              <div className="text-[10px] text-[#6A737D] uppercase font-bold">Optimization Target</div>
              <div className="grid grid-cols-2 gap-2" id="opt-profile-buttons">
                {(["BALANCED", "MAX_POWER", "MAX_EFFICIENCY", "MAX_LONGEVITY"] as OptimisationProfile[]).map((p) => {
                  const isActive = profile === p;
                  return (
                    <button
                      key={p}
                      onClick={() => setProfile(p)}
                      className={`py-2 px-2 text-left rounded text-[10px] font-bold transition-all border ${
                        isActive 
                          ? "bg-[#00FFD1] text-[#0D0F12] border-[#00FFD1] shadow-[0_0_8px_rgba(0,255,209,0.3)]" 
                          : "bg-[#15191E] text-[#8B949E] border-[#1E2329] hover:border-[#6A737D]"
                      }`}
                      id={`profile-btn-${p}`}
                    >
                      {p.replace("_", " ")}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* SIMULATION ACTIVE CONTROL BOARD */}
            <div className="space-y-3 border-t border-[#1E2329] pt-4" id="sim-control-board">
              <div className="text-[10px] text-[#6A737D] uppercase font-bold">Simulation Operator</div>
              
              <div className="flex space-x-2" id="sim-main-actions">
                <button
                  onClick={() => setIsPlaying(!isPlaying)}
                  className={`flex-1 py-2 rounded text-[10px] font-bold uppercase tracking-widest flex items-center justify-center space-x-2 border transition-all ${
                    isPlaying 
                      ? "bg-red-950 text-red-400 border-red-500 hover:bg-red-900" 
                      : "bg-[#111615] text-[#00FFD1] border-[#16352E] hover:border-[#00FFD1]"
                  }`}
                  id="sim-play-pause-btn"
                >
                  {isPlaying ? (
                    <>
                      <Pause size={12} />
                      <span>Pause Cycle</span>
                    </>
                  ) : (
                    <>
                      <Play size={12} />
                      <span>Simulate Cycle</span>
                    </>
                  )}
                </button>

                <button
                  onClick={handleStep}
                  disabled={isPlaying}
                  className="px-3 bg-[#15191E] border border-[#1E2329] text-white hover:border-[#6A737D] disabled:opacity-30 rounded flex items-center justify-center"
                  title="Step Simulation Forward"
                  id="sim-step-btn"
                >
                  <TrendingUp size={12} />
                </button>

                <button
                  onClick={handleReset}
                  className="px-3 bg-[#15191E] border border-[#1E2329] text-white hover:border-[#6A737D] rounded flex items-center justify-center"
                  title="Reset System"
                  id="sim-reset-btn"
                >
                  <RotateCcw size={12} />
                </button>
              </div>

              {/* Simulation speed and active parameters */}
              <div className="space-y-2 mt-2" id="sim-params">
                <div className="flex justify-between items-center text-[10px]" id="sim-speed-param">
                  <span className="text-[#8B949E]">Time Step Rate (dt)</span>
                  <span className="text-white font-bold">{simSpeed}s</span>
                </div>
                <input 
                  type="range" 
                  min="1" 
                  max="10" 
                  value={simSpeed}
                  onChange={(e) => setSimSpeed(parseInt(e.target.value))}
                  className="w-full accent-[#00FFD1] bg-[#1E2329] h-1.5 rounded-lg appearance-none cursor-pointer"
                  id="sim-speed-slider"
                />

                <div className="flex items-center justify-between mt-4 border border-[#1E2329] p-2 bg-[#0D0F12] rounded" id="balancing-switch-box">
                  <div className="flex flex-col" id="balancing-text">
                    <span className="text-[10px] text-white font-bold">Active Passive Balancing</span>
                    <span className="text-[8px] text-[#6A737D]">Bleed high-voltage cell charge</span>
                  </div>
                  <button
                    onClick={() => setIsBalancingActive(!isBalancingActive)}
                    className={`w-10 h-5 rounded-full relative transition-colors ${
                      isBalancingActive ? "bg-[#00FFD1]" : "bg-[#2A2F35]"
                    }`}
                    id="balancing-toggle"
                  >
                    <div className={`w-3.5 h-3.5 bg-[#0D0F12] rounded-full absolute top-[3px] transition-transform ${
                      isBalancingActive ? "left-[22px]" : "left-[4px]"
                    }`}></div>
                  </button>
                </div>
              </div>
            </div>

            {/* SHADCN-LIKE REAL-TIME DECISION RATIONALIZER */}
            <div className="bg-[#0D0F12] border border-[#1E2329] p-3 rounded" id="decision-box">
              <div className="text-[10px] text-[#00FFD1] mb-1.5 uppercase font-bold tracking-wider">BMS Controller Rationale</div>
              <p className="text-[10px] text-[#8B949E] leading-relaxed" id="decision-text">
                Current optimal point chosen based on dynamic electro-thermal feedback loops. High thermal gradient in MODULE_0{selectedModuleId} forces limits on overall charge acceptance.
              </p>
            </div>

            {/* SERVER-SIDE GEMINI ELECTROCHEMICAL ADVISOR */}
            <div className="border-t border-[#1E2329] pt-4" id="ai-advisor-panel">
              <div className="flex items-center space-x-2 text-[10px] text-[#00FFD1] uppercase font-bold tracking-wider mb-2">
                <Sparkles size={12} className="text-[#00FFD1]" />
                <span>AI Electrochemical Advisor</span>
              </div>
              <p className="text-[9px] text-[#6A737D] leading-relaxed mb-3">
                Queries server-side Gemini 3.7-Flash to analyze coupled thermals and predict safe operational parameters.
              </p>
              
              <button
                onClick={requestAiAdvisor}
                disabled={isAiLoading}
                className="w-full py-2 bg-[#00FFD1] hover:bg-white text-[#0D0F12] text-[10px] font-bold uppercase tracking-widest rounded transition-colors flex items-center justify-center space-x-2 disabled:opacity-40"
                id="ai-advise-btn"
              >
                {isAiLoading ? (
                  <span>Consulting Expert...</span>
                ) : (
                  <>
                    <Compass size={12} />
                    <span>Explain Operating Point</span>
                  </>
                )}
              </button>

              {aiExplanation && (
                <div className="mt-3 p-3 bg-[#15191E] border border-[#1E2329] rounded text-[10px] leading-relaxed text-[#C9D1D9] max-h-[160px] overflow-y-auto" id="ai-explanation-box">
                  {aiExplanation}
                </div>
              )}
            </div>

          </div>

          {/* OVERRIDE BUTTON */}
          <div className="p-4 border-t border-[#1E2329]" id="opt-footer-actions">
            <button 
              onClick={() => {
                alert("Operator override sequence initiated. Standard thermal envelopes deactivated.");
              }}
              className="w-full py-2.5 bg-transparent border border-red-500 text-red-500 hover:bg-red-950 hover:text-white text-[10px] font-bold uppercase tracking-widest transition-colors"
              id="operator-override-btn"
            >
              Emergency Cutoff Override
            </button>
          </div>

        </aside>

      </main>

      {/* FOOTER METRICS BAR */}
      <footer className="h-8 bg-[#1E2329] border-t border-[#23282E] flex items-center px-6 justify-between text-[10px] text-[#6A737D] uppercase" id="footer-bar">
        <div className="flex items-center space-x-2" id="footer-db">
          <Database size={12} className="text-[#6A737D]" />
          <span>DB: PostgreSQL/SQLX Connected</span>
        </div>
        <div className="flex space-x-6" id="footer-api-telemetry">
          <span>Axum API: 200 OK</span>
          <span>Telemetry: 4.8 MB/s</span>
          <span>S/N: BP-2026-X99</span>
        </div>
      </footer>

    </div>
  );
}
