/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { CellState, ModuleState, PackState, OptimisationProfile, ModuleImbalance } from "./types";

// Physical Constants
const R_GAS = 8.314; // Universal gas constant, J/(mol*K)
const TEMP_REF_K = 298.15; // 25°C in Kelvin
const ACTIVATION_ENERGY = 23000.0; // J/mol
const SPECIFIC_HEAT_WATER = 4184.0; // J/(kg*K)
const NOMINAL_CAPACITY_AH = 5.0; // Cell Ah capacity

/**
 * Empirical OCV model using NMC polynomial approximation
 * Range of validity: SOC [0.001, 0.999]
 */
export function calculateOCV(soc: number): number {
  const clippedSoc = Math.max(0.001, Math.min(0.999, soc));
  // OCV-SOC NMC parameters
  const c0 = 3.42;
  const c1 = 0.58;
  const c2 = 0.12;
  const c3 = 0.045;
  const c4 = -0.045;

  return c0 + c1 * clippedSoc + c2 * Math.pow(clippedSoc, 2) + c3 * Math.log(clippedSoc) + c4 * Math.log(1.0 - clippedSoc);
}

/**
 * Arrhenius Temperature-Dependent & SOC-Dependent Internal Resistance (R)
 * Assumptions: Obeys Arrhenius kinetics, increases exponentially at lower temperature and degraded SOH.
 */
export function calculateCellResistance(tempC: number, soc: number, soh: number): number {
  const tempK = tempC + 273.15;
  const baseR = 0.012; // 12 mΩ base cell resistance

  // Arrhenius thermal scaling
  const arrhenius = Math.exp((ACTIVATION_ENERGY / R_GAS) * (1.0 / tempK - 1.0 / TEMP_REF_K));

  // SOC dependence: resistance rises as cell drains
  const socFactor = 1.0 + 0.3 * Math.pow(1.0 - soc, 3);

  // Degradation factor: resistance grows as State of Health decreases
  const sohFactor = 1.0 + 1.6 * Math.pow(1.0 - soh, 2);

  return baseR * arrhenius * socFactor * sohFactor;
}

/**
 * Joule loss + Entropic reversible heat generation (Bernardi thermal model)
 * Returns rate of heating in Watts
 */
export function calculateHeatGeneration(currentA: number, soc: number, tempC: number, resistanceOhm: number): number {
  // Irreversible Joule losses: I^2 * R
  const jouleLoss = Math.pow(currentA, 2) * resistanceOhm;

  // Reversible entropic heat (dVocv/dT ≈ -0.1 mV/K)
  const entropicCoefficient = -0.0001; 
  const tempK = tempC + 273.15;
  const entropicLoss = currentA * tempK * entropicCoefficient;

  return Math.max(0.0, jouleLoss + entropicLoss);
}

/**
 * Grid search optimization for the chosen profile.
 * Computes Option A (blind maximum) vs Option B (optimal operating point).
 */
export function runOptimization(
  voltageV: number,
  resistanceOhm: number,
  maxTempC: number,
  demandKw: number,
  soc: number,
  profile: OptimisationProfile,
  maxCurrentA: number = 380
): {
  selectedCurrentA: number;
  predictedPowerKw: number;
  predictedEfficiency: number;
  expectedHeatW: number;
  recommendedCoolingLS: number;
  performanceIndex: number;
  rationale: string;
} {
  const minCurrentA = -maxCurrentA; // Discharging is negative current
  const maxVoltageLimitV = 830.0;
  const minVoltageLimitV = 600.0;

  let bestCurrent = 0.0;
  let bestScore = -Infinity;
  let bestPower = 0.0;
  let bestEff = 0.0;
  let bestHeat = 0.0;
  let bestCool = 0.0;

  const candidatesCount = 100;

  for (let i = 0; i <= candidatesCount; i++) {
    const fraction = i / candidatesCount;
    // Discharging current (negative) is prioritized if power demand is positive
    const candidateCurrent = minCurrentA + fraction * (maxCurrentA - minCurrentA);

    // KVL check
    const terminalV = voltageV + candidateCurrent * resistanceOhm;
    if (terminalV < minVoltageLimitV || terminalV > maxVoltageLimitV) {
      continue;
    }

    const powerKw = (terminalV * candidateCurrent) / 1000.0;
    const jouleLossW = Math.pow(candidateCurrent, 2) * resistanceOhm;

    // Efficiency computation
    let efficiency = 1.0;
    if (candidateCurrent < 0) {
      // Discharging efficiency
      const powerDelivered = Math.abs(powerKw);
      const chemicalSourcePower = (voltageV * Math.abs(candidateCurrent)) / 1000.0;
      efficiency = chemicalSourcePower > 0 ? powerDelivered / chemicalSourcePower : 1.0;
    } else if (candidateCurrent > 0) {
      // Charging efficiency
      const chemicalStored = (voltageV * candidateCurrent) / 1000.0;
      efficiency = powerKw > 0 ? chemicalStored / powerKw : 1.0;
    }
    efficiency = Math.min(1.0, Math.max(0.0, efficiency));

    // Parasitic cooling pump need calculation
    const coolingNeed = jouleLossW > 400.0 ? 0.2 + (jouleLossW - 400.0) / 1200.0 : 0.05;
    const coolingLS = Math.min(4.0, Math.max(0.05, coolingNeed));

    // Multi-objective weighting functions
    let score = 0;
    switch (profile) {
      case "MAX_POWER": {
        // High weight on delivering power, slight penalty on heat
        const powerMatch = -Math.pow(Math.abs(powerKw) - Math.abs(demandKw), 2) * 0.1;
        const powerPeak = Math.abs(powerKw) * 10.0;
        const lossPenalty = jouleLossW * 0.005;
        score = powerPeak + powerMatch - lossPenalty;
        break;
      }
      case "MAX_EFFICIENCY": {
        // Drastically penalize losses and cooling overhead
        const efficiencyGain = efficiency * 1000.0;
        const lossPenalty = jouleLossW * 0.08;
        const thermalPenalty = maxTempC > 35.0 ? Math.pow(maxTempC - 35.0, 2) * 5.0 : 0.0;
        score = efficiencyGain - lossPenalty - thermalPenalty;
        break;
      }
      case "MAX_LONGEVITY": {
        // Restrict current level, penalize thermal deviation above 25°C
        const currentPenalty = Math.abs(candidateCurrent) * 0.8;
        const thermalDeviation = Math.pow(Math.max(0, maxTempC - 25.0), 2) * 6.0;
        const lossPenalty = jouleLossW * 0.05;
        score = -currentPenalty - thermalDeviation - lossPenalty;
        break;
      }
      case "BALANCED": {
        // Balanced approach
        const powerDelivered = Math.abs(powerKw);
        const demandMatch = -Math.pow(powerDelivered - Math.abs(demandKw), 2) * 0.5;
        const lossPenalty = jouleLossW * 0.015;
        const thermalPenalty = maxTempC > 32.0 ? Math.pow(maxTempC - 32.0, 2) * 3.0 : 0.0;
        score = powerDelivered * 5.0 + demandMatch - lossPenalty - thermalPenalty;
        break;
      }
    }

    if (score > bestScore) {
      bestScore = score;
      bestCurrent = candidateCurrent;
      bestPower = powerKw;
      bestEff = efficiency;
      bestHeat = jouleLossW;
      bestCool = coolingLS;
    }
  }

  // Fallback to match demand if no valid optimization path found
  if (bestScore === -Infinity) {
    bestCurrent = -demandKw * 1000.0 / voltageV;
    bestPower = demandKw;
    bestEff = 0.88;
    bestHeat = Math.pow(bestCurrent, 2) * resistanceOhm;
    bestCool = 0.2;
  }

  // Rationale compiler
  let rationale = "";
  switch (profile) {
    case "MAX_POWER":
      rationale = `Selected ${Math.abs(bestCurrent).toFixed(0)}A discharge to safely push peak capabilities (${Math.abs(bestPower).toFixed(1)}kW), raising cooling flow rate to control high Joule heating (${bestHeat.toFixed(0)}W).`;
      break;
    case "MAX_EFFICIENCY":
      rationale = `Constrained current to ${Math.abs(bestCurrent).toFixed(0)}A, achieving ${(bestEff * 100).toFixed(1)}% system efficiency and lowering resistive losses by ${(bestHeat * 0.4).toFixed(0)}W compared to full-current output.`;
      break;
    case "MAX_LONGEVITY":
      rationale = `Restricted active current to ${Math.abs(bestCurrent).toFixed(0)}A to mitigate dynamic degradation, limit heat generation to ${bestHeat.toFixed(0)}W, and curb solid-electrolyte interphase (SEI) growth.`;
      break;
    case "BALANCED":
      rationale = `Balanced operational profile at ${Math.abs(bestCurrent).toFixed(0)}A to deliver ${Math.abs(bestPower).toFixed(1)}kW with moderate losses (${bestHeat.toFixed(0)}W) and sustainable cell temperatures.`;
      break;
  }

  // Normalized performance index
  const normPower = Math.min(1.0, Math.abs(bestPower) / 320.0);
  const normTemp = Math.max(0.0, 1.0 - Math.max(0, maxTempC - 25.0) / 35.0);
  const performanceIndex = normPower * 0.3 + bestEff * 0.4 + normTemp * 0.3;

  return {
    selectedCurrentA: bestCurrent,
    predictedPowerKw: bestPower,
    predictedEfficiency: bestEff,
    expectedHeatW: bestHeat,
    recommendedCoolingLS: bestCool,
    performanceIndex,
    rationale,
  };
}

/**
 * Initialize 12S8P (8 Modules, each with 12 cells in series) battery pack state
 */
export function initializeBatteryPack(): { pack: PackState; modules: ModuleState[] } {
  const modulesInSeries = 8;
  const cellsInSeries = 12;

  const modules: ModuleState[] = [];
  let globalCellId = 1;

  for (let m = 1; m <= modulesInSeries; m++) {
    const cells: CellState[] = [];
    for (let c = 1; c <= cellsInSeries; c++) {
      // Introduce slight cell-to-cell variations for realism
      const variationSoc = 0.62 + (Math.random() - 0.5) * 0.03; // imbalance!
      const variationSoh = 0.98 + (Math.random() - 0.5) * 0.02; // health imbalance!
      const variationTemp = 24.5 + (Math.random() - 0.5) * 1.5; // thermal variation!

      const cellRes = calculateCellResistance(variationTemp, variationSoc, variationSoh);
      const ocv = calculateOCV(variationSoc);

      cells.push({
        id: globalCellId++,
        soc: variationSoc,
        soh: variationSoh,
        temperatureC: variationTemp,
        voltageV: ocv,
        internalResistanceOhm: cellRes,
        heatGenerationW: 0,
        polarizationV: 0,
        cumulativeCycles: 0,
      });
    }

    modules.push({
      id: m,
      cells,
      voltageV: cells.reduce((sum, cl) => sum + cl.voltageV, 0),
      resistanceOhm: cells.reduce((sum, cl) => sum + cl.internalResistanceOhm, 0),
      averageTempC: cells.reduce((sum, cl) => sum + cl.temperatureC, 0) / cells.length,
      averageSoc: cells.reduce((sum, cl) => sum + cl.soc, 0) / cells.length,
      imbalance: {
        voltageSpreadV: 0.05,
        tempSpreadC: 1.5,
        socSpread: 0.02,
        weakestCellId: cells[0].id,
        hottestCellId: cells[0].id,
      },
    });
  }

  // Calculate imbalances
  updateImbalances(modules);

  const totalVoltage = modules.reduce((sum, mod) => sum + mod.voltageV, 0);
  const totalResistance = modules.reduce((sum, mod) => sum + mod.resistanceOhm, 0);

  const pack: PackState = {
    overallSoc: 0.62,
    overallSoh: 0.98,
    totalVoltageV: totalVoltage,
    currentA: 0,
    dynamicResistanceOhm: totalResistance,
    performanceIndex: 0.91,
    hottestTempC: 26.5,
    averageTempC: 24.8,
    bottleneckReason: "Nominal Operating State",
    bottleneckCellId: 1,
    coolingFlowLS: 0.1,
    pumpSpeedRpm: 800,
    parasiticLossW: 50,
    usefulPowerKw: 0,
    lossesW: 0,
  };

  return { pack, modules };
}

function updateImbalances(modules: ModuleState[]) {
  for (const mod of modules) {
    let minV = Infinity, maxV = -Infinity;
    let minT = Infinity, maxT = -Infinity;
    let minSoc = Infinity, maxSoc = -Infinity;
    let weakestId = mod.cells[0].id;
    let hottestId = mod.cells[0].id;

    for (const cl of mod.cells) {
      if (cl.voltageV < minV) minV = cl.voltageV;
      if (cl.voltageV > maxV) maxV = cl.voltageV;
      if (cl.temperatureC < minT) minT = cl.temperatureC;
      if (cl.temperatureC > maxT) {
        maxT = cl.temperatureC;
        hottestId = cl.id;
      }
      if (cl.soc < minSoc) {
        minSoc = cl.soc;
        weakestId = cl.id;
      }
      if (cl.soc > maxSoc) maxSoc = cl.soc;
    }

    mod.imbalance = {
      voltageSpreadV: maxV - minV,
      tempSpreadC: maxT - minT,
      socSpread: maxSoc - minSoc,
      weakestCellId: weakestId,
      hottestCellId: hottestId,
    };
  }
}

/**
 * Step simulation forward in time (dt in seconds)
 * Implements electrochemical updates, thermal updates, cooling flow heat exchanges, and balancing
 */
export function stepSimulation(
  pack: PackState,
  modules: ModuleState[],
  demandKw: number,
  profile: OptimisationProfile,
  dtSeconds: number,
  isBalancingActive: boolean
): { pack: PackState; modules: ModuleState[] } {
  // 1. Solve optimal operating current first based on current telemetry
  const opt = runOptimization(
    pack.totalVoltageV,
    pack.dynamicResistanceOhm,
    pack.hottestTempC,
    demandKw,
    pack.overallSoc,
    profile
  );

  const packCurrent = opt.selectedCurrentA;

  // 2. Step each cell in each module
  let sumSoc = 0;
  let sumSoh = 0;
  let totalCellCount = 0;
  let maxCellTemp = -Infinity;
  let sumCellTemp = 0;
  let maxCellRes = -Infinity;
  let bottleneckCellId = 1;
  let bottleneckReason = "Nominal Balanced Condition";

  // Coolant physics modeling: entrance coolant picks up heat as it moves along modules
  let coolantTemp = 18.0; // Coolant entrance temp °C
  const coolantFlowLS = opt.recommendedCoolingLS;
  const thermalCapCoolant = coolantFlowLS * 1.0 * SPECIFIC_HEAT_WATER; // effective W/K carrying capacity

  const updatedModules = modules.map((mod) => {
    const updatedCells = mod.cells.map((cl) => {
      // Resistance depends on state
      const resistance = calculateCellResistance(cl.temperatureC, cl.soc, cl.soh);
      
      // Open circuit voltage
      const ocv = calculateOCV(cl.soc);

      // KVL terminal voltage
      const vt = ocv + packCurrent * resistance - cl.polarizationV;

      // Bernardi heat generation rate
      const heatGenW = calculateHeatGeneration(packCurrent, cl.soc, cl.temperatureC, resistance);

      // Convective cooling system heat transfer
      // h * A coefficient
      const heatCoeff = 1.8 + Math.sqrt(coolantFlowLS) * 3.5; // effective heat dissipation W/K
      const heatRemovedW = heatCoeff * (cl.temperatureC - coolantTemp);

      // Accumulation
      const netHeatW = heatGenW - heatRemovedW;

      // Update temperature
      const thermalMassJK = 75.0; // standard cell thermal mass J/K
      const deltaTempC = (netHeatW * dtSeconds) / thermalMassJK;
      const nextTempC = Math.max(10.0, Math.min(65.0, cl.temperatureC + deltaTempC));

      // Update coolant temp
      if (thermalCapCoolant > 0) {
        coolantTemp += Math.max(0, heatRemovedW) / thermalCapCoolant;
      }

      // Coulomb counting for state of charge
      const capacityAs = NOMINAL_CAPACITY_AH * 3600.0;
      const efficiencyMultiplier = packCurrent > 0 ? 0.985 : 1.0;
      const deltaSoc = (packCurrent * efficiencyMultiplier * dtSeconds) / capacityAs;
      let nextSoc = Math.max(0.0, Math.min(1.0, cl.soc + deltaSoc));

      // Active passive cell balancing: bleed off charge for high cells if active
      if (isBalancingActive && cl.soc > 0.65) {
        // dissipate 50mA
        const bleedCurrentA = -0.05;
        const bleedSoc = (bleedCurrentA * dtSeconds) / capacityAs;
        nextSoc = Math.max(0.0, nextSoc + bleedSoc);
      }

      // Dynamic RC polarization relaxation
      const rcConstant = 18.0; // 18s relaxation
      const targetPolarization = Math.abs(packCurrent) * 0.0018;
      const nextPolarization = cl.polarizationV + (targetPolarization - cl.polarizationV) * (dtSeconds / rcConstant);

      // Lifetime cycles and SOH decay
      const cycleDecay = Math.abs(packCurrent * dtSeconds) / capacityAs / 2.0;
      const nextCycles = cl.cumulativeCycles + cycleDecay;
      // capacity degradation function
      const nextSoh = Math.max(0.5, 1.0 - nextCycles * 0.00015);

      sumSoc += nextSoc;
      sumSoh += nextSoh;
      totalCellCount++;

      sumCellTemp += nextTempC;
      if (nextTempC > maxCellTemp) {
        maxCellTemp = nextTempC;
        if (nextTempC > 45.0) {
          bottleneckCellId = cl.id;
          bottleneckReason = `Thermal bottleneck: Cell #${cl.id} temperature is ${nextTempC.toFixed(1)}°C`;
        }
      }

      if (resistance > maxCellRes) {
        maxCellRes = resistance;
        if (resistance > 0.022 && maxCellTemp <= 45.0) {
          bottleneckCellId = cl.id;
          bottleneckReason = `Resistance bottleneck: Cell #${cl.id} resistance is ${(resistance * 1000).toFixed(1)} mΩ`;
        }
      }

      // If SOC is near depletion, it becomes the ultimate discharge bottleneck
      if (nextSoc < 0.15 && bottleneckReason.indexOf("Thermal") === -1) {
        bottleneckCellId = cl.id;
        bottleneckReason = `Capacity depletion: Cell #${cl.id} is low at ${(nextSoc * 100).toFixed(1)}% SOC`;
      }

      return {
        ...cl,
        soc: nextSoc,
        soh: nextSoh,
        temperatureC: nextTempC,
        voltageV: vt,
        internalResistanceOhm: resistance,
        heatGenerationW: heatGenW,
        polarizationV: nextPolarization,
        cumulativeCycles: nextCycles,
      };
    });

    const modVoltage = updatedCells.reduce((sum, cl) => sum + cl.voltageV, 0);
    const modResistance = updatedCells.reduce((sum, cl) => sum + cl.internalResistanceOhm, 0);

    return {
      ...mod,
      cells: updatedCells,
      voltageV: modVoltage,
      resistanceOhm: modResistance,
      averageTempC: updatedCells.reduce((sum, cl) => sum + cl.temperatureC, 0) / updatedCells.length,
      averageSoc: updatedCells.reduce((sum, cl) => sum + cl.soc, 0) / updatedCells.length,
    };
  });

  updateImbalances(updatedModules);

  const packVoltage = updatedModules.reduce((sum, m) => sum + m.voltageV, 0);
  const packResistance = updatedModules.reduce((sum, m) => sum + m.resistanceOhm, 0);
  const overallSoc = sumSoc / totalCellCount;
  const overallSoh = sumSoh / totalCellCount;

  // Active pump speed calculation
  const pumpSpeedRpm = Math.min(3000, 800 + Math.pow(coolantFlowLS, 1.5) * 1200);
  const parasiticLossW = 50.0 + Math.pow(pumpSpeedRpm / 1000, 3) * 35.0; // pumping cubic penalty

  const usefulPowerKw = (packVoltage * packCurrent) / 1000.0;
  const totalLossesW = Math.pow(packCurrent, 2) * packResistance + parasiticLossW;

  const updatedPack: PackState = {
    overallSoc,
    overallSoh,
    totalVoltageV: packVoltage,
    currentA: packCurrent,
    dynamicResistanceOhm: packResistance,
    performanceIndex: opt.performanceIndex,
    hottestTempC: maxCellTemp,
    averageTempC: sumCellTemp / totalCellCount,
    bottleneckReason,
    bottleneckCellId,
    coolingFlowLS: coolantFlowLS,
    pumpSpeedRpm,
    parasiticLossW,
    usefulPowerKw,
    lossesW: totalLossesW,
  };

  return { pack: updatedPack, modules: updatedModules };
}
