# SolarOS

A photovoltaic simulation and optimisation engine. SolarOS models the
complete energy chain from sunlight to delivered electricity, then searches
for every practical way to increase power output, energy yield, system
efficiency and annual production **within the physical limits of the
installed hardware**.

> Do not pretend to create more solar energy. Recover more of the available
> solar energy by reducing avoidable losses and optimising the entire
> photovoltaic system.

```
SUN -> IRRADIANCE -> PANEL -> CELL -> DC -> MPPT -> INVERTER -> BATTERY/GRID/LOAD
```

## Install

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
```

## Quickstart

```python
from solaros.geometry.site import Site
from solaros.photovoltaic.module import get_preset
from solaros.photovoltaic.array import ArrayLayout
from solaros.electrical.inverter import InverterParameters
from solaros.core.simulation import SystemConfig
from solaros.simulation.year import simulate_year
from solaros.optimise import optimise_system
from solaros.weather.weather import generate_synthetic_weather
from solaros.core.clock import build_time_index
from solaros.core.configuration import TimeResolution

site = Site(name="my-roof", latitude_deg=52.5, longitude_deg=13.4, timezone="UTC")
system = SystemConfig(
    site=site,
    panel=get_preset("mono-si"),
    layout=ArrayLayout(modules_per_string=20, strings_parallel=5),
    inverter=InverterParameters(rated_ac_power_w=35_000),
    tilt_deg=35, azimuth_deg=180,
)

state = simulate_year(system)
print(state.summary(system.panel.rated_power_w * system.layout.total_modules))

weather = generate_synthetic_weather(build_time_index(2024, TimeResolution.HOURLY, "UTC"))
report = optimise_system(system, weather)
print(report.summary())
```

```
BASELINE:  9,554 kWh/year
OPTIMISED: 16,500 kWh/year
GAIN:      +6,946 kWh/year (+72.7%)

Contribution by lever:
  tilt                          +730 kWh  -> {'tilt_deg': 35.8}
  azimuth                       +716 kWh  -> {'azimuth_deg': 178.0}
  cleaning_policy                +12 kWh  -> {'cleaning_policy': 'monthly'}
  tracking                    +5,489 kWh  -> {'tracking_mode': 'dual_axis'}
```

Run `uvicorn solaros.api.main:app --reload` to expose the same engine over
HTTP (`POST /simulate`, `/simulate/year`, `/sweep`, `/monte-carlo`,
`/optimise`, `GET /panels`, `/weather`, `/results/{id}`, `/losses/{id}`).
The API is a thin wrapper -- everything works standalone from Python, with
or without a battery attached.

## Architecture

```
solaros/
├── core/            simulation orchestrator, clock, config, result state
├── solar/           sun position, irradiance, spectrum, shading, atmosphere
├── photovoltaic/    single-diode cell model, module, array, temperature,
│                    degradation, soiling
├── electrical/      I-V/P-V curves + bypass diodes, MPPT, inverter, DC bus,
│                    wiring losses
├── geometry/         panel orientation, tracking (single/dual-axis), site
├── weather/          weather abstraction, clouds, wind, temperature
├── storage/          optional battery + self-consumption dispatch
├── optimisation/     tilt, azimuth, tracking, MPPT, cooling, layout
├── simulation/        simulate_year(), scenario/sweep runner, Monte Carlo
├── economics/         production, energy value, LCOE/NPV/payback
├── visualisation/      I-V/P-V, sun path, irradiance, temperature, monthly/
│                       annual generation, shading map, layout, energy
│                       waterfall, temperature coefficient, MPPT behaviour
├── api/                FastAPI surface over the same engine
└── optimise.py         optimise_system(): the top-level BASELINE/OPTIMISED/GAIN report
```

The optimisation loop the whole package implements:

```
MEASURE -> MODEL -> SIMULATE -> OPTIMISE -> COMPARE -> SELECT BEST CONFIGURATION
```

## Physical model, and where it is *not* exact

Every computed quantity in SolarOS is traceable to one of four model bases
(`solaros.core.configuration.ModelBasis`), and the docstring at the top of
every module states which ones it uses:

- **PHYSICAL** -- first-principles (the single-diode equation solved in
  closed form via the Lambert W function; AOI/tracking geometry; series/
  parallel circuit combination for bypass diodes and string mismatch).
- **SIMPLIFIED** -- a physically-motivated reduced-order model traded for
  auditability/speed (isotropic sky-diffuse transposition instead of Perez;
  Spencer-series solar position instead of the full NREL SPA; a 1-D
  profile-angle projection for row-to-row shading).
- **EMPIRICAL** -- fitted to reference datasets, not derived (NOCT/Faiman
  thermal models, inverter efficiency curve, cloud-cover attenuation,
  soiling accumulation).
- **USER_DATA** -- taken verbatim from what you provide (a historical
  weather file, directly-specified single-diode parameters).

Two results are worth knowing about specifically:

- **Datasheet parameter extraction** (`photovoltaic.cell.extract_single_diode_parameters`)
  is a single-pass approximation (assumes Rsh >> Rs while solving Rs from
  the MPP condition). It reproduces Voc/Isc/Vmp/Imp/Pmp to within a few
  percent of the datasheet, not exactly -- pass `series_resistance_ohm` /
  `shunt_resistance_ohm` directly on `CellParameters` for a precisely
  calibrated cell.
- **Degradation rates are configurable, not measured.** `DegradationModel`
  will compute a lifetime-energy number from whatever annual rate you give
  it; it does not claim that rate is correct for a specific panel without
  field data to back it up (spec requirement: never assert exact
  degradation without empirical calibration).

## The loss waterfall

`core.simulation.run_simulation()` returns a `SimulationState` whose
`losses` (a `LossWaterfall`) is constructed so that every stage is an exact
stage-to-stage energy difference:

```
Solar resource
  -> Optical loss (glazing transmission, AOI reflection, spectral mismatch)
  -> Shading loss (obstructions + row-to-row self-shading)
  -> Conversion-efficiency loss (single-diode cell physics at 25 degC reference)
  -> Thermal loss (real cell temperature vs the 25 degC reference -- can be
     *negative*: a cold, sunny day produces more than STC-rated power)
  -> Mismatch loss (manufacturing/aging power-tolerance spread)
  -> Soiling loss
  -> Degradation loss
  -> DC wiring loss
  -> MPPT tracking loss
  -> Inverter loss (conversion + clipping + below-threshold non-startup)
  -> AC wiring loss + parasitic night-standby consumption
= Net AC electricity
```

`solar_resource_kwh - sum(all losses) == net_ac_kwh` exactly (see
`tests/test_simulation_energy_balance.py::test_loss_waterfall_telescopes_exactly_to_net_ac`),
and `visualisation.plots.plot_energy_waterfall` renders it directly.

## "More electricity" means net, useful, delivered electricity

Spec-driven design constraint, enforced throughout: **gross generation is
not the objective**. `optimisation.cooling.evaluate_cooling_scenarios`
explicitly maximises *net* energy (generation minus the fan/pump power the
cooling system itself consumes) rather than minimising panel temperature --
the scenario with the coldest cells is not always the best one.
`photovoltaic.soiling.optimise_cleaning_policy` weighs recovered energy
against labour/water cost, not just against soiling loss.
`economics.energy_value` distinguishes energy *generated* from energy
*delivered* (self-consumed vs exported, at different prices) from energy
*valued* (a marginal kWh from an upgrade is worth less than the average once
self-consumption is already saturated).

## Performance

The annual simulation loop vectorises the single-diode MPP solve across the
whole time series in one Lambert-W call rather than looping per hour
(`photovoltaic.array.uniform_array_power_w`); a full 8760-hour year runs in
~2 seconds on a laptop core. Parameter sweeps
(`simulation.scenarios.parameter_sweep`) and Monte Carlo yield assessment
(`simulation.monte_carlo.run_monte_carlo`) parallelise across combinations/
runs with `ProcessPoolExecutor`. Detailed bypass-diode/string-mismatch
circuit resolution (`photovoltaic.array.simulate_array`) is reserved for
single-condition studies (partial shading demos, layout optimisation) rather
than run every hour of the year -- the annual loop applies the measured
mismatch/MPPT-tracking loss fractions instead. `optimise_system()` runs a
sequential (coordinate-ascent) search across tilt/azimuth/cleaning/tracking/
MPPT rather than a full joint combinatorial search, trading global
optimality for a bounded number of simulations per call.

## Testing

```bash
pytest -q
```

71+ tests cover solar geometry, irradiance, the single-diode model
(including a Lambert-W overflow regression test), temperature response,
I-V/P-V curves with bypass-diode partial shading, MPPT algorithm comparison,
inverter clipping/efficiency, shading, whole-system energy-balance/
waterfall consistency, edge cases (zero irradiance, extreme heat/cold, heavy
snow-equivalent soiling, rapid cloud transitions, an undersized inverter),
economics, and the FastAPI surface.
