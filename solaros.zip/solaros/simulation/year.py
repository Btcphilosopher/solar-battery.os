"""The single most common entry point: simulate one full year for one system."""
from __future__ import annotations

from typing import Optional

from solaros.core.clock import build_time_index
from solaros.core.configuration import SimulationConfig, TimeResolution
from solaros.core.simulation import SystemConfig, run_simulation
from solaros.core.state import SimulationState
from solaros.weather.weather import WeatherSeries, generate_synthetic_weather


def simulate_year(
    system: SystemConfig,
    weather: Optional[WeatherSeries] = None,
    year: int = 2024,
    resolution: TimeResolution = TimeResolution.HOURLY,
    config: Optional[SimulationConfig] = None,
    weather_random_seed: Optional[int] = None,
) -> SimulationState:
    """Simulate hourly (or finer) irradiance -> ... -> AC electricity for one
    full calendar year. If no `weather` is supplied, generates a statistically
    plausible synthetic year for the system's site (SIMPLIFIED/EMPIRICAL --
    swap in `weather.weather.load_historical_weather` for a real site file).
    """
    config = config or SimulationConfig(resolution=resolution, year=year)
    if weather is None:
        timestamps = build_time_index(year, resolution, system.site.timezone)
        weather = generate_synthetic_weather(timestamps, random_seed=weather_random_seed)
    return run_simulation(system, weather, config)
