"""Scenario comparison and parameter sweeps: run the same weather year
through many system configurations and line the results up side by side.
"""
from __future__ import annotations

import itertools
from concurrent.futures import ProcessPoolExecutor
from typing import Any, Callable, Optional

import pandas as pd

from solaros.core.configuration import Scenario, SimulationConfig
from solaros.core.simulation import SystemConfig, run_simulation
from solaros.weather.weather import WeatherSeries


def _apply_overrides(system: SystemConfig, overrides: dict[str, Any]) -> SystemConfig:
    """Apply a flat dict of dotted-path overrides, e.g. {"tilt_deg": 25, "panel.degradation_rate_pct_per_year": 0.4}."""
    data = system.model_dump()
    for path, value in overrides.items():
        keys = path.split(".")
        node = data
        for key in keys[:-1]:
            node = node[key]
        node[keys[-1]] = value
    return SystemConfig.model_validate(data)


def run_scenarios(
    base_system: SystemConfig,
    weather: WeatherSeries,
    scenarios: list[Scenario],
    config: Optional[SimulationConfig] = None,
) -> pd.DataFrame:
    """Run one weather year through each scenario's overrides on top of `base_system`."""
    rows = []
    for scenario in scenarios:
        system = _apply_overrides(base_system, scenario.overrides)
        state = run_simulation(system, weather, config)
        rated_w = system.panel.rated_power_w * system.layout.total_modules
        row = {"scenario": scenario.name, "description": scenario.description}
        row.update(state.summary(rated_w))
        row.update({f"loss_{k}": v for k, v in state.losses.as_dict().items()})
        rows.append(row)
    return pd.DataFrame(rows).set_index("scenario")


def _sweep_worker(args: tuple) -> dict:
    base_system, weather, config, combo = args
    system = _apply_overrides(base_system, combo)
    state = run_simulation(system, weather, config)
    rated_w = system.panel.rated_power_w * system.layout.total_modules
    row = dict(combo)
    row.update(state.summary(rated_w))
    return row


def parameter_sweep(
    base_system: SystemConfig,
    weather: WeatherSeries,
    param_grid: dict[str, list[Any]],
    config: Optional[SimulationConfig] = None,
    max_workers: Optional[int] = None,
) -> pd.DataFrame:
    """Evaluate every combination in `param_grid` (e.g. {"tilt_deg": [20, 30, 40],
    "azimuth_deg": [150, 180, 210]}) against annual kWh, peak power, and losses.
    Runs combinations in parallel processes -- the point of a sweep is testing
    thousands of configurations, which a single core shouldn't have to do serially.
    """
    keys = list(param_grid)
    combos = [dict(zip(keys, values)) for values in itertools.product(*(param_grid[k] for k in keys))]
    tasks = [(base_system, weather, config, combo) for combo in combos]

    if max_workers == 1 or len(tasks) <= 1:
        rows = [_sweep_worker(t) for t in tasks]
    else:
        with ProcessPoolExecutor(max_workers=max_workers) as pool:
            rows = list(pool.map(_sweep_worker, tasks))

    return pd.DataFrame(rows)


def pareto_frontier(
    df: pd.DataFrame,
    maximize: list[str],
    minimize: Optional[list[str]] = None,
) -> pd.DataFrame:
    """Rows not dominated by any other row: no other row is at least as good on
    every objective and strictly better on at least one. Useful when e.g.
    "more annual kWh" and "lower cost" trade off against each other.
    """
    minimize = minimize or []
    values = df[maximize].to_numpy(dtype=float) if maximize else None
    neg_values = -df[minimize].to_numpy(dtype=float) if minimize else None
    import numpy as np

    score = np.concatenate([a for a in (values, neg_values) if a is not None], axis=1)
    n = len(df)
    dominated = np.zeros(n, dtype=bool)
    for i in range(n):
        if dominated[i]:
            continue
        at_least_as_good = np.all(score >= score[i], axis=1)
        strictly_better = np.any(score > score[i], axis=1)
        dominates_i = at_least_as_good & strictly_better
        dominates_i[i] = False
        if np.any(dominates_i):
            dominated[i] = True
    return df.loc[~dominated].copy()
