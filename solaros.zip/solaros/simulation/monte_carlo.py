"""Monte Carlo yield assessment: run many plausible years and report the
P90/P50/P10 exceedance-probability yields used in real bankability studies.

Convention (industry-standard, not "10th/50th/90th percentile" naming, which
is easy to get backwards): P90 is the yield *exceeded* 90% of the time (the
conservative, bankable low case -- the 10th percentile of the distribution);
P10 is exceeded only 10% of the time (the optimistic high case -- the 90th
percentile). P50 is the median.
"""
from __future__ import annotations

from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass
from typing import Callable, Optional

import numpy as np
import pandas as pd

from solaros.core.clock import build_time_index
from solaros.core.configuration import TimeResolution
from solaros.core.simulation import SystemConfig, run_simulation
from solaros.simulation.scenarios import _apply_overrides
from solaros.weather.weather import generate_synthetic_weather


@dataclass
class MonteCarloResult:
    annual_kwh_samples: np.ndarray
    p90_kwh: float
    p50_kwh: float
    p10_kwh: float
    samples: pd.DataFrame

    @property
    def mean_kwh(self) -> float:
        return float(np.mean(self.annual_kwh_samples))

    @property
    def std_kwh(self) -> float:
        return float(np.std(self.annual_kwh_samples))


def _mc_worker(args: tuple) -> dict:
    base_system, year, resolution, timezone, seed, overrides, weather_kwargs = args
    system = _apply_overrides(base_system, overrides) if overrides else base_system
    timestamps = build_time_index(year, resolution, timezone)
    weather = generate_synthetic_weather(timestamps, random_seed=seed, **weather_kwargs)
    state = run_simulation(system, weather)
    row = {"annual_ac_kwh": state.annual_ac_kwh, "weather_seed": seed}
    row.update(overrides)
    return row


def run_monte_carlo(
    base_system: SystemConfig,
    n_runs: int = 200,
    year: int = 2024,
    resolution: TimeResolution = TimeResolution.HOURLY,
    param_distributions: Optional[dict[str, Callable[[np.random.Generator], float]]] = None,
    weather_temp_std_c: float = 1.5,
    weather_cloud_std_fraction: float = 0.08,
    base_annual_mean_temp_c: float = 12.0,
    base_mean_cloud_cover_fraction: float = 0.40,
    random_seed: Optional[int] = None,
    max_workers: Optional[int] = None,
) -> MonteCarloResult:
    """Uncertainty sources: weather (temperature/cloudiness realisation, via a
    fresh random seed and perturbed climatology per run) and, if supplied,
    any system parameter with a sampling function in `param_distributions`
    (e.g. {"soiling.daily_soiling_rate_pct": lambda rng: rng.normal(0.06, 0.02)}).
    """
    rng = np.random.default_rng(random_seed)
    param_distributions = param_distributions or {}

    tasks = []
    for _ in range(n_runs):
        seed = int(rng.integers(0, 2**31 - 1))
        overrides = {name: float(sampler(rng)) for name, sampler in param_distributions.items()}
        weather_kwargs = {
            "annual_mean_temp_c": base_annual_mean_temp_c + rng.normal(0, weather_temp_std_c),
            "mean_cloud_cover_fraction": float(
                np.clip(base_mean_cloud_cover_fraction + rng.normal(0, weather_cloud_std_fraction), 0.02, 0.95)
            ),
        }
        tasks.append((base_system, year, resolution, base_system.site.timezone, seed, overrides, weather_kwargs))

    if max_workers == 1 or n_runs <= 1:
        rows = [_mc_worker(t) for t in tasks]
    else:
        with ProcessPoolExecutor(max_workers=max_workers) as pool:
            rows = list(pool.map(_mc_worker, tasks))

    samples = pd.DataFrame(rows)
    kwh = samples["annual_ac_kwh"].to_numpy()

    return MonteCarloResult(
        annual_kwh_samples=kwh,
        p90_kwh=float(np.percentile(kwh, 10)),
        p50_kwh=float(np.percentile(kwh, 50)),
        p10_kwh=float(np.percentile(kwh, 90)),
        samples=samples,
    )
