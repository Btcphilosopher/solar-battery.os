"""Engineering visualisations. Every function returns a matplotlib Figure
(caller decides whether to show/save/embed it) and uses the non-interactive
Agg backend so this module is safe to import in a headless API server.
"""
from __future__ import annotations

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from solaros.core.state import LossWaterfall
from solaros.electrical.iv_curve import IVCurve
from solaros.electrical.mppt import MPPTResult
from solaros.solar.sun_position import solar_position


def plot_iv_curve(curve: IVCurve, title: str = "I-V curve") -> plt.Figure:
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.plot(curve.voltage_v, curve.current_a, color="tab:blue")
    v_mp, i_mp, _ = curve.mpp()
    ax.scatter([v_mp], [i_mp], color="tab:red", zorder=5, label=f"MPP ({v_mp:.1f} V, {i_mp:.1f} A)")
    ax.set_xlabel("Voltage (V)")
    ax.set_ylabel("Current (A)")
    ax.set_title(title)
    ax.legend()
    ax.grid(alpha=0.3)
    return fig


def plot_pv_curve(curve: IVCurve, title: str = "P-V curve") -> plt.Figure:
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.plot(curve.voltage_v, curve.power_w, color="tab:orange")
    v_mp, _, p_mp = curve.mpp()
    ax.scatter([v_mp], [p_mp], color="tab:red", zorder=5, label=f"Pmp = {p_mp:.0f} W")
    ax.set_xlabel("Voltage (V)")
    ax.set_ylabel("Power (W)")
    ax.set_title(title)
    ax.legend()
    ax.grid(alpha=0.3)
    return fig


def plot_sun_path(latitude_deg: float, longitude_deg: float, year: int = 2024) -> plt.Figure:
    fig, ax = plt.subplots(figsize=(7, 6))
    for month, label in [(12, "Winter solstice"), (6, "Summer solstice"), (3, "Equinox")]:
        day = 21
        timestamps = pd.date_range(f"{year}-{month:02d}-{day:02d}", periods=24 * 12, freq="5min", tz="UTC")
        sun = solar_position(timestamps, latitude_deg, longitude_deg)
        above = sun.above_horizon
        ax.plot(sun.azimuth_deg[above], sun.elevation_deg[above], label=label)
    ax.set_xlabel("Azimuth (deg, 0=N, 90=E, 180=S, 270=W)")
    ax.set_ylabel("Elevation (deg)")
    ax.set_title(f"Sun path at lat={latitude_deg:.1f}, lon={longitude_deg:.1f}")
    ax.legend()
    ax.grid(alpha=0.3)
    return fig


def plot_irradiance(timestamps: pd.DatetimeIndex, poa_irradiance_w_m2: np.ndarray, title: str = "Plane-of-array irradiance") -> plt.Figure:
    fig, ax = plt.subplots(figsize=(9, 4))
    ax.plot(timestamps, poa_irradiance_w_m2, color="tab:orange", linewidth=0.8)
    ax.set_ylabel("POA irradiance (W/m^2)")
    ax.set_title(title)
    ax.grid(alpha=0.3)
    fig.autofmt_xdate()
    return fig


def plot_panel_temperature(
    timestamps: pd.DatetimeIndex, cell_temperature_c: np.ndarray, ambient_temperature_c: np.ndarray
) -> plt.Figure:
    fig, ax = plt.subplots(figsize=(9, 4))
    ax.plot(timestamps, cell_temperature_c, label="cell temperature", color="tab:red", linewidth=0.8)
    ax.plot(timestamps, ambient_temperature_c, label="ambient temperature", color="tab:blue", linewidth=0.8)
    ax.set_ylabel("Temperature (degC)")
    ax.set_title("Panel vs ambient temperature")
    ax.legend()
    ax.grid(alpha=0.3)
    fig.autofmt_xdate()
    return fig


def plot_monthly_generation(monthly_kwh: pd.Series, title: str = "Monthly AC generation") -> plt.Figure:
    fig, ax = plt.subplots(figsize=(8, 4))
    ax.bar(monthly_kwh.index.strftime("%b"), monthly_kwh.to_numpy(), color="tab:green")
    ax.set_ylabel("Energy (kWh)")
    ax.set_title(title)
    ax.grid(alpha=0.3, axis="y")
    return fig


def plot_annual_generation(daily_kwh: pd.Series, title: str = "Daily AC generation over the year") -> plt.Figure:
    fig, ax = plt.subplots(figsize=(10, 4))
    ax.fill_between(daily_kwh.index, daily_kwh.to_numpy(), color="tab:green", alpha=0.6)
    ax.set_ylabel("Energy (kWh/day)")
    ax.set_title(title)
    ax.grid(alpha=0.3)
    fig.autofmt_xdate()
    return fig


def plot_shading_map(az_mesh: np.ndarray, el_mesh: np.ndarray, blocked_fraction: np.ndarray) -> plt.Figure:
    fig, ax = plt.subplots(figsize=(8, 5))
    mesh = ax.pcolormesh(az_mesh, el_mesh, blocked_fraction, cmap="Greys", vmin=0, vmax=1, shading="auto")
    fig.colorbar(mesh, ax=ax, label="blocked fraction")
    ax.set_xlabel("Azimuth (deg)")
    ax.set_ylabel("Elevation (deg)")
    ax.set_title("Sky-dome shading map")
    return fig


def plot_layout(modules_per_string: int, strings_parallel: int, tilt_deg: float, ground_coverage_ratio: float, module_width_m: float = 1.0) -> plt.Figure:
    """Simple top-down schematic: rows of modules with pitch set by the ground coverage ratio."""
    pitch_m = module_width_m / max(ground_coverage_ratio, 1e-6)
    fig, ax = plt.subplots(figsize=(6, 6))
    for row in range(strings_parallel):
        y0 = row * pitch_m
        ax.add_patch(plt.Rectangle((0, y0), modules_per_string * module_width_m * 0.98, module_width_m * np.cos(np.radians(tilt_deg)), color="tab:blue", alpha=0.7))
    ax.set_xlim(-1, modules_per_string * module_width_m + 1)
    ax.set_ylim(-1, strings_parallel * pitch_m + 1)
    ax.set_aspect("equal")
    ax.set_xlabel("Row length (m)")
    ax.set_ylabel("Row spacing (m)")
    ax.set_title(f"Array layout (GCR={ground_coverage_ratio:.2f}, tilt={tilt_deg:.0f} deg)")
    return fig


def plot_energy_waterfall(losses: LossWaterfall) -> plt.Figure:
    """Solar resource at the top, each stage's loss stepping the running total
    down, net AC electricity as the final full bar -- by construction (the
    loss fields are defined as exact stage-to-stage differences in
    core.simulation.run_simulation) the bars telescope exactly to net_ac_kwh.
    """
    loss_stages = [
        ("Optical loss", losses.optical_loss_kwh),
        ("Shading loss", losses.shading_loss_kwh),
        ("Conversion efficiency", losses.conversion_efficiency_loss_kwh),
        ("Thermal", losses.thermal_loss_kwh),
        ("Mismatch", losses.mismatch_loss_kwh),
        ("Soiling", losses.soiling_loss_kwh),
        ("Degradation", losses.degradation_loss_kwh),
        ("DC wiring", losses.dc_wiring_loss_kwh),
        ("MPPT", losses.mppt_loss_kwh),
        ("Inverter", losses.inverter_loss_kwh),
        ("AC wiring/standby", losses.ac_wiring_loss_kwh),
    ]

    labels = ["Solar resource"]
    bar_bottoms = [0.0]
    bar_heights = [losses.solar_resource_kwh]
    colors = ["tab:blue"]

    cumulative = losses.solar_resource_kwh
    for label, loss in loss_stages:
        new_cumulative = cumulative - loss
        labels.append(label)
        bar_bottoms.append(min(cumulative, new_cumulative))
        bar_heights.append(abs(loss))
        colors.append("tab:red" if loss >= 0 else "tab:green")  # green = a net thermal *gain* over STC
        cumulative = new_cumulative

    labels.append("Net AC electricity")
    bar_bottoms.append(0.0)
    bar_heights.append(cumulative)
    colors.append("tab:blue")

    fig, ax = plt.subplots(figsize=(11, 5))
    ax.bar(labels, bar_heights, bottom=bar_bottoms, color=colors)
    ax.set_ylabel("Energy (kWh)")
    ax.set_title("Solar resource -> net AC electricity")
    plt.setp(ax.get_xticklabels(), rotation=35, ha="right")
    ax.grid(alpha=0.3, axis="y")
    fig.tight_layout()
    return fig


def plot_temperature_coefficient(cell_temperature_c: np.ndarray, power_w: np.ndarray, technology: str = "") -> plt.Figure:
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.scatter(cell_temperature_c, power_w, s=6, alpha=0.4, color="tab:red")
    order = np.argsort(cell_temperature_c)
    fit = np.poly1d(np.polyfit(cell_temperature_c, power_w, 1))
    ax.plot(cell_temperature_c[order], fit(cell_temperature_c[order]), color="black", linewidth=2, label=f"slope={fit[1]:.2f} W/degC")
    ax.set_xlabel("Cell temperature (degC)")
    ax.set_ylabel("DC power (W)")
    ax.set_title(f"Temperature response {technology}".strip())
    ax.legend()
    ax.grid(alpha=0.3)
    return fig


def plot_mppt_behaviour(results: dict[str, MPPTResult]) -> plt.Figure:
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(9, 7), sharex=True)
    steps = None
    for name, r in results.items():
        steps = np.arange(len(r.power_w))
        ax1.plot(steps, r.power_w, label=name, linewidth=1.2)
    if steps is not None:
        any_result = next(iter(results.values()))
        ax1.plot(steps, any_result.true_mpp_power_w, "--", color="black", linewidth=1, label="true MPP")
    ax1.set_ylabel("Power (W)")
    ax1.legend(fontsize=8)
    ax1.grid(alpha=0.3)

    for name, r in results.items():
        ax2.plot(steps, r.voltage_v, label=name, linewidth=1.2)
    ax2.set_xlabel("Timestep")
    ax2.set_ylabel("Operating voltage (V)")
    ax2.grid(alpha=0.3)

    fig.suptitle("MPPT algorithm comparison")
    return fig
