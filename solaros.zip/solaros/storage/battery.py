"""Battery energy storage: optional, and deliberately decoupled from the PV
engine (spec #29) -- everything upstream of this module works with zero
knowledge that a battery might be attached.

Model basis: SIMPLIFIED. A single-node energy-capacity model (state of
charge in kWh, round-trip efficiency applied on charge, power/SOC limits)
rather than an electrochemical (equivalent-circuit or degradation-aware)
battery model.
"""
from __future__ import annotations

from pydantic import BaseModel, Field


class BatteryParameters(BaseModel):
    capacity_kwh: float = Field(..., gt=0)
    max_charge_power_w: float = Field(..., gt=0)
    max_discharge_power_w: float = Field(..., gt=0)
    round_trip_efficiency_fraction: float = Field(0.90, gt=0, le=1)
    min_soc_fraction: float = Field(0.10, ge=0, lt=1)
    max_soc_fraction: float = Field(1.00, gt=0, le=1)
    initial_soc_fraction: float = Field(0.50, ge=0, le=1)

    @property
    def usable_capacity_kwh(self) -> float:
        return self.capacity_kwh * (self.max_soc_fraction - self.min_soc_fraction)

    @property
    def one_way_efficiency_fraction(self) -> float:
        return self.round_trip_efficiency_fraction**0.5
