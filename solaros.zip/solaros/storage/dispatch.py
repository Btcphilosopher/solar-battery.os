"""Battery dispatch: a self-consumption-maximising policy -- charge from PV
surplus, discharge to cover load deficit, otherwise fall back to the grid.
Inherently sequential (state of charge carries between steps), so this is a
plain Python loop; still fast at the 8760-step annual scale.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from solaros.storage.battery import BatteryParameters


@dataclass
class DispatchResult:
    soc_kwh: np.ndarray
    battery_charge_w: np.ndarray
    battery_discharge_w: np.ndarray
    grid_import_w: np.ndarray
    grid_export_w: np.ndarray
    self_consumed_pv_w: np.ndarray

    def self_consumption_fraction(self, pv_ac_power_w: np.ndarray) -> float:
        pv_total = float(np.sum(pv_ac_power_w))
        return float(np.sum(self.self_consumed_pv_w) / pv_total) if pv_total else float("nan")


def simulate_self_consumption_dispatch(
    pv_ac_power_w: np.ndarray,
    load_power_w: np.ndarray,
    battery: BatteryParameters,
    step_hours: float,
) -> DispatchResult:
    pv = np.asarray(pv_ac_power_w, dtype=float)
    load = np.asarray(load_power_w, dtype=float)
    n = len(pv)

    eta = battery.one_way_efficiency_fraction
    min_kwh = battery.capacity_kwh * battery.min_soc_fraction
    max_kwh = battery.capacity_kwh * battery.max_soc_fraction
    soc_kwh_now = battery.capacity_kwh * battery.initial_soc_fraction

    soc_kwh = np.zeros(n)
    charge_w = np.zeros(n)
    discharge_w = np.zeros(n)
    grid_import_w = np.zeros(n)
    grid_export_w = np.zeros(n)
    direct_self_consumed_w = np.minimum(pv, np.maximum(load, 0.0))

    for idx in range(n):
        net_w = pv[idx] - load[idx]

        if net_w > 0:
            headroom_kwh = max(max_kwh - soc_kwh_now, 0.0)
            max_from_headroom_w = (headroom_kwh * 1000.0) / (step_hours * eta) if step_hours > 0 else 0.0
            c = min(net_w, battery.max_charge_power_w, max_from_headroom_w)
            soc_kwh_now += c * step_hours * eta / 1000.0
            charge_w[idx] = c
            grid_export_w[idx] = net_w - c
        else:
            deficit_w = -net_w
            available_kwh = max(soc_kwh_now - min_kwh, 0.0)
            max_from_available_w = (available_kwh * 1000.0 * eta) / step_hours if step_hours > 0 else 0.0
            d = min(deficit_w, battery.max_discharge_power_w, max_from_available_w)
            soc_kwh_now -= (d * step_hours) / (eta * 1000.0)
            discharge_w[idx] = d
            grid_import_w[idx] = deficit_w - d

        soc_kwh[idx] = soc_kwh_now

    self_consumed_pv_w = direct_self_consumed_w + discharge_w

    return DispatchResult(
        soc_kwh=soc_kwh,
        battery_charge_w=charge_w,
        battery_discharge_w=discharge_w,
        grid_import_w=grid_import_w,
        grid_export_w=grid_export_w,
        self_consumed_pv_w=self_consumed_pv_w,
    )
