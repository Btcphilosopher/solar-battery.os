"""DC/AC inverter: conversion efficiency (loading-dependent), night standby
draw, and clipping when DC input exceeds the inverter's AC nameplate rating.

Model basis: EMPIRICAL. The quadratic loss curve is the same reduced-order
shape used by the Sandia and CEC inverter performance models (a no-load
tare loss, a loss linear in DC power, and a loss quadratic in loading), with
three configurable coefficients instead of the full multi-parameter fit.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from pydantic import BaseModel, Field


class InverterParameters(BaseModel):
    rated_ac_power_w: float = Field(..., gt=0)
    max_dc_power_w: float | None = Field(None, description="if set > rated_ac, models intentional DC oversizing")
    no_load_loss_w: float = Field(15.0, ge=0)
    linear_loss_fraction: float = Field(0.008, ge=0)
    quadratic_loss_fraction: float = Field(0.012, ge=0)
    night_standby_w: float = Field(0.8, ge=0, description="grid power drawn while idle at night")
    min_startup_dc_power_w: float | None = Field(None, description="defaults to 2% of rated AC power")

    def model_post_init(self, __context) -> None:
        if self.max_dc_power_w is None:
            self.max_dc_power_w = self.rated_ac_power_w
        if self.min_startup_dc_power_w is None:
            self.min_startup_dc_power_w = 0.02 * self.rated_ac_power_w


@dataclass
class InverterOutput:
    ac_power_w: np.ndarray  # negative values = net grid draw while idle (standby)
    conversion_loss_w: np.ndarray
    clipping_loss_w: np.ndarray
    standby_loss_w: np.ndarray


def convert_dc_to_ac(dc_power_w: np.ndarray, params: InverterParameters) -> InverterOutput:
    """Vectorised DC->AC conversion for a whole time series."""
    dc = np.maximum(np.asarray(dc_power_w, dtype=float), 0.0)
    dc_capped = np.minimum(dc, params.max_dc_power_w)
    clipping_loss = dc - dc_capped  # DC power thrown away because it exceeds what the inverter can accept

    loading = dc_capped / params.rated_ac_power_w
    conversion_loss = (
        params.no_load_loss_w
        + params.linear_loss_fraction * dc_capped
        + params.quadratic_loss_fraction * params.rated_ac_power_w * loading**2
    )

    running = dc_capped >= params.min_startup_dc_power_w
    ac_before_cap = np.where(running, np.maximum(dc_capped - conversion_loss, 0.0), 0.0)

    over_rated = np.maximum(ac_before_cap - params.rated_ac_power_w, 0.0)
    ac_power = np.minimum(ac_before_cap, params.rated_ac_power_w)
    clipping_loss = clipping_loss + over_rated

    standby_loss = np.where(running, 0.0, params.night_standby_w)
    ac_power = np.where(running, ac_power, -params.night_standby_w)

    conversion_loss = np.where(running, conversion_loss, 0.0)

    return InverterOutput(
        ac_power_w=ac_power,
        conversion_loss_w=conversion_loss,
        clipping_loss_w=clipping_loss,
        standby_loss_w=standby_loss,
    )


def euro_weighted_efficiency(params: InverterParameters) -> float:
    """The "European efficiency" figure of merit: weighted average efficiency
    across a standard irradiance-duration distribution (EN 50530), a single
    number widely quoted on inverter datasheets for comparison.
    """
    weights = {0.05: 0.03, 0.10: 0.06, 0.20: 0.13, 0.30: 0.10, 0.50: 0.48, 1.00: 0.20}
    total = 0.0
    for loading, weight in weights.items():
        dc = loading * params.rated_ac_power_w
        out = convert_dc_to_ac(np.array([dc]), params)
        eta = float(out.ac_power_w[0] / dc) if dc > 0 else 0.0
        total += weight * eta
    return total
