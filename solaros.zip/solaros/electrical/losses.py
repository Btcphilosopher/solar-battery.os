"""Wiring and switchgear losses between the array terminals and the meter:
cable resistance, connector contact resistance, transformer iron/copper
losses, switchgear -- the "boring" I^2R losses that are nonetheless a
completely avoidable/reducible tax on delivered energy.

Model basis: PHYSICAL for ohmic cable loss (Joule heating, exact given
resistivity/geometry); EMPIRICAL fixed-fraction models for connector,
transformer and switchgear losses, which are usually quoted as a percentage
on datasheets rather than derived from first principles.
"""
from __future__ import annotations

import numpy as np

COPPER_RESISTIVITY_OHM_M = 1.68e-8


def cable_ohmic_loss_w(
    current_a: np.ndarray,
    one_way_length_m: float,
    cross_section_mm2: float,
    resistivity_ohm_m: float = COPPER_RESISTIVITY_OHM_M,
) -> np.ndarray:
    """I^2*R heating loss in a round-trip (out and back) DC or AC cable run."""
    resistance_ohm = resistivity_ohm_m * (2.0 * one_way_length_m) / (cross_section_mm2 * 1e-6)
    return np.asarray(current_a, dtype=float) ** 2 * resistance_ohm


def connector_loss_w(power_w: np.ndarray, loss_fraction: float = 0.002) -> np.ndarray:
    return np.asarray(power_w, dtype=float) * loss_fraction


def transformer_loss_w(power_w: np.ndarray, rated_power_w: float, no_load_loss_fraction: float = 0.002, load_loss_fraction: float = 0.01) -> np.ndarray:
    """Two-parameter transformer loss: constant iron/core loss plus copper
    loss scaling with the square of loading (I^2R in the windings).
    """
    power = np.asarray(power_w, dtype=float)
    no_load_loss = no_load_loss_fraction * rated_power_w
    loading = np.clip(power / rated_power_w, 0.0, None)
    load_loss = load_loss_fraction * rated_power_w * loading**2
    return no_load_loss + load_loss


def switchgear_loss_w(power_w: np.ndarray, loss_fraction: float = 0.001) -> np.ndarray:
    return np.asarray(power_w, dtype=float) * loss_fraction


def dc_wiring_loss_w(
    dc_power_w: np.ndarray,
    dc_voltage_v: np.ndarray,
    one_way_length_m: float = 15.0,
    cross_section_mm2: float = 6.0,
    connector_fraction: float = 0.002,
) -> np.ndarray:
    """Combined DC-side wiring loss: string cables + combiner-box connectors."""
    power = np.asarray(dc_power_w, dtype=float)
    voltage = np.maximum(np.asarray(dc_voltage_v, dtype=float), 1.0)
    current = power / voltage
    return cable_ohmic_loss_w(current, one_way_length_m, cross_section_mm2) + connector_loss_w(power, connector_fraction)


def ac_wiring_loss_w(
    ac_power_w: np.ndarray,
    ac_voltage_v: float = 230.0,
    one_way_length_m: float = 25.0,
    cross_section_mm2: float = 10.0,
    include_transformer: bool = False,
    transformer_rated_power_w: float | None = None,
) -> np.ndarray:
    """Combined AC-side loss: feeder cable + switchgear + (optionally) a step-up transformer."""
    power = np.maximum(np.asarray(ac_power_w, dtype=float), 0.0)
    current = power / max(ac_voltage_v, 1.0)
    loss = cable_ohmic_loss_w(current, one_way_length_m, cross_section_mm2) + switchgear_loss_w(power)
    if include_transformer:
        rated = transformer_rated_power_w or float(np.max(power)) or 1.0
        loss = loss + transformer_loss_w(power, rated)
    return loss
