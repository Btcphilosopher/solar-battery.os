"""I-V / P-V curve construction, including partial shading with bypass diodes.

Model basis: PHYSICAL. A module with `n_substrings` bypass diodes is treated
as that many series sub-strings, each an independent single-diode circuit at
its own irradiance; sub-strings are combined at a shared current (they are
in series) using the closed-form V(I) solution, with each sub-string's
voltage clamped at the bypass diode's forward-conduction voltage once it
would otherwise go negative -- exactly what a real bypass diode does.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from solaros.photovoltaic.cell import SingleDiodeParameters, current_from_voltage, voltage_from_current

BYPASS_DIODE_DROP_V = 0.5


@dataclass
class IVCurve:
    voltage_v: np.ndarray
    current_a: np.ndarray

    @property
    def power_w(self) -> np.ndarray:
        return self.voltage_v * self.current_a

    def mpp(self) -> tuple[float, float, float]:
        idx = int(np.argmax(self.power_w))
        return float(self.voltage_v[idx]), float(self.current_a[idx]), float(self.power_w[idx])

    @property
    def open_circuit_voltage_v(self) -> float:
        return float(np.max(self.voltage_v))

    @property
    def short_circuit_current_a(self) -> float:
        return float(np.interp(0.0, self.voltage_v, self.current_a))


def _substring_params(module_params: SingleDiodeParameters, n_substrings: int) -> SingleDiodeParameters:
    """Scale a whole-module single-diode model down to one of its n equal
    series sub-strings (proportional Ns, Rs, Rsh; I0/Iph unchanged as they
    are per-junction quantities in this reduced-order model)."""
    ns_sub = max(module_params.cells_in_series // n_substrings, 1)
    fraction = ns_sub / module_params.cells_in_series
    return SingleDiodeParameters(
        photocurrent_ref_a=module_params.photocurrent_ref_a,
        saturation_current_ref_a=module_params.saturation_current_ref_a,
        series_resistance_ohm=module_params.series_resistance_ohm * fraction,
        shunt_resistance_ref_ohm=module_params.shunt_resistance_ref_ohm * fraction,
        ideality_factor=module_params.ideality_factor,
        cells_in_series=ns_sub,
        bandgap_ev=module_params.bandgap_ev,
        alpha_isc_a_per_k=module_params.alpha_isc_a_per_k,
    )


def module_iv_curve_with_bypass(
    module_params: SingleDiodeParameters,
    irradiance_w_m2: float,
    cell_temperature_c: float,
    shaded_fraction: float = 0.0,
    n_substrings: int = 3,
    n_points: int = 250,
) -> IVCurve:
    """Module P-V curve under (possibly non-uniform) partial shading.

    `shaded_fraction` in [0, 1] is the fraction of the module's area that is
    shaded; it is discretised across the `n_substrings` bypass-protected
    sub-strings (e.g. shaded_fraction=0.4 with 3 substrings shades one
    substring fully and pulls the second down to 20% irradiance).
    """
    sub_params = _substring_params(module_params, n_substrings)

    substring_shade = np.clip(shaded_fraction * n_substrings - np.arange(n_substrings), 0.0, 1.0)
    substring_irradiance = irradiance_w_m2 * (1.0 - substring_shade)

    isc_full = current_from_voltage(module_params, 0.0, irradiance_w_m2, cell_temperature_c)
    current_grid = np.linspace(0.0, max(float(isc_full), 1e-6) * 1.02, n_points)

    total_voltage = np.zeros(n_points)
    for g in substring_irradiance:
        v_sub = voltage_from_current(sub_params, current_grid, float(g), cell_temperature_c).real
        total_voltage += np.maximum(v_sub, -BYPASS_DIODE_DROP_V)

    total_voltage = np.maximum(total_voltage, 0.0)
    return IVCurve(voltage_v=total_voltage, current_a=current_grid)


def unshaded_module_iv_curve(
    module_params: SingleDiodeParameters,
    irradiance_w_m2: float,
    cell_temperature_c: float,
    n_points: int = 250,
) -> IVCurve:
    isc = float(current_from_voltage(module_params, 0.0, irradiance_w_m2, cell_temperature_c))
    if isc <= 0:
        return IVCurve(voltage_v=np.zeros(n_points), current_a=np.zeros(n_points))
    current_grid = np.linspace(0.0, isc * 1.02, n_points)
    voltage = voltage_from_current(module_params, current_grid, irradiance_w_m2, cell_temperature_c).real
    voltage = np.maximum(voltage, 0.0)
    return IVCurve(voltage_v=voltage, current_a=current_grid)


def combine_series(curves: list[IVCurve], n_points: int = 250) -> IVCurve:
    """Combine series-connected elements: shared current, voltages add."""
    max_current = min(float(np.max(c.current_a)) for c in curves)
    current_grid = np.linspace(0.0, max_current, n_points)
    total_voltage = np.zeros(n_points)
    for c in curves:
        total_voltage += np.interp(current_grid, c.current_a, c.voltage_v)
    return IVCurve(voltage_v=total_voltage, current_a=current_grid)


def combine_parallel(curves: list[IVCurve], n_points: int = 250) -> IVCurve:
    """Combine parallel-connected elements: shared voltage, currents add."""
    max_voltage = max(float(np.max(c.voltage_v)) for c in curves)
    voltage_grid = np.linspace(0.0, max_voltage, n_points)
    total_current = np.zeros(n_points)
    for c in curves:
        v_sorted_idx = np.argsort(c.voltage_v)
        total_current += np.interp(
            voltage_grid, c.voltage_v[v_sorted_idx], c.current_a[v_sorted_idx], left=c.current_a[v_sorted_idx][0], right=0.0
        )
    return IVCurve(voltage_v=voltage_grid, current_a=total_current)
