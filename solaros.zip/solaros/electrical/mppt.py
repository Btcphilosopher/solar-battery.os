"""Maximum Power Point Tracking: how well a real controller keeps the array
at its true Pmp as irradiance and temperature move around underneath it.

Model basis: PHYSICAL. Each algorithm only ever "sees" what a real MPPT
controller sees -- the array's terminal voltage/current at its own chosen
operating point -- reconstructed from the single-diode model at each
timestep's true (G, T). The "ideal" tracker is the analytic MPP solve from
photovoltaic.cell.solve_mpp and defines the 100% reference for tracking
efficiency; every real algorithm necessarily tracks below it.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np

from solaros.photovoltaic.cell import SingleDiodeParameters, current_from_voltage, solve_mpp


@dataclass
class MPPTResult:
    algorithm: str
    voltage_v: np.ndarray
    power_w: np.ndarray
    true_mpp_power_w: np.ndarray

    @property
    def tracking_efficiency_fraction(self) -> float:
        ideal = float(np.sum(self.true_mpp_power_w))
        return float(np.sum(self.power_w) / ideal) if ideal > 0 else float("nan")

    @property
    def tracking_loss_w(self) -> np.ndarray:
        return self.true_mpp_power_w - self.power_w


def _power_at(sdp: SingleDiodeParameters, v: float, g: float, t: float) -> float:
    if g <= 0:
        return 0.0
    i = float(current_from_voltage(sdp, v, g, t))
    return v * max(i, 0.0)


def _true_mpp_series(sdp: SingleDiodeParameters, irradiance_w_m2: np.ndarray, cell_temperature_c: np.ndarray) -> np.ndarray:
    return np.array([solve_mpp(sdp, float(g), float(t)).p_mp_w for g, t in zip(irradiance_w_m2, cell_temperature_c)])


def perturb_and_observe(
    sdp: SingleDiodeParameters,
    irradiance_w_m2: np.ndarray,
    cell_temperature_c: np.ndarray,
    step_size_v: float = 0.5,
) -> MPPTResult:
    """Classic hill-climbing MPPT: nudge voltage, keep going if power rose, reverse if it fell."""
    n = len(irradiance_w_m2)
    voltage = np.zeros(n)
    power = np.zeros(n)

    v = sdp.cells_in_series * 0.3  # cold start deep in the current-source region, safely below any Vmp
    direction = 1.0
    prev_power = 0.0

    for idx in range(n):
        g, t = irradiance_w_m2[idx], cell_temperature_c[idx]
        p = _power_at(sdp, v, g, t)
        voltage[idx], power[idx] = v, p
        if p <= 0.0:
            # Past Voc (or no light): power is flat at zero either direction, so P&O has
            # no gradient to climb. A real controller falls back to voltage sweep/restart;
            # the deterministic recovery here is to head back down towards Isc.
            direction = -1.0
        elif p < prev_power:
            direction *= -1.0
        v = max(v + direction * step_size_v, 0.0)
        prev_power = p

    true_mpp = _true_mpp_series(sdp, irradiance_w_m2, cell_temperature_c)
    return MPPTResult("perturb_and_observe", voltage, power, true_mpp)


def incremental_conductance(
    sdp: SingleDiodeParameters,
    irradiance_w_m2: np.ndarray,
    cell_temperature_c: np.ndarray,
    step_size_v: float = 0.5,
    dv_probe_v: float = 0.05,
    tolerance: float = 1e-3,
) -> MPPTResult:
    """Compares dI/dV against -I/V (the MPP condition dP/dV=0 rearranged);
    converges faster and oscillates less than plain P&O under changing irradiance.
    """
    n = len(irradiance_w_m2)
    voltage = np.zeros(n)
    power = np.zeros(n)

    v = sdp.cells_in_series * 0.3

    for idx in range(n):
        g, t = irradiance_w_m2[idx], cell_temperature_c[idx]
        if g <= 0:
            voltage[idx], power[idx] = 0.0, 0.0
            continue

        i = float(current_from_voltage(sdp, v, g, t))
        if i <= 1e-9:
            # Past Voc: no current to sense a gradient from, walk back down.
            v = max(v - step_size_v, 0.0)
            voltage[idx] = v
            power[idx] = _power_at(sdp, v, g, t)
            continue

        i_plus = float(current_from_voltage(sdp, v + dv_probe_v, g, t))
        d_i_d_v = (i_plus - i) / dv_probe_v

        target = -i / v if v > 1e-6 else np.inf
        if d_i_d_v > target + tolerance:
            v += step_size_v
        elif d_i_d_v < target - tolerance:
            v -= step_size_v
        v = max(v, 0.0)

        voltage[idx] = v
        power[idx] = _power_at(sdp, v, g, t)

    true_mpp = _true_mpp_series(sdp, irradiance_w_m2, cell_temperature_c)
    return MPPTResult("incremental_conductance", voltage, power, true_mpp)


def constant_voltage(
    sdp: SingleDiodeParameters,
    irradiance_w_m2: np.ndarray,
    cell_temperature_c: np.ndarray,
    voltage_ratio: float = 0.76,
    voc_resample_interval_steps: int = 24,
) -> MPPTResult:
    """Holds voltage at a fixed fraction of the array's own Voc, periodically
    re-measuring Voc (a brief open-circuit pulse, the real-world cost of this
    algorithm) rather than continuously hill-climbing.
    """
    from scipy.optimize import brentq

    n = len(irradiance_w_m2)
    voltage = np.zeros(n)
    power = np.zeros(n)
    v_target = 0.0
    # Force a resample on the first daylight step, regardless of how it lines up
    # against the fixed interval -- otherwise a resample interval that divides evenly
    # into the day length can perpetually land on a nighttime (g<=0) step and never fire.
    steps_since_resample = voc_resample_interval_steps

    for idx in range(n):
        g, t = irradiance_w_m2[idx], cell_temperature_c[idx]
        if g <= 0:
            voltage[idx], power[idx] = 0.0, 0.0
            steps_since_resample += 1
            continue
        if steps_since_resample >= voc_resample_interval_steps:
            f = lambda vv: float(current_from_voltage(sdp, vv, g, t))
            v_upper = sdp.cells_in_series * 1.0
            try:
                voc = brentq(f, 1e-6, v_upper, xtol=1e-6)
            except ValueError:
                voc = v_upper
            steps_since_resample = 0
        else:
            steps_since_resample += 1
            v_target = voltage_ratio * voc

        voltage[idx] = v_target
        power[idx] = _power_at(sdp, v_target, g, t)

    true_mpp = _true_mpp_series(sdp, irradiance_w_m2, cell_temperature_c)
    return MPPTResult("constant_voltage", voltage, power, true_mpp)


def ideal_mppt(
    sdp: SingleDiodeParameters,
    irradiance_w_m2: np.ndarray,
    cell_temperature_c: np.ndarray,
) -> MPPTResult:
    """Deterministic analytic MPPT: solves for the exact Vmp at every step.
    Not physically realisable (real controllers can't see the model), but
    it's the well-defined upper bound every real algorithm is scored against.
    """
    n = len(irradiance_w_m2)
    voltage = np.zeros(n)
    power = np.zeros(n)
    for idx in range(n):
        mpp = solve_mpp(sdp, float(irradiance_w_m2[idx]), float(cell_temperature_c[idx]))
        voltage[idx], power[idx] = mpp.v_mp_v, mpp.p_mp_w
    return MPPTResult("ideal_analytic", voltage, power, power.copy())


ALGORITHMS: dict[str, Callable[..., MPPTResult]] = {
    "perturb_and_observe": perturb_and_observe,
    "incremental_conductance": incremental_conductance,
    "constant_voltage": constant_voltage,
    "ideal_analytic": ideal_mppt,
}


def compare_algorithms(
    sdp: SingleDiodeParameters,
    irradiance_w_m2: np.ndarray,
    cell_temperature_c: np.ndarray,
    algorithms: list[str] | None = None,
) -> dict[str, MPPTResult]:
    names = algorithms or list(ALGORITHMS)
    return {name: ALGORITHMS[name](sdp, irradiance_w_m2, cell_temperature_c) for name in names}
