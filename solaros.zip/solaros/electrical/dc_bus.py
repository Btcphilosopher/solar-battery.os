"""The DC bus: the node where the array, DC wiring losses, and (optionally)
a battery all meet before the inverter. Kept deliberately thin -- the PV
engine must stay independently usable with no battery attached (spec #29).
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from solaros.electrical.losses import dc_wiring_loss_w


@dataclass
class DCBusResult:
    array_power_w: np.ndarray
    wiring_loss_w: np.ndarray
    net_dc_power_w: np.ndarray  # what reaches the inverter (before any battery interaction)


def combine_dc_bus(
    array_power_w: np.ndarray,
    array_voltage_v: np.ndarray,
    one_way_cable_length_m: float = 15.0,
    cable_cross_section_mm2: float = 6.0,
) -> DCBusResult:
    wiring_loss = dc_wiring_loss_w(array_power_w, array_voltage_v, one_way_cable_length_m, cable_cross_section_mm2)
    net = np.maximum(np.asarray(array_power_w, dtype=float) - wiring_loss, 0.0)
    return DCBusResult(array_power_w=np.asarray(array_power_w, dtype=float), wiring_loss_w=wiring_loss, net_dc_power_w=net)
