"""Physical layout optimisation: tilt vs row spacing (ground coverage ratio)
trade off row-to-row self-shading against land use. Packing rows tighter
(higher GCR) fits more modules per hectare but shades them more; the
optimum depends on whether land or module count is the binding constraint.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from solaros.core.configuration import Assumption, ModelBasis, OptimisationResult
from solaros.core.simulation import SystemConfig, run_simulation
from solaros.weather.weather import WeatherSeries


def _land_area_m2(system: SystemConfig) -> float:
    module_area_m2 = system.panel.area_m2 * system.layout.total_modules
    return module_area_m2 / max(system.ground_coverage_ratio, 1e-6)


def evaluate_layout_grid(
    system: SystemConfig,
    weather: WeatherSeries,
    tilt_grid_deg: np.ndarray | None = None,
    gcr_grid: np.ndarray | None = None,
) -> pd.DataFrame:
    """Annual energy, land use and yield-per-hectare for every (tilt, GCR) combination."""
    tilt_grid_deg = tilt_grid_deg if tilt_grid_deg is not None else np.linspace(10, 45, 6)
    gcr_grid = gcr_grid if gcr_grid is not None else np.linspace(0.25, 0.75, 6)

    rows = []
    for tilt in tilt_grid_deg:
        for gcr in gcr_grid:
            trial = system.model_copy(update={"tilt_deg": float(tilt), "ground_coverage_ratio": float(gcr)})
            state = run_simulation(trial, weather)
            land_area_m2 = _land_area_m2(trial)
            rows.append(
                {
                    "tilt_deg": float(tilt),
                    "ground_coverage_ratio": float(gcr),
                    "annual_ac_kwh": state.annual_ac_kwh,
                    "shading_loss_kwh": state.losses.shading_loss_kwh,
                    "land_area_m2": land_area_m2,
                    "annual_kwh_per_m2_land": state.annual_ac_kwh / land_area_m2,
                }
            )
    return pd.DataFrame(rows)


def optimise_layout(
    system: SystemConfig,
    weather: WeatherSeries,
    tilt_grid_deg: np.ndarray | None = None,
    gcr_grid: np.ndarray | None = None,
    maximise: str = "annual_kwh_per_m2_land",
) -> OptimisationResult:
    """Find the (tilt, GCR) combination maximising land-use efficiency
    (default) or raw annual energy for a fixed module count -- pass
    maximise="annual_ac_kwh" when the module count, not the land, is fixed
    and available_area_m2 simply must not be exceeded.
    """
    df = evaluate_layout_grid(system, weather, tilt_grid_deg, gcr_grid)

    if system.site.available_area_m2 is not None:
        feasible = df[df["land_area_m2"] <= system.site.available_area_m2]
        df = feasible if len(feasible) else df  # fall back to full grid with a note if nothing fits

    best_row = df.loc[df[maximise].idxmax()]
    baseline_row = df.iloc[(df["tilt_deg"] - system.tilt_deg).abs().argsort()[:1]]
    baseline_value = float(baseline_row[maximise].iloc[0])

    notes = []
    if system.site.available_area_m2 is not None and best_row["land_area_m2"] > system.site.available_area_m2:
        notes.append(
            Assumption(
                name="area_constraint_infeasible",
                value=f"best layout needs {best_row['land_area_m2']:.0f} m^2 > available {system.site.available_area_m2:.0f} m^2",
                basis=ModelBasis.SIMPLIFIED,
                note="No (tilt, GCR) combination in the search grid fit the available area; showing the unconstrained best instead.",
            )
        )

    return OptimisationResult.from_values(
        objective_name=maximise,
        baseline_value=baseline_value,
        optimised_value=float(best_row[maximise]),
        unit="kWh/m2/year" if "per_m2" in maximise else "kWh",
        best_parameters={"tilt_deg": float(best_row["tilt_deg"]), "ground_coverage_ratio": float(best_row["ground_coverage_ratio"])},
        assumptions=[
            Assumption(
                name="row_to_row_shading_model",
                value="1-D profile-angle projection (solar.shading.row_to_row_shaded_fraction)",
                basis=ModelBasis.SIMPLIFIED,
            )
        ]
        + notes,
    )
