"""Azimuth optimisation: which compass direction should the array face."""
from __future__ import annotations

from typing import Optional

import numpy as np
from scipy.optimize import minimize_scalar

from solaros.core.configuration import Assumption, ModelBasis, OptimisationResult
from solaros.core.simulation import SystemConfig, run_simulation
from solaros.optimisation.tilt import ObjectiveFn, annual_energy_objective
from solaros.weather.weather import WeatherSeries


def _evaluate(system: SystemConfig, weather: WeatherSeries, azimuth_deg: float, objective_fn: ObjectiveFn) -> float:
    trial = system.model_copy(update={"azimuth_deg": float(azimuth_deg) % 360.0})
    state = run_simulation(trial, weather)
    return objective_fn(state)


def optimise_azimuth(
    system: SystemConfig,
    weather: WeatherSeries,
    objective_fn: Optional[ObjectiveFn] = None,
    azimuth_bounds_deg: tuple[float, float] = (90.0, 270.0),
    n_grid: int = 9,
) -> OptimisationResult:
    objective_fn = objective_fn or annual_energy_objective

    grid = np.linspace(azimuth_bounds_deg[0], azimuth_bounds_deg[1], n_grid)
    grid_values = [_evaluate(system, weather, a, objective_fn) for a in grid]
    best_idx = int(np.argmax(grid_values))

    lo = grid[max(best_idx - 1, 0)]
    hi = grid[min(best_idx + 1, n_grid - 1)]
    result = minimize_scalar(
        lambda a: -_evaluate(system, weather, a, objective_fn),
        bounds=(lo, hi),
        method="bounded",
        options={"xatol": 0.5},
    )
    best_azimuth = float(result.x)
    best_value = -float(result.fun)

    baseline_value = _evaluate(system, weather, system.azimuth_deg, objective_fn)

    return OptimisationResult.from_values(
        objective_name=getattr(objective_fn, "__name__", "custom_objective"),
        baseline_value=baseline_value,
        optimised_value=best_value,
        unit="kWh",
        best_parameters={"azimuth_deg": best_azimuth},
        assumptions=[
            Assumption(
                name="azimuth_search",
                value=f"grid[{azimuth_bounds_deg[0]},{azimuth_bounds_deg[1]}] n={n_grid} + bounded refine",
                basis=ModelBasis.SIMPLIFIED,
            )
        ],
    )
