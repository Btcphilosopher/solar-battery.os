"""Thermal-management scenarios: does spending energy to cool the array
actually produce more *net* energy, or does the cooling system eat the gain?

Objective is explicitly MAXIMISE NET ENERGY (spec #11, #31), never
"minimise panel temperature" -- a colder panel that costs more pump/fan
energy than it recovers is a worse system, not a better one.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from solaros.core.simulation import SystemConfig, run_simulation
from solaros.photovoltaic.array import uniform_array_power_w
from solaros.photovoltaic.temperature import cell_temperature_from_module_c, faiman_module_temperature_c
from solaros.weather.weather import WeatherSeries


@dataclass
class CoolingScenario:
    name: str
    heat_loss_u0_w_m2k: float
    heat_loss_u1_w_m2k_per_ms: float
    parasitic_w_per_kwp: float = 0.0  # only drawn while the array is producing (daytime)


COOLING_SCENARIOS: dict[str, CoolingScenario] = {
    "natural_convection": CoolingScenario("natural_convection", 25.0, 6.84, 0.0),
    "ventilated_rear_air_gap": CoolingScenario("ventilated_rear_air_gap", 28.0, 7.5, 0.0),
    "forced_air": CoolingScenario("forced_air", 38.0, 9.0, 4.0),
    "water_cooling": CoolingScenario("water_cooling", 65.0, 6.84, 10.0),
}


def evaluate_cooling_scenarios(
    system: SystemConfig,
    weather: WeatherSeries,
    scenarios: dict[str, CoolingScenario] | None = None,
    energy_value_eur_per_kwh: float = 0.30,
) -> pd.DataFrame:
    scenarios = scenarios or COOLING_SCENARIOS
    rated_kwp = system.panel.rated_power_w * system.layout.total_modules / 1000.0

    baseline_state = run_simulation(system, weather)
    shaded_irradiance = baseline_state.extra["shaded_irradiance_w_m2"]
    n = len(baseline_state.timestamps)
    step_hours = baseline_state.step_hours

    rows = []
    baseline_net_kwh = None
    for scenario in scenarios.values():
        module_temp = faiman_module_temperature_c(
            weather.ambient_temperature_c,
            shaded_irradiance,
            weather.wind_speed_m_s,
            u0_override=scenario.heat_loss_u0_w_m2k,
            u1_override=scenario.heat_loss_u1_w_m2k_per_ms,
        )
        cell_temp = cell_temperature_from_module_c(module_temp, shaded_irradiance)
        dc_power_w = uniform_array_power_w(system.panel, system.layout, shaded_irradiance, cell_temp)
        gross_dc_kwh = float(np.sum(dc_power_w) * step_hours / 1000.0)

        producing_hours = float(np.sum(shaded_irradiance > 0) * step_hours)
        parasitic_kwh = scenario.parasitic_w_per_kwp * rated_kwp * producing_hours / 1000.0
        net_kwh = gross_dc_kwh - parasitic_kwh

        if baseline_net_kwh is None:
            baseline_net_kwh = net_kwh

        rows.append(
            {
                "scenario": scenario.name,
                "mean_cell_temperature_c": float(np.mean(cell_temp[shaded_irradiance > 0])) if np.any(shaded_irradiance > 0) else float("nan"),
                "gross_dc_kwh": gross_dc_kwh,
                "parasitic_kwh": parasitic_kwh,
                "net_dc_kwh": net_kwh,
                "net_gain_vs_natural_convection_kwh": net_kwh - baseline_net_kwh,
                "net_value_gain_eur": (net_kwh - baseline_net_kwh) * energy_value_eur_per_kwh,
            }
        )

    return pd.DataFrame(rows).set_index("scenario")
