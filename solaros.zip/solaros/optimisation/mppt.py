"""MPPT algorithm selection: run each tracker against the system's own
simulated irradiance/temperature trace and see how much of the true MPP
energy each one actually captures.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from solaros.core.configuration import Assumption, ModelBasis, OptimisationResult
from solaros.core.simulation import SystemConfig, run_simulation
from solaros.electrical.mppt import compare_algorithms
from solaros.weather.weather import WeatherSeries


def compare_mppt_for_system(
    system: SystemConfig,
    weather: WeatherSeries,
    day_of_year: int | None = None,
    algorithms: list[str] | None = None,
) -> pd.DataFrame:
    """Slice one representative day out of a full-year simulation (the
    cloudiest available day by default -- the regime where MPPT algorithms
    actually differentiate themselves) and compare tracker behaviour on it.
    """
    state = run_simulation(system, weather)
    shaded_irradiance = state.extra["shaded_irradiance_w_m2"]
    cell_temp = state.cell_temperature_c

    doy = state.timestamps.dayofyear.to_numpy()
    if day_of_year is None:
        daily_std = pd.Series(shaded_irradiance, index=state.timestamps).groupby(doy).std()
        day_of_year = int(daily_std.idxmax())

    mask = doy == day_of_year
    g = shaded_irradiance[mask]
    t = cell_temp[mask]

    sdp = system.panel.single_diode_parameters
    results = compare_algorithms(sdp, g, t, algorithms)

    rows = [
        {
            "algorithm": name,
            "tracking_efficiency_fraction": r.tracking_efficiency_fraction,
            "energy_captured_wh": float(np.sum(r.power_w)) * (state.step_hours),
            "ideal_energy_wh": float(np.sum(r.true_mpp_power_w)) * (state.step_hours),
        }
        for name, r in results.items()
    ]
    return pd.DataFrame(rows).set_index("algorithm")


def recommend_mppt_algorithm(
    system: SystemConfig,
    weather: WeatherSeries,
    day_of_year: int | None = None,
) -> OptimisationResult:
    df = compare_mppt_for_system(system, weather, day_of_year)
    real_algorithms = df.drop(index="ideal_analytic", errors="ignore")
    best = real_algorithms["tracking_efficiency_fraction"].idxmax()
    worst = real_algorithms["tracking_efficiency_fraction"].idxmin()

    return OptimisationResult.from_values(
        objective_name="mppt_tracking_efficiency",
        baseline_value=float(df.loc[worst, "tracking_efficiency_fraction"]),
        optimised_value=float(df.loc[best, "tracking_efficiency_fraction"]),
        unit="fraction_of_ideal_mpp_energy",
        best_parameters={"mppt_algorithm": best},
        assumptions=[
            Assumption(
                name="representative_day",
                value="highest-variance simulated day (cloudiest -> MPPT algorithms differentiate most)",
                basis=ModelBasis.SIMPLIFIED,
                note="Annual energy impact should scale this single-day efficiency gap by the fraction of "
                "the year spent in similarly variable conditions, not applied uniformly to every hour.",
            )
        ],
    )
