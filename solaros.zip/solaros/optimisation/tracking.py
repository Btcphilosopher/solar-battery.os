"""Fixed vs single-axis vs dual-axis tracking: extra energy against extra
capex, opex and parasitic tracker consumption -- is tracking worth it here?

Model basis: SIMPLIFIED/EMPIRICAL cost assumptions (typical market ranges,
2024 -- override with a real BOQ for a bankable answer).
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from solaros.core.simulation import SystemConfig, run_simulation
from solaros.weather.weather import WeatherSeries


@dataclass
class TrackingCostAssumptions:
    single_axis_extra_capex_eur_per_kwp: float = 150.0
    dual_axis_extra_capex_eur_per_kwp: float = 380.0
    single_axis_extra_om_eur_per_kwp_year: float = 3.0
    dual_axis_extra_om_eur_per_kwp_year: float = 9.0
    single_axis_parasitic_w_per_kwp: float = 0.3  # tracker motor, averaged over daylight hours
    dual_axis_parasitic_w_per_kwp: float = 0.8


def compare_tracking_options(
    system: SystemConfig,
    weather: WeatherSeries,
    cost_assumptions: TrackingCostAssumptions = TrackingCostAssumptions(),
    energy_value_eur_per_kwh: float = 0.30,
) -> pd.DataFrame:
    rated_kwp = system.panel.rated_power_w * system.layout.total_modules / 1000.0
    daylight_hours_per_year = 4400.0  # rough mid-latitude annual daylight-hours estimate for parasitic-load accounting

    modes = {
        "fixed": (0.0, 0.0, 0.0),
        "single_axis": (
            cost_assumptions.single_axis_extra_capex_eur_per_kwp,
            cost_assumptions.single_axis_extra_om_eur_per_kwp_year,
            cost_assumptions.single_axis_parasitic_w_per_kwp,
        ),
        "dual_axis": (
            cost_assumptions.dual_axis_extra_capex_eur_per_kwp,
            cost_assumptions.dual_axis_extra_om_eur_per_kwp_year,
            cost_assumptions.dual_axis_parasitic_w_per_kwp,
        ),
    }

    rows = []
    fixed_kwh = None
    for mode, (extra_capex_per_kwp, extra_om_per_kwp, parasitic_w_per_kwp) in modes.items():
        trial = system.model_copy(update={"tracking_mode": mode})
        state = run_simulation(trial, weather)
        parasitic_kwh = parasitic_w_per_kwp * rated_kwp * daylight_hours_per_year / 1000.0
        net_kwh = state.annual_ac_kwh - parasitic_kwh

        if fixed_kwh is None:
            fixed_kwh = net_kwh

        extra_kwh_vs_fixed = net_kwh - fixed_kwh
        extra_capex_eur = extra_capex_per_kwp * rated_kwp
        extra_om_eur_year = extra_om_per_kwp * rated_kwp
        extra_annual_value_eur = extra_kwh_vs_fixed * energy_value_eur_per_kwh - extra_om_eur_year
        payback_years = extra_capex_eur / extra_annual_value_eur if extra_annual_value_eur > 0 else float("inf")

        rows.append(
            {
                "tracking_mode": mode,
                "annual_ac_kwh": state.annual_ac_kwh,
                "parasitic_kwh": parasitic_kwh,
                "net_kwh": net_kwh,
                "extra_kwh_vs_fixed": extra_kwh_vs_fixed,
                "extra_capex_eur": extra_capex_eur,
                "extra_om_eur_per_year": extra_om_eur_year,
                "extra_annual_value_eur": extra_annual_value_eur,
                "simple_payback_years": payback_years,
            }
        )

    return pd.DataFrame(rows).set_index("tracking_mode")
