"""Fixed-tilt optimisation: find the tilt angle that maximises whichever
objective the engineer cares about -- annual energy is not always the goal;
winter security of supply or economic value often matter more.
"""
from __future__ import annotations

from typing import Callable, Optional

import numpy as np
from scipy.optimize import minimize_scalar

from solaros.core.configuration import Assumption, ModelBasis, OptimisationResult
from solaros.core.simulation import SystemConfig, run_simulation
from solaros.core.state import SimulationState
from solaros.weather.weather import WeatherSeries

ObjectiveFn = Callable[[SimulationState], float]


def annual_energy_objective(state: SimulationState) -> float:
    return state.annual_ac_kwh


def _season_mask(state: SimulationState, months: set[int]) -> np.ndarray:
    return np.isin(state.timestamps.month, list(months))


def winter_energy_objective(latitude_deg: float) -> ObjectiveFn:
    months = {12, 1, 2} if latitude_deg >= 0 else {6, 7, 8}

    def objective(state: SimulationState) -> float:
        mask = _season_mask(state, months)
        return float(np.sum(state.ac_power_w[mask]) * state.step_hours / 1000.0)

    return objective


def summer_energy_objective(latitude_deg: float) -> ObjectiveFn:
    months = {6, 7, 8} if latitude_deg >= 0 else {12, 1, 2}

    def objective(state: SimulationState) -> float:
        mask = _season_mask(state, months)
        return float(np.sum(state.ac_power_w[mask]) * state.step_hours / 1000.0)

    return objective


def economic_value_objective(energy_value_eur_per_kwh: float = 0.30) -> ObjectiveFn:
    def objective(state: SimulationState) -> float:
        return state.annual_ac_kwh * energy_value_eur_per_kwh

    return objective


def _evaluate(system: SystemConfig, weather: WeatherSeries, tilt_deg: float, objective_fn: ObjectiveFn) -> float:
    trial = system.model_copy(update={"tilt_deg": float(tilt_deg)})
    state = run_simulation(trial, weather)
    return objective_fn(state)


def optimise_tilt(
    system: SystemConfig,
    weather: WeatherSeries,
    objective_fn: Optional[ObjectiveFn] = None,
    tilt_bounds: tuple[float, float] = (0.0, 60.0),
    n_grid: int = 9,
) -> OptimisationResult:
    """Coarse grid scan (cheap, avoids missing a distant optimum) followed by
    a bounded local refine around the best grid point.
    """
    objective_fn = objective_fn or annual_energy_objective

    grid = np.linspace(tilt_bounds[0], tilt_bounds[1], n_grid)
    grid_values = [_evaluate(system, weather, t, objective_fn) for t in grid]
    best_idx = int(np.argmax(grid_values))

    lo = grid[max(best_idx - 1, 0)]
    hi = grid[min(best_idx + 1, n_grid - 1)]
    result = minimize_scalar(
        lambda t: -_evaluate(system, weather, t, objective_fn),
        bounds=(lo, hi),
        method="bounded",
        options={"xatol": 0.25},
    )
    best_tilt = float(result.x)
    best_value = -float(result.fun)

    baseline_value = _evaluate(system, weather, system.tilt_deg, objective_fn)

    return OptimisationResult.from_values(
        objective_name=objective_fn.__name__ if hasattr(objective_fn, "__name__") else "custom_objective",
        baseline_value=baseline_value,
        optimised_value=best_value,
        unit="kWh" if "value" not in str(objective_fn) else "EUR",
        best_parameters={"tilt_deg": best_tilt},
        assumptions=[
            Assumption(
                name="tilt_search",
                value=f"grid[{tilt_bounds[0]},{tilt_bounds[1]}] n={n_grid} + bounded refine",
                basis=ModelBasis.SIMPLIFIED,
                note="Assumes a unimodal annual-energy-vs-tilt curve, true for fixed-tilt at a single site.",
            )
        ],
    )
