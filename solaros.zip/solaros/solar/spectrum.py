"""Spectral mismatch: real sunlight's spectrum shifts with air mass and water
vapour, and different PV technologies respond differently to that shift.

Model basis: EMPIRICAL. Reduced-order polynomial in air mass, in the spirit
of the First Solar spectral correction factor. Coefficients are indicative
defaults per technology family, not a substitute for site spectroradiometer
calibration.
"""
from __future__ import annotations

import numpy as np

# Polynomial in (air_mass - 1.5), the reference AM at which STC spectrum is defined.
# Coefficients: [a0, a1, a2] -> factor = a0 + a1*x + a2*x^2, clipped to a sane band.
_SPECTRAL_COEFFICIENTS = {
    "mono-si": (1.000, -0.0020, -0.00015),
    "poly-si": (1.000, -0.0022, -0.00016),
    "thin-film-cdte": (1.000, -0.0090, -0.00060),
    "thin-film-cigs": (1.000, -0.0070, -0.00045),
}


def spectral_mismatch_factor(air_mass: np.ndarray, technology: str = "mono-si") -> np.ndarray:
    """Multiplicative correction to apply to broadband POA irradiance before the
    single-diode model, approximating the fraction of that irradiance the
    cell can actually use given its spectral response.
    """
    a0, a1, a2 = _SPECTRAL_COEFFICIENTS.get(technology, _SPECTRAL_COEFFICIENTS["mono-si"])
    am = np.where(np.isfinite(air_mass), air_mass, 10.0)
    x = am - 1.5
    factor = a0 + a1 * x + a2 * x**2
    return np.clip(factor, 0.85, 1.02)
