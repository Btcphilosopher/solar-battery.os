"""Solar geometry: where the sun is in the sky for a given place and time.

Model basis: SIMPLIFIED. Uses the Spencer (1971) Fourier-series approximation
for declination and the equation of time, which is accurate to a few
hundredths of a degree -- entirely sufficient for energy-yield engineering.
For arcsecond-grade astronomical accuracy, swap in the NREL SPA algorithm
behind the same function signature.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

DEG2RAD = np.pi / 180.0
RAD2DEG = 180.0 / np.pi


@dataclass
class SunPosition:
    elevation_deg: np.ndarray
    azimuth_deg: np.ndarray
    zenith_deg: np.ndarray
    declination_deg: np.ndarray
    hour_angle_deg: np.ndarray
    equation_of_time_min: np.ndarray

    @property
    def above_horizon(self) -> np.ndarray:
        return self.elevation_deg > 0.0


def _day_angle_rad(day_of_year: np.ndarray) -> np.ndarray:
    return 2 * np.pi * (day_of_year - 1) / 365.0


def declination_deg(day_of_year: np.ndarray) -> np.ndarray:
    """Solar declination (Spencer 1971), in degrees."""
    b = _day_angle_rad(day_of_year)
    delta = (
        0.006918
        - 0.399912 * np.cos(b)
        + 0.070257 * np.sin(b)
        - 0.006758 * np.cos(2 * b)
        + 0.000907 * np.sin(2 * b)
        - 0.002697 * np.cos(3 * b)
        + 0.00148 * np.sin(3 * b)
    )
    return delta * RAD2DEG


def equation_of_time_min(day_of_year: np.ndarray) -> np.ndarray:
    """Equation of time (Spencer 1971), in minutes (apparent minus mean solar time)."""
    b = _day_angle_rad(day_of_year)
    return 229.18 * (
        0.000075
        + 0.001868 * np.cos(b)
        - 0.032077 * np.sin(b)
        - 0.014615 * np.cos(2 * b)
        - 0.040849 * np.sin(2 * b)
    )


def solar_position(
    timestamps: pd.DatetimeIndex,
    latitude_deg: float,
    longitude_deg: float,
) -> SunPosition:
    """Solar elevation/azimuth/zenith for every timestamp at a fixed lat/lon.

    `timestamps` may be timezone-aware (any zone) or naive-UTC; solar
    geometry only cares about true UTC instant and longitude, so we
    normalise to UTC internally and sidestep DST/local-clock ambiguity.
    """
    if timestamps.tz is not None:
        ts_utc = timestamps.tz_convert("UTC")
    else:
        ts_utc = timestamps

    doy = ts_utc.dayofyear.to_numpy().astype(float)
    utc_hour = (ts_utc.hour + ts_utc.minute / 60.0 + ts_utc.second / 3600.0).to_numpy()

    delta = declination_deg(doy)
    eot = equation_of_time_min(doy)

    true_solar_time = utc_hour + longitude_deg / 15.0 + eot / 60.0
    hour_angle = 15.0 * (true_solar_time - 12.0)
    hour_angle = (hour_angle + 180.0) % 360.0 - 180.0  # wrap to [-180, 180]

    phi = latitude_deg * DEG2RAD
    dec = delta * DEG2RAD
    ha = hour_angle * DEG2RAD

    cos_zenith = np.sin(phi) * np.sin(dec) + np.cos(phi) * np.cos(dec) * np.cos(ha)
    cos_zenith = np.clip(cos_zenith, -1.0, 1.0)
    zenith = np.arccos(cos_zenith)
    elevation = np.pi / 2 - zenith

    sin_zenith = np.sin(zenith)
    with np.errstate(divide="ignore", invalid="ignore"):
        cos_az = (np.sin(dec) - np.sin(phi) * cos_zenith) / (np.cos(phi) * sin_zenith)
    cos_az = np.clip(np.nan_to_num(cos_az, nan=1.0), -1.0, 1.0)
    azimuth = np.arccos(cos_az)
    azimuth = np.where(ha > 0, 2 * np.pi - azimuth, azimuth)  # afternoon -> west of north

    return SunPosition(
        elevation_deg=elevation * RAD2DEG,
        azimuth_deg=azimuth * RAD2DEG,
        zenith_deg=zenith * RAD2DEG,
        declination_deg=delta,
        hour_angle_deg=hour_angle,
        equation_of_time_min=eot,
    )


def sunrise_sunset_hours(day_of_year: np.ndarray, latitude_deg: float, longitude_deg: float) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Sunrise, sunset (UTC decimal hours) and day length (hours) for each day of year."""
    delta = declination_deg(day_of_year) * DEG2RAD
    phi = latitude_deg * DEG2RAD
    eot = equation_of_time_min(day_of_year)

    cos_ha0 = -np.tan(phi) * np.tan(delta)
    cos_ha0 = np.clip(cos_ha0, -1.0, 1.0)  # clip => polar day/night handled below
    ha0_deg = np.arccos(cos_ha0) * RAD2DEG

    day_length_h = 2 * ha0_deg / 15.0
    solar_noon_utc = 12.0 - longitude_deg / 15.0 - eot / 60.0
    sunrise_utc = solar_noon_utc - day_length_h / 2.0
    sunset_utc = solar_noon_utc + day_length_h / 2.0

    raw_cos = -np.tan(phi) * np.tan(delta)
    day_length_h = np.where(raw_cos < -1.0, 24.0, day_length_h)  # polar day
    day_length_h = np.where(raw_cos > 1.0, 0.0, day_length_h)  # polar night

    return sunrise_utc, sunset_utc, day_length_h
