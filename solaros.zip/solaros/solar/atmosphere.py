"""Atmospheric path length and extraterrestrial irradiance.

Model basis: SIMPLIFIED / EMPIRICAL (Kasten & Young 1989 air-mass fit;
solar-constant + eccentricity correction from Spencer 1971).
"""
from __future__ import annotations

import numpy as np

SOLAR_CONSTANT_W_M2 = 1361.0


def relative_air_mass(zenith_deg: np.ndarray) -> np.ndarray:
    """Kasten & Young (1989) air mass, valid to the horizon (zenith -> 90 deg gives AM ~38)."""
    zenith = np.clip(zenith_deg, 0.0, 89.99)
    denom = np.cos(np.radians(zenith)) + 0.50572 * (96.07995 - zenith) ** -1.6364
    am = 1.0 / denom
    return np.where(zenith_deg >= 90.0, np.inf, am)


def pressure_corrected_air_mass(air_mass: np.ndarray, pressure_kpa: float) -> np.ndarray:
    """Scale sea-level air mass for site elevation via barometric pressure ratio."""
    return air_mass * (pressure_kpa / 101.325)


def extraterrestrial_irradiance_w_m2(day_of_year: np.ndarray) -> np.ndarray:
    """Irradiance on a plane normal to the sun's rays just outside the atmosphere.

    Includes the +-3.3% seasonal wobble from earth's orbital eccentricity.
    """
    b = 2 * np.pi * (day_of_year - 1) / 365.0
    eccentricity_factor = (
        1.00011
        + 0.034221 * np.cos(b)
        + 0.00128 * np.sin(b)
        + 0.000719 * np.cos(2 * b)
        + 0.000077 * np.sin(2 * b)
    )
    return SOLAR_CONSTANT_W_M2 * eccentricity_factor


def clear_sky_beam_transmittance(air_mass: np.ndarray, linke_turbidity: float = 3.0) -> np.ndarray:
    """Broadband clear-sky beam transmittance as a function of air mass and turbidity.

    EMPIRICAL: the AM^0.678 attenuation exponent is the classic Meinel &
    Meinel (1976) textbook clear-sky fit; the turbidity term is a single
    configurable knob for aerosol/water-vapour loading in place of a full
    Linke-turbidity climatology. `linke_turbidity` of ~2 is very clean air,
    ~3 typical rural, ~5-7 hazy/urban.
    """
    am = np.where(np.isfinite(air_mass), air_mass, 40.0)
    base = 0.7 ** (am**0.678)
    turbidity_factor = np.exp(-0.13 * (linke_turbidity - 1.0) * am / (am + 1.0))
    return np.clip(base * turbidity_factor, 0.0, 1.0)
