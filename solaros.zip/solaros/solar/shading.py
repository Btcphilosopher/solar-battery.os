"""Spatial shading: discrete obstructions (trees, buildings, chimneys, other
rows/panels), row-to-row self-shading in an array, and a sky-dome shading map.

Model basis: SIMPLIFIED geometric shading. Treats obstructions as opaque
angular sectors on the sky dome (no penumbra ray-tracing) and row-to-row
self-shading via the standard 1-D profile-angle projection. Cloud-shadow
transients are handled separately in weather.clouds (a temporal, not
spatial, attenuation).
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class Obstruction:
    """A fixed object that can block direct sunlight, as seen from the array.

    `azimuth_deg` is the compass bearing to the object's centre (0=N, 90=E).
    `angular_width_deg` is how wide it appears from the array.
    `elevation_deg` is how high its top edge appears above the horizon.
    """

    name: str
    azimuth_deg: float
    angular_width_deg: float
    elevation_deg: float


def obstruction_shading_fraction(
    sun_azimuth_deg: np.ndarray,
    sun_elevation_deg: np.ndarray,
    obstructions: list[Obstruction],
    soft_edge_deg: float = 1.0,
) -> np.ndarray:
    """Fraction (0-1) of the sun disk blocked by discrete obstructions at each timestep.

    Obstructions are opaque: if the sun's azimuth falls within an obstruction's
    angular width and the sun is lower than the obstruction's top edge, direct
    beam is blocked. A `soft_edge_deg` linear ramp softens the azimuth cutoff
    to approximate the sun's finite angular size / partial shading at the edge.
    """
    blocked = np.zeros_like(sun_azimuth_deg, dtype=float)
    for obs in obstructions:
        half_width = obs.angular_width_deg / 2.0
        az_delta = np.abs(((sun_azimuth_deg - obs.azimuth_deg + 180) % 360) - 180)
        in_azimuth = np.clip((half_width + soft_edge_deg - az_delta) / soft_edge_deg, 0.0, 1.0)
        below_top = sun_elevation_deg < obs.elevation_deg
        blocked = np.maximum(blocked, np.where(below_top, in_azimuth, 0.0))
    return np.clip(blocked, 0.0, 1.0)


def row_to_row_shaded_fraction(
    sun_elevation_deg: np.ndarray,
    sun_azimuth_deg: np.ndarray,
    row_azimuth_deg: float,
    tilt_deg: np.ndarray | float,
    ground_coverage_ratio: float,
) -> np.ndarray:
    """Fraction of a row's collector height shaded by the row immediately in front,
    for parallel rows of fixed-tilt collectors sharing one azimuth.

    `ground_coverage_ratio` = collector slant width / row pitch. Uses the
    profile-angle projection of the sun into the plane perpendicular to the
    row axis, a standard reduced-order model for beam self-shading.
    """
    elev = np.radians(np.clip(sun_elevation_deg, 1e-6, 90.0))
    rel_az = np.radians(sun_azimuth_deg - row_azimuth_deg)

    with np.errstate(divide="ignore", invalid="ignore"):
        tan_profile = np.tan(elev) / np.clip(np.cos(rel_az), 1e-6, None)

    beta = np.radians(tilt_deg)
    gcr = max(ground_coverage_ratio, 1e-6)

    with np.errstate(divide="ignore", invalid="ignore"):
        overhang = np.sin(beta) / tan_profile - 1.0 / gcr

    shaded = overhang / np.maximum(np.cos(beta), 1e-6)
    shaded = np.where(tan_profile <= 0, 1.0, shaded)
    shaded = np.where(sun_elevation_deg <= 0, 1.0, shaded)
    return np.clip(shaded, 0.0, 1.0)


def combined_shading_fraction(
    obstruction_fraction: np.ndarray,
    row_to_row_fraction: np.ndarray,
) -> np.ndarray:
    """Combine independent shading mechanisms conservatively (max, not additive)."""
    return np.clip(np.maximum(obstruction_fraction, row_to_row_fraction), 0.0, 1.0)


def sky_dome_shading_map(
    obstructions: list[Obstruction],
    azimuth_grid_deg: np.ndarray | None = None,
    elevation_grid_deg: np.ndarray | None = None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Build a (azimuth x elevation) grid of blocked fraction for horizon visualisation."""
    if azimuth_grid_deg is None:
        azimuth_grid_deg = np.linspace(0, 360, 361)
    if elevation_grid_deg is None:
        elevation_grid_deg = np.linspace(0, 90, 91)

    az_mesh, el_mesh = np.meshgrid(azimuth_grid_deg, elevation_grid_deg)
    blocked = obstruction_shading_fraction(az_mesh, el_mesh, obstructions)
    return az_mesh, el_mesh, blocked
