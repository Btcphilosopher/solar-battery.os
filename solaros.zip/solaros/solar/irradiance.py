"""Solar irradiance: clear-sky components, all-sky (cloud-modified) components,
and projection onto a tilted plane-of-array.

Model basis: SIMPLIFIED. The clear-sky beam/diffuse split and the isotropic
sky-diffuse transposition model are textbook-standard reduced-order models
(Liu & Jordan 1963 isotropic sky; Meinel clear-sky beam). They trade the
extra few percent accuracy of a full Perez anisotropic model for a much
smaller, more auditable parameter set. Swap `plane_of_array_irradiance`
for a Perez implementation if bankable-grade P50 accuracy is required.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from solaros.solar.atmosphere import (
    clear_sky_beam_transmittance,
    extraterrestrial_irradiance_w_m2,
    pressure_corrected_air_mass,
    relative_air_mass,
)


@dataclass
class IrradianceComponents:
    dni_w_m2: np.ndarray  # direct normal irradiance
    dhi_w_m2: np.ndarray  # diffuse horizontal irradiance
    ghi_w_m2: np.ndarray  # global horizontal irradiance


def clear_sky_irradiance(
    day_of_year: np.ndarray,
    elevation_deg: np.ndarray,
    pressure_kpa: float = 101.325,
    linke_turbidity: float = 3.0,
) -> IrradianceComponents:
    """DNI/DHI/GHI under a cloud-free sky, as a function of sun position alone."""
    zenith_deg = 90.0 - elevation_deg
    am = pressure_corrected_air_mass(relative_air_mass(zenith_deg), pressure_kpa)
    i0 = extraterrestrial_irradiance_w_m2(day_of_year)
    transmittance = clear_sky_beam_transmittance(am, linke_turbidity)

    sun_up = elevation_deg > 0.0
    dni = np.where(sun_up, i0 * transmittance, 0.0)

    sin_elev = np.clip(np.sin(np.radians(elevation_deg)), 0.0, 1.0)
    beam_horizontal = dni * sin_elev
    # Clear-sky diffuse ~ a small, turbidity-dependent fraction of the beam
    # horizontal component (rough but standard rule-of-thumb, see Liu & Jordan).
    diffuse_fraction = np.clip(0.09 + 0.01 * (linke_turbidity - 2.0), 0.05, 0.25)
    dhi = np.where(sun_up, diffuse_fraction * beam_horizontal, 0.0)
    ghi = beam_horizontal + dhi

    return IrradianceComponents(dni_w_m2=dni, dhi_w_m2=dhi, ghi_w_m2=ghi)


def apply_cloud_cover(clear_sky: IrradianceComponents, cloud_transmittance: np.ndarray) -> IrradianceComponents:
    """Attenuate clear-sky irradiance by an all-sky/clear-sky transmittance ratio.

    Clouds attenuate the beam component sharply and partly *increase* the
    diffuse component (light scattered by cloud edges); we cap diffuse
    enhancement at a modest empirical factor rather than letting it run away.
    """
    ct = np.clip(cloud_transmittance, 0.0, 1.0)
    dni = clear_sky.dni_w_m2 * ct
    dhi = clear_sky.dhi_w_m2 * np.clip(1.6 - 0.6 * ct, 1.0, 1.6)
    ghi = clear_sky.ghi_w_m2 * ct
    dhi = np.minimum(dhi, ghi)
    return IrradianceComponents(dni_w_m2=dni, dhi_w_m2=dhi, ghi_w_m2=np.maximum(ghi, dhi))


def plane_of_array_irradiance(
    irradiance: IrradianceComponents,
    aoi_deg: np.ndarray,
    tilt_deg: np.ndarray,
    albedo: float = 0.2,
) -> np.ndarray:
    """Project DNI/DHI/GHI onto a tilted surface: beam + isotropic sky diffuse + ground reflection."""
    cos_aoi = np.clip(np.cos(np.radians(aoi_deg)), 0.0, 1.0)
    tilt_rad = np.radians(tilt_deg)

    poa_beam = irradiance.dni_w_m2 * cos_aoi
    poa_sky_diffuse = irradiance.dhi_w_m2 * (1 + np.cos(tilt_rad)) / 2.0
    poa_ground = irradiance.ghi_w_m2 * albedo * (1 - np.cos(tilt_rad)) / 2.0

    return poa_beam + poa_sky_diffuse + poa_ground
