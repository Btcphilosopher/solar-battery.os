"""Soiling: dust, pollen, snow, salt spray, bird fouling and general dirt
accumulating on the glass, and the cleaning policies that fight it.

Model basis: EMPIRICAL. Follows the Kimber et al. (2006) shape -- soiling
loss builds up roughly linearly with dry days and is washed off by rain
events above a threshold -- with a single configurable daily accumulation
rate rather than a full dust-deposition physics model.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

import numpy as np


@dataclass
class SoilingModel:
    daily_soiling_rate_pct: float = 0.06
    max_soiling_loss_pct: float = 15.0
    rain_cleaning_threshold_mm: float = 5.0
    natural_cleaning_effectiveness: float = 0.9  # fraction of accumulated soiling washed off by a qualifying rain

    def simulate_daily_loss_fraction(
        self,
        daily_rainfall_mm: np.ndarray,
        cleaning_days: np.ndarray | None = None,
        cleaning_effectiveness: float = 0.95,
    ) -> np.ndarray:
        """Day-by-day soiling loss fraction (0-1), including natural rain cleaning
        and any scheduled/manual cleaning days. Inherently sequential (today's
        soiling depends on yesterday's), so this is a plain Python loop over days
        -- cheap at the ~365-3650 day scale this function is meant for.
        """
        n = len(daily_rainfall_mm)
        cleaning_days = np.zeros(n, dtype=bool) if cleaning_days is None else np.asarray(cleaning_days, dtype=bool)
        loss_pct = np.zeros(n)
        current = 0.0
        for day in range(n):
            current += self.daily_soiling_rate_pct
            if daily_rainfall_mm[day] >= self.rain_cleaning_threshold_mm:
                current *= 1.0 - self.natural_cleaning_effectiveness
            if cleaning_days[day]:
                current *= 1.0 - cleaning_effectiveness
            current = min(current, self.max_soiling_loss_pct)
            loss_pct[day] = current
        return loss_pct / 100.0


class CleaningPolicy(str, Enum):
    NONE = "none"
    MONTHLY = "monthly"
    QUARTERLY = "quarterly"
    WEATHER_BASED = "weather_based"
    OPTIMISED = "optimised"


def scheduled_cleaning_days(num_days: int, interval_days: int) -> np.ndarray:
    days = np.zeros(num_days, dtype=bool)
    if interval_days > 0:
        days[::interval_days] = True
    return days


def weather_based_cleaning_days(
    soiling: SoilingModel,
    daily_rainfall_mm: np.ndarray,
    trigger_loss_pct: float = 6.0,
) -> np.ndarray:
    """Clean whenever *monitored* accumulated soiling would cross a trigger
    threshold, rather than on a fixed calendar -- avoids cleaning a panel
    that natural rain already washed.
    """
    n = len(daily_rainfall_mm)
    cleaning_days = np.zeros(n, dtype=bool)
    current = 0.0
    for day in range(n):
        current += soiling.daily_soiling_rate_pct
        if daily_rainfall_mm[day] >= soiling.rain_cleaning_threshold_mm:
            current *= 1.0 - soiling.natural_cleaning_effectiveness
        if current >= trigger_loss_pct:
            cleaning_days[day] = True
            current = 0.0
    return cleaning_days


def cleaning_days_for_policy(
    policy: CleaningPolicy,
    soiling: SoilingModel,
    daily_rainfall_mm: np.ndarray,
) -> np.ndarray:
    n = len(daily_rainfall_mm)
    if policy is CleaningPolicy.NONE:
        return np.zeros(n, dtype=bool)
    if policy is CleaningPolicy.MONTHLY:
        return scheduled_cleaning_days(n, 30)
    if policy is CleaningPolicy.QUARTERLY:
        return scheduled_cleaning_days(n, 91)
    if policy is CleaningPolicy.WEATHER_BASED:
        return weather_based_cleaning_days(soiling, daily_rainfall_mm)
    raise ValueError(f"{policy} requires optimise_cleaning_policy(), not a fixed schedule")


def optimise_cleaning_policy(
    soiling: SoilingModel,
    daily_rainfall_mm: np.ndarray,
    daily_clear_sky_energy_kwh: np.ndarray,
    energy_value_eur_per_kwh: float,
    cleaning_cost_eur: float,
    trigger_candidates_pct: np.ndarray | None = None,
) -> dict:
    """Search cleaning-trigger thresholds for the one maximising NET useful
    electricity value (spec #16, #31): energy recovered by cleaning, minus
    the labour/water/energy cost of doing it. Not "clean as often as possible".
    """
    if trigger_candidates_pct is None:
        trigger_candidates_pct = np.arange(2.0, 15.0, 0.5)

    best = {"trigger_loss_pct": None, "net_benefit_eur": -np.inf, "cleaning_events": 0}
    baseline_days = cleaning_days_for_policy(CleaningPolicy.NONE, soiling, daily_rainfall_mm)
    baseline_loss = soiling.simulate_daily_loss_fraction(daily_rainfall_mm, baseline_days)
    baseline_energy_kwh = float(np.sum(daily_clear_sky_energy_kwh * (1 - baseline_loss)))

    for trigger in trigger_candidates_pct:
        cleaning_days = weather_based_cleaning_days(soiling, daily_rainfall_mm, trigger)
        loss = soiling.simulate_daily_loss_fraction(daily_rainfall_mm, cleaning_days)
        energy_kwh = float(np.sum(daily_clear_sky_energy_kwh * (1 - loss)))
        recovered_kwh = energy_kwh - baseline_energy_kwh
        n_events = int(np.sum(cleaning_days))
        net_benefit = recovered_kwh * energy_value_eur_per_kwh - n_events * cleaning_cost_eur
        if net_benefit > best["net_benefit_eur"]:
            best = {
                "trigger_loss_pct": float(trigger),
                "net_benefit_eur": net_benefit,
                "cleaning_events": n_events,
                "recovered_kwh": recovered_kwh,
            }
    return best
