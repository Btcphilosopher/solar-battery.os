"""The single-diode equivalent-circuit model: the physical heart of SolarOS.

    I = Iph - I0*(exp((V + I*Rs)/a) - 1) - (V + I*Rs)/Rsh

with a = n * Ns * Vt(T), Vt(T) = k*T/q the thermal voltage.

Model basis: PHYSICAL for the diode equation itself and its irradiance/
temperature dependence (De Soto et al. 2006 translation equations). The
datasheet -> (Iph, I0, Rs, Rsh, n) parameter *extraction* is a SIMPLIFIED
single-pass approximation (assumes Rsh >> Rs while solving for Rs from the
MPP condition, then sets Rsh from a heuristic) -- good enough to reproduce
Voc/Isc/Vmp/Imp/Pmp to within datasheet tolerance, but not a substitute for
a full iterative 5-parameter fit against measured I-V curves.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np
from pydantic import BaseModel, Field
from scipy import constants
from scipy.optimize import brentq, minimize_scalar
from scipy.special import lambertw

BOLTZMANN_J_PER_K = constants.k
ELEMENTARY_CHARGE_C = constants.e
STC_IRRADIANCE_W_M2 = 1000.0
STC_TEMPERATURE_K = 298.15  # 25 deg C


class CellParameters(BaseModel):
    """Datasheet parameters for one PV technology, at Standard Test Conditions
    (1000 W/m^2, 25 degC cell temperature, AM1.5 spectrum).
    """

    technology: str = Field(..., description="e.g. mono-si, poly-si, thin-film-cdte")
    v_oc_v: float = Field(..., gt=0)
    i_sc_a: float = Field(..., gt=0)
    v_mp_v: float = Field(..., gt=0)
    i_mp_a: float = Field(..., gt=0)
    cells_in_series: int = Field(..., gt=0)
    temp_coeff_voc_pct_per_k: float = Field(..., description="negative for silicon")
    temp_coeff_isc_pct_per_k: float = Field(0.05, description="positive for silicon")
    temp_coeff_pmax_pct_per_k: float = Field(..., description="negative, overall power temp coefficient")
    ideality_factor: float = Field(1.2, gt=0.8, lt=2.0)
    bandgap_ev: float = Field(1.121, gt=0)
    series_resistance_ohm: Optional[float] = None
    shunt_resistance_ohm: Optional[float] = None

    @property
    def p_mp_w(self) -> float:
        return self.v_mp_v * self.i_mp_a


@dataclass
class SingleDiodeParameters:
    """Physical five-parameter single-diode model, referenced to STC."""

    photocurrent_ref_a: float
    saturation_current_ref_a: float
    series_resistance_ohm: float
    shunt_resistance_ref_ohm: float
    ideality_factor: float
    cells_in_series: int
    bandgap_ev: float = 1.121
    alpha_isc_a_per_k: float = 0.0


def _lambertw_of_exp(log_arg: np.ndarray) -> np.ndarray:
    """W(exp(log_arg)), principal branch, computed without overflowing exp()
    for large log_arg (which happens routinely for modules with many series
    cells / high shunt resistance). Below the overflow threshold this is
    exactly `lambertw(exp(log_arg))`; above it, W is found directly from
    w + ln(w) = log_arg via Newton iteration on the asymptotic seed
    w0 = log_arg - ln(log_arg), converging in a handful of steps.
    """
    log_arg = np.asarray(log_arg, dtype=float)
    out = np.empty_like(log_arg)
    small = log_arg < 500.0

    if np.any(small):
        out[small] = np.real(lambertw(np.exp(log_arg[small])))

    if np.any(~small):
        z = log_arg[~small]
        w = z - np.log(z)
        for _ in range(8):
            w = w - (w + np.log(np.maximum(w, 1e-300)) - z) / (1.0 + 1.0 / np.maximum(w, 1e-300))
        out[~small] = w

    return out


def thermal_voltage_v(temperature_k: np.ndarray, ideality_factor: float, cells_in_series: int) -> np.ndarray:
    return ideality_factor * cells_in_series * BOLTZMANN_J_PER_K * temperature_k / ELEMENTARY_CHARGE_C


def extract_single_diode_parameters(cell: CellParameters) -> SingleDiodeParameters:
    """Recover (Iph, I0, Rs, Rsh, n) at STC from four datasheet points
    (Voc, Isc, Vmp, Imp), assuming Rsh >> Rs during extraction.
    """
    n, ns = cell.ideality_factor, cell.cells_in_series
    a = n * ns * BOLTZMANN_J_PER_K * STC_TEMPERATURE_K / ELEMENTARY_CHARGE_C

    iph_ref = cell.i_sc_a  # Rs=0 at V=0 => Iph ~= Isc to first order
    i0_ref = (cell.i_sc_a - cell.i_mp_a) / (np.exp(cell.v_oc_v / a) - np.exp(cell.v_mp_v / a))
    i0_ref = max(i0_ref, 1e-14)

    if cell.series_resistance_ohm is not None:
        rs = cell.series_resistance_ohm
    else:
        bracket = (iph_ref - cell.i_mp_a + i0_ref) / i0_ref
        rs = (a * np.log(max(bracket, 1e-12)) - cell.v_mp_v) / cell.i_mp_a
        rs = max(rs, 1e-4)

    if cell.shunt_resistance_ohm is not None:
        rsh_ref = cell.shunt_resistance_ohm
    else:
        rsh_ref = 100.0 * cell.v_oc_v / cell.i_sc_a  # heuristic: shunt loss << series loss for a healthy module

    alpha_isc_a_per_k = cell.temp_coeff_isc_pct_per_k / 100.0 * cell.i_sc_a

    return SingleDiodeParameters(
        photocurrent_ref_a=iph_ref,
        saturation_current_ref_a=i0_ref,
        series_resistance_ohm=rs,
        shunt_resistance_ref_ohm=rsh_ref,
        ideality_factor=n,
        cells_in_series=ns,
        bandgap_ev=cell.bandgap_ev,
        alpha_isc_a_per_k=alpha_isc_a_per_k,
    )


def _translate_to_conditions(
    params: SingleDiodeParameters,
    irradiance_w_m2: np.ndarray,
    cell_temperature_c: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """De Soto (2006) translation of the five parameters from STC to (G, T)."""
    g = np.maximum(np.asarray(irradiance_w_m2, dtype=float), 0.0)
    t_k = np.asarray(cell_temperature_c, dtype=float) + 273.15

    delta_t = t_k - STC_TEMPERATURE_K
    iph = (g / STC_IRRADIANCE_W_M2) * (params.photocurrent_ref_a + params.alpha_isc_a_per_k * delta_t)

    i0 = (
        params.saturation_current_ref_a
        * (t_k / STC_TEMPERATURE_K) ** 3
        * np.exp(
            (params.bandgap_ev * ELEMENTARY_CHARGE_C / (params.ideality_factor * BOLTZMANN_J_PER_K))
            * (1.0 / STC_TEMPERATURE_K - 1.0 / np.maximum(t_k, 1.0))
        )
    )

    g_safe = np.maximum(g, 1.0)
    rsh = np.clip(params.shunt_resistance_ref_ohm * (STC_IRRADIANCE_W_M2 / g_safe), 0.0, params.shunt_resistance_ref_ohm * 200.0)
    rs = np.full_like(iph, params.series_resistance_ohm)

    a = thermal_voltage_v(t_k, params.ideality_factor, params.cells_in_series)

    return iph, i0, rs, rsh, a


def current_from_voltage(
    params: SingleDiodeParameters,
    voltage_v: np.ndarray,
    irradiance_w_m2: np.ndarray,
    cell_temperature_c: np.ndarray,
) -> np.ndarray:
    """Closed-form I(V) via the Lambert-W solution of the single-diode equation
    (Jain & Kapoor 2004), vectorised over voltage/irradiance/temperature.
    """
    v = np.asarray(voltage_v, dtype=float)
    iph, i0, rs, rsh, a = _translate_to_conditions(params, irradiance_w_m2, cell_temperature_c)
    iph, i0, rs, rsh, a, v = np.broadcast_arrays(iph, i0, rs, rsh, a, v)

    gsh = 1.0 / np.maximum(rsh, 1e-9)

    zero_rs = rs < 1e-9
    rs_safe = np.where(zero_rs, 1.0, rs)  # placeholder to avoid /0; overwritten below

    denom = rs_safe * gsh + 1.0
    log_arg_w = np.log(rs_safe * i0 / (a * denom)) + (v + rs_safe * (iph + i0)) / (a * denom)
    lambert_term = _lambertw_of_exp(log_arg_w)
    i_general = (iph + i0 - v * gsh) / denom - (a / rs_safe) * lambert_term

    # explicit closed form when Rs ~ 0 (no implicit V+I*Rs coupling)
    i_zero_rs = iph - i0 * (np.expm1(v / a)) - v * gsh

    return np.where(zero_rs, i_zero_rs, i_general).real


def voltage_from_current(
    params: SingleDiodeParameters,
    current_a: np.ndarray,
    irradiance_w_m2: np.ndarray,
    cell_temperature_c: np.ndarray,
) -> np.ndarray:
    """Closed-form V(I), the Lambert-W dual of `current_from_voltage`. Needed to
    combine series-connected substrings/modules at a shared current (bypass
    diodes, string mismatch) without an iterative circuit solve.
    """
    i = np.asarray(current_a, dtype=float)
    iph, i0, rs, rsh, a = _translate_to_conditions(params, irradiance_w_m2, cell_temperature_c)
    iph, i0, rs, rsh, a, i = np.broadcast_arrays(iph, i0, rs, rsh, a, i)

    gsh = 1.0 / np.maximum(rsh, 1e-9)
    zero_gsh = rsh > 1e8

    c = iph + i0 - i  # Iph + I0 - I
    # general case (finite Rsh): x = C/Gsh - a*W((I0/(Gsh*a))*exp(C/(Gsh*a)))
    gsh_safe = np.where(zero_gsh, 1.0, gsh)
    log_arg_w = np.log(i0 / (gsh_safe * a)) + c / (gsh_safe * a)
    x_general = c / gsh_safe - a * _lambertw_of_exp(log_arg_w)

    # Rsh -> infinity: I = Iph - I0*(exp(x/a)-1)  =>  x = a*ln((Iph+I0-I)/I0)
    x_inf_rsh = a * np.log(np.maximum(c, 1e-14) / i0)

    x = np.where(zero_gsh, x_inf_rsh, x_general)
    return (x - i * rs).real


@dataclass
class MPPResult:
    v_oc_v: float
    i_sc_a: float
    v_mp_v: float
    i_mp_a: float
    p_mp_w: float


def solve_mpp(
    params: SingleDiodeParameters,
    irradiance_w_m2: float,
    cell_temperature_c: float,
) -> MPPResult:
    """Locate Voc, Isc and the maximum power point for one (G, T) condition."""
    if irradiance_w_m2 <= 0:
        return MPPResult(0.0, 0.0, 0.0, 0.0, 0.0)

    isc = float(current_from_voltage(params, 0.0, irradiance_w_m2, cell_temperature_c))

    v_upper = 1.4 * params.cells_in_series * 0.7  # generous upper bound, ~0.7 V/cell at Voc
    f = lambda v: float(current_from_voltage(params, v, irradiance_w_m2, cell_temperature_c))
    try:
        voc = brentq(f, 1e-6, v_upper, xtol=1e-6)
    except ValueError:
        voc = v_upper

    neg_power = lambda v: -v * f(v)
    res = minimize_scalar(neg_power, bounds=(1e-6, voc), method="bounded", options={"xatol": 1e-6})
    v_mp = float(res.x)
    i_mp = f(v_mp)
    p_mp = v_mp * i_mp

    return MPPResult(v_oc_v=voc, i_sc_a=isc, v_mp_v=v_mp, i_mp_a=i_mp, p_mp_w=p_mp)
