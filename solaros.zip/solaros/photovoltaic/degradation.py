"""Long-term power degradation.

Model basis: EMPIRICAL / USER_DATA. Real degradation depends on thermal
cycling, UV exposure, humidity ingress, and operating history in ways that
are technology- and site-specific. We provide a configurable linear model
(the industry-standard warranty shape: an initial light-induced-degradation
step, then a steady linear annual rate) but do NOT claim it reproduces any
specific panel's real-world degradation without calibration against that
panel's measured field data.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class DegradationModel:
    annual_rate_pct_per_year: float = 0.5
    first_year_light_induced_pct: float = 2.0
    """One-off degradation in year 1 from light-induced degradation (LID) /
    initial stabilisation, on top of the steady annual rate thereafter."""

    def remaining_capacity_fraction(self, age_years: np.ndarray) -> np.ndarray:
        age = np.maximum(np.asarray(age_years, dtype=float), 0.0)
        lid = np.where(age > 0, self.first_year_light_induced_pct / 100.0, 0.0)
        steady = self.annual_rate_pct_per_year / 100.0 * np.maximum(age - 1.0, 0.0)
        steady_year1 = self.annual_rate_pct_per_year / 100.0 * np.minimum(age, 1.0)
        total_loss = lid + steady + steady_year1
        return np.clip(1.0 - total_loss, 0.0, 1.0)

    def lifetime_energy_kwh(self, annual_kwh_at_stc: float, lifetime_years: int) -> float:
        years = np.arange(1, lifetime_years + 1)
        capacity = self.remaining_capacity_fraction(years - 0.5)  # mid-year average capacity
        return float(np.sum(annual_kwh_at_stc * capacity))
