"""PV module (panel): a named, physically-sized package around a single-diode
cell model. Different technologies are configuration, not special-cased
branches -- add a new preset instead of an `if technology == ...`.
"""
from __future__ import annotations

from pydantic import BaseModel, Field

from solaros.photovoltaic.cell import CellParameters, SingleDiodeParameters, extract_single_diode_parameters


class Panel(BaseModel):
    """A physical, purchasable PV module."""

    name: str
    cell: CellParameters
    area_m2: float = Field(..., gt=0)
    noct_c: float = Field(45.0, description="Nominal Operating Cell Temperature, degC, at 800 W/m2, 20degC ambient, 1 m/s wind")
    degradation_rate_pct_per_year: float = Field(0.5, ge=0)
    mass_kg: float | None = None

    @property
    def rated_power_w(self) -> float:
        return self.cell.v_mp_v * self.cell.i_mp_a

    @property
    def efficiency_fraction(self) -> float:
        """STC electrical efficiency = rated power / (STC irradiance * area)."""
        return self.rated_power_w / (1000.0 * self.area_m2)

    @property
    def single_diode_parameters(self) -> SingleDiodeParameters:
        return extract_single_diode_parameters(self.cell)


PRESET_PANELS: dict[str, Panel] = {
    "mono-si": Panel(
        name="generic-mono-si-400w",
        cell=CellParameters(
            technology="mono-si",
            v_oc_v=49.5,
            i_sc_a=10.65,
            v_mp_v=41.4,
            i_mp_a=9.66,
            cells_in_series=108,
            temp_coeff_voc_pct_per_k=-0.27,
            temp_coeff_isc_pct_per_k=0.045,
            temp_coeff_pmax_pct_per_k=-0.34,
            ideality_factor=1.1,
            bandgap_ev=1.121,
        ),
        area_m2=1.95,
        noct_c=43.0,
        degradation_rate_pct_per_year=0.45,
    ),
    "poly-si": Panel(
        name="generic-poly-si-330w",
        cell=CellParameters(
            technology="poly-si",
            v_oc_v=45.8,
            i_sc_a=9.36,
            v_mp_v=37.1,
            i_mp_a=8.90,
            cells_in_series=72,
            temp_coeff_voc_pct_per_k=-0.32,
            temp_coeff_isc_pct_per_k=0.05,
            temp_coeff_pmax_pct_per_k=-0.41,
            ideality_factor=1.25,
            bandgap_ev=1.121,
        ),
        area_m2=1.94,
        noct_c=45.0,
        degradation_rate_pct_per_year=0.60,
    ),
    "thin-film-cdte": Panel(
        name="generic-thin-film-cdte-120w",
        cell=CellParameters(
            technology="thin-film-cdte",
            v_oc_v=110.0,
            i_sc_a=1.62,
            v_mp_v=87.4,
            i_mp_a=1.42,
            cells_in_series=270,
            temp_coeff_voc_pct_per_k=-0.25,
            temp_coeff_isc_pct_per_k=0.04,
            temp_coeff_pmax_pct_per_k=-0.25,
            ideality_factor=1.5,
            bandgap_ev=1.45,
        ),
        area_m2=1.20,
        noct_c=45.0,
        degradation_rate_pct_per_year=0.50,
    ),
}


def get_preset(technology: str) -> Panel:
    """Look up a built-in representative panel by technology key.

    Supports adding new/future technologies by registering another entry in
    `PRESET_PANELS` -- no branching logic elsewhere in the codebase depends
    on the technology string beyond spectral-mismatch lookup.
    """
    try:
        return PRESET_PANELS[technology].model_copy(deep=True)
    except KeyError as exc:
        raise KeyError(f"Unknown panel technology '{technology}'. Known: {list(PRESET_PANELS)}") from exc
