"""Panel thermal models: how hot the cells get, and the fast linearised
power correction used where a full single-diode re-solve isn't warranted.

Model basis: EMPIRICAL (NOCT and Faiman thermal models are both fitted to
outdoor reference measurements, not first-principles heat-transfer PDEs).
"""
from __future__ import annotations

import numpy as np


def noct_cell_temperature_c(
    ambient_temperature_c: np.ndarray,
    poa_irradiance_w_m2: np.ndarray,
    noct_c: float = 45.0,
) -> np.ndarray:
    """Simple NOCT model: cell temperature rise is linear in irradiance, ignores wind.

    NOCT is measured at 800 W/m^2, 20 degC ambient, 1 m/s wind, open-rack mounting.
    """
    return ambient_temperature_c + (noct_c - 20.0) / 800.0 * poa_irradiance_w_m2


# Faiman (2008) coefficients, W/(m^2.K) and W/(m^2.K per m/s), by mounting configuration.
FAIMAN_COEFFICIENTS = {
    "open_rack": (25.0, 6.84),
    "roof_mount": (18.0, 3.4),        # reduced rear ventilation -> hotter
    "rear_air_gap": (22.0, 5.4),      # ventilated standoff mount, between roof and open rack
    "building_integrated": (13.0, 2.0),  # BIPV / no rear ventilation at all
}


def faiman_module_temperature_c(
    ambient_temperature_c: np.ndarray,
    poa_irradiance_w_m2: np.ndarray,
    wind_speed_m_s: np.ndarray,
    mounting: str = "open_rack",
    u0_override: float | None = None,
    u1_override: float | None = None,
) -> np.ndarray:
    """Faiman (2008) steady-state module temperature model, wind-speed aware.

    `u0_override`/`u1_override` let active-cooling scenarios (forced air,
    water cooling) substitute an effective heat-loss coefficient beyond what
    any passive mounting preset can reach -- see optimisation.cooling.
    """
    u0, u1 = FAIMAN_COEFFICIENTS.get(mounting, FAIMAN_COEFFICIENTS["open_rack"])
    if u0_override is not None:
        u0 = u0_override
    if u1_override is not None:
        u1 = u1_override
    heat_loss_coeff = u0 + u1 * np.maximum(wind_speed_m_s, 0.0)
    return ambient_temperature_c + poa_irradiance_w_m2 / np.maximum(heat_loss_coeff, 1e-6)


def cell_temperature_from_module_c(
    module_temperature_c: np.ndarray,
    poa_irradiance_w_m2: np.ndarray,
    delta_t_at_stc_c: float = 3.0,
) -> np.ndarray:
    """Cell-to-module temperature offset, scaled by irradiance (Sandia-style ΔT)."""
    return module_temperature_c + delta_t_at_stc_c * (poa_irradiance_w_m2 / 1000.0)


def linearised_power_correction(
    power_at_stc_w: np.ndarray,
    cell_temperature_c: np.ndarray,
    temp_coeff_pmax_pct_per_k: float,
    reference_temperature_c: float = 25.0,
) -> np.ndarray:
    """Fast first-order power correction for temperature, bypassing a full
    single-diode re-solve. Used for quick sensitivity checks; the main
    simulation path solves the diode equation directly at each condition.
    """
    factor = 1.0 + (temp_coeff_pmax_pct_per_k / 100.0) * (cell_temperature_c - reference_temperature_c)
    return power_at_stc_w * np.maximum(factor, 0.0)
