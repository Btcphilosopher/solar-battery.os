"""PV array: strings of series modules, combined in parallel, with the
electrical mismatch losses that naturally fall out of combining non-identical
sources at one shared operating point.

Model basis: PHYSICAL for the series/parallel circuit combination (it's the
same Kirchhoff current/voltage-law superposition used in iv_curve.py);
EMPIRICAL for the manufacturing/aging power-tolerance mismatch adder, which
uses the standard variance-based mismatch approximation rather than a full
Monte-Carlo population of modules.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
from pydantic import BaseModel, Field

from solaros.electrical.iv_curve import (
    IVCurve,
    combine_parallel,
    combine_series,
    module_iv_curve_with_bypass,
)
from solaros.photovoltaic.module import Panel


class ArrayLayout(BaseModel):
    """How many modules make up the array, wired series-then-parallel."""

    modules_per_string: int = Field(..., gt=0)
    strings_parallel: int = Field(..., gt=0)

    @property
    def total_modules(self) -> int:
        return self.modules_per_string * self.strings_parallel


@dataclass
class StringCondition:
    """Operating condition for one group of identical, identically-illuminated strings."""

    irradiance_w_m2: float
    cell_temperature_c: float
    shaded_fraction: float = 0.0
    n_strings: int = 1


@dataclass
class ArrayOutput:
    voltage_v: float
    current_a: float
    power_w: float
    ideal_power_w: float  # sum of each string operating at its own independent MPP
    mismatch_loss_fraction: float
    curve: IVCurve


def manufacturing_mismatch_loss_fraction(power_tolerance_std_pct: float = 1.5) -> float:
    """Classic variance-based mismatch approximation for a population of modules
    with power output scattered around the nameplate rating (Bucciarelli 1979-style):
    fractional array power loss ~= (std_dev / mean)^2 for a large parallel/series population.
    """
    sigma = power_tolerance_std_pct / 100.0
    return float(sigma**2)


def simulate_array(
    panel: Panel,
    layout: ArrayLayout,
    conditions: list[StringCondition],
    n_substrings_per_module: int = 3,
    include_manufacturing_mismatch: bool = True,
    manufacturing_power_tolerance_pct: float = 1.5,
) -> ArrayOutput:
    """Combine `layout.modules_per_string` series modules per string, then
    combine all strings (grouped by `conditions`) in parallel, and report both
    the actual array MPP (one shared operating point) and the ideal MPP each
    string could reach independently -- the gap between them is mismatch loss.
    """
    total_strings = sum(c.n_strings for c in conditions)
    if total_strings != layout.strings_parallel:
        raise ValueError(f"conditions describe {total_strings} strings, layout expects {layout.strings_parallel}")

    string_curves: list[IVCurve] = []
    ideal_power_w = 0.0
    for cond in conditions:
        module_curve = module_iv_curve_with_bypass(
            panel.single_diode_parameters,
            cond.irradiance_w_m2,
            cond.cell_temperature_c,
            shaded_fraction=cond.shaded_fraction,
            n_substrings=n_substrings_per_module,
        )
        string_curve = combine_series([module_curve] * layout.modules_per_string)
        _, _, string_pmp = string_curve.mpp()
        ideal_power_w += string_pmp * cond.n_strings
        for _ in range(cond.n_strings):
            string_curves.append(string_curve)

    array_curve = combine_parallel(string_curves)
    v_mp, i_mp, p_mp = array_curve.mpp()

    mismatch_loss_fraction = 1.0 - (p_mp / ideal_power_w) if ideal_power_w > 0 else 0.0

    if include_manufacturing_mismatch:
        extra_loss = manufacturing_mismatch_loss_fraction(manufacturing_power_tolerance_pct)
        p_mp *= 1.0 - extra_loss
        mismatch_loss_fraction = 1.0 - (p_mp / ideal_power_w) if ideal_power_w > 0 else 0.0

    return ArrayOutput(
        voltage_v=v_mp,
        current_a=i_mp,
        power_w=p_mp,
        ideal_power_w=ideal_power_w,
        mismatch_loss_fraction=mismatch_loss_fraction,
        curve=array_curve,
    )


def uniform_array_power_w(
    panel: Panel,
    layout: ArrayLayout,
    irradiance_w_m2: np.ndarray,
    cell_temperature_c: np.ndarray,
) -> np.ndarray:
    """Fast path for the common case: every module in the array sees the same
    irradiance/temperature (no shading, no mismatch). Vectorised over a whole
    time series via the module's single-diode MPP, scaled by module count --
    used by the year-long simulation loop where a full per-timestep circuit
    resolve for thousands of hours would be wasteful.
    """
    from solaros.photovoltaic.cell import current_from_voltage  # local import, avoid cycle at module load

    sdp = panel.single_diode_parameters
    g = np.atleast_1d(np.asarray(irradiance_w_m2, dtype=float))
    t = np.atleast_1d(np.asarray(cell_temperature_c, dtype=float))
    t = np.broadcast_to(t, g.shape)

    # One fully-vectorised MPP search over all timesteps at once: a shared
    # voltage grid (rows) x every timestep (columns), rather than a Python
    # loop re-invoking the Lambert-W solve per hour.
    voc_guess = sdp.cells_in_series * 0.75 * 1.2
    v_grid = np.linspace(1e-3, voc_guess, 200)[:, None]  # (200, 1)

    daylight = g > 0
    g_row = np.where(daylight, g, 1.0)[None, :]  # (1, N), placeholder for night to avoid wasted branches
    t_row = t[None, :]

    i_curve = current_from_voltage(sdp, v_grid, g_row, t_row)  # (200, N)
    p_curve = v_grid * np.maximum(i_curve, 0.0)
    power_per_module_w = np.where(daylight, np.max(p_curve, axis=0), 0.0)

    return power_per_module_w * layout.total_modules
