"""The single top-level entry point (spec #26): take a baseline system,
apply every optimisation lever SolarOS knows about, and report exactly how
much of the gain came from where.

This is a greedy, sequential (coordinate-ascent) optimiser -- it optimises
tilt, then azimuth, then cleaning policy, then tracking mode, then MPPT
tracking-efficiency assumption, each on top of the previous step's result.
That is a deliberate compute/optimality trade-off: a full joint search over
every combination of these levers would multiply simulation counts far
beyond what a single interactive call should cost, and for this system the
levers are only weakly coupled (the tilt that's best for a fixed array is
also close to best once tracking is added, etc). It will not always find
the true joint global optimum; it will always find *a* documented,
reproducible improvement with every assumption traced.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from solaros.core.configuration import Assumption, OptimisationResult
from solaros.core.simulation import SystemConfig, run_simulation
from solaros.optimisation.azimuth import optimise_azimuth
from solaros.optimisation.cooling import evaluate_cooling_scenarios
from solaros.optimisation.mppt import recommend_mppt_algorithm
from solaros.optimisation.tilt import optimise_tilt
from solaros.optimisation.tracking import TrackingCostAssumptions, compare_tracking_options
from solaros.photovoltaic.soiling import CleaningPolicy
from solaros.weather.weather import WeatherSeries


@dataclass
class OptimisationStep:
    name: str
    kwh_before: float
    kwh_after: float
    parameters_changed: dict
    note: str = ""

    @property
    def gain_kwh(self) -> float:
        return self.kwh_after - self.kwh_before


@dataclass
class SystemOptimisationReport:
    baseline_annual_kwh: float
    optimised_annual_kwh: float
    best_system: SystemConfig
    steps: list[OptimisationStep] = field(default_factory=list)
    cooling_recommendation: Optional[str] = None
    assumptions: list[Assumption] = field(default_factory=list)

    @property
    def gain_kwh(self) -> float:
        return self.optimised_annual_kwh - self.baseline_annual_kwh

    @property
    def gain_fraction(self) -> float:
        return self.gain_kwh / self.baseline_annual_kwh if self.baseline_annual_kwh else float("nan")

    def summary(self) -> str:
        lines = [
            f"BASELINE:  {self.baseline_annual_kwh:,.0f} kWh/year",
            f"OPTIMISED: {self.optimised_annual_kwh:,.0f} kWh/year",
            f"GAIN:      {self.gain_kwh:+,.0f} kWh/year ({self.gain_fraction:+.1%})",
            "",
            "Contribution by lever:",
        ]
        for step in self.steps:
            lines.append(f"  {step.name:24s} {step.gain_kwh:+9,.0f} kWh  -> {step.parameters_changed}")
        if self.cooling_recommendation:
            lines.append(f"\nCooling: {self.cooling_recommendation}")
        return "\n".join(lines)


def optimise_system(
    system: SystemConfig,
    weather: WeatherSeries,
    energy_value_eur_per_kwh: float = 0.30,
    tracking_cost_assumptions: TrackingCostAssumptions = TrackingCostAssumptions(),
    optimise_tracking: bool = True,
) -> SystemOptimisationReport:
    baseline_state = run_simulation(system, weather)
    baseline_kwh = baseline_state.annual_ac_kwh

    current = system.model_copy(deep=True)
    steps: list[OptimisationStep] = []
    assumptions: list[Assumption] = []

    # 1. Tilt
    kwh_before = run_simulation(current, weather).annual_ac_kwh
    tilt_result = optimise_tilt(current, weather)
    current = current.model_copy(update={"tilt_deg": tilt_result.best_parameters["tilt_deg"]})
    kwh_after = run_simulation(current, weather).annual_ac_kwh
    steps.append(OptimisationStep("tilt", kwh_before, kwh_after, tilt_result.best_parameters))
    assumptions += tilt_result.assumptions

    # 2. Azimuth
    kwh_before = kwh_after
    azimuth_result = optimise_azimuth(current, weather)
    current = current.model_copy(update={"azimuth_deg": azimuth_result.best_parameters["azimuth_deg"]})
    kwh_after = run_simulation(current, weather).annual_ac_kwh
    steps.append(OptimisationStep("azimuth", kwh_before, kwh_after, azimuth_result.best_parameters))
    assumptions += azimuth_result.assumptions

    # 3. Cleaning policy (soiling)
    kwh_before = kwh_after
    best_policy, best_policy_kwh = current.cleaning_policy, kwh_before
    for policy in (CleaningPolicy.NONE, CleaningPolicy.MONTHLY, CleaningPolicy.QUARTERLY, CleaningPolicy.WEATHER_BASED):
        trial = current.model_copy(update={"cleaning_policy": policy})
        kwh = run_simulation(trial, weather).annual_ac_kwh
        if kwh > best_policy_kwh:
            best_policy, best_policy_kwh = policy, kwh
    current = current.model_copy(update={"cleaning_policy": best_policy})
    steps.append(
        OptimisationStep(
            "cleaning_policy",
            kwh_before,
            best_policy_kwh,
            {"cleaning_policy": best_policy.value},
            note="Energy-only comparison; run photovoltaic.soiling.optimise_cleaning_policy "
            "for the labour/water-cost-aware threshold.",
        )
    )

    # 4. Tracking mode (cost-aware: only adopted if net annual value is positive)
    kwh_before = best_policy_kwh
    if optimise_tracking:
        tracking_df = compare_tracking_options(current, weather, tracking_cost_assumptions, energy_value_eur_per_kwh)
        best_mode = tracking_df["extra_annual_value_eur"].idxmax()
        if tracking_df.loc[best_mode, "extra_annual_value_eur"] > 0 and best_mode != "fixed":
            current = current.model_copy(update={"tracking_mode": best_mode})
            kwh_after = run_simulation(current, weather).annual_ac_kwh
            steps.append(
                OptimisationStep(
                    "tracking",
                    kwh_before,
                    kwh_after,
                    {"tracking_mode": best_mode},
                    note=f"payback {tracking_df.loc[best_mode, 'simple_payback_years']:.1f} years "
                    f"at {energy_value_eur_per_kwh} EUR/kWh",
                )
            )
        else:
            kwh_after = kwh_before
            steps.append(
                OptimisationStep(
                    "tracking", kwh_before, kwh_after, {"tracking_mode": "fixed"}, note="no tracking mode paid back; kept fixed-tilt"
                )
            )

    # 5. MPPT tracking-efficiency assumption
    kwh_before = kwh_after
    mppt_result = recommend_mppt_algorithm(current, weather)
    recommended_eff = mppt_result.optimised_value
    if recommended_eff > current.mppt_tracking_efficiency_fraction:
        current = current.model_copy(update={"mppt_tracking_efficiency_fraction": recommended_eff})
        kwh_after = run_simulation(current, weather).annual_ac_kwh
        steps.append(
            OptimisationStep(
                "mppt_algorithm", kwh_before, kwh_after, mppt_result.best_parameters, note="measured on the system's own cloudiest simulated day"
            )
        )
        assumptions += mppt_result.assumptions
    else:
        kwh_after = kwh_before

    optimised_kwh = kwh_after

    # 6. Cooling: informational only (not wired into the main energy pipeline's cost model),
    # reported as a recommendation rather than folded into best_system/optimised_annual_kwh.
    cooling_df = evaluate_cooling_scenarios(current, weather, energy_value_eur_per_kwh=energy_value_eur_per_kwh)
    best_cooling = cooling_df["net_value_gain_eur"].idxmax()
    cooling_note = (
        f"{best_cooling} maximises net value (+{cooling_df.loc[best_cooling, 'net_value_gain_eur']:.0f} EUR/year "
        f"after parasitic pump/fan consumption) -- not applied automatically, evaluate against real BOQ cost."
    )

    return SystemOptimisationReport(
        baseline_annual_kwh=baseline_kwh,
        optimised_annual_kwh=optimised_kwh,
        best_system=current,
        steps=steps,
        cooling_recommendation=cooling_note,
        assumptions=assumptions,
    )
