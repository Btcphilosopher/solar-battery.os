"""The orchestrator: wires every subsystem (sun -> irradiance -> panel ->
cell -> DC -> MPPT -> inverter -> AC) into one `run_simulation()` call and
produces a SimulationState with a full loss waterfall.

This module makes the fidelity/performance trade-off explicit: the annual
loop uses the *fast*, uniform-conditions DC power path (one single-diode MPP
solve per timestep, vectorised across the whole series) rather than
resolving the full bypass-diode/string-mismatch circuit every hour -- that
detailed circuit model lives in photovoltaic.array.simulate_array and is
used for single-condition studies (partial shading demos, layout
optimisation) instead. Manufacturing mismatch, soiling and MPPT tracking
loss are folded into the annual loop as their measured/typical loss
fractions rather than re-simulated from scratch at every timestep.
"""
from __future__ import annotations

from typing import Literal, Optional

import numpy as np
from pydantic import BaseModel, Field

from solaros.core.configuration import SimulationConfig
from solaros.core.state import LossWaterfall, SimulationState
from solaros.electrical.dc_bus import combine_dc_bus
from solaros.electrical.inverter import InverterParameters, convert_dc_to_ac
from solaros.electrical.losses import ac_wiring_loss_w
from solaros.geometry.orientation import OpticalProperties, angle_of_incidence_deg, effective_irradiance_w_m2
from solaros.geometry.site import Site
from solaros.geometry.tracking import dual_axis_tracking_pose, single_axis_tracking_pose
from solaros.photovoltaic.array import ArrayLayout, manufacturing_mismatch_loss_fraction, uniform_array_power_w
from solaros.photovoltaic.degradation import DegradationModel
from solaros.photovoltaic.module import Panel
from solaros.photovoltaic.soiling import CleaningPolicy, SoilingModel, cleaning_days_for_policy
from solaros.solar.atmosphere import pressure_corrected_air_mass, relative_air_mass
from solaros.solar.irradiance import apply_cloud_cover, clear_sky_irradiance, plane_of_array_irradiance
from solaros.solar.shading import Obstruction, combined_shading_fraction, obstruction_shading_fraction, row_to_row_shaded_fraction
from solaros.solar.spectrum import spectral_mismatch_factor
from solaros.solar.sun_position import solar_position
from solaros.photovoltaic.temperature import cell_temperature_from_module_c, faiman_module_temperature_c
from solaros.weather.clouds import cloud_transmittance
from solaros.weather.weather import WeatherSeries

TrackingMode = Literal["fixed", "single_axis", "dual_axis"]


class SystemConfig(BaseModel):
    """Everything that describes one physical, buildable PV installation."""

    model_config = {"arbitrary_types_allowed": True}

    site: Site
    panel: Panel
    layout: ArrayLayout
    inverter: InverterParameters

    tracking_mode: TrackingMode = "fixed"
    tilt_deg: float = 30.0
    azimuth_deg: float = 180.0  # equator-facing default (south, N hemisphere)
    axis_azimuth_deg: float = 0.0  # for single-axis trackers
    ground_coverage_ratio: float = 0.4
    row_azimuth_deg: float = 180.0
    apply_row_to_row_shading: bool = True
    single_axis_backtrack: bool = True

    mounting: str = "open_rack"  # -> photovoltaic.temperature.FAIMAN_COEFFICIENTS key
    optics: OpticalProperties = Field(default_factory=OpticalProperties)
    obstructions: list[Obstruction] = Field(default_factory=list)

    soiling: SoilingModel = Field(default_factory=SoilingModel)
    cleaning_policy: CleaningPolicy = CleaningPolicy.QUARTERLY
    degradation: DegradationModel = Field(default_factory=DegradationModel)
    system_age_years: float = 0.0

    manufacturing_power_tolerance_pct: float = 1.5
    mppt_tracking_efficiency_fraction: float = 0.995
    linke_turbidity: float = 3.0

    dc_cable_one_way_length_m: float = 15.0
    dc_cable_cross_section_mm2: float = 6.0
    ac_cable_one_way_length_m: float = 25.0
    ac_cable_cross_section_mm2: float = 10.0


def _panel_pose(system: SystemConfig, sun_elevation_deg: np.ndarray, sun_azimuth_deg: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    n = len(sun_elevation_deg)
    if system.tracking_mode == "fixed":
        return np.full(n, system.tilt_deg), np.full(n, system.azimuth_deg)
    if system.tracking_mode == "dual_axis":
        pose = dual_axis_tracking_pose(sun_elevation_deg, sun_azimuth_deg)
        return pose.tilt_deg, pose.azimuth_deg
    if system.tracking_mode == "single_axis":
        pose = single_axis_tracking_pose(
            sun_elevation_deg,
            sun_azimuth_deg,
            axis_azimuth_deg=system.axis_azimuth_deg,
            backtrack=system.single_axis_backtrack,
            ground_coverage_ratio=system.ground_coverage_ratio,
        )
        return pose.tilt_deg, pose.azimuth_deg
    raise ValueError(f"unknown tracking_mode {system.tracking_mode!r}")


def run_simulation(
    system: SystemConfig,
    weather: WeatherSeries,
    config: Optional[SimulationConfig] = None,
) -> SimulationState:
    config = config or SimulationConfig()
    timestamps = weather.timestamps
    n = len(timestamps)
    step_hours = float((timestamps[1] - timestamps[0]).total_seconds() / 3600.0) if n > 1 else 1.0

    day_of_year = timestamps.dayofyear.to_numpy().astype(float)
    sun = solar_position(timestamps, system.site.latitude_deg, system.site.longitude_deg)

    tilt_deg, azimuth_deg = _panel_pose(system, sun.elevation_deg, sun.azimuth_deg)
    aoi_deg = angle_of_incidence_deg(sun.elevation_deg, sun.azimuth_deg, tilt_deg, azimuth_deg)

    pressure_kpa = system.site.air_pressure_kpa()
    clear_sky = clear_sky_irradiance(day_of_year, sun.elevation_deg, pressure_kpa, system.linke_turbidity)
    transmittance = cloud_transmittance(weather.cloud_cover_fraction)
    all_sky = apply_cloud_cover(clear_sky, transmittance)

    poa_irradiance = plane_of_array_irradiance(all_sky, aoi_deg, tilt_deg, albedo=system.site.albedo)
    effective_irradiance = effective_irradiance_w_m2(poa_irradiance, aoi_deg, system.optics)

    air_mass = pressure_corrected_air_mass(relative_air_mass(90.0 - sun.elevation_deg), pressure_kpa)
    spectral_factor = spectral_mismatch_factor(air_mass, system.panel.cell.technology)
    effective_irradiance = effective_irradiance * spectral_factor

    if config.apply_shading:
        obstruction_frac = obstruction_shading_fraction(sun.azimuth_deg, sun.elevation_deg, system.obstructions)
        if system.apply_row_to_row_shading and system.tracking_mode != "dual_axis":
            row_frac = row_to_row_shaded_fraction(
                sun.elevation_deg, sun.azimuth_deg, system.row_azimuth_deg, tilt_deg, system.ground_coverage_ratio
            )
        else:
            row_frac = np.zeros(n)
        shade_fraction = combined_shading_fraction(obstruction_frac, row_frac)
    else:
        shade_fraction = np.zeros(n)
    shaded_irradiance = effective_irradiance * (1.0 - shade_fraction)

    module_temp_c = faiman_module_temperature_c(
        weather.ambient_temperature_c, shaded_irradiance, weather.wind_speed_m_s, system.mounting
    )
    cell_temp_c = cell_temperature_from_module_c(module_temp_c, shaded_irradiance)

    dc_power_w = uniform_array_power_w(system.panel, system.layout, shaded_irradiance, cell_temp_c)
    dc_power_w_at_25c = uniform_array_power_w(
        system.panel, system.layout, shaded_irradiance, np.full(n, 25.0)
    )
    # Not clipped at zero: on cold, sunny days real cell temperature can sit below the 25 degC
    # reference, in which case this is legitimately negative -- a thermal *gain* over STC, not a loss.
    thermal_loss_w = dc_power_w_at_25c - dc_power_w

    dc_power_after_mismatch = dc_power_w
    if config.apply_mismatch:
        mismatch_loss_frac = manufacturing_mismatch_loss_fraction(system.manufacturing_power_tolerance_pct)
        dc_power_after_mismatch = dc_power_w * (1.0 - mismatch_loss_frac)

    dc_power_after_soiling = dc_power_after_mismatch
    if config.apply_soiling:
        daily_rain = weather.daily_rainfall_mm().to_numpy()
        cleaning_days = cleaning_days_for_policy(system.cleaning_policy, system.soiling, daily_rain)
        daily_soiling_loss = system.soiling.simulate_daily_loss_fraction(daily_rain, cleaning_days)
        soiling_loss_by_step = np.repeat(daily_soiling_loss, int(np.ceil(n / len(daily_soiling_loss))))[:n]
        dc_power_after_soiling = dc_power_after_mismatch * (1.0 - soiling_loss_by_step)

    dc_power_after_degradation = dc_power_after_soiling
    if config.apply_degradation:
        capacity_fraction = system.degradation.remaining_capacity_fraction(np.full(n, system.system_age_years))
        dc_power_after_degradation = dc_power_after_soiling * capacity_fraction

    array_voltage_v = system.layout.modules_per_string * system.panel.cell.v_mp_v
    if config.apply_wiring_losses:
        dc_bus = combine_dc_bus(
            dc_power_after_degradation,
            np.full(n, array_voltage_v),
            system.dc_cable_one_way_length_m,
            system.dc_cable_cross_section_mm2,
        )
        net_dc_power_w = dc_bus.net_dc_power_w
        dc_wiring_loss_w = dc_bus.wiring_loss_w
    else:
        net_dc_power_w = dc_power_after_degradation
        dc_wiring_loss_w = np.zeros(n)

    net_dc_power_w = net_dc_power_w * system.mppt_tracking_efficiency_fraction
    mppt_loss_w = net_dc_power_w / max(system.mppt_tracking_efficiency_fraction, 1e-9) - net_dc_power_w

    inverter_out = convert_dc_to_ac(net_dc_power_w, system.inverter)

    ac_positive = np.maximum(inverter_out.ac_power_w, 0.0)
    ac_wiring_loss = ac_wiring_loss_w(ac_positive, one_way_length_m=system.ac_cable_one_way_length_m, cross_section_mm2=system.ac_cable_cross_section_mm2) if config.apply_wiring_losses else np.zeros(n)
    net_ac_power_w = ac_positive - ac_wiring_loss
    standby_draw_w = np.maximum(-inverter_out.ac_power_w, 0.0)
    net_ac_power_w = net_ac_power_w - standby_draw_w  # parasitic night consumption nets against delivered energy

    def kwh(power_w: np.ndarray) -> float:
        return float(np.sum(power_w) * step_hours / 1000.0)

    total_module_area_m2 = system.layout.total_modules * system.panel.area_m2
    # Defined as a residual (DC in - AC out), not conversion_loss+clipping_loss alone, so that
    # any DC energy the inverter simply never starts up for (below its minimum threshold) is
    # still accounted for -- the waterfall must telescope exactly to net_ac_kwh.
    inverter_loss_kwh = kwh(net_dc_power_w) - kwh(ac_positive)
    losses = LossWaterfall(
        solar_resource_kwh=kwh(poa_irradiance * total_module_area_m2),
        optical_loss_kwh=kwh((poa_irradiance - effective_irradiance) * total_module_area_m2),
        shading_loss_kwh=kwh((effective_irradiance - shaded_irradiance) * total_module_area_m2),
        conversion_efficiency_loss_kwh=kwh(shaded_irradiance * total_module_area_m2) - kwh(dc_power_w_at_25c),
        thermal_loss_kwh=kwh(thermal_loss_w),
        mismatch_loss_kwh=kwh(dc_power_w - dc_power_after_mismatch),
        soiling_loss_kwh=kwh(dc_power_after_mismatch - dc_power_after_soiling),
        degradation_loss_kwh=kwh(dc_power_after_soiling - dc_power_after_degradation),
        dc_wiring_loss_kwh=kwh(dc_wiring_loss_w),
        mppt_loss_kwh=kwh(mppt_loss_w),
        inverter_loss_kwh=inverter_loss_kwh,
        ac_wiring_loss_kwh=kwh(ac_wiring_loss) + kwh(standby_draw_w),
        net_ac_kwh=kwh(net_ac_power_w),
    )

    return SimulationState(
        timestamps=timestamps,
        step_hours=step_hours,
        poa_irradiance_w_m2=poa_irradiance,
        cell_temperature_c=cell_temp_c,
        dc_power_w=dc_power_after_degradation,
        ac_power_w=net_ac_power_w,
        losses=losses,
        extra={
            "sun_elevation_deg": sun.elevation_deg,
            "sun_azimuth_deg": sun.azimuth_deg,
            "tilt_deg": tilt_deg,
            "panel_azimuth_deg": azimuth_deg,
            "aoi_deg": aoi_deg,
            "shade_fraction": shade_fraction,
            "shaded_irradiance_w_m2": shaded_irradiance,
            "module_temperature_c": module_temp_c,
            "degradation_capacity_fraction": (
                system.degradation.remaining_capacity_fraction(np.full(n, system.system_age_years)) if config.apply_degradation else np.ones(n)
            ),
        },
    )
