"""Time-stepping utilities: build the timestamp grid a simulation runs over."""
from __future__ import annotations

import numpy as np
import pandas as pd

from solaros.core.configuration import TimeResolution


def build_time_index(
    year: int,
    resolution: TimeResolution = TimeResolution.HOURLY,
    timezone: str = "UTC",
) -> pd.DatetimeIndex:
    """Return a timezone-aware DatetimeIndex spanning Jan 1 00:00 to Dec 31 23:59 of `year`."""
    freq = {"1h": "1h", "15min": "15min", "5min": "5min", "1min": "1min"}[resolution.value]
    start = pd.Timestamp(year=year, month=1, day=1, tz=timezone)
    end = pd.Timestamp(year=year, month=12, day=31, hour=23, minute=59, tz=timezone)
    return pd.date_range(start=start, end=end, freq=freq)


def step_hours(resolution: TimeResolution) -> float:
    """Duration of one simulation step, in hours (needed to integrate power -> energy)."""
    return resolution.minutes / 60.0


def day_of_year(index: pd.DatetimeIndex) -> np.ndarray:
    return index.dayofyear.to_numpy()


def fractional_hour(index: pd.DatetimeIndex) -> np.ndarray:
    """Local solar-relevant hour-of-day as a float, e.g. 13.5 == 13:30."""
    return (index.hour + index.minute / 60.0 + index.second / 3600.0).to_numpy()
