"""Cross-cutting configuration models shared by every SolarOS subsystem.

All physical quantities carry explicit units in their field names
(``_w_m2``, ``_deg_c``, ``_kwh`` ...). No bare ``power`` or ``temp``.
"""
from __future__ import annotations

from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


class ModelBasis(str, Enum):
    """Provenance tag every simulated/optimised quantity must carry (spec #37).

    PHYSICAL   - derived from first-principles physics (e.g. single-diode equation).
    SIMPLIFIED - a physically-motivated but reduced-order approximation.
    EMPIRICAL  - fit to reference datasets; needs calibration to a real site.
    USER_DATA  - taken verbatim from user-supplied measurements/config.
    """

    PHYSICAL = "physical"
    SIMPLIFIED = "simplified"
    EMPIRICAL = "empirical"
    USER_DATA = "user_supplied"


class TimeResolution(str, Enum):
    HOURLY = "1h"
    FIFTEEN_MIN = "15min"
    FIVE_MIN = "5min"
    ONE_MIN = "1min"

    @property
    def minutes(self) -> int:
        return {"1h": 60, "15min": 15, "5min": 5, "1min": 1}[self.value]


class Assumption(BaseModel):
    """A single documented assumption behind a computed result."""

    name: str
    value: str
    basis: ModelBasis
    note: Optional[str] = None


class EconomicAssumptions(BaseModel):
    electricity_price_eur_per_kwh: float = Field(0.30, gt=0)
    export_price_eur_per_kwh: float = Field(0.08, ge=0)
    discount_rate_fraction: float = Field(0.05, ge=0, lt=1)
    om_cost_eur_per_kwp_year: float = Field(15.0, ge=0)
    system_lifetime_years: int = Field(25, gt=0)


class SimulationConfig(BaseModel):
    """Top level knobs for a single simulation run."""

    resolution: TimeResolution = TimeResolution.HOURLY
    year: int = 2024
    apply_shading: bool = True
    apply_soiling: bool = True
    apply_mismatch: bool = True
    apply_degradation: bool = True
    apply_wiring_losses: bool = True
    random_seed: Optional[int] = None


class Scenario(BaseModel):
    """A named, reproducible bundle of configuration choices to compare."""

    name: str
    description: str = ""
    overrides: dict = Field(default_factory=dict)


class OptimisationResult(BaseModel):
    """Standard shape returned by every optimiser in solaros.optimisation.*"""

    objective_name: str
    baseline_value: float
    optimised_value: float
    unit: str
    gain_absolute: float
    gain_fraction: float
    best_parameters: dict
    assumptions: list[Assumption] = Field(default_factory=list)

    @classmethod
    def from_values(
        cls,
        objective_name: str,
        baseline_value: float,
        optimised_value: float,
        unit: str,
        best_parameters: dict,
        assumptions: Optional[list[Assumption]] = None,
    ) -> "OptimisationResult":
        gain_absolute = optimised_value - baseline_value
        gain_fraction = gain_absolute / baseline_value if baseline_value else float("nan")
        return cls(
            objective_name=objective_name,
            baseline_value=baseline_value,
            optimised_value=optimised_value,
            unit=unit,
            gain_absolute=gain_absolute,
            gain_fraction=gain_fraction,
            best_parameters=best_parameters,
            assumptions=assumptions or [],
        )
