"""Container for the results of a simulation run, plus the standard summary metrics."""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd


@dataclass
class LossWaterfall:
    """Energy lost at each stage of the chain, in kWh, over the simulated period.

    Every stage is expressed relative to the stage above it so the numbers
    sum exactly to the gross-to-net waterfall used in visualisation.energy_waterfall.
    """

    solar_resource_kwh: float = 0.0
    optical_loss_kwh: float = 0.0
    shading_loss_kwh: float = 0.0
    conversion_efficiency_loss_kwh: float = 0.0
    """Energy not converted to DC electricity by the cell's photoelectric
    conversion (bandgap/recombination/fill-factor limits), evaluated at a
    fixed 25 degC reference so it isn't contaminated by real-world heat."""
    thermal_loss_kwh: float = 0.0
    mismatch_loss_kwh: float = 0.0
    soiling_loss_kwh: float = 0.0
    degradation_loss_kwh: float = 0.0
    dc_wiring_loss_kwh: float = 0.0
    mppt_loss_kwh: float = 0.0
    inverter_loss_kwh: float = 0.0
    ac_wiring_loss_kwh: float = 0.0
    net_ac_kwh: float = 0.0

    def as_dict(self) -> dict:
        return self.__dict__.copy()


@dataclass
class SimulationState:
    """Time series output of a Simulation run, sampled on `timestamps`."""

    timestamps: pd.DatetimeIndex
    step_hours: float

    poa_irradiance_w_m2: np.ndarray
    cell_temperature_c: np.ndarray
    dc_power_w: np.ndarray
    ac_power_w: np.ndarray

    losses: LossWaterfall = field(default_factory=LossWaterfall)
    extra: dict = field(default_factory=dict)

    def energy_kwh(self, power_w: np.ndarray) -> float:
        return float(np.sum(power_w) * self.step_hours / 1000.0)

    @property
    def annual_ac_kwh(self) -> float:
        return self.energy_kwh(self.ac_power_w)

    @property
    def annual_dc_kwh(self) -> float:
        return self.energy_kwh(self.dc_power_w)

    def capacity_factor(self, rated_power_w: float) -> float:
        hours = len(self.timestamps) * self.step_hours
        max_possible_kwh = rated_power_w * hours / 1000.0
        return self.annual_ac_kwh / max_possible_kwh if max_possible_kwh else float("nan")

    @property
    def peak_ac_power_w(self) -> float:
        return float(np.max(self.ac_power_w)) if len(self.ac_power_w) else 0.0

    def _series(self, power_w: np.ndarray) -> pd.Series:
        return pd.Series(power_w, index=self.timestamps)

    def daily_energy_kwh(self) -> pd.Series:
        return self._series(self.ac_power_w).resample("D").sum() * self.step_hours / 1000.0

    def monthly_energy_kwh(self) -> pd.Series:
        return self._series(self.ac_power_w).resample("ME").sum() * self.step_hours / 1000.0

    def summary(self, rated_power_w: float) -> dict:
        return {
            "annual_ac_kwh": self.annual_ac_kwh,
            "annual_dc_kwh": self.annual_dc_kwh,
            "capacity_factor": self.capacity_factor(rated_power_w),
            "peak_ac_power_w": self.peak_ac_power_w,
            "specific_yield_kwh_per_kwp": self.annual_ac_kwh / (rated_power_w / 1000.0) if rated_power_w else float("nan"),
        }
