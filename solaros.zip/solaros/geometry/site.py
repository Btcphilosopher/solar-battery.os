"""Physical site description: where the array is, and how much room/money it has."""
from __future__ import annotations

from pydantic import BaseModel, Field


class Site(BaseModel):
    """A geographic installation site."""

    name: str = "site"
    latitude_deg: float = Field(..., ge=-90, le=90)
    longitude_deg: float = Field(..., ge=-180, le=180)
    elevation_m: float = 0.0
    timezone: str = "UTC"
    albedo: float = Field(0.2, ge=0, le=1, description="ground reflectance, dimensionless")
    available_area_m2: float | None = Field(None, gt=0)
    budget_eur: float | None = Field(None, gt=0)
    ambient_pressure_kpa: float = Field(101.325, gt=0)

    def air_pressure_kpa(self) -> float:
        """Barometric pressure at site elevation, standard atmosphere approximation."""
        return 101.325 * (1 - 2.25577e-5 * self.elevation_m) ** 5.25588
