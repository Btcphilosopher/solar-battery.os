"""Panel orientation: angle of incidence and the optical losses that follow
from the sun not being perpendicular to the glass.

Model basis: PHYSICAL (AOI geometry is exact spherical trigonometry) with an
EMPIRICAL incidence-angle modifier (ASHRAE model, Souka & Safwat 1966).
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


def angle_of_incidence_deg(
    sun_elevation_deg: np.ndarray,
    sun_azimuth_deg: np.ndarray,
    panel_tilt_deg: np.ndarray,
    panel_azimuth_deg: np.ndarray,
) -> np.ndarray:
    """Angle between the sun's rays and the panel's surface normal (0 = perpendicular)."""
    elev = np.radians(sun_elevation_deg)
    tilt = np.radians(panel_tilt_deg)
    rel_az = np.radians(sun_azimuth_deg - panel_azimuth_deg)

    cos_aoi = np.cos(elev) * np.sin(tilt) * np.cos(rel_az) + np.sin(elev) * np.cos(tilt)
    cos_aoi = np.clip(cos_aoi, -1.0, 1.0)
    aoi = np.degrees(np.arccos(cos_aoi))
    # Sun below the panel's own horizon (elevation <=0) => no direct beam at all.
    return np.where(sun_elevation_deg <= 0, 90.0, aoi)


@dataclass
class OpticalProperties:
    """Configurable glazing optics for the optical-loss model (spec #8)."""

    normal_transmittance: float = 0.98  # glass transmission + AR coating at AOI=0
    ashrae_b0: float = 0.05  # incidence-angle-modifier coefficient


def incidence_angle_modifier(aoi_deg: np.ndarray, b0: float = 0.05) -> np.ndarray:
    """ASHRAE incidence-angle modifier: fraction of normal-incidence transmission
    retained as AOI grows, capturing increased reflection at glancing angles.
    """
    aoi = np.clip(aoi_deg, 0.0, 89.999)
    cos_aoi = np.cos(np.radians(aoi))
    iam = 1.0 - b0 * (1.0 / cos_aoi - 1.0)
    iam = np.where(aoi_deg >= 90.0, 0.0, iam)
    return np.clip(iam, 0.0, 1.0)


def effective_irradiance_w_m2(
    poa_irradiance_w_m2: np.ndarray,
    aoi_deg: np.ndarray,
    optics: OpticalProperties = OpticalProperties(),
) -> np.ndarray:
    """POA irradiance actually reaching the cells, after glazing transmission and AOI reflection loss."""
    iam = incidence_angle_modifier(aoi_deg, optics.ashrae_b0)
    return poa_irradiance_w_m2 * optics.normal_transmittance * iam
