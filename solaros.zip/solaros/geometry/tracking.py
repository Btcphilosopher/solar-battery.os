"""Sun-tracking geometry: dual-axis (always normal to the sun) and horizontal
single-axis (N-S axis, rotates E-W), with optional backtracking to avoid
row-to-row self-shading at low sun angles.

Model basis: PHYSICAL for true-tracking geometry; SIMPLIFIED for the
backtracking limit (a critical-angle clip derived from the Lorenzo et al.
2011 backtracking condition, rather than the full continuous solution).
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class TrackerPose:
    tilt_deg: np.ndarray
    azimuth_deg: np.ndarray
    rotation_deg: np.ndarray  # signed rotation about the tracker axis, backtracking-limited


def dual_axis_tracking_pose(
    sun_elevation_deg: np.ndarray,
    sun_azimuth_deg: np.ndarray,
    max_tilt_deg: float = 90.0,
) -> TrackerPose:
    """A dual-axis tracker always points straight at the sun (AOI == 0), within mechanical limits."""
    tilt = np.clip(90.0 - np.asarray(sun_elevation_deg, dtype=float), 0.0, max_tilt_deg)
    azimuth = np.asarray(sun_azimuth_deg, dtype=float)
    return TrackerPose(tilt_deg=tilt, azimuth_deg=azimuth, rotation_deg=tilt)


def single_axis_tracking_pose(
    sun_elevation_deg: np.ndarray,
    sun_azimuth_deg: np.ndarray,
    axis_azimuth_deg: float = 0.0,
    max_rotation_deg: float = 60.0,
    backtrack: bool = True,
    ground_coverage_ratio: float = 0.4,
) -> TrackerPose:
    """Horizontal single-axis tracker rotation, with mechanical limit and optional backtracking."""
    elev = np.radians(np.clip(sun_elevation_deg, 1e-6, 90.0))
    rel_az = np.radians(np.asarray(sun_azimuth_deg, dtype=float) - axis_azimuth_deg)
    zenith = np.pi / 2 - elev

    true_rotation_deg = np.degrees(np.arctan2(np.sin(zenith) * np.sin(rel_az), np.cos(zenith)))
    true_rotation_deg = np.clip(true_rotation_deg, -max_rotation_deg, max_rotation_deg)

    if backtrack and ground_coverage_ratio > 0:
        gcr = min(ground_coverage_ratio, 1.0)
        temp = np.clip(gcr * np.abs(np.cos(np.radians(true_rotation_deg))), 0.0, 1.0)
        critical_angle_deg = np.degrees(np.arccos(temp))
        rotation_deg = np.where(
            np.abs(true_rotation_deg) < critical_angle_deg,
            true_rotation_deg,
            np.sign(true_rotation_deg) * critical_angle_deg,
        )
    else:
        rotation_deg = true_rotation_deg

    rotation_deg = np.where(sun_elevation_deg <= 0, 0.0, rotation_deg)

    tilt_deg = np.abs(rotation_deg)
    azimuth_deg = np.where(
        rotation_deg >= 0,
        (axis_azimuth_deg + 90.0) % 360.0,
        (axis_azimuth_deg - 90.0) % 360.0,
    )
    return TrackerPose(tilt_deg=tilt_deg, azimuth_deg=azimuth_deg, rotation_deg=rotation_deg)
