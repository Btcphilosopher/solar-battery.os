"""What a kWh is actually worth -- which is not one number. Self-consumed
energy avoids a retail purchase; exported energy earns a (usually lower)
feed-in price. This module is the concrete implementation of spec #31's
"MORE ENERGY GENERATED != MORE ENERGY VALUED".
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd


@dataclass
class FlatTariff:
    price_eur_per_kwh: float

    def price_at(self, timestamps: pd.DatetimeIndex) -> np.ndarray:
        return np.full(len(timestamps), self.price_eur_per_kwh)


@dataclass
class TimeOfUseTariff:
    peak_price_eur_per_kwh: float
    offpeak_price_eur_per_kwh: float
    peak_hours: tuple[int, int] = (8, 20)  # [start, end)

    def price_at(self, timestamps: pd.DatetimeIndex) -> np.ndarray:
        hour = timestamps.hour.to_numpy()
        is_peak = (hour >= self.peak_hours[0]) & (hour < self.peak_hours[1])
        return np.where(is_peak, self.peak_price_eur_per_kwh, self.offpeak_price_eur_per_kwh)


Tariff = FlatTariff | TimeOfUseTariff


def gross_generation_value_eur(
    ac_power_w: np.ndarray,
    step_hours: float,
    timestamps: pd.DatetimeIndex,
    tariff: Tariff,
) -> float:
    """Value if every kWh generated could be sold/used at the tariff price --
    "MORE ENERGY GENERATED" valued naively, ignoring self-consumption/export split."""
    energy_kwh = np.maximum(ac_power_w, 0.0) * step_hours / 1000.0
    return float(np.sum(energy_kwh * tariff.price_at(timestamps)))


def delivered_value_eur(
    ac_power_w: np.ndarray,
    step_hours: float,
    timestamps: pd.DatetimeIndex,
    retail_tariff: Tariff,
    export_price_eur_per_kwh: float,
    load_power_w: np.ndarray | None = None,
) -> dict:
    """"MORE ENERGY VALUED": split generation into self-consumed (avoids a
    retail purchase, valued at the retail tariff) and exported (valued at
    the usually-lower export/feed-in price). Without a load profile, assumes
    everything is exported -- the conservative case.
    """
    generation_kwh = np.maximum(ac_power_w, 0.0) * step_hours / 1000.0
    retail_price = retail_tariff.price_at(timestamps)

    if load_power_w is None:
        self_consumed_kwh = np.zeros_like(generation_kwh)
        exported_kwh = generation_kwh
    else:
        load_kwh = np.maximum(load_power_w, 0.0) * step_hours / 1000.0
        self_consumed_kwh = np.minimum(generation_kwh, load_kwh)
        exported_kwh = generation_kwh - self_consumed_kwh

    self_consumed_value_eur = float(np.sum(self_consumed_kwh * retail_price))
    exported_value_eur = float(np.sum(exported_kwh * export_price_eur_per_kwh))

    return {
        "self_consumed_kwh": float(np.sum(self_consumed_kwh)),
        "exported_kwh": float(np.sum(exported_kwh)),
        "self_consumed_value_eur": self_consumed_value_eur,
        "exported_value_eur": exported_value_eur,
        "total_value_eur": self_consumed_value_eur + exported_value_eur,
        "average_value_eur_per_kwh": (self_consumed_value_eur + exported_value_eur) / max(float(np.sum(generation_kwh)), 1e-9),
    }


def marginal_kwh_value_eur(
    extra_ac_power_w: np.ndarray,
    step_hours: float,
    timestamps: pd.DatetimeIndex,
    retail_tariff: Tariff,
    export_price_eur_per_kwh: float,
    existing_load_power_w: np.ndarray,
    existing_generation_power_w: np.ndarray,
) -> float:
    """Value of an *incremental* block of generation (e.g. from an
    optimisation upgrade) given what the system already produces/consumes --
    the marginal kWh is worth less than the average once self-consumption
    is already saturated by existing_generation_power_w.
    """
    load_kwh = np.maximum(existing_load_power_w, 0.0) * step_hours / 1000.0
    existing_gen_kwh = np.maximum(existing_generation_power_w, 0.0) * step_hours / 1000.0
    extra_kwh = np.maximum(extra_ac_power_w, 0.0) * step_hours / 1000.0

    remaining_load_headroom_kwh = np.maximum(load_kwh - existing_gen_kwh, 0.0)
    marginal_self_consumed_kwh = np.minimum(extra_kwh, remaining_load_headroom_kwh)
    marginal_exported_kwh = extra_kwh - marginal_self_consumed_kwh

    retail_price = retail_tariff.price_at(timestamps)
    value = float(np.sum(marginal_self_consumed_kwh * retail_price)) + float(marginal_exported_kwh.sum() * export_price_eur_per_kwh)
    return value
