"""Whole-life economics: LCOE, NPV, and payback, degradation-aware."""
from __future__ import annotations

import numpy as np

from solaros.economics.production import annual_production_series_kwh
from solaros.photovoltaic.degradation import DegradationModel


def lcoe_eur_per_kwh(
    capex_eur: float,
    annual_om_eur: float,
    year1_annual_ac_kwh: float,
    degradation: DegradationModel,
    discount_rate_fraction: float,
    lifetime_years: int,
) -> float:
    """Levelised Cost of Electricity: discounted lifetime cost / discounted lifetime energy."""
    years = np.arange(1, lifetime_years + 1)
    discount_factor = (1.0 + discount_rate_fraction) ** years

    discounted_costs = capex_eur + float(np.sum(annual_om_eur / discount_factor))
    energy_series_kwh = annual_production_series_kwh(year1_annual_ac_kwh, degradation, lifetime_years)
    discounted_energy_kwh = float(np.sum(energy_series_kwh / discount_factor))

    return discounted_costs / discounted_energy_kwh if discounted_energy_kwh > 0 else float("inf")


def npv_eur(
    capex_eur: float,
    annual_cashflow_eur: np.ndarray,
    discount_rate_fraction: float,
) -> float:
    years = np.arange(1, len(annual_cashflow_eur) + 1)
    discount_factor = (1.0 + discount_rate_fraction) ** years
    return float(-capex_eur + np.sum(annual_cashflow_eur / discount_factor))


def simple_payback_years(capex_eur: float, year1_annual_cashflow_eur: float) -> float:
    return capex_eur / year1_annual_cashflow_eur if year1_annual_cashflow_eur > 0 else float("inf")


def discounted_payback_years(
    capex_eur: float,
    annual_cashflow_eur: np.ndarray,
    discount_rate_fraction: float,
) -> float | None:
    years = np.arange(1, len(annual_cashflow_eur) + 1)
    discounted = annual_cashflow_eur / (1.0 + discount_rate_fraction) ** years
    cumulative = np.cumsum(discounted)
    crossing = np.argmax(cumulative >= capex_eur)
    if cumulative[crossing] < capex_eur:
        return None  # never pays back within the given horizon
    prior_cumulative = cumulative[crossing - 1] if crossing > 0 else 0.0
    fraction_into_year = (capex_eur - prior_cumulative) / discounted[crossing]
    return float(years[crossing] - 1 + fraction_into_year)


def annual_cashflow_series_eur(
    year1_annual_ac_kwh: float,
    energy_value_eur_per_kwh: float,
    annual_om_eur: float,
    degradation: DegradationModel,
    lifetime_years: int,
) -> np.ndarray:
    energy_series_kwh = annual_production_series_kwh(year1_annual_ac_kwh, degradation, lifetime_years)
    return energy_series_kwh * energy_value_eur_per_kwh - annual_om_eur
