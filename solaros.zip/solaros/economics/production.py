"""Turn a single simulated year into a full-lifetime production forecast,
degradation included -- the input every downstream economic calculation needs.
"""
from __future__ import annotations

import numpy as np

from solaros.core.state import SimulationState
from solaros.photovoltaic.degradation import DegradationModel


def annual_production_series_kwh(
    year1_annual_ac_kwh: float,
    degradation: DegradationModel,
    lifetime_years: int,
) -> np.ndarray:
    """Year-by-year AC energy over the system's life, year 1 measured, the
    rest projected via the degradation model's remaining-capacity curve.
    """
    years = np.arange(1, lifetime_years + 1)
    capacity_fraction = degradation.remaining_capacity_fraction(years - 0.5)  # mid-year average
    return year1_annual_ac_kwh * capacity_fraction


def production_summary(state: SimulationState, rated_power_w: float) -> dict:
    return {
        **state.summary(rated_power_w),
        "monthly_kwh": state.monthly_energy_kwh().to_dict(),
    }
