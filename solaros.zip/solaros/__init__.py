"""SolarOS: a computational laboratory for photovoltaic design, installation,
control and optimisation.

    Do not pretend to create more solar energy. Recover more of the
    available solar energy by reducing avoidable losses and optimising
    the entire photovoltaic system.

Quickstart:

    from solaros.geometry.site import Site
    from solaros.photovoltaic.module import get_preset
    from solaros.photovoltaic.array import ArrayLayout
    from solaros.electrical.inverter import InverterParameters
    from solaros.core.simulation import SystemConfig
    from solaros.simulation.year import simulate_year
    from solaros.optimise import optimise_system
    from solaros.weather.weather import generate_synthetic_weather
    from solaros.core.clock import build_time_index
    from solaros.core.configuration import TimeResolution

    site = Site(name="my-roof", latitude_deg=52.5, longitude_deg=13.4, timezone="UTC")
    system = SystemConfig(
        site=site,
        panel=get_preset("mono-si"),
        layout=ArrayLayout(modules_per_string=20, strings_parallel=5),
        inverter=InverterParameters(rated_ac_power_w=35_000),
        tilt_deg=35, azimuth_deg=180,
    )

    state = simulate_year(system)
    print(state.summary(system.panel.rated_power_w * system.layout.total_modules))

    weather = generate_synthetic_weather(build_time_index(2024, TimeResolution.HOURLY, "UTC"))
    report = optimise_system(system, weather)
    print(report.summary())

See README.md for the full module map and the physical model behind each
subsystem.
"""

__version__ = "0.1.0"
