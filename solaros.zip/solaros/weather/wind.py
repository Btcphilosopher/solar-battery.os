"""Wind speed: affects convective cooling of the panel (photovoltaic.temperature).

Model basis: EMPIRICAL/statistical. Synthetic wind is drawn from a Weibull
distribution (the standard wind-resource statistical model) with a mild
daytime-thermal-mixing boost; it has no spatial or synoptic structure.
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def synthetic_wind_speed_m_s(
    timestamps: pd.DatetimeIndex,
    mean_speed_m_s: float = 3.5,
    weibull_shape: float = 2.0,
    daytime_boost_m_s: float = 1.0,
    random_seed: int | None = None,
) -> np.ndarray:
    rng = np.random.default_rng(random_seed)
    # Weibull(shape, scale) has mean = scale * Gamma(1 + 1/shape); invert for the requested mean.
    from math import gamma

    scale = mean_speed_m_s / gamma(1 + 1.0 / weibull_shape)
    base = rng.weibull(weibull_shape, size=len(timestamps)) * scale

    hour = (timestamps.hour + timestamps.minute / 60.0).to_numpy()
    daytime_factor = np.clip(np.sin(np.pi * (hour - 6) / 12.0), 0.0, 1.0)  # thermal mixing peaks midday
    return base + daytime_boost_m_s * daytime_factor
