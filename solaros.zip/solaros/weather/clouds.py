"""Cloud cover: fraction of sky covered, and the irradiance transmittance
that follows from it. Cloud *shadows* (fast-moving, spatially local
transients) are a special case of this same time series at high temporal
resolution, not a separate spatial mechanism.

Model basis: EMPIRICAL. Kasten & Czeplak (1980) cloud-attenuation curve for
transmittance; a mean-reverting random walk for synthetic cloud cover, which
gives realistic persistence (clouds don't teleport) without claiming to
forecast anything.
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def cloud_transmittance(cloud_cover_fraction: np.ndarray) -> np.ndarray:
    """All-sky / clear-sky irradiance ratio as a function of cloud cover (Kasten & Czeplak 1980)."""
    cc = np.clip(np.asarray(cloud_cover_fraction, dtype=float), 0.0, 1.0)
    return np.clip(1.0 - 0.75 * cc**3.4, 0.03, 1.0)


def synthetic_cloud_cover(
    timestamps: pd.DatetimeIndex,
    mean_cover_fraction: float = 0.4,
    persistence: float = 0.92,
    volatility: float = 0.10,
    random_seed: int | None = None,
) -> np.ndarray:
    """Mean-reverting (Ornstein-Uhlenbeck-style) random walk in [0, 1], giving
    clouds realistic minute-to-minute/hour-to-hour persistence.
    """
    rng = np.random.default_rng(random_seed)
    n = len(timestamps)
    cover = np.empty(n)
    cover[0] = mean_cover_fraction
    for idx in range(1, n):
        shock = rng.normal(0.0, volatility)
        cover[idx] = persistence * cover[idx - 1] + (1 - persistence) * mean_cover_fraction + shock
    return np.clip(cover, 0.0, 1.0)


def cloud_shadow_transients(
    timestamps: pd.DatetimeIndex,
    base_transmittance: np.ndarray,
    event_rate_per_hour: float = 0.0,
    dip_fraction: float = 0.6,
    dip_duration_steps: int = 3,
    random_seed: int | None = None,
) -> np.ndarray:
    """Superimpose brief, sharp transmittance dips on top of the slower cloud
    field, e.g. for high-resolution (1-5 min) simulations that need to show
    fast-moving cumulus shadows crossing the array.
    """
    if event_rate_per_hour <= 0:
        return base_transmittance
    rng = np.random.default_rng(random_seed)
    n = len(timestamps)
    step_hours = float((timestamps[1] - timestamps[0]).total_seconds() / 3600.0) if n > 1 else 1.0
    p_event_per_step = event_rate_per_hour * step_hours

    transmittance = base_transmittance.copy()
    idx = 0
    while idx < n:
        if rng.random() < p_event_per_step:
            end = min(idx + dip_duration_steps, n)
            transmittance[idx:end] *= 1.0 - dip_fraction
            idx = end
        else:
            idx += 1
    return np.clip(transmittance, 0.0, 1.0)
