"""Weather abstraction: the common time-series shape every irradiance/thermal
calculation consumes, whichever source it came from.

Model basis: SIMPLIFIED/EMPIRICAL for `generate_synthetic_weather` (a
stochastic stand-in for a real climate, useful for design-space exploration);
USER_DATA for `load_historical_weather` (verbatim measured/reanalysis data,
as accurate as the file you give it).
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from solaros.weather.clouds import synthetic_cloud_cover
from solaros.weather.temperature import synthetic_ambient_temperature_c
from solaros.weather.wind import synthetic_wind_speed_m_s


@dataclass
class WeatherSeries:
    timestamps: pd.DatetimeIndex
    ambient_temperature_c: np.ndarray
    cloud_cover_fraction: np.ndarray
    wind_speed_m_s: np.ndarray
    humidity_fraction: np.ndarray
    rainfall_mm: np.ndarray
    basis: str = "empirical"

    def __len__(self) -> int:
        return len(self.timestamps)

    def daily_rainfall_mm(self) -> pd.Series:
        return pd.Series(self.rainfall_mm, index=self.timestamps).resample("D").sum()


def generate_synthetic_weather(
    timestamps: pd.DatetimeIndex,
    annual_mean_temp_c: float = 12.0,
    annual_temp_amplitude_c: float = 10.0,
    mean_cloud_cover_fraction: float = 0.4,
    mean_wind_speed_m_s: float = 3.5,
    rain_probability_per_day: float = 0.30,
    random_seed: int | None = None,
) -> WeatherSeries:
    """A statistically plausible, self-consistent weather year for design-space
    exploration where no site-specific measured file is available yet.
    """
    ambient_temperature_c = synthetic_ambient_temperature_c(
        timestamps, annual_mean_c=annual_mean_temp_c, annual_amplitude_c=annual_temp_amplitude_c
    )
    cloud_cover_fraction = synthetic_cloud_cover(
        timestamps, mean_cover_fraction=mean_cloud_cover_fraction, random_seed=random_seed
    )
    wind_speed_m_s = synthetic_wind_speed_m_s(timestamps, mean_speed_m_s=mean_wind_speed_m_s, random_seed=random_seed)

    rng = np.random.default_rng(random_seed)
    n = len(timestamps)
    # Rain is decided once per calendar day (not independently per timestep) so daily
    # totals -- what the soiling model actually cares about -- have realistic statistics,
    # then spread evenly across that day's timesteps.
    calendar_day = timestamps.floor("D")
    unique_days, day_index = np.unique(calendar_day, return_inverse=True)
    daily_cloud_cover = pd.Series(cloud_cover_fraction).groupby(day_index).mean().to_numpy()
    is_rain_day = rng.random(len(unique_days)) < (rain_probability_per_day * (0.3 + 0.7 * daily_cloud_cover))
    daily_total_mm = np.where(is_rain_day, rng.exponential(6.0, size=len(unique_days)), 0.0)
    steps_per_day = pd.Series(np.ones(n)).groupby(day_index).transform("sum").to_numpy()
    rainfall_mm = daily_total_mm[day_index] / steps_per_day

    humidity_fraction = np.clip(0.5 + 0.3 * cloud_cover_fraction + rng.normal(0, 0.05, size=n), 0.1, 1.0)

    return WeatherSeries(
        timestamps=timestamps,
        ambient_temperature_c=ambient_temperature_c,
        cloud_cover_fraction=cloud_cover_fraction,
        wind_speed_m_s=wind_speed_m_s,
        humidity_fraction=humidity_fraction,
        rainfall_mm=rainfall_mm,
        basis="synthetic_empirical",
    )


def load_historical_weather(
    csv_path: str,
    timestamp_column: str = "timestamp",
    temperature_column: str = "ambient_temperature_c",
    cloud_cover_column: str = "cloud_cover_fraction",
    wind_speed_column: str = "wind_speed_m_s",
    humidity_column: str | None = "humidity_fraction",
    rainfall_column: str | None = "rainfall_mm",
    timezone: str = "UTC",
) -> WeatherSeries:
    """Import a measured/reanalysis weather file. Column names are configurable
    since every data provider names things differently; only `timestamp`,
    `temperature` and `cloud_cover` (or an equivalent irradiance-derived proxy)
    are required.
    """
    df = pd.read_csv(csv_path)
    timestamps = pd.to_datetime(df[timestamp_column])
    if timestamps.dt.tz is None:
        timestamps = timestamps.dt.tz_localize(timezone)
    else:
        timestamps = timestamps.dt.tz_convert(timezone)
    index = pd.DatetimeIndex(timestamps)

    n = len(df)
    humidity = df[humidity_column].to_numpy() if humidity_column and humidity_column in df else np.full(n, 0.6)
    rainfall = df[rainfall_column].to_numpy() if rainfall_column and rainfall_column in df else np.zeros(n)

    return WeatherSeries(
        timestamps=index,
        ambient_temperature_c=df[temperature_column].to_numpy(dtype=float),
        cloud_cover_fraction=np.clip(df[cloud_cover_column].to_numpy(dtype=float), 0.0, 1.0),
        wind_speed_m_s=df[wind_speed_column].to_numpy(dtype=float),
        humidity_fraction=humidity,
        rainfall_mm=rainfall,
        basis="user_supplied",
    )
