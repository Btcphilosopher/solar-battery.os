"""Ambient air temperature: seasonal + diurnal cycle for synthetic weather.

Model basis: EMPIRICAL. A two-harmonic sinusoid (annual + diurnal) is a
standard reduced-order climatology model; it will not reproduce real cold
snaps or heatwaves, only the smooth seasonal/diurnal envelope around them.
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def synthetic_ambient_temperature_c(
    timestamps: pd.DatetimeIndex,
    annual_mean_c: float = 12.0,
    annual_amplitude_c: float = 10.0,
    diurnal_amplitude_c: float = 6.0,
    coldest_day_of_year: int = 21,  # ~Jan 21 in the northern hemisphere
    coolest_hour: float = 5.0,
) -> np.ndarray:
    doy = timestamps.dayofyear.to_numpy().astype(float)
    hour = (timestamps.hour + timestamps.minute / 60.0).to_numpy()

    seasonal = -annual_amplitude_c * np.cos(2 * np.pi * (doy - coldest_day_of_year) / 365.25)
    diurnal = -diurnal_amplitude_c * np.cos(2 * np.pi * (hour - coolest_hour) / 24.0)

    return annual_mean_c + seasonal + diurnal
