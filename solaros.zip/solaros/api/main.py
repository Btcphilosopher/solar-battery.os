"""FastAPI surface over the SolarOS engine. The engine is fully usable
without this file (every endpoint here is a thin wrapper over
solaros.core/simulation/optimisation/economics); this module exists purely
for remote/service access, e.g. a web front-end or another service calling in.
"""
from __future__ import annotations

import uuid
from typing import Optional

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from solaros.core.clock import build_time_index
from solaros.core.configuration import SimulationConfig, TimeResolution
from solaros.core.simulation import SystemConfig, run_simulation
from solaros.core.state import SimulationState
from solaros.optimise import optimise_system
from solaros.photovoltaic.module import PRESET_PANELS
from solaros.simulation.monte_carlo import run_monte_carlo
from solaros.simulation.scenarios import parameter_sweep
from solaros.weather.weather import generate_synthetic_weather

app = FastAPI(
    title="SolarOS",
    description="Photovoltaic simulation and optimisation engine: maximise real, deliverable, useful electricity.",
    version="0.1.0",
)

_RESULTS: dict[str, SimulationState] = {}

MAX_SWEEP_COMBOS = 200
MAX_MONTE_CARLO_RUNS = 100


class WeatherRequest(BaseModel):
    year: int = 2024
    resolution: TimeResolution = TimeResolution.HOURLY
    random_seed: Optional[int] = None
    annual_mean_temp_c: float = 12.0
    mean_cloud_cover_fraction: float = 0.40


class SimulateRequest(BaseModel):
    system: SystemConfig
    config: SimulationConfig = Field(default_factory=SimulationConfig)
    weather: WeatherRequest = Field(default_factory=WeatherRequest)


class SweepRequest(BaseModel):
    system: SystemConfig
    weather: WeatherRequest = Field(default_factory=WeatherRequest)
    param_grid: dict[str, list[float]]


class MonteCarloRequest(BaseModel):
    system: SystemConfig
    n_runs: int = 50
    year: int = 2024
    random_seed: Optional[int] = None


class OptimiseRequest(BaseModel):
    system: SystemConfig
    weather: WeatherRequest = Field(default_factory=WeatherRequest)
    energy_value_eur_per_kwh: float = 0.30


def _build_weather(req: WeatherRequest, system: SystemConfig):
    timestamps = build_time_index(req.year, req.resolution, system.site.timezone)
    return generate_synthetic_weather(
        timestamps,
        annual_mean_temp_c=req.annual_mean_temp_c,
        mean_cloud_cover_fraction=req.mean_cloud_cover_fraction,
        random_seed=req.random_seed,
    )


def _store(state: SimulationState, rated_power_w: float) -> str:
    result_id = uuid.uuid4().hex
    state.extra["_rated_power_w"] = rated_power_w
    _RESULTS[result_id] = state
    return result_id


@app.post("/simulate")
def simulate(req: SimulateRequest) -> dict:
    weather = _build_weather(req.weather, req.system)
    state = run_simulation(req.system, weather, req.config)
    rated_w = req.system.panel.rated_power_w * req.system.layout.total_modules
    result_id = _store(state, rated_w)
    return {"id": result_id, "summary": state.summary(rated_w), "losses": state.losses.as_dict()}


@app.post("/simulate/year")
def simulate_year_endpoint(req: SimulateRequest) -> dict:
    return simulate(req)


@app.post("/sweep")
def sweep(req: SweepRequest) -> dict:
    n_combos = 1
    for values in req.param_grid.values():
        n_combos *= len(values)
    if n_combos > MAX_SWEEP_COMBOS:
        raise HTTPException(400, f"{n_combos} combinations requested, max {MAX_SWEEP_COMBOS} over the API (use the Python API directly for larger sweeps)")

    weather = _build_weather(req.weather, req.system)
    df = parameter_sweep(req.system, weather, req.param_grid, max_workers=1)
    return {"rows": df.to_dict(orient="records")}


@app.post("/monte-carlo")
def monte_carlo(req: MonteCarloRequest) -> dict:
    n_runs = min(req.n_runs, MAX_MONTE_CARLO_RUNS)
    result = run_monte_carlo(req.system, n_runs=n_runs, year=req.year, random_seed=req.random_seed, max_workers=1)
    return {
        "n_runs": n_runs,
        "p90_kwh": result.p90_kwh,
        "p50_kwh": result.p50_kwh,
        "p10_kwh": result.p10_kwh,
        "mean_kwh": result.mean_kwh,
        "std_kwh": result.std_kwh,
    }


@app.post("/optimise")
def optimise(req: OptimiseRequest) -> dict:
    weather = _build_weather(req.weather, req.system)
    report = optimise_system(req.system, weather, energy_value_eur_per_kwh=req.energy_value_eur_per_kwh)
    return {
        "baseline_annual_kwh": report.baseline_annual_kwh,
        "optimised_annual_kwh": report.optimised_annual_kwh,
        "gain_kwh": report.gain_kwh,
        "gain_fraction": report.gain_fraction,
        "steps": [
            {"name": s.name, "gain_kwh": s.gain_kwh, "parameters_changed": s.parameters_changed, "note": s.note}
            for s in report.steps
        ],
        "cooling_recommendation": report.cooling_recommendation,
        "best_system": report.best_system.model_dump(),
    }


@app.get("/panels")
def list_panels() -> list[dict]:
    return [
        {
            "technology": name,
            "name": panel.name,
            "rated_power_w": panel.rated_power_w,
            "area_m2": panel.area_m2,
            "efficiency_fraction": panel.efficiency_fraction,
        }
        for name, panel in PRESET_PANELS.items()
    ]


@app.get("/weather")
def weather_preview(latitude_deg: float, longitude_deg: float, year: int = 2024, random_seed: Optional[int] = None) -> dict:
    timestamps = build_time_index(year, TimeResolution.HOURLY, "UTC")
    weather = generate_synthetic_weather(timestamps, random_seed=random_seed)
    import pandas as pd

    monthly_temp = pd.Series(weather.ambient_temperature_c, index=timestamps).resample("ME").mean()
    monthly_cloud = pd.Series(weather.cloud_cover_fraction, index=timestamps).resample("ME").mean()
    return {
        "monthly_mean_temperature_c": {str(k.date()): v for k, v in monthly_temp.items()},
        "monthly_mean_cloud_cover_fraction": {str(k.date()): v for k, v in monthly_cloud.items()},
        "basis": weather.basis,
    }


@app.get("/results/{result_id}")
def get_result(result_id: str) -> dict:
    state = _RESULTS.get(result_id)
    if state is None:
        raise HTTPException(404, "unknown result id")
    rated_w = state.extra.get("_rated_power_w", 0.0)
    return {
        "summary": state.summary(rated_w),
        "monthly_kwh": {str(k.date()): v for k, v in state.monthly_energy_kwh().items()},
    }


@app.get("/losses/{result_id}")
def get_losses(result_id: str) -> dict:
    state = _RESULTS.get(result_id)
    if state is None:
        raise HTTPException(404, "unknown result id")
    return state.losses.as_dict()
