import pandas as pd
import pytest

from solaros.core.clock import build_time_index
from solaros.core.configuration import TimeResolution
from solaros.electrical.inverter import InverterParameters
from solaros.geometry.site import Site
from solaros.photovoltaic.array import ArrayLayout
from solaros.photovoltaic.module import get_preset
from solaros.core.simulation import SystemConfig
from solaros.weather.weather import generate_synthetic_weather


@pytest.fixture
def berlin_site() -> Site:
    return Site(name="berlin", latitude_deg=52.5, longitude_deg=13.4, elevation_m=50, timezone="UTC")


@pytest.fixture
def small_system(berlin_site) -> SystemConfig:
    panel = get_preset("mono-si")
    layout = ArrayLayout(modules_per_string=10, strings_parallel=2)
    inverter = InverterParameters(rated_ac_power_w=8000)
    return SystemConfig(site=berlin_site, panel=panel, layout=layout, inverter=inverter, tilt_deg=35, azimuth_deg=180)


@pytest.fixture
def hourly_year_index() -> pd.DatetimeIndex:
    return build_time_index(2023, TimeResolution.HOURLY, "UTC")  # 2023: non-leap year, 8760 steps


@pytest.fixture
def synthetic_weather(hourly_year_index):
    return generate_synthetic_weather(hourly_year_index, random_seed=42)
