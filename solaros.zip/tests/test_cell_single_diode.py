import numpy as np
import pytest

from solaros.photovoltaic.cell import (
    CellParameters,
    current_from_voltage,
    extract_single_diode_parameters,
    solve_mpp,
    voltage_from_current,
)
from solaros.photovoltaic.module import get_preset


@pytest.fixture
def sdp():
    panel = get_preset("mono-si")
    return panel.single_diode_parameters


def test_mpp_reproduces_datasheet_power_within_a_few_percent(sdp):
    mpp = solve_mpp(sdp, 1000.0, 25.0)
    panel = get_preset("mono-si")
    datasheet_pmp = panel.rated_power_w
    assert abs(mpp.p_mp_w - datasheet_pmp) / datasheet_pmp < 0.05


def test_zero_irradiance_gives_zero_power(sdp):
    mpp = solve_mpp(sdp, 0.0, 25.0)
    assert mpp.p_mp_w == 0.0
    assert mpp.v_oc_v == 0.0
    assert mpp.i_sc_a == 0.0


def test_higher_irradiance_gives_more_power(sdp):
    low = solve_mpp(sdp, 200.0, 25.0)
    high = solve_mpp(sdp, 1000.0, 25.0)
    assert high.p_mp_w > low.p_mp_w
    assert high.i_sc_a > low.i_sc_a


def test_higher_temperature_reduces_power_for_silicon(sdp):
    cold = solve_mpp(sdp, 1000.0, 0.0)
    hot = solve_mpp(sdp, 1000.0, 70.0)
    assert hot.p_mp_w < cold.p_mp_w
    assert hot.v_oc_v < cold.v_oc_v  # Voc drops with temperature for silicon


def test_extreme_cold_does_not_produce_nan_or_negative_power(sdp):
    mpp = solve_mpp(sdp, 1000.0, -40.0)
    assert np.isfinite(mpp.p_mp_w)
    assert mpp.p_mp_w > 0


def test_extreme_heat_does_not_produce_nan(sdp):
    mpp = solve_mpp(sdp, 1000.0, 85.0)
    assert np.isfinite(mpp.p_mp_w)
    assert mpp.p_mp_w >= 0


def test_voltage_current_roundtrip_is_exact(sdp):
    v = np.linspace(0.5, 45.0, 30)
    i = current_from_voltage(sdp, v, 1000.0, 25.0)
    v_recovered = voltage_from_current(sdp, i, 1000.0, 25.0)
    np.testing.assert_allclose(v_recovered, v, atol=1e-6)


def test_current_from_voltage_is_monotonically_non_increasing(sdp):
    v = np.linspace(0.0, 55.0, 100)
    i = current_from_voltage(sdp, v, 1000.0, 25.0)
    assert np.all(np.diff(i) <= 1e-9)


def test_extreme_shunt_resistance_does_not_overflow():
    # Regression test: a very high Rsh (near-infinite shunt) previously overflowed
    # np.exp() inside the Lambert-W argument before the log-domain fix.
    cell = CellParameters(
        technology="mono-si",
        v_oc_v=49.5,
        i_sc_a=10.65,
        v_mp_v=41.4,
        i_mp_a=9.66,
        cells_in_series=108,
        temp_coeff_voc_pct_per_k=-0.27,
        temp_coeff_isc_pct_per_k=0.045,
        temp_coeff_pmax_pct_per_k=-0.34,
        shunt_resistance_ohm=1e6,
    )
    sdp = extract_single_diode_parameters(cell)
    v = np.linspace(0.1, 49.0, 20)
    i = current_from_voltage(sdp, v, 1000.0, 25.0)
    assert np.all(np.isfinite(i))
