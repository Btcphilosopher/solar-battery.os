import numpy as np

from solaros.economics.lcoe import discounted_payback_years, lcoe_eur_per_kwh, npv_eur, simple_payback_years
from solaros.photovoltaic.degradation import DegradationModel
from solaros.photovoltaic.soiling import CleaningPolicy, SoilingModel, cleaning_days_for_policy, optimise_cleaning_policy


def test_degradation_capacity_decreases_monotonically():
    model = DegradationModel(annual_rate_pct_per_year=0.5, first_year_light_induced_pct=2.0)
    years = np.arange(0, 26)
    capacity = model.remaining_capacity_fraction(years)
    assert np.all(np.diff(capacity) <= 1e-9)
    assert capacity[0] == 1.0
    assert capacity[-1] < capacity[1]


def test_lcoe_decreases_with_more_energy():
    deg = DegradationModel()
    low_energy = lcoe_eur_per_kwh(40000, 400, 8000, deg, 0.05, 25)
    high_energy = lcoe_eur_per_kwh(40000, 400, 12000, deg, 0.05, 25)
    assert high_energy < low_energy


def test_npv_positive_for_a_good_investment():
    cashflow = np.full(25, 3000.0)
    assert npv_eur(20000, cashflow, 0.05) > 0


def test_simple_payback_matches_capex_over_cashflow():
    assert abs(simple_payback_years(10000, 2000) - 5.0) < 1e-9


def test_discounted_payback_is_longer_than_simple_payback():
    cashflow = np.full(20, 2000.0)
    simple = simple_payback_years(10000, 2000)
    discounted = discounted_payback_years(10000, cashflow, 0.05)
    assert discounted > simple


def test_soiling_resets_after_qualifying_rain():
    model = SoilingModel(daily_soiling_rate_pct=1.0, rain_cleaning_threshold_mm=5.0, natural_cleaning_effectiveness=0.9)
    rain = np.array([0.0, 0.0, 0.0, 10.0, 0.0])
    loss = model.simulate_daily_loss_fraction(rain)
    assert loss[3] < loss[2]  # rain on day 4 washes off most of the accumulated soiling


def test_no_cleaning_accumulates_more_loss_than_monthly_cleaning():
    model = SoilingModel(daily_soiling_rate_pct=0.1, max_soiling_loss_pct=20.0)
    rain = np.zeros(90)
    none_days = cleaning_days_for_policy(CleaningPolicy.NONE, model, rain)
    monthly_days = cleaning_days_for_policy(CleaningPolicy.MONTHLY, model, rain)
    loss_none = model.simulate_daily_loss_fraction(rain, none_days)
    loss_monthly = model.simulate_daily_loss_fraction(rain, monthly_days)
    assert loss_none[-1] > loss_monthly[-1]


def test_optimise_cleaning_policy_never_recommends_negative_events():
    model = SoilingModel(daily_soiling_rate_pct=0.05)
    rain = np.zeros(180)
    clear_sky_energy = np.full(180, 500.0)
    result = optimise_cleaning_policy(model, rain, clear_sky_energy, energy_value_eur_per_kwh=0.3, cleaning_cost_eur=50.0)
    assert result["cleaning_events"] >= 0
