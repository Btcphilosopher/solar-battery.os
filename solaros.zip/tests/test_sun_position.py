import numpy as np
import pandas as pd

from solaros.solar.sun_position import solar_position, sunrise_sunset_hours


def test_solar_noon_elevation_at_equinox_matches_latitude_complement():
    # At the equinox, solar noon elevation = 90 - |latitude| (sun over the equator).
    ts = pd.DatetimeIndex(["2024-03-20 12:00:00"], tz="UTC")  # ~equinox, longitude 0 => solar noon ~12:00 UTC
    sun = solar_position(ts, latitude_deg=52.5, longitude_deg=0.0)
    assert abs(sun.elevation_deg[0] - (90.0 - 52.5)) < 2.0


def test_summer_solstice_elevation_higher_than_winter_at_noon():
    ts = pd.DatetimeIndex(["2024-06-21 12:00:00", "2024-12-21 12:00:00"], tz="UTC")
    sun = solar_position(ts, latitude_deg=52.5, longitude_deg=0.0)
    assert sun.elevation_deg[0] > sun.elevation_deg[1]


def test_sun_below_horizon_at_midnight():
    ts = pd.DatetimeIndex(["2024-06-21 00:00:00"], tz="UTC")
    sun = solar_position(ts, latitude_deg=52.5, longitude_deg=0.0)
    assert sun.elevation_deg[0] < 0


def test_day_length_longer_in_summer_than_winter_northern_hemisphere():
    doy = np.array([172, 355])  # ~Jun 21, ~Dec 21
    _, _, day_length = sunrise_sunset_hours(doy, latitude_deg=52.5, longitude_deg=0.0)
    assert day_length[0] > day_length[1]


def test_polar_day_and_night_handled_without_nan():
    doy = np.array([172, 355])  # summer solstice, winter solstice
    _, _, day_length = sunrise_sunset_hours(doy, latitude_deg=78.0, longitude_deg=0.0)  # above arctic circle
    assert not np.any(np.isnan(day_length))
    assert day_length[0] == 24.0  # midnight sun
    assert day_length[1] == 0.0  # polar night


def test_azimuth_progresses_east_to_west_over_the_day():
    ts = pd.date_range("2024-06-21 05:00", "2024-06-21 19:00", freq="1h", tz="UTC")
    sun = solar_position(ts, latitude_deg=52.5, longitude_deg=0.0)
    above = sun.above_horizon
    az = sun.azimuth_deg[above]
    assert az[0] < 180 < az[-1]  # morning sun in the east (<180), evening sun in the west (>180)
