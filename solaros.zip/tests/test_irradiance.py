import numpy as np

from solaros.solar.irradiance import apply_cloud_cover, clear_sky_irradiance, plane_of_array_irradiance
from solaros.weather.clouds import cloud_transmittance


def test_zero_irradiance_when_sun_below_horizon():
    day_of_year = np.array([100, 100])
    elevation = np.array([-10.0, 30.0])
    irr = clear_sky_irradiance(day_of_year, elevation)
    assert irr.dni_w_m2[0] == 0.0
    assert irr.ghi_w_m2[0] == 0.0
    assert irr.dni_w_m2[1] > 0.0


def test_clear_sky_irradiance_never_exceeds_solar_constant():
    day_of_year = np.full(5, 172.0)
    elevation = np.array([10, 30, 50, 70, 90.0])
    irr = clear_sky_irradiance(day_of_year, elevation)
    assert np.all(irr.dni_w_m2 < 1400)
    assert np.all(irr.ghi_w_m2 < 1400)


def test_higher_turbidity_reduces_irradiance():
    day_of_year = np.full(1, 172.0)
    elevation = np.array([45.0])
    clean = clear_sky_irradiance(day_of_year, elevation, linke_turbidity=2.0)
    hazy = clear_sky_irradiance(day_of_year, elevation, linke_turbidity=6.0)
    assert hazy.ghi_w_m2[0] < clean.ghi_w_m2[0]


def test_full_cloud_cover_attenuates_but_full_overcast_still_gt_zero():
    transmittance = cloud_transmittance(np.array([1.0]))
    assert 0.0 < transmittance[0] < 0.3


def test_apply_cloud_cover_reduces_dni_more_than_dhi():
    day_of_year = np.full(1, 172.0)
    elevation = np.array([45.0])
    clear = clear_sky_irradiance(day_of_year, elevation)
    cloudy = apply_cloud_cover(clear, cloud_transmittance(np.array([0.9])))
    dni_ratio = cloudy.dni_w_m2[0] / clear.dni_w_m2[0]
    dhi_ratio = cloudy.dhi_w_m2[0] / clear.dhi_w_m2[0]
    assert dni_ratio < dhi_ratio


def test_plane_of_array_irradiance_matches_ghi_at_zero_tilt_normal_incidence():
    from solaros.solar.irradiance import IrradianceComponents

    irr = IrradianceComponents(dni_w_m2=np.array([800.0]), dhi_w_m2=np.array([100.0]), ghi_w_m2=np.array([900.0]))
    # AOI=0 (sun straight overhead), tilt=0 (flat panel): POA should equal DNI*cos(0) + DHI*1 + ground(0) = DNI+DHI = GHI
    poa = plane_of_array_irradiance(irr, aoi_deg=np.array([0.0]), tilt_deg=np.array([0.0]), albedo=0.2)
    assert abs(poa[0] - 900.0) < 1e-6
