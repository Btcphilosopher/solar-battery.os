import numpy as np

from solaros.electrical.iv_curve import module_iv_curve_with_bypass, unshaded_module_iv_curve
from solaros.electrical.mppt import compare_algorithms
from solaros.photovoltaic.module import get_preset


def test_pv_curve_peak_is_the_mpp():
    panel = get_preset("mono-si")
    curve = unshaded_module_iv_curve(panel.single_diode_parameters, 1000.0, 25.0)
    v_mp, i_mp, p_mp = curve.mpp()
    assert np.isclose(p_mp, np.max(curve.power_w))
    assert v_mp > 0 and i_mp > 0


def test_partial_shading_with_bypass_diodes_costs_less_than_proportional_loss():
    panel = get_preset("mono-si")
    unshaded = unshaded_module_iv_curve(panel.single_diode_parameters, 1000.0, 25.0)
    _, _, p_unshaded = unshaded.mpp()

    shaded = module_iv_curve_with_bypass(panel.single_diode_parameters, 1000.0, 25.0, shaded_fraction=0.34)
    _, _, p_shaded = shaded.mpp()

    # One of three substrings fully shaded (~1/3 of the module): a bypass diode should
    # recover most of the module's power, losing much less than the naive 33% you'd
    # expect if the whole series string were limited by the shaded substring's current.
    fraction_retained = p_shaded / p_unshaded
    assert fraction_retained > 0.55


def test_full_shading_gives_zero_power():
    panel = get_preset("mono-si")
    curve = module_iv_curve_with_bypass(panel.single_diode_parameters, 1000.0, 25.0, shaded_fraction=1.0)
    assert curve.mpp()[2] == 0.0


def test_mppt_algorithms_stay_below_ideal_tracking_efficiency():
    panel = get_preset("mono-si")
    sdp = panel.single_diode_parameters
    n = 100
    g = np.clip(800 + 300 * np.sin(np.linspace(0, 6, n)), 0, 1200)
    t = np.full(n, 40.0)
    results = compare_algorithms(sdp, g, t)
    for name, r in results.items():
        if name == "ideal_analytic":
            assert r.tracking_efficiency_fraction == 1.0
        else:
            assert 0.0 < r.tracking_efficiency_fraction <= 1.0


def test_mppt_handles_zero_irradiance_without_error():
    panel = get_preset("mono-si")
    sdp = panel.single_diode_parameters
    n = 24
    g = np.zeros(n)
    t = np.full(n, 15.0)
    results = compare_algorithms(sdp, g, t)
    for r in results.values():
        assert np.all(r.power_w == 0.0)
