import numpy as np

from solaros.photovoltaic.temperature import (
    cell_temperature_from_module_c,
    faiman_module_temperature_c,
    noct_cell_temperature_c,
)


def test_noct_model_at_zero_irradiance_equals_ambient():
    assert noct_cell_temperature_c(20.0, 0.0, noct_c=45.0) == 20.0


def test_noct_model_increases_with_irradiance():
    low = noct_cell_temperature_c(20.0, 400.0)
    high = noct_cell_temperature_c(20.0, 1000.0)
    assert high > low


def test_faiman_model_higher_wind_speed_cools_the_module():
    calm = faiman_module_temperature_c(25.0, 800.0, wind_speed_m_s=np.array([0.0]))
    windy = faiman_module_temperature_c(25.0, 800.0, wind_speed_m_s=np.array([8.0]))
    assert windy[0] < calm[0]


def test_faiman_model_never_divides_by_zero_at_zero_wind():
    result = faiman_module_temperature_c(25.0, 800.0, wind_speed_m_s=np.array([0.0]))
    assert np.isfinite(result[0])


def test_cell_hotter_than_module_when_irradiance_positive():
    module_temp = np.array([40.0])
    cell_temp = cell_temperature_from_module_c(module_temp, poa_irradiance_w_m2=np.array([1000.0]))
    assert cell_temp[0] > module_temp[0]
