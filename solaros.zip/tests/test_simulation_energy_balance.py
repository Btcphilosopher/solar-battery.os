import numpy as np

from solaros.core.simulation import run_simulation


def test_loss_waterfall_telescopes_exactly_to_net_ac(small_system, synthetic_weather):
    state = run_simulation(small_system, synthetic_weather)
    d = state.losses.as_dict()
    loss_keys = [k for k in d if k not in ("solar_resource_kwh", "net_ac_kwh")]
    reconstructed = d["solar_resource_kwh"] - sum(d[k] for k in loss_keys)
    assert abs(reconstructed - d["net_ac_kwh"]) < 1e-3


def test_annual_yield_is_in_a_physically_plausible_range(small_system, synthetic_weather):
    state = run_simulation(small_system, synthetic_weather)
    rated_w = small_system.panel.rated_power_w * small_system.layout.total_modules
    specific_yield = state.annual_ac_kwh / (rated_w / 1000.0)
    # A well-oriented mid-latitude fixed-tilt system: roughly 700-1700 kWh/kWp/year
    # across plausible weather/turbidity assumptions.
    assert 500 < specific_yield < 2000


def test_capacity_factor_between_zero_and_one(small_system, synthetic_weather):
    state = run_simulation(small_system, synthetic_weather)
    rated_w = small_system.panel.rated_power_w * small_system.layout.total_modules
    cf = state.capacity_factor(rated_w)
    assert 0.0 < cf < 0.5


def test_ac_power_never_exceeds_inverter_rating(small_system, synthetic_weather):
    state = run_simulation(small_system, synthetic_weather)
    assert np.all(state.ac_power_w <= small_system.inverter.rated_ac_power_w + 1e-6)


def test_undersized_inverter_causes_clipping_losses(small_system, synthetic_weather):
    small_inverter_system = small_system.model_copy(
        update={"inverter": small_system.inverter.model_copy(update={"rated_ac_power_w": 500.0, "max_dc_power_w": 8000.0})}
    )
    state = run_simulation(small_inverter_system, synthetic_weather)
    assert state.losses.inverter_loss_kwh > 0
    assert state.peak_ac_power_w <= 500.0 + 1e-6


def test_night_hours_produce_no_positive_dc_power(small_system, synthetic_weather):
    state = run_simulation(small_system, synthetic_weather)
    night_mask = state.extra["sun_elevation_deg"] <= 0
    assert np.all(state.dc_power_w[night_mask] == 0.0)


def test_higher_soiling_rate_reduces_energy(small_system, synthetic_weather):
    from solaros.photovoltaic.soiling import SoilingModel

    clean = small_system.model_copy(update={"soiling": SoilingModel(daily_soiling_rate_pct=0.01)})
    dirty = small_system.model_copy(update={"soiling": SoilingModel(daily_soiling_rate_pct=0.3)})
    clean_kwh = run_simulation(clean, synthetic_weather).annual_ac_kwh
    dirty_kwh = run_simulation(dirty, synthetic_weather).annual_ac_kwh
    assert dirty_kwh < clean_kwh


def test_degradation_reduces_output_with_system_age(small_system, synthetic_weather):
    new = small_system.model_copy(update={"system_age_years": 0.0})
    old = small_system.model_copy(update={"system_age_years": 20.0})
    new_kwh = run_simulation(new, synthetic_weather).annual_ac_kwh
    old_kwh = run_simulation(old, synthetic_weather).annual_ac_kwh
    assert old_kwh < new_kwh


def test_dual_axis_tracking_never_produces_less_energy_than_fixed(small_system, synthetic_weather):
    fixed_kwh = run_simulation(small_system, synthetic_weather).annual_ac_kwh
    tracked = small_system.model_copy(update={"tracking_mode": "dual_axis"})
    tracked_kwh = run_simulation(tracked, synthetic_weather).annual_ac_kwh
    assert tracked_kwh >= fixed_kwh
