import numpy as np

from solaros.solar.shading import (
    Obstruction,
    obstruction_shading_fraction,
    row_to_row_shaded_fraction,
)


def test_obstruction_blocks_sun_directly_behind_it():
    obs = [Obstruction("tree", azimuth_deg=180.0, angular_width_deg=20.0, elevation_deg=30.0)]
    blocked = obstruction_shading_fraction(
        sun_azimuth_deg=np.array([180.0]), sun_elevation_deg=np.array([10.0]), obstructions=obs
    )
    assert blocked[0] > 0.9


def test_obstruction_does_not_block_when_sun_is_higher_than_it():
    obs = [Obstruction("tree", azimuth_deg=180.0, angular_width_deg=20.0, elevation_deg=30.0)]
    blocked = obstruction_shading_fraction(
        sun_azimuth_deg=np.array([180.0]), sun_elevation_deg=np.array([60.0]), obstructions=obs
    )
    assert blocked[0] == 0.0


def test_obstruction_does_not_block_when_sun_is_far_in_azimuth():
    obs = [Obstruction("tree", azimuth_deg=180.0, angular_width_deg=20.0, elevation_deg=30.0)]
    blocked = obstruction_shading_fraction(
        sun_azimuth_deg=np.array([90.0]), sun_elevation_deg=np.array([10.0]), obstructions=obs
    )
    assert blocked[0] == 0.0


def test_row_to_row_shading_worse_at_low_sun_elevation():
    low_sun = row_to_row_shaded_fraction(
        sun_elevation_deg=np.array([10.0]), sun_azimuth_deg=np.array([180.0]),
        row_azimuth_deg=180.0, tilt_deg=30.0, ground_coverage_ratio=0.5,
    )
    high_sun = row_to_row_shaded_fraction(
        sun_elevation_deg=np.array([60.0]), sun_azimuth_deg=np.array([180.0]),
        row_azimuth_deg=180.0, tilt_deg=30.0, ground_coverage_ratio=0.5,
    )
    assert low_sun[0] >= high_sun[0]


def test_row_to_row_shading_worse_with_tighter_packing():
    loose = row_to_row_shaded_fraction(
        sun_elevation_deg=np.array([20.0]), sun_azimuth_deg=np.array([180.0]),
        row_azimuth_deg=180.0, tilt_deg=30.0, ground_coverage_ratio=0.2,
    )
    tight = row_to_row_shaded_fraction(
        sun_elevation_deg=np.array([20.0]), sun_azimuth_deg=np.array([180.0]),
        row_azimuth_deg=180.0, tilt_deg=30.0, ground_coverage_ratio=0.9,
    )
    assert tight[0] >= loose[0]


def test_row_to_row_shading_zero_when_sun_below_horizon():
    result = row_to_row_shaded_fraction(
        sun_elevation_deg=np.array([-5.0]), sun_azimuth_deg=np.array([180.0]),
        row_azimuth_deg=180.0, tilt_deg=30.0, ground_coverage_ratio=0.5,
    )
    assert result[0] == 1.0  # no usable beam at all when the sun's below the horizon; treated as fully unavailable
