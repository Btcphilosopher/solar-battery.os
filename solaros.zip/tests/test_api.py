import pytest
from fastapi.testclient import TestClient

from solaros.api.main import app

client = TestClient(app)


def _system_payload():
    return {
        "site": {"name": "t", "latitude_deg": 52.5, "longitude_deg": 13.4, "elevation_m": 50, "timezone": "UTC"},
        "panel": {
            "name": "p",
            "area_m2": 1.95,
            "cell": {
                "technology": "mono-si",
                "v_oc_v": 49.5,
                "i_sc_a": 10.65,
                "v_mp_v": 41.4,
                "i_mp_a": 9.66,
                "cells_in_series": 108,
                "temp_coeff_voc_pct_per_k": -0.27,
                "temp_coeff_isc_pct_per_k": 0.045,
                "temp_coeff_pmax_pct_per_k": -0.34,
            },
        },
        "layout": {"modules_per_string": 10, "strings_parallel": 2},
        "inverter": {"rated_ac_power_w": 8000},
    }


def test_list_panels():
    r = client.get("/panels")
    assert r.status_code == 200
    assert any(p["technology"] == "mono-si" for p in r.json())


def test_simulate_and_fetch_results():
    r = client.post("/simulate", json={"system": _system_payload(), "weather": {"random_seed": 1}})
    assert r.status_code == 200
    body = r.json()
    assert body["summary"]["annual_ac_kwh"] > 0

    result_id = body["id"]
    r2 = client.get(f"/results/{result_id}")
    assert r2.status_code == 200
    r3 = client.get(f"/losses/{result_id}")
    assert r3.status_code == 200
    assert "net_ac_kwh" in r3.json()


def test_unknown_result_id_returns_404():
    r = client.get("/results/does-not-exist")
    assert r.status_code == 404


def test_sweep_endpoint():
    r = client.post(
        "/sweep",
        json={"system": _system_payload(), "weather": {"random_seed": 2}, "param_grid": {"tilt_deg": [20, 35]}},
    )
    assert r.status_code == 200
    assert len(r.json()["rows"]) == 2


def test_sweep_endpoint_rejects_oversized_grids():
    huge_grid = {"tilt_deg": list(range(50)), "azimuth_deg": list(range(50))}
    r = client.post("/sweep", json={"system": _system_payload(), "param_grid": huge_grid})
    assert r.status_code == 400


def test_weather_preview_endpoint():
    r = client.get("/weather", params={"latitude_deg": 52.5, "longitude_deg": 13.4, "random_seed": 1})
    assert r.status_code == 200
    assert len(r.json()["monthly_mean_temperature_c"]) == 12
