import numpy as np

from solaros.core.simulation import run_simulation
from solaros.weather.weather import WeatherSeries


def _weather_like(base: WeatherSeries, **overrides) -> WeatherSeries:
    fields = dict(
        timestamps=base.timestamps,
        ambient_temperature_c=base.ambient_temperature_c,
        cloud_cover_fraction=base.cloud_cover_fraction,
        wind_speed_m_s=base.wind_speed_m_s,
        humidity_fraction=base.humidity_fraction,
        rainfall_mm=base.rainfall_mm,
        basis=base.basis,
    )
    fields.update(overrides)
    return WeatherSeries(**fields)


def test_permanently_overcast_sky_still_produces_some_energy(small_system, synthetic_weather):
    overcast = _weather_like(synthetic_weather, cloud_cover_fraction=np.ones(len(synthetic_weather)))
    state = run_simulation(small_system, overcast)
    assert state.annual_ac_kwh > 0  # diffuse light still gets through
    assert np.all(np.isfinite(state.ac_power_w))


def test_extreme_heat_weather_does_not_produce_nan(small_system, synthetic_weather):
    scorching = _weather_like(synthetic_weather, ambient_temperature_c=np.full(len(synthetic_weather), 55.0))
    state = run_simulation(small_system, scorching)
    assert np.all(np.isfinite(state.ac_power_w))
    assert np.all(np.isfinite(state.cell_temperature_c))


def test_extreme_cold_weather_does_not_produce_nan(small_system, synthetic_weather):
    arctic = _weather_like(synthetic_weather, ambient_temperature_c=np.full(len(synthetic_weather), -35.0))
    state = run_simulation(small_system, arctic)
    assert np.all(np.isfinite(state.ac_power_w))
    assert np.all(state.ac_power_w >= -small_system.inverter.night_standby_w - 1e-6)


def test_rapid_cloud_transitions_do_not_break_the_simulation(small_system, synthetic_weather):
    n = len(synthetic_weather)
    flickering = _weather_like(synthetic_weather, cloud_cover_fraction=np.array([0.0, 1.0] * (n // 2) + [0.0] * (n % 2)))
    state = run_simulation(small_system, flickering)
    assert np.all(np.isfinite(state.ac_power_w))
    assert state.annual_ac_kwh > 0


def test_heavy_snow_equivalent_soiling_can_near_fully_block_output(small_system, synthetic_weather):
    from solaros.photovoltaic.soiling import CleaningPolicy, SoilingModel

    snowed_in = small_system.model_copy(
        update={
            "soiling": SoilingModel(daily_soiling_rate_pct=5.0, max_soiling_loss_pct=95.0, rain_cleaning_threshold_mm=1000.0),
            "cleaning_policy": CleaningPolicy.NONE,
        }
    )
    clear = small_system.model_copy(update={"soiling": SoilingModel(daily_soiling_rate_pct=0.0)})

    snowed_kwh = run_simulation(snowed_in, synthetic_weather).annual_ac_kwh
    clear_kwh = run_simulation(clear, synthetic_weather).annual_ac_kwh
    assert snowed_kwh < 0.2 * clear_kwh


def test_zero_available_wind_does_not_crash_thermal_model(small_system, synthetic_weather):
    still_air = _weather_like(synthetic_weather, wind_speed_m_s=np.zeros(len(synthetic_weather)))
    state = run_simulation(small_system, still_air)
    assert np.all(np.isfinite(state.cell_temperature_c))
