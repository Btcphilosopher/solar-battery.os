import numpy as np

from solaros.electrical.inverter import InverterParameters, convert_dc_to_ac


def test_night_standby_draws_negative_ac_power():
    params = InverterParameters(rated_ac_power_w=5000)
    out = convert_dc_to_ac(np.array([0.0]), params)
    assert out.ac_power_w[0] < 0
    assert out.standby_loss_w[0] > 0


def test_clipping_caps_ac_output_at_rated_power():
    params = InverterParameters(rated_ac_power_w=5000, max_dc_power_w=7000)
    out = convert_dc_to_ac(np.array([7000.0]), params)
    assert out.ac_power_w[0] <= params.rated_ac_power_w
    assert out.clipping_loss_w[0] > 0


def test_dc_above_max_dc_power_is_hard_clipped_before_conversion():
    params = InverterParameters(rated_ac_power_w=5000, max_dc_power_w=6000)
    out = convert_dc_to_ac(np.array([9000.0]), params)
    assert out.clipping_loss_w[0] >= 3000.0 - 1.0  # at least the excess over max_dc_power_w


def test_low_loading_has_lower_efficiency_than_mid_loading():
    params = InverterParameters(rated_ac_power_w=5000)
    out = convert_dc_to_ac(np.array([100.0, 2500.0]), params)
    eff_low = out.ac_power_w[0] / 100.0
    eff_mid = out.ac_power_w[1] / 2500.0
    assert eff_mid > eff_low


def test_energy_conservation_dc_equals_ac_plus_losses():
    params = InverterParameters(rated_ac_power_w=5000, max_dc_power_w=6000)
    dc = np.array([0.0, 50.0, 500.0, 3000.0, 5500.0, 8000.0])
    out = convert_dc_to_ac(dc, params)
    running = dc >= params.min_startup_dc_power_w
    reconstructed_ac = dc - out.conversion_loss_w - out.clipping_loss_w
    # only holds while running; while not running the inverter draws standby instead
    np.testing.assert_allclose(np.where(running, out.ac_power_w, 0), np.where(running, np.maximum(reconstructed_ac, 0), 0), atol=1e-6)
