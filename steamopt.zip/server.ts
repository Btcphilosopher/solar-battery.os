/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

// Initialize the Google Gen AI client with appropriate headers
let aiClient: GoogleGenAI | null = null;
function getGeminiClient() {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      console.warn("GEMINI_API_KEY is not defined. AI Advisor features will operate in simulated offline mode.");
      return null;
    }
    aiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        }
      }
    });
  }
  return aiClient;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // STEAMOPT AI Advisor Endpoint
  app.post("/api/copilot/analyze", async (req, res) => {
    try {
      const { telemetry, mode, recommendation } = req.body;
      
      const ai = getGeminiClient();
      if (!ai) {
        // Mock offline response if no API key is available
        const mockResponse = `### [STEAMOPT AI Offline Advisor Response]
The thermodynamic state of the steam cycle is stable.
- **HP Expansion**: Operating at **${telemetry.hpEff.toFixed(1)}%** isentropic efficiency. Slight inlet valve throttling loss detected.
- **Condenser**: Backpressure is **${telemetry.condBar.toFixed(3)} bar**. Recommend checking water-box cooling temperature approach (~${(telemetry.ambientC + 5).toFixed(1)}°C).
- **Optimization Directive**: Shifting to **${mode}** mode suggests an adjustment of **${(recommendation?.targetSteamMassFlowKgS - telemetry.flow).toFixed(1)} kg/s** to reach optimal enthalpy drop across the intermediate pressure stage.`;
        return res.json({ response: mockResponse });
      }

      const prompt = `You are a senior thermal-power engineer, turbomachinery specialist, and industrial optimization architect.
Analyze the current steam cycle state below:

--- Telemetry Data ---
- Inlet Pressure: ${telemetry.pBar} bar
- Inlet Temperature: ${telemetry.tC} °C
- Steam Mass Flow: ${telemetry.flow} kg/s
- Condenser Pressure: ${telemetry.condBar} bar
- Ambient Cooling Temp: ${telemetry.ambientC} °C
- Gross Power Output: ${telemetry.grossMw} MW
- Net Power Output: ${telemetry.netMw} MW
- Auxiliary Power Load: ${telemetry.auxMw} MW
- Net Plant Efficiency: ${telemetry.netEffPct}%
- Net Heat Rate: ${telemetry.heatRate} kJ/kWh

--- Target Optimisation Mode ---
- Selected Mode: ${mode}
- Optimizer Suggestion: ${recommendation?.message || "Stable"}
- Target Pressure: ${recommendation?.targetSteamPressureBar} bar
- Target Temperature: ${recommendation?.targetSteamTemperatureC} °C
- Target Mass Flow: ${recommendation?.targetSteamMassFlowKgS} kg/s

Please provide a highly professional, physically-grounded engineering report analyzing this cycle state.
Specifically discuss:
1. Thermodynamic losses (Isentropic drops in the HP/IP/LP turbine stages).
2. Condenser vacuum effectiveness and ambient thermal feedback.
3. Specific operator recommendations to maximize net electrical generation, increase cycle efficiency, reduce heat rate, and avoid wet steam turbine blade erosion.
Keep your analysis rigorous, concise, and focused on physical and economic efficiency. Do not use generic explanations.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.7-flash",
        contents: prompt,
        config: {
          systemInstruction: "You are the STEAMOPT Digital Twin AI Advisor, a world-class turbomachinery specialist and thermodynamics professor. Write in structured markdown.",
        },
      });

      res.json({ response: response.text || "No analysis generated." });
    } catch (error: any) {
      console.error("Gemini Co-pilot analysis failed:", error);
      res.status(500).json({ error: error.message || "Failed to generate AI analysis." });
    }
  });

  // Serve static assets or run Vite middleware
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`STEAMOPT server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start STEAMOPT server:", err);
});
