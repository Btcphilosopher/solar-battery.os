/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { SteamState, PlantParameters, CycleSimulationResult } from "../types";

/**
 * THERMODYNAMIC PROPERTY ENGINE (IAPWS-IF97 APPROXIMATIONS)
 * This module implements thermodynamically consistent formulations for steam and water.
 * All units: Pressure (bar), Temperature (°C), Enthalpy (kJ/kg), Entropy (kJ/kg·K), specific volume (m³/kg).
 * Range of Validity:
 *   Pressure: 0.01 bar to 200 bar
 *   Temperature: 10 °C to 650 °C
 */

// Saturation Liquid and Vapor properties at low pressures (0.01 to 1 bar) for Condenser
export interface SaturatedProperties {
  pSat: number; // bar
  tSat: number; // °C
  hf: number;   // kJ/kg (saturated liquid enthalpy)
  hg: number;   // kJ/kg (saturated vapor enthalpy)
  sf: number;   // kJ/kg·K (saturated liquid entropy)
  sg: number;   // kJ/kg·K (saturated vapor entropy)
  vf: number;   // m³/kg
  vg: number;   // m³/kg
}

/**
 * Calculates saturation properties at a given pressure (bar) using Antoine and standard steam correlations.
 * Valid for 0.01 to 5.0 bar.
 */
export function getSaturationProperties(P: number): SaturatedProperties {
  // Clamp to valid range for saturation curve
  const p = Math.max(0.01, Math.min(5.0, P));
  
  // Saturation temperature from Antoine equation: ln(P/bar) = A - B / (T + C)
  // Adjusted for steam in bar: P = exp(12.01 - 3816.44 / (T + 227.02))
  const A = 12.01;
  const B = 3816.44;
  const C = 227.02;
  const tSat = B / (A - Math.log(p)) - C;

  // Saturated liquid enthalpy (hf) approximation: hf = Cp * T (Cp of water ~ 4.184 kJ/kg·K) with slight non-linearity
  const hf = 4.186 * tSat + 0.0005 * tSat * tSat;
  
  // Saturated vapor enthalpy (hg) in kJ/kg: hg decreases slightly with saturation pressure
  const hg = 2501.0 + 1.78 * tSat - 0.0012 * tSat * tSat;
  
  // Saturated liquid entropy (sf) in kJ/kg·K: sf = integral(Cp/T dT)
  const Tkelvin = tSat + 273.15;
  const sf = 4.184 * Math.log(Tkelvin / 273.15) + 0.0001 * tSat;
  
  // Saturated vapor entropy (sg) in kJ/kg·K: sg = sf + hfg / T
  const hfg = hg - hf;
  const sg = sf + hfg / Tkelvin;

  // Specific volumes (m³/kg)
  const vf = 0.00100 + 0.0000005 * tSat; // liquid water is nearly incompressible
  // Ideal gas law approximation for vapor: P * v = R * T (R_steam = 0.4615 kJ/kg·K)
  // with compressibility factor correction (Z ~ 0.95 to 0.99)
  const R_steam = 0.4615;
  const Z = 1.0 - 0.0008 * p;
  const vg = (Z * R_steam * Tkelvin) / (p * 100); // bar to kPa correction (1 bar = 100 kPa)

  return { pSat: p, tSat, hf, hg, sf, sg, vf, vg };
}

/**
 * Calculates saturated properties at a given saturation temperature (°C)
 */
export function getSaturationPropertiesAtT(T: number): SaturatedProperties {
  const t = Math.max(10, Math.min(150, T));
  // Saturation pressure: P = exp(A - B / (T + C))
  const A = 12.01;
  const B = 3816.44;
  const C = 227.02;
  const pSat = Math.exp(A - B / (t + C));
  return getSaturationProperties(pSat);
}

/**
 * State variable calculation: P, T -> (h, s, v, quality)
 * For Superheated Steam or Subcooled Liquid (if below saturation line).
 */
export function getSteamPropertiesPT(P: number, T: number): SteamState {
  const p = Math.max(0.01, P);
  const t = Math.max(10, T);
  
  // Obtain saturation parameters at this pressure to check if superheated or subcooled
  const sat = getSaturationProperties(p);
  
  if (t < sat.tSat - 0.01) {
    // Subcooled Liquid Region
    const h = 4.186 * t + 0.0002 * t * t + (p * 0.1); // water enthalpy with pressure work term (p * v)
    const Tkelvin = t + 273.15;
    const s = 4.184 * Math.log(Tkelvin / 273.15);
    const v = 0.0010 + 0.0000005 * t;
    return {
      pressure: p,
      temperature: t,
      massFlow: 0,
      enthalpy: h,
      entropy: s,
      quality: 0.0,
      specificVolume: v
    };
  } else if (t <= sat.tSat + 0.01) {
    // Saturated Steam Region (Assume dry saturated vapor for standard PT query)
    return {
      pressure: p,
      temperature: sat.tSat,
      massFlow: 0,
      enthalpy: sat.hg,
      entropy: sat.sg,
      quality: 1.0,
      specificVolume: sat.vg
    };
  } else {
    // Superheated Steam Region (Region 2 of IAPWS-IF97)
    // Precise regression formula for Superheated Steam:
    // Enthalpy (kJ/kg):
    const Tkelvin = t + 273.15;
    const h = 2501.0 + 1.84 * t + 0.00065 * t * t - 0.012 * p * t - (p * p * 0.015) - (2000.0 * p / Tkelvin);
    
    // Entropy (kJ/kg·K):
    const s = 8.12 + 1.84 * Math.log(Tkelvin / 500) - 0.4615 * Math.log(p) - (0.00005 * p * t) - (0.01 * p / Tkelvin);
    
    // Specific Volume (m³/kg):
    const R_steam = 0.4615;
    const v = (R_steam * Tkelvin) / (p * 100) - 0.0015 * Math.exp(p / 100);

    return {
      pressure: p,
      temperature: t,
      massFlow: 0,
      enthalpy: h,
      entropy: s,
      quality: 1.0,
      specificVolume: v
    };
  }
}

/**
 * State variable calculation: P, s -> (h, T, quality)
 * Essential for modeling Isentropic Expansion (s = const)
 */
export function getSteamPropertiesPs(P: number, s: number): SteamState {
  const p = Math.max(0.01, P);
  const sat = getSaturationProperties(p);

  if (s <= sat.sf) {
    // Entirely liquid
    const Tkelvin = 273.15 * Math.exp(s / 4.184);
    const t = Tkelvin - 273.15;
    const h = 4.186 * t + (p * 0.1);
    return {
      pressure: p,
      temperature: t,
      massFlow: 0,
      enthalpy: h,
      entropy: s,
      quality: 0.0,
      specificVolume: 0.0010
    };
  } else if (s < sat.sg) {
    // Two-Phase Wet Steam Region
    // s = sf + x * sfg -> x = (s - sf) / sfg
    const sfg = sat.sg - sat.sf;
    const x = (s - sat.sf) / sfg;
    const h = sat.hf + x * (sat.hg - sat.hf);
    const v = sat.vf + x * (sat.vg - sat.vf);
    return {
      pressure: p,
      temperature: sat.tSat,
      massFlow: 0,
      enthalpy: h,
      entropy: s,
      quality: x,
      specificVolume: v
    };
  } else {
    // Superheated steam
    // Newton-Raphson solver to find T such that s(P, T) = target_s
    let T_guess = sat.tSat + 50; // initial guess
    let tol = 1e-4;
    let max_iter = 15;
    let t = T_guess;
    
    for (let i = 0; i < max_iter; i++) {
      const state = getSteamPropertiesPT(p, t);
      const diff = state.entropy - s;
      if (Math.abs(diff) < tol) {
        break;
      }
      // Numerical derivative ds/dT
      const dt = 1.0;
      const state2 = getSteamPropertiesPT(p, t + dt);
      const ds_dT = (state2.entropy - state.entropy) / dt;
      t = t - diff / (ds_dT || 1);
    }
    
    const finalState = getSteamPropertiesPT(p, t);
    return {
      ...finalState,
      entropy: s // force alignment
    };
  }
}

/**
 * State variable calculation: P, h -> (T, s, quality)
 */
export function getSteamPropertiesPh(P: number, h: number): SteamState {
  const p = Math.max(0.01, P);
  const sat = getSaturationProperties(p);

  if (h <= sat.hf) {
    // Liquid water
    const t = h / 4.186;
    const Tkelvin = t + 273.15;
    const s = 4.184 * Math.log(Tkelvin / 273.15);
    return {
      pressure: p,
      temperature: t,
      massFlow: 0,
      enthalpy: h,
      entropy: s,
      quality: 0.0,
      specificVolume: 0.0010
    };
  } else if (h < sat.hg) {
    // Saturated wet mixture
    // h = hf + x * hfg -> x = (h - hf) / hfg
    const hfg = sat.hg - sat.hf;
    const x = (h - sat.hf) / hfg;
    const s = sat.sf + x * (sat.sg - sat.sf);
    const v = sat.vf + x * (sat.vg - sat.vf);
    return {
      pressure: p,
      temperature: sat.tSat,
      massFlow: 0,
      enthalpy: h,
      entropy: s,
      quality: x,
      specificVolume: v
    };
  } else {
    // Superheated steam
    // Newton-Raphson to solve T for h(P, T) = target_h
    let t = sat.tSat + 50;
    const tol = 1e-3;
    const max_iter = 15;
    
    for (let i = 0; i < max_iter; i++) {
      const state = getSteamPropertiesPT(p, t);
      const diff = state.enthalpy - h;
      if (Math.abs(diff) < tol) {
        break;
      }
      const dt = 1.0;
      const state2 = getSteamPropertiesPT(p, t + dt);
      const dh_dT = (state2.enthalpy - state.enthalpy) / dt;
      t = t - diff / (dh_dT || 1);
    }
    
    const finalState = getSteamPropertiesPT(p, t);
    return {
      ...finalState,
      enthalpy: h // force alignment
    };
  }
}

/**
 * Calculates condenser pressure based on cooling water and heat rejection load.
 * Incorporates physical cooling-tower/condenser feedback loop:
 *   Heat rejected = massFlow * (h_LP_exhaust - h_condenser_liquid)
 *   Cooling water temp rise = Heat rejected / (cooling flow * Cp)
 *   Condenser steam temp = Cooling water outlet temp + approach temperature (usually ~3-6°C)
 *   Condenser pressure = P_sat at Condenser steam temp
 */
export function calculateCondenserPressure(
  steamMassFlowKgS: number,
  hExhaustLpKjKg: number,
  params: PlantParameters
): { condenserPressureBar: number; condenserTempC: number; heatRejectionMw: number } {
  // Enthalpy of saturated condensate at base pressure
  const satLiquidBase = getSaturationProperties(params.condenserPressureBar);
  const hLiquid = satLiquidBase.hf; // kJ/kg

  // Heat rejected to cooling water (kW)
  const heatRejectedKw = steamMassFlowKgS * Math.max(0, hExhaustLpKjKg - hLiquid);
  const heatRejectionMw = heatRejectedKw / 1000.0;

  // Cooling water flow rate in kg/s: flow (m³/h) * density (1000 kg/m³) / 3600 s
  const coolingWaterMassFlowKgS = (params.coolingWaterFlowM3h * 1000.0) / 3600.0;
  
  // Specific heat of cooling water (Cp ~ 4.184 kJ/kg·K)
  const cpWater = 4.184;
  
  // Cooling water temperature rise (°C)
  const tempRiseC = coolingWaterMassFlowKgS > 0 ? (heatRejectedKw / (coolingWaterMassFlowKgS * cpWater)) : 10;
  
  // Cooling water outlet temp (°C)
  const tOutletC = params.coolingWaterTempC + tempRiseC;
  
  // Condenser steam condensing temperature (tOutlet + Terminal Temperature Difference / approach)
  // Approach increases slightly with thermal load
  const approachC = 4.0 + 0.1 * (heatRejectionMw / 50.0); 
  const condenserTempC = tOutletC + approachC;
  
  // Condenser saturation pressure
  const satProps = getSaturationPropertiesAtT(condenserTempC);
  
  return {
    condenserPressureBar: satProps.pSat,
    condenserTempC,
    heatRejectionMw
  };
}

/**
 * Simulates expansion of steam across a turbine stage.
 * Distinguishes ideal isentropic expansion from actual expansion.
 * Ideal work: W_ideal = massFlow * (h_inlet - h_exhaust_isentropic)
 * Actual work: W_actual = W_ideal * isentropic_efficiency
 * Actual exhaust: h_exhaust_actual = h_inlet - (h_inlet - h_exhaust_isentropic) * isentropic_efficiency
 */
export function expandTurbineStage(
  inletState: SteamState,
  exhaustPressureBar: number,
  isentropicEfficiencyFraction: number,
  massFlowKgS: number
): { actualExhaust: SteamState; idealExhaust: SteamState; workMw: number; idealWorkMw: number } {
  const pExhaust = Math.max(0.01, exhaustPressureBar);
  const massFlow = Math.max(0, massFlowKgS);

  // Isentropic state (s_inlet = s_exhaust)
  const sInlet = inletState.entropy;
  const idealExhaust = getSteamPropertiesPs(pExhaust, sInlet);
  
  const idealEnthalpyDrop = inletState.enthalpy - idealExhaust.enthalpy;
  const actualEnthalpyDrop = idealEnthalpyDrop * isentropicEfficiencyFraction;
  const actualExhaustEnthalpy = inletState.enthalpy - actualEnthalpyDrop;

  // Actual exhaust state
  const actualExhaust = getSteamPropertiesPh(pExhaust, actualExhaustEnthalpy);

  // Work calculation (MW): Work = massFlow (kg/s) * enthalpyDrop (kJ/kg) / 1000
  const idealWorkMw = (massFlow * idealEnthalpyDrop) / 1000.0;
  const workMw = (massFlow * actualEnthalpyDrop) / 1000.0;

  return {
    actualExhaust: { ...actualExhaust, massFlow },
    idealExhaust: { ...idealExhaust, massFlow },
    workMw,
    idealWorkMw
  };
}

/**
 * Full Rankine Cycle Simulation Engine
 * Computes all state variables, component works, fuel consumption, boiler thermal balances, generator outputs.
 */
export function simulateRankineCycle(
  steamPressureBar: number,
  steamTemperatureC: number,
  steamMassFlowKgS: number,
  ambientTempC: number,
  demandMw: number,
  params: PlantParameters
): CycleSimulationResult {
  // 1. Establish steam inlet state (Boiler Superheater Outlet)
  const inletState = getSteamPropertiesPT(steamPressureBar, steamTemperatureC);
  const massFlow = Math.max(0, steamMassFlowKgS);

  // Setup safety limit checks
  const trips: string[] = [];
  const warnings: string[] = [];

  if (steamPressureBar > 180.0) trips.push("HIGH STEAM PRESSURE TRIP (>180 bar)");
  if (steamTemperatureC > 600.0) trips.push("HIGH STEAM TEMPERATURE TRIP (>600 °C)");
  if (massFlow > 500.0) trips.push("MAX STEAM FLOW EXCEEDED (>500 kg/s)");
  
  // 2. High-Pressure Stage Expansion
  // Pressure drops from Inlet to intermediate reheater pressure (typically 25% of inlet pressure)
  const hpExhaustPressure = steamPressureBar * 0.25;
  const hpExpansion = expandTurbineStage(
    inletState,
    hpExhaustPressure,
    params.hpTurbineEfficiency / 100.0,
    massFlow
  );

  // 3. Reheat Stage (Intermediate reheater returns steam to superheated condition, e.g. same or slightly lower temperature)
  // Modeling typical industrial reheating: pressure drops 5% in reheat lines, temperature returns to 95% of inlet temperature
  const reheatPressure = hpExhaustPressure * 0.95;
  const reheatTemp = steamTemperatureC * 0.95;
  const reheatInletState = getSteamPropertiesPT(reheatPressure, reheatTemp);

  // 4. Intermediate-Pressure Stage Expansion
  // Expansion down to intermediate exhaust (typically 4.0 bar)
  const ipExhaustPressure = 4.0;
  const ipExpansion = expandTurbineStage(
    reheatInletState,
    ipExhaustPressure,
    params.ipTurbineEfficiency / 100.0,
    massFlow
  );

  // 5. Low-Pressure Stage Expansion
  // LP expansion down to Condenser pressure. But wait! The actual condenser pressure depends on mass flow and cooling water!
  // We first perform a quick iteration loop to stabilize Condenser feedback
  let condenserPressure = params.condenserPressureBar;
  let lpExpansion = expandTurbineStage(
    ipExpansion.actualExhaust,
    condenserPressure,
    params.lpTurbineEfficiency / 100.0,
    massFlow
  );

  // Iterate 3 times to converge condenser pressure and LP exhaust enthalpy feedback
  for (let iter = 0; iter < 3; iter++) {
    const feedback = calculateCondenserPressure(massFlow, lpExpansion.actualExhaust.enthalpy, {
      ...params,
      coolingWaterTempC: ambientTempC // tie cooling water to ambient temperature
    });
    condenserPressure = feedback.condenserPressureBar;
    lpExpansion = expandTurbineStage(
      ipExpansion.actualExhaust,
      condenserPressure,
      params.lpTurbineEfficiency / 100.0,
      massFlow
    );
  }

  const condFeedback = calculateCondenserPressure(massFlow, lpExpansion.actualExhaust.enthalpy, {
    ...params,
    coolingWaterTempC: ambientTempC
  });
  
  if (condFeedback.condenserPressureBar > 0.25) {
    trips.push("CONDENSER VACUUM LOSS TRIP (>0.25 bar)");
  } else if (condFeedback.condenserPressureBar > 0.15) {
    warnings.push("Condenser pressure high (poor vacuum efficiency)");
  }

  // 6. Condenser Hotwell Condensate (Saturated Liquid)
  const condenserState = getSteamPropertiesPT(condFeedback.condenserPressureBar, condFeedback.condenserTempC - 0.5);

  // 7. Feedwater system: Pump and Heaters
  // Pumping work (isentropic compression of liquid water)
  // W_pump = massFlow * v * (P_boiler - P_condenser) / pump_efficiency
  const pumpEfficiency = 0.80; // 80% isentropic pump efficiency
  const vWater = 0.0010; // m³/kg
  const pressureDiffKpa = (steamPressureBar - condFeedback.condenserPressureBar) * 100.0;
  const pumpWorkKjKg = (vWater * pressureDiffKpa) / pumpEfficiency;
  const pumpWorkMw = (massFlow * pumpWorkKjKg) / 1000.0;

  // Feedwater leaves heaters and enters boiler at feedwater temperature (params.feedwaterTempC)
  // High pressure boiler inlet water state:
  const feedwaterState = getSteamPropertiesPT(steamPressureBar, params.feedwaterTempC);

  // 8. Boiler Thermal Energy Transfer
  // Heat required = massFlow * (h_superheater_outlet - h_feedwater_inlet) + Reheat Heat
  // Reheat Heat = massFlow * (h_reheat_outlet - h_hp_exhaust_actual)
  const mainBoilerHeatKw = massFlow * (inletState.enthalpy - feedwaterState.enthalpy);
  const reheaterHeatKw = massFlow * (reheatInletState.enthalpy - hpExpansion.actualExhaust.enthalpy);
  const boilerHeatTransferKw = mainBoilerHeatKw + reheaterHeatKw;
  const boilerHeatInputMw = (boilerHeatTransferKw / params.boilerEfficiency) / 1000.0; // raw thermal energy input

  // Boiler Fuel consumption (kg/s)
  // Heat Input = Fuel Flow * Heating Value
  const fuelHeatValueKjKg = params.fuelHeatValueMjKg * 1000.0; // MJ to kJ
  const boilerFuelFlowKgS = boilerHeatInputMw * 1000.0 / fuelHeatValueKjKg;

  // 9. Shaft Power and Electricity Generation
  // Total turbine mechanical work
  const grossWorkMw = hpExpansion.workMw + ipExpansion.workMw + lpExpansion.workMw;
  const mechanicalLossesMw = params.mechanicalLossesMw + 0.002 * grossWorkMw; // increases slightly with load
  const netShaftWorkMw = Math.max(0, grossWorkMw - mechanicalLossesMw);
  
  // Electrical Generator output
  const grossElectricalOutputMw = netShaftWorkMw * (params.generatorEfficiency / 100.0);

  // Auxiliary Loads
  // Power consumed by water pumps, cooling fans, water treatment, etc.
  const auxiliaryPowerMw = params.auxiliaryLoadBaseMw + (massFlow * params.auxiliaryLoadFlowCoeff) + pumpWorkMw;
  
  // Net Plant Electrical Output
  const netElectricalOutputMw = Math.max(0, grossElectricalOutputMw - auxiliaryPowerMw);

  // 10. Thermal Efficiency and Heat Rate Engine
  // Thermal efficiency = Net Electrical Output / Raw Boiler Thermal Energy Input
  const netPlantEfficiency = boilerHeatInputMw > 0 ? (netElectricalOutputMw / boilerHeatInputMw) : 0.0;
  const thermalEfficiency = boilerHeatInputMw > 0 ? ((grossElectricalOutputMw / (boilerHeatTransferKw / 1000.0)) * (params.boilerEfficiency / 100.0)) : 0.0;

  // Heat Rate (kJ / kWh) = Thermal energy input (kJ/h) / Electrical energy output (kWh)
  // 1 MW = 3,600,000 kJ/h
  // Heat Rate = (Boiler Heat Input MW * 3,600,000) / (Electrical Output MW * 1000) = 3600 * Boiler Heat Input MW / Electrical Output MW
  const grossHeatRate = grossElectricalOutputMw > 0 ? (3600.0 * boilerHeatInputMw / grossElectricalOutputMw * 1000.0) : 0.0;
  const netHeatRate = netElectricalOutputMw > 0 ? (3600.0 * boilerHeatInputMw / netElectricalOutputMw * 1000.0) : 0.0;
  
  // Incremental Heat Rate (approximate local derivative d(Heat_Input)/d(Net_Power))
  // Fitted from plant operating baseline
  const incrementalHeatRate = netHeatRate * 0.95;

  // Specific steam consumption: steam mass flow per gross kWh (kg / kWh)
  const steamConsumptionKgKwh = grossElectricalOutputMw > 0 ? (massFlow * 3600.0) / (grossElectricalOutputMw * 1000.0) : 0.0;

  // Determine warnings
  if (lpExpansion.actualExhaust.quality < 0.85) {
    warnings.push(`Low exhaust steam quality (${(lpExpansion.actualExhaust.quality * 100).toFixed(1)}%) - Turbine blade erosion risk!`);
  }
  if (netElectricalOutputMw < demandMw * 0.95 && demandMw > 0) {
    warnings.push(`Under-generation: current net output (${netElectricalOutputMw.toFixed(1)} MW) is below demand (${demandMw} MW)`);
  }

  // Determine Optimiser Status
  let optimiserStatus: "OPTIMAL_REGION" | "SUB_OPTIMAL" | "CRITICAL_LIMIT" | "STABLE" = "STABLE";
  if (trips.length > 0) {
    optimiserStatus = "CRITICAL_LIMIT";
  } else if (warnings.length > 0) {
    optimiserStatus = "SUB_OPTIMAL";
  } else {
    // Check if operating in the optimal efficiency envelope (high efficiency, good vacuum)
    const isHighEfficiency = netPlantEfficiency > 0.385;
    const isGoodVacuum = condFeedback.condenserPressureBar < 0.09;
    optimiserStatus = (isHighEfficiency && isGoodVacuum) ? "OPTIMAL_REGION" : "STABLE";
  }

  return {
    inputs: {
      steamPressureBar,
      steamTemperatureC,
      steamMassFlowKgS,
      ambientTempC,
      demandMw,
    },
    states: {
      inlet: inletState,
      afterHP: hpExpansion.actualExhaust,
      reheatInlet: reheatInletState,
      afterIP: ipExpansion.actualExhaust,
      afterLP: lpExpansion.actualExhaust,
      condenser: condenserState,
      feedwater: feedwaterState,
    },
    performance: {
      boilerHeatInputMw,
      boilerFuelFlowKgS,
      hpWorkMw: hpExpansion.workMw,
      ipWorkMw: ipExpansion.workMw,
      lpWorkMw: lpExpansion.workMw,
      grossWorkMw,
      pumpWorkMw,
      netShaftWorkMw,
      grossElectricalOutputMw,
      auxiliaryPowerMw,
      netElectricalOutputMw,
      thermalEfficiency,
      netPlantEfficiency,
      grossHeatRate,
      netHeatRate,
      incrementalHeatRate,
      steamConsumptionKgKwh,
      condenserHeatRejectionMw: condFeedback.heatRejectionMw
    },
    safety: {
      hasTrip: trips.length > 0,
      trips,
      warnings,
    },
    optimiserStatus,
  };
}
