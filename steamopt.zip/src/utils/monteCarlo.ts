/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PlantParameters, MonteCarloSummary, MetricStats } from "../types";
import { simulateRankineCycle } from "./thermodynamics";
import { calculateEconomicMargin } from "./optimizer";

/**
 * Box-Muller transform to generate normally distributed random variables.
 */
function randomNormal(mean: number, stdDev: number): number {
  let u = 0, v = 0;
  while(u === 0) u = Math.random(); // Converting [0,1) to (0,1)
  while(v === 0) v = Math.random();
  const num = Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
  return num * stdDev + mean;
}

/**
 * Calculates statistical metrics for a list of numbers (Mean, Median, StdDev, P5, P95, Min, Max).
 */
function calculateStats(values: number[]): MetricStats {
  if (values.length === 0) {
    return { mean: 0, median: 0, stdDev: 0, p5: 0, p95: 0, min: 0, max: 0 };
  }
  const n = values.length;
  const sorted = [...values].sort((a, b) => a - b);
  
  const sum = values.reduce((acc, val) => acc + val, 0);
  const mean = sum / n;
  
  const median = n % 2 === 0 
    ? (sorted[n / 2 - 1] + sorted[n / 2]) / 2 
    : sorted[Math.floor(n / 2)];
    
  const variance = values.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0) / Math.max(1, n - 1);
  const stdDev = Math.sqrt(variance);
  
  const p5 = sorted[Math.floor(n * 0.05)];
  const p95 = sorted[Math.floor(n * 0.95)];
  const min = sorted[0];
  const max = sorted[n - 1];

  return { mean, median, stdDev, p5, p95, min, max };
}

/**
 * Runs a multi-variable Monte Carlo simulation (e.g. 1,000 iterations)
 * under stochastic input and environmental variations:
 *   - Steam Pressure: Nominal ± 3.5 bar (SD)
 *   - Steam Temperature: Nominal ± 6.0 °C (SD)
 *   - Steam Mass Flow: Nominal ± 12.0 kg/s (SD)
 *   - Ambient/Cooling Temp: Nominal ± 4.5 °C (SD)
 */
export function runMonteCarloSimulation(
  nominalPressure: number,
  nominalTemp: number,
  nominalFlow: number,
  nominalAmbient: number,
  params: PlantParameters,
  runsCount: number = 1000
): { summary: MonteCarloSummary; rawData: Array<{ netPower: number; efficiency: number; heatRate: number; margin: number }> } {
  const netPowers: number[] = [];
  const efficiencies: number[] = [];
  const heatRates: number[] = [];
  const margins: number[] = [];
  const rawData: Array<{ netPower: number; efficiency: number; heatRate: number; margin: number }> = [];

  // standard deviations
  const pSD = 3.0; // bar
  const tSD = 5.0; // °C
  const fSD = 10.0; // kg/s
  const ambSD = 3.5; // °C

  for (let i = 0; i < runsCount; i++) {
    const p = randomNormal(nominalPressure, pSD);
    const t = randomNormal(nominalTemp, tSD);
    const f = Math.max(50.0, randomNormal(nominalFlow, fSD));
    const amb = Math.max(5.0, randomNormal(nominalAmbient, ambSD));

    try {
      const sim = simulateRankineCycle(p, t, f, amb, 0, params);
      
      // Filter out severe trips from statistics to focus on operating uncertainty
      if (sim.safety.hasTrip) {
        continue;
      }

      const econ = calculateEconomicMargin(sim.performance, params);

      netPowers.push(sim.performance.netElectricalOutputMw);
      efficiencies.push(sim.performance.netPlantEfficiency * 100.0); // as percentage
      heatRates.push(sim.performance.netHeatRate);
      margins.push(econ.netMargin);

      if (i < 200) { // keep a subset for high-fidelity charting
        rawData.push({
          netPower: sim.performance.netElectricalOutputMw,
          efficiency: sim.performance.netPlantEfficiency * 100.0,
          heatRate: sim.performance.netHeatRate,
          margin: econ.netMargin
        });
      }
    } catch (e) {
      // ignore rare extreme states that fail calculations
    }
  }

  const summary: MonteCarloSummary = {
    runsCount: netPowers.length,
    netPower: calculateStats(netPowers),
    thermalEfficiency: calculateStats(efficiencies),
    heatRate: calculateStats(heatRates),
    hourlyRevenue: calculateStats(margins)
  };

  return { summary, rawData };
}
