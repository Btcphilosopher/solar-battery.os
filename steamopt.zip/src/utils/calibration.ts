/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { CalibrationResult } from "../types";

/**
 * SCIENTIFIC CALIBRATION & REGRESSION ENGINE
 * This helper models Ordinary Least Squares (OLS) polynomial regression to fit
 * turbomachinery performance curves against historical plant operation logs.
 */

/**
 * Fits a simple linear regression: Y = beta0 + beta1 * X
 */
export function fitLinearRegression(
  x: number[],
  y: number[],
  parameterName: string
): CalibrationResult {
  const n = x.length;
  if (n === 0 || n !== y.length) {
    throw new Error("Invalid data dimensions for regression analysis.");
  }

  const sumX = x.reduce((a, b) => a + b, 0);
  const sumY = y.reduce((a, b) => a + b, 0);
  const sumXY = x.reduce((acc, val, idx) => acc + val * y[idx], 0);
  const sumXX = x.reduce((acc, val) => acc + val * val, 0);

  const slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
  const intercept = (sumY - slope * sumX) / n;

  const fittedValues: number[] = [];
  const residuals: number[] = [];
  let sumSquaredResiduals = 0;
  let totalSumSquares = 0;
  const meanY = sumY / n;

  for (let i = 0; i < n; i++) {
    const fitted = intercept + slope * x[i];
    fittedValues.push(fitted);
    
    const residual = y[i] - fitted;
    residuals.push(residual);
    
    sumSquaredResiduals += residual * residual;
    totalSumSquares += Math.pow(y[i] - meanY, 2);
  }

  const rSquared = totalSumSquares > 0 ? 1.0 - (sumSquaredResiduals / totalSumSquares) : 1.0;

  return {
    parameter: parameterName,
    rSquared: Math.max(0, Math.min(1, rSquared)),
    coefficients: {
      intercept,
      slope,
    },
    residuals,
    fittedValues,
    actualValues: y,
  };
}

/**
 * Fits a quadratic polynomial regression: Y = beta0 + beta1 * X + beta2 * X^2
 * Solves the normal equations (X^T * X) * beta = X^T * Y using a 3x3 Cramer solver
 */
export function fitQuadraticRegression(
  x: number[],
  y: number[],
  parameterName: string
): CalibrationResult {
  const n = x.length;
  if (n < 3 || n !== y.length) {
    return fitLinearRegression(x, y, parameterName); // fallback to linear if not enough points
  }

  // Sums for normal equations
  let s0 = n;
  let s1 = 0, s2 = 0, s3 = 0, s4 = 0;
  let t0 = 0, t1 = 0, t2 = 0;

  for (let i = 0; i < n; i++) {
    const xi = x[i];
    const yi = y[i];
    const x2 = xi * xi;
    const x3 = x2 * xi;
    const x4 = x3 * xi;

    s1 += xi;
    s2 += x2;
    s3 += x3;
    s4 += x4;

    t0 += yi;
    t1 += yi * xi;
    t2 += yi * x2;
  }

  // Matrix A (3x3 normal equations matrix)
  // [ s0  s1  s2 ] [ b0 ]   [ t0 ]
  // [ s1  s2  s3 ] [ b1 ] = [ t1 ]
  // [ s2  s3  s4 ] [ b2 ]   [ t2 ]
  
  const det = 
    s0 * (s2 * s4 - s3 * s3) - 
    s1 * (s1 * s4 - s2 * s3) + 
    s2 * (s1 * s3 - s2 * s2);

  if (Math.abs(det) < 1e-12) {
    // Singular matrix, fallback to linear
    return fitLinearRegression(x, y, parameterName);
  }

  // Cramer's Rule solver
  const det0 = 
    t0 * (s2 * s4 - s3 * s3) - 
    s1 * (t1 * s4 - s2 * t2) + 
    s2 * (t1 * s3 - s2 * t1);

  const det1 = 
    s0 * (t1 * s4 - s3 * t2) - 
    t0 * (s1 * s4 - s2 * s3) + 
    s2 * (s1 * t2 - t1 * s2);

  const det2 = 
    s0 * (s2 * t2 - s3 * t1) - 
    s1 * (s1 * t2 - s2 * t1) + 
    t0 * (s1 * s3 - s2 * s2);

  const b0 = det0 / det;
  const b1 = det1 / det;
  const b2 = det2 / det;

  const fittedValues: number[] = [];
  const residuals: number[] = [];
  let sumSquaredResiduals = 0;
  let totalSumSquares = 0;
  
  const meanY = t0 / n;

  for (let i = 0; i < n; i++) {
    const xi = x[i];
    const fitted = b0 + b1 * xi + b2 * xi * xi;
    fittedValues.push(fitted);

    const residual = y[i] - fitted;
    residuals.push(residual);

    sumSquaredResiduals += residual * residual;
    totalSumSquares += Math.pow(y[i] - meanY, 2);
  }

  const rSquared = totalSumSquares > 0 ? 1.0 - (sumSquaredResiduals / totalSumSquares) : 1.0;

  return {
    parameter: parameterName,
    rSquared: Math.max(0, Math.min(1, rSquared)),
    coefficients: {
      intercept: b0,
      slope: b1,
      quadratic: b2,
    },
    residuals,
    fittedValues,
    actualValues: y,
  };
}

/**
 * Generates synthetic historical plant telemetry data to perform calibrations on.
 * Intentionally contains slight measurement noise and offset to demonstrate calibration capability.
 */
export function generateHistoricalCalibrationData(): {
  flows: number[];
  hpEfficiencies: number[];
  boilerEfficiencies: number[];
} {
  const flows: number[] = [];
  const hpEfficiencies: number[] = [];
  const boilerEfficiencies: number[] = [];

  // Generate 40 points in typical flow range 200 - 450 kg/s
  for (let i = 0; i < 40; i++) {
    // Flow centered around 320 with some dispersion
    const f = 200.0 + (i * 250.0 / 39.0);
    flows.push(f);

    // HP Turbine Efficiency performance curve has a peak around 380 kg/s
    // Eff = 88.5% - 0.00008 * (Flow - 380)^2 + Gaussian Noise
    const noiseEff = (Math.random() - 0.5) * 0.4; // up to ±0.2% noise
    const baseHPEff = 88.5 - 0.00007 * Math.pow(f - 360, 2);
    hpEfficiencies.push(Math.max(70.0, baseHPEff + noiseEff));

    // Boiler efficiency peaks around 300 kg/s
    // Boiler Eff = 89.2% - 0.00005 * (Flow - 300)^2 + Gaussian Noise
    const noiseBoiler = (Math.random() - 0.5) * 0.5;
    const baseBoilerEff = 89.2 - 0.00005 * Math.pow(f - 300, 2);
    boilerEfficiencies.push(Math.max(65.0, baseBoilerEff + noiseBoiler));
  }

  return { flows, hpEfficiencies, boilerEfficiencies };
}
