/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { OperatingMode, PlantParameters, CycleSimulationResult, OptimizationRecommendation } from "../types";
import { simulateRankineCycle } from "./thermodynamics";

/**
 * STEAM SYSTEM OPTIMISATION ENGINE
 * This optimizer evaluates the operating envelopes of the Boiler, Turbines, and Condenser,
 * searching the control space [Pressure, Temperature, Mass Flow] to find the absolute mathematically
 * optimal point for the specified operational objective, subject to engineering and safety constraints.
 */

export interface OptimizerBounds {
  minPressureBar: number;
  maxPressureBar: number;
  minTempC: number;
  maxTempC: number;
  minMassFlowKgS: number;
  maxMassFlowKgS: number;
}

export const DEFAULT_OPTIMIZER_BOUNDS: OptimizerBounds = {
  minPressureBar: 100.0,
  maxPressureBar: 175.0,
  minTempC: 480.0,
  maxTempC: 585.0,
  minMassFlowKgS: 150.0,
  maxMassFlowKgS: 460.0,
};

/**
 * Evaluates the financial margin of a cycle state in USD per hour.
 * Revenue = Net Power (MW) * Electricity Price ($/MWh)
 * Fuel Cost = Fuel Flow (kg/s) * 3600 (s/h) * Cost ($/ton) / 1000 (kg/ton)
 * Cooling Cost = Cooling Water Flow (m³/h) * Water Cost ($/m³)
 */
export function calculateEconomicMargin(
  performance: CycleSimulationResult["performance"],
  params: PlantParameters
): { revenue: number; fuelCost: number; coolingCost: number; netMargin: number } {
  const electricityPrice = params.electricityPriceMwh; // $/MWh
  const fuelCostPerKg = params.fuelCostPerTon / 1000.0; // $/kg
  const waterCostPerM3 = params.waterCostPerM3; // $/m³

  const revenue = performance.netElectricalOutputMw * electricityPrice; // USD per hour (since MW is energy rate, and price is per MWh)
  const fuelCost = performance.boilerFuelFlowKgS * 3600.0 * fuelCostPerKg; // USD per hour
  const coolingCost = params.coolingWaterFlowM3h * waterCostPerM3; // USD per hour
  
  const netMargin = revenue - (fuelCost + coolingCost);
  
  return { revenue, fuelCost, coolingCost, netMargin };
}

/**
 * Optimizes the Steam Turbine System by executing a targeted multi-dimensional grid search
 * and local gradient refinement. Returns the absolute optimal control recommendation.
 */
export function optimizePlantOperation(
  currentResult: CycleSimulationResult,
  mode: OperatingMode,
  ambientTempC: number,
  demandMw: number,
  params: PlantParameters,
  bounds: OptimizerBounds = DEFAULT_OPTIMIZER_BOUNDS
): OptimizationRecommendation {
  let bestPressure = currentResult.inputs.steamPressureBar;
  let bestTemp = currentResult.inputs.steamTemperatureC;
  let bestFlow = currentResult.inputs.steamMassFlowKgS;
  
  let bestScore = -Infinity;
  let bestSimResult: CycleSimulationResult | null = null;

  // Multi-objective scoring function
  const evaluateOperatingPoint = (p: number, t: number, f: number): { score: number; sim: CycleSimulationResult } => {
    const sim = simulateRankineCycle(p, t, f, ambientTempC, demandMw, params);
    
    // Safety check: Reject points that trigger active mechanical or vacuum trips
    if (sim.safety.hasTrip) {
      return { score: -9999999, sim };
    }

    // Wet steam erosion constraint: turbine blade safety (exhaust quality must be >= 84%)
    if (sim.states.afterLP.quality < 0.84) {
      return { score: -999999 * (0.85 - sim.states.afterLP.quality), sim };
    }

    let score = 0;
    const econ = calculateEconomicMargin(sim.performance, params);

    switch (mode) {
      case OperatingMode.MAX_OUTPUT:
        // Purely maximize Net Electrical Output
        score = sim.performance.netElectricalOutputMw;
        break;

      case OperatingMode.MAX_EFFICIENCY:
        // Maximize overall cycle thermal efficiency
        score = sim.performance.netPlantEfficiency * 10000.0;
        break;

      case OperatingMode.MIN_HEAT_RATE:
        // Minimize Net Heat Rate (equivalent to maximizing efficiency)
        // Score is negative of heat rate so that we maximize the score
        score = -sim.performance.netHeatRate;
        break;

      case OperatingMode.ECONOMIC:
        // Maximize absolute net cash margin in USD/hour
        score = econ.netMargin;
        break;

      case OperatingMode.LOAD_FOLLOWING:
      case OperatingMode.FLEXIBLE_GENERATION: {
        // Track the grid demand precisely, minimizing under/over generation
        // penalize deviations from demand, then maximize efficiency
        const deviation = Math.abs(sim.performance.netElectricalOutputMw - demandMw);
        score = -deviation * 5000.0 + sim.performance.netPlantEfficiency * 1000.0;
        break;
      }

      case OperatingMode.BASE_LOAD:
        // Maintain high, constant load safely at maximum efficiency
        const isNearBase = sim.performance.netElectricalOutputMw >= 350.0;
        score = (isNearBase ? 5000.0 : 0.0) + sim.performance.netPlantEfficiency * 1000.0;
        break;

      case OperatingMode.BALANCED:
      default:
        // Balanced approach: optimize both financial margin and environmental efficiency
        score = econ.netMargin * 0.6 + sim.performance.netPlantEfficiency * 4000.0;
        break;
    }

    return { score, sim };
  };

  // Perform a 3D grid search over the valid engineering bounds
  // Step sizes: 10 pressure divisions, 10 temperature divisions, 12 flow divisions
  const pSteps = 10;
  const tSteps = 10;
  const fSteps = 12;

  const pStepVal = (bounds.maxPressureBar - bounds.minPressureBar) / pSteps;
  const tStepVal = (bounds.maxTempC - bounds.minTempC) / tSteps;
  const fStepVal = (bounds.maxMassFlowKgS - bounds.minMassFlowKgS) / fSteps;

  // Grid sweep
  for (let pi = 0; pi <= pSteps; pi++) {
    const p = bounds.minPressureBar + pi * pStepVal;
    for (let ti = 0; ti <= tSteps; ti++) {
      const t = bounds.minTempC + ti * tStepVal;
      
      // In load following, we restrict flow search around the current flow to avoid jumping wildly
      const flowMin = mode === OperatingMode.LOAD_FOLLOWING ? Math.max(bounds.minMassFlowKgS, currentResult.inputs.steamMassFlowKgS - 100) : bounds.minMassFlowKgS;
      const flowMax = mode === OperatingMode.LOAD_FOLLOWING ? Math.min(bounds.maxMassFlowKgS, currentResult.inputs.steamMassFlowKgS + 100) : bounds.maxMassFlowKgS;
      const fStepValLocal = (flowMax - flowMin) / fSteps;

      for (let fi = 0; fi <= fSteps; fi++) {
        const f = flowMin + fi * fStepValLocal;
        
        const { score, sim } = evaluateOperatingPoint(p, t, f);
        if (score > bestScore) {
          bestScore = score;
          bestPressure = p;
          bestTemp = t;
          bestFlow = f;
          bestSimResult = sim;
        }
      }
    }
  }

  // Refine locally around the best grid point (Gradient descent style)
  let refineStep = 1.0;
  for (let refine = 0; refine < 3; refine++) {
    const neighbors = [
      { p: bestPressure + refineStep, t: bestTemp, f: bestFlow },
      { p: bestPressure - refineStep, t: bestTemp, f: bestFlow },
      { p: bestPressure, t: bestTemp + refineStep * 2, f: bestFlow },
      { p: bestPressure, t: bestTemp - refineStep * 2, f: bestFlow },
      { p: bestPressure, t: bestTemp, f: bestFlow + refineStep * 5 },
      { p: bestPressure, t: bestTemp, f: bestFlow - refineStep * 5 },
    ];

    for (const n of neighbors) {
      // Clamp n to bounds
      const cp = Math.max(bounds.minPressureBar, Math.min(bounds.maxPressureBar, n.p));
      const ct = Math.max(bounds.minTempC, Math.min(bounds.maxTempC, n.t));
      const cf = Math.max(bounds.minMassFlowKgS, Math.min(bounds.maxMassFlowKgS, n.f));

      const { score, sim } = evaluateOperatingPoint(cp, ct, cf);
      if (score > bestScore) {
        bestScore = score;
        bestPressure = cp;
        bestTemp = ct;
        bestFlow = cf;
        bestSimResult = sim;
      }
    }
    refineStep /= 2.0;
  }

  // Fallback to current if optimizer somehow fails to find any valid point
  if (!bestSimResult) {
    bestSimResult = currentResult;
    bestPressure = currentResult.inputs.steamPressureBar;
    bestTemp = currentResult.inputs.steamTemperatureC;
    bestFlow = currentResult.inputs.steamMassFlowKgS;
  }

  // Compute gains
  const currentEcon = calculateEconomicMargin(currentResult.performance, params);
  const bestEcon = calculateEconomicMargin(bestSimResult.performance, params);
  const marginGain = Math.max(0, bestEcon.netMargin - currentEcon.netMargin);

  // Draft message recommendation
  let message = "";
  const dP = bestPressure - currentResult.inputs.steamPressureBar;
  const dT = bestTemp - currentResult.inputs.steamTemperatureC;
  const dF = bestFlow - currentResult.inputs.steamMassFlowKgS;

  if (Math.abs(dP) < 0.5 && Math.abs(dT) < 0.5 && Math.abs(dF) < 0.5) {
    message = "The system is currently operating at the thermodynamic optimum for this mode. Safety and efficiency envelopes are fully respected.";
  } else {
    message = `Optimiser recommends: ${dP > 0 ? "Increase" : "Decrease"} pressure by ${Math.abs(dP).toFixed(1)} bar, ${dT > 0 ? "increase" : "decrease"} temperature by ${Math.abs(dT).toFixed(1)}°C, and adjust steam mass flow rate by ${dF.toFixed(1)} kg/s.`;
    if (mode === OperatingMode.ECONOMIC && marginGain > 5.0) {
      message += ` This adjustment is projected to increase operating margins by $${marginGain.toFixed(2)}/hour.`;
    }
  }

  return {
    mode,
    targetSteamPressureBar: Math.round(bestPressure * 10) / 10,
    targetSteamTemperatureC: Math.round(bestTemp * 10) / 10,
    targetSteamMassFlowKgS: Math.round(bestFlow * 10) / 10,
    targetCondenserPressureBar: Math.round(bestSimResult.performance.condenserHeatRejectionMw > 0 ? bestSimResult.states.afterLP.pressure * 1000 : 0) / 1000,
    predictedNetOutputMw: bestSimResult.performance.netElectricalOutputMw,
    predictedEfficiency: bestSimResult.performance.netPlantEfficiency,
    predictedHeatRate: bestSimResult.performance.netHeatRate,
    expectedMarginGainUsdHour: marginGain,
    constraintsRespected: true,
    message,
  };
}
