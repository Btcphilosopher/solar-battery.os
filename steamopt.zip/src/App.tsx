/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { OperatingMode, PlantParameters, CycleSimulationResult } from "./types";
import { simulateRankineCycle } from "./utils/thermodynamics";
import { optimizePlantOperation, calculateEconomicMargin } from "./utils/optimizer";

// Components
import DigitalTwin from "./components/DigitalTwin";
import OptimizationCockpit from "./components/OptimizationCockpit";
import AnalyticsPanel from "./components/AnalyticsPanel";
import DatabaseExplorer from "./components/DatabaseExplorer";
import CodeViewer from "./components/CodeViewer";
import AiAdvisor from "./components/AiAdvisor";

// Icons
import {
  ShieldAlert,
  Cpu,
  BarChart,
  Database,
  Terminal,
  Activity,
  Zap,
  DollarSign,
  Layers,
  Sparkles,
  HelpCircle
} from "lucide-react";

export default function App() {
  // Navigation Tabs
  const [activeTab, setActiveTab] = useState<"DigitalTwin" | "Optimizer" | "Analytics" | "Database" | "Code" | "AiAdvisor">("DigitalTwin");

  // Actuators & Control Sliders
  const [pressure, setPressure] = useState<number>(165.0); // bar
  const [temperature, setTemperature] = useState<number>(565.0); // °C
  const [massFlow, setMassFlow] = useState<number>(425.0); // kg/s
  const [ambientC, setAmbientC] = useState<number>(20.0); // °C
  const [demandMw, setDemandMw] = useState<number>(390.0); // MW

  // Operating parameters & plant coefficients
  const [params, setParams] = useState<PlantParameters>({
    boilerEfficiency: 89.0, // %
    hpTurbineEfficiency: 87.5, // %
    ipTurbineEfficiency: 92.0, // %
    lpTurbineEfficiency: 84.5, // %
    generatorEfficiency: 98.7, // %
    mechanicalLossesMw: 4.5, // MW
    condenserPressureBar: 0.08, // bar
    coolingWaterTempC: 20.0, // °C
    coolingWaterFlowM3h: 28000, // m³/h
    feedwaterTempC: 245.0, // °C
    auxiliaryLoadBaseMw: 6.5, // MW
    auxiliaryLoadFlowCoeff: 0.02, // MW per kg/s steam
    fuelHeatValueMjKg: 24.5, // MJ/kg (Coal)
    fuelCostPerTon: 85.0, // USD/ton
    electricityPriceMwh: 120.0, // USD/MWh
    waterCostPerM3: 1.2, // USD/m³
  });

  const [activeMode, setActiveMode] = useState<OperatingMode>(OperatingMode.ECONOMIC);

  // AI Advisor state
  const [aiReport, setAiReport] = useState<string | null>(null);
  const [aiLoading, setAiLoading] = useState(false);

  // Calculate current system simulation
  const [currentSim, setCurrentSim] = useState<CycleSimulationResult>(() =>
    simulateRankineCycle(pressure, temperature, massFlow, ambientC, demandMw, params)
  );

  // Calculate recommendations
  const [recommendation, setRecommendation] = useState(() =>
    optimizePlantOperation(currentSim, activeMode, ambientC, demandMw, params)
  );

  // Synchronize state when actuators or parameters change
  useEffect(() => {
    const sim = simulateRankineCycle(pressure, temperature, massFlow, ambientC, demandMw, params);
    setCurrentSim(sim);
    
    const rec = optimizePlantOperation(sim, activeMode, ambientC, demandMw, params);
    setRecommendation(rec);
  }, [pressure, temperature, massFlow, ambientC, demandMw, params, activeMode]);

  // Adjust parameters helper
  const handleUpdateParams = (newParams: Partial<PlantParameters>) => {
    setParams((prev) => ({ ...prev, ...newParams }));
  };

  // Change actuators from Optimization Cockpit
  const handleChangeControls = (controls: {
    pressure?: number;
    temperature?: number;
    massFlow?: number;
    ambientC?: number;
    demandMw?: number;
  }) => {
    if (controls.pressure !== undefined) setPressure(controls.pressure);
    if (controls.temperature !== undefined) setTemperature(controls.temperature);
    if (controls.massFlow !== undefined) setMassFlow(controls.massFlow);
    if (controls.ambientC !== undefined) setAmbientC(controls.ambientC);
    if (controls.demandMw !== undefined) setDemandMw(controls.demandMw);
  };

  // Set optimum recommended values instantly
  const handleApplyOptimal = () => {
    setPressure(recommendation.targetSteamPressureBar);
    setTemperature(recommendation.targetSteamTemperatureC);
    setMassFlow(recommendation.targetSteamMassFlowKgS);
  };

  // Trigger Gemini API Co-pilot report
  const handleTriggerAiAdvisor = async () => {
    setAiLoading(true);
    setActiveTab("AiAdvisor");
    
    try {
      const response = await fetch("/api/copilot/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          telemetry: {
            pBar: pressure,
            tC: temperature,
            flow: massFlow,
            condBar: currentSim.states.afterLP.pressure,
            ambientC: ambientC,
            grossMw: currentSim.performance.grossElectricalOutputMw,
            netMw: currentSim.performance.netElectricalOutputMw,
            auxMw: currentSim.performance.auxiliaryPowerMw,
            netEffPct: (currentSim.performance.netPlantEfficiency * 100).toFixed(2),
            heatRate: currentSim.performance.netHeatRate,
            hpEff: params.hpTurbineEfficiency,
          },
          mode: activeMode,
          recommendation: recommendation,
        }),
      });

      const data = await response.json();
      if (data.error) throw new Error(data.error);
      setAiReport(data.response);
    } catch (err: any) {
      console.error(err);
      setAiReport(`Failed to connect to the STEAMOPT digital twin server. \n\n**Thermodynamic Diagnostics fallback:**\n- Inlet pressure of **${pressure.toFixed(1)} bar** is stable. \n- Exhaust blade quality is **${(currentSim.states.afterLP.quality * 100).toFixed(1)}%**. \n- Condenser approaches limit at **${ambientC.toFixed(1)}°C** cooling supply.`);
    } finally {
      setAiLoading(false);
    }
  };

  const econCurrent = calculateEconomicMargin(currentSim.performance, params);

  return (
    <div className="min-h-screen bg-[#0F172A] text-slate-100 flex flex-col font-sans select-none antialiased">
      
      {/* 1. Header Navigation Bar (Professional Polish style) */}
      <header className="px-6 py-3 bg-[#0F172A] border-b border-slate-700 flex flex-col md:flex-row justify-between items-stretch md:items-center gap-4 z-10">
        <div className="flex items-center space-x-4">
          <div className="bg-blue-600 px-3 py-1 font-black text-lg tracking-tighter text-white">
            STEAMOPT
          </div>
          <div className="h-6 w-px bg-slate-700 hidden md:block"></div>
          <div className="flex flex-col">
            <span className="text-[10px] uppercase tracking-widest text-slate-400 font-semibold">Plant Digital Twin</span>
            <span className="text-sm font-mono text-slate-300">ST-GEN-04_UNIT_REHEAT</span>
          </div>
        </div>

        {/* Real-time telemetry readouts inside the header */}
        <div className="flex space-x-6 text-right self-end md:self-auto">
          <div className="flex flex-col">
            <span className="text-[10px] uppercase tracking-widest text-slate-400">Net Plant Efficiency</span>
            <span className="text-xl font-bold text-emerald-400">{(currentSim.performance.netPlantEfficiency * 100).toFixed(2)}%</span>
          </div>
          <div className="flex flex-col border-l border-slate-700 pl-6">
            <span className="text-[10px] uppercase tracking-widest text-slate-400">Net Electrical Output</span>
            <span className="text-xl font-bold text-white">{currentSim.performance.netElectricalOutputMw.toFixed(1)} MW</span>
          </div>
          <div className="flex flex-col border-l border-slate-700 pl-6">
            <span className="text-[10px] uppercase tracking-widest text-slate-400">Heat Rate</span>
            <span className="text-xl font-bold text-blue-400">
              {currentSim.performance.netHeatRate > 0 ? currentSim.performance.netHeatRate.toFixed(0) : "0"} <span className="text-xs font-normal text-slate-400">kJ/kWh</span>
            </span>
          </div>
        </div>
      </header>

      {/* 2. Sub-Header Tab Navigation */}
      <div className="px-6 py-2 bg-[#1E293B]/40 border-b border-slate-700/80 flex items-center justify-between gap-4 overflow-x-auto">
        <nav className="flex gap-1 overflow-x-auto py-0.5">
          {[
            { id: "DigitalTwin", label: "Digital Twin", icon: <Layers className="w-3.5 h-3.5" /> },
            { id: "Optimizer", label: "Optimisation Cockpit", icon: <Activity className="w-3.5 h-3.5" /> },
            { id: "Analytics", label: "Stochastic Analytics", icon: <BarChart className="w-3.5 h-3.5" /> },
            { id: "Database", label: "SQL Terminal", icon: <Database className="w-3.5 h-3.5" /> },
            { id: "Code", label: "RUST / R Repo", icon: <Terminal className="w-3.5 h-3.5" /> },
            { id: "AiAdvisor", label: "AI Co-Pilot", icon: <Sparkles className="w-3.5 h-3.5" /> },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded text-xs font-semibold tracking-wide transition-all whitespace-nowrap ${
                activeTab === tab.id
                  ? "bg-blue-600 text-white shadow-sm"
                  : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/40"
              }`}
            >
              {tab.icon}
              {tab.label}
            </button>
          ))}
        </nav>
        <div className="text-[10px] font-mono text-slate-500 tracking-wider uppercase hidden md:flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          GRID SYNCHRONIZATION: <span className="text-emerald-400 font-bold">ACTIVE</span>
        </div>
      </div>

      {/* 3. Key Performance Indicators Row */}
      <section className="px-6 py-4 bg-[#0F172A] border-b border-slate-700/50 grid grid-cols-2 md:grid-cols-4 gap-4">
        {/* KPI 1: Gross Power Output */}
        <div className="bg-[#1E293B]/40 border border-slate-700/80 p-3.5 rounded flex items-center justify-between shadow-sm">
          <div>
            <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider block">Gross Power Output</span>
            <div className="font-mono text-lg font-black text-slate-100 mt-1">
              {currentSim.performance.grossElectricalOutputMw.toFixed(1)} MWe
            </div>
          </div>
          <Zap className="w-5 h-5 text-yellow-500" />
        </div>

        {/* KPI 2: Net Plant Output */}
        <div className="bg-[#1E293B]/40 border border-slate-700/80 p-3.5 rounded flex items-center justify-between shadow-sm">
          <div>
            <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider block">Net Plant Output</span>
            <div className="font-mono text-lg font-black text-teal-400 mt-1">
              {currentSim.performance.netElectricalOutputMw.toFixed(1)} MWe
            </div>
          </div>
          <Activity className="w-5 h-5 text-teal-400" />
        </div>

        {/* KPI 3: Cycle Thermal Efficiency */}
        <div className="bg-[#1E293B]/40 border border-slate-700/80 p-3.5 rounded flex items-center justify-between shadow-sm">
          <div>
            <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider block">Net Plant Efficiency</span>
            <div className="font-mono text-lg font-black text-slate-100 mt-1">
              {(currentSim.performance.netPlantEfficiency * 100).toFixed(2)}%
            </div>
          </div>
          <PercentGauge percent={currentSim.performance.netPlantEfficiency * 100} />
        </div>

        {/* KPI 4: Operating Financial Margin */}
        <div className="bg-[#1E293B]/40 border border-slate-700/80 p-3.5 rounded flex items-center justify-between shadow-sm">
          <div>
            <span className="text-[10px] text-slate-400 uppercase font-bold tracking-wider block">Net Operating Margin</span>
            <div className="font-mono text-lg font-black text-emerald-400 mt-1">
              ${econCurrent.netMargin.toLocaleString(undefined, { maximumFractionDigits: 0 })} /hr
            </div>
          </div>
          <DollarSign className="w-5 h-5 text-emerald-500" />
        </div>
      </section>

      {/* 4. Main Dashboard Body Context */}
      <main className="flex-1 p-6 max-w-7xl mx-auto w-full">
        {activeTab === "DigitalTwin" && (
          <DigitalTwin
            simResult={currentSim}
            params={params}
            onUpdateParams={handleUpdateParams}
          />
        )}

        {activeTab === "Optimizer" && (
          <OptimizationCockpit
            currentSim={currentSim}
            recommendation={recommendation}
            activeMode={activeMode}
            onSelectMode={setActiveMode}
            pressure={pressure}
            temperature={temperature}
            massFlow={massFlow}
            ambientC={ambientC}
            demandMw={demandMw}
            onChangeControls={handleChangeControls}
            onApplyOptimal={handleApplyOptimal}
            onTriggerAiAdvisor={handleTriggerAiAdvisor}
            aiAdvisorLoading={aiLoading}
          />
        )}

        {activeTab === "Analytics" && (
          <AnalyticsPanel
            pressure={pressure}
            temperature={temperature}
            massFlow={massFlow}
            ambientC={ambientC}
            params={params}
          />
        )}

        {activeTab === "Database" && <DatabaseExplorer />}

        {activeTab === "Code" && <CodeViewer />}

        {activeTab === "AiAdvisor" && (
          <AiAdvisor
            onTriggerAiAdvisor={handleTriggerAiAdvisor}
            aiReport={aiReport}
            loading={aiLoading}
          />
        )}
      </main>

      {/* 5. Engineering Terminal Footer */}
      <footer className="px-6 py-3.5 bg-[#0F172A] border-t border-slate-700 text-center text-[10px] text-slate-500 flex flex-col sm:flex-row justify-between items-center gap-2">
        <span>STEAMOPT © 2026. Production Thermofluid Simulation Client. All safety limits priority-locked.</span>
        <div className="flex gap-4">
          <span>Region 1-2 thermodynamic range: 0.01 - 200 bar, 10 - 650°C</span>
          <span className="text-blue-400 font-semibold">IAPWS-IF97 Compliant</span>
        </div>
      </footer>

    </div>
  );
}

// Micro utility helper for efficiency ring/circle
function PercentGauge({ percent }: { percent: number }) {
  const radius = 10;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (percent / 100) * circumference;
  
  return (
    <svg className="w-6 h-6 -rotate-90">
      <circle cx="12" cy="12" r={radius} stroke="#334155" strokeWidth="2.5" fill="none" />
      <circle
        cx="12"
        cy="12"
        r={radius}
        stroke="#10b981"
        strokeWidth="2.5"
        fill="none"
        strokeDasharray={circumference}
        strokeDashoffset={offset}
        strokeLinecap="round"
      />
    </svg>
  );
}
