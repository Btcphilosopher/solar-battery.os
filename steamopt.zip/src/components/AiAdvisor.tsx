/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Cpu, Send, RefreshCw, AlertCircle, Sparkles } from "lucide-react";

interface AiAdvisorProps {
  onTriggerAiAdvisor: () => void;
  aiReport: string | null;
  loading: boolean;
}

export default function AiAdvisor({ onTriggerAiAdvisor, aiReport, loading }: AiAdvisorProps) {
  const [customQuestion, setCustomQuestion] = useState("");
  const [conversations, setConversations] = useState<Array<{ sender: "user" | "twin"; text: string }>>([]);

  const quickQuestions = [
    "How does high cooling tower approach affect turbine backpressure?",
    "Why does low turbine exhaust steam quality erode LP rotor blades?",
    "Suggest methods to decrease auxiliary power consumption during low grid load.",
  ];

  const handleAskQuickQuestion = (question: string) => {
    setCustomQuestion(question);
  };

  // Renders the AI markdown response beautifully with tailored styling
  const renderFormattedReport = (text: string) => {
    if (!text) return null;
    
    // Split lines and parse basic markdown headers and bolding
    const lines = text.split("\n");
    return (
      <div className="space-y-3.5 text-slate-300 text-xs leading-relaxed font-sans max-h-[380px] overflow-y-auto pr-1">
        {lines.map((line, idx) => {
          const trimmed = line.trim();
          if (trimmed.startsWith("###")) {
            return (
              <h4 key={idx} className="text-blue-400 font-bold text-sm mt-4 pb-1 border-b border-slate-700/60 uppercase tracking-wide">
                {trimmed.replace("###", "").trim()}
              </h4>
            );
          } else if (trimmed.startsWith("##")) {
            return (
              <h3 key={idx} className="text-blue-300 font-bold text-base mt-5 pb-1 border-b border-slate-700/60 uppercase tracking-wide">
                {trimmed.replace("##", "").trim()}
              </h3>
            );
          } else if (trimmed.startsWith("#")) {
            return (
              <h2 key={idx} className="text-white font-bold text-lg mt-6 pb-2 border-b border-slate-700/60">
                {trimmed.replace("#", "").trim()}
              </h2>
            );
          } else if (trimmed.startsWith("-") || trimmed.startsWith("*")) {
            return (
              <li key={idx} className="ml-4 list-disc text-slate-300 pl-1">
                {parseBolds(trimmed.substring(1).trim())}
              </li>
            );
          } else {
            return (
              <p key={idx} className="text-slate-300 text-justify">
                {parseBolds(trimmed)}
              </p>
            );
          }
        })}
      </div>
    );
  };

  // Helper to parse double asterisks **bold** in lines
  const parseBolds = (str: string) => {
    if (!str) return "";
    const parts = str.split("**");
    return parts.map((part, index) => {
      if (index % 2 === 1) {
        return (
          <strong key={index} className="text-blue-300 font-semibold">
            {part}
          </strong>
        );
      }
      return part;
    });
  };

  return (
    <div className="bg-[#1E293B]/40 border border-slate-700/80 rounded p-5 flex flex-col h-[500px]">
      
      {/* Header */}
      <div className="flex justify-between items-center pb-3 border-b border-slate-700/60 mb-4 shrink-0">
        <div className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-blue-400 animate-pulse" />
          <h3 className="text-sm font-bold text-white uppercase tracking-wider">STEAMOPT AI Co-Pilot</h3>
        </div>
        <span className="text-[9px] text-slate-500 font-mono">Gemini 3.7 Cognitive Solver</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6 flex-1 min-h-0">
        
        {/* Tech Question Suggestions Sidebar */}
        <div className="lg:col-span-2 flex flex-col justify-between min-h-0">
          <div>
            <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block mb-2">Technical Guidance Queries</span>
            <div className="space-y-2">
              {quickQuestions.map((q, idx) => (
                <button
                  key={idx}
                  onClick={() => handleAskQuickQuestion(q)}
                  className="w-full text-left p-2.5 bg-slate-800/20 hover:bg-slate-800/50 text-[11px] text-slate-400 hover:text-slate-200 border border-slate-700/40 rounded transition-colors leading-relaxed cursor-pointer"
                >
                  {q}
                </button>
              ))}
            </div>
          </div>

          {/* Prompt field */}
          <div className="mt-4 pt-3 border-t border-slate-700/50">
            <label className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block mb-1">Interactive Diagnostic Console</label>
            <div className="relative">
              <input
                type="text"
                value={customQuestion}
                onChange={(e) => setCustomQuestion(e.target.value)}
                placeholder="Ask the steam co-pilot a physical question..."
                className="w-full bg-slate-900/60 border border-slate-700/60 rounded py-2.5 pl-3 pr-10 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
              />
              <button
                onClick={() => {
                  if (customQuestion.trim()) {
                    onTriggerAiAdvisor();
                    setCustomQuestion("");
                  }
                }}
                disabled={loading || !customQuestion.trim()}
                className="absolute right-1.5 top-1.5 p-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded disabled:opacity-40 transition-all cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* AI Report Output */}
        <div className="lg:col-span-3 flex flex-col bg-slate-800/10 border border-slate-700/60 rounded p-4 min-h-0">
          <div className="flex justify-between items-center mb-2.5 border-b border-slate-700/40 pb-1.5 shrink-0">
            <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Analysis Diagnostic Log</span>
            <button
              onClick={onTriggerAiAdvisor}
              disabled={loading}
              className="text-[10px] text-blue-400 hover:text-blue-300 font-semibold flex items-center gap-1 hover:underline disabled:opacity-40 cursor-pointer"
            >
              <RefreshCw className={`w-3 h-3 ${loading ? "animate-spin" : ""}`} />
              Re-Analyze Cycle
            </button>
          </div>

          <div className="flex-1 overflow-y-auto min-h-0">
            {loading ? (
              <div className="h-full flex flex-col items-center justify-center text-slate-500">
                <RefreshCw className="w-6 h-6 animate-spin text-blue-500 mb-2.5" />
                <p className="text-xs">Computing steam-tables & generating full-plant thermodynamic analysis...</p>
              </div>
            ) : aiReport ? (
              renderFormattedReport(aiReport)
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-slate-500 text-center px-4">
                <Sparkles className="w-8 h-8 text-slate-800 mb-2" />
                <p className="text-xs max-w-xs leading-normal">
                  No diagnostic report generated. Click **AI Advisor Report** in the cockpit or **Re-Analyze Cycle** above to request a comprehensive thermodynamic cycle analysis from Gemini.
                </p>
              </div>
            )}
          </div>
        </div>

      </div>

    </div>
  );
}
