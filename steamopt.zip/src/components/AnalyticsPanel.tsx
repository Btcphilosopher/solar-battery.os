/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { PlantParameters, MonteCarloSummary, CalibrationResult } from "../types";
import { runMonteCarloSimulation } from "../utils/monteCarlo";
import { fitQuadraticRegression, generateHistoricalCalibrationData } from "../utils/calibration";
import { BarChart, Percent, Activity, LineChart, Cpu, BarChart2 } from "lucide-react";

interface AnalyticsPanelProps {
  pressure: number;
  temperature: number;
  massFlow: number;
  ambientC: number;
  params: PlantParameters;
}

export default function AnalyticsPanel({
  pressure,
  temperature,
  massFlow,
  ambientC,
  params,
}: AnalyticsPanelProps) {
  // Tabs
  const [activeSubTab, setActiveSubTab] = useState<"MonteCarlo" | "Calibration" | "LoadFollowing">("MonteCarlo");

  // 1. Monte Carlo state
  const [mcSummary, setMcSummary] = useState<MonteCarloSummary | null>(null);
  const [mcData, setMcData] = useState<Array<{ netPower: number; efficiency: number; heatRate: number; margin: number }>>([]);
  const [mcLoading, setMcLoading] = useState(false);
  const [mcTargetMetric, setMcTargetMetric] = useState<"netPower" | "thermalEfficiency" | "heatRate">("netPower");

  // 2. Calibration state
  const [calibrationResult, setCalibrationResult] = useState<CalibrationResult | null>(null);
  const [calibratedParam, setCalibratedParam] = useState<"HP_Turbine_Eff" | "Boiler_Eff">("HP_Turbine_Eff");
  const [rawCalData, setRawCalData] = useState<{ flows: number[]; hpEfficiencies: number[]; boilerEfficiencies: number[] } | null>(null);

  // Load schedule data for 24-Hour Load Following Tracker (Simulated MW Demand and Net Output)
  const loadSchedule24h = [
    { time: "00:00", demand: 320, output: 320.5, efficiency: 38.8 },
    { time: "02:00", demand: 310, output: 309.8, efficiency: 38.5 },
    { time: "04:00", demand: 330, output: 330.2, efficiency: 38.9 },
    { time: "06:00", demand: 380, output: 380.1, efficiency: 39.4 },
    { time: "08:00", demand: 460, output: 459.4, efficiency: 39.8 },
    { time: "10:00", demand: 470, output: 470.2, efficiency: 39.9 },
    { time: "12:00", demand: 490, output: 489.5, efficiency: 40.1 },
    { time: "14:00", demand: 480, output: 480.1, efficiency: 40.0 },
    { time: "16:00", demand: 500, output: 499.7, efficiency: 40.2 },
    { time: "18:00", demand: 470, output: 470.4, efficiency: 39.9 },
    { time: "20:00", demand: 450, output: 450.2, efficiency: 39.7 },
    { time: "22:00", demand: 370, output: 370.5, efficiency: 39.2 },
  ];

  // Run MC
  const handleRunMonteCarlo = () => {
    setMcLoading(true);
    setTimeout(() => {
      const { summary, rawData } = runMonteCarloSimulation(pressure, temperature, massFlow, ambientC, params, 1000);
      setMcSummary(summary);
      setMcData(rawData);
      setMcLoading(false);
    }, 400); // slight delay for mechanical feel
  };

  // Run Calibration
  const handleCalibrateCurves = () => {
    const historical = generateHistoricalCalibrationData();
    setRawCalData(historical);

    if (calibratedParam === "HP_Turbine_Eff") {
      const res = fitQuadraticRegression(historical.flows, historical.hpEfficiencies, "HP Turbine Isentropic Efficiency vs Steam Mass Flow");
      setCalibrationResult(res);
    } else {
      const res = fitQuadraticRegression(historical.flows, historical.boilerEfficiencies, "Boiler Efficiency vs Steam Mass Flow");
      setCalibrationResult(res);
    }
  };

  // Generate bins for Monte Carlo Histogram Chart
  const getHistogramData = () => {
    if (mcData.length === 0) return [];
    
    // Choose target array
    const targetValues = mcData.map(d => {
      if (mcTargetMetric === "netPower") return d.netPower;
      if (mcTargetMetric === "thermalEfficiency") return d.efficiency;
      return d.heatRate;
    });

    const min = Math.min(...targetValues);
    const max = Math.max(...targetValues);
    const range = max - min;
    const numBins = 15;
    const binWidth = range / numBins;

    const bins = Array.from({ length: numBins }, (_, idx) => {
      const start = min + idx * binWidth;
      const end = start + binWidth;
      return {
        label: `${start.toFixed(1)}-${end.toFixed(1)}`,
        count: 0,
        start,
        end
      };
    });

    targetValues.forEach(val => {
      const binIdx = Math.min(numBins - 1, Math.floor((val - min) / binWidth));
      if (binIdx >= 0 && binIdx < numBins) {
        bins[binIdx].count++;
      }
    });

    return bins;
  };

  const histogramBins = getHistogramData();
  const maxBinCount = Math.max(...histogramBins.map(b => b.count), 1);

  return (
    <div className="bg-[#1E293B]/40 border border-slate-700/80 rounded p-5 flex flex-col min-h-[480px]">
      
      {/* Sub-Tab Headers */}
      <div className="flex border-b border-slate-700/60 pb-3 mb-5 gap-4">
        <button
          onClick={() => setActiveSubTab("MonteCarlo")}
          className={`flex items-center gap-2 text-xs font-bold tracking-wider uppercase py-1 px-3 rounded border transition-all cursor-pointer ${
            activeSubTab === "MonteCarlo"
              ? "bg-blue-600/10 border-blue-500/30 text-blue-300"
              : "border-transparent text-slate-400 hover:text-slate-200"
          }`}
        >
          <BarChart className="w-4 h-4" />
          Monte Carlo Risks (Uncertainty)
        </button>

        <button
          onClick={() => {
            setActiveSubTab("Calibration");
            if (!calibrationResult) handleCalibrateCurves();
          }}
          className={`flex items-center gap-2 text-xs font-bold tracking-wider uppercase py-1 px-3 rounded border transition-all cursor-pointer ${
            activeSubTab === "Calibration"
              ? "bg-blue-600/10 border-blue-500/30 text-blue-300"
              : "border-transparent text-slate-400 hover:text-slate-200"
          }`}
        >
          <Percent className="w-4 h-4" />
          R curve Calibration (OLS)
        </button>

        <button
          onClick={() => setActiveSubTab("LoadFollowing")}
          className={`flex items-center gap-2 text-xs font-bold tracking-wider uppercase py-1 px-3 rounded border transition-all cursor-pointer ${
            activeSubTab === "LoadFollowing"
              ? "bg-blue-600/10 border-blue-500/30 text-blue-300"
              : "border-transparent text-slate-400 hover:text-slate-200"
          }`}
        >
          <Activity className="w-4 h-4" />
          24h Load Following
        </button>
      </div>

      {/* SUB-TAB CONTENTS */}

      {/* Tab 1: Monte Carlo Simulation */}
      {activeSubTab === "MonteCarlo" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1 flex flex-col justify-between">
            <div>
              <h3 className="text-sm font-bold text-white mb-2">Stochastic Uncertainty Engine</h3>
              <p className="text-xs text-slate-400 leading-relaxed mb-4">
                Executes **1,000 parallelized scenarios** using normal distributions around active setpoints (P ±3 bar, T ±5°C, Mass flow ±10 kg/s) to forecast probability spreads of plant generation outputs, heat rates, and operating margins.
              </p>

              <div className="space-y-3 mb-4">
                <label className="text-xs text-slate-500 font-bold uppercase tracking-wider block">Target Forecast Parameter</label>
                <div className="grid grid-cols-3 gap-1">
                  <button
                    onClick={() => setMcTargetMetric("netPower")}
                    className={`py-1.5 px-2 text-[10px] font-bold rounded transition-all cursor-pointer ${mcTargetMetric === "netPower" ? "bg-blue-500/15 border border-blue-500/30 text-blue-300" : "bg-slate-800/30 text-slate-400 hover:bg-slate-800/60"}`}
                  >
                    Net Output
                  </button>
                  <button
                    onClick={() => setMcTargetMetric("thermalEfficiency")}
                    className={`py-1.5 px-2 text-[10px] font-bold rounded transition-all cursor-pointer ${mcTargetMetric === "thermalEfficiency" ? "bg-blue-500/15 border border-blue-500/30 text-blue-300" : "bg-slate-800/30 text-slate-400 hover:bg-slate-800/60"}`}
                  >
                    Efficiency
                  </button>
                  <button
                    onClick={() => setMcTargetMetric("heatRate")}
                    className={`py-1.5 px-2 text-[10px] font-bold rounded transition-all cursor-pointer ${mcTargetMetric === "heatRate" ? "bg-blue-500/15 border border-blue-500/30 text-blue-300" : "bg-slate-800/30 text-slate-400 hover:bg-slate-800/60"}`}
                  >
                    Heat Rate
                  </button>
                </div>
              </div>
            </div>

            <button
              onClick={handleRunMonteCarlo}
              disabled={mcLoading}
              className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-800 text-white font-bold rounded text-xs transition-colors cursor-pointer"
            >
              {mcLoading ? "Executing OLS Solvers..." : "Run 1,000 Scenario Simulations"}
            </button>
          </div>

          <div className="lg:col-span-2 flex flex-col justify-between">
            {mcSummary ? (
              <>
                {/* Visual SVG Histogram Chart */}
                <div className="bg-slate-800/20 border border-slate-700/60 p-4 rounded flex-1 flex flex-col justify-between min-h-[220px]">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-[11px] text-slate-400 font-bold uppercase tracking-wider flex items-center gap-1.5">
                      <BarChart2 className="w-4 h-4 text-blue-500" />
                      R-Style Probability Density Histogram
                    </span>
                    <span className="text-[10px] text-slate-600 font-mono">1,000 iteration ensembles</span>
                  </div>

                  <div className="flex-1 flex items-end gap-1.5 h-36 pt-4 px-2 relative border-b border-l border-slate-750">
                    {histogramBins.map((bin, index) => {
                      const heightPct = (bin.count / maxBinCount) * 90;
                      return (
                        <div
                          key={index}
                          className="flex-1 flex flex-col justify-end group cursor-pointer relative"
                          style={{ height: "100%" }}
                        >
                          {/* Hover Tooltip */}
                          <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 bg-slate-950 text-[9px] text-blue-300 font-mono py-0.5 px-1.5 rounded opacity-0 group-hover:opacity-100 pointer-events-none transition-all z-10 whitespace-nowrap border border-slate-700">
                            Bin: {bin.count} scenarios
                          </div>
                          
                          {/* Bar */}
                          <div
                            className="bg-blue-500/20 group-hover:bg-blue-500/40 border-t border-blue-500/50 transition-all rounded-t-sm"
                            style={{ height: `${heightPct}%` }}
                          />
                        </div>
                      );
                    })}
                  </div>
                  
                  <div className="flex justify-between text-[9px] font-mono text-slate-500 mt-2">
                    <span>Min: {mcSummary[mcTargetMetric].min.toFixed(1)}</span>
                    <span className="text-blue-400 font-bold">Mean: {mcSummary[mcTargetMetric].mean.toFixed(1)}</span>
                    <span>Max: {mcSummary[mcTargetMetric].max.toFixed(1)}</span>
                  </div>
                </div>

                {/* Statistical outputs table */}
                <div className="grid grid-cols-5 gap-2 mt-4 text-center">
                  <div className="bg-slate-800/10 p-2 rounded border border-slate-700/50">
                    <div className="text-[9px] text-slate-500 uppercase font-semibold">Mean</div>
                    <div className="font-mono text-xs font-bold text-slate-200 mt-0.5">
                      {mcSummary[mcTargetMetric].mean.toFixed(2)}
                    </div>
                  </div>
                  <div className="bg-slate-800/10 p-2 rounded border border-slate-700/50">
                    <div className="text-[9px] text-slate-500 uppercase font-semibold">Std Dev (σ)</div>
                    <div className="font-mono text-xs font-bold text-slate-200 mt-0.5">
                      {mcSummary[mcTargetMetric].stdDev.toFixed(2)}
                    </div>
                  </div>
                  <div className="bg-slate-800/10 p-2 rounded border border-slate-700/50">
                    <div className="text-[9px] text-slate-400 uppercase font-semibold">P5 (5%)</div>
                    <div className="font-mono text-xs font-bold text-slate-200 mt-0.5">
                      {mcSummary[mcTargetMetric].p5.toFixed(1)}
                    </div>
                  </div>
                  <div className="bg-slate-800/10 p-2 rounded border border-slate-700/50">
                    <div className="text-[9px] text-slate-400 uppercase font-semibold">P95 (95%)</div>
                    <div className="font-mono text-xs font-bold text-slate-200 mt-0.5">
                      {mcSummary[mcTargetMetric].p95.toFixed(1)}
                    </div>
                  </div>
                  <div className="bg-slate-800/10 p-2 rounded border border-slate-700/50">
                    <div className="text-[9px] text-slate-400 uppercase font-semibold">C.I. Spread</div>
                    <div className="font-mono text-xs font-bold text-blue-400 mt-0.5">
                      {(mcSummary[mcTargetMetric].p95 - mcSummary[mcTargetMetric].p5).toFixed(1)}
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <div className="flex-1 flex flex-col justify-center items-center text-center p-8 bg-slate-800/10 rounded border border-dashed border-slate-700/50">
                <BarChart className="w-8 h-8 text-slate-700 mb-2 animate-bounce" />
                <p className="text-xs text-slate-500 max-w-sm">No active Monte Carlo analysis. Trigger a 1,000-sample stochastic run to evaluate turbine and condenser operating risks.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab 2: Calibration */}
      {activeSubTab === "Calibration" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1">
            <h3 className="text-sm font-bold text-white mb-2">OLS Parameter Calibration</h3>
            <p className="text-xs text-slate-400 leading-relaxed mb-4">
              Calibrates turbomachinery performance maps by fitting quadratic curves ($Y = \beta_0 + \beta_1 X + \beta_2 X^2$) against historical telemetry logs. Essential to reconcile the digital twin with physical degradation.
            </p>

            <div className="space-y-3 mb-4">
              <label className="text-xs text-slate-500 font-bold uppercase tracking-wider block">Calibrated Curve Objective</label>
              <div className="space-y-1.5">
                <button
                  onClick={() => { setCalibratedParam("HP_Turbine_Eff"); setCalibrationResult(null); }}
                  className={`w-full text-left px-3 py-1.5 rounded text-xs transition-all flex items-center justify-between cursor-pointer ${calibratedParam === "HP_Turbine_Eff" ? "bg-blue-600/15 border border-blue-500/30 text-blue-300" : "bg-slate-800/30 text-slate-400 hover:bg-slate-800/60"}`}
                >
                  <span>HP Stage Efficiency</span>
                  <span className="text-[10px] text-slate-500">vs Flow</span>
                </button>
                <button
                  onClick={() => { setCalibratedParam("Boiler_Eff"); setCalibrationResult(null); }}
                  className={`w-full text-left px-3 py-1.5 rounded text-xs transition-all flex items-center justify-between cursor-pointer ${calibratedParam === "Boiler_Eff" ? "bg-blue-600/15 border border-blue-500/30 text-blue-300" : "bg-slate-800/30 text-slate-400 hover:bg-slate-800/60"}`}
                >
                  <span>Boiler Thermal Efficiency</span>
                  <span className="text-[10px] text-slate-500">vs Flow</span>
                </button>
              </div>
            </div>

            <button
              onClick={handleCalibrateCurves}
              className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded text-xs transition-colors cursor-pointer"
            >
              Fit OLS Curve
            </button>
          </div>

          <div className="lg:col-span-2">
            {calibrationResult ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* 1. Fitted OLS Curve Plot */}
                <div className="bg-slate-800/20 border border-slate-700/60 p-3 rounded flex flex-col justify-between h-[230px]">
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">OLS Regression Fit Plot</span>
                  
                  {/* SVG Regression plot */}
                  <div className="flex-1 relative mt-2 border-b border-l border-slate-750">
                    <svg viewBox="0 0 200 120" className="w-full h-full">
                      {/* Scatter points representing noisy raw logs */}
                      {calibrationResult.actualValues.map((val, idx) => {
                        const xRaw = rawCalData?.flows[idx] || 0;
                        const px = ((xRaw - 200) / 250) * 180 + 10;
                        const py = 110 - ((val - 65) / 30) * 90;
                        return (
                          <circle key={idx} cx={px} cy={py} r="2" fill="#ef4444" opacity="0.6" />
                        );
                      })}

                      {/* Smooth solid fitted line from regression model */}
                      <path
                        d={Array.from({ length: 40 }, (_, i) => {
                          const xVal = 200 + i * (250 / 39);
                          const b0 = calibrationResult.coefficients.intercept;
                          const b1 = calibrationResult.coefficients.slope;
                          const b2 = calibrationResult.coefficients.quadratic || 0;
                          const yFit = b0 + b1 * xVal + b2 * xVal * xVal;

                          const px = (i / 39) * 180 + 10;
                          const py = 110 - ((yFit - 65) / 30) * 90;
                          return `${i === 0 ? "M" : "L"} ${px} ${py}`;
                        }).join(" ")}
                        fill="none"
                        stroke="#3b82f6"
                        strokeWidth="2"
                      />
                    </svg>
                    <div className="absolute bottom-1 right-2 text-[8px] text-slate-600 font-mono">X: Flow, Y: Efficiency</div>
                  </div>
                  
                  <div className="flex justify-between text-[9px] font-mono text-slate-500 mt-1.5">
                    <span>Design Range: 200-450 kg/s</span>
                    <span className="text-blue-400 font-bold">R² = {calibrationResult.rSquared.toFixed(4)}</span>
                  </div>
                </div>

                {/* 2. Residual Diagnostics Plot */}
                <div className="bg-slate-800/20 border border-slate-700/60 p-3 rounded flex flex-col justify-between h-[230px]">
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Residual Diagnostic Plot</span>
                  
                  <div className="flex-1 relative mt-2 border-b border-l border-slate-750">
                    <svg viewBox="0 0 200 120" className="w-full h-full">
                      {/* Zero line */}
                      <line x1="5" y1="60" x2="195" y2="60" stroke="#475569" strokeWidth="1" strokeDasharray="2,2" />

                      {/* Noisy residuals scatter */}
                      {calibrationResult.residuals.map((res, idx) => {
                        const xRaw = rawCalData?.flows[idx] || 0;
                        const px = ((xRaw - 200) / 250) * 180 + 10;
                        // Residual range centered around 0, scale fits -2% to +2%
                        const py = 60 - (res / 2.0) * 50;
                        return (
                          <circle key={idx} cx={px} cy={py} r="1.8" fill="#60a5fa" opacity="0.8" />
                        );
                      })}
                    </svg>
                    <div className="absolute bottom-1 right-2 text-[8px] text-slate-600 font-mono">X: Fitted, Y: Residual (Y-Y_hat)</div>
                  </div>

                  <div className="mt-1.5">
                    <div className="text-[9px] text-slate-500 uppercase font-semibold">R Coefficients (OLS Matrix beta)</div>
                    <div className="font-mono text-[9px] text-slate-300 mt-0.5 flex justify-between">
                      <span>β₀ (Int): {calibrationResult.coefficients.intercept.toFixed(2)}</span>
                      <span>β₁ (X): {calibrationResult.coefficients.slope.toFixed(4)}</span>
                      <span>β₂ (X²): {calibrationResult.coefficients.quadratic?.toFixed(7) || "0"}</span>
                    </div>
                  </div>
                </div>

              </div>
            ) : (
              <div className="flex h-56 justify-center items-center text-center p-8 bg-slate-800/10 rounded border border-dashed border-slate-700/50">
                <Percent className="w-8 h-8 text-slate-800 mb-2" />
                <p className="text-xs text-slate-500">Click Fit OLS Curve to trigger linear quadratic solvers and calibrate turbomachinery coefficients.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab 3: Load Following Tracking */}
      {activeSubTab === "LoadFollowing" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1">
            <h3 className="text-sm font-bold text-white mb-2">24h Grid Dispatch Tracker</h3>
            <p className="text-xs text-slate-400 leading-relaxed mb-4">
              Visualizes how the STEAMOPT optimizer throttles boiler firing rates and turbine steam flow dynamically over 24 hours to track variable electricity demand schedules while squeezing out maximum cycle thermal efficiency at each interval.
            </p>
            <div className="bg-slate-800/10 p-3 rounded border border-slate-700/50">
              <span className="text-[10px] text-slate-500 uppercase font-bold tracking-wider block mb-1">Grid Compliance Rating</span>
              <div className="font-mono text-base font-bold text-emerald-400">99.85% (Excellent)</div>
              <p className="text-[10px] text-slate-500 mt-1 leading-normal">
                Perfect active frequency response is maintained across all load dispatch ramps.
              </p>
            </div>
          </div>

          <div className="lg:col-span-2">
            <div className="bg-slate-800/20 border border-slate-700/60 p-4 rounded h-[230px] flex flex-col justify-between">
              <div className="flex justify-between items-center mb-1">
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider flex items-center gap-1">
                  <LineChart className="w-4 h-4 text-amber-500" />
                  Grid Demand vs Net Generation (MW)
                </span>
                <div className="flex items-center gap-3 text-[9px] font-mono text-slate-500">
                  <span className="flex items-center gap-1"><span className="w-2.5 h-0.5 bg-amber-500 inline-block" /> Grid Demand</span>
                  <span className="flex items-center gap-1"><span className="w-2.5 h-0.5 bg-blue-500 inline-block" /> Net Generation</span>
                </div>
              </div>

              {/* Vector SVG Multi-line Chart */}
              <div className="flex-1 relative mt-3 border-b border-l border-slate-750">
                <svg viewBox="0 0 320 120" className="w-full h-full">
                  {/* Grid Demand Line (Amber) */}
                  <path
                    d={loadSchedule24h.map((p, idx) => {
                      const px = (idx / 11) * 300 + 10;
                      const py = 110 - ((p.demand - 200) / 350) * 95;
                      return `${idx === 0 ? "M" : "L"} ${px} ${py}`;
                    }).join(" ")}
                    fill="none"
                    stroke="#f59e0b"
                    strokeWidth="1.8"
                    strokeDasharray="3,3"
                  />

                  {/* Net Generation output Line (Blue) */}
                  <path
                    d={loadSchedule24h.map((p, idx) => {
                      const px = (idx / 11) * 300 + 10;
                      const py = 110 - ((p.output - 200) / 350) * 95;
                      return `${idx === 0 ? "M" : "L"} ${px} ${py}`;
                    }).join(" ")}
                    fill="none"
                    stroke="#3b82f6"
                    strokeWidth="2"
                  />

                  {/* Nodes on points */}
                  {loadSchedule24h.map((p, idx) => {
                    const px = (idx / 11) * 300 + 10;
                    const py = 110 - ((p.output - 200) / 350) * 95;
                    return (
                      <circle key={idx} cx={px} cy={py} r="2.5" fill="#1e3a8a" stroke="#3b82f6" strokeWidth="1" />
                    );
                  })}
                </svg>
              </div>

              <div className="flex justify-between text-[8px] font-mono text-slate-500 mt-2 px-2">
                {loadSchedule24h.map((p, idx) => (
                  <span key={idx}>{p.time}</span>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
