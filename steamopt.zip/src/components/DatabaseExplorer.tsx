/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Database, Terminal, Table, Play, CornerDownRight, CheckCircle } from "lucide-react";

interface SqlRow {
  [key: string]: any;
}

export default function DatabaseExplorer() {
  const [activeTab, setActiveTab] = useState<"Schema" | "SQL">("Schema");
  const [sqlQuery, setSqlQuery] = useState<string>(
    "SELECT timestamp, steam_pressure_bar, steam_mass_flow_kg_s, net_output_mw, efficiency_pct \nFROM telemetry \nWHERE steam_pressure_bar > 155 \nORDER BY efficiency_pct DESC \nLIMIT 5;"
  );
  const [sqlResult, setSqlResult] = useState<{ columns: string[]; rows: SqlRow[] } | null>(null);
  const [sqlError, setSqlError] = useState<string | null>(null);

  // PostgreSQL tables definition
  const tables = [
    {
      name: "plant",
      desc: "Static configuration of physical thermal generating facilities",
      columns: [
        { name: "id", type: "UUID (Primary Key)" },
        { name: "name", type: "VARCHAR(128)" },
        { name: "location", type: "VARCHAR(256)" },
        { name: "fuel_type", type: "VARCHAR(64)" },
        { name: "design_mw", type: "DOUBLE PRECISION" },
        { name: "status", type: "VARCHAR(32)" },
      ],
    },
    {
      name: "telemetry",
      desc: "Continuous high-resolution historical steam-cycle operating logs",
      columns: [
        { name: "id", type: "BIGSERIAL (Primary Key)" },
        { name: "timestamp", type: "TIMESTAMPTZ" },
        { name: "steam_pressure_bar", type: "DOUBLE PRECISION" },
        { name: "steam_temperature_c", type: "DOUBLE PRECISION" },
        { name: "steam_mass_flow_kg_s", type: "DOUBLE PRECISION" },
        { name: "condenser_pressure_bar", type: "DOUBLE PRECISION" },
        { name: "gross_output_mw", type: "DOUBLE PRECISION" },
        { name: "net_output_mw", type: "DOUBLE PRECISION" },
        { name: "efficiency_pct", type: "DOUBLE PRECISION" },
        { name: "heat_rate_kj_kwh", type: "DOUBLE PRECISION" },
      ],
    },
    {
      name: "performance_curves",
      desc: "Calibrated R regression curves, model variables and parameters",
      columns: [
        { name: "id", type: "SERIAL (Primary Key)" },
        { name: "model_version", type: "VARCHAR(64)" },
        { name: "curve_type", type: "VARCHAR(128)" },
        { name: "r_squared", type: "DOUBLE PRECISION" },
        { name: "coeff_intercept", type: "DOUBLE PRECISION" },
        { name: "coeff_slope", type: "DOUBLE PRECISION" },
        { name: "coeff_quadratic", type: "DOUBLE PRECISION" },
        { name: "calibrated_at", type: "TIMESTAMPTZ" },
      ],
    },
    {
      name: "optimisation_runs",
      desc: "Archived optimizer decisions, goals, constraints and actual yields",
      columns: [
        { name: "id", type: "UUID (Primary Key)" },
        { name: "timestamp", type: "TIMESTAMPTZ" },
        { name: "objective_mode", type: "VARCHAR(64)" },
        { name: "input_pressure_bar", type: "DOUBLE PRECISION" },
        { name: "target_pressure_bar", type: "DOUBLE PRECISION" },
        { name: "net_power_gain_mw", type: "DOUBLE PRECISION" },
        { name: "constraints_satisfied", type: "BOOLEAN" },
      ],
    },
  ];

  // Dummy database rows
  const telemetryDummyData: SqlRow[] = [
    { timestamp: "2026-08-15 00:00:00", steam_pressure_bar: 165.2, steam_temperature_c: 565.4, steam_mass_flow_kg_s: 425.2, net_output_mw: 387.4, efficiency_pct: 39.85, heat_rate_kj_kwh: 9033 },
    { timestamp: "2026-08-15 01:00:00", steam_pressure_bar: 164.8, steam_temperature_c: 564.2, steam_mass_flow_kg_s: 424.8, net_output_mw: 386.1, efficiency_pct: 39.72, heat_rate_kj_kwh: 9062 },
    { timestamp: "2026-08-15 02:00:00", steam_pressure_bar: 165.5, steam_temperature_c: 566.1, steam_mass_flow_kg_s: 426.1, net_output_mw: 388.9, efficiency_pct: 39.94, heat_rate_kj_kwh: 9012 },
    { timestamp: "2026-08-15 03:00:00", steam_pressure_bar: 154.2, steam_temperature_c: 542.5, steam_mass_flow_kg_s: 320.1, net_output_mw: 288.4, efficiency_pct: 38.12, heat_rate_kj_kwh: 9443 },
    { timestamp: "2026-08-15 04:00:00", steam_pressure_bar: 152.1, steam_temperature_c: 538.2, steam_mass_flow_kg_s: 310.4, net_output_mw: 279.1, efficiency_pct: 37.95, heat_rate_kj_kwh: 9486 },
    { timestamp: "2026-08-15 05:00:00", steam_pressure_bar: 166.4, steam_temperature_c: 568.5, steam_mass_flow_kg_s: 430.5, net_output_mw: 392.5, efficiency_pct: 40.12, heat_rate_kj_kwh: 8973 },
    { timestamp: "2026-08-15 06:00:00", steam_pressure_bar: 165.9, steam_temperature_c: 567.2, steam_mass_flow_kg_s: 428.1, net_output_mw: 390.4, efficiency_pct: 40.03, heat_rate_kj_kwh: 8993 },
  ];

  const curvesDummyData: SqlRow[] = [
    { id: 1, model_version: "v2.1.4-beta", curve_type: "HP Turbine Isentropic Eff vs Flow", r_squared: 0.9854, coeff_intercept: 81.25, coeff_slope: 0.0432, coeff_quadratic: -0.000062 },
    { id: 2, model_version: "v2.1.4-beta", curve_type: "Boiler Efficiency vs Flow", r_squared: 0.9912, coeff_intercept: 88.12, coeff_slope: 0.0112, coeff_quadratic: -0.000035 },
  ];

  // Simple Mock SQL Parser
  const executeMockSql = () => {
    setSqlError(null);
    setSqlResult(null);

    const queryClean = sqlQuery.replace(/\s+/g, " ").trim().toLowerCase();

    // Check query structure
    if (!queryClean.startsWith("select")) {
      setSqlError("SQL Error: Only SELECT queries are permitted on this telemetry twin console.");
      return;
    }

    // Determine target table
    let table = "";
    if (queryClean.includes("from telemetry")) {
      table = "telemetry";
    } else if (queryClean.includes("from performance_curves")) {
      table = "performance_curves";
    } else {
      setSqlError("SQL Error: Relation not found. Allowed tables: 'telemetry', 'performance_curves'.");
      return;
    }

    try {
      let data = table === "telemetry" ? [...telemetryDummyData] : [...curvesDummyData];

      // Parse WHERE clause (simplified: e.g. "steam_pressure_bar > 155")
      if (queryClean.includes("where")) {
        const whereIndex = queryClean.indexOf("where") + 5;
        const orderIndex = queryClean.includes("order by") ? queryClean.indexOf("order by") : queryClean.length;
        const limitIndex = queryClean.includes("limit") ? queryClean.indexOf("limit") : queryClean.length;
        const stopIndex = Math.min(orderIndex, limitIndex);

        const condition = queryClean.substring(whereIndex, stopIndex).trim();

        if (condition.includes("steam_pressure_bar > 155")) {
          data = data.filter((r) => r.steam_pressure_bar > 155);
        } else if (condition.includes("steam_pressure_bar < 155")) {
          data = data.filter((r) => r.steam_pressure_bar < 155);
        }
      }

      // Parse ORDER BY (simplified: "efficiency_pct desc" or "r_squared desc")
      if (queryClean.includes("order by")) {
        const orderIndex = queryClean.indexOf("order by") + 8;
        const limitIndex = queryClean.includes("limit") ? queryClean.indexOf("limit") : queryClean.length;
        const orderClause = queryClean.substring(orderIndex, limitIndex).trim();

        if (orderClause.includes("efficiency_pct desc") || orderClause.includes("efficiency_pct")) {
          data.sort((a, b) => b.efficiency_pct - a.efficiency_pct);
        } else if (orderClause.includes("r_squared desc") || orderClause.includes("r_squared")) {
          data.sort((a, b) => b.r_squared - a.r_squared);
        }
      }

      // Parse LIMIT
      if (queryClean.includes("limit")) {
        const limitIndex = queryClean.indexOf("limit") + 5;
        const limitCount = parseInt(queryClean.substring(limitIndex).trim());
        if (!isNaN(limitCount)) {
          data = data.slice(0, limitCount);
        }
      }

      // Extract specific columns requested
      const selectIndex = 6;
      const fromIndex = queryClean.indexOf("from");
      const selectClause = queryClean.substring(selectIndex, fromIndex).trim();

      let cols: string[] = [];
      if (selectClause === "*") {
        cols = Object.keys(data[0] || {});
      } else {
        cols = selectClause.split(",").map((c) => c.trim());
      }

      // Filter rows to only requested columns
      const finalRows = data.map((row) => {
        const filteredRow: SqlRow = {};
        cols.forEach((col) => {
          // match snake case properties
          const val = row[col];
          if (val !== undefined) {
            filteredRow[col] = val;
          }
        });
        return filteredRow;
      });

      setSqlResult({ columns: cols, rows: finalRows });
    } catch (err: any) {
      setSqlError(`SQL Syntax Error near offset: ${err.message || "Parse failed"}`);
    }
  };

  const templates = [
    { label: "High Pressure Telemetry", query: "SELECT timestamp, steam_pressure_bar, steam_mass_flow_kg_s, net_output_mw, efficiency_pct \nFROM telemetry \nWHERE steam_pressure_bar > 155 \nORDER BY efficiency_pct DESC \nLIMIT 5;" },
    { label: "Calibrated Regression Models", query: "SELECT id, curve_type, r_squared, coeff_intercept, coeff_slope \nFROM performance_curves \nORDER BY r_squared DESC;" },
  ];

  return (
    <div className="bg-[#1E293B]/40 border border-slate-700/80 rounded p-5 flex flex-col h-[500px]">
      
      {/* Tab Selectors */}
      <div className="flex border-b border-slate-700/60 pb-3 mb-4 justify-between items-center">
        <div className="flex gap-4">
          <button
            onClick={() => setActiveTab("Schema")}
            className={`flex items-center gap-1.5 text-xs font-bold tracking-wider uppercase py-1 px-3 rounded border transition-all cursor-pointer ${
              activeTab === "Schema"
                ? "bg-blue-600/10 border-blue-500/30 text-blue-300"
                : "border-transparent text-slate-400 hover:text-slate-200"
            }`}
          >
            <Database className="w-4 h-4" />
            PostgreSQL Schema Catalog
          </button>

          <button
            onClick={() => {
              setActiveTab("SQL");
              if (!sqlResult) executeMockSql();
            }}
            className={`flex items-center gap-1.5 text-xs font-bold tracking-wider uppercase py-1 px-3 rounded border transition-all cursor-pointer ${
              activeTab === "SQL"
                ? "bg-blue-600/10 border-blue-500/30 text-blue-300"
                : "border-transparent text-slate-400 hover:text-slate-200"
            }`}
          >
            <Terminal className="w-4 h-4" />
            Active SQL Scratchpad
          </button>
        </div>
        <span className="text-[10px] text-slate-600 font-mono">DB Status: Connected</span>
      </div>

      {/* SCHEMA CATALOG TAB */}
      {activeTab === "Schema" && (
        <div className="flex-1 overflow-y-auto grid grid-cols-1 md:grid-cols-2 gap-4 pr-1">
          {tables.map((table) => (
            <div key={table.name} className="bg-slate-800/10 border border-slate-700/60 p-4 rounded">
              <div className="flex items-center gap-2 pb-2 mb-2 border-b border-slate-700/60">
                <Table className="w-4 h-4 text-blue-500" />
                <span className="font-mono text-sm font-bold text-white">{table.name}</span>
              </div>
              <p className="text-[11px] text-slate-400 mb-3">{table.desc}</p>
              
              <div className="space-y-1.5 font-mono text-[10px]">
                {table.columns.map((col) => (
                  <div key={col.name} className="flex items-center justify-between py-0.5 border-b border-slate-700/30">
                    <div className="flex items-center gap-1.5">
                      <CornerDownRight className="w-3 h-3 text-slate-600" />
                      <span className="text-slate-300 font-semibold">{col.name}</span>
                    </div>
                    <span className="text-slate-500 text-right">{col.type}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* SQL TERMINAL TAB */}
      {activeTab === "SQL" && (
        <div className="flex-1 flex flex-col min-h-0">
          
          {/* Quick templates bar */}
          <div className="flex gap-2.5 mb-3.5 items-center">
            <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Templates:</span>
            {templates.map((tpl, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setSqlQuery(tpl.query);
                  setSqlResult(null);
                  setSqlError(null);
                }}
                className="px-2.5 py-1 bg-slate-800/30 hover:bg-slate-800/60 text-[10px] font-mono text-slate-300 rounded border border-slate-700/40 transition-colors cursor-pointer"
              >
                {tpl.label}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-5 gap-4 flex-1 min-h-0">
            {/* Input SQL editor */}
            <div className="lg:col-span-2 flex flex-col justify-between">
              <div className="flex-1 flex flex-col min-h-0">
                <label className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block mb-1">SQL Console</label>
                <textarea
                  value={sqlQuery}
                  onChange={(e) => setSqlQuery(e.target.value)}
                  className="flex-1 w-full bg-slate-900/50 text-slate-200 border border-slate-700/60 rounded p-3 font-mono text-xs focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 resize-none"
                  spellCheck="false"
                />
              </div>

              <button
                onClick={executeMockSql}
                className="w-full mt-3 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded text-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Play className="w-3.5 h-3.5 fill-white" />
                Run Query
              </button>
            </div>

            {/* SQL Output Results dataset */}
            <div className="lg:col-span-3 flex flex-col min-h-0 bg-slate-800/10 border border-slate-700/60 rounded overflow-hidden p-3">
              <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block mb-2">Query Output Table</span>

              {sqlError && (
                <div className="text-rose-400 font-mono text-xs bg-rose-950/20 p-3 rounded border border-rose-500/20">
                  {sqlError}
                </div>
              )}

              {sqlResult && !sqlError && (
                <div className="flex-1 overflow-auto border border-slate-700/40 rounded bg-slate-950/40">
                  <table className="w-full text-left font-mono text-[10px] border-collapse">
                    <thead>
                      <tr className="bg-slate-800/50 text-slate-400 uppercase border-b border-slate-700/60">
                        {sqlResult.columns.map((col) => (
                          <th key={col} className="p-2 border-r border-slate-700/40 whitespace-nowrap">{col}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {sqlResult.rows.length > 0 ? (
                        sqlResult.rows.map((row, idx) => (
                          <tr key={idx} className="border-b border-slate-700/20 hover:bg-slate-800/10">
                            {sqlResult.columns.map((col) => (
                              <td key={col} className="p-2 border-r border-slate-700/10 text-slate-300 whitespace-nowrap">
                                {typeof row[col] === "number" ? row[col].toLocaleString(undefined, { maximumFractionDigits: 4 }) : row[col]?.toString() || "NULL"}
                              </td>
                            ))}
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={sqlResult.columns.length} className="text-center p-8 text-slate-500">No rows matched the SELECT WHERE query parameters.</td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              )}

              {sqlResult && !sqlError && (
                <div className="mt-2 flex items-center gap-1.5 text-[9px] text-slate-500 font-mono justify-end">
                  <CheckCircle className="w-3.5 h-3.5 text-emerald-500" />
                  <span>{sqlResult.rows.length} rows returned successfully. (PostgreSQL Engine optimized)</span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
