/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { OperatingMode, CycleSimulationResult, PlantParameters, OptimizationRecommendation } from "../types";
import { Gauge, TrendingUp, DollarSign, RefreshCw, AlertTriangle, Play, HelpCircle } from "lucide-react";

interface OptimizationCockpitProps {
  currentSim: CycleSimulationResult;
  recommendation: OptimizationRecommendation;
  activeMode: OperatingMode;
  onSelectMode: (mode: OperatingMode) => void;
  // Controls
  pressure: number;
  temperature: number;
  massFlow: number;
  ambientC: number;
  demandMw: number;
  onChangeControls: (controls: {
    pressure?: number;
    temperature?: number;
    massFlow?: number;
    ambientC?: number;
    demandMw?: number;
  }) => void;
  onApplyOptimal: () => void;
  onTriggerAiAdvisor: () => void;
  aiAdvisorLoading: boolean;
}

export default function OptimizationCockpit({
  currentSim,
  recommendation,
  activeMode,
  onSelectMode,
  pressure,
  temperature,
  massFlow,
  ambientC,
  demandMw,
  onChangeControls,
  onApplyOptimal,
  onTriggerAiAdvisor,
  aiAdvisorLoading,
}: OptimizationCockpitProps) {
  
  const { performance, safety, optimiserStatus } = currentSim;

  const modesList = [
    { id: OperatingMode.MAX_OUTPUT, label: "Max Output", desc: "Maximize net electrical megawatts" },
    { id: OperatingMode.MAX_EFFICIENCY, label: "Max Efficiency", desc: "Maximize thermodynamic cycle efficiency" },
    { id: OperatingMode.MIN_HEAT_RATE, label: "Min Heat Rate", desc: "Minimize fuel burn rate per megawatt hour" },
    { id: OperatingMode.ECONOMIC, label: "Economic Dispatch", desc: "Maximize dollar operating margin (USD/hour)" },
    { id: OperatingMode.LOAD_FOLLOWING, label: "Load Following", desc: "Modulate flow to track active grid load demand" },
  ];

  return (
    <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
      
      {/* 1. Control Sliders & Modes Panel */}
      <div className="xl:col-span-1 bg-[#1E293B]/40 border border-slate-700/80 rounded p-5 flex flex-col justify-between">
        <div>
          <h3 className="text-sm font-bold text-slate-300 mb-4 uppercase tracking-wider flex items-center gap-2">
            <Gauge className="w-4 h-4 text-blue-500" />
            Control Variables (Actuators)
          </h3>

          <div className="space-y-4">
            {/* Pressure */}
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-400 font-medium">Main Steam Pressure</span>
                <span className="font-mono text-blue-400 font-semibold">{pressure.toFixed(1)} bar</span>
              </div>
              <input
                type="range"
                min="90"
                max="190"
                step="1"
                value={pressure}
                onChange={(e) => onChangeControls({ pressure: parseFloat(e.target.value) })}
                className="w-full h-1 bg-slate-850 rounded appearance-none cursor-pointer accent-blue-500"
              />
              <div className="flex justify-between text-[10px] text-slate-500 mt-1">
                <span>90 bar (Min)</span>
                <span className="text-rose-400">Trip: &gt;180 bar</span>
                <span>190 bar (Max)</span>
              </div>
            </div>

            {/* Temperature */}
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-400 font-medium">Superheat Temperature</span>
                <span className="font-mono text-blue-400 font-semibold">{temperature.toFixed(0)} °C</span>
              </div>
              <input
                type="range"
                min="430"
                max="610"
                step="5"
                value={temperature}
                onChange={(e) => onChangeControls({ temperature: parseFloat(e.target.value) })}
                className="w-full h-1 bg-slate-850 rounded appearance-none cursor-pointer accent-blue-500"
              />
              <div className="flex justify-between text-[10px] text-slate-500 mt-1">
                <span>430 °C</span>
                <span className="text-rose-400 font-mono">Trip: &gt;600°C</span>
                <span>610 °C</span>
              </div>
            </div>

            {/* Mass Flow */}
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-400 font-medium">Steam Mass Flow Rate</span>
                <span className="font-mono text-blue-400 font-semibold">{massFlow.toFixed(1)} kg/s</span>
              </div>
              <input
                type="range"
                min="100"
                max="520"
                step="5"
                value={massFlow}
                onChange={(e) => onChangeControls({ massFlow: parseFloat(e.target.value) })}
                className="w-full h-1 bg-slate-850 rounded appearance-none cursor-pointer accent-blue-500"
              />
              <div className="flex justify-between text-[10px] text-slate-500 mt-1">
                <span>100 kg/s</span>
                <span className="text-rose-400">Trip: &gt;500 kg/s</span>
                <span>520 kg/s</span>
              </div>
            </div>

            {/* Ambient cooling water temperature */}
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-400 font-medium">Ambient Temperature (Cooling In)</span>
                <span className="font-mono text-slate-300">{ambientC.toFixed(1)} °C</span>
              </div>
              <input
                type="range"
                min="5"
                max="40"
                step="0.5"
                value={ambientC}
                onChange={(e) => onChangeControls({ ambientC: parseFloat(e.target.value) })}
                className="w-full h-1 bg-slate-850 rounded appearance-none cursor-pointer accent-slate-500"
              />
              <div className="flex justify-between text-[10px] text-slate-500 mt-1">
                <span>5 °C (Winter)</span>
                <span>40 °C (Heatwave)</span>
              </div>
            </div>

            {/* Active grid demand */}
            {activeMode === OperatingMode.LOAD_FOLLOWING && (
              <div className="pt-2 border-t border-slate-750">
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-amber-400 font-medium">Simulated Grid Load Demand</span>
                  <span className="font-mono text-amber-400 font-semibold">{demandMw.toFixed(0)} MW</span>
                </div>
                <input
                  type="range"
                  min="200"
                  max="500"
                  step="10"
                  value={demandMw}
                  onChange={(e) => onChangeControls({ demandMw: parseInt(e.target.value) })}
                  className="w-full h-1 bg-amber-950/40 rounded appearance-none cursor-pointer accent-amber-500"
                />
                <div className="flex justify-between text-[10px] text-slate-500 mt-1">
                  <span>200 MW (Valley)</span>
                  <span>500 MW (Peak)</span>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Optimisation Mode Selection */}
        <div className="mt-6 pt-5 border-t border-slate-700/60">
          <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-2.5">
            Optimisation Objective Mode
          </label>
          <div className="space-y-1.5 max-h-[140px] overflow-y-auto">
            {modesList.map((m) => (
              <button
                key={m.id}
                onClick={() => onSelectMode(m.id)}
                className={`w-full text-left px-3 py-1.5 rounded transition-all flex justify-between items-center ${
                  activeMode === m.id
                    ? "bg-blue-600/10 border border-blue-500/30 text-blue-300"
                    : "bg-slate-800/20 border border-transparent hover:bg-slate-800/40 text-slate-400"
                }`}
              >
                <div>
                  <span className="font-semibold block">{m.label}</span>
                  <span className="text-[10px] text-slate-500 block leading-tight">{m.desc}</span>
                </div>
                {activeMode === m.id && <div className="w-1.5 h-1.5 rounded-full bg-blue-400" />}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 2. Optimiser Targets / Comparison Panel */}
      <div className="xl:col-span-2 bg-[#1E293B]/40 border border-slate-700/80 rounded p-5 flex flex-col justify-between">
        <div>
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-sm font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-blue-400" />
              Real-time Optimizer Comparison
            </h3>
            <div className={`px-2 py-0.5 rounded text-[9px] font-mono font-bold ${
              optimiserStatus === "OPTIMAL_REGION" 
                ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" 
                : optimiserStatus === "SUB_OPTIMAL" 
                ? "bg-amber-500/10 text-amber-400 border border-amber-500/20"
                : optimiserStatus === "CRITICAL_LIMIT" 
                ? "bg-rose-500/10 text-rose-400 border border-rose-500/20 animate-pulse"
                : "bg-slate-500/10 text-slate-400 border border-slate-500/10"
            }`}>
              {optimiserStatus}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            {/* Net Power Output Card */}
            <div className="bg-slate-800/20 border border-slate-700/50 p-3 rounded">
              <div className="text-[11px] text-slate-400 uppercase font-semibold">Net Power Output</div>
              <div className="font-mono font-bold text-lg text-slate-200 mt-1">
                {performance.netElectricalOutputMw.toFixed(1)} MW
              </div>
              <div className="text-[10px] text-slate-500 mt-1.5 flex justify-between">
                <span>Optimised:</span>
                <span className="text-blue-400 font-semibold">{recommendation.predictedNetOutputMw.toFixed(1)} MW</span>
              </div>
            </div>

            {/* Net Efficiency Card */}
            <div className="bg-slate-800/20 border border-slate-700/50 p-3 rounded">
              <div className="text-[11px] text-slate-400 uppercase font-semibold">Net Plant Efficiency</div>
              <div className="font-mono font-bold text-lg text-slate-200 mt-1">
                {(performance.netPlantEfficiency * 100).toFixed(2)}%
              </div>
              <div className="text-[10px] text-slate-500 mt-1.5 flex justify-between">
                <span>Optimised:</span>
                <span className="text-blue-400 font-semibold">{(recommendation.predictedEfficiency * 100).toFixed(2)}%</span>
              </div>
            </div>

            {/* Net Heat Rate Card */}
            <div className="bg-slate-800/20 border border-slate-700/50 p-3 rounded">
              <div className="text-[11px] text-slate-400 uppercase font-semibold">Net Heat Rate</div>
              <div className="font-mono font-bold text-lg text-slate-200 mt-1">
                {performance.netHeatRate > 0 ? performance.netHeatRate.toFixed(0) : "0"} kJ/kWh
              </div>
              <div className="text-[10px] text-slate-500 mt-1.5 flex justify-between">
                <span>Optimised:</span>
                <span className="text-blue-400 font-semibold">
                  {recommendation.predictedHeatRate > 0 ? recommendation.predictedHeatRate.toFixed(0) : "0"} kJ
                </span>
              </div>
            </div>
          </div>

          {/* Detailed State comparison grid */}
          <div className="border border-slate-700/80 rounded overflow-hidden text-xs font-sans">
            <div className="grid grid-cols-4 bg-[#1E293B]/60 p-2.5 text-slate-400 font-semibold uppercase text-[10px] tracking-wider border-b border-slate-700">
              <span>Control Point</span>
              <span>Current Operating</span>
              <span>Target Optimum</span>
              <span className="text-right">Adjustment Delta</span>
            </div>
            
            {/* Pressure comparison */}
            <div className="grid grid-cols-4 p-2.5 border-b border-slate-700/50 items-center font-mono">
              <span className="text-slate-400 font-sans font-medium">Steam Pressure</span>
              <span className="text-slate-200">{pressure.toFixed(1)} bar</span>
              <span className="text-blue-400">{recommendation.targetSteamPressureBar.toFixed(1)} bar</span>
              <span className={`text-right ${recommendation.targetSteamPressureBar - pressure > 0 ? "text-emerald-400" : recommendation.targetSteamPressureBar - pressure < 0 ? "text-rose-400" : "text-slate-500"}`}>
                {(recommendation.targetSteamPressureBar - pressure).toFixed(1)} bar
              </span>
            </div>

            {/* Temperature comparison */}
            <div className="grid grid-cols-4 p-2.5 border-b border-slate-700/50 items-center font-mono">
              <span className="text-slate-400 font-sans font-medium">Steam Temp</span>
              <span className="text-slate-200">{temperature.toFixed(0)} °C</span>
              <span className="text-blue-400">{recommendation.targetSteamTemperatureC.toFixed(0)} °C</span>
              <span className={`text-right ${recommendation.targetSteamTemperatureC - temperature > 0 ? "text-emerald-400" : recommendation.targetSteamTemperatureC - temperature < 0 ? "text-rose-400" : "text-slate-500"}`}>
                {(recommendation.targetSteamTemperatureC - temperature).toFixed(0)} °C
              </span>
            </div>

            {/* Mass Flow comparison */}
            <div className="grid grid-cols-4 p-2.5 items-center font-mono">
              <span className="text-slate-400 font-sans font-medium">Steam Flow</span>
              <span className="text-slate-200">{massFlow.toFixed(1)} kg/s</span>
              <span className="text-blue-400">{recommendation.targetSteamMassFlowKgS.toFixed(1)} kg/s</span>
              <span className={`text-right ${recommendation.targetSteamMassFlowKgS - massFlow > 0 ? "text-emerald-400" : recommendation.targetSteamMassFlowKgS - massFlow < 0 ? "text-rose-400" : "text-slate-500"}`}>
                {(recommendation.targetSteamMassFlowKgS - massFlow).toFixed(1)} kg/s
              </span>
            </div>
          </div>

          {/* Active Safety Trips and Warnings Alert banner */}
          {(safety.hasTrip || safety.warnings.length > 0) && (
            <div className={`mt-4 p-3 rounded text-xs flex gap-2.5 items-start ${safety.hasTrip ? "bg-rose-950/20 border border-rose-500/20 text-rose-300" : "bg-amber-950/20 border border-amber-500/20 text-amber-300"}`}>
              <AlertTriangle className={`w-4 h-4 shrink-0 ${safety.hasTrip ? "text-rose-400" : "text-amber-400"}`} />
              <div>
                <span className="font-bold block uppercase">{safety.hasTrip ? "Turbine Interlock Safety Trip" : "Turbine Operating Warnings"}</span>
                <ul className="list-disc pl-4 mt-1 space-y-0.5">
                  {safety.trips.map((t, idx) => <li key={idx} className="font-semibold">{t}</li>)}
                  {safety.warnings.map((w, idx) => <li key={idx}>{w}</li>)}
                </ul>
              </div>
            </div>
          )}
        </div>

        {/* Dynamic Control recommendations footer */}
        <div className="mt-6 pt-4 border-t border-slate-700 bg-slate-800/20 p-4 rounded flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex-1">
            <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider block mb-1">
              Optimiser Decision Recommendation
            </span>
            <p className="text-xs text-slate-300 leading-relaxed">
              {recommendation.message}
            </p>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            {/* Sync control loops */}
            <button
              onClick={onApplyOptimal}
              className="px-4 py-2 bg-blue-600/15 border border-blue-500/30 rounded text-xs font-semibold text-blue-300 hover:bg-blue-600/25 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              Apply Optimum
            </button>

            {/* Run Gemini analysis */}
            <button
              onClick={onTriggerAiAdvisor}
              disabled={aiAdvisorLoading}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded text-xs font-semibold disabled:opacity-50 transition-all flex items-center gap-1.5 cursor-pointer"
            >
              <TrendingUp className="w-3.5 h-3.5" />
              {aiAdvisorLoading ? "Advisor analyzing..." : "AI Advisor Report"}
            </button>
          </div>
        </div>

      </div>

    </div>
  );
}
