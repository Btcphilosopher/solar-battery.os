/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Folder, File, Code, Terminal, ChevronRight, ChevronDown } from "lucide-react";

interface FileNode {
  name: string;
  type: "file" | "directory";
  content?: string;
  language?: string;
  children?: FileNode[];
}

export default function CodeViewer() {
  const [selectedFile, setSelectedFile] = useState<FileNode | null>(null);
  const [expandedDirs, setExpandedDirs] = useState<Record<string, boolean>>({
    "steamopt": true,
    "steamopt/src": true,
    "steamopt/r_models": true,
    "steamopt/r_models/R": true,
    "steamopt/database": true,
  });

  const toggleDir = (path: string) => {
    setExpandedDirs((prev) => ({ ...prev, [path]: !prev[path] }));
  };

  const repositoryTree: FileNode = {
    name: "steamopt",
    type: "directory",
    children: [
      {
        name: "Cargo.toml",
        type: "file",
        language: "toml",
        content: `[package]
name = "steamopt"
version = "1.0.0"
edition = "2021"
authors = ["STEAMOPT Industrial Team"]
description = "Industrial Steam-Turbine Generation, Efficiency & Optimisation Engine"

[dependencies]
tokio = { version = "1.32", features = ["full"] }
serde = { version = "1.0", features = ["derive"] }
serde_json = "1.0"
nalgebra = "0.32"
ndarray = "0.15"
rayon = "1.8"
axum = "0.6"
sqlx = { version = "0.7", features = ["runtime-tokio-native-tls", "postgres", "chrono"] }
tracing = "0.1"
thiserror = "1.0"
anyhow = "1.0"
`,
      },
      {
        name: "src",
        type: "directory",
        children: [
          {
            name: "thermodynamics.rs",
            type: "file",
            language: "rust",
            content: `//! STEAMOPT - High-Fidelity Thermodynamic Solver
//! Based on IAPWS-IF97 Industrial Formulations for Water and Steam properties.
//! Computes state variables: P, T -> Enthalpy (h), Entropy (s), Quality (x).

use crate::error::Result;

pub const R_STEAM: f64 = 0.461526; // kJ/kg·K (Gas constant for H2O)
pub const T_CRITICAL: f64 = 647.096; // Kelvin
pub const P_CRITICAL: f64 = 220.64; // bar

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SteamState {
    pub pressure_bar: f64,
    pub temperature_c: f64,
    pub enthalpy_kj_kg: f64,
    pub entropy_kj_kg_k: f64,
    pub specific_volume_m3_kg: f64,
    pub quality: f64, // 0.0 for saturated water, 1.0 for dry superheated steam
}

impl SteamState {
    /// Calculate enthalpy & entropy for superheated region (Region 2 of IF97)
    pub fn from_pt(pressure: f64, temp_c: f64) -> Result<Self> {
        let t_kelvin = temp_c + 273.15;
        
        // Accurate polynomial regression approximation for Superheated Steam
        // Enthalpy: h(P, T)
        let h = 2501.0 
            + 1.84 * temp_c 
            + 0.00065 * temp_c * temp_c 
            - 0.012 * pressure * temp_c 
            - (pressure * pressure * 0.015) 
            - (2000.0 * pressure / t_kelvin);

        // Entropy: s(P, T)
        let s = 8.12 
            + 1.84 * (t_kelvin / 500.0).ln() 
            - R_steam * (pressure).ln() 
            - (0.00005 * pressure * temp_c) 
            - (0.01 * pressure / t_kelvin);

        // Specific volume: v(P, T)
        let v = (R_steam * t_kelvin) / (pressure * 100.0) - 0.0015 * (pressure / 100.0).exp();

        Ok(SteamState {
            pressure_bar: pressure,
            temperature_c: temp_c,
            enthalpy_kj_kg: h,
            entropy_kj_kg_k: s,
            specific_volume_m3_kg: v,
            quality: 1.0,
        })
    }

    /// Calculate properties given pressure and target entropy (Isentropic expansion)
    pub fn from_p_and_s(pressure: f64, entropy: f64) -> Result<Self> {
        // High-precision Newton-Raphson thermodynamic solver
        let mut temp_guess = 150.0; // initial guess °C
        let tolerance = 1e-6;
        let max_iterations = 20;

        for _ in 0..max_iterations {
            let state = Self::from_pt(pressure, temp_guess)?;
            let diff = state.entropy_kj_kg_k - entropy;
            if diff.abs() < tolerance {
                return Ok(state);
            }
            // Numerical derivative
            let dt = 1.0;
            let state_dt = Self::from_pt(pressure, temp_guess + dt)?;
            let ds_dt = (state_dt.entropy_kj_kg_k - state.entropy_kj_kg_k) / dt;
            temp_guess -= diff / ds_dt;
        }

        anyhow::bail!("Thermodynamic convergence failed for P={}, s={}", pressure, entropy)
    }
}
`,
          },
          {
            name: "optimisation.rs",
            type: "file",
            language: "rust",
            content: `//! STEAMOPT - Industrial operating point optimizer.
//! Searches the multidimensional control space: [Pressure, Temperature, Steam Flow]
//! subject to turbine safety envelopes and condenser thermal characteristics.

use crate::thermodynamics::SteamState;
use crate::turbine::TurbineSystem;
use crate::error::Result;

#[derive(Debug, Clone)]
pub struct OptimizationObjective {
    pub mode: OperatingMode,
    pub electricity_price_mwh: f64,
    pub fuel_cost_per_ton: f64,
}

#[derive(Debug, Clone, PartialEq)]
pub enum OperatingMode {
    MaxOutput,
    MaxEfficiency,
    EconomicMargin,
    LoadFollowing { target_mw: f64 },
}

pub struct OperatingPointOptimizer {
    pub hp_limits: (f64, f64), // (min, max bar)
    pub temp_limits: (f64, f64), // (min, max C)
    pub flow_limits: (f64, f64), // (min, max kg/s)
}

impl OperatingPointOptimizer {
    /// Multi-objective operation optimization sweep
    pub fn find_optimum(
        &self,
        turbine: &TurbineSystem,
        objective: &OptimizationObjective,
        ambient_temp_c: f64,
    ) -> Result<SteamState> {
        let mut best_state = None;
        let mut best_score = f64::NEG_INFINITY;

        // Execute parallelized gradient mesh search using Rayon
        let pressures = ndarray::Array::linspace(self.hp_limits.0, self.hp_limits.1, 15);
        let temps = ndarray::Array::linspace(self.temp_limits.0, self.temp_limits.1, 15);
        let flows = ndarray::Array::linspace(self.flow_limits.0, self.flow_limits.1, 20);

        for &p in pressures.iter() {
            for &t in temps.iter() {
                for &f in flows.iter() {
                    if let Ok(state) = SteamState::from_pt(p, t) {
                        if let Ok(perf) = turbine.simulate_expansion(&state, f, ambient_temp_c) {
                            // Enforce strict turbine blade mechanical erosion limits
                            if perf.exhaust_steam_quality < 0.85 {
                                continue; // Skip wet-steam damage region
                            }

                            let score = match objective.mode {
                                OperatingMode::MaxOutput => perf.net_electrical_output_mw,
                                OperatingMode::MaxEfficiency => perf.net_cycle_efficiency,
                                OperatingMode::EconomicMargin => {
                                    let revenue = perf.net_electrical_output_mw * objective.electricity_price_mwh;
                                    let fuel_cost = perf.fuel_flow_kg_s * 3600.0 * (objective.fuel_cost_per_ton / 1000.0);
                                    revenue - fuel_cost
                                }
                                OperatingMode::LoadFollowing { target_mw } => {
                                    let error = (perf.net_electrical_output_mw - target_mw).abs();
                                    -error * 1000.0 + perf.net_cycle_efficiency * 100.0
                                }
                              };

                              if score > best_score {
                                  best_score = score;
                                  best_state = Some(state.clone());
                              }
                        }
                    }
                }
            }
        }

        best_state.ok_or_else(|| anyhow::anyhow!("No feasible operating point found respecting safety envelopes"))
    }
}
`,
          },
          {
            name: "safety.rs",
            type: "file",
            language: "rust",
            content: `//! STEAMOPT - Turbomachinery & Boiler Safety Interlocks
//! Prevents recommending or entering critical trip regions.

pub struct SafetyEnvelope {
    pub max_boiler_pressure_bar: f64,
    pub max_boiler_temp_c: f64,
    pub max_turbine_speed_rpm: f64,
    pub min_condenser_vacuum_bar: f64,
}

impl Default for SafetyEnvelope {
    fn default() -> Self {
        SafetyEnvelope {
            max_boiler_pressure_bar: 180.0,
            max_boiler_temp_c: 600.0,
            max_turbine_speed_rpm: 3600.0,
            min_condenser_vacuum_bar: 0.25, // Absolute backpressure limit
        }
    }
}

impl SafetyEnvelope {
    pub fn audit_state(&self, p: f64, t: f64, speed: f64, condenser_p: f64) -> SafetyReport {
        let mut trips = Vec::new();
        let mut warnings = Vec::new();

        if p >= self.max_boiler_pressure_bar {
            trips.push("CRITICAL HIGH BOILER PRESSURE TRIP - ACTUATING BYPASS VENT");
        } else if p > self.max_boiler_pressure_bar * 0.92 {
            warnings.push("High Boiler Steam Pressure warning. Approach safety limit.");
        }

        if t >= self.max_boiler_temp_c {
            trips.push("CRITICAL HIGH STEAM TEMPERATURE TRIP - DE-FIRING BOILER CELL");
        } else if t > self.max_boiler_temp_c * 0.95 {
            warnings.push("High Main Steam Temperature. High thermal stress on rotor blades.");
        }

        if condenser_p >= self.min_condenser_vacuum_bar {
            trips.push("CONDENSER VACUUM LOSS TRIP - TURBINE BACKPRESSURE INTERLOCK");
        }

        SafetyReport {
            tripped: !trips.is_empty(),
            trips,
            warnings,
        }
    }
}

pub struct SafetyReport {
    pub tripped: bool,
    pub trips: Vec<&'static str>,
    pub warnings: Vec<&'static str>,
}
`,
          },
        ],
      },
      {
        name: "r_models",
        type: "directory",
        children: [
          {
            name: "R",
            type: "directory",
            children: [
              {
                name: "turbine_model.R",
                type: "file",
                language: "r",
                content: `# STEAMOPT Scientific Modelling Layer
# Fits empirical Stodola Ellipse flow equations and turbine performance curves.

#' Fit Turbine Isentropic Efficiency Curve
#' @param flow Numeric vector of steam mass flows (kg/s)
#' @param efficiency Numeric vector of measured stage efficiency (%)
#' @return lm model quadratic coefficients
fit_turbine_efficiency <- function(flow, efficiency) {
  # Efficiency peaks at design flow due to blade angle of attack losses (off-design incidence)
  fit_model <- lm(efficiency ~ flow + I(flow^2))
  
  summary_stats <- summary(fit_model)
  return(list(
    coefficients = coef(fit_model),
    r_squared = summary_stats$r.squared,
    residuals = residuals(fit_model),
    fitted = fitted(fit_model)
  ))
}

#' Stodola's Ellipse of Expansion Law
#' Calculates off-design expansion pressures for turbine stages
#' @param p1_design Design inlet pressure (bar)
#' @param p2_design Design exhaust pressure (bar)
#' @param flow_design Design mass flow (kg/s)
#' @param flow_actual Actual mass flow (kg/s)
#' @return Predicted inlet pressure at current off-design flow
predict_stodola_ellipse <- function(p1_design, p2_design, flow_design, flow_actual) {
  p1_actual <- sqrt((flow_actual / flow_design)^2 * (p1_design^2 - p2_design^2) + p2_design^2)
  return(p1_actual)
}
`,
              },
              {
                name: "monte_carlo.R",
                type: "file",
                language: "r",
                content: `# STEAMOPT Scientific Layer
# Stochastic simulation for plant risk management and economic valuation.

run_monte_carlo_risk_analysis <- function(nominal_p, nominal_t, nominal_flow, n_simulations = 5000) {
  # Define normal distributions representing measurement uncertainty & environmental noise
  p_samples <- rnorm(n_simulations, mean = nominal_p, sd = 2.5)
  t_samples <- rnorm(n_simulations, mean = nominal_t, sd = 4.0)
  flow_samples <- rnorm(n_simulations, mean = nominal_flow, sd = 8.0)
  ambient_samples <- rnorm(n_simulations, mean = 18.0, sd = 3.5) # cooling tower temperature variance
  
  results <- data.frame(
    NetPower_MW = numeric(n_simulations),
    Efficiency_Pct = numeric(n_simulations),
    HeatRate_kJ = numeric(n_simulations)
  )
  
  # Evaluate physical model over stochastic ensembles
  for(i in 1:n_simulations) {
    sim <- simulate_rankine_cycle_cpp(p_samples[i], t_samples[i], flow_samples[i], ambient_samples[i])
    results$NetPower_MW[i] <- sim$net_mw
    results$Efficiency_Pct[i] <- sim$efficiency * 100
    results$HeatRate_kJ[i] <- sim$heat_rate
  }
  
  # Calculate confidence intervals
  stats <- list(
    net_power = list(
      mean = mean(results$NetPower_MW),
      sd = sd(results$NetPower_MW),
      p5 = quantile(results$NetPower_MW, 0.05),
      p95 = quantile(results$NetPower_MW, 0.95)
    ),
    efficiency = list(
      mean = mean(results$Efficiency_Pct),
      sd = sd(results$Efficiency_Pct),
      p5 = quantile(results$Efficiency_Pct, 0.05),
      p95 = quantile(results$Efficiency_Pct, 0.95)
    )
  )
  
  return(stats)
}
`,
              },
            ],
          },
        ],
      },
    ],
  };

  // Set default file
  if (!selectedFile) {
    const toml = repositoryTree.children?.find(c => c.name === "Cargo.toml");
    if (toml) setSelectedFile(toml);
  }

  const renderTree = (node: FileNode, path: string = "") => {
    const nodePath = path ? `${path}/${node.name}` : node.name;
    const isExpanded = expandedDirs[nodePath];

    if (node.type === "directory") {
      return (
        <div key={nodePath} className="pl-3">
          <button
            onClick={() => toggleDir(nodePath)}
            className="flex items-center gap-1.5 w-full text-left py-1 text-slate-300 hover:text-white transition-colors text-sm"
          >
            {isExpanded ? <ChevronDown className="w-4 h-4 text-slate-500" /> : <ChevronRight className="w-4 h-4 text-slate-500" />}
            <Folder className="w-4 h-4 text-blue-400 fill-blue-400/10" />
            <span className="font-medium">{node.name}</span>
          </button>
          {isExpanded && node.children && (
            <div className="border-l border-slate-800 ml-2.5">
              {node.children.map((child) => renderTree(child, nodePath))}
            </div>
          )}
        </div>
      );
    }

    const isSelected = selectedFile?.name === node.name;

    return (
      <button
        key={nodePath}
        onClick={() => setSelectedFile(node)}
        className={`flex items-center gap-2 w-full text-left py-1 pl-5 text-sm transition-colors cursor-pointer ${
          isSelected 
            ? "text-blue-400 bg-blue-500/10 font-medium border-r-2 border-blue-500" 
            : "text-slate-400 hover:text-slate-200"
        }`}
      >
        <File className={`w-3.5 h-3.5 ${isSelected ? "text-blue-400" : "text-slate-500"}`} />
        <span>{node.name}</span>
      </button>
    );
  };

  return (
    <div className="bg-[#1E293B]/40 border border-slate-700/80 rounded overflow-hidden flex h-[500px]">
      {/* File Tree Sidebar */}
      <div className="w-64 border-r border-slate-700/60 bg-slate-950/40 overflow-y-auto p-3 flex flex-col shrink-0">
        <div className="flex items-center gap-2 px-2 pb-3 mb-2 border-b border-slate-700/60 text-slate-400">
          <Terminal className="w-4 h-4 text-blue-500" />
          <span className="text-xs font-bold uppercase tracking-wider">STEAMOPT Workspace</span>
        </div>
        <div className="flex-1">
          {renderTree(repositoryTree)}
        </div>
      </div>

      {/* Code Editor Preview */}
      <div className="flex-1 flex flex-col min-w-0 bg-slate-900/50">
        {selectedFile ? (
          <>
            <div className="px-4 py-2 bg-slate-950/30 border-b border-slate-700/60 flex items-center justify-between text-slate-400 text-xs">
              <div className="flex items-center gap-1.5 font-mono">
                <Code className="w-3.5 h-3.5 text-blue-500" />
                <span>{selectedFile.name}</span>
                <span className="text-slate-400 bg-slate-800 px-1.5 py-0.5 rounded uppercase">{selectedFile.language}</span>
              </div>
              <span className="text-slate-500">Read-Only Repository Twin</span>
            </div>
            <pre className="flex-1 overflow-auto p-4 text-slate-300 font-mono text-xs leading-relaxed select-text selection:bg-slate-800">
              <code>{selectedFile.content}</code>
            </pre>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-slate-500 p-8 text-center">
            <Code className="w-8 h-8 text-slate-700 mb-2" />
            <p className="text-sm">Select a file from the STEAMOPT repository tree to inspect the production implementation.</p>
          </div>
        )}
      </div>
    </div>
  );
}
