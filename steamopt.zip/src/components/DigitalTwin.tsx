/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { CycleSimulationResult, PlantParameters } from "../types";
import { Flame, Waves, Gauge, Zap, Hammer, RotateCcw } from "lucide-react";

interface DigitalTwinProps {
  simResult: CycleSimulationResult;
  params: PlantParameters;
  onUpdateParams: (newParams: Partial<PlantParameters>) => void;
}

export default function DigitalTwin({ simResult, params, onUpdateParams }: DigitalTwinProps) {
  const [hoveredComponent, setHoveredComponent] = useState<string | null>(null);
  const [selectedComponent, setSelectedComponent] = useState<string>("Turbines");

  const { states, performance, inputs } = simResult;

  // Component description card helper
  const getComponentData = (id: string) => {
    switch (id) {
      case "Boiler":
        return {
          title: "Steam Generator / Boiler",
          icon: <Flame className="w-5 h-5 text-red-500" />,
          details: [
            { label: "Main Fuel Flow", value: `${performance.boilerFuelFlowKgS.toFixed(1)} kg/s` },
            { label: "Thermal Fuel Input", value: `${performance.boilerHeatInputMw.toFixed(1)} MWt` },
            { label: "Steam Pressure", value: `${states.inlet.pressure.toFixed(1)} bar` },
            { label: "Steam Temperature", value: `${states.inlet.temperature.toFixed(1)} °C` },
            { label: "Feedwater Temp (In)", value: `${inputs.demandMw > 0 ? params.feedwaterTempC : 0} °C` },
            { label: "Boiler Efficiency", value: `${params.boilerEfficiency.toFixed(1)}%` },
          ],
          controls: (
            <div className="mt-3 pt-3 border-t border-slate-700/60">
              <label className="text-[11px] text-slate-400 block mb-1">Boiler Efficiency (%)</label>
              <input
                type="range"
                min="70"
                max="95"
                step="0.5"
                value={params.boilerEfficiency}
                onChange={(e) => onUpdateParams({ boilerEfficiency: parseFloat(e.target.value) })}
                className="w-full accent-blue-500 h-1 bg-slate-800 rounded appearance-none"
              />
              <div className="flex justify-between text-[10px] text-slate-500 mt-1">
                <span>70%</span>
                <span>Current: {params.boilerEfficiency}%</span>
                <span>95%</span>
              </div>
            </div>
          )
        };
      case "Turbines":
        return {
          title: "Multi-Stage Expansion Turbine",
          icon: <Hammer className="w-5 h-5 text-teal-400" />,
          details: [
            { label: "HP Stage Efficiency", value: `${params.hpTurbineEfficiency.toFixed(1)}%` },
            { label: "IP Stage Efficiency", value: `${params.ipTurbineEfficiency.toFixed(1)}%` },
            { label: "LP Stage Efficiency", value: `${params.lpTurbineEfficiency.toFixed(1)}%` },
            { label: "Total Shaft Work", value: `${performance.netShaftWorkMw.toFixed(1)} MW` },
            { label: "Exhaust Quality (LP)", value: `${(states.afterLP.quality * 100).toFixed(1)}%` },
            { label: "Steam Exhaust Velocity", value: "310 m/s" },
          ],
          controls: (
            <div className="mt-3 pt-3 border-t border-slate-700/60 space-y-3">
              <div>
                <label className="text-[11px] text-slate-400 block mb-0.5">HP Isentropic Efficiency (%)</label>
                <input
                  type="range"
                  min="75"
                  max="94"
                  step="0.5"
                  value={params.hpTurbineEfficiency}
                  onChange={(e) => onUpdateParams({ hpTurbineEfficiency: parseFloat(e.target.value) })}
                  className="w-full accent-blue-500 h-1 bg-slate-800 rounded appearance-none"
                />
              </div>
              <div>
                <label className="text-[11px] text-slate-400 block mb-0.5">LP Isentropic Efficiency (%)</label>
                <input
                  type="range"
                  min="75"
                  max="94"
                  step="0.5"
                  value={params.lpTurbineEfficiency}
                  onChange={(e) => onUpdateParams({ lpTurbineEfficiency: parseFloat(e.target.value) })}
                  className="w-full accent-blue-500 h-1 bg-slate-800 rounded appearance-none"
                />
              </div>
            </div>
          )
        };
      case "Condenser":
        return {
          title: "Surface Condenser & Cooling",
          icon: <Waves className="w-5 h-5 text-blue-400" />,
          details: [
            { label: "Condensing Backpressure", value: `${states.afterLP.pressure.toFixed(3)} bar` },
            { label: "Condensing Temp", value: `${states.condenser.temperature.toFixed(1)} °C` },
            { label: "Cooling Water Temp (In)", value: `${inputs.ambientTempC.toFixed(1)} °C` },
            { label: "Cooling Water Flow", value: `${params.coolingWaterFlowM3h.toLocaleString()} m³/h` },
            { label: "Total Heat Rejected", value: `${performance.condenserHeatRejectionMw.toFixed(1)} MWt` },
          ],
          controls: (
            <div className="mt-3 pt-3 border-t border-slate-700/60 space-y-3">
              <div>
                <label className="text-[11px] text-slate-400 block mb-1">Cooling Water Flow (m³/h)</label>
                <input
                  type="range"
                  min="10000"
                  max="45000"
                  step="500"
                  value={params.coolingWaterFlowM3h}
                  onChange={(e) => onUpdateParams({ coolingWaterFlowM3h: parseInt(e.target.value) })}
                  className="w-full accent-blue-500 h-1 bg-slate-800 rounded appearance-none"
                />
                <div className="flex justify-between text-[10px] text-slate-500 mt-1">
                  <span>10k m³/h</span>
                  <span>{params.coolingWaterFlowM3h.toLocaleString()}</span>
                  <span>45k m³/h</span>
                </div>
              </div>
            </div>
          )
        };
      case "Generator":
        return {
          title: "Turbo-Generator Module",
          icon: <Zap className="w-5 h-5 text-yellow-500" />,
          details: [
            { label: "Gross Electrical Power", value: `${performance.grossElectricalOutputMw.toFixed(1)} MWe` },
            { label: "Generator Efficiency", value: `${params.generatorEfficiency.toFixed(1)}%` },
            { label: "Rotational Speed", value: "3,000 RPM (50Hz)" },
            { label: "Generator Copper Loss", value: `${(performance.grossElectricalOutputMw * (1 - params.generatorEfficiency/100)).toFixed(2)} MW` },
            { label: "Rotor Core Temp", value: `${(65 + performance.grossElectricalOutputMw * 0.12).toFixed(1)} °C` },
          ],
          controls: (
            <div className="mt-3 pt-3 border-t border-slate-700/60">
              <label className="text-[11px] text-slate-400 block mb-1">Generator Efficiency (%)</label>
              <input
                type="range"
                min="94"
                max="99.5"
                step="0.1"
                value={params.generatorEfficiency}
                onChange={(e) => onUpdateParams({ generatorEfficiency: parseFloat(e.target.value) })}
                className="w-full accent-yellow-500 h-1 bg-slate-800 rounded appearance-none"
              />
              <div className="flex justify-between text-[10px] text-slate-500 mt-1">
                <span>94%</span>
                <span>Current: {params.generatorEfficiency}%</span>
                <span>99.5%</span>
              </div>
            </div>
          )
        };
      case "Pump":
      default:
        return {
          title: "Feedwater Pump (BFP)",
          icon: <Gauge className="w-5 h-5 text-slate-400" />,
          details: [
            { label: "Pump Consumption", value: `${performance.pumpWorkMw.toFixed(2)} MW` },
            { label: "Mass Flow rate", value: `${states.inlet.massFlow.toFixed(1)} kg/s` },
            { label: "Isentropic Head", value: `${(states.inlet.pressure * 10).toFixed(1)} m H2O` },
            { label: "BFP Efficiency", value: "80.0%" },
          ],
          controls: (
            <div className="mt-3 pt-3 border-t border-slate-700/60">
              <span className="text-[11px] text-slate-400 leading-relaxed block">
                The Boiler Feed Pump (BFP) consumes raw shaft or electrical energy to compress the condensed water up to the boiler operating pressure ({inputs.steamPressureBar.toFixed(1)} bar).
              </span>
            </div>
          )
        };
    }
  };

  const compData = getComponentData(selectedComponent);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Schematic SVG */}
      <div className="lg:col-span-2 bg-[#1E293B]/40 border border-slate-700/80 rounded p-5 flex flex-col justify-between min-h-[420px] relative overflow-hidden select-none">
        <div className="flex justify-between items-center mb-3">
          <div className="flex items-center gap-2">
            <div className="w-2.5 h-2.5 bg-blue-500 rounded-full animate-ping" />
            <span className="text-xs font-bold text-slate-400 tracking-wider uppercase">Active Telemetry Diagram</span>
          </div>
          <span className="text-[10px] text-slate-500 font-mono">Click components to inspect</span>
        </div>

        {/* The Vector Diagram */}
        <div className="flex-1 flex items-center justify-center p-2">
          <svg viewBox="0 0 760 340" className="w-full h-auto max-h-[300px]">
            {/* Flow Animations (Dashed moving stroke) */}
            <defs>
              <linearGradient id="boilerGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#f43f5e" stopOpacity="0.25" />
                <stop offset="100%" stopColor="#ef4444" stopOpacity="0.05" />
              </linearGradient>
              <linearGradient id="condGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor="#2563eb" stopOpacity="0.1" />
                <stop offset="100%" stopColor="#3b82f6" stopOpacity="0.2" />
              </linearGradient>
            </defs>

            {/* STEAM CYCLE CONNECTING LINES */}
            {/* 1. Main steam line (Boiler -> HP Turbine) */}
            <path
              d="M 120 110 L 260 110"
              fill="none"
              stroke={states.inlet.pressure > 130 ? "#ef4444" : "#f43f5e"}
              strokeWidth="4"
            />
            <path
              d="M 120 110 L 260 110"
              fill="none"
              stroke="#fff"
              strokeWidth="4"
              strokeDasharray="8,12"
              className="animate-[dash_1s_linear_infinite]"
              style={{ strokeDashoffset: -10 }}
            />

            {/* Reheat Line (HP Turbine -> Reheater -> IP Turbine) */}
            <path
              d="M 300 135 L 300 170 L 120 170 L 120 190 L 330 190 L 330 200"
              fill="none"
              stroke="#fb7185"
              strokeWidth="3"
            />

            {/* 2. Expansion Turbine stage drops (IP -> LP -> Condenser) */}
            <path
              d="M 350 200 L 350 230"
              fill="none"
              stroke="#38bdf8"
              strokeWidth="4"
              strokeDasharray="6,8"
              className="animate-[dash_1.5s_linear_infinite]"
            />

            {/* 3. Saturated Condensate Line (Condenser -> Pump -> Feedwater -> Boiler) */}
            <path
              d="M 350 270 L 350 300 L 120 300 L 120 220"
              fill="none"
              stroke="#3b82f6"
              strokeWidth="3.5"
            />
            <path
              d="M 350 270 L 350 300 L 120 300 L 120 220"
              fill="none"
              stroke="#60a5fa"
              strokeWidth="3.5"
              strokeDasharray="6,12"
              className="animate-[dash_2.5s_linear_infinite]"
              style={{ strokeDashoffset: 10 }}
            />

            {/* Shaft line (Turbines -> Generator) */}
            <line x1="280" y1="110" x2="560" y2="110" stroke="#475569" strokeWidth="6" strokeDasharray="1,2" />

            {/* Component 1: Boiler / Steam Generator */}
            <g
              onClick={() => setSelectedComponent("Boiler")}
              onMouseEnter={() => setHoveredComponent("Boiler")}
              onMouseLeave={() => setHoveredComponent(null)}
              className="cursor-pointer group"
            >
              <rect
                x="40"
                y="50"
                width="80"
                height="170"
                rx="6"
                fill="url(#boilerGrad)"
                stroke={selectedComponent === "Boiler" ? "#f43f5e" : hoveredComponent === "Boiler" ? "#fda4af" : "#9f1239"}
                strokeWidth={selectedComponent === "Boiler" ? 2.5 : 1.5}
                className="transition-all"
              />
              <text x="80" y="80" fill="#fda4af" fontSize="11" textAnchor="middle" className="font-bold uppercase tracking-wider">Boiler</text>
              <Flame className="w-5 h-5 text-red-500 transition-transform group-hover:scale-110" x="70" y="95" />
              <text x="80" y="155" fill="#f43f5e" fontSize="10" fontWeight="bold" textAnchor="middle">{states.inlet.pressure.toFixed(0)} bar</text>
              <text x="80" y="170" fill="#f43f5e" fontSize="10" textAnchor="middle">{states.inlet.temperature.toFixed(0)} °C</text>
              <text x="80" y="195" fill="#9f1239" fontSize="8" textAnchor="middle" className="italic">Fired Steam</text>
            </g>

            {/* Component 2: Turbines (HP / IP / LP Stages) */}
            <g
              onClick={() => setSelectedComponent("Turbines")}
              onMouseEnter={() => setHoveredComponent("Turbines")}
              onMouseLeave={() => setHoveredComponent(null)}
              className="cursor-pointer group"
            >
              {/* HP Turbine Shape (Trapezoid pointing right) */}
              <polygon
                points="260,85 300,95 300,125 260,135"
                fill="#1e293b"
                stroke={selectedComponent === "Turbines" ? "#2dd4bf" : hoveredComponent === "Turbines" ? "#5eead4" : "#115e59"}
                strokeWidth={selectedComponent === "Turbines" ? 2.5 : 1.5}
                className="transition-all"
              />
              <text x="280" y="113" fill="#2dd4bf" fontSize="8" fontWeight="bold" textAnchor="middle">HP</text>

              {/* IP / LP Stage Shape (Large trapezoid) */}
              <polygon
                points="315,175 365,185 365,245 315,255"
                fill="#1e293b"
                stroke={selectedComponent === "Turbines" ? "#2dd4bf" : hoveredComponent === "Turbines" ? "#5eead4" : "#115e59"}
                strokeWidth={selectedComponent === "Turbines" ? 2.5 : 1.5}
                className="transition-all"
              />
              <text x="340" y="218" fill="#2dd4bf" fontSize="10" fontWeight="bold" textAnchor="middle">IP/LP</text>

              <text x="315" y="65" fill="#5eead4" fontSize="11" textAnchor="middle" className="font-bold uppercase tracking-wider">Turbine</text>
              <text x="315" y="152" fill="#2dd4bf" fontSize="9" textAnchor="middle">Eff: {((params.hpTurbineEfficiency + params.lpTurbineEfficiency)/2).toFixed(1)}%</text>
            </g>

            {/* Component 3: Generator */}
            <g
              onClick={() => setSelectedComponent("Generator")}
              onMouseEnter={() => setHoveredComponent("Generator")}
              onMouseLeave={() => setHoveredComponent(null)}
              className="cursor-pointer group"
            >
              <circle
                cx="560"
                cy="110"
                r="35"
                fill="#1e293b"
                stroke={selectedComponent === "Generator" ? "#eab308" : hoveredComponent === "Generator" ? "#fef08a" : "#854d0e"}
                strokeWidth={selectedComponent === "Generator" ? 2.5 : 1.5}
                className="transition-all"
              />
              <text x="560" y="105" fill="#fef08a" fontSize="11" textAnchor="middle" className="font-bold uppercase tracking-wider">Gen</text>
              <Zap className="w-5 h-5 text-yellow-500" x="550" y="112" />
              <text x="560" y="165" fill="#eab308" fontSize="12" fontWeight="bold" textAnchor="middle">{performance.grossElectricalOutputMw.toFixed(1)} MWe</text>
              <text x="560" y="180" fill="#854d0e" fontSize="8" textAnchor="middle" className="italic">3,000 RPM</text>
            </g>

            {/* Component 4: Condenser */}
            <g
              onClick={() => setSelectedComponent("Condenser")}
              onMouseEnter={() => setHoveredComponent("Condenser")}
              onMouseLeave={() => setHoveredComponent(null)}
              className="cursor-pointer group"
            >
              <rect
                x="310"
                y="245"
                width="80"
                height="50"
                rx="4"
                fill="url(#condGrad)"
                stroke={selectedComponent === "Condenser" ? "#3b82f6" : hoveredComponent === "Condenser" ? "#93c5fd" : "#1e40af"}
                strokeWidth={selectedComponent === "Condenser" ? 2.5 : 1.5}
                className="transition-all"
              />
              <text x="350" y="265" fill="#93c5fd" fontSize="9" fontWeight="bold" textAnchor="middle" className="uppercase tracking-wider">Condenser</text>
              <Waves className="w-4 h-4 text-blue-400" x="342" y="272" />
              <text x="350" y="315" fill="#3b82f6" fontSize="10" fontWeight="bold" textAnchor="middle">{states.afterLP.pressure.toFixed(3)} bar</text>
            </g>

            {/* Component 5: Boiler Feedwater Pump (BFP) */}
            <g
              onClick={() => setSelectedComponent("Pump")}
              onMouseEnter={() => setHoveredComponent("Pump")}
              onMouseLeave={() => setHoveredComponent(null)}
              className="cursor-pointer group"
            >
              <circle
                cx="120"
                cy="220"
                r="18"
                fill="#0f172a"
                stroke={selectedComponent === "Pump" ? "#94a3b8" : hoveredComponent === "Pump" ? "#cbd5e1" : "#475569"}
                strokeWidth={selectedComponent === "Pump" ? 2.5 : 1.5}
                className="transition-all"
              />
              <text x="120" y="213" fill="#cbd5e1" fontSize="8" textAnchor="middle" className="font-bold">BFP</text>
              <Gauge className="w-3.5 h-3.5 text-slate-400" x="113" y="218" />
              <text x="120" y="252" fill="#64748b" fontSize="8" textAnchor="middle">{performance.pumpWorkMw.toFixed(2)} MW</text>
            </g>

            {/* GRID OUTPUT CONNECTION (Visual) */}
            <path d="M 595 110 L 680 110 L 680 150" fill="none" stroke="#475569" strokeWidth="2.5" />
            <polygon points="675,150 685,150 680,165" fill="#64748b" />
            <text x="680" y="100" fill="#64748b" fontSize="8" textAnchor="middle">GRID BUS</text>
          </svg>
        </div>

        {/* Quick parameters readout footer */}
        <div className="grid grid-cols-4 gap-2 pt-3 border-t border-slate-700/60 text-center font-mono text-[10px] text-slate-500">
          <div>
            <div className="text-slate-400 font-bold">{states.inlet.enthalpy.toFixed(1)} kJ/kg</div>
            <div>Inlet Enthalpy (h)</div>
          </div>
          <div>
            <div className="text-slate-400 font-bold">{states.afterLP.enthalpy.toFixed(1)} kJ/kg</div>
            <div>Exhaust Enthalpy</div>
          </div>
          <div>
            <div className="text-slate-400 font-bold">{(states.afterLP.quality * 100).toFixed(1)}%</div>
            <div>Steam Quality (x)</div>
          </div>
          <div>
            <div className="text-slate-400 font-bold">{(performance.netPlantEfficiency * 100).toFixed(2)}%</div>
            <div>Net Plant Efficiency</div>
          </div>
        </div>
      </div>

      {/* Inspection Sidebar Card */}
      <div className="bg-[#1E293B]/40 border border-slate-700/80 rounded p-5 flex flex-col justify-between">
        <div>
          <div className="flex items-center gap-2 pb-3 mb-3 border-b border-slate-700/60">
            {compData.icon}
            <h3 className="text-sm font-bold text-white tracking-wide">{compData.title}</h3>
          </div>

          <div className="space-y-2.5">
            {compData.details.map((det, index) => (
              <div key={index} className="flex justify-between items-center text-xs">
                <span className="text-slate-400">{det.label}</span>
                <span className="font-mono font-semibold text-slate-200">{det.value}</span>
              </div>
            ))}
          </div>

          {/* Render component sliders/controls */}
          {compData.controls}
        </div>

        <div className="mt-6 pt-3 border-t border-slate-700/60">
          <div className="text-[11px] text-slate-400 flex items-center justify-between">
            <span>Overall Plant Status</span>
            <span className="text-teal-400 font-bold">SYNCHRONIZED</span>
          </div>
          <div className="flex justify-between items-center mt-2">
            <span className="text-[10px] text-slate-500">Grid Freq</span>
            <span className="font-mono text-xs text-slate-300">50.00 Hz</span>
          </div>
          <div className="flex justify-between items-center mt-1">
            <span className="text-[10px] text-slate-500">Rotor Vibration</span>
            <span className="font-mono text-xs text-green-400">12.5 µm (Safe)</span>
          </div>
        </div>
      </div>
    </div>
  );
}
