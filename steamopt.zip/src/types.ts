/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum OperatingMode {
  MAX_OUTPUT = "MAX_OUTPUT",
  MAX_EFFICIENCY = "MAX_EFFICIENCY",
  MIN_HEAT_RATE = "MIN_HEAT_RATE",
  FLEXIBLE_GENERATION = "FLEXIBLE_GENERATION",
  BASE_LOAD = "BASE_LOAD",
  LOAD_FOLLOWING = "LOAD_FOLLOWING",
  ECONOMIC = "ECONOMIC",
  BALANCED = "BALANCED",
}

export interface SteamState {
  pressure: number; // bar
  temperature: number; // °C
  massFlow: number; // kg/s
  enthalpy: number; // kJ/kg
  entropy: number; // kJ/kg·K
  quality: number; // 0 to 1 (wet steam) or 1 (dry/superheated)
  specificVolume: number; // m³/kg
}

export interface PlantParameters {
  boilerEfficiency: number; // %
  hpTurbineEfficiency: number; // %
  ipTurbineEfficiency: number; // %
  lpTurbineEfficiency: number; // %
  generatorEfficiency: number; // %
  mechanicalLossesMw: number; // MW
  condenserPressureBar: number; // bar
  coolingWaterTempC: number; // °C
  coolingWaterFlowM3h: number; // m³/h
  feedwaterTempC: number; // °C
  auxiliaryLoadBaseMw: number; // MW
  auxiliaryLoadFlowCoeff: number; // MW per kg/s steam
  fuelHeatValueMjKg: number; // MJ/kg (e.g., Coal = 24, Gas = 50)
  fuelCostPerTon: number; // USD per ton
  electricityPriceMwh: number; // USD/MWh
  waterCostPerM3: number; // USD/m³
}

export interface CycleSimulationResult {
  // Input parameters
  inputs: {
    steamPressureBar: number;
    steamTemperatureC: number;
    steamMassFlowKgS: number;
    ambientTempC: number;
    demandMw: number;
  };
  
  // Component States
  states: {
    inlet: SteamState;
    afterHP: SteamState;
    reheatInlet: SteamState;
    afterIP: SteamState;
    afterLP: SteamState;
    condenser: SteamState;
    feedwater: SteamState;
  };

  // Performance outputs
  performance: {
    boilerHeatInputMw: number;
    boilerFuelFlowKgS: number;
    hpWorkMw: number;
    ipWorkMw: number;
    lpWorkMw: number;
    grossWorkMw: number;
    pumpWorkMw: number;
    netShaftWorkMw: number;
    grossElectricalOutputMw: number;
    auxiliaryPowerMw: number;
    netElectricalOutputMw: number;
    thermalEfficiency: number; // Fraction 0-1
    netPlantEfficiency: number; // Fraction 0-1
    grossHeatRate: number; // kJ/kWh
    netHeatRate: number; // kJ/kWh
    incrementalHeatRate: number; // kJ/kWh
    steamConsumptionKgKwh: number;
    condenserHeatRejectionMw: number;
  };

  // Status flags
  safety: {
    hasTrip: boolean;
    trips: string[];
    warnings: string[];
  };

  optimiserStatus: "OPTIMAL_REGION" | "SUB_OPTIMAL" | "CRITICAL_LIMIT" | "STABLE";
}

export interface OptimizationRecommendation {
  mode: OperatingMode;
  targetSteamPressureBar: number;
  targetSteamTemperatureC: number;
  targetSteamMassFlowKgS: number;
  targetCondenserPressureBar: number;
  predictedNetOutputMw: number;
  predictedEfficiency: number;
  predictedHeatRate: number;
  expectedMarginGainUsdHour: number;
  constraintsRespected: boolean;
  message: string;
}

export interface MonteCarloSummary {
  runsCount: number;
  netPower: MetricStats;
  thermalEfficiency: MetricStats;
  heatRate: MetricStats;
  hourlyRevenue: MetricStats;
}

export interface MetricStats {
  mean: number;
  median: number;
  stdDev: number;
  p5: number;
  p95: number;
  min: number;
  max: number;
}

export interface TelemetryLog {
  id: string;
  timestamp: string;
  steam_pressure_bar: number;
  steam_temperature_c: number;
  steam_mass_flow_kg_s: number;
  condenser_pressure_bar: number;
  gross_output_mw: number;
  net_output_mw: number;
  efficiency_pct: number;
  heat_rate_kj_kwh: number;
  margin_usd_h: number;
  status: string;
}

export interface CalibrationResult {
  parameter: string;
  rSquared: number;
  coefficients: {
    intercept: number;
    slope: number;
    quadratic?: number;
  };
  residuals: number[];
  fittedValues: number[];
  actualValues: number[];
}
