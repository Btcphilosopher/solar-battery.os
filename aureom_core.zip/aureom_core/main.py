#!/usr/bin/env python3
"""
AUREOM CORE — command-line demonstration.
============================================

Runs the final-deliverable demonstration described in the design brief
(§44): builds a large-reactor :class:`NuclearPowerStation`, runs a
grid-fluctuation scenario, and writes telemetry (CSV/JSON), the 8-panel
summary figure, and the engineering performance report to ``output/``.

Usage:
    python main.py [--scenario NAME] [--duration SECONDS] [--timestep SECONDS]
                    [--units N] [--reactor-power-mw MW] [--electrical-capacity-mw MW]
                    [--seed N] [--output-dir DIR]
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import scenarios  # noqa: F401 - registers the built-in scenario library
from plant.power_station import NuclearPowerStation
from simulation.scenario import available_scenarios
from visualisation.dashboards import render_text_dashboard

logging.basicConfig(level=logging.WARNING, format="%(levelname)s: %(message)s")
logger = logging.getLogger("aureom_core")


BANNER = r"""
AUREOM CORE
Large Reactor Digital Twin
---------------------------
"""


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="AUREOM CORE large-reactor digital-twin demonstration.")
    parser.add_argument("--scenario", default="grid_fluctuation", choices=None)
    parser.add_argument("--duration", type=float, default=3600.0)
    parser.add_argument("--timestep", type=float, default=0.1)
    parser.add_argument("--units", type=int, default=1)
    parser.add_argument("--reactor-power-mw", type=float, default=3400.0)
    parser.add_argument("--electrical-capacity-mw", type=float, default=1300.0)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output-dir", default="output")
    parser.add_argument("--list-scenarios", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    print(BANNER)

    if args.list_scenarios:
        print("Available scenarios:")
        for name in available_scenarios():
            print(f"  - {name}")
        return 0

    def step(label: str) -> None:
        print(f"{label:<32}", end="", flush=True)

    step("Initialising plant .............")
    station = NuclearPowerStation(
        units=args.units,
        reactor_power_mw=args.reactor_power_mw,
        electrical_capacity_mw=args.electrical_capacity_mw,
    )
    print("OK")

    step("Initialising reactor ...........")
    print("OK")
    step("Initialising thermal systems ...")
    print("OK")
    step("Initialising turbine ...........")
    print("OK")
    step("Initialising controls ..........")
    print("OK")
    step("Initialising protection ........")
    print("OK")

    print()
    print(f"Scenario: {args.scenario.upper()}")
    print(f"Duration: {args.duration:.0f} s")
    print(f"Timestep: {args.timestep:.3f} s")
    print()

    start = time.perf_counter()
    result = station.run(
        duration=args.duration,
        scenario=args.scenario,
        timestep=args.timestep,
        seed=args.seed,
    )
    elapsed = time.perf_counter() - start
    print(f"Simulation complete. ({elapsed:.2f} s wall-clock, {len(result.telemetry)} telemetry samples)")
    print()

    os.makedirs(args.output_dir, exist_ok=True)
    csv_path = os.path.join(args.output_dir, f"telemetry_{args.scenario}.csv")
    json_path = os.path.join(args.output_dir, f"telemetry_{args.scenario}.json")
    plot_path = os.path.join(args.output_dir, f"summary_{args.scenario}.png")

    result.to_csv(csv_path)
    result.to_json(json_path)
    result.plot(out_path=plot_path)

    print(f"Telemetry CSV:  {csv_path}")
    print(f"Telemetry JSON: {json_path}")
    print(f"Summary plot:   {plot_path}")
    print()

    report_text = result.report()
    report_path = os.path.join(args.output_dir, f"report_{args.scenario}.txt")
    with open(report_path, "w") as f:
        f.write(report_text)
    print(f"\nReport saved:   {report_path}")

    print()
    print(render_text_dashboard(result.telemetry[-1]))
    print()

    print("Causal chain (final sample):")
    final = result.telemetry[-1]
    print(f"  Reactivity ({final.total_reactivity * 1e5:+.1f} pcm)")
    print(f"    -> Fission/decay power ({final.reactor_fission_power_mw:,.0f} + {final.reactor_decay_power_mw:,.1f} MW)")
    print(f"    -> Fuel/coolant thermal mass (fuel {final.fuel_temperature_c:,.0f} degC, coolant {final.coolant_temperature_c:,.0f} degC)")
    print(f"    -> Primary coolant ({final.coolant_flow_kg_s:,.0f} kg/s, {final.pressurizer_pressure_mpa:.2f} MPa)")
    print(f"    -> Steam generator / main steam ({final.steam_pressure_mpa:.2f} MPa, {final.steam_flow_kg_s:,.0f} kg/s)")
    print(f"    -> Turbine ({final.turbine_power_mw:,.0f} MW mech, {final.turbine_speed_rad_s:.1f} rad/s)")
    print(f"    -> Generator / grid (gross {final.gross_electrical_power_mw:,.0f} MW, net {final.net_electrical_power_mw:,.0f} MW, {final.grid_frequency_hz:.3f} Hz)")
    print(f"    -> Demand feedback -> Control -> Reactor state (grid demand {final.grid_demand_mw:,.0f} MW)")
    print()

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
