"""
Grid interconnection model.
==============================

Top-level electrical subsystem model. Combines station auxiliary-load
accounting, the step-up transformer, the terminal-voltage proxy, and a
simple droop-based grid-frequency model into a single observable
:class:`~electrical.electrical_state.ElectricalState`.

    net_output   = gross_generator_output - auxiliary_consumption
    export_power = net_output * transformer_efficiency
    freq_target  = f_nominal + (export_power - grid_demand) / grid_stiffness
    d(freq)/dt   = (freq_target - freq) / swing_time_constant

The droop relation is the standard steady-state characteristic of a
synchronous generator on an interconnected grid (more generation than
demand raises frequency, and vice versa); the first-order lag towards
that target is a reduced-order stand-in for the full multi-machine swing
dynamics of a real power system.
"""

from __future__ import annotations

from dataclasses import dataclass

from config import GeneratorConfig, GridConfig
from electrical.electrical_state import ElectricalState
from electrical.generator_model import TerminalElectricalModel
from electrical.transformer import Transformer


@dataclass
class GridModel:
    grid_cfg: GridConfig
    generator_cfg: GeneratorConfig
    frequency_hz: float = 0.0

    def __post_init__(self) -> None:
        if self.frequency_hz == 0.0:
            self.frequency_hz = self.grid_cfg.nominal_frequency_hz
        self.terminal_model = TerminalElectricalModel(self.generator_cfg)
        self.transformer = Transformer(self.generator_cfg, self.grid_cfg)

    def auxiliary_power_mw(self, gross_power_mw: float) -> float:
        cfg = self.grid_cfg
        return cfg.auxiliary_fixed_load_mw + cfg.auxiliary_load_fraction_of_gross * max(gross_power_mw, 0.0)

    def step(self, gross_electrical_power_mw: float, grid_demand_mw: float, dt: float) -> ElectricalState:
        cfg = self.grid_cfg

        auxiliary_mw = self.auxiliary_power_mw(gross_electrical_power_mw)
        net_mw = max(gross_electrical_power_mw - auxiliary_mw, 0.0)
        export_mw = self.transformer.step(net_mw)

        voltage_pu = self.terminal_model.step(gross_electrical_power_mw, dt)

        frequency_target = cfg.nominal_frequency_hz + (export_mw - grid_demand_mw) / max(cfg.grid_stiffness_mw_per_hz, 1.0e-6)
        tau = max(cfg.swing_time_constant_s, 1.0e-3)
        self.frequency_hz += (frequency_target - self.frequency_hz) * (dt / tau)
        self.frequency_hz = max(0.5 * cfg.nominal_frequency_hz, min(self.frequency_hz, 1.5 * cfg.nominal_frequency_hz))

        return ElectricalState(
            gross_electrical_power_mw=gross_electrical_power_mw,
            auxiliary_power_mw=auxiliary_mw,
            net_electrical_power_mw=net_mw,
            export_power_mw=export_mw,
            terminal_voltage_pu=voltage_pu,
            grid_demand_mw=grid_demand_mw,
            grid_frequency_hz=self.frequency_hz,
            grid_voltage_pu=voltage_pu,
        )
