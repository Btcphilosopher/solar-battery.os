"""
Generator step-up transformer.
=================================

Applies a fixed transformer efficiency and an MVA-equivalent rating cap
between the generator terminals and the grid interconnection point.
"""

from __future__ import annotations

from dataclasses import dataclass

from config import GeneratorConfig, GridConfig


@dataclass
class Transformer:
    generator_cfg: GeneratorConfig
    grid_cfg: GridConfig

    def step(self, terminal_power_mw: float) -> float:
        rating_mw = self.generator_cfg.rated_electrical_power_mw * 1.1
        loaded_power = max(0.0, min(terminal_power_mw, rating_mw))
        return loaded_power * self.grid_cfg.transformer_efficiency
