"""
Grid demand / load-profile generator.
========================================

Deterministic demand-vs-time profiles used to drive load-following
scenarios. Every profile is a pure function of simulation time (and a
fixed random seed for the profiles that use pseudo-randomness), so the
same configuration always reproduces the same demand trace — required by
the platform's determinism guarantee (design brief §21, §34).

Supported profile kinds: constant, morning_ramp, evening_ramp,
sinusoidal, grid_fluctuation, industrial_load, custom.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Callable, Optional

import numpy as np


@dataclass
class LoadProfile:
    kind: str
    base_demand_mw: float
    amplitude_mw: float = 0.0
    period_s: float = 3600.0
    ramp_start_s: float = 300.0
    ramp_duration_s: float = 1800.0
    ramp_delta_mw: float = 0.0
    seed: int = 42
    custom_fn: Optional[Callable[[float], float]] = None
    _fluctuation_terms: list = field(default_factory=list, init=False, repr=False)
    _industrial_blocks: list = field(default_factory=list, init=False, repr=False)

    def __post_init__(self) -> None:
        rng = np.random.default_rng(self.seed)
        if self.kind == "grid_fluctuation":
            n_terms = 5
            for _ in range(n_terms):
                period = rng.uniform(20.0, 400.0)
                amplitude = self.amplitude_mw * rng.uniform(0.1, 0.35)
                phase = rng.uniform(0.0, 2.0 * math.pi)
                self._fluctuation_terms.append((period, amplitude, phase))
        elif self.kind == "industrial_load":
            n_blocks = 6
            t = 0.0
            for _ in range(n_blocks):
                duration = rng.uniform(180.0, 900.0)
                magnitude = rng.uniform(-1.0, 1.0) * self.amplitude_mw
                self._industrial_blocks.append((t, t + duration, magnitude))
                t += duration

    def demand_mw(self, t: float) -> float:
        if self.kind == "constant":
            return self.base_demand_mw

        if self.kind == "morning_ramp":
            return self.base_demand_mw + self._ramp(t, self.ramp_delta_mw)

        if self.kind == "evening_ramp":
            return self.base_demand_mw + self._ramp(t, -abs(self.ramp_delta_mw))

        if self.kind == "sinusoidal":
            omega = 2.0 * math.pi / max(self.period_s, 1.0e-6)
            return self.base_demand_mw + self.amplitude_mw * math.sin(omega * t)

        if self.kind == "grid_fluctuation":
            value = self.base_demand_mw
            for period, amplitude, phase in self._fluctuation_terms:
                value += amplitude * math.sin(2.0 * math.pi * t / period + phase)
            return value

        if self.kind == "industrial_load":
            value = self.base_demand_mw
            for start, end, magnitude in self._industrial_blocks:
                if start <= t < end:
                    value += magnitude
            return value

        if self.kind == "custom" and self.custom_fn is not None:
            return self.custom_fn(t)

        return self.base_demand_mw

    def _ramp(self, t: float, delta: float) -> float:
        if t <= self.ramp_start_s:
            return 0.0
        if t >= self.ramp_start_s + self.ramp_duration_s:
            return delta
        fraction = (t - self.ramp_start_s) / max(self.ramp_duration_s, 1.0e-6)
        return delta * fraction
