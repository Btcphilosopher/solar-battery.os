"""Observable state for the electrical / grid-interconnection subsystem."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class ElectricalState:
    gross_electrical_power_mw: float = 0.0
    auxiliary_power_mw: float = 0.0
    net_electrical_power_mw: float = 0.0
    export_power_mw: float = 0.0

    terminal_voltage_pu: float = 1.0

    grid_demand_mw: float = 0.0
    grid_frequency_hz: float = 50.0
    grid_voltage_pu: float = 1.0
