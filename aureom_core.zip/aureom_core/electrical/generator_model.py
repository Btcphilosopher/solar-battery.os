"""
Station-side electrical interconnection model.
=================================================

Distinct from the turbine-shaft-coupled conversion in
secondary/generator.py (which models the mechanical -> electrical energy
conversion at the machine), this module represents the generator as seen
from the station electrical system: a simplified terminal-voltage
regulator response used purely for observability of the electrical
subsystem, at fixed (near-unity) power factor.

    d(voltage_pu)/dt = (target_voltage_pu - voltage_pu) / tau
"""

from __future__ import annotations

from dataclasses import dataclass

from config import GeneratorConfig


@dataclass
class TerminalElectricalModel:
    cfg: GeneratorConfig
    voltage_pu: float = 1.0

    def step(self, electrical_power_mw: float, dt: float) -> float:
        cfg = self.cfg
        loading_fraction = electrical_power_mw / max(cfg.rated_electrical_power_mw, 1.0e-6)
        # Simplified AVR proxy: voltage droops slightly under heavy real
        # power loading at fixed assumed power factor, then is restored by
        # the automatic voltage regulator with a short time constant.
        target_voltage_pu = 1.0 - 0.01 * max(loading_fraction - 1.0, 0.0)
        self.voltage_pu += (target_voltage_pu - self.voltage_pu) * (dt / 2.0)
        self.voltage_pu = max(0.9, min(self.voltage_pu, 1.1))
        return self.voltage_pu
