"""
Efficiency and utilisation metrics (design brief §25).
"""

from __future__ import annotations

import numpy as np
import pandas as pd


def thermal_efficiency(df: pd.DataFrame) -> float:
    """Mean net_electrical / reactor_thermal, over samples with meaningful
    thermal power, expressed as a fraction (0-1)."""
    mask = df["reactor_thermal_power_mw"] > 1.0
    if not mask.any():
        return 0.0
    ratio = df.loc[mask, "net_electrical_power_mw"] / df.loc[mask, "reactor_thermal_power_mw"]
    return float(np.clip(ratio, 0.0, 1.0).mean())


def gross_efficiency(df: pd.DataFrame) -> float:
    mask = df["reactor_thermal_power_mw"] > 1.0
    if not mask.any():
        return 0.0
    ratio = df.loc[mask, "gross_electrical_power_mw"] / df.loc[mask, "reactor_thermal_power_mw"]
    return float(np.clip(ratio, 0.0, 1.0).mean())


def net_efficiency(df: pd.DataFrame) -> float:
    return thermal_efficiency(df)


def capacity_factor(df: pd.DataFrame, rated_electrical_mw: float) -> float:
    if rated_electrical_mw <= 0:
        return 0.0
    return float(df["net_electrical_power_mw"].mean() / rated_electrical_mw)


def load_factor(df: pd.DataFrame) -> float:
    peak = df["net_electrical_power_mw"].max()
    if peak <= 0:
        return 0.0
    return float(df["net_electrical_power_mw"].mean() / peak)


def auxiliary_power_fraction(df: pd.DataFrame) -> float:
    gross = df["gross_electrical_power_mw"].sum()
    if gross <= 0:
        return 0.0
    return float(df["auxiliary_power_mw"].sum() / gross)
