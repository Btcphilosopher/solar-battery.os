"""
Control and thermal stability metrics (design brief §25).
"""

from __future__ import annotations

import numpy as np
import pandas as pd


def power_tracking_error_mw(df: pd.DataFrame) -> float:
    return float((df["net_electrical_power_mw"] - df["grid_demand_mw"]).abs().mean())


def maximum_overshoot_pct(df: pd.DataFrame) -> float:
    demand = df["grid_demand_mw"]
    output = df["net_electrical_power_mw"]
    peak_demand = demand.max()
    if peak_demand <= 0:
        return 0.0
    overshoot = (output - demand).clip(lower=0.0)
    return float(overshoot.max() / peak_demand * 100.0)


def control_activity_pct(df: pd.DataFrame) -> float:
    """Fraction of samples where the rod or valve position changed
    meaningfully step-to-step — a simple proxy for how "busy" the
    controllers were during the run."""
    rod_delta = df["control_rod_position_pct"].diff().abs()
    valve_delta = df["valve_position_pct"].diff().abs()
    active = (rod_delta > 0.01) | (valve_delta > 0.01)
    if len(active) <= 1:
        return 0.0
    return float(active.iloc[1:].mean() * 100.0)


def thermal_stability_c(df: pd.DataFrame) -> float:
    """Standard deviation of coolant temperature — lower is more stable."""
    return float(df["coolant_temperature_c"].std(ddof=0))


def temperature_stability_c(df: pd.DataFrame) -> float:
    return thermal_stability_c(df)
