"""
Telemetry access helpers.
=============================

Small utilities for pulling well-shaped :class:`pandas.DataFrame` views
out of a :class:`~simulation.simulation_state.SimulationResult`, used by
every other module in ``analysis/`` and ``visualisation/``.
"""

from __future__ import annotations

import pandas as pd


def unit_dataframe(result, unit_id: int = 0) -> pd.DataFrame:
    df = result.to_dataframe()
    return df[df["unit_id"] == unit_id].reset_index(drop=True)


def site_dataframe(result) -> pd.DataFrame:
    """Aggregates electrical output across all units at each recorded
    instant, using unit 0's reactor/thermal telemetry for context."""

    df = result.to_dataframe()
    if df["unit_id"].nunique() <= 1:
        return unit_dataframe(result, 0)

    sums = df.groupby("simulation_time_s")[
        ["gross_electrical_power_mw", "auxiliary_power_mw", "net_electrical_power_mw", "export_power_mw", "grid_demand_mw"]
    ].sum().reset_index()

    unit0 = unit_dataframe(result, 0).drop(
        columns=["gross_electrical_power_mw", "auxiliary_power_mw", "net_electrical_power_mw", "export_power_mw", "grid_demand_mw"]
    )
    return unit0.merge(sums, on="simulation_time_s", how="left")
