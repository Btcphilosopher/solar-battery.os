"""
Engineering performance report (design brief §25).
"""

from __future__ import annotations

from analysis.performance import build_performance_summary


def generate_report(result) -> str:
    s = build_performance_summary(result)
    m = result.metadata

    lines = [
        "AUREOM CORE -- SIMULATION REPORT",
        "",
        "Plant Configuration",
        "-" * 19,
        f"Units:                  {s.units}",
        f"Nominal Thermal Power:  {s.nominal_thermal_power_mw:,.1f} MWth",
        f"Nominal Electrical:     {s.nominal_electrical_power_mw:,.1f} MWe",
        "",
        "Simulation",
        "-" * 10,
        f"Scenario:                {m.scenario}",
        f"Duration:                {s.duration_s:,.1f} s",
        f"Time Step:               {s.timestep_s:.3f} s",
        f"Random Seed:             {m.random_seed}",
        f"Configuration Hash:      {m.configuration_hash}",
        f"Simulation ID:           {m.simulation_id}",
        "",
        "Performance",
        "-" * 11,
        f"Average Output:         {s.average_output_mw:,.1f} MW",
        f"Peak Output:             {s.peak_output_mw:,.1f} MW",
        f"Minimum Output:          {s.minimum_output_mw:,.1f} MW",
        f"Average Efficiency:      {s.average_efficiency_pct:.1f} %",
        f"Capacity Factor:         {s.capacity_factor_pct:.1f} %",
        f"Load Factor:             {s.load_factor_pct:.1f} %",
        f"Auxiliary Power Fraction:{s.auxiliary_power_fraction_pct:6.1f} %",
        "",
        "Control",
        "-" * 7,
        f"Mean Tracking Error:     {s.mean_tracking_error_mw:.1f} MW",
        f"Maximum Overshoot:       {s.maximum_overshoot_pct:.1f} %",
        f"Control Activity:        {s.control_activity_pct:.1f} %",
        f"Thermal Stability (std): {s.thermal_stability_c:.2f} degC",
        "",
        "Safety",
        "-" * 6,
        f"Trips:                   {s.trips}",
        f"Faults:                  {s.faults}",
        f"Thermal Excursions:      {s.thermal_excursions}",
        f"Emergency Cooling Events:{s.emergency_cooling_activations:6d}",
        "",
        "Simulation Status",
        "-" * 17,
        s.overall_status,
        "",
    ]
    return "\n".join(lines)
