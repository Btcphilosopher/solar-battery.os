"""
Aggregate performance summary (design brief §25).
"""

from __future__ import annotations

from dataclasses import dataclass

from analysis.efficiency import auxiliary_power_fraction, capacity_factor, load_factor, net_efficiency
from analysis.metrics import site_dataframe
from analysis.stability import control_activity_pct, maximum_overshoot_pct, power_tracking_error_mw, thermal_stability_c
from simulation.events import EventType


@dataclass
class PerformanceSummary:
    units: int
    nominal_thermal_power_mw: float
    nominal_electrical_power_mw: float

    duration_s: float
    timestep_s: float

    average_output_mw: float
    peak_output_mw: float
    minimum_output_mw: float
    average_efficiency_pct: float
    capacity_factor_pct: float
    load_factor_pct: float
    auxiliary_power_fraction_pct: float

    mean_tracking_error_mw: float
    maximum_overshoot_pct: float
    control_activity_pct: float
    thermal_stability_c: float

    trips: int
    faults: int
    thermal_excursions: int
    emergency_cooling_activations: int

    overall_status: str


def _count_rising_edges(series) -> int:
    prev = False
    count = 0
    for value in series:
        current = bool(value)
        if current and not prev:
            count += 1
        prev = current
    return count


def build_performance_summary(result) -> PerformanceSummary:
    units = result.metadata.units
    nominal_thermal_power_mw = result.metadata.nominal_thermal_power_mw
    nominal_electrical_power_mw = result.metadata.nominal_electrical_power_mw

    df = site_dataframe(result)

    trips = sum(1 for e in result.events if e.type == EventType.REACTOR_TRIP)
    faults = len({alarm for row in df["active_alarms"] for alarm in row.split(",") if alarm})
    excursions = _count_rising_edges((df["fuel_thermal_margin_c"] < 0) | (df["coolant_thermal_margin_c"] < 0))
    ec_activations = _count_rising_edges(df["emergency_cooling_active"])

    tripped_final = bool((df["reactor_status"].iloc[-5:] == "TRIPPED").any()) if len(df) else False
    has_faults_at_end = bool(df["active_alarms"].iloc[-1]) if len(df) else False

    if tripped_final:
        overall_status = "PROTECTIVE SHUTDOWN"
    elif has_faults_at_end:
        overall_status = "DEGRADED"
    else:
        overall_status = "STABLE"

    return PerformanceSummary(
        units=units,
        nominal_thermal_power_mw=nominal_thermal_power_mw,
        nominal_electrical_power_mw=nominal_electrical_power_mw,
        duration_s=result.metadata.duration_s,
        timestep_s=result.metadata.timestep_s,
        average_output_mw=float(df["net_electrical_power_mw"].mean()) if len(df) else 0.0,
        peak_output_mw=float(df["net_electrical_power_mw"].max()) if len(df) else 0.0,
        minimum_output_mw=float(df["net_electrical_power_mw"].min()) if len(df) else 0.0,
        average_efficiency_pct=net_efficiency(df) * 100.0,
        capacity_factor_pct=capacity_factor(df, nominal_electrical_power_mw * units) * 100.0,
        load_factor_pct=load_factor(df) * 100.0,
        auxiliary_power_fraction_pct=auxiliary_power_fraction(df) * 100.0,
        mean_tracking_error_mw=power_tracking_error_mw(df),
        maximum_overshoot_pct=maximum_overshoot_pct(df),
        control_activity_pct=control_activity_pct(df),
        thermal_stability_c=thermal_stability_c(df),
        trips=trips,
        faults=faults,
        thermal_excursions=excursions,
        emergency_cooling_activations=ec_activations,
        overall_status=overall_status,
    )
