"""
AUREOM CORE — Configuration Objects
====================================

All engineering parameters used by the simulation are declared here as
strongly-typed dataclasses. Every numeric value is a **synthetic simulation
parameter**, chosen to be plausible for a large (~1,000-1,600 MWe class)
light-water reactor generating station, but it is NOT derived from, and
must NOT be interpreted as, any real reactor design, proprietary vendor
data, or an operating plant's licensed parameters.

Nothing in this module should be read as engineering, safety, or licensing
guidance for a real facility.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class NeutronKineticsConfig:
    """Point-kinetics parameters (generic textbook thermal-reactor values).

    beta_i / lambda_i are the classic 6-group delayed-neutron fractions and
    decay constants that appear in reactor-physics textbooks for thermal
    fission of U-235; they are not specific to any single design.
    """

    prompt_neutron_lifetime_s: float = 2.0e-5
    beta_fractions: tuple = (
        0.000215, 0.001424, 0.001274, 0.002568, 0.000748, 0.000273,
    )
    precursor_decay_constants_s: tuple = (
        0.0124, 0.0305, 0.111, 0.301, 1.14, 3.01,
    )
    # The dominant stiff eigenvalue of the linearised point-kinetics system
    # is approximately -beta/Lambda (~-325 /s for the defaults above). RK4's
    # stability region for a real negative eigenvalue only extends to about
    # h*|lambda| ~= 2.785, so the substep must satisfy h << 2.785*Lambda/beta
    # (~0.0086 s here) with real margin, or the "stable" RK4 integrator
    # itself becomes numerically unstable. 0.001 s gives h*|lambda| ~= 0.33,
    # comfortably inside the stability region.
    max_kinetics_substep_s: float = 0.001

    @property
    def beta_total(self) -> float:
        return sum(self.beta_fractions)


@dataclass(frozen=True)
class ReactivityConfig:
    """Feedback-coefficient configuration (synthetic, dimensionless dk/k per unit)."""

    fuel_temperature_coefficient_per_c: float = -3.2e-5
    coolant_temperature_coefficient_per_c: float = -2.1e-4
    reference_fuel_temperature_c: float = 650.0
    reference_coolant_temperature_c: float = 310.0
    # Calibrated so that the fuel/xenon model's own equilibrium xenon
    # concentration at n=1.0 (rated power) -- ~389.5 in the raw
    # concentration units produced by core/fuel_model.py's I-135/Xe-135
    # kinetics with the yield/decay constants in FuelConfig -- gives a
    # full-power equilibrium xenon reactivity worth of about -0.03 dk/k,
    # a typical order of magnitude for a thermal power reactor.
    xenon_worth_per_unit_concentration: float = -7.7e-5
    max_control_reactivity: float = 0.02
    scram_reactivity: float = -0.12
    scram_insertion_time_s: float = 2.2


@dataclass(frozen=True)
class FuelConfig:
    """Core thermal-mass / fission-product proxy configuration."""

    fuel_thermal_mass_mj_per_c: float = 6800.0
    coolant_thermal_mass_mj_per_c: float = 2600.0
    fuel_to_coolant_ua_mw_per_c: float = 210.0
    xenon_yield_fraction: float = 0.061
    xenon_decay_constant_per_s: float = 2.09e-5
    iodine_yield_fraction: float = 0.064
    iodine_decay_constant_per_s: float = 2.87e-5
    xenon_microscopic_burn_rate: float = 3.0e-4


@dataclass(frozen=True)
class ReactorConfig:
    """Top-level reactor / nuclear-island rating."""

    nominal_thermal_power_mw: float = 3400.0
    kinetics: NeutronKineticsConfig = field(default_factory=NeutronKineticsConfig)
    reactivity: ReactivityConfig = field(default_factory=ReactivityConfig)
    fuel: FuelConfig = field(default_factory=FuelConfig)
    decay_heat_fraction_at_trip: float = 0.066
    decay_heat_time_constant_s: float = 1.0


@dataclass(frozen=True)
class CoolantConfig:
    """Primary reactor-coolant-system loop parameters (synthetic)."""

    nominal_mass_flow_kg_s: float = 18500.0
    nominal_pressure_mpa: float = 15.5
    cold_leg_setpoint_c: float = 292.0
    specific_heat_kj_per_kg_c: float = 5.5
    loop_transport_time_s: float = 4.0
    pump_count: int = 4
    pump_rated_flow_kg_s_each: float = 4625.0
    pump_spin_down_time_s: float = 12.0


@dataclass(frozen=True)
class PressurizerConfig:
    """Pressurizer pressure-control parameters (synthetic)."""

    setpoint_mpa: float = 15.5
    relaxation_time_s: float = 25.0
    heater_gain_mpa_per_c: float = 0.003
    spray_gain_mpa_per_c: float = 0.02
    pressure_min_mpa: float = 13.0
    pressure_max_mpa: float = 17.2


@dataclass(frozen=True)
class SteamGeneratorConfig:
    """Once-through / U-tube style steam-generator heat-exchanger proxy."""

    count: int = 4
    effectiveness: float = 0.86
    secondary_thermal_mass_mj_per_c: float = 950.0
    nominal_steam_pressure_mpa: float = 6.9
    nominal_steam_flow_kg_s: float = 1890.0
    pressure_time_constant_s: float = 6.0
    latent_heat_kj_per_kg: float = 1500.0
    header_capacitance_kg_per_mpa: float = 420.0
    # Steam dump / atmospheric relief: represents the turbine-bypass and
    # atmospheric relief valves that let a real plant continue rejecting
    # decay heat via the steam generators after a turbine trip closes the
    # governor valve. Opens proportionally once header pressure exceeds
    # relief_setpoint_fraction * nominal_steam_pressure_mpa.
    relief_setpoint_fraction: float = 1.1
    relief_capacity_kg_s_per_mpa: float = 900.0


@dataclass(frozen=True)
class TurbineConfig:
    """Large multi-stage steam turbine (synthetic Willans-line model)."""

    rated_mechanical_power_mw: float = 1350.0
    willans_coefficient: float = 0.92
    no_load_steam_flow_kg_s: float = 45.0
    rotor_inertia_kg_m2: float = 4.8e5
    synchronous_speed_rad_s: float = 314.159  # 3000 rpm, 50 Hz, 2-pole equivalent
    mechanical_loss_torque_nm: float = 1.2e5
    valve_time_constant_s: float = 1.5
    available_enthalpy_drop_kj_per_kg: float = 1500.0


@dataclass(frozen=True)
class GeneratorConfig:
    """Turbine-generator electrical conversion (synthetic)."""

    rated_electrical_power_mw: float = 1300.0
    efficiency: float = 0.986
    rated_power_factor: float = 0.90
    inertia_constant_h_s: float = 5.5


@dataclass(frozen=True)
class CondenserConfig:
    """Main condenser / heat-rejection proxy."""

    design_backpressure_kpa: float = 6.0
    cooling_water_flow_kg_s: float = 42000.0
    latent_heat_kj_per_kg: float = 2260.0
    backpressure_time_constant_s: float = 20.0
    design_steam_flow_kg_s: float = 1890.0


@dataclass(frozen=True)
class FeedwaterConfig:
    """Feedwater / condensate system proxy."""

    nominal_flow_kg_s: float = 1890.0
    feed_temperature_c: float = 226.0
    heater_effectiveness: float = 0.78
    pump_time_constant_s: float = 3.0


@dataclass(frozen=True)
class GridConfig:
    """Electrical grid interconnection proxy."""

    nominal_frequency_hz: float = 50.0
    nominal_voltage_kv: float = 400.0
    grid_stiffness_mw_per_hz: float = 900.0
    transformer_efficiency: float = 0.993
    auxiliary_load_fraction_of_gross: float = 0.045
    auxiliary_fixed_load_mw: float = 18.0
    swing_time_constant_s: float = 8.0


@dataclass(frozen=True)
class ControlConfig:
    """Controller tuning (synthetic; not a real plant setpoint set)."""

    reactor_power_pid_kp: float = 0.55
    reactor_power_pid_ki: float = 0.08
    reactor_power_pid_kd: float = 0.02
    rod_max_speed_pct_per_s: float = 1.0
    rod_reactivity_worth_full_stroke: float = 0.024

    turbine_load_pid_kp: float = 0.9
    turbine_load_pid_ki: float = 0.15
    turbine_load_pid_kd: float = 0.0
    valve_max_rate_pct_per_s: float = 4.0

    load_ramp_max_mw_per_min: float = 25.0


@dataclass(frozen=True)
class ProtectionConfig:
    """Reactor-protection-system synthetic trip setpoints.

    NON-OPERATIONAL PLACEHOLDER VALUES — for simulation only. These are not
    the setpoints of any licensed reactor protection system.
    """

    high_power_trip_pct: float = 118.0
    high_fuel_temperature_trip_c: float = 1200.0
    high_coolant_temperature_trip_c: float = 345.0
    low_coolant_flow_trip_pct: float = 85.0
    high_pressurizer_pressure_trip_mpa: float = 17.2
    low_pressurizer_pressure_trip_mpa: float = 13.5
    high_condenser_backpressure_trip_kpa: float = 25.0
    grid_disturbance_frequency_deviation_hz: float = 1.5
    instrumentation_deviation_trip_c: float = 15.0


@dataclass(frozen=True)
class SafetyConfig:
    """Emergency-cooling / thermal-margin synthetic parameters."""

    fuel_temperature_margin_alert_c: float = 950.0
    coolant_temperature_margin_alert_c: float = 330.0
    emergency_cooling_activation_flow_pct: float = 70.0
    emergency_cooling_capacity_mw: float = 420.0
    emergency_cooling_ramp_time_s: float = 15.0
    containment_design_pressure_kpa: float = 480.0


@dataclass(frozen=True)
class SimulationConfig:
    """Deterministic simulation-engine configuration."""

    timestep_s: float = 0.1
    duration_s: float = 3600.0
    random_seed: int = 42
    telemetry_decimation: int = 1  # record every Nth step


SOFTWARE_VERSION = "1.0.0"


@dataclass(frozen=True)
class PlantConfig:
    """Aggregate configuration bundle for a single reactor/turbine unit."""

    reactor: ReactorConfig = field(default_factory=ReactorConfig)
    coolant: CoolantConfig = field(default_factory=CoolantConfig)
    pressurizer: PressurizerConfig = field(default_factory=PressurizerConfig)
    steam_generator: SteamGeneratorConfig = field(default_factory=SteamGeneratorConfig)
    turbine: TurbineConfig = field(default_factory=TurbineConfig)
    generator: GeneratorConfig = field(default_factory=GeneratorConfig)
    condenser: CondenserConfig = field(default_factory=CondenserConfig)
    feedwater: FeedwaterConfig = field(default_factory=FeedwaterConfig)
    grid: GridConfig = field(default_factory=GridConfig)
    control: ControlConfig = field(default_factory=ControlConfig)
    protection: ProtectionConfig = field(default_factory=ProtectionConfig)
    safety: SafetyConfig = field(default_factory=SafetyConfig)
    simulation: SimulationConfig = field(default_factory=SimulationConfig)


def default_large_reactor_config(
    reactor_thermal_power_mw: float = 3400.0,
    electrical_capacity_mw: float = 1300.0,
) -> PlantConfig:
    """Build a self-consistent :class:`PlantConfig` scaled from two headline
    ratings, both clearly synthetic modelling assumptions in the
    ~3-4.5 GWth / ~1.0-1.6 GWe large-reactor regime described in the design
    brief. Sub-system nominal values are scaled proportionally so that
    100% power corresponds to the requested ratings.
    """

    base = PlantConfig()
    thermal_scale = reactor_thermal_power_mw / base.reactor.nominal_thermal_power_mw
    electrical_scale = electrical_capacity_mw / base.generator.rated_electrical_power_mw

    reactor = ReactorConfig(
        nominal_thermal_power_mw=reactor_thermal_power_mw,
        kinetics=base.reactor.kinetics,
        reactivity=base.reactor.reactivity,
        fuel=FuelConfig(
            fuel_thermal_mass_mj_per_c=base.reactor.fuel.fuel_thermal_mass_mj_per_c * thermal_scale,
            coolant_thermal_mass_mj_per_c=base.reactor.fuel.coolant_thermal_mass_mj_per_c * thermal_scale,
            fuel_to_coolant_ua_mw_per_c=base.reactor.fuel.fuel_to_coolant_ua_mw_per_c * thermal_scale,
            xenon_yield_fraction=base.reactor.fuel.xenon_yield_fraction,
            xenon_decay_constant_per_s=base.reactor.fuel.xenon_decay_constant_per_s,
            iodine_yield_fraction=base.reactor.fuel.iodine_yield_fraction,
            iodine_decay_constant_per_s=base.reactor.fuel.iodine_decay_constant_per_s,
            xenon_microscopic_burn_rate=base.reactor.fuel.xenon_microscopic_burn_rate,
        ),
        decay_heat_fraction_at_trip=base.reactor.decay_heat_fraction_at_trip,
        decay_heat_time_constant_s=base.reactor.decay_heat_time_constant_s,
    )
    coolant = CoolantConfig(
        nominal_mass_flow_kg_s=base.coolant.nominal_mass_flow_kg_s * thermal_scale,
        nominal_pressure_mpa=base.coolant.nominal_pressure_mpa,
        cold_leg_setpoint_c=base.coolant.cold_leg_setpoint_c,
        specific_heat_kj_per_kg_c=base.coolant.specific_heat_kj_per_kg_c,
        loop_transport_time_s=base.coolant.loop_transport_time_s,
        pump_count=base.coolant.pump_count,
        pump_rated_flow_kg_s_each=base.coolant.nominal_mass_flow_kg_s * thermal_scale / base.coolant.pump_count,
        pump_spin_down_time_s=base.coolant.pump_spin_down_time_s,
    )
    steam_generator = SteamGeneratorConfig(
        count=base.steam_generator.count,
        effectiveness=base.steam_generator.effectiveness,
        secondary_thermal_mass_mj_per_c=base.steam_generator.secondary_thermal_mass_mj_per_c * thermal_scale,
        nominal_steam_pressure_mpa=base.steam_generator.nominal_steam_pressure_mpa,
        nominal_steam_flow_kg_s=base.steam_generator.nominal_steam_flow_kg_s * thermal_scale,
        pressure_time_constant_s=base.steam_generator.pressure_time_constant_s,
        latent_heat_kj_per_kg=base.steam_generator.latent_heat_kj_per_kg,
        header_capacitance_kg_per_mpa=base.steam_generator.header_capacitance_kg_per_mpa * thermal_scale,
        relief_setpoint_fraction=base.steam_generator.relief_setpoint_fraction,
        relief_capacity_kg_s_per_mpa=base.steam_generator.relief_capacity_kg_s_per_mpa * thermal_scale,
    )
    # Calibrate the turbine's Willans-line enthalpy drop so that the
    # configured rated mechanical power is reached exactly at the steam
    # generators' full-power steam flow (rather than at an independently
    # guessed enthalpy-drop constant, which could silently overshoot or
    # undershoot the requested electrical_capacity_mw and -- more
    # importantly -- could produce an unphysically high overall cycle
    # efficiency if the "available" enthalpy drop were close to the
    # steam's full latent heat). This keeps net thermal efficiency in a
    # realistic large-PWR range that falls out naturally from the ratio
    # between reactor_thermal_power_mw and electrical_capacity_mw.
    rated_mechanical_power_mw = electrical_capacity_mw / base.generator.efficiency
    no_load_flow_kg_s = base.turbine.no_load_steam_flow_kg_s * thermal_scale
    usable_flow_kg_s = max(steam_generator.nominal_steam_flow_kg_s - no_load_flow_kg_s, 1.0)
    available_enthalpy_drop_kj_per_kg = (rated_mechanical_power_mw * 1000.0) / (
        base.turbine.willans_coefficient * usable_flow_kg_s
    )

    turbine = TurbineConfig(
        rated_mechanical_power_mw=rated_mechanical_power_mw,
        willans_coefficient=base.turbine.willans_coefficient,
        no_load_steam_flow_kg_s=no_load_flow_kg_s,
        rotor_inertia_kg_m2=base.turbine.rotor_inertia_kg_m2 * electrical_scale,
        synchronous_speed_rad_s=base.turbine.synchronous_speed_rad_s,
        mechanical_loss_torque_nm=base.turbine.mechanical_loss_torque_nm * electrical_scale,
        valve_time_constant_s=base.turbine.valve_time_constant_s,
        available_enthalpy_drop_kj_per_kg=available_enthalpy_drop_kj_per_kg,
    )
    generator = GeneratorConfig(
        rated_electrical_power_mw=electrical_capacity_mw,
        efficiency=base.generator.efficiency,
        rated_power_factor=base.generator.rated_power_factor,
        inertia_constant_h_s=base.generator.inertia_constant_h_s,
    )
    condenser = CondenserConfig(
        design_backpressure_kpa=base.condenser.design_backpressure_kpa,
        cooling_water_flow_kg_s=base.condenser.cooling_water_flow_kg_s * thermal_scale,
        latent_heat_kj_per_kg=base.condenser.latent_heat_kj_per_kg,
        backpressure_time_constant_s=base.condenser.backpressure_time_constant_s,
        design_steam_flow_kg_s=steam_generator.nominal_steam_flow_kg_s,
    )
    feedwater = FeedwaterConfig(
        nominal_flow_kg_s=steam_generator.nominal_steam_flow_kg_s,
        feed_temperature_c=base.feedwater.feed_temperature_c,
        heater_effectiveness=base.feedwater.heater_effectiveness,
        pump_time_constant_s=base.feedwater.pump_time_constant_s,
    )

    return PlantConfig(
        reactor=reactor,
        coolant=coolant,
        pressurizer=base.pressurizer,
        steam_generator=steam_generator,
        turbine=turbine,
        generator=generator,
        condenser=condenser,
        feedwater=feedwater,
        grid=base.grid,
        control=base.control,
        protection=base.protection,
        safety=base.safety,
        simulation=base.simulation,
    )
