"""
Feedwater system.
===================

Feedwater flow tracks steam demand (closing the secondary-side mass
balance back to the steam generators) through a first-order pump-response
lag, and feed temperature is raised toward a load-dependent target by the
feedwater heater train (representing regenerative extraction-steam
heating, without modelling each individual heater stage):

    d(flow)/dt = (target_flow - flow) / tau_pump
    target_temp = feed_temperature_design * heater_effectiveness * (0.6 + 0.4 * load_fraction)
"""

from __future__ import annotations

from dataclasses import dataclass

from config import FeedwaterConfig


@dataclass
class FeedwaterResult:
    flow_kg_s: float
    temperature_c: float


@dataclass
class FeedwaterSystem:
    cfg: FeedwaterConfig
    flow_kg_s: float = 0.0
    temperature_c: float = 0.0

    def __post_init__(self) -> None:
        if self.temperature_c == 0.0:
            self.temperature_c = self.cfg.feed_temperature_c

    def step(self, target_flow_kg_s: float, load_fraction: float, dt: float) -> FeedwaterResult:
        cfg = self.cfg
        tau = max(cfg.pump_time_constant_s, 1.0e-3)
        self.flow_kg_s += (max(target_flow_kg_s, 0.0) - self.flow_kg_s) * (dt / tau)
        self.flow_kg_s = max(self.flow_kg_s, 0.0)

        target_temp = cfg.feed_temperature_c * cfg.heater_effectiveness * (0.6 + 0.4 * max(load_fraction, 0.0))
        self.temperature_c += (target_temp - self.temperature_c) * (dt / max(tau * 3.0, 1.0))

        return FeedwaterResult(flow_kg_s=self.flow_kg_s, temperature_c=self.temperature_c)
