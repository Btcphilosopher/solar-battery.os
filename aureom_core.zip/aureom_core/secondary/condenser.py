"""
Main condenser.
=================

First-order backpressure model: turbine exhaust steam is condensed by
the circulating-water system, and backpressure rises above the design
value when the exhaust duty exceeds the condenser's design flow (fouling,
loss of cooling-water flow, or high steam demand):

    target_backpressure = design_backpressure * (1 + k * (flow / design_flow - 1))
    d(backpressure)/dt = (target_backpressure - backpressure) / tau
"""

from __future__ import annotations

from dataclasses import dataclass

from config import CondenserConfig


@dataclass
class Condenser:
    cfg: CondenserConfig
    backpressure_kpa: float = 0.0
    cooling_water_flow_fraction: float = 1.0

    def __post_init__(self) -> None:
        if self.backpressure_kpa == 0.0:
            self.backpressure_kpa = self.cfg.design_backpressure_kpa

    def step(self, exhaust_steam_flow_kg_s: float, dt: float) -> float:
        cfg = self.cfg
        flow_ratio = exhaust_steam_flow_kg_s / max(cfg.design_steam_flow_kg_s, 1.0e-6)
        cooling_penalty = max(1.0 / max(self.cooling_water_flow_fraction, 0.05) - 1.0, 0.0)

        target_kpa = cfg.design_backpressure_kpa * (1.0 + 0.20 * (flow_ratio - 1.0) + cooling_penalty)
        target_kpa = max(target_kpa, cfg.design_backpressure_kpa * 0.5)

        tau = max(cfg.backpressure_time_constant_s, 1.0e-3)
        self.backpressure_kpa += (target_kpa - self.backpressure_kpa) * (dt / tau)
        self.backpressure_kpa = max(self.backpressure_kpa, 1.0)
        return self.backpressure_kpa

    def heat_rejected_mw(self, exhaust_steam_flow_kg_s: float) -> float:
        return exhaust_steam_flow_kg_s * self.cfg.latent_heat_kj_per_kg / 1000.0
