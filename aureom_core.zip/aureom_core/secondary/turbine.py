"""
Main turbine.
==============

Simplified Willans-line steam turbine coupled to a single-mass rotor:

    P_mechanical = eta_turbine * h_drop * max(steam_flow - no_load_flow, 0)
    J * domega/dt = T_steam - T_generator - T_loss

``h_drop`` (``available_enthalpy_drop_kj_per_kg``) is a configured
representative isentropic enthalpy drop across the turbine for this
plant's steam conditions — a synthetic modelling assumption, not a
steam-table-derived value for a specific design. The rotor equation
gives the turbine genuine rotational dynamics rather than treating shaft
power as an instantaneous function of steam flow.
"""

from __future__ import annotations

from dataclasses import dataclass

from config import TurbineConfig


@dataclass
class TurbineResult:
    mechanical_power_mw: float
    mechanical_torque_nm: float
    rotor_speed_rad_s: float


@dataclass
class Turbine:
    cfg: TurbineConfig
    rotor_speed_rad_s: float = 0.0

    def __post_init__(self) -> None:
        if self.rotor_speed_rad_s == 0.0:
            self.rotor_speed_rad_s = self.cfg.synchronous_speed_rad_s

    def step(self, steam_flow_kg_s: float, generator_counter_torque_nm: float, dt: float) -> TurbineResult:
        cfg = self.cfg

        ideal_mw_per_kgps = cfg.available_enthalpy_drop_kj_per_kg / 1000.0
        net_flow = max(steam_flow_kg_s - cfg.no_load_steam_flow_kg_s, 0.0)
        mechanical_power_mw = min(
            cfg.willans_coefficient * ideal_mw_per_kgps * net_flow,
            cfg.rated_mechanical_power_mw * 1.05,
        )
        mechanical_power_mw = max(mechanical_power_mw, 0.0)

        omega_ref = max(self.rotor_speed_rad_s, 10.0)
        torque_from_steam_nm = mechanical_power_mw * 1.0e6 / omega_ref

        loss_torque = cfg.mechanical_loss_torque_nm * (1.0 if self.rotor_speed_rad_s > 1.0 else 0.0)
        d_omega_dt = (torque_from_steam_nm - generator_counter_torque_nm - loss_torque) / max(
            cfg.rotor_inertia_kg_m2, 1.0
        )

        self.rotor_speed_rad_s += d_omega_dt * dt
        self.rotor_speed_rad_s = max(0.0, min(self.rotor_speed_rad_s, cfg.synchronous_speed_rad_s * 1.2))

        return TurbineResult(
            mechanical_power_mw=mechanical_power_mw,
            mechanical_torque_nm=torque_from_steam_nm,
            rotor_speed_rad_s=self.rotor_speed_rad_s,
        )
