"""
Turbine-generator electrical conversion.
==========================================

Converts turbine shaft mechanical power to electrical power at the
generator terminals, and computes the electromagnetic counter-torque fed
back to the turbine rotor (closing the shaft-dynamics loop from
secondary/turbine.py):

    P_electrical = eta_generator * P_mechanical
    T_counter    = P_electrical / omega
"""

from __future__ import annotations

from dataclasses import dataclass

from config import GeneratorConfig


@dataclass
class GeneratorResult:
    electrical_power_mw: float
    counter_torque_nm: float
    efficiency: float


@dataclass
class TurbineGenerator:
    cfg: GeneratorConfig

    def step(self, mechanical_power_mw: float, rotor_speed_rad_s: float) -> GeneratorResult:
        cfg = self.cfg
        electrical_power_mw = max(mechanical_power_mw, 0.0) * cfg.efficiency
        electrical_power_mw = min(electrical_power_mw, cfg.rated_electrical_power_mw * 1.05)

        omega_ref = max(rotor_speed_rad_s, 10.0)
        counter_torque_nm = electrical_power_mw * 1.0e6 / omega_ref

        return GeneratorResult(
            electrical_power_mw=electrical_power_mw,
            counter_torque_nm=counter_torque_nm,
            efficiency=cfg.efficiency,
        )
