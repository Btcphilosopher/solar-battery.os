"""
Main steam system.
====================

Lumped-capacitance model of the main-steam header connecting the steam
generators to the turbine governor valve. Header pressure integrates the
mass-flow imbalance between steam generation and turbine consumption
(a simplified mass/energy-storage proxy for the header + steam piping
inventory), and the governor valve meters flow to the turbine using a
choked-flow-like proportionality to pressure:

    dP/dt = (generation - consumption - relief) / header_capacitance
    consumption = valve_opening * nominal_flow * sqrt(P / P_nominal)
    relief = max(0, P - relief_setpoint) * relief_gain

The relief term represents turbine-bypass / atmospheric relief valves:
without it, a turbine trip (governor valve closed) would leave the steam
generators with no way to reject decay heat and header pressure would
climb without bound, which is not how a real plant's post-trip steam
system behaves (design brief §17-18: shutdown does not mean the plant
stops needing a heat sink).
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from config import SteamGeneratorConfig


@dataclass
class SteamSystemResult:
    header_pressure_mpa: float
    steam_flow_to_turbine_kg_s: float
    relief_flow_kg_s: float = 0.0


@dataclass
class MainSteamSystem:
    cfg: SteamGeneratorConfig
    header_pressure_mpa: float = 0.0

    def __post_init__(self) -> None:
        if self.header_pressure_mpa == 0.0:
            self.header_pressure_mpa = self.cfg.nominal_steam_pressure_mpa

    def step(self, steam_generation_kg_s: float, valve_opening_fraction: float, dt: float) -> SteamSystemResult:
        cfg = self.cfg
        valve_opening_fraction = max(0.0, min(valve_opening_fraction, 1.05))

        pressure_ratio = max(self.header_pressure_mpa / cfg.nominal_steam_pressure_mpa, 0.0)
        consumption_kg_s = valve_opening_fraction * cfg.nominal_steam_flow_kg_s * math.sqrt(pressure_ratio)

        relief_setpoint_mpa = cfg.relief_setpoint_fraction * cfg.nominal_steam_pressure_mpa
        relief_kg_s = max(self.header_pressure_mpa - relief_setpoint_mpa, 0.0) * cfg.relief_capacity_kg_s_per_mpa

        capacitance = max(cfg.header_capacitance_kg_per_mpa, 1.0e-3)
        d_p_dt = (steam_generation_kg_s - consumption_kg_s - relief_kg_s) / capacitance
        self.header_pressure_mpa += d_p_dt * dt
        self.header_pressure_mpa = max(self.header_pressure_mpa, 0.05)

        return SteamSystemResult(
            header_pressure_mpa=self.header_pressure_mpa,
            steam_flow_to_turbine_kg_s=max(consumption_kg_s, 0.0),
            relief_flow_kg_s=relief_kg_s,
        )
