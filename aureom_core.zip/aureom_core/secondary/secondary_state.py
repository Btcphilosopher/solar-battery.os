"""Observable state for the secondary (steam/turbine) island."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class SecondaryState:
    steam_header_pressure_mpa: float = 6.9
    steam_flow_to_turbine_kg_s: float = 0.0
    turbine_valve_position_pct: float = 0.0

    rotor_speed_rad_s: float = 314.159
    turbine_mechanical_power_mw: float = 0.0
    turbine_mechanical_torque_nm: float = 0.0

    generator_electrical_power_mw: float = 0.0
    generator_frequency_hz: float = 50.0
    generator_efficiency: float = 0.0

    condenser_backpressure_kpa: float = 6.0

    feedwater_flow_kg_s: float = 0.0
    feedwater_temperature_c: float = 226.0
