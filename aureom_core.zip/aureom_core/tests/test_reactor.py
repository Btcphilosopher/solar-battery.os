"""Reactor-physics tests: point kinetics, reactivity feedback, decay heat."""

from __future__ import annotations

from config import ReactorConfig
from core.reactor_core import ReactorCore


def _core_at_power(power_fraction: float = 0.9) -> ReactorCore:
    core = ReactorCore(ReactorConfig())
    core.initialize_at_power(power_fraction, coolant_temperature_c=310.0)
    return core


def test_positive_reactivity_increases_power():
    core = _core_at_power(0.5)
    initial_power = core.state.normalized_power

    for _ in range(50):
        core.step(
            dt=0.1,
            control_reactivity=0.0015,  # small positive step insertion
            coolant_inlet_temperature_c=292.0,
            coolant_mass_flow_kg_s=18500.0,
            coolant_specific_heat_kj_per_kg_c=5.5,
        )

    assert core.state.normalized_power > initial_power


def test_negative_temperature_feedback_is_stabilising():
    core = _core_at_power(0.9)
    core.state.coolant_temperature_avg_c += 20.0  # perturb hot

    reactivity = core._reactivity.compute(
        control_reactivity=0.0,
        fuel_temperature_c=core.state.fuel_temperature_c,
        coolant_temperature_c=core.state.coolant_temperature_avg_c,
        xenon_concentration=0.0,
    )
    assert reactivity.thermal_feedback < 0.0


def test_reactor_trip_decays_power_and_produces_decay_heat():
    core = _core_at_power(1.0)
    core.trip()

    for _ in range(200):
        core.step(
            dt=0.1,
            control_reactivity=-0.03,  # scram-like large negative reactivity
            coolant_inlet_temperature_c=292.0,
            coolant_mass_flow_kg_s=18500.0,
            coolant_specific_heat_kj_per_kg_c=5.5,
        )

    assert core.state.normalized_power < 0.1
    # Decay heat must remain positive and non-trivial after shutdown --
    # shutdown does not mean zero thermal energy (design brief §16-17).
    assert core.state.decay_power_mw > 0.0
    assert core.state.thermal_power_mw > core.state.fission_power_mw - 1e-6


def test_decay_heat_decreases_over_time():
    core = _core_at_power(1.0)
    core.trip()

    for _ in range(100):
        core.step(0.1, -0.03, 292.0, 18500.0, 5.5)
    decay_at_10s = core.state.decay_power_mw

    for _ in range(9000):
        core.step(0.1, -0.03, 292.0, 18500.0, 5.5)
    decay_at_900s = core.state.decay_power_mw

    assert decay_at_900s < decay_at_10s
