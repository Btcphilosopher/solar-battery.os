"""Ensures the project root is on sys.path so tests can use the same
flat, top-level import style (``from config import ...``) as the rest
of the codebase, regardless of the directory pytest is invoked from."""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
