"""Safety-system tests: fault detection, protective transitions, shutdown behaviour."""

from __future__ import annotations

from config import ProtectionConfig
from protection.protection_state import ProtectionStatus
from protection.reactor_protection import ReactorProtectionSystem
from protection.trip_logic import TripMeasurements
from safety.fault_detection import FaultDetector
from simulation.scheduler import Fault


def test_fault_detector_reports_pump_degradation_effect_and_alarm():
    detector = FaultDetector()
    fault = Fault(component="primary_pump", mode="pump_degradation", severity=0.4, start_time_s=0.0, duration_s=100.0)

    effects = detector.apply([fault])

    assert effects.pump_health_multiplier == 0.6
    assert any("pump_degradation" in a for a in effects.alarms)


def test_fault_schedule_only_active_within_window():
    fault = Fault(component="x", mode="sensor_dropout", severity=1.0, start_time_s=100.0, duration_s=50.0)
    assert not fault.active_at(50.0)
    assert fault.active_at(120.0)
    assert not fault.active_at(151.0)


def test_protection_system_trips_on_high_power():
    cfg = ProtectionConfig()
    rps = ReactorProtectionSystem(cfg)

    normal = TripMeasurements(
        power_pct=90.0, fuel_temperature_c=600.0, coolant_temperature_c=310.0,
        flow_pct=100.0, pressurizer_pressure_mpa=15.5, condenser_backpressure_kpa=6.0,
        frequency_deviation_hz=0.0,
    )
    state = rps.evaluate(normal)
    assert state.status == ProtectionStatus.NORMAL

    excursion = TripMeasurements(
        power_pct=cfg.high_power_trip_pct + 1.0, fuel_temperature_c=600.0, coolant_temperature_c=310.0,
        flow_pct=100.0, pressurizer_pressure_mpa=15.5, condenser_backpressure_kpa=6.0,
        frequency_deviation_hz=0.0,
    )
    state = rps.evaluate(excursion)
    assert state.status == ProtectionStatus.TRIPPED
    assert "HIGH_REACTOR_POWER" in state.active_trips
    assert state.scram_commanded


def test_protection_latches_after_measurement_recovers():
    cfg = ProtectionConfig()
    rps = ReactorProtectionSystem(cfg)

    excursion = TripMeasurements(
        power_pct=cfg.high_power_trip_pct + 5.0, fuel_temperature_c=600.0, coolant_temperature_c=310.0,
        flow_pct=100.0, pressurizer_pressure_mpa=15.5, condenser_backpressure_kpa=6.0,
        frequency_deviation_hz=0.0,
    )
    rps.evaluate(excursion)

    recovered = TripMeasurements(
        power_pct=50.0, fuel_temperature_c=600.0, coolant_temperature_c=310.0,
        flow_pct=100.0, pressurizer_pressure_mpa=15.5, condenser_backpressure_kpa=6.0,
        frequency_deviation_hz=0.0,
    )
    state = rps.evaluate(recovered)
    # Latched: the trip does not clear itself just because the
    # measurement is back in range (design brief §15).
    assert state.status == ProtectionStatus.TRIPPED


def test_post_shutdown_scenario_shows_bounded_decay_heat():
    from plant.power_station import NuclearPowerStation

    station = NuclearPowerStation(units=1, reactor_power_mw=3400.0, electrical_capacity_mw=1300.0)
    result = station.run(duration=900.0, scenario="protective_shutdown", timestep=0.2, seed=7)

    df = result.to_dataframe()
    tail = df[df["simulation_time_s"] > 800.0]
    assert (tail["reactor_status"] == "TRIPPED").any()
    # Residual thermal energy must remain bounded (finite, not runaway).
    assert (tail["fuel_temperature_c"] < 3000.0).all()
    assert (tail["fuel_temperature_c"] > -50.0).all()
