"""Thermal-hydraulics tests: core thermal lag, heat-exchanger direction,
energy balance sanity."""

from __future__ import annotations

from config import FuelConfig, SteamGeneratorConfig
from core.core_thermal_model import CoreThermalModel
from primary.steam_generators import SteamGenerator, saturation_temperature_c


def test_core_thermal_model_has_lag_not_instantaneous_response():
    cfg = FuelConfig()
    model = CoreThermalModel(cfg)

    # Start at (approximately) equilibrium for 3400 MW: Q = UA * (T_fuel - T_coolant).
    coolant_t = 310.0
    fuel_t = coolant_t + 3400.0 / cfg.fuel_to_coolant_ua_mw_per_c

    # Step-change thermal power up; the new equilibrium fuel temperature
    # would be several degrees higher, but a single small timestep must
    # only move a small fraction of the way there -- that is the required
    # thermal lag (design brief §6).
    new_equilibrium_fuel_t = coolant_t + 4400.0 / cfg.fuel_to_coolant_ua_mw_per_c
    result = model.step(
        fuel_temperature_c=fuel_t,
        coolant_temperature_avg_c=coolant_t,
        thermal_power_mw=4400.0,
        coolant_inlet_temperature_c=292.0,
        coolant_mass_flow_kg_s=18500.0,
        coolant_specific_heat_kj_per_kg_c=5.5,
        dt=0.1,
    )

    assert result.fuel_temperature_c > fuel_t
    assert result.fuel_temperature_c < new_equilibrium_fuel_t


def test_core_thermal_model_conserves_energy_direction():
    model = CoreThermalModel(FuelConfig())
    # No thermal power in, flow removing heat -> both nodes should cool.
    # (A moderate, physically-plausible fuel/coolant temperature split is
    # used here -- an extreme split would make the fuel-to-coolant heat
    # transfer term dominate and could transiently warm the coolant node.)
    result = model.step(
        fuel_temperature_c=340.0,
        coolant_temperature_avg_c=320.0,
        thermal_power_mw=0.0,
        coolant_inlet_temperature_c=292.0,
        coolant_mass_flow_kg_s=18500.0,
        coolant_specific_heat_kj_per_kg_c=5.5,
        dt=1.0,
    )
    assert result.fuel_temperature_c < 340.0
    assert result.coolant_temperature_avg_c < 320.0


def test_steam_generator_heat_flows_from_primary_to_secondary():
    sg = SteamGenerator(SteamGeneratorConfig())
    result = sg.step(
        primary_inlet_temperature_c=325.0,
        primary_mass_flow_kg_s=4625.0,
        primary_specific_heat_kj_per_kg_c=5.5,
        header_pressure_mpa=6.9,
        dt=1.0,
    )
    assert result.heat_transferred_mw > 0.0
    assert result.primary_outlet_temperature_c < 325.0


def test_saturation_temperature_proxy_is_monotonic_in_pressure():
    assert saturation_temperature_c(0.1) < saturation_temperature_c(7.0) < saturation_temperature_c(15.5)
