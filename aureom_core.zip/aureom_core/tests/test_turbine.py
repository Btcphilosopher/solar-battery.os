"""Turbine / generator dynamics tests."""

from __future__ import annotations

from config import GeneratorConfig, TurbineConfig
from secondary.generator import TurbineGenerator
from secondary.turbine import Turbine


def test_turbine_power_increases_with_steam_flow():
    cfg = TurbineConfig()
    turbine = Turbine(cfg)

    low = turbine.step(steam_flow_kg_s=200.0, generator_counter_torque_nm=0.0, dt=1.0)
    turbine2 = Turbine(cfg)
    high = turbine2.step(steam_flow_kg_s=1800.0, generator_counter_torque_nm=0.0, dt=1.0)

    assert high.mechanical_power_mw > low.mechanical_power_mw
    assert low.mechanical_power_mw >= 0.0


def test_turbine_mechanical_power_bounded_near_rated():
    cfg = TurbineConfig()
    turbine = Turbine(cfg)
    result = turbine.step(steam_flow_kg_s=1.0e6, generator_counter_torque_nm=0.0, dt=1.0)
    assert result.mechanical_power_mw <= cfg.rated_mechanical_power_mw * 1.05 + 1.0e-6


def test_turbine_rotor_speed_stays_bounded_and_finite():
    cfg = TurbineConfig()
    turbine = Turbine(cfg)
    for _ in range(500):
        result = turbine.step(steam_flow_kg_s=1890.0, generator_counter_torque_nm=0.0, dt=0.1)
        assert result.rotor_speed_rad_s >= 0.0
        assert result.rotor_speed_rad_s <= cfg.synchronous_speed_rad_s * 1.2
        assert result.rotor_speed_rad_s == result.rotor_speed_rad_s  # NaN check


def test_generator_electrical_power_below_mechanical_input():
    gen = TurbineGenerator(GeneratorConfig())
    result = gen.step(mechanical_power_mw=1000.0, rotor_speed_rad_s=314.159)
    assert 0.0 < result.electrical_power_mw <= 1000.0
    assert result.counter_torque_nm > 0.0
