"""Simulation-engine tests: determinism, timestep validation, export,
and numerical-safety guards."""

from __future__ import annotations

import os

import pytest

from plant.power_station import NuclearPowerStation
from simulation.timestep import SimulationStateError, validate_timestep


def _run(seed: int = 42, duration: float = 300.0, scenario: str = "grid_fluctuation"):
    station = NuclearPowerStation(units=1, reactor_power_mw=3400.0, electrical_capacity_mw=1300.0)
    return station.run(duration=duration, scenario=scenario, timestep=0.2, seed=seed)


def test_simulation_is_deterministic():
    result_a = _run(seed=42)
    result_b = _run(seed=42)

    df_a = result_a.to_dataframe()
    df_b = result_b.to_dataframe()

    assert df_a.equals(df_b)
    assert result_a.metadata.configuration_hash == result_b.metadata.configuration_hash


def test_different_seeds_can_diverge_on_stochastic_profile():
    result_a = _run(seed=1, scenario="grid_fluctuation")
    result_b = _run(seed=2, scenario="grid_fluctuation")

    df_a = result_a.to_dataframe()
    df_b = result_b.to_dataframe()
    assert not df_a["grid_demand_mw"].equals(df_b["grid_demand_mw"])


def test_timestep_validation_rejects_invalid_values():
    with pytest.raises(SimulationStateError):
        validate_timestep(0.0)
    with pytest.raises(SimulationStateError):
        validate_timestep(-1.0)
    with pytest.raises(SimulationStateError):
        validate_timestep(float("nan"))
    with pytest.raises(SimulationStateError):
        validate_timestep(100.0, max_dt=5.0)
    validate_timestep(0.1)  # should not raise


def test_all_telemetry_values_finite():
    result = _run(duration=120.0)
    df = result.to_dataframe()
    numeric = df.select_dtypes(include="number")
    assert numeric.replace([float("inf"), float("-inf")], pd_na()).isna().sum().sum() == 0


def pd_na():
    import numpy as np

    return np.nan


def test_csv_and_json_export_round_trip(tmp_path):
    result = _run(duration=60.0)

    csv_path = tmp_path / "telemetry.csv"
    json_path = tmp_path / "telemetry.json"
    result.to_csv(str(csv_path))
    result.to_json(str(json_path))

    assert os.path.getsize(csv_path) > 0
    assert os.path.getsize(json_path) > 0

    import pandas as pd

    df = pd.read_csv(csv_path)
    assert len(df) == len(result.telemetry)


def test_multi_unit_station_runs_and_reports_per_unit_telemetry():
    station = NuclearPowerStation(units=2, reactor_power_mw=3400.0, electrical_capacity_mw=1300.0)
    result = station.run(duration=60.0, scenario="multi_unit_load_following", timestep=0.5, seed=3)

    df = result.to_dataframe()
    assert set(df["unit_id"].unique()) == {0, 1}
