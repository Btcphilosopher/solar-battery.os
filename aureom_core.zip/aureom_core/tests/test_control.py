"""Control-system tests: PID saturation/anti-windup, load-following tracking."""

from __future__ import annotations

from control.pid import PIDController
from plant.power_station import NuclearPowerStation


def test_pid_output_respects_saturation():
    pid = PIDController(kp=10.0, ki=5.0, kd=0.0, output_min=-1.0, output_max=1.0)
    output = None
    for _ in range(100):
        output = pid.step(setpoint=100.0, measurement=0.0, dt=0.1)
    assert -1.0 <= output <= 1.0


def test_pid_anti_windup_recovers_without_large_overshoot():
    pid = PIDController(kp=1.0, ki=2.0, kd=0.0, output_min=-1.0, output_max=1.0)

    # Force long saturation (large sustained error).
    for _ in range(200):
        pid.step(setpoint=1000.0, measurement=0.0, dt=0.1)

    # Now measurement suddenly matches setpoint -- a windup-prone
    # integrator would keep the output pinned at saturation for a long
    # time; with anti-windup it should be able to move off it quickly.
    outputs = [pid.step(setpoint=1000.0, measurement=1000.0, dt=0.1) for _ in range(20)]
    assert outputs[-1] < 1.0 - 1.0e-6 or abs(outputs[-1]) < 1.0


def test_pid_rate_limit_bounds_output_change_per_step():
    pid = PIDController(kp=100.0, ki=0.0, kd=0.0, output_min=-1.0, output_max=1.0, rate_limit_per_s=0.5)
    pid.reset(0.0)
    first = pid.step(setpoint=1.0, measurement=0.0, dt=0.1)
    assert abs(first) <= 0.5 * 0.1 + 1.0e-9


def test_station_tracks_grid_demand_within_reasonable_bound():
    station = NuclearPowerStation(units=1, reactor_power_mw=3400.0, electrical_capacity_mw=1300.0)
    result = station.run(duration=600.0, scenario="nominal", timestep=0.2, seed=1)

    df = result.to_dataframe()
    steady = df[df["simulation_time_s"] > 300.0]
    tracking_error = (steady["net_electrical_power_mw"] - steady["grid_demand_mw"]).abs().mean()

    # Loose bound: the load-following controllers should bring the plant
    # within a modest fraction of rated capacity of the constant demand
    # signal well before the run ends.
    assert tracking_error < 0.08 * 1300.0
