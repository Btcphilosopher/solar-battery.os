"""
Central digital-twin state and simulation-result containers.
================================================================

:class:`PlantState` is the single, fully observable snapshot of the
plant at one instant in simulated time (design brief §20) — every field
that matters for control, protection, safety, or analysis purposes is
present here rather than buried inside a subsystem object.

:class:`SimulationResult` is the object returned by
``NuclearPowerStation.run(...)``; it carries the full telemetry history
plus reproducibility metadata, and exposes ``.plot()``, ``.report()``,
``.to_csv()`` and ``.to_json()`` convenience methods.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone

import pandas as pd


@dataclass
class PlantState:
    simulation_time_s: float
    unit_id: int = 0

    # --- Reactor / core ---
    reactor_normalized_power: float = 0.0
    reactor_thermal_power_mw: float = 0.0
    reactor_fission_power_mw: float = 0.0
    reactor_decay_power_mw: float = 0.0
    fuel_temperature_c: float = 0.0
    coolant_temperature_c: float = 0.0
    total_reactivity: float = 0.0

    # --- Primary system ---
    coolant_flow_kg_s: float = 0.0
    coolant_flow_pct: float = 0.0
    pressurizer_pressure_mpa: float = 0.0

    # --- Secondary system ---
    steam_pressure_mpa: float = 0.0
    steam_flow_kg_s: float = 0.0
    turbine_speed_rad_s: float = 0.0
    turbine_power_mw: float = 0.0
    condenser_backpressure_kpa: float = 0.0

    # --- Electrical ---
    gross_electrical_power_mw: float = 0.0
    auxiliary_power_mw: float = 0.0
    net_electrical_power_mw: float = 0.0
    export_power_mw: float = 0.0
    grid_demand_mw: float = 0.0
    grid_frequency_hz: float = 50.0

    # --- Control ---
    control_rod_position_pct: float = 0.0
    valve_position_pct: float = 0.0

    # --- Protection / safety ---
    reactor_status: str = "SHUTDOWN"
    protection_status: str = "NORMAL"
    safety_status: str = "NORMAL"
    active_trips: str = ""
    active_alarms: str = ""
    fuel_thermal_margin_c: float = 0.0
    coolant_thermal_margin_c: float = 0.0
    emergency_cooling_active: bool = False
    containment_pressure_kpa: float = 101.3


@dataclass
class SimulationMetadata:
    simulation_id: str
    software_version: str
    configuration_hash: str
    scenario: str
    random_seed: int
    timestep_s: float
    duration_s: float
    units: int = 1
    nominal_thermal_power_mw: float = 0.0
    nominal_electrical_power_mw: float = 0.0
    generated_at_utc: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


@dataclass
class SimulationResult:
    metadata: SimulationMetadata
    telemetry: list  # list[PlantState]
    events: list = field(default_factory=list)  # list[Event] (see simulation/events.py)

    def to_dataframe(self) -> pd.DataFrame:
        return pd.DataFrame([asdict(s) for s in self.telemetry])

    def to_csv(self, path: str) -> None:
        self.to_dataframe().to_csv(path, index=False)

    def to_json(self, path: str) -> None:
        payload = {
            "metadata": asdict(self.metadata),
            "telemetry": [asdict(s) for s in self.telemetry],
            "events": [asdict(e) for e in self.events],
        }
        with open(path, "w") as f:
            json.dump(payload, f, indent=2)

    def plot(self, out_path: str = None, show: bool = False):
        from visualisation.plots import plot_summary

        return plot_summary(self, out_path=out_path, show=show)

    def report(self) -> str:
        from analysis.reporting import generate_report

        text = generate_report(self)
        print(text)
        return text
