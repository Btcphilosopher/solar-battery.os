"""
Timestep configuration and numerical-safety utilities.
==========================================================

Small, dependency-free helpers used throughout the plant model to keep
integration bounded and detect invalid numerical states early (design
brief §30): bounded states, finite-value checks, and timestep
validation, rather than letting NaN/Inf propagate silently through the
plant.
"""

from __future__ import annotations

import math
from dataclasses import dataclass


class SimulationStateError(RuntimeError):
    """Raised when the plant model reaches a numerically invalid state."""


def validate_timestep(dt: float, max_dt: float = 5.0) -> None:
    if not math.isfinite(dt) or dt <= 0.0:
        raise SimulationStateError(f"Invalid timestep: {dt!r} (must be finite and > 0)")
    if dt > max_dt:
        raise SimulationStateError(f"Timestep {dt}s exceeds the maximum stable timestep {max_dt}s")


def is_finite(value: float) -> bool:
    return isinstance(value, (int, float)) and math.isfinite(value)


def assert_finite(name: str, value: float) -> None:
    if not is_finite(value):
        raise SimulationStateError(f"Non-finite value detected for '{name}': {value!r}")


def clamp(value: float, lower: float, upper: float) -> float:
    return max(lower, min(value, upper))


@dataclass(frozen=True)
class TimestepPolicy:
    """Bundles the outer simulation timestep with the maximum stable
    timestep the plant model will accept, independent of the finer
    internal sub-stepping used by the stiff neutron-kinetics solver."""

    dt_s: float
    max_dt_s: float = 5.0

    def validate(self) -> None:
        validate_timestep(self.dt_s, self.max_dt_s)
