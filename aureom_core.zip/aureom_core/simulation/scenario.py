"""
Scenario configuration and registry.
=======================================

A :class:`ScenarioConfig` fully specifies one reproducible simulation
run: duration, timestep, initial conditions, the grid demand profile,
the fault schedule, and the random seed (design brief §28). Named
scenario *builders* live in the ``scenarios/`` package and register
themselves here so that ``NuclearPowerStation.run(scenario="...")`` can
resolve a scenario by name.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Optional

from config import PlantConfig
from electrical.load_model import LoadProfile
from simulation.scheduler import FaultSchedule


@dataclass
class ScenarioConfig:
    name: str
    description: str
    duration_s: float
    timestep_s: float
    initial_power_fraction: float
    load_profile: LoadProfile
    fault_schedule: FaultSchedule = field(default_factory=FaultSchedule)
    random_seed: int = 42
    telemetry_decimation: int = 1


_REGISTRY: dict[str, Callable[..., ScenarioConfig]] = {}


def register_scenario(name: str, builder: Callable[..., ScenarioConfig]) -> None:
    _REGISTRY[name] = builder


def get_scenario(
    name: str,
    plant_cfg: PlantConfig,
    electrical_capacity_mw: float,
    **overrides,
) -> ScenarioConfig:
    if name not in _REGISTRY:
        available = ", ".join(sorted(_REGISTRY))
        raise KeyError(f"Unknown scenario '{name}'. Available scenarios: {available}")
    return _REGISTRY[name](plant_cfg, electrical_capacity_mw, **overrides)


def available_scenarios() -> list[str]:
    return sorted(_REGISTRY)
