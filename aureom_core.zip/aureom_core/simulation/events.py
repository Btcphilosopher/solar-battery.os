"""
Simulation event log.
========================

Timestamped, structured event records (design brief §22) that give the
telemetry a readable narrative on top of the raw time-series: load
changes, trips, faults, disturbances, and recoveries.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class EventType(str, Enum):
    SIMULATION_START = "SIMULATION_START"
    SIMULATION_END = "SIMULATION_END"
    LOAD_CHANGE = "LOAD_CHANGE"
    REACTOR_TRIP = "REACTOR_TRIP"
    TURBINE_TRIP = "TURBINE_TRIP"
    PUMP_DEGRADATION = "PUMP_DEGRADATION"
    GRID_DISTURBANCE = "GRID_DISTURBANCE"
    SENSOR_FAULT = "SENSOR_FAULT"
    CONTROL_ACTUATOR_FAULT = "CONTROL_ACTUATOR_FAULT"
    TEMPERATURE_EXCURSION = "TEMPERATURE_EXCURSION"
    EMERGENCY_COOLING_ACTIVATED = "EMERGENCY_COOLING_ACTIVATED"
    RECOVERY = "RECOVERY"


@dataclass
class Event:
    time_s: float
    type: EventType
    message: str
    unit_id: int = 0


@dataclass
class EventLog:
    events: list = field(default_factory=list)

    def record(self, time_s: float, event_type: EventType, message: str, unit_id: int = 0) -> None:
        self.events.append(Event(time_s=time_s, type=event_type, message=message, unit_id=unit_id))

    def as_list(self) -> list:
        return list(self.events)
