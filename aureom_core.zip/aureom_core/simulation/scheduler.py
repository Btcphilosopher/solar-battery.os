"""
Fault-injection scheduler.
=============================

General, deterministic fault-injection framework (design brief §19).
A :class:`Fault` describes a component, a failure mode, a severity
(0-1), and a time window; a :class:`FaultSchedule` is simply an ordered
collection of such faults. Because faults are pure data evaluated as a
function of simulation time, running the same schedule twice always
produces the same result.

Supported generic fault modes (interpreted by
safety/fault_detection.py): ``sensor_bias``, ``sensor_dropout``,
``pump_degradation``, ``valve_degradation``, ``actuator_failure``,
``communication_delay``, ``grid_disturbance``, ``coolant_flow_reduction``,
``turbine_efficiency_loss``.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class Fault:
    component: str
    mode: str
    severity: float
    start_time_s: float
    duration_s: float
    parameters: dict = field(default_factory=dict)

    def active_at(self, t: float) -> bool:
        return self.start_time_s <= t < (self.start_time_s + self.duration_s)


@dataclass
class FaultSchedule:
    faults: list = field(default_factory=list)

    def add(self, fault: Fault) -> None:
        self.faults.append(fault)

    def active_faults(self, t: float) -> list:
        return [f for f in self.faults if f.active_at(t)]
