"""
Deterministic simulation engine.
====================================

Drives the discrete-time plant-model loop described in the design brief
(§21): resolve the scenario, initialise the station, then for every
timestep evaluate the fault schedule and grid demand, step every unit
(which internally runs reactor physics, reactivity feedback, thermal
state, coolant system, steam generator, turbine, generator, auxiliary
loads, net output, control, fault detection, and protection/safety, in
that causal order — see plant/power_station.py), record telemetry, and
advance the clock.

Running the same :class:`~simulation.scenario.ScenarioConfig` (same
seed, same timestep, same duration) always produces identical output —
the load profile, fault schedule, and plant physics are all pure
functions of simulation time and prior state, with no unseeded
randomness anywhere in the loop.
"""

from __future__ import annotations

import hashlib
import json
import uuid
from dataclasses import asdict

import scenarios  # noqa: F401 - registers the built-in scenario library
from config import SOFTWARE_VERSION
from simulation.events import EventLog, EventType
from simulation.scenario import get_scenario
from simulation.simulation_state import PlantState, SimulationMetadata, SimulationResult
from simulation.timestep import SimulationStateError, TimestepPolicy, is_finite


def _assert_finite_state(state: PlantState) -> None:
    for name, value in asdict(state).items():
        if isinstance(value, float) and not is_finite(value):
            raise SimulationStateError(f"Non-finite telemetry value at t={state.simulation_time_s}s: {name}={value!r}")


class SimulationEngine:
    def __init__(self, station):
        self.station = station

    def run(
        self,
        scenario: str = "nominal",
        duration: float = None,
        timestep: float = None,
        seed: int = None,
        **overrides,
    ) -> SimulationResult:
        # `seed` must reach the scenario *builder* (not just the resulting
        # ScenarioConfig.random_seed field afterward), since builders seed
        # their LoadProfile's pseudo-random elements at construction time.
        if seed is not None:
            overrides.setdefault("random_seed", seed)

        scenario_cfg = get_scenario(scenario, self.station.plant_config, self.station.electrical_capacity_mw, **overrides)

        if duration is not None:
            scenario_cfg.duration_s = duration
        if timestep is not None:
            scenario_cfg.timestep_s = timestep
        if seed is not None:
            scenario_cfg.random_seed = seed

        dt = scenario_cfg.timestep_s
        TimestepPolicy(dt).validate()

        self.station.initialize_at_power(scenario_cfg.initial_power_fraction)

        event_log = EventLog()
        telemetry: list[PlantState] = []

        n_steps = max(int(round(scenario_cfg.duration_s / dt)), 0)
        event_log.record(0.0, EventType.SIMULATION_START, f"Scenario '{scenario_cfg.name}' started")

        t = 0.0
        n_units = max(len(self.station.units), 1)
        for step_index in range(n_steps):
            active_faults = scenario_cfg.fault_schedule.active_faults(t)
            site_demand_mw = scenario_cfg.load_profile.demand_mw(t)
            per_unit_demand_mw = site_demand_mw / n_units

            for unit in self.station.units:
                state = unit.step(dt, t, per_unit_demand_mw, active_faults, event_log)
                _assert_finite_state(state)
                if step_index % max(scenario_cfg.telemetry_decimation, 1) == 0:
                    telemetry.append(state)

            t += dt

        event_log.record(t, EventType.SIMULATION_END, "Simulation complete")

        metadata = SimulationMetadata(
            simulation_id=str(uuid.uuid4()),
            software_version=SOFTWARE_VERSION,
            configuration_hash=self._configuration_hash(scenario_cfg),
            scenario=scenario_cfg.name,
            random_seed=scenario_cfg.random_seed,
            timestep_s=dt,
            duration_s=scenario_cfg.duration_s,
            units=self.station.units_count,
            nominal_thermal_power_mw=self.station.plant_config.reactor.nominal_thermal_power_mw,
            nominal_electrical_power_mw=self.station.plant_config.generator.rated_electrical_power_mw,
        )

        return SimulationResult(metadata=metadata, telemetry=telemetry, events=event_log.as_list())

    def _configuration_hash(self, scenario_cfg) -> str:
        payload = {
            "plant_config": asdict(self.station.plant_config),
            "scenario": scenario_cfg.name,
            "seed": scenario_cfg.random_seed,
            "timestep_s": scenario_cfg.timestep_s,
            "duration_s": scenario_cfg.duration_s,
            "units": self.station.units_count,
        }
        blob = json.dumps(payload, sort_keys=True, default=str).encode("utf-8")
        return hashlib.sha256(blob).hexdigest()[:16]
