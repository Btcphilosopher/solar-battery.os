"""
Fault detection / interpretation layer.
==========================================

Translates the currently active :class:`~simulation.scheduler.Fault`
objects into a :class:`FaultEffects` bundle that the plant model applies
to the relevant subsystem (pump health, sensor readings, valve and
actuator degradation, turbine efficiency, coolant flow, grid
disturbance), plus a list of human-readable alarm labels for the safety
state and telemetry.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from simulation.scheduler import Fault


@dataclass
class FaultEffects:
    pump_health_multiplier: float = 1.0
    coolant_flow_multiplier: float = 1.0
    turbine_efficiency_multiplier: float = 1.0
    valve_health_multiplier: float = 1.0
    actuator_health_multiplier: float = 1.0
    sensor_bias_fuel_temp_c: float = 0.0
    sensor_bias_coolant_temp_c: float = 0.0
    sensor_dropout: bool = False
    communication_delay_s: float = 0.0
    grid_disturbance_mw: float = 0.0
    alarms: tuple = field(default_factory=tuple)


class FaultDetector:
    """Stateless interpreter: pure function of the currently active faults."""

    def apply(self, active_faults: list[Fault]) -> FaultEffects:
        effects = FaultEffects()
        alarms = []

        for fault in active_faults:
            severity = max(0.0, min(fault.severity, 1.0))
            alarms.append(f"FAULT:{fault.component}:{fault.mode}")

            if fault.mode == "pump_degradation":
                effects.pump_health_multiplier = min(effects.pump_health_multiplier, 1.0 - severity)
            elif fault.mode == "coolant_flow_reduction":
                effects.coolant_flow_multiplier = min(effects.coolant_flow_multiplier, 1.0 - severity)
            elif fault.mode == "turbine_efficiency_loss":
                effects.turbine_efficiency_multiplier = min(effects.turbine_efficiency_multiplier, 1.0 - severity)
            elif fault.mode == "valve_degradation":
                effects.valve_health_multiplier = min(effects.valve_health_multiplier, 1.0 - severity)
            elif fault.mode == "actuator_failure":
                effects.actuator_health_multiplier = min(effects.actuator_health_multiplier, 1.0 - severity)
            elif fault.mode == "sensor_bias":
                target = fault.parameters.get("target", "coolant_temperature")
                bias_c = fault.parameters.get("bias_c", 10.0) * severity
                if target == "fuel_temperature":
                    effects.sensor_bias_fuel_temp_c += bias_c
                else:
                    effects.sensor_bias_coolant_temp_c += bias_c
            elif fault.mode == "sensor_dropout":
                effects.sensor_dropout = True
            elif fault.mode == "communication_delay":
                effects.communication_delay_s = max(effects.communication_delay_s, fault.parameters.get("delay_s", 1.0))
            elif fault.mode == "grid_disturbance":
                effects.grid_disturbance_mw += fault.parameters.get("magnitude_mw", 50.0) * severity * (
                    1.0 if fault.parameters.get("direction", "drop") == "surge" else -1.0
                )

        effects.alarms = tuple(alarms)
        return effects
