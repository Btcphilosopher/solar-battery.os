"""
Thermal-margin calculations.
===============================

Distance-to-limit calculations against the synthetic alert thresholds in
:class:`config.SafetyConfig`. A positive margin means the plant is
operating below the configured alert threshold; a margin approaching or
crossing zero indicates the simulated thermal state is approaching (or
has breached) the synthetic limit.
"""

from __future__ import annotations

from config import SafetyConfig


def fuel_thermal_margin_c(cfg: SafetyConfig, fuel_temperature_c: float) -> float:
    return cfg.fuel_temperature_margin_alert_c - fuel_temperature_c


def coolant_thermal_margin_c(cfg: SafetyConfig, coolant_temperature_c: float) -> float:
    return cfg.coolant_temperature_margin_alert_c - coolant_temperature_c
