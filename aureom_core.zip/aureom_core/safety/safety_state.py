"""Observable state for the plant-level safety subsystem."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class SafetyStatus(str, Enum):
    NORMAL = "NORMAL"
    DEGRADED = "DEGRADED"
    PROTECTIVE = "PROTECTIVE"
    SHUTDOWN = "SHUTDOWN"


@dataclass
class SafetyState:
    status: SafetyStatus = SafetyStatus.NORMAL
    active_alarms: tuple = field(default_factory=tuple)
    fault_count: int = 0

    fuel_thermal_margin_c: float = 0.0
    coolant_thermal_margin_c: float = 0.0

    emergency_cooling_available: bool = True
    emergency_cooling_activated: bool = False
    emergency_cooling_flow_fraction: float = 0.0
    emergency_cooling_heat_removal_mw: float = 0.0

    containment_pressure_kpa: float = 101.3
