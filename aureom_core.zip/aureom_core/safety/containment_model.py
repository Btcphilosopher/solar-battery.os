"""
Containment pressure proxy.
==============================

A deliberately minimal placeholder representing containment atmosphere
pressure. It relaxes toward atmospheric pressure under normal conditions
and toward a mildly elevated pressure while the plant is in a
PROTECTIVE safety state with emergency cooling active (representing, in
a purely illustrative way, heat/mass release into the containment
volume). This is not a containment thermal-hydraulics analysis.
"""

from __future__ import annotations

from dataclasses import dataclass

from config import SafetyConfig

ATMOSPHERIC_PRESSURE_KPA = 101.3


@dataclass
class ContainmentModel:
    cfg: SafetyConfig
    pressure_kpa: float = ATMOSPHERIC_PRESSURE_KPA

    def step(self, emergency_cooling_active: bool, decay_power_mw: float, dt: float) -> float:
        cfg = self.cfg
        if emergency_cooling_active and decay_power_mw > 1.0:
            target = min(
                ATMOSPHERIC_PRESSURE_KPA + 0.02 * decay_power_mw,
                cfg.containment_design_pressure_kpa,
            )
        else:
            target = ATMOSPHERIC_PRESSURE_KPA

        tau = 120.0
        self.pressure_kpa += (target - self.pressure_kpa) * (dt / tau)
        self.pressure_kpa = max(50.0, min(self.pressure_kpa, cfg.containment_design_pressure_kpa * 1.2))
        return self.pressure_kpa
