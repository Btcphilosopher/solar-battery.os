"""
Emergency cooling system (simulation-level proxy).
======================================================

A simplified emergency-cooling subsystem used to study whether the
simulated thermal state remains bounded under hypothetical fault
conditions. It is NOT a model of, and must not be read as, any actual
certified nuclear safety system. It activates automatically when primary
flow has degraded below a configured threshold while thermal margin is
eroding, and ramps its heat-removal capacity up over a configured time
constant once activated:

    d(flow_fraction)/dt = (target_fraction - flow_fraction) / tau_ramp
    heat_removal = flow_fraction * cooling_capacity
"""

from __future__ import annotations

from dataclasses import dataclass

from config import SafetyConfig


@dataclass
class EmergencyCoolingResult:
    available: bool
    activated: bool
    flow_fraction: float
    heat_removal_mw: float


@dataclass
class EmergencyCoolingSystem:
    cfg: SafetyConfig
    available: bool = True
    _flow_fraction: float = 0.0
    _latched: bool = False

    def step(
        self,
        coolant_flow_pct: float,
        fuel_thermal_margin_c: float,
        coolant_thermal_margin_c: float,
        dt: float,
    ) -> EmergencyCoolingResult:
        cfg = self.cfg

        activation_needed = (
            coolant_flow_pct < cfg.emergency_cooling_activation_flow_pct
            and (fuel_thermal_margin_c < 150.0 or coolant_thermal_margin_c < 40.0)
        )
        if activation_needed and self.available:
            self._latched = True

        target_fraction = 1.0 if self._latched and self.available else 0.0
        tau = max(cfg.emergency_cooling_ramp_time_s, 1.0e-3)
        self._flow_fraction += (target_fraction - self._flow_fraction) * (dt / tau)
        self._flow_fraction = max(0.0, min(self._flow_fraction, 1.0))

        heat_removal_mw = self._flow_fraction * cfg.emergency_cooling_capacity_mw

        return EmergencyCoolingResult(
            available=self.available,
            activated=self._latched,
            flow_fraction=self._flow_fraction,
            heat_removal_mw=heat_removal_mw,
        )
