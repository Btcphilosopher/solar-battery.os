"""Observable state for the control subsystem."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class ControlMode(str, Enum):
    MANUAL = "MANUAL"
    AUTOMATIC = "AUTOMATIC"
    LOAD_FOLLOWING = "LOAD_FOLLOWING"


@dataclass
class ControlState:
    mode: ControlMode = ControlMode.AUTOMATIC

    target_plant_output_mw: float = 0.0
    actual_plant_output_mw: float = 0.0
    power_tracking_error_mw: float = 0.0

    reactor_power_setpoint_fraction: float = 0.0
    rod_requested_position_pct: float = 0.0
    rod_actual_position_pct: float = 0.0
    rod_control_reactivity: float = 0.0

    turbine_load_setpoint_mw: float = 0.0
    valve_position_pct: float = 0.0
