"""
Reusable PID controller.
===========================

A general-purpose proportional-integral-derivative controller with the
practical safeguards a real control-system implementation needs:

* output saturation (min/max clamping)
* back-calculation anti-windup (prevents integral wind-up while saturated)
* output rate limiting (bounds how fast the actuator demand can move)
* an error deadband (ignores noise-level error before it reaches the
  integral term)

    u(t) = Kp*e(t) + Ki*integral(e) + Kd*de/dt,  clamped and rate-limited
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Optional


def clamp(value: float, lower: float, upper: float) -> float:
    return max(lower, min(value, upper))


@dataclass
class PIDController:
    kp: float
    ki: float
    kd: float
    output_min: float = -1.0
    output_max: float = 1.0
    rate_limit_per_s: Optional[float] = None
    deadband: float = 0.0
    anti_windup_gain: float = 1.0

    _integral: float = field(default=0.0, init=False, repr=False)
    _prev_error: Optional[float] = field(default=None, init=False, repr=False)
    _prev_output: float = field(default=0.0, init=False, repr=False)

    def reset(self, initial_output: float = 0.0) -> None:
        self._integral = 0.0
        self._prev_error = None
        self._prev_output = clamp(initial_output, self.output_min, self.output_max)

    def step(self, setpoint: float, measurement: float, dt: float) -> float:
        if dt <= 0.0:
            return self._prev_output

        error = setpoint - measurement
        if abs(error) < self.deadband:
            error = 0.0

        derivative = 0.0
        if self._prev_error is not None:
            derivative = (error - self._prev_error) / dt

        proposed_integral = self._integral + error * dt

        unclamped = self.kp * error + self.ki * proposed_integral + self.kd * derivative
        output = clamp(unclamped, self.output_min, self.output_max)

        # Back-calculation anti-windup: pull the integral term back toward
        # a value consistent with the clamped output, rather than letting
        # it keep accumulating while the actuator is saturated.
        saturation_error = unclamped - output
        if abs(self.ki) > 1.0e-12:
            proposed_integral -= self.anti_windup_gain * saturation_error / self.ki
        self._integral = proposed_integral

        if self.rate_limit_per_s is not None:
            max_delta = self.rate_limit_per_s * dt
            output = clamp(output, self._prev_output - max_delta, self._prev_output + max_delta)
            output = clamp(output, self.output_min, self.output_max)

        if not math.isfinite(output):
            output = self._prev_output

        self._prev_error = error
        self._prev_output = output
        return output
