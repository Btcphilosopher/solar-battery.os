"""
Reactor controller.
=====================

Closes the loop between the demanded normalized reactor power (from the
load-following coordinator or a scenario setpoint) and the measured
normalized power from neutron kinetics, by commanding the control-rod
actuator's movement rate. This is the "REACTOR CONTROLLER" node of the
hierarchical control architecture in the design brief (§12):

    PLANT CONTROLLER -> REACTOR CONTROLLER -> control rods -> reactivity -> core power
"""

from __future__ import annotations

from dataclasses import dataclass

from config import ControlConfig, ReactivityConfig
from control.control_rods import ControlRodActuator
from control.pid import PIDController


@dataclass
class ReactorController:
    control_cfg: ControlConfig
    reactivity_cfg: ReactivityConfig

    def __post_init__(self) -> None:
        self.pid = PIDController(
            kp=self.control_cfg.reactor_power_pid_kp,
            ki=self.control_cfg.reactor_power_pid_ki,
            kd=self.control_cfg.reactor_power_pid_kd,
            output_min=-1.0,
            output_max=1.0,
            rate_limit_per_s=2.0,
            deadband=0.0015,
        )
        self.rod_actuator = ControlRodActuator(self.control_cfg, self.reactivity_cfg)

    def scram(self) -> None:
        self.rod_actuator.scram()

    def reset_scram(self) -> None:
        self.rod_actuator.reset_scram()

    def step(self, power_setpoint_fraction: float, measured_power_fraction: float, dt: float) -> tuple[float, float, float]:
        """Returns (control_reactivity, rod_requested_position_pct, rod_actual_position_pct)."""

        rate_demand = self.pid.step(power_setpoint_fraction, measured_power_fraction, dt)
        if not self.rod_actuator.scram_active:
            self.rod_actuator.request_rate(rate_demand, dt)

        control_reactivity = self.rod_actuator.step(dt)
        return control_reactivity, self.rod_actuator.requested_position_pct, self.rod_actuator.position_pct
