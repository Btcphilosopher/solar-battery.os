"""
Turbine controller.
======================

Regulates the governor (throttle) valve opening to track a net-electrical
-output setpoint, the "TURBINE CONTROLLER" node of the hierarchical
control architecture (design brief §12):

    PLANT CONTROLLER -> TURBINE CONTROLLER -> steam valve -> steam flow -> turbine power
"""

from __future__ import annotations

from dataclasses import dataclass

from config import ControlConfig
from control.pid import PIDController


@dataclass
class TurbineController:
    control_cfg: ControlConfig
    initial_valve_position_pct: float = 0.0

    def __post_init__(self) -> None:
        self.pid = PIDController(
            kp=self.control_cfg.turbine_load_pid_kp,
            ki=self.control_cfg.turbine_load_pid_ki,
            kd=self.control_cfg.turbine_load_pid_kd,
            output_min=0.0,
            output_max=100.0,
            rate_limit_per_s=self.control_cfg.valve_max_rate_pct_per_s,
            deadband=0.05,
        )
        self.pid.reset(self.initial_valve_position_pct)

    def trip(self) -> None:
        self.pid.reset(0.0)

    def step(self, load_setpoint_mw: float, measured_output_mw: float, dt: float) -> float:
        return self.pid.step(load_setpoint_mw, measured_output_mw, dt)
