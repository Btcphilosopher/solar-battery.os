"""
Load-following coordinator.
==============================

The "PLANT CONTROLLER" node of the hierarchical control architecture
(design brief §12-13): translates a grid demand signal into a
rate-limited plant output target, then derives consistent setpoints for
the reactor controller (normalized thermal-power fraction) and the
turbine controller (net electrical-output MW):

    Grid Demand -> [ramp rate limit] -> Target Plant Output
        -> Reactor Controller setpoint (fraction of thermal rating)
        -> Turbine Controller setpoint (MW)
"""

from __future__ import annotations

from dataclasses import dataclass

from config import ControlConfig


@dataclass
class LoadFollowingCoordinator:
    control_cfg: ControlConfig
    electrical_capacity_mw: float
    target_plant_output_mw: float = 0.0

    def step(self, grid_demand_mw: float, dt: float) -> tuple[float, float]:
        """Returns (reactor_power_setpoint_fraction, turbine_load_setpoint_mw)."""

        max_delta = self.control_cfg.load_ramp_max_mw_per_min / 60.0 * dt
        error = grid_demand_mw - self.target_plant_output_mw
        delta = max(-max_delta, min(error, max_delta))
        self.target_plant_output_mw += delta
        self.target_plant_output_mw = max(0.0, min(self.target_plant_output_mw, self.electrical_capacity_mw * 1.05))

        reactor_power_setpoint_fraction = self.target_plant_output_mw / max(self.electrical_capacity_mw, 1.0e-6)
        turbine_load_setpoint_mw = self.target_plant_output_mw

        return reactor_power_setpoint_fraction, turbine_load_setpoint_mw
