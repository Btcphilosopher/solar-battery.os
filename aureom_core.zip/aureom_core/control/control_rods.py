"""
Control-rod actuator (abstract).
===================================

Abstract control-actuator model — deliberately not a model of any real
rod-drive mechanism or a source of operational procedure. Position is a
0-100 % stroke, where 0 = fully inserted (maximum negative worth) and
100 = fully withdrawn. Reactivity worth is mapped from position with a
simplified S-curve (steepest in the mid-stroke band, as is qualitatively
true of real rod worth curves, without reproducing any specific design's
curve), and movement is rate-limited and health-scaled to represent
actuator degradation or partial failure.

A SCRAM command overrides normal rate limiting and drives the rod fully
inserted within the configured scram insertion time.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from config import ControlConfig, ReactivityConfig


def _s_curve_fraction(position_pct: float) -> float:
    """Normalized (0-1) worth-vs-position S-curve: steepest around mid-stroke."""
    x = clamp01(position_pct / 100.0)
    return 0.5 * (1.0 - math.cos(math.pi * x))


def clamp01(x: float) -> float:
    return max(0.0, min(x, 1.0))


def solve_position_for_worth(worth_target: float, worth_full_stroke: float) -> float:
    """Inverse of the S-curve worth mapping: returns the rod position
    (0-100 %) whose control-reactivity worth equals ``worth_target``.
    Reactivity worth here only ever runs 0 (fully inserted) to
    ``worth_full_stroke`` (fully withdrawn), so a negative target simply
    clamps to the fully-inserted position — see the module docstring.
    """
    if worth_full_stroke <= 0.0:
        return 0.0
    fraction_needed = clamp01(worth_target / worth_full_stroke)
    x = math.acos(clamp(1.0 - 2.0 * fraction_needed, -1.0, 1.0)) / math.pi
    return x * 100.0


def clamp(value: float, lower: float, upper: float) -> float:
    return max(lower, min(value, upper))


@dataclass
class ControlRodActuator:
    control_cfg: ControlConfig
    reactivity_cfg: ReactivityConfig

    # Safe default: fully inserted (zero worth). Steady-power initial
    # conditions are established explicitly by
    # plant/nuclear_island.py's initialize_at_power(), which derives a
    # self-consistent rod position from the reactivity balance rather
    # than relying on this default.
    position_pct: float = 0.0
    requested_position_pct: float = 0.0
    actuator_health: float = 1.0
    scram_active: bool = False

    def request_position(self, position_pct: float) -> None:
        self.requested_position_pct = clamp01(position_pct / 100.0) * 100.0

    def request_rate(self, rate_fraction: float, dt: float) -> None:
        """Command a movement as a fraction (-1..1) of max rod speed for this step."""
        max_speed = self.control_cfg.rod_max_speed_pct_per_s
        delta = clamp01(abs(rate_fraction)) * max_speed * dt * (1.0 if rate_fraction >= 0 else -1.0)
        self.request_position(self.position_pct + delta)

    def scram(self) -> None:
        self.scram_active = True
        self.requested_position_pct = 0.0

    def reset_scram(self) -> None:
        self.scram_active = False

    def step(self, dt: float) -> float:
        """Advance actuator position and return the resulting control
        reactivity contribution (dk/k)."""

        if self.scram_active:
            full_stroke_time = max(self.reactivity_cfg.scram_insertion_time_s, 1.0e-3)
            max_speed = 100.0 / full_stroke_time
        else:
            max_speed = self.control_cfg.rod_max_speed_pct_per_s * max(self.actuator_health, 0.0)

        max_delta = max_speed * dt
        error = self.requested_position_pct - self.position_pct
        delta = max(-max_delta, min(error, max_delta))
        self.position_pct = clamp01((self.position_pct + delta) / 100.0) * 100.0

        worth_fraction = _s_curve_fraction(self.position_pct)
        control_reactivity = worth_fraction * self.control_cfg.rod_reactivity_worth_full_stroke
        return control_reactivity
