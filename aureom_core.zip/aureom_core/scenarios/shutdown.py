"""Controlled shutdown scenario: full power ramping down to house load."""

from __future__ import annotations

from config import PlantConfig
from electrical.load_model import LoadProfile
from simulation.scenario import ScenarioConfig, register_scenario
from simulation.scheduler import FaultSchedule


def build(plant_cfg: PlantConfig, electrical_capacity_mw: float, **overrides) -> ScenarioConfig:
    duration_s = overrides.get("duration_s", 5400.0)
    timestep_s = overrides.get("timestep_s", 0.1)
    seed = overrides.get("random_seed", 42)

    load_profile = LoadProfile(
        kind="evening_ramp",
        base_demand_mw=electrical_capacity_mw * 0.92,
        ramp_start_s=overrides.get("ramp_start_s", 600.0),
        ramp_duration_s=overrides.get("ramp_duration_s", 3600.0),
        ramp_delta_mw=electrical_capacity_mw * 0.88,
    )

    return ScenarioConfig(
        name="shutdown",
        description="Controlled, ramped power reduction from full load toward house load (not a protective trip).",
        duration_s=duration_s,
        timestep_s=timestep_s,
        initial_power_fraction=0.92,
        load_profile=load_profile,
        fault_schedule=FaultSchedule(),
        random_seed=seed,
    )


register_scenario("shutdown", build)
