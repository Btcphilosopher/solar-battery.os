"""Grid-disturbance scenario: a transient external grid-frequency event
superimposed on baseload demand."""

from __future__ import annotations

from config import PlantConfig
from electrical.load_model import LoadProfile
from simulation.scenario import ScenarioConfig, register_scenario
from simulation.scheduler import Fault, FaultSchedule


def build(plant_cfg: PlantConfig, electrical_capacity_mw: float, **overrides) -> ScenarioConfig:
    duration_s = overrides.get("duration_s", 1800.0)
    timestep_s = overrides.get("timestep_s", 0.1)
    seed = overrides.get("random_seed", 42)
    base_fraction = overrides.get("base_fraction", 0.9)

    fault_schedule = FaultSchedule()
    fault_schedule.add(
        Fault(
            component="grid",
            mode="grid_disturbance",
            severity=overrides.get("severity", 0.6),
            start_time_s=overrides.get("start_time_s", 300.0),
            duration_s=overrides.get("fault_duration_s", 20.0),
            parameters={"magnitude_mw": electrical_capacity_mw * 0.35, "direction": "drop"},
        )
    )

    return ScenarioConfig(
        name="grid_disturbance",
        description="Transient external grid demand/frequency disturbance during baseload operation.",
        duration_s=duration_s,
        timestep_s=timestep_s,
        initial_power_fraction=base_fraction,
        load_profile=LoadProfile(kind="constant", base_demand_mw=electrical_capacity_mw * base_fraction),
        fault_schedule=fault_schedule,
        random_seed=seed,
    )


register_scenario("grid_disturbance", build)
