"""Grid load-following scenarios: sinusoidal tracking, fluctuation,
morning/evening ramps, and a multi-unit variant."""

from __future__ import annotations

from config import PlantConfig
from electrical.load_model import LoadProfile
from simulation.scenario import ScenarioConfig, register_scenario
from simulation.scheduler import FaultSchedule


def _build(kind: str, name: str, description: str, plant_cfg: PlantConfig, electrical_capacity_mw: float, **overrides) -> ScenarioConfig:
    duration_s = overrides.get("duration_s", 3600.0)
    timestep_s = overrides.get("timestep_s", 0.1)
    seed = overrides.get("random_seed", 42)
    base_fraction = overrides.get("base_fraction", 0.85)
    amplitude_fraction = overrides.get("amplitude_fraction", 0.15)

    load_profile = LoadProfile(
        kind=kind,
        base_demand_mw=electrical_capacity_mw * base_fraction,
        amplitude_mw=electrical_capacity_mw * amplitude_fraction,
        period_s=overrides.get("period_s", 900.0),
        ramp_start_s=overrides.get("ramp_start_s", 300.0),
        ramp_duration_s=overrides.get("ramp_duration_s", 1800.0),
        ramp_delta_mw=electrical_capacity_mw * overrides.get("ramp_delta_fraction", 0.3),
        seed=seed,
    )

    return ScenarioConfig(
        name=name,
        description=description,
        duration_s=duration_s,
        timestep_s=timestep_s,
        initial_power_fraction=base_fraction,
        load_profile=load_profile,
        fault_schedule=FaultSchedule(),
        random_seed=seed,
    )


def build_grid_load_following(plant_cfg, electrical_capacity_mw, **overrides):
    return _build("sinusoidal", "grid_load_following", "Sinusoidal grid demand tracking.", plant_cfg, electrical_capacity_mw, **overrides)


def build_grid_fluctuation(plant_cfg, electrical_capacity_mw, **overrides):
    return _build("grid_fluctuation", "grid_fluctuation", "Deterministic multi-frequency grid demand fluctuation.", plant_cfg, electrical_capacity_mw, **overrides)


def build_morning_ramp(plant_cfg, electrical_capacity_mw, **overrides):
    overrides.setdefault("base_fraction", 0.55)
    overrides.setdefault("ramp_delta_fraction", 0.35)
    return _build("morning_ramp", "morning_load_ramp", "Overnight-minimum to daytime-peak demand ramp.", plant_cfg, electrical_capacity_mw, **overrides)


def build_evening_ramp(plant_cfg, electrical_capacity_mw, **overrides):
    overrides.setdefault("base_fraction", 0.90)
    overrides.setdefault("ramp_delta_fraction", 0.35)
    return _build("evening_ramp", "evening_load_ramp", "Evening-peak to overnight-minimum demand ramp.", plant_cfg, electrical_capacity_mw, **overrides)


def build_multi_unit_load_following(plant_cfg, electrical_capacity_mw, **overrides):
    return _build("sinusoidal", "multi_unit_load_following", "Shared site demand tracking across multiple units.", plant_cfg, electrical_capacity_mw, **overrides)


register_scenario("grid_load_following", build_grid_load_following)
register_scenario("grid_fluctuation", build_grid_fluctuation)
register_scenario("morning_load_ramp", build_morning_ramp)
register_scenario("evening_load_ramp", build_evening_ramp)
register_scenario("multi_unit_load_following", build_multi_unit_load_following)
