"""Nominal steady-state operation scenario."""

from __future__ import annotations

from config import PlantConfig
from electrical.load_model import LoadProfile
from simulation.scenario import ScenarioConfig, register_scenario
from simulation.scheduler import FaultSchedule


def build(plant_cfg: PlantConfig, electrical_capacity_mw: float, **overrides) -> ScenarioConfig:
    demand_fraction = overrides.get("demand_fraction", 0.92)
    duration_s = overrides.get("duration_s", 3600.0)
    timestep_s = overrides.get("timestep_s", 0.1)
    seed = overrides.get("random_seed", 42)

    return ScenarioConfig(
        name="nominal_operation",
        description="Steady baseload operation at constant demand, no faults.",
        duration_s=duration_s,
        timestep_s=timestep_s,
        initial_power_fraction=demand_fraction,
        load_profile=LoadProfile(kind="constant", base_demand_mw=electrical_capacity_mw * demand_fraction),
        fault_schedule=FaultSchedule(),
        random_seed=seed,
    )


register_scenario("nominal", build)
register_scenario("nominal_operation", build)
