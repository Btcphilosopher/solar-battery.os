"""Plant startup scenario: near-zero initial power ramping to full load."""

from __future__ import annotations

from config import PlantConfig
from electrical.load_model import LoadProfile
from simulation.scenario import ScenarioConfig, register_scenario
from simulation.scheduler import FaultSchedule


def build(plant_cfg: PlantConfig, electrical_capacity_mw: float, **overrides) -> ScenarioConfig:
    duration_s = overrides.get("duration_s", 5400.0)
    timestep_s = overrides.get("timestep_s", 0.1)
    seed = overrides.get("random_seed", 42)

    load_profile = LoadProfile(
        kind="morning_ramp",
        base_demand_mw=electrical_capacity_mw * 0.02,
        ramp_start_s=overrides.get("ramp_start_s", 600.0),
        ramp_duration_s=overrides.get("ramp_duration_s", 3600.0),
        ramp_delta_mw=electrical_capacity_mw * 0.90,
    )

    return ScenarioConfig(
        name="startup",
        description="Reactor and turbine startup from a near-zero-power condition to full load.",
        duration_s=duration_s,
        timestep_s=timestep_s,
        initial_power_fraction=1.0e-6,
        load_profile=load_profile,
        fault_schedule=FaultSchedule(),
        random_seed=seed,
    )


register_scenario("startup", build)
