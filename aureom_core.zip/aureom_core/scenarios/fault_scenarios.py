"""
Fault-injection scenarios.
=============================

Baseload operation with a single scheduled fault of the given kind,
built on the generic fault-injection framework in
simulation/scheduler.py + safety/fault_detection.py.

``protective_shutdown`` and ``post_shutdown_decay_heat`` both use a
severe, sustained coolant-flow-reduction fault, which is expected to
depress indicated flow below the low-flow reactor-protection setpoint
and produce a genuine reactor trip; ``post_shutdown_decay_heat`` simply
runs long enough afterward to show the post-trip decay-heat decay curve.
"""

from __future__ import annotations

from config import PlantConfig
from electrical.load_model import LoadProfile
from simulation.scenario import ScenarioConfig, register_scenario
from simulation.scheduler import Fault, FaultSchedule


def _baseload(plant_cfg: PlantConfig, electrical_capacity_mw: float, overrides: dict, base_fraction: float = 0.9) -> LoadProfile:
    return LoadProfile(kind="constant", base_demand_mw=electrical_capacity_mw * overrides.get("base_fraction", base_fraction))


def build_turbine_degradation(plant_cfg, electrical_capacity_mw, **overrides):
    fault_schedule = FaultSchedule()
    fault_schedule.add(
        Fault(
            component="turbine",
            mode="turbine_efficiency_loss",
            severity=overrides.get("severity", 0.25),
            start_time_s=overrides.get("start_time_s", 600.0),
            duration_s=overrides.get("fault_duration_s", 1800.0),
        )
    )
    return ScenarioConfig(
        name="turbine_degradation",
        description="Gradual turbine internal-efficiency loss during baseload operation.",
        duration_s=overrides.get("duration_s", 3000.0),
        timestep_s=overrides.get("timestep_s", 0.1),
        initial_power_fraction=overrides.get("base_fraction", 0.9),
        load_profile=_baseload(plant_cfg, electrical_capacity_mw, overrides),
        fault_schedule=fault_schedule,
        random_seed=overrides.get("random_seed", 42),
    )


def build_coolant_flow_degradation(plant_cfg, electrical_capacity_mw, **overrides):
    fault_schedule = FaultSchedule()
    fault_schedule.add(
        Fault(
            component="primary_pump",
            mode="pump_degradation",
            severity=overrides.get("severity", 0.35),
            start_time_s=overrides.get("start_time_s", 600.0),
            duration_s=overrides.get("fault_duration_s", 1200.0),
        )
    )
    return ScenarioConfig(
        name="coolant_flow_degradation",
        description="Reactor coolant pump degradation reducing primary flow during baseload operation.",
        duration_s=overrides.get("duration_s", 3000.0),
        timestep_s=overrides.get("timestep_s", 0.1),
        initial_power_fraction=overrides.get("base_fraction", 0.9),
        load_profile=_baseload(plant_cfg, electrical_capacity_mw, overrides),
        fault_schedule=fault_schedule,
        random_seed=overrides.get("random_seed", 42),
    )


def build_sensor_fault(plant_cfg, electrical_capacity_mw, **overrides):
    fault_schedule = FaultSchedule()
    fault_schedule.add(
        Fault(
            component="coolant_temperature_sensor",
            mode="sensor_bias",
            severity=overrides.get("severity", 1.0),
            start_time_s=overrides.get("start_time_s", 600.0),
            duration_s=overrides.get("fault_duration_s", 900.0),
            parameters={"target": "coolant_temperature", "bias_c": overrides.get("bias_c", 12.0)},
        )
    )
    return ScenarioConfig(
        name="sensor_fault",
        description="Biased coolant-temperature instrumentation during baseload operation.",
        duration_s=overrides.get("duration_s", 2400.0),
        timestep_s=overrides.get("timestep_s", 0.1),
        initial_power_fraction=overrides.get("base_fraction", 0.9),
        load_profile=_baseload(plant_cfg, electrical_capacity_mw, overrides),
        fault_schedule=fault_schedule,
        random_seed=overrides.get("random_seed", 42),
    )


def build_control_actuator_fault(plant_cfg, electrical_capacity_mw, **overrides):
    fault_schedule = FaultSchedule()
    fault_schedule.add(
        Fault(
            component="control_rod_actuator",
            mode="actuator_failure",
            severity=overrides.get("severity", 0.6),
            start_time_s=overrides.get("start_time_s", 600.0),
            duration_s=overrides.get("fault_duration_s", 1200.0),
        )
    )
    return ScenarioConfig(
        name="control_actuator_fault",
        description="Degraded control-rod actuator response during a load change.",
        duration_s=overrides.get("duration_s", 2700.0),
        timestep_s=overrides.get("timestep_s", 0.1),
        initial_power_fraction=overrides.get("base_fraction", 0.85),
        load_profile=LoadProfile(
            kind="sinusoidal",
            base_demand_mw=electrical_capacity_mw * overrides.get("base_fraction", 0.85),
            amplitude_mw=electrical_capacity_mw * 0.1,
            period_s=800.0,
        ),
        fault_schedule=fault_schedule,
        random_seed=overrides.get("random_seed", 42),
    )


def _severe_flow_loss_schedule(overrides: dict) -> FaultSchedule:
    fault_schedule = FaultSchedule()
    fault_schedule.add(
        Fault(
            component="primary_pump",
            mode="coolant_flow_reduction",
            severity=overrides.get("severity", 0.85),
            start_time_s=overrides.get("start_time_s", 300.0),
            duration_s=overrides.get("fault_duration_s", 600.0),
        )
    )
    return fault_schedule


def build_protective_shutdown(plant_cfg, electrical_capacity_mw, **overrides):
    return ScenarioConfig(
        name="protective_shutdown",
        description="Severe coolant-flow-reduction fault driving a reactor protection trip.",
        duration_s=overrides.get("duration_s", 1800.0),
        timestep_s=overrides.get("timestep_s", 0.1),
        initial_power_fraction=overrides.get("base_fraction", 0.9),
        load_profile=_baseload(plant_cfg, electrical_capacity_mw, overrides),
        fault_schedule=_severe_flow_loss_schedule(overrides),
        random_seed=overrides.get("random_seed", 42),
    )


def build_post_shutdown_decay_heat(plant_cfg, electrical_capacity_mw, **overrides):
    overrides.setdefault("duration_s", 7200.0)
    overrides.setdefault("fault_duration_s", 60.0)
    return ScenarioConfig(
        name="post_shutdown_decay_heat",
        description="Reactor trip followed by an extended observation of residual decay-heat behaviour.",
        duration_s=overrides.get("duration_s", 7200.0),
        timestep_s=overrides.get("timestep_s", 0.1),
        initial_power_fraction=overrides.get("base_fraction", 0.9),
        load_profile=_baseload(plant_cfg, electrical_capacity_mw, overrides),
        fault_schedule=_severe_flow_loss_schedule(overrides),
        random_seed=overrides.get("random_seed", 42),
    )


register_scenario("turbine_degradation", build_turbine_degradation)
register_scenario("coolant_flow_degradation", build_coolant_flow_degradation)
register_scenario("sensor_fault", build_sensor_fault)
register_scenario("control_actuator_fault", build_control_actuator_fault)
register_scenario("protective_shutdown", build_protective_shutdown)
register_scenario("post_shutdown_decay_heat", build_post_shutdown_decay_heat)
