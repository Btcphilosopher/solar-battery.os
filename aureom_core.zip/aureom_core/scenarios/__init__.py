"""
Built-in scenario library.
=============================

Importing this package registers every built-in scenario builder with
the :mod:`simulation.scenario` registry as a side effect, so that
``NuclearPowerStation.run(scenario="...")`` can resolve any of them by
name without the caller needing to import each scenario module
individually.
"""

from scenarios import (  # noqa: F401
    fault_scenarios,
    grid_disturbance,
    load_following,
    nominal,
    shutdown,
    startup,
)

from simulation.scenario import available_scenarios

__all__ = ["available_scenarios"]
