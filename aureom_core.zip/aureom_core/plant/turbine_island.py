"""
Turbine (secondary) island.
==============================

Composes the main steam system, turbine, turbine-generator, condenser,
feedwater system, and turbine controller into a single stepped unit —
the "Secondary Island" branch of the plant architecture.

As in the nuclear island, the turbine/generator rotor-torque coupling
uses a one-timestep lag (the generator's counter-torque this tick is
computed from *last* tick's rotor speed and fed back into *next* tick's
turbine rotor equation) — a standard staggered-solve simplification for
a discrete-time simulator.
"""

from __future__ import annotations

from dataclasses import dataclass

from config import PlantConfig
from control.turbine_controller import TurbineController
from secondary.condenser import Condenser
from secondary.feedwater import FeedwaterSystem, FeedwaterResult
from secondary.generator import GeneratorResult, TurbineGenerator
from secondary.steam_system import MainSteamSystem
from secondary.turbine import Turbine, TurbineResult
from safety.fault_detection import FaultDetector, FaultEffects
from simulation.scheduler import Fault


@dataclass
class TurbineIslandResult:
    steam_header_pressure_mpa: float
    steam_flow_to_turbine_kg_s: float
    valve_position_pct: float
    turbine: TurbineResult
    generator: GeneratorResult
    frequency_hz: float
    condenser_backpressure_kpa: float
    feedwater: FeedwaterResult
    fault_effects: FaultEffects


@dataclass
class TurbineIsland:
    cfg: PlantConfig

    def __post_init__(self) -> None:
        self.steam_system = MainSteamSystem(self.cfg.steam_generator)
        self.turbine = Turbine(self.cfg.turbine)
        self.generator = TurbineGenerator(self.cfg.generator)
        self.condenser = Condenser(self.cfg.condenser)
        self.feedwater = FeedwaterSystem(self.cfg.feedwater)
        self.controller = TurbineController(self.cfg.control)
        self.fault_detector = FaultDetector()

        self._last_counter_torque_nm = 0.0
        self._last_electrical_power_mw = 0.0

    def step(self, dt: float, load_setpoint_mw: float, steam_generation_kg_s: float, active_faults: list[Fault]) -> TurbineIslandResult:
        fault_effects = self.fault_detector.apply(active_faults)

        valve_pct = self.controller.step(load_setpoint_mw, self._last_electrical_power_mw, dt)
        valve_pct *= max(fault_effects.valve_health_multiplier, 0.0)

        steam_result = self.steam_system.step(steam_generation_kg_s, valve_pct / 100.0, dt)

        turbine_result = self.turbine.step(
            steam_result.steam_flow_to_turbine_kg_s, self._last_counter_torque_nm, dt
        )
        turbine_result = TurbineResult(
            mechanical_power_mw=turbine_result.mechanical_power_mw * max(fault_effects.turbine_efficiency_multiplier, 0.0),
            mechanical_torque_nm=turbine_result.mechanical_torque_nm,
            rotor_speed_rad_s=turbine_result.rotor_speed_rad_s,
        )

        generator_result = self.generator.step(turbine_result.mechanical_power_mw, turbine_result.rotor_speed_rad_s)
        self._last_counter_torque_nm = generator_result.counter_torque_nm
        self._last_electrical_power_mw = generator_result.electrical_power_mw

        condenser_backpressure = self.condenser.step(steam_result.steam_flow_to_turbine_kg_s, dt)

        load_fraction = generator_result.electrical_power_mw / max(self.cfg.generator.rated_electrical_power_mw, 1.0e-6)
        feedwater_result = self.feedwater.step(steam_result.steam_flow_to_turbine_kg_s, load_fraction, dt)

        frequency_hz = self.cfg.grid.nominal_frequency_hz * (
            turbine_result.rotor_speed_rad_s / self.cfg.turbine.synchronous_speed_rad_s
        )

        return TurbineIslandResult(
            steam_header_pressure_mpa=steam_result.header_pressure_mpa,
            steam_flow_to_turbine_kg_s=steam_result.steam_flow_to_turbine_kg_s,
            valve_position_pct=valve_pct,
            turbine=turbine_result,
            generator=generator_result,
            frequency_hz=frequency_hz,
            condenser_backpressure_kpa=condenser_backpressure,
            feedwater=feedwater_result,
            fault_effects=fault_effects,
        )
