"""
Balance of plant.
====================

Station electrical bookkeeping: wraps the grid-interconnection model to
turn the turbine-generator's gross electrical output and the current
grid demand into auxiliary consumption, net output, export power, and
grid frequency/voltage proxies (design brief §10-11):

    net_output = gross_generator_output - auxiliary_consumption
"""

from __future__ import annotations

from dataclasses import dataclass

from config import PlantConfig
from electrical.electrical_state import ElectricalState
from electrical.grid_model import GridModel


@dataclass
class BalanceOfPlant:
    cfg: PlantConfig

    def __post_init__(self) -> None:
        self.grid_model = GridModel(self.cfg.grid, self.cfg.generator)

    def step(self, gross_electrical_power_mw: float, grid_demand_mw: float, dt: float) -> ElectricalState:
        return self.grid_model.step(gross_electrical_power_mw, grid_demand_mw, dt)
