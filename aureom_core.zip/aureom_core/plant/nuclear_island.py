"""
Nuclear island.
=================

Composes the reactor core, primary coolant loop (RCPs, pressurizer,
vessel), steam-generator bank, reactor controller, reactor protection
system, emergency cooling, and containment proxy into a single stepped
unit — the "Nuclear Island" branch of the plant architecture (design
brief overview diagram).

Coupling notes
--------------
The primary loop and the steam generators are mutually dependent each
timestep (the loop's cold leg depends on the SG's primary-side outlet,
and the SG's primary inlet depends on the loop's hot leg). Rather than
solve that algebraic loop implicitly, this module uses a one-timestep
lag on the SG->loop coupling (a standard staggered-solve simplification
for discrete-time plant simulators), which is stable and, at the
configured timestep, introduces negligible additional lag compared with
the subsystems' own multi-second time constants. The same pattern is
used for the emergency-cooling decision, which acts on the previous
timestep's thermal margins.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from config import PlantConfig
from core.core_state import CoreState
from core.reactor_core import ReactorCore
from control.control_rods import solve_position_for_worth
from control.reactor_controller import ReactorController
from primary.coolant_loop import CoolantLoop
from primary.primary_state import PrimaryState
from primary.steam_generators import SteamGeneratorBank, SteamGeneratorResult
from protection.protection_state import ProtectionState
from protection.trip_logic import TripMeasurements
from protection.reactor_protection import ReactorProtectionSystem
from safety.containment_model import ContainmentModel
from safety.emergency_cooling import EmergencyCoolingResult, EmergencyCoolingSystem
from safety.fault_detection import FaultDetector, FaultEffects
from safety.thermal_limits import coolant_thermal_margin_c, fuel_thermal_margin_c
from simulation.scheduler import Fault


@dataclass
class NuclearIslandResult:
    core_state: CoreState
    primary_state: PrimaryState
    steam_generator: SteamGeneratorResult
    protection_state: ProtectionState
    emergency_cooling: EmergencyCoolingResult
    containment_pressure_kpa: float
    fuel_thermal_margin_c: float
    coolant_thermal_margin_c: float
    fault_effects: FaultEffects


@dataclass
class NuclearIsland:
    cfg: PlantConfig

    def __post_init__(self) -> None:
        self.reactor_core = ReactorCore(self.cfg.reactor)
        self.coolant_loop = CoolantLoop(self.cfg.coolant, self.cfg.pressurizer)
        self.steam_generators = SteamGeneratorBank(self.cfg.steam_generator)
        self.controller = ReactorController(self.cfg.control, self.cfg.reactor.reactivity)
        self.protection = ReactorProtectionSystem(self.cfg.protection)
        self.emergency_cooling = EmergencyCoolingSystem(self.cfg.safety)
        self.containment = ContainmentModel(self.cfg.safety)
        self.fault_detector = FaultDetector()

        self._last_sg_primary_outlet_c = self.cfg.coolant.cold_leg_setpoint_c
        self._last_fuel_margin_c = self.cfg.safety.fuel_temperature_margin_alert_c
        self._last_coolant_margin_c = self.cfg.safety.coolant_temperature_margin_alert_c

    def initialize_at_power(self, power_fraction: float) -> None:
        """Derive a self-consistent steady-power initial condition: core
        thermal state from the steady-state energy balance, fission-product
        poisons at their power-dependent equilibrium, and a control-rod
        position solved from the reactivity balance so that total
        reactivity starts near zero (critical) rather than defaulting to
        an arbitrary rod position that could start the point-kinetics
        solver far from criticality."""

        n0 = max(power_fraction, 1.0e-9)
        reactor_cfg = self.cfg.reactor
        thermal_power_mw = n0 * reactor_cfg.nominal_thermal_power_mw

        coolant_inlet_c = self.cfg.coolant.cold_leg_setpoint_c
        flow_capacity_mw_per_c = (
            self.cfg.coolant.nominal_mass_flow_kg_s * self.cfg.coolant.specific_heat_kj_per_kg_c / 1000.0
        )
        coolant_avg_c = coolant_inlet_c + thermal_power_mw / max(2.0 * flow_capacity_mw_per_c, 1.0e-6)
        fuel_c = coolant_avg_c + thermal_power_mw / max(reactor_cfg.fuel.fuel_to_coolant_ua_mw_per_c, 1.0e-6)

        fuel_cfg = reactor_cfg.fuel
        iodine_eq = fuel_cfg.iodine_yield_fraction * n0 / max(fuel_cfg.iodine_decay_constant_per_s, 1.0e-12)
        xenon_eq = (fuel_cfg.xenon_yield_fraction * n0 + fuel_cfg.iodine_decay_constant_per_s * iodine_eq) / max(
            fuel_cfg.xenon_decay_constant_per_s + fuel_cfg.xenon_microscopic_burn_rate * n0, 1.0e-12
        )

        self.reactor_core.initialize_at_power(n0, coolant_avg_c)
        s = self.reactor_core.state
        s.fuel_temperature_c = fuel_c
        s.coolant_temperature_avg_c = coolant_avg_c
        s.coolant_outlet_temperature_c = 2.0 * coolant_avg_c - coolant_inlet_c
        s.fuel.iodine_concentration = iodine_eq
        s.fuel.xenon_concentration = xenon_eq

        reactivity_cfg = reactor_cfg.reactivity
        thermal_fb = reactivity_cfg.coolant_temperature_coefficient_per_c * (
            coolant_avg_c - reactivity_cfg.reference_coolant_temperature_c
        )
        fuel_fb = reactivity_cfg.fuel_temperature_coefficient_per_c * (fuel_c - reactivity_cfg.reference_fuel_temperature_c)
        poison_fb = reactivity_cfg.xenon_worth_per_unit_concentration * xenon_eq
        required_control = -(thermal_fb + fuel_fb + poison_fb)
        required_control = max(0.0, min(required_control, reactivity_cfg.max_control_reactivity))

        rod_position_pct = solve_position_for_worth(required_control, self.cfg.control.rod_reactivity_worth_full_stroke)
        self.controller.rod_actuator.position_pct = rod_position_pct
        self.controller.rod_actuator.requested_position_pct = rod_position_pct
        self.controller.pid.reset(0.0)

        # Seed the coolant loop / pressurizer / vessel and steam generators
        # near the same steady state so the first several timesteps do not
        # have to work through a large, physically-arbitrary transient.
        self.coolant_loop.hot_leg_temperature_c = s.coolant_outlet_temperature_c
        self.coolant_loop.vessel.core_inlet_temperature_c = coolant_inlet_c
        self.coolant_loop.pressurizer.pressure_mpa = self.cfg.pressurizer.setpoint_mpa
        self._last_sg_primary_outlet_c = coolant_inlet_c

        for unit in self.steam_generators.units:
            unit.secondary_temperature_c = min(
                self._sg_saturation_hint(fuel_c, coolant_avg_c), unit.secondary_temperature_c + 40.0
            )

    @staticmethod
    def _sg_saturation_hint(fuel_c: float, coolant_avg_c: float) -> float:
        # A simple, bounded hint for the initial secondary-side shell
        # temperature: somewhat below the primary hot-leg temperature,
        # never a physically absurd value regardless of power fraction.
        return max(min(coolant_avg_c - 10.0, 320.0), 100.0)

    def step(
        self,
        dt: float,
        power_setpoint_fraction: float,
        active_faults: list[Fault],
        steam_header_pressure_mpa: float,
        condenser_backpressure_kpa: float,
        frequency_deviation_hz: float,
    ) -> NuclearIslandResult:
        fault_effects = self.fault_detector.apply(active_faults)

        measurements = TripMeasurements(
            power_pct=self.reactor_core.state.normalized_power * 100.0,
            fuel_temperature_c=self.reactor_core.state.fuel_temperature_c + fault_effects.sensor_bias_fuel_temp_c,
            coolant_temperature_c=self.reactor_core.state.coolant_temperature_avg_c + fault_effects.sensor_bias_coolant_temp_c,
            flow_pct=self.coolant_loop.state.mass_flow_fraction * 100.0,
            pressurizer_pressure_mpa=self.coolant_loop.state.pressure_mpa,
            condenser_backpressure_kpa=condenser_backpressure_kpa,
            frequency_deviation_hz=frequency_deviation_hz,
        )
        protection_state = self.protection.evaluate(measurements)
        if protection_state.scram_commanded:
            self.controller.scram()

        control_reactivity, _, _ = self.controller.step(
            power_setpoint_fraction, self.reactor_core.state.normalized_power, dt
        )

        pump_health = max(fault_effects.pump_health_multiplier, 0.0)
        for i in range(len(self.coolant_loop.pump_bank.pumps)):
            self.coolant_loop.pump_bank.set_pump_health(i, pump_health)

        primary_state = self.coolant_loop.step(
            core_outlet_temperature_c=self.reactor_core.state.coolant_outlet_temperature_c,
            sg_outlet_temperature_c=self._last_sg_primary_outlet_c,
            dt=dt,
        )
        effective_flow_kg_s = primary_state.mass_flow_kg_s * max(fault_effects.coolant_flow_multiplier, 0.0)

        emergency_cooling_result = self.emergency_cooling.step(
            coolant_flow_pct=primary_state.mass_flow_fraction * 100.0 * max(fault_effects.coolant_flow_multiplier, 0.0),
            fuel_thermal_margin_c=self._last_fuel_margin_c,
            coolant_thermal_margin_c=self._last_coolant_margin_c,
            dt=dt,
        )

        core_state = self.reactor_core.step(
            dt=dt,
            control_reactivity=control_reactivity,
            coolant_inlet_temperature_c=primary_state.cold_leg_temperature_c,
            coolant_mass_flow_kg_s=effective_flow_kg_s,
            coolant_specific_heat_kj_per_kg_c=self.cfg.coolant.specific_heat_kj_per_kg_c,
            extra_heat_removal_mw=emergency_cooling_result.heat_removal_mw,
        )
        if protection_state.scram_commanded:
            self.reactor_core.trip()

        sg_result = self.steam_generators.step(
            primary_inlet_temperature_c=self.coolant_loop.hot_leg_temperature_c,
            primary_mass_flow_kg_s=effective_flow_kg_s,
            primary_specific_heat_kj_per_kg_c=self.cfg.coolant.specific_heat_kj_per_kg_c,
            header_pressure_mpa=steam_header_pressure_mpa,
            dt=dt,
        )
        self._last_sg_primary_outlet_c = sg_result.primary_outlet_temperature_c

        fuel_margin = fuel_thermal_margin_c(self.cfg.safety, core_state.fuel_temperature_c)
        coolant_margin = coolant_thermal_margin_c(self.cfg.safety, core_state.coolant_temperature_avg_c)
        self._last_fuel_margin_c = fuel_margin
        self._last_coolant_margin_c = coolant_margin

        containment_pressure = self.containment.step(
            emergency_cooling_result.activated, core_state.decay_power_mw, dt
        )

        return NuclearIslandResult(
            core_state=core_state,
            primary_state=primary_state,
            steam_generator=sg_result,
            protection_state=protection_state,
            emergency_cooling=emergency_cooling_result,
            containment_pressure_kpa=containment_pressure,
            fuel_thermal_margin_c=fuel_margin,
            coolant_thermal_margin_c=coolant_margin,
            fault_effects=fault_effects,
        )
