"""
Power station — top-level plant API.
=======================================

:class:`PowerStationUnit` wires one nuclear island, one turbine island,
and the station electrical interconnection into a fully stepped large
-reactor unit, closing the causal chain required by the design brief
(§39):

    reactivity -> fission proxy -> thermal power -> fuel/coolant mass
        -> primary coolant -> steam generator -> steam -> turbine
        -> generator -> grid -> demand feedback -> control -> reactor

:class:`NuclearPowerStation` is the public top-level entry point
(design brief §29, §44): it owns 1-4 independent
:class:`PowerStationUnit` objects sharing a common site demand signal,
and its ``.run(...)`` delegates to :class:`simulation.engine.SimulationEngine`
for the actual deterministic timestepping loop.

:class:`ReactorSimulation` is a single-unit convenience alias matching
the alternate example API in the design brief §29.
"""

from __future__ import annotations

from typing import Optional

from config import PlantConfig, default_large_reactor_config
from control.load_following import LoadFollowingCoordinator
from electrical.electrical_state import ElectricalState
from plant.balance_of_plant import BalanceOfPlant
from plant.nuclear_island import NuclearIsland
from plant.turbine_island import TurbineIsland
from protection.protection_state import ProtectionStatus
from core.core_state import ReactorStatus
from safety.fault_detection import FaultDetector
from safety.safety_state import SafetyStatus
from simulation.events import EventLog, EventType
from simulation.simulation_state import PlantState


class PowerStationUnit:
    """A single large-reactor generating unit: nuclear island + turbine
    island + station electrical interconnection."""

    def __init__(self, cfg: PlantConfig, unit_id: int = 0):
        self.cfg = cfg
        self.unit_id = unit_id

        self.nuclear_island = NuclearIsland(cfg)
        self.turbine_island = TurbineIsland(cfg)
        self.balance_of_plant = BalanceOfPlant(cfg)
        self.load_following = LoadFollowingCoordinator(cfg.control, cfg.generator.rated_electrical_power_mw)
        self.grid_fault_detector = FaultDetector()

        self._last_condenser_backpressure_kpa = cfg.condenser.design_backpressure_kpa
        self._last_frequency_deviation_hz = 0.0
        self._last_steam_header_pressure_mpa = cfg.steam_generator.nominal_steam_pressure_mpa

        self.electrical_state = ElectricalState()
        self._trip_logged = False
        self._emergency_cooling_logged = False

    def initialize_at_power(self, power_fraction: float) -> None:
        self.nuclear_island.initialize_at_power(power_fraction)
        target_mw = power_fraction * self.cfg.generator.rated_electrical_power_mw
        self.load_following.target_plant_output_mw = target_mw
        self.turbine_island.controller.pid.reset(power_fraction * 100.0)
        self.turbine_island._last_electrical_power_mw = target_mw

    def step(self, dt: float, t: float, grid_demand_mw: float, active_faults: list, event_log: EventLog) -> PlantState:
        grid_fault_effects = self.grid_fault_detector.apply(active_faults)
        grid_demand_mw = max(grid_demand_mw + grid_fault_effects.grid_disturbance_mw, 0.0)

        reactor_setpoint_fraction, turbine_load_setpoint_mw = self.load_following.step(grid_demand_mw, dt)

        nuclear_result = self.nuclear_island.step(
            dt=dt,
            power_setpoint_fraction=reactor_setpoint_fraction,
            active_faults=active_faults,
            steam_header_pressure_mpa=self._last_steam_header_pressure_mpa,
            condenser_backpressure_kpa=self._last_condenser_backpressure_kpa,
            frequency_deviation_hz=self._last_frequency_deviation_hz,
        )

        if nuclear_result.protection_state.turbine_trip_commanded:
            turbine_load_setpoint_mw = 0.0

        turbine_result = self.turbine_island.step(
            dt=dt,
            load_setpoint_mw=turbine_load_setpoint_mw,
            steam_generation_kg_s=nuclear_result.steam_generator.steam_generation_kg_s,
            active_faults=active_faults,
        )
        self._last_steam_header_pressure_mpa = turbine_result.steam_header_pressure_mpa
        self._last_condenser_backpressure_kpa = turbine_result.condenser_backpressure_kpa

        electrical_state = self.balance_of_plant.step(
            gross_electrical_power_mw=turbine_result.generator.electrical_power_mw,
            grid_demand_mw=grid_demand_mw,
            dt=dt,
        )
        self._last_frequency_deviation_hz = electrical_state.grid_frequency_hz - self.cfg.grid.nominal_frequency_hz
        self.electrical_state = electrical_state

        self._log_events(t, nuclear_result, event_log)

        safety_status = self._derive_safety_status(nuclear_result, turbine_result)

        alarms = tuple(nuclear_result.fault_effects.alarms) + tuple(turbine_result.fault_effects.alarms)

        return PlantState(
            simulation_time_s=t,
            unit_id=self.unit_id,
            reactor_normalized_power=nuclear_result.core_state.normalized_power,
            reactor_thermal_power_mw=nuclear_result.core_state.thermal_power_mw,
            reactor_fission_power_mw=nuclear_result.core_state.fission_power_mw,
            reactor_decay_power_mw=nuclear_result.core_state.decay_power_mw,
            fuel_temperature_c=nuclear_result.core_state.fuel_temperature_c,
            coolant_temperature_c=nuclear_result.core_state.coolant_temperature_avg_c,
            total_reactivity=nuclear_result.core_state.reactivity.total,
            coolant_flow_kg_s=nuclear_result.primary_state.mass_flow_kg_s,
            coolant_flow_pct=nuclear_result.primary_state.mass_flow_fraction * 100.0,
            pressurizer_pressure_mpa=nuclear_result.primary_state.pressure_mpa,
            steam_pressure_mpa=turbine_result.steam_header_pressure_mpa,
            steam_flow_kg_s=turbine_result.steam_flow_to_turbine_kg_s,
            turbine_speed_rad_s=turbine_result.turbine.rotor_speed_rad_s,
            turbine_power_mw=turbine_result.turbine.mechanical_power_mw,
            condenser_backpressure_kpa=turbine_result.condenser_backpressure_kpa,
            gross_electrical_power_mw=electrical_state.gross_electrical_power_mw,
            auxiliary_power_mw=electrical_state.auxiliary_power_mw,
            net_electrical_power_mw=electrical_state.net_electrical_power_mw,
            export_power_mw=electrical_state.export_power_mw,
            grid_demand_mw=grid_demand_mw,
            grid_frequency_hz=electrical_state.grid_frequency_hz,
            control_rod_position_pct=self.nuclear_island.controller.rod_actuator.position_pct,
            valve_position_pct=turbine_result.valve_position_pct,
            reactor_status=nuclear_result.core_state.status.value,
            protection_status=nuclear_result.protection_state.status.value,
            safety_status=safety_status,
            active_trips=",".join(nuclear_result.protection_state.active_trips),
            active_alarms=",".join(alarms),
            fuel_thermal_margin_c=nuclear_result.fuel_thermal_margin_c,
            coolant_thermal_margin_c=nuclear_result.coolant_thermal_margin_c,
            emergency_cooling_active=nuclear_result.emergency_cooling.activated,
            containment_pressure_kpa=nuclear_result.containment_pressure_kpa,
        )

    def _log_events(self, t: float, nuclear_result, event_log: EventLog) -> None:
        if nuclear_result.protection_state.scram_commanded and not self._trip_logged:
            reasons = ", ".join(nuclear_result.protection_state.active_trips) or "protection latched"
            event_log.record(t, EventType.REACTOR_TRIP, f"Unit {self.unit_id} reactor trip: {reasons}", self.unit_id)
            self._trip_logged = True
        if nuclear_result.emergency_cooling.activated and not self._emergency_cooling_logged:
            event_log.record(t, EventType.EMERGENCY_COOLING_ACTIVATED, f"Unit {self.unit_id} emergency cooling activated", self.unit_id)
            self._emergency_cooling_logged = True

    def _derive_safety_status(self, nuclear_result, turbine_result) -> str:
        if nuclear_result.protection_state.status == ProtectionStatus.TRIPPED:
            settled = (
                nuclear_result.core_state.status == ReactorStatus.TRIPPED
                and nuclear_result.core_state.normalized_power < 0.02
                and not nuclear_result.emergency_cooling.activated
                and nuclear_result.core_state.decay_power_mw < 5.0
            )
            return SafetyStatus.SHUTDOWN.value if settled else SafetyStatus.PROTECTIVE.value

        has_alarms = bool(nuclear_result.fault_effects.alarms) or bool(turbine_result.fault_effects.alarms)
        return SafetyStatus.DEGRADED.value if has_alarms else SafetyStatus.NORMAL.value


class NuclearPowerStation:
    """Top-level digital-twin API. Owns one or more independent
    :class:`PowerStationUnit` objects sharing a common site grid demand
    signal (design brief §23, §29, §44)."""

    def __init__(
        self,
        units: int = 1,
        reactor_power_mw: float = 3400.0,
        electrical_capacity_mw: float = 1300.0,
        plant_config: Optional[PlantConfig] = None,
    ):
        if units < 1 or units > 4:
            raise ValueError("NuclearPowerStation supports 1-4 units (design brief §23).")

        self.units_count = units
        self.reactor_power_mw = reactor_power_mw
        self.electrical_capacity_mw = electrical_capacity_mw
        self.plant_config = plant_config or default_large_reactor_config(reactor_power_mw, electrical_capacity_mw)

        self.units = [PowerStationUnit(self.plant_config, unit_id=i) for i in range(units)]

    @property
    def site_electrical_capacity_mw(self) -> float:
        return self.electrical_capacity_mw * self.units_count

    def initialize_at_power(self, power_fraction: float = 1.0) -> None:
        for unit in self.units:
            unit.initialize_at_power(power_fraction)

    def run(self, duration: float = None, scenario: str = "nominal", timestep: float = None, seed: int = None, **overrides):
        # Deferred import: simulation.engine imports plant.power_station,
        # so this call is resolved lazily to avoid a circular top-level import.
        from simulation.engine import SimulationEngine

        engine = SimulationEngine(self)
        return engine.run(scenario=scenario, duration=duration, timestep=timestep, seed=seed, **overrides)


class ReactorSimulation(NuclearPowerStation):
    """Single-unit convenience alias matching the alternate example API
    in the design brief (§29): ``ReactorSimulation(reactor_power_mw=...,
    electrical_capacity_mw=..., timestep=...)``."""

    def __init__(
        self,
        reactor_power_mw: float = 3400.0,
        electrical_capacity_mw: float = 1300.0,
        timestep: float = 0.1,
        plant_config: Optional[PlantConfig] = None,
    ):
        super().__init__(units=1, reactor_power_mw=reactor_power_mw, electrical_capacity_mw=electrical_capacity_mw, plant_config=plant_config)
        self.default_timestep = timestep

    def run(self, duration: float = 3600.0, scenario: str = "nominal", **overrides):
        overrides.setdefault("timestep", self.default_timestep)
        return super().run(duration=duration, scenario=scenario, **overrides)
