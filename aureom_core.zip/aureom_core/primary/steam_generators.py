"""
Steam generator (primary-to-secondary heat exchanger).
========================================================

Simplified dynamic effectiveness-NTU-style heat exchanger coupling the
primary reactor-coolant loop to the secondary steam system. The secondary
side is represented by a lumped thermal-mass ("shell") node so that steam
production lags a change in primary heat input rather than following it
instantaneously — this is the thermal-inertia requirement in the design
brief (§8).

    Q_transferred = effectiveness * C_min * (T_primary_in - T_secondary)
    dT_secondary/dt = (Q_transferred - Q_to_steam) / C_secondary
    steam_generation_kg_s = Q_to_steam * 1000 / latent_heat_kj_per_kg

A simplified linear saturation-temperature proxy,
``T_sat(P) = 100 + 26 * P_mpa`` (°C, with P in MPa), stands in for full
steam-table lookups; it is accurate to a few percent across the 0.1-8 MPa
range of interest here and is documented explicitly as an engineering
approximation, not a steam-table reference.
"""

from __future__ import annotations

from dataclasses import dataclass

from config import SteamGeneratorConfig


def saturation_temperature_c(pressure_mpa: float) -> float:
    """Simplified linear saturation-temperature proxy (see module docstring)."""
    return 100.0 + 26.0 * max(pressure_mpa, 0.0)


@dataclass
class SteamGeneratorResult:
    heat_transferred_mw: float
    primary_outlet_temperature_c: float
    steam_generation_kg_s: float
    secondary_temperature_c: float


@dataclass
class SteamGenerator:
    cfg: SteamGeneratorConfig
    secondary_temperature_c: float = 0.0

    def __post_init__(self) -> None:
        if self.secondary_temperature_c == 0.0:
            self.secondary_temperature_c = saturation_temperature_c(self.cfg.nominal_steam_pressure_mpa)

    def step(
        self,
        primary_inlet_temperature_c: float,
        primary_mass_flow_kg_s: float,
        primary_specific_heat_kj_per_kg_c: float,
        header_pressure_mpa: float,
        dt: float,
    ) -> SteamGeneratorResult:
        cfg = self.cfg

        # Effectiveness-NTU heat exchanger with a boiling (near-isothermal)
        # secondary side: the primary (single-phase) flow is always the
        # minimum-capacity-rate stream, so C_min = primary flow * Cp.
        c_primary_mw_per_c = primary_mass_flow_kg_s * primary_specific_heat_kj_per_kg_c / 1000.0
        q_transferred_mw = max(
            cfg.effectiveness * c_primary_mw_per_c * (primary_inlet_temperature_c - self.secondary_temperature_c),
            0.0,
        )

        sat_temp = saturation_temperature_c(header_pressure_mpa)
        # Heat leaving the shell as steam is proportional to how far the
        # shell node sits above the current saturation temperature at the
        # header pressure — this provides the negative feedback that lets
        # the header pressure regulate steam production.
        q_to_steam_mw = max(
            (self.secondary_temperature_c - sat_temp) * (cfg.secondary_thermal_mass_mj_per_c / max(cfg.pressure_time_constant_s, 1e-3)),
            0.0,
        )
        q_to_steam_mw = min(q_to_steam_mw, q_transferred_mw + 5000.0)  # bounded, non-singular

        d_t_secondary = (q_transferred_mw - q_to_steam_mw) / cfg.secondary_thermal_mass_mj_per_c
        self.secondary_temperature_c += d_t_secondary * dt
        self.secondary_temperature_c = max(self.secondary_temperature_c, 0.0)

        steam_generation_kg_s = q_to_steam_mw * 1000.0 / cfg.latent_heat_kj_per_kg

        flow_capacity_mw_per_c = primary_mass_flow_kg_s * primary_specific_heat_kj_per_kg_c / 1000.0
        if flow_capacity_mw_per_c > 1.0e-6:
            primary_outlet_c = primary_inlet_temperature_c - q_transferred_mw / flow_capacity_mw_per_c
        else:
            primary_outlet_c = primary_inlet_temperature_c

        return SteamGeneratorResult(
            heat_transferred_mw=q_transferred_mw,
            primary_outlet_temperature_c=primary_outlet_c,
            steam_generation_kg_s=max(steam_generation_kg_s, 0.0),
            secondary_temperature_c=self.secondary_temperature_c,
        )


@dataclass
class SteamGeneratorBank:
    """Aggregates ``cfg.count`` identical steam generators (large PWR-class
    plants typically use multiple SGs feeding a common main-steam header)."""

    cfg: SteamGeneratorConfig

    def __post_init__(self) -> None:
        unit_cfg = SteamGeneratorConfig(
            count=1,
            effectiveness=self.cfg.effectiveness,
            secondary_thermal_mass_mj_per_c=self.cfg.secondary_thermal_mass_mj_per_c / self.cfg.count,
            nominal_steam_pressure_mpa=self.cfg.nominal_steam_pressure_mpa,
            nominal_steam_flow_kg_s=self.cfg.nominal_steam_flow_kg_s / self.cfg.count,
            pressure_time_constant_s=self.cfg.pressure_time_constant_s,
            latent_heat_kj_per_kg=self.cfg.latent_heat_kj_per_kg,
            header_capacitance_kg_per_mpa=self.cfg.header_capacitance_kg_per_mpa,
        )
        self.units = [SteamGenerator(unit_cfg) for _ in range(self.cfg.count)]

    def step(
        self,
        primary_inlet_temperature_c: float,
        primary_mass_flow_kg_s: float,
        primary_specific_heat_kj_per_kg_c: float,
        header_pressure_mpa: float,
        dt: float,
    ) -> SteamGeneratorResult:
        flow_per_unit = primary_mass_flow_kg_s / max(len(self.units), 1)
        heat = 0.0
        steam = 0.0
        outlet_sum = 0.0
        secondary_sum = 0.0
        for unit in self.units:
            r = unit.step(
                primary_inlet_temperature_c,
                flow_per_unit,
                primary_specific_heat_kj_per_kg_c,
                header_pressure_mpa,
                dt,
            )
            heat += r.heat_transferred_mw
            steam += r.steam_generation_kg_s
            outlet_sum += r.primary_outlet_temperature_c
            secondary_sum += r.secondary_temperature_c

        n = max(len(self.units), 1)
        return SteamGeneratorResult(
            heat_transferred_mw=heat,
            primary_outlet_temperature_c=outlet_sum / n,
            steam_generation_kg_s=steam,
            secondary_temperature_c=secondary_sum / n,
        )
