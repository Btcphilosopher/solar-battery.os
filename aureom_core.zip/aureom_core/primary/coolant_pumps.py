"""
Reactor coolant pump bank.
===========================

Models N parallel reactor coolant pumps (RCPs) with first-order
spin-up/spin-down dynamics and a per-pump health/degradation factor that
the fault-injection framework (see safety/fault_detection.py and
simulation/scheduler.py) can drive to simulate mechanical degradation or
a pump trip.

    d(speed_fraction)/dt = (commanded_fraction * health - speed_fraction) / tau_spin

Total delivered flow is the sum of each pump's rated flow scaled by its
current speed fraction and health factor.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from config import CoolantConfig
from primary.primary_state import PumpStatus


@dataclass
class _PumpUnit:
    speed_fraction: float = 1.0
    health: float = 1.0
    commanded_fraction: float = 1.0
    running: bool = True


@dataclass
class CoolantPumpBank:
    cfg: CoolantConfig
    pumps: list = field(default_factory=list)

    def __post_init__(self) -> None:
        if not self.pumps:
            self.pumps = [_PumpUnit() for _ in range(self.cfg.pump_count)]

    def set_pump_health(self, index: int, health: float) -> None:
        if 0 <= index < len(self.pumps):
            self.pumps[index].health = max(0.0, min(health, 1.0))

    def trip_pump(self, index: int) -> None:
        if 0 <= index < len(self.pumps):
            self.pumps[index].running = False
            self.pumps[index].commanded_fraction = 0.0

    def start_pump(self, index: int) -> None:
        if 0 <= index < len(self.pumps):
            self.pumps[index].running = True
            self.pumps[index].commanded_fraction = 1.0

    def step(self, dt: float) -> tuple[float, tuple, tuple]:
        """Advance pump dynamics and return
        (total_mass_flow_kg_s, pump_statuses, pump_health)."""

        tau = max(self.cfg.pump_spin_down_time_s, 1.0e-3)
        total_flow = 0.0
        statuses = []
        healths = []

        for pump in self.pumps:
            target = pump.commanded_fraction * pump.health if pump.running else 0.0
            pump.speed_fraction += (target - pump.speed_fraction) * (dt / tau)
            pump.speed_fraction = max(0.0, min(pump.speed_fraction, 1.0))

            flow = pump.speed_fraction * self.cfg.pump_rated_flow_kg_s_each
            total_flow += flow

            if not pump.running:
                status = PumpStatus.STOPPED if pump.speed_fraction < 0.02 else PumpStatus.TRIPPED
            elif pump.health < 0.85:
                status = PumpStatus.DEGRADED
            else:
                status = PumpStatus.RUNNING

            statuses.append(status)
            healths.append(pump.health)

        return total_flow, tuple(statuses), tuple(healths)
