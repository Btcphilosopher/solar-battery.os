"""
Reactor pressure vessel — downcomer mixing volume.
=====================================================

Represents the thermal inertia of the coolant mass held in the vessel
downcomer/lower plenum between the cold-leg nozzles and the core inlet.
This adds a further first-order lag stage so that a step change in
cold-leg temperature (e.g. from a steam-generator or pump transient)
does not appear instantaneously at the core inlet:

    dT_core_inlet/dt = (T_cold_leg - T_core_inlet) / tau_downcomer
"""

from __future__ import annotations

from dataclasses import dataclass

from config import CoolantConfig


@dataclass
class ReactorVessel:
    cfg: CoolantConfig
    core_inlet_temperature_c: float = 0.0

    def __post_init__(self) -> None:
        if self.core_inlet_temperature_c == 0.0:
            self.core_inlet_temperature_c = self.cfg.cold_leg_setpoint_c

    def step(self, cold_leg_temperature_c: float, dt: float) -> float:
        tau = max(self.cfg.loop_transport_time_s * 0.5, 0.5)
        d_t = (cold_leg_temperature_c - self.core_inlet_temperature_c) / tau
        self.core_inlet_temperature_c += d_t * dt
        return self.core_inlet_temperature_c
