"""Observable state for the primary (reactor coolant) system."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class PumpStatus(str, Enum):
    RUNNING = "RUNNING"
    DEGRADED = "DEGRADED"
    TRIPPED = "TRIPPED"
    STOPPED = "STOPPED"


@dataclass
class PrimaryState:
    hot_leg_temperature_c: float = 292.0
    cold_leg_temperature_c: float = 292.0
    pressure_mpa: float = 15.5
    mass_flow_kg_s: float = 0.0
    mass_flow_fraction: float = 1.0
    pump_statuses: tuple = field(default_factory=tuple)
    pump_health: tuple = field(default_factory=tuple)
