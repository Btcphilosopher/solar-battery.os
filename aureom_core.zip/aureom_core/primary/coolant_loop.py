"""
Primary coolant loop.
=======================

Owns the reactor-coolant-pump bank, the pressurizer, and the hot-leg /
cold-leg piping transport lags that connect the reactor core to the
steam generators. This module does not compute core or steam-generator
heat transfer itself (see core/core_thermal_model.py and
primary/steam_generators.py); it provides the flow, pressure, and piping
dynamics that couple them, following

    Q = m_dot * Cp * delta_T

for the primary-side energy transport, with configurable perturbations
(pump degradation, sensor error) supported through the fault-injection
framework acting on the pump bank and sensor read-out layer.
"""

from __future__ import annotations

from dataclasses import dataclass

from config import CoolantConfig, PressurizerConfig
from primary.coolant_pumps import CoolantPumpBank
from primary.pressurizer import Pressurizer
from primary.primary_state import PrimaryState
from primary.reactor_vessel import ReactorVessel


@dataclass
class CoolantLoop:
    coolant_cfg: CoolantConfig
    pressurizer_cfg: PressurizerConfig

    def __post_init__(self) -> None:
        self.pump_bank = CoolantPumpBank(self.coolant_cfg)
        self.pressurizer = Pressurizer(self.pressurizer_cfg)
        self.vessel = ReactorVessel(self.coolant_cfg)
        self.hot_leg_temperature_c = self.coolant_cfg.cold_leg_setpoint_c + 30.0
        self.state = PrimaryState(
            hot_leg_temperature_c=self.hot_leg_temperature_c,
            cold_leg_temperature_c=self.vessel.core_inlet_temperature_c,
            pressure_mpa=self.pressurizer.pressure_mpa,
        )

    def step(self, core_outlet_temperature_c: float, sg_outlet_temperature_c: float, dt: float) -> PrimaryState:
        flow, statuses, health = self.pump_bank.step(dt)

        tau_hot_leg = max(self.coolant_cfg.loop_transport_time_s * 0.5, 0.5)
        d_hot = (core_outlet_temperature_c - self.hot_leg_temperature_c) / tau_hot_leg
        self.hot_leg_temperature_c += d_hot * dt

        core_inlet_c = self.vessel.step(sg_outlet_temperature_c, dt)

        temperature_deviation = core_inlet_c - self.coolant_cfg.cold_leg_setpoint_c
        pressure = self.pressurizer.step(temperature_deviation, dt)

        self.state = PrimaryState(
            hot_leg_temperature_c=self.hot_leg_temperature_c,
            cold_leg_temperature_c=core_inlet_c,
            pressure_mpa=pressure,
            mass_flow_kg_s=flow,
            mass_flow_fraction=flow / max(self.coolant_cfg.nominal_mass_flow_kg_s, 1.0e-6),
            pump_statuses=statuses,
            pump_health=health,
        )
        return self.state
