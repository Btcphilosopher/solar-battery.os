"""
Pressurizer.
=============

Simplified pressure-control volume that relaxes primary-system pressure
toward its setpoint, with the relaxation rate reduced by average coolant
temperature deviating from its reference (representing the coupled
heater/spray thermodynamic response of a real pressurizer, without
modelling two-phase saturation explicitly):

    dP/dt = (P_setpoint - P) / tau + k_heater * (T_avg - T_ref)
"""

from __future__ import annotations

from dataclasses import dataclass

from config import PressurizerConfig


@dataclass
class Pressurizer:
    cfg: PressurizerConfig
    pressure_mpa: float = 0.0

    def __post_init__(self) -> None:
        if self.pressure_mpa == 0.0:
            self.pressure_mpa = self.cfg.setpoint_mpa

    def step(self, coolant_temperature_deviation_c: float, dt: float) -> float:
        cfg = self.cfg
        d_p = (cfg.setpoint_mpa - self.pressure_mpa) / max(cfg.relaxation_time_s, 1.0e-3)
        d_p += cfg.heater_gain_mpa_per_c * coolant_temperature_deviation_c
        self.pressure_mpa += d_p * dt
        self.pressure_mpa = max(cfg.pressure_min_mpa * 0.5, min(self.pressure_mpa, cfg.pressure_max_mpa * 1.2))
        return self.pressure_mpa
