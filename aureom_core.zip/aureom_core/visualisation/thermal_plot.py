"""Thermal / primary-system plotting primitives (matplotlib, one Axes each)."""

from __future__ import annotations

import numpy as np
import pandas as pd

from visualisation.reactor_plot import AUREOM_ACCENT, AUREOM_ALARM, AUREOM_NAVY, AUREOM_STEEL


def plot_reactor_temperature(ax, df: pd.DataFrame) -> None:
    t = df["simulation_time_s"]
    ax.plot(t, df["fuel_temperature_c"], color=AUREOM_ALARM, linewidth=1.2, label="Fuel temperature")
    ax.plot(t, df["coolant_temperature_c"], color=AUREOM_NAVY, linewidth=1.4, label="Coolant temperature")
    ax.set_ylabel("Temperature (degC)")
    ax.set_title("Reactor Temperature")
    ax.legend(loc="best", fontsize=8, frameon=False)
    ax.grid(True, alpha=0.3)


def plot_coolant_flow(ax, df: pd.DataFrame) -> None:
    t = df["simulation_time_s"]
    ax.plot(t, df["coolant_flow_pct"], color=AUREOM_STEEL, linewidth=1.3)
    ax.set_ylabel("Primary coolant flow (% rated)")
    ax.set_title("Coolant Flow")
    ax.set_ylim(bottom=0)
    ax.grid(True, alpha=0.3)


def plot_thermal_efficiency(ax, df: pd.DataFrame) -> None:
    load_pct = (df["net_electrical_power_mw"] / max(df["net_electrical_power_mw"].max(), 1.0)) * 100.0
    thermal = df["reactor_thermal_power_mw"].replace(0, np.nan)
    efficiency_pct = (df["net_electrical_power_mw"] / thermal * 100.0).clip(lower=0, upper=60).fillna(0)

    ax.scatter(load_pct, efficiency_pct, s=4, color=AUREOM_ACCENT, alpha=0.5)
    ax.set_xlabel("Relative load (%)")
    ax.set_ylabel("Net thermal efficiency (%)")
    ax.set_title("Thermal Efficiency vs Load")
    ax.grid(True, alpha=0.3)
