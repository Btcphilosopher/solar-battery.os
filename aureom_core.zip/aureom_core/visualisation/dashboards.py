"""
Safety-state plot and text dashboard.
========================================

Plots the categorical safety-state trace (NORMAL / DEGRADED /
PROTECTIVE / SHUTDOWN, design brief §26 Plot 8), and renders a compact
observational ASCII status dashboard (design brief §27) from the latest
:class:`~simulation.simulation_state.PlantState`. The dashboard is
purely informational — it reports plant state, it does not accept
operator input or represent any real control-room instrumentation.
"""

from __future__ import annotations

import pandas as pd

from visualisation.reactor_plot import AUREOM_ACCENT, AUREOM_ALARM, AUREOM_NAVY, AUREOM_STEEL

_SAFETY_LEVELS = {"NORMAL": 0, "DEGRADED": 1, "PROTECTIVE": 2, "SHUTDOWN": 3}
_SAFETY_COLORS = {0: AUREOM_NAVY, 1: AUREOM_ACCENT, 2: AUREOM_ALARM, 3: "#555555"}


def plot_safety_state(ax, df: pd.DataFrame) -> None:
    t = df["simulation_time_s"]
    levels = df["safety_status"].map(_SAFETY_LEVELS).fillna(0)

    ax.step(t, levels, where="post", color=AUREOM_STEEL, linewidth=1.4)
    ax.set_yticks(list(_SAFETY_LEVELS.values()))
    ax.set_yticklabels(list(_SAFETY_LEVELS.keys()))
    ax.set_ylim(-0.3, 3.3)
    ax.set_title("Safety State")
    ax.grid(True, alpha=0.3)


def render_text_dashboard(state) -> str:
    """Render the ASCII status panel described in design brief §27 from a
    single :class:`~simulation.simulation_state.PlantState`."""

    def row(label_a, value_a, label_b, value_b):
        return f"| {label_a:<22}| {label_b:<22}|\n| {value_a:<22}| {value_b:<22}|"

    lines = [
        "+-------------------------------------------------+",
        "|                 AUREOM CORE                      |",
        "|          LARGE REACTOR DIGITAL TWIN               |",
        "+------------------------+--------------------------+",
        row("REACTOR POWER", f"{state.reactor_thermal_power_mw:,.0f} MWth", "ELECTRICAL OUTPUT", f"{state.net_electrical_power_mw:,.0f} MWe"),
        "+------------------------+--------------------------+",
        row("CORE TEMPERATURE", f"{state.coolant_temperature_c:,.0f} degC", "COOLANT FLOW", f"{state.coolant_flow_kg_s:,.0f} kg/s"),
        "+------------------------+--------------------------+",
        row("TURBINE", f"{state.turbine_power_mw:,.0f} MW", "GRID", f"{state.grid_demand_mw:,.0f} MW demand"),
        "+------------------------+--------------------------+",
        "|                    PLANT STATUS                   |",
        f"|                  * {state.safety_status:<10}                     |",
        "+-----------------------------------------------------+",
    ]
    return "\n".join(lines)
