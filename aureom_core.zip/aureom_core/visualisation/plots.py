"""
Summary plot — the 8-panel engineering figure (design brief §26).
"""

from __future__ import annotations

import matplotlib.pyplot as plt

from analysis.metrics import site_dataframe
from visualisation.dashboards import plot_safety_state
from visualisation.electrical_plot import plot_electrical_output, plot_grid_tracking
from visualisation.reactor_plot import plot_control_activity, plot_reactor_power
from visualisation.thermal_plot import plot_coolant_flow, plot_reactor_temperature, plot_thermal_efficiency

plt.rcParams.update(
    {
        "figure.facecolor": "white",
        "axes.facecolor": "white",
        "axes.edgecolor": "#333333",
        "axes.grid": True,
        "grid.color": "#dddddd",
        "font.size": 9,
        "axes.titlesize": 10,
        "axes.titleweight": "bold",
    }
)


def plot_summary(result, out_path: str = None, show: bool = False):
    df = site_dataframe(result)

    fig, axes = plt.subplots(4, 2, figsize=(13, 14))
    fig.suptitle(
        f"AUREOM CORE -- {result.metadata.scenario} "
        f"(units={result.metadata.units}, seed={result.metadata.random_seed})",
        fontsize=13,
        fontweight="bold",
    )

    plot_reactor_power(axes[0, 0], df)
    plot_reactor_temperature(axes[0, 1], df)
    plot_coolant_flow(axes[1, 0], df)
    plot_electrical_output(axes[1, 1], df)
    plot_grid_tracking(axes[2, 0], df)
    plot_control_activity(axes[2, 1], df)
    plot_thermal_efficiency(axes[3, 0], df)
    plot_safety_state(axes[3, 1], df)

    for row in axes[:3, :]:
        for ax in row:
            ax.set_xlabel("Simulation time (s)")
    axes[3, 0].set_xlabel("Relative load (%)")
    axes[3, 1].set_xlabel("Simulation time (s)")

    fig.tight_layout(rect=[0, 0, 1, 0.96])

    if out_path:
        fig.savefig(out_path, dpi=150)
    if show:
        plt.show()
    return fig
