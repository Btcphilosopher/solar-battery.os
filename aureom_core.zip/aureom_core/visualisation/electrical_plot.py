"""Electrical / grid plotting primitives (matplotlib, one Axes each)."""

from __future__ import annotations

import pandas as pd

from visualisation.reactor_plot import AUREOM_ACCENT, AUREOM_NAVY, AUREOM_STEEL


def plot_electrical_output(ax, df: pd.DataFrame) -> None:
    t = df["simulation_time_s"]
    ax.plot(t, df["gross_electrical_power_mw"], color=AUREOM_STEEL, linewidth=1.0, label="Gross")
    ax.plot(t, df["net_electrical_power_mw"], color=AUREOM_NAVY, linewidth=1.4, label="Net")
    ax.set_ylabel("Electrical power (MW)")
    ax.set_title("Electrical Output")
    ax.legend(loc="best", fontsize=8, frameon=False)
    ax.grid(True, alpha=0.3)
    ax.set_ylim(bottom=0)


def plot_grid_tracking(ax, df: pd.DataFrame) -> None:
    t = df["simulation_time_s"]
    ax.plot(t, df["grid_demand_mw"], color=AUREOM_ACCENT, linewidth=1.2, linestyle="--", label="Grid demand")
    ax.plot(t, df["net_electrical_power_mw"], color=AUREOM_NAVY, linewidth=1.3, label="Plant output")
    ax.set_ylabel("Power (MW)")
    ax.set_title("Grid Demand vs Plant Output")
    ax.legend(loc="best", fontsize=8, frameon=False)
    ax.grid(True, alpha=0.3)
