"""Reactor / control plotting primitives (matplotlib, one Axes each)."""

from __future__ import annotations

import pandas as pd

AUREOM_NAVY = "#13293d"
AUREOM_STEEL = "#3e5c76"
AUREOM_ACCENT = "#d6a419"
AUREOM_ALARM = "#b8332f"


def plot_reactor_power(ax, df: pd.DataFrame) -> None:
    t = df["simulation_time_s"]
    ax.plot(t, df["reactor_normalized_power"] * 100.0, color=AUREOM_NAVY, linewidth=1.4, label="Reactor power (%)")
    ax.set_ylabel("Reactor power (% rated)")
    ax.set_title("Reactor Power")
    ax.grid(True, alpha=0.3)
    ax.set_ylim(bottom=0)


def plot_control_activity(ax, df: pd.DataFrame) -> None:
    t = df["simulation_time_s"]
    ax.plot(t, df["control_rod_position_pct"], color=AUREOM_STEEL, linewidth=1.2, label="Rod position (%)")
    ax.plot(t, df["valve_position_pct"], color=AUREOM_ACCENT, linewidth=1.2, label="Valve position (%)")
    ax.set_ylabel("Actuator position (%)")
    ax.set_title("Control Activity")
    ax.set_ylim(-2, 102)
    ax.legend(loc="best", fontsize=8, frameon=False)
    ax.grid(True, alpha=0.3)
