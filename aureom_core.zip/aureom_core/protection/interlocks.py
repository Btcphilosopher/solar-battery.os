"""
Interlocks.
=============

Simple permissive checks that gate normal control actions, independent
of (and evaluated alongside) the trip logic. These are illustrative
generic interlocks for the digital twin, not a real plant's licensed
interlock set.
"""

from __future__ import annotations

from config import ProtectionConfig
from protection.trip_logic import TripMeasurements


def rod_withdrawal_permitted(cfg: ProtectionConfig, m: TripMeasurements, scram_active: bool) -> bool:
    if scram_active:
        return False
    if m.flow_pct <= cfg.low_coolant_flow_trip_pct + 5.0:
        return False
    if m.power_pct >= cfg.high_power_trip_pct - 3.0:
        return False
    return True


def turbine_loading_permitted(cfg: ProtectionConfig, m: TripMeasurements) -> bool:
    return m.condenser_backpressure_kpa < cfg.high_condenser_backpressure_trip_kpa - 3.0
