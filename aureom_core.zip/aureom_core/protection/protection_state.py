"""Observable state for the reactor protection system (RPS)."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class ProtectionStatus(str, Enum):
    NORMAL = "NORMAL"
    ALARM = "ALARM"
    TRIPPED = "TRIPPED"


@dataclass
class ProtectionState:
    status: ProtectionStatus = ProtectionStatus.NORMAL
    active_trips: tuple = field(default_factory=tuple)
    scram_commanded: bool = False
    turbine_trip_commanded: bool = False
    latched: bool = False
