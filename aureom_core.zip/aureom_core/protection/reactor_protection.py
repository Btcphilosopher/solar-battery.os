"""
Reactor protection system (RPS).
====================================

Architecturally independent of the normal reactor/turbine controllers
(design brief §15): it only ever *reads* plant measurements and issues a
SCRAM / turbine-trip command — it never adjusts control rods or the
governor valve directly, and normal control logic cannot suppress it.
Once tripped, the protection state is latched (requires an explicit
operator-style reset) rather than clearing itself the moment a
measurement drops back below its setpoint, matching the qualitative
behaviour of a real protection system.
"""

from __future__ import annotations

from dataclasses import dataclass

from config import ProtectionConfig
from protection.protection_state import ProtectionState, ProtectionStatus
from protection.trip_logic import TripMeasurements, evaluate_trips


@dataclass
class ReactorProtectionSystem:
    cfg: ProtectionConfig
    state: ProtectionState = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        if self.state is None:
            self.state = ProtectionState()

    def reset(self) -> None:
        self.state = ProtectionState()

    def evaluate(self, measurements: TripMeasurements) -> ProtectionState:
        trips = evaluate_trips(self.cfg, measurements)

        if self.state.latched:
            status = ProtectionStatus.TRIPPED
            scram = True
            turbine_trip = True
        elif trips:
            status = ProtectionStatus.TRIPPED
            scram = True
            turbine_trip = True
            self.state.latched = True
        else:
            status = ProtectionStatus.NORMAL
            scram = False
            turbine_trip = False

        self.state = ProtectionState(
            status=status,
            active_trips=tuple(trips),
            scram_commanded=scram,
            turbine_trip_commanded=turbine_trip,
            latched=self.state.latched,
        )
        return self.state
