"""
Reactor-protection trip logic.
=================================

Evaluates plant measurements against configurable, clearly synthetic trip
setpoints (see config.ProtectionConfig — NON-OPERATIONAL PLACEHOLDER
VALUES). Each condition is independently evaluated and reported by name,
so the protection layer's reasoning is fully observable rather than a
single opaque boolean.
"""

from __future__ import annotations

from dataclasses import dataclass

from config import ProtectionConfig


@dataclass
class TripMeasurements:
    power_pct: float
    fuel_temperature_c: float
    coolant_temperature_c: float
    flow_pct: float
    pressurizer_pressure_mpa: float
    condenser_backpressure_kpa: float
    frequency_deviation_hz: float
    instrumentation_deviation_c: float = 0.0


def evaluate_trips(cfg: ProtectionConfig, m: TripMeasurements) -> list[str]:
    trips: list[str] = []

    if m.power_pct >= cfg.high_power_trip_pct:
        trips.append("HIGH_REACTOR_POWER")

    if m.fuel_temperature_c >= cfg.high_fuel_temperature_trip_c:
        trips.append("HIGH_FUEL_TEMPERATURE")

    if m.coolant_temperature_c >= cfg.high_coolant_temperature_trip_c:
        trips.append("HIGH_COOLANT_TEMPERATURE")

    if m.flow_pct <= cfg.low_coolant_flow_trip_pct:
        trips.append("LOW_COOLANT_FLOW")

    if m.pressurizer_pressure_mpa >= cfg.high_pressurizer_pressure_trip_mpa:
        trips.append("HIGH_PRESSURIZER_PRESSURE")

    if m.pressurizer_pressure_mpa <= cfg.low_pressurizer_pressure_trip_mpa:
        trips.append("LOW_PRESSURIZER_PRESSURE")

    if m.condenser_backpressure_kpa >= cfg.high_condenser_backpressure_trip_kpa:
        trips.append("HIGH_CONDENSER_BACKPRESSURE")

    if abs(m.frequency_deviation_hz) >= cfg.grid_disturbance_frequency_deviation_hz:
        trips.append("GRID_DISTURBANCE")

    if abs(m.instrumentation_deviation_c) >= cfg.instrumentation_deviation_trip_c:
        trips.append("INSTRUMENTATION_INCONSISTENCY")

    return trips
