# AUREOM CORE

**Advanced Unified Reactor Operations & Engineering Model**
*Large Reactor Digital Twin — High-Fidelity Nuclear Power Station Simulation Platform*

> **Safety disclaimer — read first.** AUREOM CORE is a **synthetic, reduced-order
> engineering simulation and digital-twin research platform**. It is **not** a
> reactor design tool, a certified safety-analysis package, or an operational
> control system. Every numeric parameter in `config.py` is a clearly labelled
> *synthetic simulation parameter*, chosen to be plausible for a large
> (~1,000–1,600 MWe class) light-water generating station, but **none of it is
> derived from, and none of it should be read as, any real reactor design,
> proprietary vendor data, licensed operating parameter, or protection-system
> setpoint.** Do not use this software, or any value in it, as an input to a
> real engineering, licensing, or operational decision.

---

## 1. Project overview

AUREOM CORE is a deterministic, discrete-time simulation of a hypothetical large
commercial pressurised-water-reactor-class generating station: a single
~3,000–4,500 MWth / ~1,000–1,600 MWe reactor unit (architecture extensible to
1–4 units sharing a site grid interface), a conventional Rankine steam cycle,
a large turbine-generator, and a full control/protection/safety stack.

It exists to let an engineer or researcher study reactor response, thermal
inertia, heat transport, steam-cycle behaviour, turbine dynamics, electrical
generation, grid load-following, controller performance, equipment
degradation, sensor faults, protective transitions, shutdown behaviour,
residual (decay) heat, and multi-unit station behaviour — as one coherent,
dynamically coupled engineering system, not as a lookup-table efficiency
calculation.

The governing causal chain, realised end-to-end every timestep, is:

```
Reactivity -> Neutron/fission proxy -> Thermal power
    -> Fuel/core thermal mass -> Primary coolant -> Steam generator
    -> Steam -> Turbine -> Generator -> Electrical grid
    -> Demand feedback -> Control system -> Reactor state
```

## 2. Architecture

```
Nuclear Island                         Secondary Island
  Reactor Core (core/)                   Main Steam (secondary/steam_system.py)
  Reactor Vessel (primary/)              Turbine (secondary/turbine.py)
  Primary Coolant / RCPs / Pressurizer   Generator (secondary/generator.py)
  Steam Generators (primary/)            Condenser (secondary/condenser.py)
  Reactor Protection (protection/)       Feedwater (secondary/feedwater.py)
  Emergency Safety Systems (safety/)
        |                                        |
        +---------------> Electrical (electrical/) --------> Grid
                                  |
                          Control (control/)
```

Package layout:

```
aureom_core/
  main.py                 CLI demonstration entry point
  config.py                All engineering parameters (typed dataclasses)
  core/                    Point-kinetics, reactivity, fuel/poison proxy, core thermal model
  primary/                 RCPs, pressurizer, steam generators, vessel, coolant loop
  secondary/                Main steam, turbine, generator, condenser, feedwater
  electrical/               Grid interconnection, transformer, load profiles
  control/                  PID, control rods, reactor/turbine controllers, load following
  protection/                Independent reactor protection system (trip logic, interlocks)
  safety/                   Fault detection, emergency cooling, thermal limits, containment proxy
  plant/                    Nuclear/turbine islands, balance of plant, top-level station API
  simulation/                Deterministic engine, scenarios, fault scheduler, events, state
  scenarios/                 Built-in scenario library
  analysis/                  Efficiency, stability, performance metrics, reporting
  visualisation/             Matplotlib plots and a text status dashboard
  tests/                     pytest suite
```

Physics, control, protection, and visualisation are strictly separated: no
subsystem module imports `visualisation/`, and the independent
`protection/` layer never calls into `control/` — it only ever reads plant
measurements and issues a scram/turbine-trip command.

## 3. Installation

Requires Python 3.11+.

```bash
cd aureom_core
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

## 4. Dependencies

Deliberately modest: `numpy`, `scipy`, `pandas`, `matplotlib`, `pytest`. No
web/dashboard framework is required for the core simulator; the optional
live-dashboard layer (`visualisation/dashboards.py`) renders a text panel
with no extra dependencies.

## 5. Running the simulator

```bash
python main.py --scenario grid_fluctuation --duration 3600 --timestep 0.1
python main.py --list-scenarios
```

This writes CSV/JSON telemetry, an 8-panel summary plot, and a text
performance report to `output/`, and prints an engineering-style console
log plus a final ASCII status dashboard.

Programmatic API (design brief §29/§44):

```python
from aureom_core import NuclearPowerStation

station = NuclearPowerStation(
    units=1,
    reactor_power_mw=3400.0,
    electrical_capacity_mw=1300.0,
)
result = station.run(duration=3600, scenario="grid_fluctuation")
result.plot(out_path="summary.png")
result.report()
```

A single-unit convenience alias matching the alternate example API is also
available:

```python
from aureom_core import ReactorSimulation

sim = ReactorSimulation(reactor_power_mw=3200.0, electrical_capacity_mw=1200.0, timestep=0.1)
result = sim.run(duration=3600, scenario="grid_fluctuation")
```

Multi-unit station sharing one site grid interface (1–4 units):

```python
station = NuclearPowerStation(units=3, reactor_power_mw=3200.0, electrical_capacity_mw=1200.0)
result = station.run(duration=7200, scenario="multi_unit_load_following")
```

## 6. Reactor model

`core/neutron_kinetics.py` implements standard six-delayed-group point
kinetics, sub-stepped internally with RK4 (the system is numerically stiff
relative to the outer simulation timestep). `core/reactivity.py` sums
control, thermal-feedback, fuel-feedback, xenon-poison, and external
reactivity contributions into one fully observable `ReactivityState`.
`core/fuel_model.py` tracks a reduced-order I-135/Xe-135 poison proxy and a
burnup proxy. `core/core_thermal_model.py` is a two-node (fuel + coolant)
lumped-capacitance thermal model, giving the plant genuine thermal lag
rather than an instantaneous power-to-heat conversion.

## 7. Thermal model

Energy-balance equations throughout (`Q = m_dot * Cp * dT`, `dT/dt = Q_net /
thermal_mass`) — never an instantaneous `power * efficiency` shortcut. See
`core/core_thermal_model.py`, `primary/coolant_loop.py`, and
`primary/steam_generators.py`. After a reactor trip, `core/reactor_core.py`
continues to compute a decay-heat proxy (`P_decay(t) = f0 * P_trip * ((t +
t0)/t0)^-0.2`, a Way-Wigner-style empirical approximation) — shutdown does
not mean zero thermal energy.

## 8. Turbine model

`secondary/turbine.py` uses a simplified Willans-line power characteristic
coupled to a single-mass rotor equation `J * domega/dt = T_steam -
T_generator - T_loss`. `secondary/generator.py` converts shaft power to
electrical power and feeds an electromagnetic counter-torque back to the
rotor. `secondary/condenser.py` models backpressure as a first-order
response to exhaust-steam duty and cooling-water availability.

## 9. Electrical model

`electrical/grid_model.py` computes auxiliary consumption, `net_output =
gross_generator_output - auxiliary_consumption`, transformer losses, a
terminal-voltage proxy, and a droop-based grid-frequency proxy (`freq_target
= f_nominal + (export - demand) / grid_stiffness`, lagged by a swing time
constant). `electrical/load_model.py` provides the deterministic demand
profiles: `constant`, `morning_ramp`, `evening_ramp`, `sinusoidal`,
`grid_fluctuation`, `industrial_load`, `custom`.

## 10. Control architecture

Hierarchical, matching the design brief:

```
              PLANT CONTROLLER (control/load_following.py)
                     |
       +-------------+-------------+
       |                           |
REACTOR CONTROLLER           TURBINE CONTROLLER
(control/reactor_controller)  (control/turbine_controller)
       |                           |
  control rods                 governor valve
(control/control_rods.py)   (secondary/steam_system.py)
```

`control/pid.py` provides a reusable `PIDController` with saturation,
back-calculation anti-windup, output rate limiting, and an error deadband.

## 11. Protection architecture

`protection/reactor_protection.py` is architecturally independent of the
controllers: it only reads measurements and issues a scram/turbine-trip
command, and normal control logic can never suppress it. Trip conditions
(`protection/trip_logic.py`) use configurable, explicitly-labelled
non-operational placeholder setpoints in `config.ProtectionConfig`. A trip
latches until an explicit reset — it does not clear itself the moment a
measurement recovers.

## 12. Scenario system

`simulation/scenario.py` defines `ScenarioConfig` and a name registry;
`scenarios/` contains the built-in library, imported once (as a package)
to register every scenario. Run `python main.py --list-scenarios` for the
full list, or call `aureom_core.available_scenarios()`. Includes nominal
operation, several load-following/ramp profiles, startup, shutdown, grid
disturbance, five fault-injection scenarios, a protective-shutdown /
post-shutdown-decay-heat pair, and a multi-unit variant.

## 13. Visualisation

`visualisation/plots.py` renders the required 8-panel matplotlib summary
figure (reactor power, reactor temperature, coolant flow, electrical
output, grid demand vs. plant output, control activity, thermal efficiency
vs. load, safety-state transitions). `visualisation/dashboards.py` renders
a compact, purely observational ASCII status panel from the latest plant
state — it reports state, it does not accept operator input.

## 14. Testing

```bash
pytest
```

Covers reactor-physics response and decay heat, thermal-hydraulics
direction/lag, turbine/generator dynamics, PID saturation/anti-windup and
load tracking, fault detection and protective-transition/latching
behaviour, post-shutdown thermal boundedness, and simulation-level
determinism, timestep validation, finite-value guarding, and CSV/JSON
export.

## 15. Configuration

Every engineering parameter lives in a typed, frozen dataclass in
`config.py` (`ReactorConfig`, `CoolantConfig`, `SteamGeneratorConfig`,
`TurbineConfig`, `GeneratorConfig`, `GridConfig`, `ControlConfig`,
`ProtectionConfig`, `SafetyConfig`, `SimulationConfig`, ...), aggregated
into `PlantConfig`. `default_large_reactor_config(reactor_power_mw,
electrical_capacity_mw)` builds a self-consistent large-reactor-scale
configuration by proportionally scaling the defaults. **Every value is a
synthetic simulation parameter**, not a real plant's operating data.

## 16. Data export

`SimulationResult.to_csv(path)` / `.to_json(path)` export full telemetry
(reactor, primary, secondary, electrical, control, and safety columns) plus
reproducibility metadata: `simulation_id`, `software_version`,
`configuration_hash`, `scenario`, `random_seed`, `timestep_s`,
`duration_s`, `generated_at_utc`. Re-running the same configuration and
seed reproduces the same `configuration_hash` and identical telemetry.

## 17. Limitations

* Reduced-order, lumped-parameter physics throughout — not a
  spatial/multi-node neutronics, sub-channel thermal-hydraulics, or
  steam-table-accurate model. Saturation temperature and enthalpy-drop
  relationships are simplified linear proxies, documented at their
  point of use.
* Several tightly-coupled subsystems (primary loop / steam generator,
  turbine / generator torque) use a one-timestep staggered-solve lag
  rather than an implicit simultaneous solve; at the configured
  timestep this is stable and negligible relative to the subsystems'
  own multi-second time constants, but it is a modelling simplification.
* Multi-unit "site" aggregation sums per-unit electrical output and
  shares one demand signal; detailed unit-to-unit electrical coupling
  (shared switchyard dynamics, etc.) is not modelled.
* Not validated against, and not intended to reproduce, any specific
  real reactor design or licensed safety analysis.

## 18. Safety disclaimer (restated)

AUREOM CORE is a synthetic reduced-order simulation and digital-twin
research platform for simulation, education, control-system
experimentation, and scenario analysis. It is **not** a reactor design
tool, a certified safety-analysis package, or an operational control
system, and no output of this software should inform any real-world
nuclear engineering, licensing, or operational decision.
