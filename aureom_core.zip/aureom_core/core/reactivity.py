"""
Reactivity accounting.
=======================

Combines the independently observable reactivity contributions into the
total reactivity fed to the point-kinetics model:

    total = control + thermal_feedback + fuel_feedback + poison_feedback + external

Temperature feedbacks are modelled as simple linear coefficients about a
reference temperature, which by design (negative coefficients) provide
the negative feedback that is the primary self-stabilising mechanism of
a light-water reactor core. This is a reduced-order proxy, not a
lattice-physics-derived feedback curve.
"""

from __future__ import annotations

from dataclasses import dataclass

from config import ReactivityConfig
from core.core_state import ReactivityState


@dataclass
class ReactivityModel:
    cfg: ReactivityConfig

    def compute(
        self,
        control_reactivity: float,
        fuel_temperature_c: float,
        coolant_temperature_c: float,
        xenon_concentration: float,
        external_reactivity: float = 0.0,
    ) -> ReactivityState:
        cfg = self.cfg

        thermal_feedback = cfg.coolant_temperature_coefficient_per_c * (
            coolant_temperature_c - cfg.reference_coolant_temperature_c
        )
        fuel_feedback = cfg.fuel_temperature_coefficient_per_c * (
            fuel_temperature_c - cfg.reference_fuel_temperature_c
        )
        poison_feedback = cfg.xenon_worth_per_unit_concentration * xenon_concentration

        control = max(-abs(cfg.max_control_reactivity) * 6.0, min(control_reactivity, cfg.max_control_reactivity))

        return ReactivityState(
            control=control,
            thermal_feedback=thermal_feedback,
            fuel_feedback=fuel_feedback,
            poison_feedback=poison_feedback,
            external=external_reactivity,
        )
