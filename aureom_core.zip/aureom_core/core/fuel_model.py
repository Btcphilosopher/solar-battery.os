"""
Fuel / fission-product-poison proxy model.
===========================================

Tracks a reduced-order Iodine-135 / Xenon-135 "poison proxy" pair, using
the standard simplified I-135/Xe-135 production-decay-burnout kinetics
found in reactor-physics textbooks, plus a simple linear burnup-proxy
accumulator. None of these are plant-specific; they exist purely to give
the digital twin a slow (hours-timescale) reactivity feedback path that
is independent of the fast thermal feedback, which is important for
realistic load-following and post-shutdown behaviour.

    dI/dt  = yield_I * fission_rate - lambda_I * I
    dXe/dt = yield_Xe * fission_rate + lambda_I * I
             - lambda_Xe * Xe - sigma_Xe * flux_proxy * Xe

``fission_rate`` and ``flux_proxy`` are both represented by the
normalized neutron population ``n`` for simplicity (reduced-order proxy,
not a multi-group flux solution).
"""

from __future__ import annotations

from dataclasses import dataclass

from config import FuelConfig
from core.core_state import FuelState


@dataclass
class FuelModel:
    cfg: FuelConfig

    def step(self, state: FuelState, normalized_power: float, dt: float) -> FuelState:
        cfg = self.cfg
        n = max(normalized_power, 0.0)

        dI_dt = cfg.iodine_yield_fraction * n - cfg.iodine_decay_constant_per_s * state.iodine_concentration
        dXe_dt = (
            cfg.xenon_yield_fraction * n
            + cfg.iodine_decay_constant_per_s * state.iodine_concentration
            - cfg.xenon_decay_constant_per_s * state.xenon_concentration
            - cfg.xenon_microscopic_burn_rate * n * state.xenon_concentration
        )

        iodine = max(state.iodine_concentration + dI_dt * dt, 0.0)
        xenon = max(state.xenon_concentration + dXe_dt * dt, 0.0)

        # Burnup proxy: simple integral of thermal power over time, used
        # only as an illustrative long-duration performance-degradation
        # signal (see analysis/performance.py), not a licensed depletion
        # calculation.
        burnup = state.burnup_proxy_mwd_per_t + n * dt / 86400.0

        return FuelState(
            iodine_concentration=iodine,
            xenon_concentration=xenon,
            burnup_proxy_mwd_per_t=burnup,
        )
