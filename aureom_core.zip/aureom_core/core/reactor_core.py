"""
Reactor core — top-level composition.
======================================

Wires together neutron kinetics, reactivity accounting, the fission-product
poison proxy, the two-node core thermal model, and a decay-heat proxy into
a single :class:`ReactorCore` object that owns the observable
:class:`~core.core_state.CoreState`.

Causal chain realised by this module (see design brief §39):

    reactivity -> neutron/fission proxy -> thermal power
        -> fuel/coolant thermal mass -> heat to primary coolant

Decay heat
----------
After a reactor trip, fission power collapses on the (fast) neutron-kinetics
timescale, but the core continues to generate significant thermal power from
radioactive decay of fission products. This module implements a documented
empirical (Way-Wigner-style) decay-heat approximation:

    P_decay(t) = f0 * P_trip * ((t + t0) / t0) ** -0.2

where ``t`` is time since trip, ``P_trip`` is the fission power immediately
before trip, ``f0`` is the configured decay-heat fraction at t=0, and ``t0``
is a small regularising time constant that avoids the singularity of a pure
power law at t=0. This is a reduced-order engineering approximation, not a
licensed decay-heat standard (e.g. ANS-5.1) calculation.
"""

from __future__ import annotations

from dataclasses import dataclass

from config import ReactorConfig
from core.core_state import CoreState, FuelState, ReactorStatus
from core.core_thermal_model import CoreThermalModel
from core.fuel_model import FuelModel
from core.neutron_kinetics import NeutronKinetics
from core.reactivity import ReactivityModel


@dataclass
class ReactorCore:
    cfg: ReactorConfig

    def __post_init__(self) -> None:
        self._kinetics = NeutronKinetics(self.cfg.kinetics)
        self._reactivity = ReactivityModel(self.cfg.reactivity)
        self._fuel_model = FuelModel(self.cfg.fuel)
        self._thermal = CoreThermalModel(self.cfg.fuel)
        self.state = CoreState(
            precursor_concentrations=self._kinetics.equilibrium_precursors(1.0e-9),
        )

    def initialize_at_power(self, normalized_power: float, coolant_temperature_c: float) -> None:
        """Seed the core in an equilibrium state at the given power fraction,
        used by scenarios that start at steady-state power operation rather
        than from a cold, shut-down condition."""

        n0 = max(normalized_power, 1.0e-9)
        self.state.normalized_power = n0
        self.state.precursor_concentrations = self._kinetics.equilibrium_precursors(n0)
        self.state.fuel_temperature_c = coolant_temperature_c + 40.0 * n0
        self.state.coolant_temperature_avg_c = coolant_temperature_c
        self.state.fission_power_mw = n0 * self.cfg.nominal_thermal_power_mw
        self.state.thermal_power_mw = self.state.fission_power_mw
        self.state.status = ReactorStatus.POWER_OPERATION if n0 > 0.005 else ReactorStatus.SHUTDOWN

    def trip(self) -> None:
        """Record a reactor trip; decay-heat integration begins from this point."""
        if self.state.status != ReactorStatus.TRIPPED:
            self.state.status = ReactorStatus.TRIPPED
            self.state.time_since_trip_s = 0.0
            self.state.power_at_trip_mw = self.state.fission_power_mw

    def _decay_power_mw(self, dt: float) -> float:
        if self.state.time_since_trip_s is None or self.state.power_at_trip_mw is None:
            return 0.0
        t0 = max(self.cfg.decay_heat_time_constant_s, 1.0e-3)
        t = self.state.time_since_trip_s + dt
        fraction = ((t + t0) / t0) ** -0.2
        return self.cfg.decay_heat_fraction_at_trip * self.state.power_at_trip_mw * fraction

    def step(
        self,
        dt: float,
        control_reactivity: float,
        coolant_inlet_temperature_c: float,
        coolant_mass_flow_kg_s: float,
        coolant_specific_heat_kj_per_kg_c: float,
        external_reactivity: float = 0.0,
        extra_heat_removal_mw: float = 0.0,
    ) -> CoreState:
        s = self.state

        reactivity = self._reactivity.compute(
            control_reactivity=control_reactivity,
            fuel_temperature_c=s.fuel_temperature_c,
            coolant_temperature_c=s.coolant_temperature_avg_c,
            xenon_concentration=s.fuel.xenon_concentration,
            external_reactivity=external_reactivity,
        )

        kinetics_result = self._kinetics.step(
            n=s.normalized_power,
            c=s.precursor_concentrations,
            rho=reactivity.total,
            dt=dt,
        )

        fuel_state = self._fuel_model.step(s.fuel, kinetics_result.normalized_power, dt)

        fission_power_mw = kinetics_result.normalized_power * self.cfg.nominal_thermal_power_mw

        if s.time_since_trip_s is not None:
            decay_power_mw = self._decay_power_mw(dt)
            s.time_since_trip_s += dt
        else:
            decay_power_mw = 0.0

        thermal_power_mw = fission_power_mw + decay_power_mw

        thermal_result = self._thermal.step(
            fuel_temperature_c=s.fuel_temperature_c,
            coolant_temperature_avg_c=s.coolant_temperature_avg_c,
            thermal_power_mw=thermal_power_mw,
            coolant_inlet_temperature_c=coolant_inlet_temperature_c,
            coolant_mass_flow_kg_s=max(coolant_mass_flow_kg_s, 0.0),
            coolant_specific_heat_kj_per_kg_c=coolant_specific_heat_kj_per_kg_c,
            dt=dt,
            extra_heat_removal_mw=extra_heat_removal_mw,
        )

        if s.status != ReactorStatus.TRIPPED:
            if kinetics_result.normalized_power < 1.0e-5:
                status = ReactorStatus.SHUTDOWN
            elif kinetics_result.normalized_power < 0.98:
                status = ReactorStatus.STARTUP
            else:
                status = ReactorStatus.POWER_OPERATION
        else:
            status = ReactorStatus.TRIPPED

        s.time_s += dt
        s.normalized_power = kinetics_result.normalized_power
        s.precursor_concentrations = kinetics_result.precursor_concentrations
        s.reactivity = reactivity
        s.fuel = fuel_state
        s.fuel_temperature_c = thermal_result.fuel_temperature_c
        s.coolant_temperature_avg_c = thermal_result.coolant_temperature_avg_c
        s.coolant_outlet_temperature_c = thermal_result.coolant_outlet_temperature_c
        s.fission_power_mw = fission_power_mw
        s.decay_power_mw = decay_power_mw
        s.thermal_power_mw = thermal_power_mw
        s.heat_to_coolant_mw = thermal_result.heat_to_coolant_mw
        s.status = status

        return s
