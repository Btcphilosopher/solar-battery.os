"""
Point-kinetics neutron model.
=============================

Reduced-order six-delayed-group point-kinetics equations, the standard
approximation used in reactor-simulator and control-system literature in
place of full spatial neutron transport:

    dn/dt   = ((rho - beta) / Lambda) * n + sum_i(lambda_i * C_i)
    dC_i/dt = (beta_i / Lambda) * n - lambda_i * C_i

where ``n`` is the normalized neutron population (proxy for normalized
reactor power, 1.0 = 100 % rated), ``C_i`` are normalized delayed-neutron
precursor concentrations, ``rho`` is total reactivity (dk/k), ``beta`` is
total delayed-neutron fraction, ``Lambda`` is the prompt-neutron
generation time, and ``beta_i`` / ``lambda_i`` are the six-group yield
fractions and decay constants.

Numerical method
-----------------
The characteristic eigenvalue of these equations is approximately
``-beta/Lambda`` (a few hundred per second for typical thermal-reactor
parameters), which makes the system numerically stiff relative to the
outer simulation timestep. To keep the explicit integrator stable and
bounded without resorting to an implicit solver, this module sub-steps
internally with a classical 4th-order Runge-Kutta integrator at a
substep size below ``max_kinetics_substep_s``.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from config import NeutronKineticsConfig


@dataclass
class KineticsResult:
    normalized_power: float
    precursor_concentrations: tuple


class NeutronKinetics:
    """Six-group point-kinetics integrator."""

    def __init__(self, cfg: NeutronKineticsConfig):
        self.cfg = cfg
        self._n_groups = len(cfg.beta_fractions)

    def equilibrium_precursors(self, n0: float) -> tuple:
        """Steady-state precursor concentrations for a given power level.

        At equilibrium dC_i/dt = 0  =>  C_i = (beta_i / (Lambda * lambda_i)) * n
        """
        lam = self.cfg.prompt_neutron_lifetime_s
        return tuple(
            (beta_i / (lam * lambda_i)) * n0
            for beta_i, lambda_i in zip(self.cfg.beta_fractions, self.cfg.precursor_decay_constants_s)
        )

    def _derivatives(self, n: float, c: tuple, rho: float) -> tuple:
        cfg = self.cfg
        beta = cfg.beta_total
        lam = cfg.prompt_neutron_lifetime_s

        precursor_source = sum(
            lambda_i * c_i for lambda_i, c_i in zip(cfg.precursor_decay_constants_s, c)
        )
        dn_dt = ((rho - beta) / lam) * n + precursor_source
        dc_dt = tuple(
            (beta_i / lam) * n - lambda_i * c_i
            for beta_i, lambda_i, c_i in zip(cfg.beta_fractions, cfg.precursor_decay_constants_s, c)
        )
        return dn_dt, dc_dt

    def step(self, n: float, c: tuple, rho: float, dt: float) -> KineticsResult:
        """Advance the point-kinetics state by ``dt`` seconds using
        sub-stepped RK4 integration for numerical stability."""

        if dt <= 0.0:
            return KineticsResult(n, c)

        n_substeps = max(1, math.ceil(dt / self.cfg.max_kinetics_substep_s))
        h = dt / n_substeps

        state_n, state_c = n, c
        for _ in range(n_substeps):
            k1n, k1c = self._derivatives(state_n, state_c, rho)

            n2 = state_n + 0.5 * h * k1n
            c2 = tuple(ci + 0.5 * h * dci for ci, dci in zip(state_c, k1c))
            k2n, k2c = self._derivatives(n2, c2, rho)

            n3 = state_n + 0.5 * h * k2n
            c3 = tuple(ci + 0.5 * h * dci for ci, dci in zip(state_c, k2c))
            k3n, k3c = self._derivatives(n3, c3, rho)

            n4 = state_n + h * k3n
            c4 = tuple(ci + h * dci for ci, dci in zip(state_c, k3c))
            k4n, k4c = self._derivatives(n4, c4, rho)

            state_n = state_n + (h / 6.0) * (k1n + 2 * k2n + 2 * k3n + k4n)
            state_c = tuple(
                ci + (h / 6.0) * (a + 2 * b + 2 * cc + d)
                for ci, a, b, cc, d in zip(state_c, k1c, k2c, k3c, k4c)
            )

            # Physical bound: neutron population proxy cannot be negative.
            state_n = max(state_n, 1.0e-12)
            state_c = tuple(max(ci, 0.0) for ci in state_c)

            if not (math.isfinite(state_n) and all(math.isfinite(ci) for ci in state_c)):
                # Numerical-safety fallback: hold the last finite state rather
                # than propagate NaN/Inf through the plant model.
                state_n, state_c = n, c
                break

        return KineticsResult(state_n, state_c)
