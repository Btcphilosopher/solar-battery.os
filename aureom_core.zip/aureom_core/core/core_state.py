"""Observable state objects for the reactor-core subsystem."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class ReactorStatus(str, Enum):
    SHUTDOWN = "SHUTDOWN"
    STARTUP = "STARTUP"
    CRITICAL = "CRITICAL"
    POWER_OPERATION = "POWER_OPERATION"
    TRIPPED = "TRIPPED"


@dataclass
class ReactivityState:
    """Decomposition of total core reactivity (dimensionless, delta-k/k).

    total = control + thermal_feedback + fuel_feedback + poison_feedback + external
    """

    control: float = 0.0
    thermal_feedback: float = 0.0
    fuel_feedback: float = 0.0
    poison_feedback: float = 0.0
    external: float = 0.0

    @property
    def total(self) -> float:
        return (
            self.control
            + self.thermal_feedback
            + self.fuel_feedback
            + self.poison_feedback
            + self.external
        )


@dataclass
class FuelState:
    """Fission-product poison proxy state (normalized concentrations)."""

    iodine_concentration: float = 0.0
    xenon_concentration: float = 0.0
    burnup_proxy_mwd_per_t: float = 0.0


@dataclass
class CoreState:
    """Central observable state of the reactor core."""

    time_s: float = 0.0
    normalized_power: float = 1.0e-9  # n, dimensionless (1.0 = 100% rated power)
    precursor_concentrations: tuple = field(default_factory=tuple)
    reactivity: ReactivityState = field(default_factory=ReactivityState)
    fuel: FuelState = field(default_factory=FuelState)

    fuel_temperature_c: float = 290.0
    coolant_temperature_avg_c: float = 290.0
    coolant_outlet_temperature_c: float = 290.0

    fission_power_mw: float = 0.0
    decay_power_mw: float = 0.0
    thermal_power_mw: float = 0.0
    heat_to_coolant_mw: float = 0.0

    status: ReactorStatus = ReactorStatus.SHUTDOWN
    time_since_trip_s: float | None = None
    power_at_trip_mw: float | None = None
