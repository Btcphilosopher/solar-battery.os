"""
Core thermal model.
====================

Two-node lumped thermal-capacitance model of the reactor core: a fuel
node (representing the fuel + cladding thermal mass) and a coolant node
(representing the coolant mass resident in the core at any instant).
This is what gives the plant realistic thermal *lag* between a change in
fission power and the resulting change in coolant outlet temperature,
rather than an instantaneous reactor-power-to-electricity conversion.

    dT_fuel/dt    = (Q_thermal - Q_transfer) / C_fuel
    Q_transfer    = UA * (T_fuel - T_coolant_avg)
    dT_coolant/dt = (Q_transfer - Q_carried_by_flow) / C_coolant
    Q_carried_by_flow = 2 * m_dot * Cp * (T_coolant_avg - T_inlet)

The factor of two on the flow term follows from T_coolant_avg being the
mean of the core inlet and outlet temperatures
(T_avg = (T_in + T_out) / 2  =>  T_out - T_in = 2 (T_avg - T_in)), so the
energy carried out of the core by the flow, m_dot*Cp*(T_out - T_in),
becomes 2*m_dot*Cp*(T_avg - T_in).

All thermal masses (`C_fuel`, `C_coolant`) are expressed in MJ/°C so that
power terms in MW integrate directly to °C/s.
"""

from __future__ import annotations

from dataclasses import dataclass

from config import FuelConfig


@dataclass
class CoreThermalResult:
    fuel_temperature_c: float
    coolant_temperature_avg_c: float
    coolant_outlet_temperature_c: float
    heat_to_coolant_mw: float


@dataclass
class CoreThermalModel:
    cfg: FuelConfig

    def step(
        self,
        fuel_temperature_c: float,
        coolant_temperature_avg_c: float,
        thermal_power_mw: float,
        coolant_inlet_temperature_c: float,
        coolant_mass_flow_kg_s: float,
        coolant_specific_heat_kj_per_kg_c: float,
        dt: float,
        extra_heat_removal_mw: float = 0.0,
    ) -> CoreThermalResult:
        cfg = self.cfg

        q_transfer_mw = cfg.fuel_to_coolant_ua_mw_per_c * (fuel_temperature_c - coolant_temperature_avg_c)

        d_fuel_dt = (thermal_power_mw - q_transfer_mw) / cfg.fuel_thermal_mass_mj_per_c
        fuel_temp_new = fuel_temperature_c + d_fuel_dt * dt

        # m_dot [kg/s] * Cp [kJ/kg/C] = kW/C -> MW/C by /1000
        flow_capacity_mw_per_c = coolant_mass_flow_kg_s * coolant_specific_heat_kj_per_kg_c / 1000.0
        q_carried_mw = 2.0 * flow_capacity_mw_per_c * (coolant_temperature_avg_c - coolant_inlet_temperature_c)
        # Emergency-cooling heat removal (safety/emergency_cooling.py) acts as
        # an additional sink directly on the coolant node.
        q_carried_mw += max(extra_heat_removal_mw, 0.0)

        d_coolant_dt = (q_transfer_mw - q_carried_mw) / cfg.coolant_thermal_mass_mj_per_c
        coolant_temp_new = coolant_temperature_avg_c + d_coolant_dt * dt

        # Physical bound: temperatures cannot fall below absolute zero in
        # Celsius terms this model would ever plausibly encounter; guard
        # against runaway negative excursions from pathological inputs.
        fuel_temp_new = max(fuel_temp_new, -273.0)
        coolant_temp_new = max(coolant_temp_new, -273.0)

        coolant_outlet_c = 2.0 * coolant_temp_new - coolant_inlet_temperature_c

        return CoreThermalResult(
            fuel_temperature_c=fuel_temp_new,
            coolant_temperature_avg_c=coolant_temp_new,
            coolant_outlet_temperature_c=coolant_outlet_c,
            heat_to_coolant_mw=q_transfer_mw,
        )
