"""
AUREOM CORE
=============

Advanced Unified Reactor Operations & Engineering Model.

A synthetic, reduced-order digital-twin simulation platform for a large
(~1,000-1,600 MWe class) light-water nuclear generating station. See
README.md for the full architecture description and safety disclaimer.

This is a simulation and software-engineering research platform. It is
NOT a reactor design tool, a certified safety-analysis package, or an
operational control system, and none of its parameters represent any
real facility.

Internally every module uses flat, top-level imports (``from config
import ...``, ``from core.reactor_core import ...``) so that the
package also runs directly as a script collection from within its own
directory (``python main.py``). To make ``import aureom_core`` work the
same way from an external working directory, this file adds the
package's own directory to ``sys.path`` before importing the public API.
"""

from __future__ import annotations

import os
import sys

_PACKAGE_DIR = os.path.dirname(os.path.abspath(__file__))
if _PACKAGE_DIR not in sys.path:
    sys.path.insert(0, _PACKAGE_DIR)

import scenarios  # noqa: F401,E402 - registers the built-in scenario library
from config import PlantConfig, default_large_reactor_config  # noqa: E402
from plant.power_station import NuclearPowerStation, PowerStationUnit, ReactorSimulation  # noqa: E402
from simulation.scenario import available_scenarios  # noqa: E402

__version__ = "1.0.0"

__all__ = [
    "NuclearPowerStation",
    "PowerStationUnit",
    "ReactorSimulation",
    "PlantConfig",
    "default_large_reactor_config",
    "available_scenarios",
]
