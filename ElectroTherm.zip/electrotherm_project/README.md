# ElectroTherm

**A Python electro-thermal conductor simulator and optimisation engine.**

ElectroTherm is a digital laboratory for electro-thermal engineering: it
simulates how electrical current, resistance, voltage, heat generation
and thermal dissipation interact over time in conductors, cables,
busbars and PCB traces, and it optimises conductor geometry and
operating conditions against engineering constraints.

The core principle: **electricity and temperature are not separate
problems.** ElectroTherm solves the feedback loop between them directly:

```
Electrical Current
       |
       v
   Resistance
       |
       v
 Joule Heating
       |
       v
  Temperature
       |
       v
Material Properties
       |
       v
   Resistance
       ^
       (loop closes)
```

> **This is a simulation and design-exploration tool, not a certified
> protection system.** Every number ElectroTherm produces is the output
> of a numerical model built on the assumptions you supply (material
> properties, geometry, thermal environment). Results require
> independent engineering validation before use in a safety-critical,
> certified, or otherwise real-world load-bearing design.

---

## Install

```bash
pip install -e .                 # core engine
pip install -e ".[accel]"        # + numba acceleration
pip install -e ".[dev]"          # + pytest/httpx for running the test suite
```

Requires Python 3.10+ (developed against 3.11/3.13). Core dependencies:
NumPy, SciPy, Polars, Pydantic v2, Matplotlib, Plotly, FastAPI.

## Quickstart

```python
from electrotherm.geometry import WireGeometry
from electrotherm.materials import COPPER
from electrotherm.thermal import ThermalEnvironment, CoolingType
from electrotherm.simulation.coupled import solve_steady_state

geometry = WireGeometry(diameter=0.0032, length=4.0)   # 3.2mm dia, 4m
environment = ThermalEnvironment(
    ambient_temperature=298.15,               # kelvin (25 degC)
    cooling_type=CoolingType.STILL_AIR,
)

result = solve_steady_state(
    geometry=geometry, material=COPPER, environment=environment, current=60.0,
)

print(result.max_temperature_c, "degC")
print(result.power_loss_w, "W")
print(result.severity)   # NORMAL / WARNING / THERMAL_LIMIT / CRITICAL
```

See `examples/demo.py` for an end-to-end tour (steady state, transient,
pulsed loads, spatial hot spots, the design optimiser, parameter
sweeps, the what-if engine, energy/cost analysis, and the persistent
digital-conductor model), and `examples/benchmark_accelerator.py` for
solver performance benchmarks.

```bash
python examples/demo.py
python examples/benchmark_accelerator.py
pytest electrotherm/tests -q
uvicorn electrotherm.api.main:app --reload   # http://127.0.0.1:8000/docs
```

## Architecture

```
                    ELECTROTHERM
                         |
          +--------------+--------------+
          v              v              v
      MATERIAL       GEOMETRY          LOAD
          |              |              |
          +--------------+--------------+
                         |
                  ELECTRICAL SOLVER
                         |
                   JOULE HEATING
                         |
                   THERMAL SOLVER
                         |
                  COUPLED STATE
                         |
          +--------------+--------------+
          v              v              v
      VISUALISE      OPTIMISE       ANALYSE
```

```
electrotherm/
  core/
    models/          Pydantic base model (ETBaseModel), severity enum
    units/            SI unit helpers, physical constants
    configuration/    SolverConfig (tolerances, ODE method, numba on/off, ...)
  materials/          Material engine: rho(T), k(T), cp(T); Cu/Al/Ag/Au/Ni/steel
  geometry/            Wire, rod, busbar, strip, PCB trace, cable, custom
  electrical/          Ohm's law, load profiles (constant/variable/pulsed)
  thermal/             Convection correlations, radiation, ThermalEnvironment
  numerical/           Vectorised NumPy + optional Numba coupled-RHS kernels
  simulation/          Spatial model, coupled solver, DigitalConductor,
                       failure/severity, energy analysis, what-if engine
  optimisation/        Parameter sweeps, scipy-based conductor optimiser,
                       design optimiser (smallest-conductor sizing)
  visualisation/        Matplotlib/Plotly plots, ASCII "cold -> hot" bar
  api/                  FastAPI service (POST /simulate, /optimise, /sweep, ...)
  tests/                Unit, analytical-benchmark, convergence and API tests
```

Every module in `simulation`/`optimisation` calls into `numerical` through
a small, stable, array-in/array-out function signature
(`electrotherm.numerical.coupled_rhs` and friends). That boundary is
deliberate: the same kernels could be reimplemented in Rust/C++ (via
PyO3/pybind11) later without touching any calling code above it.

## Physics model

**Electrical (DC):** `V = IR`, `P = VI = I^2R = V^2/R`. Constant-current,
constant-voltage (current resolved self-consistently from `V/R(T)` each
step), arbitrary time-varying, and pulsed/multi-step loads are all
supported (`electrotherm.electrical`).

**Material properties** are temperature-dependent, not constant:

```
rho(T)  = rho0 * [1 + alpha*(T - T0)]      resistivity
k(T)    = k0   * [1 + beta*(T - T0)]        thermal conductivity
cp(T)   = cp0  * [1 + gamma*(T - T0)]       specific heat
```

**Thermal:** convective loss uses the Churchill-Chu (natural) and
Churchill-Bernstein (forced) correlations for a cylinder/hydraulic-
diameter characteristic length; radiative loss is
`eps * sigma * A * (Ts^4 - Tamb^4)`; axial conduction between spatial
cells is `k*A/dx * dT`. Contact resistance and heat-sink thermal
resistance are supported as additional series/parallel terms in
`ThermalEnvironment`.

**Coupled solve:** steady state solves `dT/dt = 0` (i.e. Joule heating =
convective + radiative loss - axial conduction) with
`scipy.optimize.root`, seeded from a closed-form equilibrium estimate for
robustness across the whole design space (including badly undersized,
"obviously infeasible" conductors, which the design optimiser
deliberately probes while bisecting). Transient solves integrate the
same right-hand side with `scipy.integrate.solve_ivp` (implicit BDF by
default, since the `T^4` radiation term can make the system stiff).

**Spatial model:** the conductor is discretised into axial cells (1D,
appropriate for long slender conductors — wires, cables, busbars, PCB
traces). Per-cell resistance/ambient/convection multipliers let you
model hot spots, uneven cooling, and localised damage/corrosion
directly. See `examples/benchmark_accelerator.py`'s module docstring
for how a future 2D/3D conduction solver would slot in behind the same
kernel API.

## Validation

`electrotherm/tests/test_coupled_solver.py` benchmarks the coupled
solver against closed-form analytical solutions of the lumped-capacitance
model (temperature-independent resistivity, no radiation):

- Ohmic resistance (`R = rho*L/A`) and Joule heating (`P = I^2R`)
- steady-state temperature `T_ss = Tamb + I^2R/(hA)`
- transient exponential approach `T(t) = T_ss + (T0-T_ss)*exp(-t/tau)`
- energy conservation (integrated dissipated energy vs. `P*t`, and
  steady-state Joule power vs. convective loss)
- convergence with tightened ODE tolerance and with spatial resolution
  (a uniform conductor must give the same answer at 1 and 8 cells)
- determinism (identical inputs -> bit-identical outputs)

`electrotherm/tests/test_failure_and_spatial.py`,
`test_pulsed_load.py`, `test_optimisation_and_sweep.py` and
`test_whatif_energy_conductor.py` cover severity classification, hot
spots, pulsed/cumulative heating, the design and general optimisers,
sweeps, what-if scenarios, energy analysis, and digital-conductor
save/load round-tripping. `test_api.py` exercises the FastAPI layer
with `TestClient`. Run everything with:

```bash
pytest electrotherm/tests -q
```

## Known limitations / scope

- The spatial model is 1D-axial; it does not resolve cross-sectional
  (radial) temperature gradients within a single conductor. For most
  wire/cable/busbar/trace geometries this is the physically appropriate
  reduction, since the cross-section is thin relative to axial
  conduction lengths.
- Convection coefficients come from standard engineering correlations
  (Churchill-Chu / Churchill-Bernstein) with simplified air-property
  fits; liquid-cooling and heat-sink paths use representative
  placeholder coefficients unless you supply a validated
  `fixed_convection_coefficient`.
- The dense-Jacobian steady-state solve scales worse than linearly with
  cell count (see the benchmark script); very fine 1D meshes (>~500
  cells) are better served by a future sparse/Newton-Krylov solve behind
  the same `numerical` kernel API.
- Materials, correlations and cost figures in the built-in library are
  typical engineering-handbook values for simulation convenience, not
  certified datasheet values.

## License

MIT.
