"""
ElectroTherm end-to-end demo.

Run with:

    python examples/demo.py

Walks through the main engine capabilities: steady state, transient,
a pulsed load, spatial hot-spot modelling, the design optimiser, a
parameter sweep / performance map, a what-if comparison, energy/cost
analysis, and the digital-conductor persistence layer.

Conductor sizes below are chosen so the demo currents sit in a
plausible operating range for each geometry -- they illustrate the
engine, not a validated real-world design.
"""

from __future__ import annotations

import numpy as np

from electrotherm.electrical import PulsedCurrent
from electrotherm.geometry import BusbarGeometry, WireGeometry
from electrotherm.materials import COPPER, ALUMINIUM
from electrotherm.optimisation.design import smallest_wire_for_current
from electrotherm.optimisation.sweep import parameter_sweep, performance_map
from electrotherm.simulation.coupled import solve_steady_state, solve_transient
from electrotherm.simulation.conductor import DigitalConductor
from electrotherm.simulation.energy import analyse_steady_state_energy
from electrotherm.simulation.whatif import make_common_scenarios, run_whatif
from electrotherm.thermal import ThermalEnvironment, CoolingType
from electrotherm.visualisation import ascii_conductor_bar


def section(title: str) -> None:
    print("\n" + "=" * 70)
    print(title)
    print("=" * 70)


def main() -> None:
    environment = ThermalEnvironment(
        ambient_temperature=298.15, cooling_type=CoolingType.FORCED_AIR, air_velocity=2.0,
    )

    # A slender hook-up wire for the low-current sections, and two
    # copper busbars sized for the higher-current sections below.
    wire = WireGeometry(diameter=0.0032, length=4.0)            # 3.2mm dia, 4m
    perf_bar = BusbarGeometry(width=0.020, thickness=0.004, length=2.0)   # 20x4mm, 2m
    pulse_bar = BusbarGeometry(width=0.050, thickness=0.010, length=2.0)  # 50x10mm, 2m

    section("1) Steady state: 3.2mm copper wire carrying 60 A, forced air (2 m/s)")
    result = solve_steady_state(geometry=wire, material=COPPER, environment=environment, current=60.0)
    print(f"  current      : {result.current_a:.2f} A")
    print(f"  voltage drop : {result.voltage_v:.4f} V")
    print(f"  resistance   : {result.total_resistance_ohm * 1e3:.4f} mOhm")
    print(f"  power loss   : {result.power_loss_w:.2f} W")
    print(f"  temperature  : {result.max_temperature_c:.1f} degC")
    print(f"  severity     : {result.severity.value}")
    print(ascii_conductor_bar([result.max_temperature_c], t_cold_c=25, t_hot_c=150))

    section("2) Transient: same wire, step from 0 to 90 A")
    t_eval = np.linspace(0, 600, 60)
    transient = solve_transient(
        geometry=wire, material=COPPER, environment=environment, current=90.0,
        t_span=(0, 600), t_eval=t_eval,
    )
    print(f"  final temperature : {transient.final_max_temperature_c():.1f} degC")
    print(f"  reached steady?    : {transient.reached_steady_state}")
    print(f"  energy dissipated  : {transient.energy_dissipated_j() / 1000:.2f} kJ")

    section("3) Pulsed load on a 50x10mm busbar: 0 -> 500 A -> 1000 A -> 500 A -> 0 (cyclic)")
    pulse = PulsedCurrent(amplitude=1000.0, baseline=50.0, period=8.0, duty_cycle=0.5)
    pulsed_result = solve_transient(
        geometry=pulse_bar, material=COPPER, environment=environment, load_profile=pulse,
        t_span=(0, 120), t_eval=np.linspace(0, 120, 240),
    )
    print(f"  peak temperature over window: {pulsed_result.max_temperature_k() - 273.15:.1f} degC")

    section("4) Spatial hot spot: same busbar at 400 A, 8-cell model, local damage in cell 4")
    damage = [1.0, 1.0, 1.0, 2.5, 1.0, 1.0, 1.0, 1.0]
    hotspot = solve_steady_state(
        geometry=pulse_bar, material=COPPER, environment=environment, current=400.0,
        num_cells=8, local_resistance_multiplier=damage,
    )
    temps_c = [t - 273.15 for t in hotspot.cell_temperatures_k]
    print("  per-cell temperature (degC):", [f"{t:.1f}" for t in temps_c])
    print(ascii_conductor_bar(temps_c))

    section("5) Design optimiser: smallest wire for 500 A, <= 90 degC")
    design = smallest_wire_for_current(
        material=COPPER, current_a=500.0, length_m=10.0, environment=environment,
        max_temperature_c=90.0,
    )
    print(f"  material     : {design.material}")
    print(f"  area         : {design.area_mm2:.1f} mm^2")
    print(f"  diameter     : {design.diameter_mm:.2f} mm")
    print(f"  temperature  : {design.temperature_c:.1f} degC")
    print(f"  voltage drop : {design.voltage_drop_v:.3f} V")
    print(f"  power loss   : {design.power_loss_w:.1f} W")
    print(f"  mass         : {design.mass_kg:.2f} kg")
    print(f"  {design.notes}")

    section("6) Parameter sweep on the 20x4mm busbar: current vs temperature performance map")
    def case_builder(params):
        return dict(geometry=perf_bar, material=COPPER, environment=environment, current=params["current_a"])

    df = parameter_sweep(case_builder, {"current_a": [100.0, 200.0, 300.0, 400.0]}, engine="serial")
    pm = performance_map(df, "current_a", "max_temperature_c")
    for row in pm.iter_rows(named=True):
        print(f"  {row['current_a']:.0f} A -> {row['max_temperature_c']:.1f} degC")

    section("7) What-if engine (20x4mm busbar at 150 A)")
    scenarios = make_common_scenarios(150.0, environment, COPPER, perf_bar, alternate_material=ALUMINIUM)
    whatif_df = run_whatif(perf_bar, COPPER, environment, 150.0, scenarios)
    print(whatif_df.select(["scenario", "max_temperature_c", "delta_max_temperature_c", "severity"]))

    section("8) Energy / economic loss analysis (section 1 result)")
    energy = analyse_steady_state_energy(result, electricity_price_per_kwh=0.18)
    print(f"  power loss        : {energy.power_loss_w:.2f} W")
    print(f"  energy / day      : {energy.energy_per_day_kwh:.3f} kWh")
    print(f"  energy / year     : {energy.energy_per_year_kwh:.1f} kWh")
    print(f"  cost / year       : ${energy.cost_per_year:.2f}")

    section("9) Digital conductor: persistent, reproducible twin")
    conductor = DigitalConductor(name="feeder-A1", material=COPPER, geometry=wire, default_environment=environment)
    conductor.run_steady_state(current=60.0)
    conductor.run_transient(t_span=(0, 300), current=90.0)
    conductor.save("digital_conductor_demo.json")
    reloaded = DigitalConductor.load("digital_conductor_demo.json")
    print(f"  saved & reloaded conductor id={reloaded.id}, history entries={len(reloaded.simulation_history)}")

    print("\nDone. All results above are numerical-model outputs and require")
    print("independent engineering validation before use in a real design.")


if __name__ == "__main__":
    main()
