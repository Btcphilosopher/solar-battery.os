"""
ElectroTherm accelerator benchmark.

Measures how the coupled solver scales with spatial resolution
(number of axial cells: our 1D spatial model), with and without the
Numba-accelerated kernel, and benchmarks a parallel parameter sweep
against a serial one.

Run with:

    python examples/benchmark_accelerator.py

Notes on dimensionality
------------------------
ElectroTherm's spatial model discretises a conductor **axially** (1D):
this is the physically appropriate reduction for long, slender
conductors (wires, cables, busbars, PCB traces) where cross-sectional
temperature gradients are negligible compared to axial ones. The
"benchmark 1D/2D/3D" request in the original brief is interpreted here
as: benchmark how the 1D axial solver scales with resolution (a stand
-in for what would be the node count in a higher-dimensional FEM mesh),
since the same vectorised-kernel API in
:mod:`electrotherm.numerical` is deliberately structured so a future
2D (cross-section) or 3D (full-volume) conduction solver -- e.g. for
busbar stacks or connector blocks where cross-sectional gradients do
matter -- can be dropped in behind it without changing the solver's
public interface (or requiring the Python callers, like `simulation`
and `optimisation`, to change at all).
"""

from __future__ import annotations

import time

import numpy as np

from electrotherm.core.configuration import SolverConfig
from electrotherm.geometry import WireGeometry
from electrotherm.materials import COPPER
from electrotherm.numerical import numba_available
from electrotherm.optimisation.sweep import parameter_sweep
from electrotherm.simulation.coupled import solve_steady_state, solve_transient
from electrotherm.thermal import ThermalEnvironment


def timeit(fn, *args, repeats: int = 3, **kwargs) -> float:
    best = float("inf")
    for _ in range(repeats):
        t0 = time.perf_counter()
        fn(*args, **kwargs)
        best = min(best, time.perf_counter() - t0)
    return best


def main() -> None:
    print(f"numba available: {numba_available()}\n")

    geometry = WireGeometry(diameter=0.006, length=5.0)
    environment = ThermalEnvironment(ambient_temperature=298.15, fixed_convection_coefficient=15.0)

    print("Steady-state solve time vs. number of spatial cells:")
    for n in (1, 10, 50, 200, 1000):
        t = timeit(
            solve_steady_state, geometry=geometry, material=COPPER, environment=environment,
            current=80.0, num_cells=n, repeats=3,
        )
        print(f"  num_cells={n:5d} -> {t * 1e3:8.2f} ms")

    print("\nTransient solve time vs. number of spatial cells (60s window, 60 points):")
    t_eval = np.linspace(0, 60, 60)
    for n in (1, 10, 50, 200):
        t = timeit(
            solve_transient, geometry=geometry, material=COPPER, environment=environment,
            current=80.0, t_span=(0, 60), t_eval=t_eval, num_cells=n, repeats=3,
        )
        print(f"  num_cells={n:5d} -> {t * 1e3:8.2f} ms")

    print("\nNumba on vs. off (steady state, 200 cells):")
    for use_numba in (True, False):
        cfg = SolverConfig(use_numba=use_numba)
        t = timeit(
            solve_steady_state, geometry=geometry, material=COPPER, environment=environment,
            current=80.0, num_cells=200, config=cfg, repeats=5,
        )
        print(f"  use_numba={use_numba!s:5s} -> {t * 1e3:8.2f} ms")

    print("\nParameter sweep: serial vs. threaded (400 steady-state cases):")
    def case_builder(params):
        return dict(geometry=geometry, material=COPPER, environment=environment, current=params["current_a"])

    currents = list(np.linspace(10, 400, 400))
    for engine in ("serial", "thread"):
        t0 = time.perf_counter()
        parameter_sweep(case_builder, {"current_a": currents}, engine=engine)
        dt = time.perf_counter() - t0
        print(f"  engine={engine:7s} -> {dt * 1e3:8.1f} ms total ({dt / len(currents) * 1e3:.3f} ms/case)")


if __name__ == "__main__":
    main()
