"""
electrotherm.simulation.coupled
=================================

The coupled electro-thermal solver: the core of ElectroTherm.

At every evaluation, the feedback loop

    Temperature -> Material Properties -> Resistance -> Electrical Power
        -> Heat Generation -> Thermal Solver -> New Temperature

is resolved self-consistently:

- **Steady state**: the equilibrium temperature vector that makes the
  net heat balance (Joule heating - convection - radiation +
  conduction) zero in every cell is found with
  ``scipy.optimize.root``.
- **Transient**: the coupled ODE system ``dT/dt = f(T, t)`` is
  integrated with ``scipy.integrate.solve_ivp`` (implicit BDF by
  default, since the T^4 radiation term and fast electrical time
  constants relative to thermal ones can make the system stiff).

Both modes support constant-current, constant-voltage and arbitrary
time-varying (:class:`~electrotherm.electrical.LoadProfile`) excitation.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Literal

import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import root

from electrotherm.core.configuration import SolverConfig, get_config
from electrotherm.core.units import STEFAN_BOLTZMANN
from electrotherm.electrical import LoadProfile
from electrotherm.geometry import ConductorGeometry
from electrotherm.materials import Material
from electrotherm.numerical import resistivity_array, axial_conduction_array
from electrotherm.simulation.failure import classify_severity
from electrotherm.simulation.results import SteadyStateResult, TransientResult
from electrotherm.simulation.spatial import SpatialModel
from electrotherm.thermal import ThermalEnvironment

ExcitationMode = Literal["current", "voltage", "profile"]


def characteristic_length(geometry: ConductorGeometry) -> float:
    """Characteristic length (m) used by the convection correlations.

    Circular geometries use their diameter; everything else uses the
    hydraulic diameter ``4*A/perimeter``.
    """
    for attr in ("diameter", "outer_diameter"):
        if hasattr(geometry, attr):
            return float(getattr(geometry, attr))
    area = geometry.cross_sectional_area()
    perim = geometry.perimeter()
    return 4.0 * area / perim if perim > 0 else math.sqrt(max(area, 1e-12))


@dataclass
class _CellPhysics:
    dTdt: np.ndarray
    R_array: np.ndarray
    R_total: float
    P_array: np.ndarray
    current: float
    ambient_array: np.ndarray


def _cell_physics(
    spatial: SpatialModel,
    environment: ThermalEnvironment,
    T: np.ndarray,
    mode: ExcitationMode,
    current_value: float | None,
    voltage_value: float | None,
    load_profile: LoadProfile | None,
    t: float,
    static: dict,
    eps: np.ndarray,
    char_len: float,
) -> _CellPhysics:
    mat = spatial.material
    lengths = static["lengths"]
    areas = static["areas"]
    surface_areas = static["surface_areas"]
    masses = static["masses"]
    dx = static["dx"]
    r_mult = static["resistance_multiplier"]
    amb_off = static["ambient_offset"]
    conv_mult = static["convection_multiplier"]

    rho = resistivity_array(T, mat.resistivity_ref, mat.temp_coefficient_resistance, mat.reference_temperature)
    R_array = rho * lengths / areas * r_mult
    R_total = float(np.sum(R_array))

    if mode == "current":
        current = float(current_value)
    elif mode == "voltage":
        current = float(voltage_value) / R_total
    else:  # profile
        current = load_profile.current_at(t)

    P_array = current ** 2 * R_array

    ambient_array = environment.ambient_temperature + amb_off
    h_array = environment.convection_coefficient_array(T, char_len) * conv_mult
    Q_conv = h_array * surface_areas * (T - ambient_array)
    Q_rad = eps * STEFAN_BOLTZMANN * surface_areas * (T ** 4 - ambient_array ** 4)

    # Linear temperature coefficients are only physically valid near the
    # reference point; floor thermal conductivity and specific heat at a
    # small positive value so a solver iterate that overshoots to an
    # extreme temperature can't drive either property negative and
    # destabilise the root-find / integration.
    if spatial.num_cells > 1:
        dt_ref = T - mat.reference_temperature
        k_array = np.maximum(
            mat.thermal_conductivity_ref * (1.0 + mat.thermal_conductivity_temp_coeff * dt_ref), 1e-6
        )
        cross_area = spatial.cross_sectional_area()
        Q_cond = axial_conduction_array(T, k_array, cross_area, dx)
    else:
        Q_cond = np.zeros_like(T)

    dt_ref = T - mat.reference_temperature
    cp_array = np.maximum(
        mat.specific_heat_ref * (1.0 + mat.specific_heat_temp_coeff * dt_ref), 1.0
    )
    thermal_mass = masses * cp_array

    dTdt = (P_array - Q_conv - Q_rad + Q_cond) / thermal_mass

    return _CellPhysics(dTdt, R_array, R_total, P_array, current, ambient_array)


def _prep(spatial: SpatialModel, environment: ThermalEnvironment) -> tuple[dict, np.ndarray, float]:
    static = spatial.build_static_arrays()
    eps = spatial.emissivity_array(environment)
    char_len = characteristic_length(spatial.geometry)
    return static, eps, char_len


def _estimate_initial_temperature(
    spatial: SpatialModel,
    environment: ThermalEnvironment,
    mode: ExcitationMode,
    current_value: float | None,
    voltage_value: float | None,
    static: dict,
    char_len: float,
) -> float:
    """A closed-form (no iteration beyond two fixed-point refinements)
    estimate of the equilibrium temperature, used to seed the
    Newton-type steady-state root-find.

    ``root()`` with a naive ``ambient + 10 K`` starting guess can fail
    to converge (or converge to a spurious point) whenever the true
    equilibrium is far from ambient -- e.g. a badly undersized
    conductor under heavy current, where the real steady state may be
    hundreds or thousands of kelvin above ambient. Estimating that
    scale up front dramatically improves solver robustness across the
    whole design space (including "obviously infeasible" cases that
    :func:`~electrotherm.optimisation.design.smallest_wire_for_current`
    deliberately probes while bisecting).
    """
    mat = spatial.material
    lengths, areas, r_mult = static["lengths"], static["areas"], static["resistance_multiplier"]
    ambient = environment.ambient_temperature

    def resistance_at(t_k: float) -> float:
        rho = max(mat.resistivity_ref * (1.0 + mat.temp_coefficient_resistance * (t_k - mat.reference_temperature)), 1e-16)
        return float(np.sum(rho * lengths / areas * r_mult))

    r_ambient = resistance_at(ambient)
    if mode == "current":
        power_est = current_value ** 2 * r_ambient
    else:
        power_est = voltage_value ** 2 / r_ambient

    surface_total = float(np.sum(static["surface_areas"]))
    t_guess = ambient
    for _ in range(3):
        h = float(environment.convection_coefficient(t_guess, char_len))
        dT = power_est / max(h * surface_total, 1e-6)
        t_guess = ambient + dT
    return t_guess


# ---------------------------------------------------------------------------
# Steady-state solver
# ---------------------------------------------------------------------------

def solve_steady_state(
    geometry: ConductorGeometry,
    material: Material,
    environment: ThermalEnvironment,
    current: float | None = None,
    voltage: float | None = None,
    num_cells: int | None = None,
    initial_temperature_k: float | None = None,
    local_resistance_multiplier: list[float] | None = None,
    local_ambient_offset_k: list[float] | None = None,
    local_convection_multiplier: list[float] | None = None,
    config: SolverConfig | None = None,
) -> SteadyStateResult:
    """Solve for the equilibrium (dT/dt = 0) temperature distribution.

    Exactly one of ``current`` or ``voltage`` must be supplied.
    """
    if (current is None) == (voltage is None):
        raise ValueError("Provide exactly one of `current` or `voltage`")

    cfg = config or get_config()
    n = num_cells or cfg.default_num_cells
    spatial = SpatialModel(
        geometry=geometry, material=material, num_cells=n,
        local_resistance_multiplier=local_resistance_multiplier,
        local_ambient_offset_k=local_ambient_offset_k,
        local_convection_multiplier=local_convection_multiplier,
    )
    static, eps, char_len = _prep(spatial, environment)
    mode: ExcitationMode = "current" if current is not None else "voltage"

    if initial_temperature_k is not None:
        t0_guess = initial_temperature_k
    else:
        t0_guess = _estimate_initial_temperature(spatial, environment, mode, current, voltage, static, char_len)
    T0 = np.full(n, t0_guess)

    def residual(T: np.ndarray) -> np.ndarray:
        phys = _cell_physics(spatial, environment, T, mode, current, voltage, None, 0.0, static, eps, char_len)
        return phys.dTdt

    sol = root(residual, T0, method="hybr", tol=cfg.steady_state_tol_k,
               options={"maxfev": cfg.steady_state_max_iter * (n + 1)})

    T_final = sol.x
    phys = _cell_physics(spatial, environment, T_final, mode, current, voltage, None, 0.0, static, eps, char_len)

    area = spatial.cross_sectional_area()
    avg_j = phys.current / area
    max_j = avg_j  # uniform cross-section along length in this model

    severity = classify_severity(float(np.max(T_final)), material.max_operating_temperature, material.melting_point)

    return SteadyStateResult(
        converged=bool(sol.success),
        iterations=int(getattr(sol, "nfev", 0)),
        current_a=phys.current,
        voltage_v=phys.current * phys.R_total,
        total_resistance_ohm=phys.R_total,
        power_loss_w=float(np.sum(phys.P_array)),
        cell_temperatures_k=[float(x) for x in T_final],
        ambient_temperature_k=environment.ambient_temperature,
        mass_kg=geometry.mass(material),
        avg_current_density_a_m2=avg_j,
        max_current_density_a_m2=max_j,
        severity=severity,
        notes="" if sol.success else f"Solver did not fully converge: {sol.message}",
    )


# ---------------------------------------------------------------------------
# Transient solver
# ---------------------------------------------------------------------------

def solve_transient(
    geometry: ConductorGeometry,
    material: Material,
    environment: ThermalEnvironment,
    t_span: tuple[float, float],
    current: float | None = None,
    voltage: float | None = None,
    load_profile: LoadProfile | None = None,
    t_eval: np.ndarray | None = None,
    num_cells: int | None = None,
    initial_temperature_k: float | None = None,
    local_resistance_multiplier: list[float] | None = None,
    local_ambient_offset_k: list[float] | None = None,
    local_convection_multiplier: list[float] | None = None,
    config: SolverConfig | None = None,
) -> TransientResult:
    """Integrate the coupled electro-thermal ODE system over ``t_span``.

    Exactly one excitation must be supplied: ``current`` (constant),
    ``voltage`` (constant, current resolved self-consistently each
    step from V/R(T)), or ``load_profile`` (arbitrary I(t), including
    pulsed/time-varying loads).
    """
    n_sources = sum(x is not None for x in (current, voltage, load_profile))
    if n_sources != 1:
        raise ValueError("Provide exactly one of `current`, `voltage`, or `load_profile`")

    cfg = config or get_config()
    n = num_cells or cfg.default_num_cells
    spatial = SpatialModel(
        geometry=geometry, material=material, num_cells=n,
        local_resistance_multiplier=local_resistance_multiplier,
        local_ambient_offset_k=local_ambient_offset_k,
        local_convection_multiplier=local_convection_multiplier,
    )
    static, eps, char_len = _prep(spatial, environment)

    if current is not None:
        mode: ExcitationMode = "current"
    elif voltage is not None:
        mode = "voltage"
    else:
        mode = "profile"

    T0 = np.full(n, initial_temperature_k or environment.ambient_temperature)

    def rhs(t: float, T: np.ndarray) -> np.ndarray:
        phys = _cell_physics(spatial, environment, T, mode, current, voltage, load_profile, t, static, eps, char_len)
        return phys.dTdt

    sol = solve_ivp(
        rhs, t_span, T0, method=cfg.ode_method, t_eval=t_eval,
        rtol=cfg.rtol, atol=cfg.atol, max_step=cfg.max_step or np.inf,
        dense_output=False,
    )
    if not sol.success:
        raise RuntimeError(f"Transient solve failed: {sol.message}")

    temperatures: list[list[float]] = []
    currents: list[float] = []
    voltages: list[float] = []
    resistances: list[float] = []
    powers: list[float] = []

    for i, t in enumerate(sol.t):
        T = sol.y[:, i]
        phys = _cell_physics(spatial, environment, T, mode, current, voltage, load_profile, float(t), static, eps, char_len)
        temperatures.append([float(x) for x in T])
        currents.append(phys.current)
        voltages.append(phys.current * phys.R_total)
        resistances.append(phys.R_total)
        powers.append(float(np.sum(phys.P_array)))

    reached_steady = False
    if len(temperatures) >= 2:
        dt = sol.t[-1] - sol.t[-2]
        if dt > 0:
            last_rate = max(abs(a - b) for a, b in zip(temperatures[-1], temperatures[-2])) / dt
            reached_steady = last_rate < 1e-3

    return TransientResult(
        times_s=[float(t) for t in sol.t],
        temperatures_k=temperatures,
        currents_a=currents,
        voltages_v=voltages,
        total_resistance_ohm=resistances,
        power_loss_w=powers,
        ambient_temperature_k=environment.ambient_temperature,
        mass_kg=geometry.mass(material),
        reached_steady_state=reached_steady,
    )


__all__ = ["solve_steady_state", "solve_transient", "characteristic_length"]
