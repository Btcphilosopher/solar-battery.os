"""
electrotherm.simulation.spatial
=================================

Spatial discretisation of a conductor into axial computational cells,
so temperature, resistance and current density can be resolved
independently along the conductor's length.

    ┌───┬───┬───┬───┬───┐
    │ T │ T │ T │ T │ T │
    └───┴───┴───┴───┴───┘
      1   2   3   4   5

Cells are connected in series electrically (same current flows through
each) and thermally by axial conduction between neighbours. Optional
per-cell multipliers allow simulation of hot spots, uneven cooling and
localised damage (see :mod:`electrotherm.simulation.failure`).
"""

from __future__ import annotations

import numpy as np
from pydantic import Field, model_validator

from electrotherm.core.models import ETBaseModel
from electrotherm.geometry import AnyGeometry, ConductorGeometry
from electrotherm.materials import Material
from electrotherm.thermal import ThermalEnvironment


class SpatialModel(ETBaseModel):
    """Divides a conductor into ``num_cells`` equal-length axial cells."""

    geometry: AnyGeometry
    material: Material
    num_cells: int = Field(default=1, ge=1)

    #: per-cell resistance multiplier (>1 simulates local damage/corrosion)
    local_resistance_multiplier: list[float] | None = None
    #: per-cell ambient temperature offset, K (simulates uneven cooling /
    #: a hot spot next to another heat source)
    local_ambient_offset_k: list[float] | None = None
    #: per-cell convection-coefficient multiplier (<1 simulates blocked
    #: airflow / poor local cooling, e.g. bundled cables)
    local_convection_multiplier: list[float] | None = None

    @model_validator(mode="after")
    def _check_modifier_lengths(self) -> "SpatialModel":
        for name in (
            "local_resistance_multiplier",
            "local_ambient_offset_k",
            "local_convection_multiplier",
        ):
            values = getattr(self, name)
            if values is not None and len(values) != self.num_cells:
                raise ValueError(f"{name} must have length num_cells ({self.num_cells})")
        return self

    @property
    def cell_length(self) -> float:
        return self.geometry.length / self.num_cells

    def cell_geometry(self, index: int) -> ConductorGeometry:
        return self.geometry.sub_length_geometry(self.cell_length)

    def resistance_multipliers(self) -> np.ndarray:
        if self.local_resistance_multiplier is not None:
            return np.array(self.local_resistance_multiplier, dtype=float)
        return np.ones(self.num_cells)

    def ambient_offsets(self) -> np.ndarray:
        if self.local_ambient_offset_k is not None:
            return np.array(self.local_ambient_offset_k, dtype=float)
        return np.zeros(self.num_cells)

    def convection_multipliers(self) -> np.ndarray:
        if self.local_convection_multiplier is not None:
            return np.array(self.local_convection_multiplier, dtype=float)
        return np.ones(self.num_cells)

    def cross_sectional_area(self) -> float:
        return self.geometry.cross_sectional_area()

    def cell_surface_area(self) -> float:
        return self.geometry.perimeter() * self.cell_length

    def cell_mass(self) -> float:
        return self.cross_sectional_area() * self.cell_length * self.material.density

    def build_static_arrays(self) -> dict[str, np.ndarray | float]:
        """Arrays that don't depend on the current temperature state."""
        n = self.num_cells
        lengths = np.full(n, self.cell_length)
        areas = np.full(n, self.cross_sectional_area())
        surface_areas = np.full(n, self.cell_surface_area())
        masses = np.full(n, self.cell_mass())
        return {
            "lengths": lengths,
            "areas": areas,
            "surface_areas": surface_areas,
            "masses": masses,
            "dx": self.cell_length,
            "resistance_multiplier": self.resistance_multipliers(),
            "ambient_offset": self.ambient_offsets(),
            "convection_multiplier": self.convection_multipliers(),
        }

    def emissivity_array(self, environment: ThermalEnvironment) -> np.ndarray:
        eps = environment.emissivity_override if environment.emissivity_override is not None else self.material.emissivity
        return np.full(self.num_cells, eps)


__all__ = ["SpatialModel"]
