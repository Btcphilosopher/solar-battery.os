"""
electrotherm.simulation.results
=================================

Result data structures returned by the electrical, thermal and coupled
solvers. All results are Pydantic models so they serialise cleanly to
JSON for the digital-conductor history, the FastAPI layer, and
parameter-sweep dataframes.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

import numpy as np
from pydantic import Field, field_validator

from electrotherm.core.models import ETBaseModel, SeverityLevel
from electrotherm.core.units import kelvin_to_celsius


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class SteadyStateResult(ETBaseModel):
    """Result of a steady-state (equilibrium) electro-thermal solve."""

    converged: bool
    iterations: int = 0
    current_a: float
    voltage_v: float
    total_resistance_ohm: float
    power_loss_w: float
    cell_temperatures_k: list[float]
    ambient_temperature_k: float
    mass_kg: float
    avg_current_density_a_m2: float
    max_current_density_a_m2: float
    severity: SeverityLevel
    timestamp: str = Field(default_factory=_now_iso)
    notes: str = ""

    @property
    def max_temperature_k(self) -> float:
        return max(self.cell_temperatures_k)

    @property
    def avg_temperature_k(self) -> float:
        return float(np.mean(self.cell_temperatures_k))

    @property
    def max_temperature_c(self) -> float:
        return kelvin_to_celsius(self.max_temperature_k)

    @property
    def avg_temperature_c(self) -> float:
        return kelvin_to_celsius(self.avg_temperature_k)

    def summary(self) -> dict[str, Any]:
        return {
            "current_a": self.current_a,
            "voltage_v": self.voltage_v,
            "resistance_ohm": self.total_resistance_ohm,
            "power_loss_w": self.power_loss_w,
            "max_temperature_c": round(self.max_temperature_c, 2),
            "avg_temperature_c": round(self.avg_temperature_c, 2),
            "severity": self.severity.value,
            "converged": self.converged,
        }


class TransientResult(ETBaseModel):
    """Result of a time-domain (transient) electro-thermal solve."""

    times_s: list[float]
    #: temperatures[i] is the per-cell temperature vector (K) at times_s[i]
    temperatures_k: list[list[float]]
    currents_a: list[float]
    voltages_v: list[float]
    total_resistance_ohm: list[float]
    power_loss_w: list[float]
    ambient_temperature_k: float
    mass_kg: float
    reached_steady_state: bool
    timestamp: str = Field(default_factory=_now_iso)
    notes: str = ""

    @field_validator("temperatures_k")
    @classmethod
    def _check_shape(cls, v: list[list[float]], info):
        return v

    def as_arrays(self) -> dict[str, np.ndarray]:
        return {
            "t": np.array(self.times_s),
            "T": np.array(self.temperatures_k),
            "I": np.array(self.currents_a),
            "V": np.array(self.voltages_v),
            "R": np.array(self.total_resistance_ohm),
            "P": np.array(self.power_loss_w),
        }

    def max_temperature_k(self) -> float:
        return float(np.max(self.temperatures_k))

    def final_max_temperature_c(self) -> float:
        return kelvin_to_celsius(float(np.max(self.temperatures_k[-1])))

    def energy_dissipated_j(self) -> float:
        """Total Joule energy dissipated over the simulated window (J),
        via trapezoidal integration of instantaneous power loss.
        """
        trapezoid = getattr(np, "trapezoid", None) or np.trapz
        return float(trapezoid(self.power_loss_w, self.times_s))

    def severity_timeline(self, max_operating_k: float, melting_k: float) -> list[SeverityLevel]:
        from electrotherm.simulation.failure import classify_severity

        return [
            classify_severity(max(cell_temps), max_operating_k, melting_k)
            for cell_temps in self.temperatures_k
        ]


__all__ = ["SteadyStateResult", "TransientResult"]
