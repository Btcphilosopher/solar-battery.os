"""
electrotherm.simulation.conductor
===================================

The "digital conductor": a persistent, reproducible model of a
physical conductor (material + geometry + default operating
environment) together with its simulation history, so engineering
scenarios can be saved, reloaded, and re-run deterministically.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from pathlib import Path

from pydantic import Field

from electrotherm.core.configuration import SolverConfig, get_config
from electrotherm.core.models import ETBaseModel
from electrotherm.electrical import LoadProfile
from electrotherm.geometry import AnyGeometry
from electrotherm.materials import Material
from electrotherm.simulation.coupled import solve_steady_state, solve_transient
from electrotherm.simulation.results import SteadyStateResult, TransientResult
from electrotherm.thermal import ThermalEnvironment, STILL_AIR


def _new_id() -> str:
    return str(uuid.uuid4())


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class DigitalConductor(ETBaseModel):
    """A persistent, reproducible digital twin of a physical conductor.

        ID
        Material
        Geometry
        Electrical / thermal properties (derived on demand)
        Operating conditions (default environment)
        Simulation history
    """

    id: str = Field(default_factory=_new_id)
    name: str = "unnamed_conductor"
    material: Material
    geometry: AnyGeometry
    default_environment: ThermalEnvironment = Field(default_factory=lambda: STILL_AIR.model_copy())
    num_cells: int = Field(default=1, ge=1)
    created_at: str = Field(default_factory=_now_iso)
    tags: list[str] = Field(default_factory=list)
    #: lightweight history of simulation summaries (JSON-safe dicts), so
    #: the whole digital conductor stays serialisable to a single file.
    simulation_history: list[dict] = Field(default_factory=list)

    # -- convenience geometry/material queries -------------------------

    def resistance_at(self, temperature_k: float) -> float:
        return self.geometry.resistance(self.material, temperature_k)

    def mass_kg(self) -> float:
        return self.geometry.mass(self.material)

    # -- simulation entry points, with automatic history logging -------

    def run_steady_state(
        self,
        current: float | None = None,
        voltage: float | None = None,
        environment: ThermalEnvironment | None = None,
        config: SolverConfig | None = None,
        **spatial_kwargs,
    ) -> SteadyStateResult:
        env = environment or self.default_environment
        result = solve_steady_state(
            geometry=self.geometry, material=self.material, environment=env,
            current=current, voltage=voltage, num_cells=self.num_cells,
            config=config or get_config(), **spatial_kwargs,
        )
        self.simulation_history.append({
            "kind": "steady_state",
            "timestamp": result.timestamp,
            **result.summary(),
        })
        return result

    def run_transient(
        self,
        t_span: tuple[float, float],
        current: float | None = None,
        voltage: float | None = None,
        load_profile: LoadProfile | None = None,
        environment: ThermalEnvironment | None = None,
        config: SolverConfig | None = None,
        **kwargs,
    ) -> TransientResult:
        env = environment or self.default_environment
        result = solve_transient(
            geometry=self.geometry, material=self.material, environment=env,
            t_span=t_span, current=current, voltage=voltage,
            load_profile=load_profile, num_cells=self.num_cells,
            config=config or get_config(), **kwargs,
        )
        self.simulation_history.append({
            "kind": "transient",
            "timestamp": result.timestamp,
            "t_span": list(t_span),
            "final_max_temperature_c": result.final_max_temperature_c(),
            "energy_dissipated_j": result.energy_dissipated_j(),
            "reached_steady_state": result.reached_steady_state,
        })
        return result

    # -- persistence -----------------------------------------------------

    def save(self, path: str | Path) -> None:
        Path(path).write_text(self.to_json())

    @classmethod
    def load(cls, path: str | Path) -> "DigitalConductor":
        return cls.model_validate_json(Path(path).read_text())


__all__ = ["DigitalConductor"]
