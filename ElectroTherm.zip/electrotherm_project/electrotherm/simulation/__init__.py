"""
electrotherm.simulation
=========================

Coupled electro-thermal simulation engine: spatial discretisation, the
steady-state/transient coupled solver, the digital-conductor
persistence model, failure/severity classification, energy analysis
and the what-if comparison engine.
"""

from electrotherm.simulation.spatial import SpatialModel
from electrotherm.simulation.results import SteadyStateResult, TransientResult
from electrotherm.simulation.coupled import solve_steady_state, solve_transient, characteristic_length
from electrotherm.simulation.conductor import DigitalConductor
from electrotherm.simulation.failure import (
    classify_severity,
    classify_material_state,
    overcurrent_scenario,
    cooling_failure_scenario,
    ambient_rise_scenario,
    contact_resistance_scenario,
    partial_damage_resistance_multiplier,
)
from electrotherm.simulation.energy import EnergyAnalysis, analyse_steady_state_energy, analyse_transient_energy
from electrotherm.simulation.whatif import Scenario, run_whatif, make_common_scenarios

__all__ = [
    "SpatialModel",
    "SteadyStateResult",
    "TransientResult",
    "solve_steady_state",
    "solve_transient",
    "characteristic_length",
    "DigitalConductor",
    "classify_severity",
    "classify_material_state",
    "overcurrent_scenario",
    "cooling_failure_scenario",
    "ambient_rise_scenario",
    "contact_resistance_scenario",
    "partial_damage_resistance_multiplier",
    "EnergyAnalysis",
    "analyse_steady_state_energy",
    "analyse_transient_energy",
    "Scenario",
    "run_whatif",
    "make_common_scenarios",
]
