"""
electrotherm.simulation.failure
=================================

Severity classification and controlled "extreme condition" scenario
helpers (overcurrent, cooling failure, ambient rise, contact
resistance degradation, localised damage).

ElectroTherm is a *simulation and design-exploration tool*. The
NORMAL/WARNING/THERMAL_LIMIT/CRITICAL labels below describe modelled
thermal risk under the assumptions supplied by the caller. They are
**not** outputs of a certified protection relay, fuse curve, or safety
system, and must not be used as the sole basis for a safety
determination.
"""

from __future__ import annotations

from electrotherm.core.models import SeverityLevel
from electrotherm.materials import Material
from electrotherm.thermal import ThermalEnvironment

#: fraction of max_operating_temperature above which a WARNING is raised
WARNING_FRACTION = 0.8


def classify_severity(temperature_k: float, max_operating_k: float, melting_k: float) -> SeverityLevel:
    """Classify a single temperature reading against material limits.

    - NORMAL: below ``WARNING_FRACTION`` of the rated max operating temp
    - WARNING: between that fraction and the rated max operating temp
    - THERMAL_LIMIT: at/above the rated max operating temp, below melting
    - CRITICAL: at/above melting point (or any physically invalid state)
    """
    if temperature_k >= melting_k:
        return SeverityLevel.CRITICAL
    if temperature_k >= max_operating_k:
        return SeverityLevel.THERMAL_LIMIT
    if temperature_k >= WARNING_FRACTION * max_operating_k:
        return SeverityLevel.WARNING
    return SeverityLevel.NORMAL


def classify_material_state(temperature_k: float, material: Material) -> SeverityLevel:
    return classify_severity(temperature_k, material.max_operating_temperature, material.melting_point)


# ---------------------------------------------------------------------------
# Extreme-condition scenario builders
#
# These are convenience factories that perturb an environment/current to
# represent common failure modes. They do not run a simulation
# themselves -- pass the returned environment/current into
# solve_steady_state / solve_transient.
# ---------------------------------------------------------------------------

def overcurrent_scenario(nominal_current_a: float, overcurrent_factor: float) -> float:
    """Return the perturbed current (A) for an overcurrent event."""
    if overcurrent_factor <= 1.0:
        raise ValueError("overcurrent_factor must be > 1.0")
    return nominal_current_a * overcurrent_factor


def cooling_failure_scenario(environment: ThermalEnvironment) -> ThermalEnvironment:
    """Return a copy of ``environment`` with convective cooling disabled
    (e.g. fan failure, blocked airflow, coolant pump failure), leaving
    only natural convection and radiation.
    """
    return environment.model_copy(
        update={
            "cooling_type": environment.cooling_type.__class__.STILL_AIR,
            "air_velocity": 0.0,
            "fixed_convection_coefficient": None,
            "heatsink_thermal_resistance": None,
        }
    )


def ambient_rise_scenario(environment: ThermalEnvironment, new_ambient_k: float) -> ThermalEnvironment:
    """Return a copy of ``environment`` with a raised ambient temperature."""
    return environment.model_copy(update={"ambient_temperature": new_ambient_k})


def contact_resistance_scenario(environment: ThermalEnvironment, added_resistance_k_m2_w: float) -> ThermalEnvironment:
    """Return a copy of ``environment`` with degraded (increased) contact
    thermal resistance, e.g. a loose/corroded connector.
    """
    return environment.model_copy(
        update={"contact_resistance": environment.contact_resistance + added_resistance_k_m2_w}
    )


def partial_damage_resistance_multiplier(damage_fraction: float) -> float:
    """Approximate local resistance multiplier for a partially-damaged
    conductor cross-section (e.g. corrosion, nicked strands).

    A conductor whose effective conducting area is reduced by
    ``damage_fraction`` (0-1) has its local resistance increased
    roughly by 1 / (1 - damage_fraction), assuming the remaining
    material still spans the full length.
    """
    if not (0.0 <= damage_fraction < 1.0):
        raise ValueError("damage_fraction must be in [0, 1)")
    return 1.0 / (1.0 - damage_fraction)


__all__ = [
    "WARNING_FRACTION",
    "classify_severity",
    "classify_material_state",
    "overcurrent_scenario",
    "cooling_failure_scenario",
    "ambient_rise_scenario",
    "contact_resistance_scenario",
    "partial_damage_resistance_multiplier",
]
