"""
electrotherm.simulation.energy
================================

Energy-loss and economic-loss analysis built on top of steady-state /
transient power-loss results.
"""

from __future__ import annotations

from electrotherm.core.models import ETBaseModel
from electrotherm.core.units import joules_to_kwh
from electrotherm.simulation.results import SteadyStateResult, TransientResult


class EnergyAnalysis(ETBaseModel):
    """Energy-loss projection derived from a steady (constant) power loss."""

    power_loss_w: float
    energy_per_hour_kwh: float
    energy_per_day_kwh: float
    energy_per_year_kwh: float
    electricity_price_per_kwh: float | None = None
    cost_per_day: float | None = None
    cost_per_year: float | None = None
    thermal_efficiency: float | None = None


def analyse_steady_state_energy(
    result: SteadyStateResult,
    electricity_price_per_kwh: float | None = None,
    useful_power_w: float | None = None,
) -> EnergyAnalysis:
    """Project a steady-state power loss into hourly/daily/annual energy
    (and, optionally, economic) losses.

    ``useful_power_w``, if given (e.g. the load power actually delivered
    downstream of the conductor), is used to report a simple thermal
    efficiency estimate = useful / (useful + loss).
    """
    p = result.power_loss_w
    kwh_hour = p / 1000.0
    kwh_day = kwh_hour * 24.0
    kwh_year = kwh_day * 365.25

    cost_day = cost_year = None
    if electricity_price_per_kwh is not None:
        cost_day = kwh_day * electricity_price_per_kwh
        cost_year = kwh_year * electricity_price_per_kwh

    efficiency = None
    if useful_power_w is not None and (useful_power_w + p) > 0:
        efficiency = useful_power_w / (useful_power_w + p)

    return EnergyAnalysis(
        power_loss_w=p,
        energy_per_hour_kwh=kwh_hour,
        energy_per_day_kwh=kwh_day,
        energy_per_year_kwh=kwh_year,
        electricity_price_per_kwh=electricity_price_per_kwh,
        cost_per_day=cost_day,
        cost_per_year=cost_year,
        thermal_efficiency=efficiency,
    )


def analyse_transient_energy(
    result: TransientResult,
    electricity_price_per_kwh: float | None = None,
) -> dict:
    """Summarise energy dissipated over a transient window and extrapolate
    to hourly/daily/annual figures using the window's time-averaged power.
    """
    energy_j = result.energy_dissipated_j()
    duration_s = result.times_s[-1] - result.times_s[0] if len(result.times_s) > 1 else 1.0
    avg_power_w = energy_j / duration_s if duration_s > 0 else 0.0
    kwh_window = joules_to_kwh(energy_j)
    kwh_hour = avg_power_w / 1000.0
    kwh_day = kwh_hour * 24.0
    kwh_year = kwh_day * 365.25
    out = {
        "energy_dissipated_j": energy_j,
        "energy_dissipated_kwh": kwh_window,
        "average_power_w": avg_power_w,
        "energy_per_hour_kwh": kwh_hour,
        "energy_per_day_kwh": kwh_day,
        "energy_per_year_kwh": kwh_year,
    }
    if electricity_price_per_kwh is not None:
        out["cost_per_day"] = kwh_day * electricity_price_per_kwh
        out["cost_per_year"] = kwh_year * electricity_price_per_kwh
    return out


__all__ = ["EnergyAnalysis", "analyse_steady_state_energy", "analyse_transient_energy"]
