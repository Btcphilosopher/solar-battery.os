"""
electrotherm.simulation.whatif
================================

The what-if engine: quantitatively compare a baseline steady-state
scenario against one or more named perturbations, e.g.

    "What if current increases 20%?"
    "What if ambient temperature rises from 25C to 40C?"
    "What if cooling fails?"
    "What if aluminium replaces copper?"
    "What if conductor area is reduced by 15%?"

Each scenario is expressed as a small dict of overrides applied on top
of the baseline inputs; the engine re-solves steady state for each and
reports the delta against baseline.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

import polars as pl

from electrotherm.core.configuration import SolverConfig
from electrotherm.geometry import ConductorGeometry
from electrotherm.materials import Material
from electrotherm.simulation.coupled import solve_steady_state
from electrotherm.simulation.results import SteadyStateResult
from electrotherm.thermal import ThermalEnvironment


@dataclass
class Scenario:
    """A named modification of the baseline inputs.

    ``overrides`` is a dict of keyword overrides accepted by
    :func:`~electrotherm.simulation.coupled.solve_steady_state`
    (``geometry``, ``material``, ``environment``, ``current``,
    ``voltage``, ``num_cells``, ...). Any key omitted falls back to the
    baseline value.
    """

    name: str
    overrides: dict[str, Any] = field(default_factory=dict)


def run_whatif(
    baseline_geometry: ConductorGeometry,
    baseline_material: Material,
    baseline_environment: ThermalEnvironment,
    baseline_current: float,
    scenarios: list[Scenario],
    num_cells: int = 1,
    config: SolverConfig | None = None,
) -> pl.DataFrame:
    """Run the baseline plus every scenario and return a comparison table."""

    base_kwargs = dict(
        geometry=baseline_geometry, material=baseline_material,
        environment=baseline_environment, current=baseline_current,
        num_cells=num_cells, config=config,
    )
    baseline_result = solve_steady_state(**base_kwargs)

    rows = [_row("baseline", baseline_result, baseline_result)]

    for scenario in scenarios:
        kwargs = dict(base_kwargs)
        kwargs.update(scenario.overrides)
        result = solve_steady_state(**kwargs)
        rows.append(_row(scenario.name, result, baseline_result))

    return pl.DataFrame(rows)


def _row(name: str, result: SteadyStateResult, baseline: SteadyStateResult) -> dict:
    return {
        "scenario": name,
        "current_a": result.current_a,
        "voltage_v": result.voltage_v,
        "resistance_ohm": result.total_resistance_ohm,
        "power_loss_w": result.power_loss_w,
        "max_temperature_c": result.max_temperature_c,
        "avg_temperature_c": result.avg_temperature_c,
        "severity": result.severity.value,
        "delta_max_temperature_c": result.max_temperature_c - baseline.max_temperature_c,
        "delta_power_loss_w": result.power_loss_w - baseline.power_loss_w,
        "converged": result.converged,
    }


# ---------------------------------------------------------------------------
# Convenience scenario builders for the common what-if questions
# ---------------------------------------------------------------------------

def make_common_scenarios(
    baseline_current: float,
    baseline_environment: ThermalEnvironment,
    baseline_material: Material,
    baseline_geometry: ConductorGeometry,
    alternate_material: Material | None = None,
) -> list[Scenario]:
    """Build a standard bundle of what-if scenarios out of the box."""
    scenarios = [
        Scenario("current +20%", {"current": baseline_current * 1.2}),
        Scenario(
            "ambient 25C -> 40C",
            {"environment": baseline_environment.model_copy(update={"ambient_temperature": 313.15})},
        ),
        Scenario(
            "cooling fails (still air only)",
            {
                "environment": baseline_environment.model_copy(
                    update={
                        "cooling_type": baseline_environment.cooling_type.__class__.STILL_AIR,
                        "air_velocity": 0.0,
                        "fixed_convection_coefficient": None,
                    }
                )
            },
        ),
        Scenario(
            "area reduced 15%",
            {"geometry": _scale_area(baseline_geometry, 0.85)},
        ),
    ]
    if alternate_material is not None:
        scenarios.insert(1, Scenario(f"material -> {alternate_material.name}", {"material": alternate_material}))
    return scenarios


def _scale_area(geometry: ConductorGeometry, factor: float) -> ConductorGeometry:
    """Return a copy of ``geometry`` with cross-sectional area scaled by
    ``factor`` (linear dimensions scaled by sqrt(factor) to preserve shape).
    """
    import math

    s = math.sqrt(factor)
    if hasattr(geometry, "diameter"):
        return geometry.model_copy(update={"diameter": geometry.diameter * s})
    if hasattr(geometry, "outer_diameter"):
        updates = {"outer_diameter": geometry.outer_diameter * s}
        if getattr(geometry, "inner_diameter", 0):
            updates["inner_diameter"] = geometry.inner_diameter * s
        return geometry.model_copy(update=updates)
    if hasattr(geometry, "width") and hasattr(geometry, "thickness"):
        return geometry.model_copy(update={"width": geometry.width * s, "thickness": geometry.thickness * s})
    if hasattr(geometry, "area_m2"):
        return geometry.model_copy(update={"area_m2": geometry.area_m2 * factor, "perimeter_m": geometry.perimeter_m * s})
    raise TypeError(f"Don't know how to scale geometry type {type(geometry)}")


__all__ = ["Scenario", "run_whatif", "make_common_scenarios"]
