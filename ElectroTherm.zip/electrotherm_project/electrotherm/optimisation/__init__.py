"""
electrotherm.optimisation
============================

Optimisation engine: parameter sweeps for performance maps, and
scipy-based conductor design optimisation (minimise mass/energy/cost
subject to thermal and electrical constraints), plus the design
optimiser for direct sizing questions ("smallest conductor that
carries X A below Y degC").
"""

from electrotherm.optimisation.sweep import parameter_sweep, performance_map, CaseBuilder
from electrotherm.optimisation.optimiser import (
    OptimisationResult,
    OptimisationConstraints,
    OptimisationWeights,
    optimise_conductor,
)
from electrotherm.optimisation.design import DesignResult, smallest_wire_for_current

__all__ = [
    "parameter_sweep",
    "performance_map",
    "CaseBuilder",
    "OptimisationResult",
    "OptimisationConstraints",
    "OptimisationWeights",
    "optimise_conductor",
    "DesignResult",
    "smallest_wire_for_current",
]
