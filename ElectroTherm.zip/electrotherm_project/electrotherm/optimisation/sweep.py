"""
electrotherm.optimisation.sweep
=================================

Parameter sweep engine: run a steady-state (or transient) simulation
across the Cartesian product of many parameter axes (material, length,
diameter, current, voltage, ambient temperature, cooling, duty
cycle, ...) and collect the results into a tidy Polars DataFrame -
suitable for building performance maps such as:

    CURRENT vs TEMPERATURE
    100 A -> 42 degC
    200 A -> 58 degC
    300 A -> 81 degC
    400 A -> 117 degC
"""

from __future__ import annotations

import itertools
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor
from typing import Any, Callable, Literal

import polars as pl

from electrotherm.simulation.coupled import solve_steady_state
from electrotherm.simulation.results import SteadyStateResult

CaseBuilder = Callable[[dict[str, Any]], dict[str, Any]]
Engine = Literal["serial", "thread", "process"]


def _combinations(param_grid: dict[str, list[Any]]) -> list[dict[str, Any]]:
    keys = list(param_grid.keys())
    values = [param_grid[k] for k in keys]
    return [dict(zip(keys, combo)) for combo in itertools.product(*values)]


def _run_case(case_builder: CaseBuilder, params: dict[str, Any]) -> dict[str, Any]:
    kwargs = case_builder(params)
    result: SteadyStateResult = solve_steady_state(**kwargs)
    row = dict(params)
    row.update(result.summary())
    row["mass_kg"] = result.mass_kg
    return row


def parameter_sweep(
    case_builder: CaseBuilder,
    param_grid: dict[str, list[Any]],
    engine: Engine = "thread",
    max_workers: int | None = None,
) -> pl.DataFrame:
    """Run a steady-state simulation for every combination of
    ``param_grid`` values.

    ``case_builder(params) -> kwargs`` must translate one parameter
    combination (e.g. ``{"current": 200.0, "material": ALUMINIUM}``)
    into the keyword arguments accepted by
    :func:`~electrotherm.simulation.coupled.solve_steady_state`
    (``geometry``, ``material``, ``environment``, ``current``/``voltage``,
    ``num_cells``, ...).

    Returns a Polars DataFrame with one row per combination: the swept
    parameters plus the resulting electrical/thermal summary.
    """
    combos = _combinations(param_grid)
    if not combos:
        return pl.DataFrame()

    if engine == "serial" or len(combos) == 1:
        rows = [_run_case(case_builder, p) for p in combos]
    elif engine == "thread":
        with ThreadPoolExecutor(max_workers=max_workers) as ex:
            rows = list(ex.map(lambda p: _run_case(case_builder, p), combos))
    elif engine == "process":
        # NOTE: case_builder and every object it references must be
        # picklable for the "process" engine (e.g. a module-level
        # function referencing only built-in Material presets).
        with ProcessPoolExecutor(max_workers=max_workers) as ex:
            rows = list(ex.map(_run_case, itertools.repeat(case_builder), combos))
    else:
        raise ValueError(f"Unknown engine '{engine}'")

    return pl.DataFrame(rows)


def performance_map(df: pl.DataFrame, x: str, y: str = "max_temperature_c") -> pl.DataFrame:
    """Convenience: extract a 2-column (x, y) performance-map view from a
    sweep DataFrame, sorted by x, e.g. current -> max_temperature_c.
    """
    return df.select([x, y]).sort(x)


__all__ = ["parameter_sweep", "performance_map", "CaseBuilder"]
