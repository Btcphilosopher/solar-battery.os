"""
electrotherm.optimisation.design
==================================

The design optimiser: answers concrete sizing questions such as

    "What is the smallest conductor that can continuously carry 500 A
     while remaining below 90 degC?"

by bisecting on conductor cross-sectional area (via
``scipy.optimize.brentq``) against the steady-state coupled solver.

All results are simulation outputs from a numerical model using the
material/geometry/environment assumptions supplied by the caller, and
require independent engineering validation before use in a real
design (see module docstring of :mod:`electrotherm.simulation.failure`).
"""

from __future__ import annotations

from scipy.optimize import brentq

from electrotherm.core.models import ETBaseModel
from electrotherm.core.units import kelvin_to_celsius, m2_to_mm2
from electrotherm.geometry import WireGeometry
from electrotherm.materials import Material
from electrotherm.simulation.coupled import solve_steady_state
from electrotherm.simulation.results import SteadyStateResult
from electrotherm.thermal import ThermalEnvironment


class DesignResult(ETBaseModel):
    """Output of :func:`smallest_wire_for_current`."""

    material: str
    area_mm2: float
    diameter_mm: float
    current_a: float
    temperature_c: float
    voltage_drop_v: float
    power_loss_w: float
    mass_kg: float
    converged: bool
    notes: str = (
        "Simulation output from a numerical model; requires independent "
        "engineering validation before use in a certified design."
    )


def smallest_wire_for_current(
    material: Material,
    current_a: float,
    length_m: float,
    environment: ThermalEnvironment,
    max_temperature_c: float,
    diameter_bounds_m: tuple[float, float] = (1e-4, 5e-2),
    num_cells: int = 1,
) -> DesignResult:
    """Find the smallest round-wire diameter that keeps the steady-state
    temperature at/just-below ``max_temperature_c`` while continuously
    carrying ``current_a``.

    Uses bisection: steady-state temperature is monotonically
    decreasing in diameter (more area -> lower resistance & more
    surface -> lower temperature rise), so a unique root exists in
    ``diameter_bounds_m`` for any physically realisable target.
    """
    max_temp_k = max_temperature_c + 273.15

    def temp_margin(diameter_m: float) -> float:
        geometry = WireGeometry(diameter=diameter_m, length=length_m)
        result: SteadyStateResult = solve_steady_state(
            geometry=geometry, material=material, environment=environment,
            current=current_a, num_cells=num_cells,
        )
        return result.max_temperature_k - max_temp_k

    lo, hi = diameter_bounds_m
    f_lo, f_hi = temp_margin(lo), temp_margin(hi)
    if f_lo <= 0:
        # even the smallest bound already meets the target
        diameter = lo
    elif f_hi > 0:
        raise ValueError(
            "No diameter within diameter_bounds_m keeps the conductor below "
            f"{max_temperature_c} degC at {current_a} A; widen diameter_bounds_m."
        )
    else:
        diameter = brentq(temp_margin, lo, hi, xtol=1e-6, rtol=1e-8, maxiter=200)

    geometry = WireGeometry(diameter=diameter, length=length_m)
    result = solve_steady_state(
        geometry=geometry, material=material, environment=environment,
        current=current_a, num_cells=num_cells,
    )

    return DesignResult(
        material=material.name,
        area_mm2=m2_to_mm2(geometry.cross_sectional_area()),
        diameter_mm=diameter * 1000.0,
        current_a=result.current_a,
        temperature_c=kelvin_to_celsius(result.max_temperature_k),
        voltage_drop_v=result.voltage_v,
        power_loss_w=result.power_loss_w,
        mass_kg=result.mass_kg,
        converged=result.converged,
    )


__all__ = ["DesignResult", "smallest_wire_for_current"]
