"""
electrotherm.optimisation.optimiser
=====================================

General-purpose conductor optimisation engine.

Optimises conductor diameter and (by trying each candidate) material
to minimise a weighted objective of

    material mass + annualised energy-loss cost + material cost

subject to soft (penalty-based) engineering constraints:

    temperature       < max_temperature
    current density   < max_current_density
    voltage drop       < max_voltage_drop

The per-material 1D diameter optimisation uses
``scipy.optimize.minimize_scalar`` (bounded Brent's method), which is
well suited to the smooth-but-nonlinear, blackbox-simulation objective
produced by the coupled electro-thermal solver. Running one bounded
1D optimisation per candidate material approximates a full mixed
integer/continuous search without needing a MIP solver.
"""

from __future__ import annotations

from dataclasses import dataclass

from scipy.optimize import minimize_scalar

from electrotherm.core.models import ETBaseModel
from electrotherm.core.units import m2_to_mm2, kelvin_to_celsius
from electrotherm.geometry import WireGeometry
from electrotherm.materials import Material
from electrotherm.simulation.coupled import solve_steady_state
from electrotherm.thermal import ThermalEnvironment


class OptimisationResult(ETBaseModel):
    material: str
    diameter_mm: float
    area_mm2: float
    length_m: float
    current_a: float
    temperature_c: float
    voltage_drop_v: float
    power_loss_w: float
    mass_kg: float
    annual_energy_cost: float
    objective_value: float
    feasible: bool
    violated_constraints: list[str] = []


@dataclass
class OptimisationConstraints:
    max_temperature_c: float
    max_current_density_a_mm2: float | None = None
    max_voltage_drop_v: float | None = None


@dataclass
class OptimisationWeights:
    mass_weight: float = 1.0          # currency per kg-equivalent weighting
    energy_weight: float = 1.0        # weighting on annualised energy cost
    cost_weight: float = 1.0          # weighting on material purchase cost
    electricity_price_per_kwh: float = 0.15
    penalty_scale: float = 1e4        # penalty multiplier per unit constraint violation


def _evaluate(
    diameter_m: float,
    material: Material,
    current_a: float,
    length_m: float,
    environment: ThermalEnvironment,
    constraints: OptimisationConstraints,
    weights: OptimisationWeights,
) -> tuple[float, dict]:
    geometry = WireGeometry(diameter=diameter_m, length=length_m)
    result = solve_steady_state(
        geometry=geometry, material=material, environment=environment, current=current_a,
    )

    mass = result.mass_kg
    annual_kwh = result.power_loss_w * 24.0 * 365.25 / 1000.0
    annual_cost = annual_kwh * weights.electricity_price_per_kwh
    material_cost = mass * (material.cost_per_kg or 0.0)

    objective = (
        weights.mass_weight * mass
        + weights.energy_weight * annual_cost
        + weights.cost_weight * material_cost
    )

    violated = []
    temp_c = kelvin_to_celsius(result.max_temperature_k)
    if temp_c > constraints.max_temperature_c:
        violated.append("temperature")
        objective += weights.penalty_scale * (temp_c - constraints.max_temperature_c)

    current_density_a_mm2 = result.avg_current_density_a_m2 / 1e6
    if constraints.max_current_density_a_mm2 is not None and current_density_a_mm2 > constraints.max_current_density_a_mm2:
        violated.append("current_density")
        objective += weights.penalty_scale * (current_density_a_mm2 - constraints.max_current_density_a_mm2)

    if constraints.max_voltage_drop_v is not None and result.voltage_v > constraints.max_voltage_drop_v:
        violated.append("voltage_drop")
        objective += weights.penalty_scale * (result.voltage_v - constraints.max_voltage_drop_v)

    info = {
        "result": result, "mass": mass, "annual_cost": annual_cost,
        "violated": violated, "temp_c": temp_c,
    }
    return objective, info


def optimise_conductor(
    candidate_materials: list[Material],
    current_a: float,
    length_m: float,
    environment: ThermalEnvironment,
    constraints: OptimisationConstraints,
    weights: OptimisationWeights | None = None,
    diameter_bounds_m: tuple[float, float] = (2e-4, 5e-2),
) -> OptimisationResult:
    """Search over candidate materials and continuous wire diameter to
    minimise the weighted mass/energy/cost objective subject to the
    given thermal/electrical constraints.
    """
    weights = weights or OptimisationWeights()
    best: OptimisationResult | None = None

    for material in candidate_materials:
        def obj(d: float, _material=material) -> float:
            value, _ = _evaluate(d, _material, current_a, length_m, environment, constraints, weights)
            return value

        opt = minimize_scalar(obj, bounds=diameter_bounds_m, method="bounded",
                               options={"xatol": 1e-6})
        diameter = float(opt.x)
        objective_value, info = _evaluate(diameter, material, current_a, length_m, environment, constraints, weights)
        result = info["result"]

        candidate = OptimisationResult(
            material=material.name,
            diameter_mm=diameter * 1000.0,
            area_mm2=m2_to_mm2(WireGeometry(diameter=diameter, length=length_m).cross_sectional_area()),
            length_m=length_m,
            current_a=result.current_a,
            temperature_c=info["temp_c"],
            voltage_drop_v=result.voltage_v,
            power_loss_w=result.power_loss_w,
            mass_kg=info["mass"],
            annual_energy_cost=info["annual_cost"],
            objective_value=objective_value,
            feasible=(len(info["violated"]) == 0),
            violated_constraints=info["violated"],
        )

        if best is None:
            best = candidate
        else:
            # prefer feasible solutions; among feasible (or among all
            # infeasible, if none are feasible) prefer lower objective
            better = (candidate.feasible and not best.feasible) or (
                candidate.feasible == best.feasible and candidate.objective_value < best.objective_value
            )
            if better:
                best = candidate

    assert best is not None
    return best


__all__ = ["OptimisationResult", "OptimisationConstraints", "OptimisationWeights", "optimise_conductor"]
