"""
electrotherm.core.configuration
=================================

Global solver configuration. Centralising these knobs makes numerical
behaviour (accuracy vs. speed) reproducible and lets tests pin down a
deterministic configuration.
"""

from __future__ import annotations

from electrotherm.core.models import ETBaseModel
from pydantic import Field


class SolverConfig(ETBaseModel):
    """Numerical settings for the electro-thermal solvers."""

    #: default number of spatial cells for 1D spatial models
    default_num_cells: int = Field(default=1, ge=1)
    #: absolute/relative tolerances passed to scipy.integrate.solve_ivp
    rtol: float = Field(default=1e-6, gt=0)
    atol: float = Field(default=1e-6, gt=0)
    #: ODE integration method (scipy.integrate.solve_ivp `method`)
    ode_method: str = Field(default="BDF")
    #: max internal solver step, seconds (None = solver default)
    max_step: float | None = None
    #: steady-state root-finding tolerance, kelvin
    steady_state_tol_k: float = Field(default=1e-4, gt=0)
    #: steady-state root-finding max iterations
    steady_state_max_iter: int = Field(default=200, ge=1)
    #: use numba-accelerated kernels when available
    use_numba: bool = True
    #: number of worker processes for parameter sweeps (None = cpu_count)
    sweep_workers: int | None = None
    #: deterministic random seed for anything stochastic (e.g. Monte Carlo
    #: sensitivity sweeps added by users)
    random_seed: int = 42


#: module-level default configuration instance, mutated in place by callers
#: who want to change global solver behaviour without threading a config
#: object through every call.
DEFAULT_CONFIG = SolverConfig()


def get_config() -> SolverConfig:
    return DEFAULT_CONFIG


def set_config(config: SolverConfig) -> None:
    global DEFAULT_CONFIG
    DEFAULT_CONFIG = config
