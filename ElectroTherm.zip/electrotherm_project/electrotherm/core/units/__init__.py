"""
electrotherm.core.units
========================

Central definitions of the physical unit system and constants used
throughout ElectroTherm.

ElectroTherm computes internally in **SI base units**:

    length        -> metre (m)
    mass          -> kilogram (kg)
    time          -> second (s)
    current       -> ampere (A)
    temperature   -> kelvin (K)
    resistance    -> ohm (Ω)
    resistivity   -> ohm-metre (Ω·m)
    conductivity  -> siemens/metre (S/m)
    power         -> watt (W)
    energy        -> joule (J)
    heat capacity -> J/(kg·K)
    thermal cond. -> W/(m·K)

Convenience conversion helpers are provided so callers can work in the
units that are natural for engineering work (mm, mm^2, degC, AWG, ...)
without ambiguity creeping into the solver core.
"""

from __future__ import annotations

import math

# ---------------------------------------------------------------------------
# Physical constants
# ---------------------------------------------------------------------------

STEFAN_BOLTZMANN = 5.670374419e-8  # W/(m^2 K^4)
GRAVITY = 9.80665  # m/s^2
CELSIUS_TO_KELVIN_OFFSET = 273.15

#: Standard reference / room temperature, in kelvin (20 degC)
T_REFERENCE_K = 293.15
#: Standard ambient temperature, in kelvin (25 degC)
T_AMBIENT_K = 298.15


# ---------------------------------------------------------------------------
# Temperature
# ---------------------------------------------------------------------------

def celsius_to_kelvin(t_celsius: float) -> float:
    return t_celsius + CELSIUS_TO_KELVIN_OFFSET


def kelvin_to_celsius(t_kelvin: float) -> float:
    return t_kelvin - CELSIUS_TO_KELVIN_OFFSET


def fahrenheit_to_kelvin(t_f: float) -> float:
    return (t_f - 32.0) * 5.0 / 9.0 + CELSIUS_TO_KELVIN_OFFSET


def kelvin_to_fahrenheit(t_k: float) -> float:
    return (t_k - CELSIUS_TO_KELVIN_OFFSET) * 9.0 / 5.0 + 32.0


# ---------------------------------------------------------------------------
# Length / area / volume
# ---------------------------------------------------------------------------

def mm_to_m(value_mm: float) -> float:
    return value_mm * 1e-3


def m_to_mm(value_m: float) -> float:
    return value_m * 1e3


def mm2_to_m2(value_mm2: float) -> float:
    return value_mm2 * 1e-6


def m2_to_mm2(value_m2: float) -> float:
    return value_m2 * 1e6


def circle_area(diameter_m: float) -> float:
    """Cross-sectional area of a circle given its diameter, in m^2."""
    return math.pi * (diameter_m ** 2) / 4.0


def circle_circumference(diameter_m: float) -> float:
    return math.pi * diameter_m


# ---------------------------------------------------------------------------
# Electrical / thermal convenience conversions
# ---------------------------------------------------------------------------

def awg_to_diameter_m(awg: float) -> float:
    """
    Approximate diameter (in metres) of solid round wire from its
    American Wire Gauge (AWG) number, using the standard geometric
    progression formula. Valid roughly for -3 <= AWG <= 40.
    """
    return 0.000127 * (92 ** ((36 - awg) / 39.0))


def watts_to_kwh(power_w: float, hours: float) -> float:
    return power_w * hours / 1000.0


def joules_to_kwh(energy_j: float) -> float:
    return energy_j / 3.6e6
