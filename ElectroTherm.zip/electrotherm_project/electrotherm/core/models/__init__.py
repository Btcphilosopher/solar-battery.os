"""
electrotherm.core.models
=========================

Base Pydantic model classes shared across ElectroTherm sub-packages.
Every physical/engineering data structure in ElectroTherm (materials,
geometries, environments, results, ...) derives from :class:`ETBaseModel`
so that the whole engine has consistent (de)serialisation, validation
and immutability semantics.
"""

from __future__ import annotations

import enum
import json
from pathlib import Path
from typing import Any

from pydantic import BaseModel, ConfigDict


class ETBaseModel(BaseModel):
    """
    Common base class for all ElectroTherm data models.

    - Validates on assignment (catches unit / sign mistakes early).
    - Rejects unknown fields (typo protection for engineering inputs).
    - Provides ``to_json`` / ``from_json`` round-trip helpers used by the
      digital-conductor persistence layer and the FastAPI layer.
    """

    model_config = ConfigDict(
        validate_assignment=True,
        extra="forbid",
        arbitrary_types_allowed=True,
    )

    def to_json(self, path: str | Path | None = None, indent: int = 2) -> str:
        text = self.model_dump_json(indent=indent)
        if path is not None:
            Path(path).write_text(text)
        return text

    @classmethod
    def from_json(cls, source: str | Path) -> "ETBaseModel":
        p = Path(source)
        if p.exists():
            return cls.model_validate_json(p.read_text())
        return cls.model_validate_json(source)

    def to_dict(self) -> dict[str, Any]:
        return self.model_dump()


class SeverityLevel(str, enum.Enum):
    """Operating-condition severity classification.

    ElectroTherm is a *simulation* tool, not a certified protection
    device. These labels describe modelled thermal risk only.
    """

    NORMAL = "NORMAL"
    WARNING = "WARNING"
    THERMAL_LIMIT = "THERMAL_LIMIT"
    CRITICAL = "CRITICAL"


def dumps(obj: ETBaseModel) -> str:
    return json.dumps(obj.to_dict(), default=str, indent=2)
