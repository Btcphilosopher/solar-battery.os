import math

import pytest

from electrotherm.materials import COPPER, ALUMINIUM, Material, get_material, register_material


def test_resistivity_reference_point():
    # at reference temperature, rho(T0) must equal rho0 exactly
    assert COPPER.resistivity(COPPER.reference_temperature) == pytest.approx(COPPER.resistivity_ref)


def test_resistivity_increases_with_temperature():
    r_cold = COPPER.resistivity(273.15)
    r_hot = COPPER.resistivity(373.15)
    assert r_hot > r_cold


def test_resistivity_linear_model():
    t0 = COPPER.reference_temperature
    dt = 50.0
    expected = COPPER.resistivity_ref * (1 + COPPER.temp_coefficient_resistance * dt)
    assert COPPER.resistivity(t0 + dt) == pytest.approx(expected)


def test_conductivity_is_inverse_of_resistivity():
    t = 350.0
    assert COPPER.conductivity(t) == pytest.approx(1.0 / COPPER.resistivity(t))


def test_material_registry_lookup_case_insensitive():
    assert get_material("Copper") is COPPER
    assert get_material("ALUMINIUM") is ALUMINIUM


def test_unknown_material_raises():
    with pytest.raises(KeyError):
        get_material("unobtainium")


def test_custom_material_registration():
    alloy = Material(
        name="TestAlloy",
        resistivity_ref=5e-8,
        temp_coefficient_resistance=0.002,
        thermal_conductivity_ref=100.0,
        density=8000.0,
        specific_heat_ref=400.0,
        melting_point=1500.0,
        max_operating_temperature=400.0,
    )
    register_material(alloy)
    assert get_material("TestAlloy") is alloy


def test_melting_point_must_exceed_max_operating_temperature():
    with pytest.raises(Exception):
        Material(
            name="bad",
            resistivity_ref=1e-8,
            temp_coefficient_resistance=0.001,
            thermal_conductivity_ref=10.0,
            density=1000.0,
            specific_heat_ref=100.0,
            melting_point=300.0,
            max_operating_temperature=400.0,
        )


def test_thermal_diffusivity_positive():
    assert COPPER.thermal_diffusivity(300.0) > 0
