import pytest

from electrotherm.geometry import WireGeometry
from electrotherm.materials import COPPER, ALUMINIUM
from electrotherm.simulation.coupled import solve_steady_state
from electrotherm.simulation.conductor import DigitalConductor
from electrotherm.simulation.energy import analyse_steady_state_energy
from electrotherm.simulation.whatif import Scenario, run_whatif, make_common_scenarios
from electrotherm.thermal import ThermalEnvironment, STILL_AIR

ENV = ThermalEnvironment(ambient_temperature=298.15, fixed_convection_coefficient=15.0)
GEOM = WireGeometry(diameter=0.004, length=3.0)


def test_whatif_current_increase_raises_temperature():
    scenarios = [Scenario("current +20%", {"current": 150.0 * 1.2})]
    df = run_whatif(GEOM, COPPER, ENV, 150.0, scenarios)
    baseline_temp = df.filter(df["scenario"] == "baseline")["max_temperature_c"][0]
    scenario_temp = df.filter(df["scenario"] == "current +20%")["max_temperature_c"][0]
    assert scenario_temp > baseline_temp


def test_whatif_material_swap_changes_result():
    scenarios = [Scenario("aluminium instead of copper", {"material": ALUMINIUM})]
    df = run_whatif(GEOM, COPPER, ENV, 100.0, scenarios)
    baseline_r = df.filter(df["scenario"] == "baseline")["resistance_ohm"][0]
    swapped_r = df.filter(df["scenario"] == "aluminium instead of copper")["resistance_ohm"][0]
    assert swapped_r != pytest.approx(baseline_r)


def test_make_common_scenarios_all_run():
    scenarios = make_common_scenarios(100.0, ENV, COPPER, GEOM, alternate_material=ALUMINIUM)
    df = run_whatif(GEOM, COPPER, ENV, 100.0, scenarios)
    assert df.height == len(scenarios) + 1  # + baseline
    assert df["converged"].all()


def test_energy_analysis_scales_correctly():
    result = solve_steady_state(geometry=GEOM, material=COPPER, environment=ENV, current=120.0)
    analysis = analyse_steady_state_energy(result, electricity_price_per_kwh=0.20)
    assert analysis.energy_per_day_kwh == pytest.approx(analysis.energy_per_hour_kwh * 24, rel=1e-6)
    assert analysis.energy_per_year_kwh == pytest.approx(analysis.energy_per_day_kwh * 365.25, rel=1e-6)
    assert analysis.cost_per_year == pytest.approx(analysis.energy_per_year_kwh * 0.20, rel=1e-6)


def test_digital_conductor_round_trip(tmp_path):
    conductor = DigitalConductor(
        name="test_feeder", material=COPPER, geometry=GEOM, default_environment=STILL_AIR.model_copy(),
    )
    result = conductor.run_steady_state(current=80.0)
    assert len(conductor.simulation_history) == 1
    assert conductor.simulation_history[0]["current_a"] == pytest.approx(result.current_a)

    path = tmp_path / "conductor.json"
    conductor.save(path)
    reloaded = DigitalConductor.load(path)
    assert reloaded.id == conductor.id
    assert reloaded.material.name == COPPER.name
    assert len(reloaded.simulation_history) == 1


def test_digital_conductor_transient_history():
    conductor = DigitalConductor(name="pulse_test", material=COPPER, geometry=GEOM)
    conductor.run_transient(t_span=(0, 30.0), current=50.0)
    assert conductor.simulation_history[-1]["kind"] == "transient"
