import pytest

from electrotherm.geometry import WireGeometry
from electrotherm.materials import COPPER, ALUMINIUM
from electrotherm.optimisation.design import smallest_wire_for_current
from electrotherm.optimisation.optimiser import (
    OptimisationConstraints, OptimisationWeights, optimise_conductor,
)
from electrotherm.optimisation.sweep import parameter_sweep, performance_map
from electrotherm.thermal import ThermalEnvironment


ENV = ThermalEnvironment(ambient_temperature=298.15, fixed_convection_coefficient=15.0)


def test_smallest_wire_for_current_meets_target():
    design = smallest_wire_for_current(
        material=COPPER, current_a=100.0, length_m=5.0, environment=ENV, max_temperature_c=90.0,
    )
    assert design.temperature_c <= 90.0 + 0.1
    assert design.diameter_mm > 0
    assert design.converged


def test_smallest_wire_larger_current_needs_larger_diameter():
    small = smallest_wire_for_current(material=COPPER, current_a=50.0, length_m=5.0,
                                       environment=ENV, max_temperature_c=90.0)
    large = smallest_wire_for_current(material=COPPER, current_a=200.0, length_m=5.0,
                                       environment=ENV, max_temperature_c=90.0)
    assert large.diameter_mm > small.diameter_mm


def test_optimise_conductor_prefers_feasible_solution():
    constraints = OptimisationConstraints(max_temperature_c=90.0)
    weights = OptimisationWeights(electricity_price_per_kwh=0.15)
    result = optimise_conductor(
        candidate_materials=[COPPER, ALUMINIUM], current_a=150.0, length_m=10.0,
        environment=ENV, constraints=constraints, weights=weights,
    )
    assert result.feasible
    assert result.temperature_c <= 90.0 + 1.0


def test_parameter_sweep_builds_performance_map():
    def case_builder(params):
        geometry = WireGeometry(diameter=0.004, length=2.0)
        return dict(geometry=geometry, material=COPPER, environment=ENV, current=params["current_a"])

    df = parameter_sweep(case_builder, {"current_a": [50.0, 100.0, 150.0, 200.0]}, engine="serial")
    assert df.height == 4
    pm = performance_map(df, "current_a", "max_temperature_c")
    temps = pm["max_temperature_c"].to_list()
    # monotonically increasing temperature with current
    assert all(b >= a for a, b in zip(temps, temps[1:]))


def test_parameter_sweep_threaded_matches_serial():
    def case_builder(params):
        geometry = WireGeometry(diameter=0.004, length=2.0)
        return dict(geometry=geometry, material=COPPER, environment=ENV, current=params["current_a"])

    grid = {"current_a": [50.0, 100.0]}
    df_serial = parameter_sweep(case_builder, grid, engine="serial")
    df_thread = parameter_sweep(case_builder, grid, engine="thread")
    assert sorted(df_serial["max_temperature_c"].to_list()) == pytest.approx(
        sorted(df_thread["max_temperature_c"].to_list())
    )
