import pytest
from fastapi.testclient import TestClient

from electrotherm.api.main import app

client = TestClient(app)


def test_health():
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"


def test_list_materials_contains_copper():
    r = client.get("/materials")
    assert r.status_code == 200
    body = r.json()
    assert "copper" in body


def test_simulate_steady_state():
    payload = {
        "geometry": {"kind": "wire", "diameter": 0.004, "length": 3.0},
        "material": {
            "name": "TestCopper", "resistivity_ref": 1.68e-8, "reference_temperature": 293.15,
            "temp_coefficient_resistance": 0.00393, "thermal_conductivity_ref": 401.0,
            "density": 8960.0, "specific_heat_ref": 385.0, "melting_point": 1357.77,
            "max_operating_temperature": 473.15, "emissivity": 0.04,
        },
        "environment": {"ambient_temperature": 298.15, "fixed_convection_coefficient": 15.0},
        "current_a": 100.0,
    }
    r = client.post("/simulate", json=payload)
    assert r.status_code == 200, r.text
    body = r.json()
    assert body["result"]["current_a"] == pytest.approx(100.0)
    assert body["result"]["converged"] is True

    sim_id = body["id"]
    r2 = client.get(f"/simulation/{sim_id}")
    assert r2.status_code == 200
    assert r2.json()["kind"] == "steady_state"


def test_simulate_rejects_both_current_and_voltage():
    payload = {
        "geometry": {"kind": "wire", "diameter": 0.004, "length": 3.0},
        "material": {
            "name": "TestCopper", "resistivity_ref": 1.68e-8,
            "temp_coefficient_resistance": 0.00393, "thermal_conductivity_ref": 401.0,
            "density": 8960.0, "specific_heat_ref": 385.0, "melting_point": 1357.77,
            "max_operating_temperature": 473.15,
        },
        "environment": {"ambient_temperature": 298.15, "fixed_convection_coefficient": 15.0},
        "current_a": 100.0,
        "voltage_v": 5.0,
    }
    r = client.post("/simulate", json=payload)
    assert r.status_code == 400


def test_design_endpoint():
    payload = {
        "material_name": "copper", "current_a": 100.0, "length_m": 5.0,
        "environment": {"ambient_temperature": 298.15, "fixed_convection_coefficient": 15.0},
        "max_temperature_c": 90.0,
    }
    r = client.post("/design", json=payload)
    assert r.status_code == 200, r.text
    assert r.json()["result"]["diameter_mm"] > 0


def test_unknown_simulation_returns_404():
    r = client.get("/simulation/does-not-exist")
    assert r.status_code == 404
