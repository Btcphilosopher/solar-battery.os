import pytest

from electrotherm.core.models import SeverityLevel
from electrotherm.geometry import WireGeometry
from electrotherm.materials import COPPER
from electrotherm.simulation.coupled import solve_steady_state
from electrotherm.simulation.failure import (
    classify_severity, classify_material_state, overcurrent_scenario,
    cooling_failure_scenario, partial_damage_resistance_multiplier,
)
from electrotherm.thermal import ThermalEnvironment, CoolingType, STILL_AIR


def test_classify_severity_bands():
    max_op, melt = 400.0, 1000.0
    assert classify_severity(300.0, max_op, melt) == SeverityLevel.NORMAL
    assert classify_severity(340.0, max_op, melt) == SeverityLevel.WARNING  # 0.85 of max_op
    assert classify_severity(450.0, max_op, melt) == SeverityLevel.THERMAL_LIMIT
    assert classify_severity(1000.0, max_op, melt) == SeverityLevel.CRITICAL


def test_classify_material_state_matches_manual():
    assert classify_material_state(COPPER.max_operating_temperature + 1, COPPER) == SeverityLevel.THERMAL_LIMIT


def test_overcurrent_scenario_scales_current():
    assert overcurrent_scenario(100.0, 1.5) == pytest.approx(150.0)
    with pytest.raises(ValueError):
        overcurrent_scenario(100.0, 0.9)


def test_cooling_failure_scenario_disables_forced_air():
    env = ThermalEnvironment(ambient_temperature=298.15, cooling_type=CoolingType.FORCED_AIR, air_velocity=5.0)
    failed = cooling_failure_scenario(env)
    assert failed.cooling_type == CoolingType.STILL_AIR
    assert failed.air_velocity == 0.0


def test_partial_damage_multiplier():
    assert partial_damage_resistance_multiplier(0.5) == pytest.approx(2.0)
    with pytest.raises(ValueError):
        partial_damage_resistance_multiplier(1.0)


def test_overcurrent_raises_severity():
    geometry = WireGeometry(diameter=0.0015, length=3.0)
    env = STILL_AIR.model_copy(update={"ambient_temperature": 298.15})
    normal = solve_steady_state(geometry=geometry, material=COPPER, environment=env, current=10.0)
    overcurrent = solve_steady_state(
        geometry=geometry, material=COPPER, environment=env,
        current=overcurrent_scenario(10.0, 5.0),
    )
    assert overcurrent.max_temperature_k > normal.max_temperature_k
    # severity should never decrease under a large overcurrent
    order = [SeverityLevel.NORMAL, SeverityLevel.WARNING, SeverityLevel.THERMAL_LIMIT, SeverityLevel.CRITICAL]
    assert order.index(overcurrent.severity) >= order.index(normal.severity)


def test_local_resistance_multiplier_creates_hot_spot():
    """A locally damaged cell (higher resistance) should run hotter than
    its undamaged neighbours in a multi-cell spatial model.
    """
    geometry = WireGeometry(diameter=0.002, length=1.0)
    env = ThermalEnvironment(ambient_temperature=298.15, fixed_convection_coefficient=15.0)
    n = 5
    damage = [1.0, 1.0, 3.0, 1.0, 1.0]  # cell index 2 (0-based) is damaged
    result = solve_steady_state(
        geometry=geometry, material=COPPER, environment=env, current=40.0,
        num_cells=n, local_resistance_multiplier=damage,
    )
    temps = result.cell_temperatures_k
    hot_cell = temps[2]
    others = [t for i, t in enumerate(temps) if i != 2]
    assert hot_cell > max(others)


def test_local_ambient_offset_creates_cooler_region():
    geometry = WireGeometry(diameter=0.002, length=1.0)
    env = ThermalEnvironment(ambient_temperature=298.15, fixed_convection_coefficient=15.0)
    n = 4
    offsets = [0.0, 0.0, -20.0, 0.0]  # cell 2 sits in a locally cooled zone
    result = solve_steady_state(
        geometry=geometry, material=COPPER, environment=env, current=30.0,
        num_cells=n, local_ambient_offset_k=offsets,
    )
    temps = result.cell_temperatures_k
    assert temps[2] < temps[0]
