import pytest

from electrotherm.thermal import (
    ThermalEnvironment, CoolingType, radiative_heat_loss, convective_heat_loss,
    natural_convection_coefficient_cylinder, forced_convection_coefficient_cylinder,
)
from electrotherm.core.units import STEFAN_BOLTZMANN


def test_radiative_heat_loss_zero_when_equal_temperature():
    q = radiative_heat_loss(300.0, 300.0, 1.0, 0.5)
    assert q == pytest.approx(0.0)


def test_radiative_heat_loss_matches_stefan_boltzmann():
    ts, ta, a, eps = 400.0, 300.0, 0.02, 0.3
    expected = eps * STEFAN_BOLTZMANN * a * (ts ** 4 - ta ** 4)
    assert radiative_heat_loss(ts, ta, a, eps) == pytest.approx(expected)


def test_convective_heat_loss_linear_in_dt():
    q1 = convective_heat_loss(320.0, 300.0, 0.01, 10.0)
    q2 = convective_heat_loss(340.0, 300.0, 0.01, 10.0)
    assert q2 == pytest.approx(2 * q1)


def test_forced_convection_exceeds_natural_for_same_dt():
    h_natural = natural_convection_coefficient_cylinder(350.0, 300.0, 0.01)
    h_forced = forced_convection_coefficient_cylinder(350.0, 300.0, 0.01, air_velocity_m_s=5.0)
    assert h_forced > h_natural


def test_environment_convection_coefficient_positive():
    env = ThermalEnvironment(ambient_temperature=298.15, cooling_type=CoolingType.STILL_AIR)
    h = env.convection_coefficient(350.0, 0.01)
    assert h > 0


def test_environment_fixed_coefficient_overrides_correlation():
    env = ThermalEnvironment(ambient_temperature=298.15, fixed_convection_coefficient=25.0)
    assert env.convection_coefficient(500.0, 0.01) == pytest.approx(25.0)


def test_contact_resistance_reduces_effective_h():
    env_no_contact = ThermalEnvironment(ambient_temperature=298.15, fixed_convection_coefficient=100.0)
    env_with_contact = ThermalEnvironment(
        ambient_temperature=298.15, fixed_convection_coefficient=100.0, contact_resistance=0.01,
    )
    h1 = env_no_contact.convection_coefficient(350.0, 0.01)
    h2 = env_with_contact.convection_coefficient(350.0, 0.01)
    assert h2 < h1


def test_total_heat_loss_increases_with_temperature():
    env = ThermalEnvironment(ambient_temperature=298.15, fixed_convection_coefficient=15.0)
    q1 = env.total_heat_loss(320.0, 0.01, 0.01, emissivity=0.3)
    q2 = env.total_heat_loss(360.0, 0.01, 0.01, emissivity=0.3)
    assert q2 > q1
