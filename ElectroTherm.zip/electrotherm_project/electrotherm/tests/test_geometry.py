import math

import pytest

from electrotherm.geometry import (
    WireGeometry, CylindricalConductorGeometry, RectangularConductorGeometry,
    BusbarGeometry, CableGeometry, CustomGeometry,
)
from electrotherm.materials import COPPER


def test_wire_cross_sectional_area():
    wire = WireGeometry(diameter=0.01, length=1.0)  # 10mm dia
    expected = math.pi * 0.01 ** 2 / 4.0
    assert wire.cross_sectional_area() == pytest.approx(expected)


def test_wire_resistance_matches_rho_l_over_a():
    wire = WireGeometry(diameter=0.002, length=2.0)
    t = 293.15
    expected = COPPER.resistivity(t) * wire.length / wire.cross_sectional_area()
    assert wire.resistance(COPPER, t) == pytest.approx(expected)


def test_wire_mass():
    wire = WireGeometry(diameter=0.002, length=2.0)
    expected = wire.cross_sectional_area() * wire.length * COPPER.density
    assert wire.mass(COPPER) == pytest.approx(expected)


def test_cylindrical_hollow_area_less_than_solid():
    solid = CylindricalConductorGeometry(outer_diameter=0.02, inner_diameter=0.0, length=1.0)
    hollow = CylindricalConductorGeometry(outer_diameter=0.02, inner_diameter=0.01, length=1.0)
    assert hollow.cross_sectional_area() < solid.cross_sectional_area()


def test_cylindrical_rejects_inner_ge_outer():
    with pytest.raises(Exception):
        CylindricalConductorGeometry(outer_diameter=0.01, inner_diameter=0.02, length=1.0)


def test_rectangular_area_and_perimeter():
    bar = RectangularConductorGeometry(width=0.05, thickness=0.005, length=1.0)
    assert bar.cross_sectional_area() == pytest.approx(0.05 * 0.005)
    assert bar.perimeter() == pytest.approx(2 * (0.05 + 0.005))


def test_busbar_stack_scales_area_linearly():
    single = BusbarGeometry(width=0.05, thickness=0.005, length=1.0, num_bars=1)
    triple = BusbarGeometry(width=0.05, thickness=0.005, length=1.0, num_bars=3)
    assert triple.cross_sectional_area() == pytest.approx(3 * single.cross_sectional_area())


def test_cable_area_from_strands():
    cable = CableGeometry(strand_diameter=0.001, num_strands=19, length=1.0)
    expected = 19 * math.pi * 0.001 ** 2 / 4.0
    assert cable.cross_sectional_area() == pytest.approx(expected)


def test_custom_geometry_from_polygon_square():
    # 10mm x 10mm square -> area 1e-4 m^2, perimeter 0.04 m
    points = [(0, 0), (0.01, 0), (0.01, 0.01), (0, 0.01)]
    geom = CustomGeometry.from_polygon(points, length=1.0)
    assert geom.cross_sectional_area() == pytest.approx(1e-4)
    assert geom.perimeter() == pytest.approx(0.04)


def test_surface_area_and_volume():
    wire = WireGeometry(diameter=0.01, length=2.0)
    assert wire.surface_area() == pytest.approx(wire.perimeter() * wire.length)
    assert wire.volume() == pytest.approx(wire.cross_sectional_area() * wire.length)


def test_current_density():
    wire = WireGeometry(diameter=0.01, length=1.0)
    j = wire.current_density(100.0)
    assert j == pytest.approx(100.0 / wire.cross_sectional_area())
