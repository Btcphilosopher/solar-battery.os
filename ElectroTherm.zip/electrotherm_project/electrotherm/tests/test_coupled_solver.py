"""
Analytical / validation benchmarks for the coupled electro-thermal
solver: Ohmic resistance, Joule heating, steady-state temperature,
transient thermal response, energy conservation, and convergence with
respect to timestep tolerance and spatial resolution.

Each test disables the nonlinear feedback terms that don't have a
simple closed form (temperature-dependent resistivity, radiation) so
the coupled solver's numerics can be checked against an exact
analytical solution of the remaining linear lumped-capacitance model:

    m*cp * dT/dt = I^2*R - h*A*(T - Tamb)

whose steady state is  T_ss = Tamb + I^2*R / (h*A)
and whose transient solution is
    T(t) = T_ss + (T0 - T_ss) * exp(-t / tau),   tau = m*cp / (h*A)
"""

from __future__ import annotations

import math

import numpy as np
import pytest

from electrotherm.core.configuration import SolverConfig
from electrotherm.geometry import WireGeometry
from electrotherm.materials import Material
from electrotherm.simulation.coupled import solve_steady_state, solve_transient
from electrotherm.thermal import ThermalEnvironment


def _linear_material() -> Material:
    """A material with zero temperature coefficients and zero emissivity,
    so resistivity is constant and radiation is exactly zero -- reducing
    the coupled system to a simple linear lumped-capacitance model with
    a closed-form analytical solution.
    """
    return Material(
        name="LinearTestMaterial",
        resistivity_ref=1.7e-8,
        temp_coefficient_resistance=0.0,
        thermal_conductivity_ref=400.0,
        density=8900.0,
        specific_heat_ref=390.0,
        melting_point=1400.0,
        max_operating_temperature=500.0,
        emissivity=0.0,
    )


@pytest.fixture()
def linear_setup():
    material = _linear_material()
    geometry = WireGeometry(diameter=0.004, length=1.5)
    h = 20.0
    environment = ThermalEnvironment(ambient_temperature=298.15, fixed_convection_coefficient=h)
    current = 60.0
    return material, geometry, environment, current, h


def test_ohmic_resistance_matches_rho_l_over_a(linear_setup):
    material, geometry, environment, current, h = linear_setup
    result = solve_steady_state(geometry=geometry, material=material, environment=environment, current=current)
    expected_r = material.resistivity_ref * geometry.length / geometry.cross_sectional_area()
    assert result.total_resistance_ohm == pytest.approx(expected_r, rel=1e-6)


def test_joule_heating_matches_i2r(linear_setup):
    material, geometry, environment, current, h = linear_setup
    result = solve_steady_state(geometry=geometry, material=material, environment=environment, current=current)
    expected_p = current ** 2 * result.total_resistance_ohm
    assert result.power_loss_w == pytest.approx(expected_p, rel=1e-6)


def test_steady_state_temperature_matches_analytical(linear_setup):
    material, geometry, environment, current, h = linear_setup
    result = solve_steady_state(geometry=geometry, material=material, environment=environment, current=current)

    R = material.resistivity_ref * geometry.length / geometry.cross_sectional_area()
    P = current ** 2 * R
    A = geometry.surface_area()
    T_ss_analytical = environment.ambient_temperature + P / (h * A)

    assert result.max_temperature_k == pytest.approx(T_ss_analytical, rel=1e-4)
    assert result.converged


def test_transient_matches_analytical_exponential(linear_setup):
    material, geometry, environment, current, h = linear_setup
    R = material.resistivity_ref * geometry.length / geometry.cross_sectional_area()
    P = current ** 2 * R
    A = geometry.surface_area()
    T_ss = environment.ambient_temperature + P / (h * A)
    mass = geometry.mass(material)
    tau = mass * material.specific_heat_ref / (h * A)

    t_eval = np.linspace(0, 3 * tau, 25)
    result = solve_transient(
        geometry=geometry, material=material, environment=environment, current=current,
        t_span=(0, 3 * tau), t_eval=t_eval, initial_temperature_k=environment.ambient_temperature,
    )

    T0 = environment.ambient_temperature
    for t, cell_temps in zip(result.times_s, result.temperatures_k):
        analytical = T_ss + (T0 - T_ss) * math.exp(-t / tau)
        assert cell_temps[0] == pytest.approx(analytical, abs=0.5)


def test_energy_conservation_constant_power(linear_setup):
    """With alpha=0, resistance (and hence Joule power) is exactly
    constant through the transient, so integrated dissipated energy
    must equal power * duration.
    """
    material, geometry, environment, current, h = linear_setup
    t_end = 500.0
    t_eval = np.linspace(0, t_end, 100)
    result = solve_transient(
        geometry=geometry, material=material, environment=environment, current=current,
        t_span=(0, t_end), t_eval=t_eval,
    )
    R = material.resistivity_ref * geometry.length / geometry.cross_sectional_area()
    expected_energy = current ** 2 * R * t_end
    assert result.energy_dissipated_j() == pytest.approx(expected_energy, rel=1e-3)


def test_steady_state_energy_balance(linear_setup):
    """At steady state, Joule power in must equal convective power out."""
    material, geometry, environment, current, h = linear_setup
    result = solve_steady_state(geometry=geometry, material=material, environment=environment, current=current)
    q_out = h * geometry.surface_area() * (result.max_temperature_k - environment.ambient_temperature)
    assert result.power_loss_w == pytest.approx(q_out, rel=1e-3)


def test_timestep_tolerance_convergence(linear_setup):
    """Tightening solve_ivp tolerances should not materially change the
    final temperature (numerical convergence check).
    """
    material, geometry, environment, current, h = linear_setup
    loose = SolverConfig(rtol=1e-4, atol=1e-4)
    tight = SolverConfig(rtol=1e-9, atol=1e-9)

    r1 = solve_transient(geometry=geometry, material=material, environment=environment,
                          current=current, t_span=(0, 200), config=loose)
    r2 = solve_transient(geometry=geometry, material=material, environment=environment,
                          current=current, t_span=(0, 200), config=tight)

    assert r1.temperatures_k[-1][0] == pytest.approx(r2.temperatures_k[-1][0], abs=0.05)


def test_spatial_resolution_convergence(linear_setup):
    """A uniform conductor (no local hot spots) should give (nearly)
    identical steady-state temperature regardless of how many axial
    cells it is divided into, since every cell sees identical
    conditions and net inter-cell conduction is zero at equilibrium.
    """
    material, geometry, environment, current, h = linear_setup
    r1 = solve_steady_state(geometry=geometry, material=material, environment=environment,
                             current=current, num_cells=1)
    r8 = solve_steady_state(geometry=geometry, material=material, environment=environment,
                             current=current, num_cells=8)
    assert r1.max_temperature_k == pytest.approx(r8.max_temperature_k, abs=0.1)
    assert r1.power_loss_w == pytest.approx(r8.power_loss_w, rel=1e-3)


def test_solver_is_deterministic(linear_setup):
    material, geometry, environment, current, h = linear_setup
    r1 = solve_steady_state(geometry=geometry, material=material, environment=environment, current=current)
    r2 = solve_steady_state(geometry=geometry, material=material, environment=environment, current=current)
    assert r1.max_temperature_k == r2.max_temperature_k
    assert r1.power_loss_w == r2.power_loss_w


def test_higher_current_gives_higher_temperature(linear_setup):
    material, geometry, environment, _, h = linear_setup
    r_low = solve_steady_state(geometry=geometry, material=material, environment=environment, current=30.0)
    r_high = solve_steady_state(geometry=geometry, material=material, environment=environment, current=90.0)
    assert r_high.max_temperature_k > r_low.max_temperature_k


def test_constant_voltage_mode_self_consistent(linear_setup):
    material, geometry, environment, current, h = linear_setup
    # first find the resistance at some plausible operating point, then
    # drive with the corresponding voltage and check current comes back
    # out self-consistently near the target current.
    r_current_mode = solve_steady_state(geometry=geometry, material=material, environment=environment, current=current)
    target_voltage = r_current_mode.voltage_v
    r_voltage_mode = solve_steady_state(geometry=geometry, material=material, environment=environment, voltage=target_voltage)
    assert r_voltage_mode.current_a == pytest.approx(current, rel=1e-3)
    assert r_voltage_mode.max_temperature_k == pytest.approx(r_current_mode.max_temperature_k, rel=1e-3)
