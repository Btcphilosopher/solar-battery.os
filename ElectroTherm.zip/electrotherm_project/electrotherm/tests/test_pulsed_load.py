import numpy as np

from electrotherm.electrical import PulsedCurrent
from electrotherm.geometry import WireGeometry
from electrotherm.materials import COPPER
from electrotherm.simulation.coupled import solve_transient
from electrotherm.thermal import ThermalEnvironment


def test_pulsed_current_transient_tracks_profile():
    geometry = WireGeometry(diameter=0.003, length=1.0)
    env = ThermalEnvironment(ambient_temperature=298.15, fixed_convection_coefficient=20.0)
    pulse = PulsedCurrent(amplitude=800.0, baseline=0.0, period=4.0, duty_cycle=0.25)

    t_eval = np.linspace(0, 20.0, 401)
    result = solve_transient(
        geometry=geometry, material=COPPER, environment=env, load_profile=pulse,
        t_span=(0, 20.0), t_eval=t_eval,
    )

    currents = np.array(result.currents_a)
    # the reported currents should reproduce the pulse shape: mix of ~0 and ~800A
    assert currents.max() > 750.0
    assert currents.min() < 1.0


def test_pulsed_load_raises_temperature_above_baseline_idle():
    geometry = WireGeometry(diameter=0.0025, length=1.0)
    env = ThermalEnvironment(ambient_temperature=298.15, fixed_convection_coefficient=20.0)
    pulse = PulsedCurrent(amplitude=600.0, baseline=0.0, period=2.0, duty_cycle=0.5)

    result = solve_transient(
        geometry=geometry, material=COPPER, environment=env, load_profile=pulse,
        t_span=(0, 60.0), t_eval=np.linspace(0, 60.0, 121),
    )
    assert max(t[0] for t in result.temperatures_k) > env.ambient_temperature


def test_cumulative_thermal_behaviour_increases_over_pulses():
    """Peak temperature should trend upward pulse-over-pulse until the
    conductor approaches thermal equilibrium (cumulative heating)."""
    geometry = WireGeometry(diameter=0.002, length=1.0)
    env = ThermalEnvironment(ambient_temperature=298.15, fixed_convection_coefficient=12.0)
    pulse = PulsedCurrent(amplitude=700.0, baseline=50.0, period=5.0, duty_cycle=0.4)

    t_eval = np.linspace(0, 40.0, 801)
    result = solve_transient(
        geometry=geometry, material=COPPER, environment=env, load_profile=pulse,
        t_span=(0, 40.0), t_eval=t_eval,
    )
    temps = [t[0] for t in result.temperatures_k]
    # peak of the first pulse cycle vs. peak of the last pulse cycle
    first_cycle_peak = max(temps[:100])
    last_cycle_peak = max(temps[-100:])
    assert last_cycle_peak >= first_cycle_peak
