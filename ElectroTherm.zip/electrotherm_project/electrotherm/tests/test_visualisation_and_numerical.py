import matplotlib
matplotlib.use("Agg")  # headless backend for CI/test environments

import numpy as np
import pytest

from electrotherm.geometry import WireGeometry
from electrotherm.materials import COPPER
from electrotherm.numerical import (
    numba_available, resistivity_array, coupled_rhs,
)
from electrotherm.simulation.coupled import solve_transient
from electrotherm.thermal import ThermalEnvironment
from electrotherm.visualisation import (
    plot_temperature_vs_time, plot_current_vs_time, plot_power_loss_vs_time,
    plot_resistance_vs_temperature, plot_temperature_distribution,
    ascii_conductor_bar,
)

ENV = ThermalEnvironment(ambient_temperature=298.15, fixed_convection_coefficient=15.0)
GEOM = WireGeometry(diameter=0.003, length=2.0)


@pytest.fixture()
def transient_result():
    return solve_transient(geometry=GEOM, material=COPPER, environment=ENV, current=80.0,
                            t_span=(0, 60.0), t_eval=np.linspace(0, 60.0, 30))


def test_matplotlib_plots_return_axes(transient_result):
    assert plot_temperature_vs_time(transient_result) is not None
    assert plot_current_vs_time(transient_result) is not None
    assert plot_power_loss_vs_time(transient_result) is not None
    assert plot_resistance_vs_temperature(COPPER, 273.15, 473.15, geometry=GEOM) is not None
    assert plot_temperature_distribution(transient_result.temperatures_k[-1]) is not None


def test_ascii_conductor_bar_shape():
    bar = ascii_conductor_bar([25.0, 40.0, 90.0, 40.0, 25.0], width=20)
    lines = bar.splitlines()
    assert "COLD" in lines[0] and "HOT" in lines[0]
    bar_line = lines[1][:20]
    assert len(bar_line) == 20
    assert all(c in " .:-=+*#%@" for c in bar_line)


def test_resistivity_array_matches_scalar_formula():
    temps = np.array([280.0, 300.0, 350.0])
    rho0, alpha, t0 = COPPER.resistivity_ref, COPPER.temp_coefficient_resistance, COPPER.reference_temperature
    arr = resistivity_array(temps, rho0, alpha, t0)
    for t, r in zip(temps, arr):
        assert r == pytest.approx(COPPER.resistivity(float(t)))


def test_numba_available_is_bool():
    assert isinstance(numba_available(), bool)


def test_coupled_rhs_zero_at_equilibrium_lumped():
    # a hand-built single-cell equilibrium: choose T such that P == Q_conv
    T = np.array([350.0])
    rho0, alpha, t0 = 1.7e-8, 0.0, 293.15
    L, A = np.array([1.0]), np.array([1e-5])
    surface = np.array([0.02])
    h = np.array([10.0])
    eps = np.array([0.0])
    ambient = 300.0
    k_thermal = np.array([400.0])
    mass_cp = np.array([1.0])

    # solve current analytically for equilibrium at T=350K:
    R = rho0 * L[0] / A[0]
    q_conv = h[0] * surface[0] * (T[0] - ambient)
    current = (q_conv / R) ** 0.5

    dTdt = coupled_rhs(T, current, rho0, alpha, t0, L, A, surface, h, eps, ambient,
                        k_thermal, A[0], 1.0, mass_cp)
    assert dTdt[0] == pytest.approx(0.0, abs=1e-6)
