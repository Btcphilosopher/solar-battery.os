import pytest

from electrotherm.electrical import (
    voltage, current_from_voltage, resistance_from_vi,
    power_vi, power_i2r, power_v2r,
    ConstantCurrent, PulsedCurrent, MultiStepPulseTrain, VariableLoad,
)


def test_ohms_law_round_trip():
    i, r = 10.0, 5.0
    v = voltage(i, r)
    assert v == pytest.approx(50.0)
    assert current_from_voltage(v, r) == pytest.approx(i)
    assert resistance_from_vi(v, i) == pytest.approx(r)


def test_power_relationships_agree():
    v, i, r = 12.0, 3.0, 4.0  # V = IR holds here
    assert power_vi(v, i) == pytest.approx(power_i2r(i, r))
    assert power_vi(v, i) == pytest.approx(power_v2r(v, r))


def test_constant_current_profile():
    load = ConstantCurrent(current=42.0)
    assert load.current_at(0.0) == 42.0
    assert load.current_at(1000.0) == 42.0


def test_pulsed_current_duty_cycle():
    pulse = PulsedCurrent(amplitude=1000.0, baseline=0.0, period=10.0, duty_cycle=0.3)
    assert pulse.current_at(1.0) == pytest.approx(1000.0)  # inside "on" window
    assert pulse.current_at(5.0) == pytest.approx(0.0)      # inside "off" window
    # cycle repeats
    assert pulse.current_at(11.0) == pytest.approx(pulse.current_at(1.0))


def test_pulsed_current_with_ramps():
    pulse = PulsedCurrent(amplitude=500.0, baseline=0.0, period=4.0, duty_cycle=0.5, rise_time=1.0, fall_time=1.0)
    assert pulse.current_at(0.0) == pytest.approx(0.0)
    assert pulse.current_at(0.5) == pytest.approx(250.0)
    assert pulse.current_at(1.0) == pytest.approx(500.0)


def test_multi_step_pulse_train():
    train = MultiStepPulseTrain(levels=[0, 500, 1000, 500, 0], durations=[1, 1, 1, 1, 1])
    assert train.current_at(0.5) == 0
    assert train.current_at(1.5) == 500
    assert train.current_at(2.5) == 1000
    assert train.current_at(5.5) == 0  # cycle repeats (period = 5s)


def test_variable_load_interpolates():
    load = VariableLoad(times=[0, 10], currents=[0, 100])
    assert load.current_at(5.0) == pytest.approx(50.0)
