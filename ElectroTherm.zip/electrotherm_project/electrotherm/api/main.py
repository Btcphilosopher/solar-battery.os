"""
electrotherm.api.main
=======================

FastAPI service exposing the ElectroTherm engine over HTTP.

Endpoints
---------
    POST /simulate              steady-state electro-thermal solve
    POST /simulate/transient    transient (time-domain) solve
    POST /optimise              conductor design optimisation
    POST /sweep                 parameter sweep -> performance map
    GET  /materials             list built-in materials
    GET  /simulation/{id}       fetch a stored simulation request+result
    GET  /results/{id}          fetch just the stored result

Run with:

    uvicorn electrotherm.api.main:app --reload
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any

import numpy as np
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from electrotherm.core.models import ETBaseModel
from electrotherm.electrical import ConstantCurrent, PulsedCurrent
from electrotherm.geometry import AnyGeometry
from electrotherm.materials import MATERIAL_LIBRARY, Material, get_material
from electrotherm.optimisation.design import DesignResult, smallest_wire_for_current
from electrotherm.optimisation.optimiser import (
    OptimisationConstraints,
    OptimisationResult,
    OptimisationWeights,
    optimise_conductor,
)
from electrotherm.optimisation.sweep import parameter_sweep
from electrotherm.simulation.coupled import solve_steady_state, solve_transient
from electrotherm.simulation.results import SteadyStateResult, TransientResult
from electrotherm.thermal import ThermalEnvironment

app = FastAPI(
    title="ElectroTherm API",
    description=(
        "Coupled electro-thermal conductor simulation and optimisation "
        "engine. All results are numerical-model outputs and require "
        "independent engineering validation before use in a certified "
        "or safety-critical design."
    ),
    version="0.1.0",
)

# In-memory result store keyed by simulation id. A production deployment
# would swap this for a database/object-store, without changing the
# solver API above it.
_STORE: dict[str, dict[str, Any]] = {}


def _store(kind: str, request: BaseModel, result: BaseModel) -> str:
    sim_id = str(uuid.uuid4())
    _STORE[sim_id] = {
        "id": sim_id,
        "kind": kind,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "request": request.model_dump(),
        "result": result.model_dump(),
    }
    return sim_id


# ---------------------------------------------------------------------------
# Request / response schemas
# ---------------------------------------------------------------------------


class SteadyStateRequest(ETBaseModel):
    geometry: AnyGeometry
    material: Material
    environment: ThermalEnvironment
    current_a: float | None = None
    voltage_v: float | None = None
    num_cells: int = Field(default=1, ge=1)


class SteadyStateResponse(ETBaseModel):
    id: str
    result: SteadyStateResult


class TransientRequest(ETBaseModel):
    geometry: AnyGeometry
    material: Material
    environment: ThermalEnvironment
    t_start_s: float = 0.0
    t_end_s: float
    n_points: int = Field(default=200, ge=2)
    current_a: float | None = None
    voltage_v: float | None = None
    pulse: PulsedCurrent | None = None
    num_cells: int = Field(default=1, ge=1)
    initial_temperature_k: float | None = None


class TransientResponse(ETBaseModel):
    id: str
    result: TransientResult


class OptimiseRequest(ETBaseModel):
    material_names: list[str] = Field(default_factory=lambda: ["copper", "aluminium"])
    current_a: float
    length_m: float
    environment: ThermalEnvironment
    max_temperature_c: float
    max_current_density_a_mm2: float | None = None
    max_voltage_drop_v: float | None = None
    electricity_price_per_kwh: float = 0.15


class OptimiseResponse(ETBaseModel):
    id: str
    result: OptimisationResult


class DesignRequest(ETBaseModel):
    material_name: str = "copper"
    current_a: float
    length_m: float
    environment: ThermalEnvironment
    max_temperature_c: float


class DesignResponse(ETBaseModel):
    id: str
    result: DesignResult


class SweepRequest(ETBaseModel):
    material_name: str = "copper"
    length_m: float
    environment: ThermalEnvironment
    diameters_mm: list[float]
    currents_a: list[float]
    num_cells: int = 1


class SweepResponse(ETBaseModel):
    id: str
    rows: list[dict[str, Any]]


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@app.get("/materials")
def list_materials() -> dict[str, Any]:
    return {
        name: {
            "name": m.name,
            "resistivity_ref": m.resistivity_ref,
            "temp_coefficient_resistance": m.temp_coefficient_resistance,
            "thermal_conductivity_ref": m.thermal_conductivity_ref,
            "density": m.density,
            "specific_heat_ref": m.specific_heat_ref,
            "melting_point": m.melting_point,
            "max_operating_temperature": m.max_operating_temperature,
        }
        for name, m in MATERIAL_LIBRARY.items()
    }


@app.post("/simulate", response_model=SteadyStateResponse)
def simulate(req: SteadyStateRequest) -> SteadyStateResponse:
    if (req.current_a is None) == (req.voltage_v is None):
        raise HTTPException(400, "Provide exactly one of current_a or voltage_v")
    result = solve_steady_state(
        geometry=req.geometry, material=req.material, environment=req.environment,
        current=req.current_a, voltage=req.voltage_v, num_cells=req.num_cells,
    )
    sim_id = _store("steady_state", req, result)
    return SteadyStateResponse(id=sim_id, result=result)


@app.post("/simulate/transient", response_model=TransientResponse)
def simulate_transient(req: TransientRequest) -> TransientResponse:
    n_sources = sum(x is not None for x in (req.current_a, req.voltage_v, req.pulse))
    if n_sources != 1:
        raise HTTPException(400, "Provide exactly one of current_a, voltage_v, or pulse")
    t_eval = np.linspace(req.t_start_s, req.t_end_s, req.n_points)
    result = solve_transient(
        geometry=req.geometry, material=req.material, environment=req.environment,
        t_span=(req.t_start_s, req.t_end_s), t_eval=t_eval,
        current=req.current_a, voltage=req.voltage_v, load_profile=req.pulse,
        num_cells=req.num_cells, initial_temperature_k=req.initial_temperature_k,
    )
    sim_id = _store("transient", req, result)
    return TransientResponse(id=sim_id, result=result)


@app.post("/optimise", response_model=OptimiseResponse)
def optimise(req: OptimiseRequest) -> OptimiseResponse:
    try:
        materials = [get_material(name) for name in req.material_names]
    except KeyError as exc:
        raise HTTPException(400, str(exc)) from exc
    constraints = OptimisationConstraints(
        max_temperature_c=req.max_temperature_c,
        max_current_density_a_mm2=req.max_current_density_a_mm2,
        max_voltage_drop_v=req.max_voltage_drop_v,
    )
    weights = OptimisationWeights(electricity_price_per_kwh=req.electricity_price_per_kwh)
    result = optimise_conductor(
        candidate_materials=materials, current_a=req.current_a, length_m=req.length_m,
        environment=req.environment, constraints=constraints, weights=weights,
    )
    sim_id = _store("optimise", req, result)
    return OptimiseResponse(id=sim_id, result=result)


@app.post("/design", response_model=DesignResponse)
def design(req: DesignRequest) -> DesignResponse:
    try:
        material = get_material(req.material_name)
    except KeyError as exc:
        raise HTTPException(400, str(exc)) from exc
    result = smallest_wire_for_current(
        material=material, current_a=req.current_a, length_m=req.length_m,
        environment=req.environment, max_temperature_c=req.max_temperature_c,
    )
    sim_id = _store("design", req, result)
    return DesignResponse(id=sim_id, result=result)


@app.post("/sweep", response_model=SweepResponse)
def sweep(req: SweepRequest) -> SweepResponse:
    try:
        material = get_material(req.material_name)
    except KeyError as exc:
        raise HTTPException(400, str(exc)) from exc

    from electrotherm.geometry import WireGeometry

    def case_builder(params: dict[str, Any]) -> dict[str, Any]:
        geometry = WireGeometry(diameter=params["diameter_mm"] / 1000.0, length=req.length_m)
        return dict(geometry=geometry, material=material, environment=req.environment,
                    current=params["current_a"], num_cells=req.num_cells)

    df = parameter_sweep(
        case_builder,
        {"diameter_mm": req.diameters_mm, "current_a": req.currents_a},
        engine="thread",
    )
    rows = df.to_dicts()
    sim_id = str(uuid.uuid4())
    _STORE[sim_id] = {"id": sim_id, "kind": "sweep", "created_at": datetime.now(timezone.utc).isoformat(),
                       "request": req.model_dump(), "result": {"rows": rows}}
    return SweepResponse(id=sim_id, rows=rows)


@app.get("/simulation/{sim_id}")
def get_simulation(sim_id: str) -> dict[str, Any]:
    if sim_id not in _STORE:
        raise HTTPException(404, "simulation not found")
    return _STORE[sim_id]


@app.get("/results/{sim_id}")
def get_result(sim_id: str) -> dict[str, Any]:
    if sim_id not in _STORE:
        raise HTTPException(404, "simulation not found")
    return _STORE[sim_id]["result"]


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}
