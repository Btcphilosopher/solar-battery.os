"""
electrotherm.api
==================

FastAPI service layer exposing the ElectroTherm engine over HTTP.
See :mod:`electrotherm.api.main` for the application and endpoints.
Run with::

    uvicorn electrotherm.api.main:app --reload
"""

from electrotherm.api.main import app

__all__ = ["app"]
