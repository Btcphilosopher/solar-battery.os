"""
electrotherm.geometry
=======================

Conductor cross-section and geometry models: wires, rods, busbars,
strips, PCB traces, cables and arbitrary custom cross-sections.

Every geometry exposes the same physical-quantity interface so the
electrical/thermal solvers can stay geometry-agnostic:

    cross_sectional_area()  -> m^2
    length                  -> m
    perimeter()             -> m   (wetted/exposed perimeter of the
                                     cross-section, used for convective
                                     and radiative surface area)
    surface_area()          -> m^2 (total exposed lateral surface area)
    volume()                -> m^3
    mass(material)          -> kg
    resistance(material, T) -> ohm   (R = rho(T) * L / A)
"""

from __future__ import annotations

import math
from abc import ABC, abstractmethod
from typing import Annotated, Literal, Union

from pydantic import Field, model_validator

from electrotherm.core.models import ETBaseModel
from electrotherm.materials import Material


class ConductorGeometry(ETBaseModel, ABC):
    """Abstract base class for all conductor cross-section geometries."""

    length: float = Field(gt=0, description="Conductor length, metres")

    @abstractmethod
    def cross_sectional_area(self) -> float:
        """Cross-sectional area, m^2."""

    @abstractmethod
    def perimeter(self) -> float:
        """Cross-section perimeter exposed to the environment, m."""

    def surface_area(self) -> float:
        """Total lateral (exposed) surface area, m^2."""
        return self.perimeter() * self.length

    def volume(self) -> float:
        return self.cross_sectional_area() * self.length

    def mass(self, material: Material) -> float:
        return self.volume() * material.density

    def resistance(self, material: Material, temperature_k: float) -> float:
        """R = rho(T) * L / A"""
        return material.resistivity(temperature_k) * self.length / self.cross_sectional_area()

    def current_density(self, current_a: float) -> float:
        """J = I / A, A/m^2."""
        return current_a / self.cross_sectional_area()

    def sub_length_geometry(self, sub_length: float) -> "ConductorGeometry":
        """Return a copy of this geometry with a different (shorter) length.

        Used by the spatial model to build per-cell geometries that share
        the parent cross-section.
        """
        clone = self.model_copy(update={"length": sub_length})
        return clone


class WireGeometry(ConductorGeometry):
    """Solid round wire / rod of circular cross-section."""

    kind: Literal["wire"] = "wire"
    diameter: float = Field(gt=0, description="Wire diameter, metres")

    def cross_sectional_area(self) -> float:
        return math.pi * self.diameter ** 2 / 4.0

    def perimeter(self) -> float:
        return math.pi * self.diameter


class RodGeometry(WireGeometry):
    """Alias of WireGeometry: a solid cylindrical rod."""

    kind: Literal["rod"] = "rod"


class CylindricalConductorGeometry(ConductorGeometry):
    """Solid or hollow (tubular) cylindrical conductor."""

    kind: Literal["cylindrical"] = "cylindrical"
    outer_diameter: float = Field(gt=0)
    inner_diameter: float = Field(default=0.0, ge=0.0)

    @model_validator(mode="after")
    def _check_diameters(self) -> "CylindricalConductorGeometry":
        if self.inner_diameter >= self.outer_diameter:
            raise ValueError("inner_diameter must be smaller than outer_diameter")
        return self

    def cross_sectional_area(self) -> float:
        return math.pi * (self.outer_diameter ** 2 - self.inner_diameter ** 2) / 4.0

    def perimeter(self) -> float:
        # outer + inner (bore) exposed surfaces
        return math.pi * (self.outer_diameter + self.inner_diameter)


class RectangularConductorGeometry(ConductorGeometry):
    """Generic solid rectangular conductor (bar / strip / busbar base)."""

    kind: Literal["rectangular"] = "rectangular"
    width: float = Field(gt=0, description="metres")
    thickness: float = Field(gt=0, description="metres")

    def cross_sectional_area(self) -> float:
        return self.width * self.thickness

    def perimeter(self) -> float:
        return 2.0 * (self.width + self.thickness)


class BusbarGeometry(RectangularConductorGeometry):
    """Rectangular busbar. Optionally stacked as N parallel bars with a gap."""

    kind: Literal["busbar"] = "busbar"
    num_bars: int = Field(default=1, ge=1)
    bar_gap: float = Field(default=0.0, ge=0.0, description="metres between stacked bars")

    def cross_sectional_area(self) -> float:
        return self.num_bars * self.width * self.thickness

    def perimeter(self) -> float:
        # each bar exposes its own perimeter; stacking reduces mutual
        # convective/radiative efficiency, approximated by exposing all
        # bar perimeters (conservative for widely spaced bars).
        return self.num_bars * 2.0 * (self.width + self.thickness)


class StripGeometry(RectangularConductorGeometry):
    """Thin conductive strip/foil (width >> thickness)."""

    kind: Literal["strip"] = "strip"


class PCBTraceGeometry(ConductorGeometry):
    """Copper PCB trace on a substrate (IPC-2152 style geometry).

    Only the trace's own cross-section carries current; the substrate is
    accounted for separately via the thermal environment (conduction into
    the board is modelled as an equivalent convection coefficient boost,
    configurable by the caller).
    """

    kind: Literal["pcb_trace"] = "pcb_trace"
    trace_width: float = Field(gt=0, description="metres")
    copper_thickness: float = Field(gt=0, description="metres (e.g. 35e-6 for 1oz copper)")
    #: fraction (0-1) of the trace edge that is thermally coupled into the
    #: board vs. exposed to ambient air on top; used only as metadata for
    #: environment models, not in area calculations.
    board_coupling_factor: float = Field(default=0.5, ge=0.0, le=1.0)

    def cross_sectional_area(self) -> float:
        return self.trace_width * self.copper_thickness

    def perimeter(self) -> float:
        return 2.0 * (self.trace_width + self.copper_thickness)


class CableGeometry(ConductorGeometry):
    """Stranded cable: many round strands bundled into a nominal diameter.

    The conductive area is the sum of individual strand areas (a fill
    factor slightly below 1 to allow for the interstitial gaps between
    round strands); the exposed perimeter is approximated as the outer
    bundle circumference.
    """

    kind: Literal["cable"] = "cable"
    strand_diameter: float = Field(gt=0, description="metres")
    num_strands: int = Field(gt=0)
    #: bundle packing fill factor (fraction of the nominal bundle circle
    #: that is actually copper); ~0.75-0.9 for typical concentric-lay cable.
    fill_factor: float = Field(default=0.85, gt=0.0, le=1.0)

    def strand_area(self) -> float:
        return math.pi * self.strand_diameter ** 2 / 4.0

    def cross_sectional_area(self) -> float:
        return self.num_strands * self.strand_area()

    def nominal_bundle_diameter(self) -> float:
        copper_area = self.cross_sectional_area()
        bundle_area = copper_area / self.fill_factor
        return math.sqrt(4.0 * bundle_area / math.pi)

    def perimeter(self) -> float:
        return math.pi * self.nominal_bundle_diameter()


class CustomGeometry(ConductorGeometry):
    """Arbitrary cross-section defined directly by its area and perimeter.

    Use this for extruded / machined / non-standard profiles where the
    area and wetted perimeter have been computed externally (e.g. from a
    CAD export or a polygon integration).
    """

    kind: Literal["custom"] = "custom"
    area_m2: float = Field(gt=0)
    perimeter_m: float = Field(gt=0)

    def cross_sectional_area(self) -> float:
        return self.area_m2

    def perimeter(self) -> float:
        return self.perimeter_m

    @classmethod
    def from_polygon(cls, points: list[tuple[float, float]], length: float) -> "CustomGeometry":
        """Build a CustomGeometry from a closed polygon (list of (x, y) in
        metres) using the shoelace formula for area and summed edge
        lengths for the perimeter.
        """
        n = len(points)
        if n < 3:
            raise ValueError("A polygon needs at least 3 points")
        area2 = 0.0
        perim = 0.0
        for i in range(n):
            x1, y1 = points[i]
            x2, y2 = points[(i + 1) % n]
            area2 += x1 * y2 - x2 * y1
            perim += math.hypot(x2 - x1, y2 - y1)
        area = abs(area2) / 2.0
        return cls(area_m2=area, perimeter_m=perim, length=length)


#: Discriminated union of every concrete geometry type, keyed on the
#: ``kind`` field. Use this annotation anywhere a geometry needs to be
#: polymorphically (de)serialised, e.g. in :class:`DigitalConductor` or
#: the FastAPI request/response models.
AnyGeometry = Annotated[
    Union[
        WireGeometry,
        RodGeometry,
        CylindricalConductorGeometry,
        RectangularConductorGeometry,
        BusbarGeometry,
        StripGeometry,
        PCBTraceGeometry,
        CableGeometry,
        CustomGeometry,
    ],
    Field(discriminator="kind"),
]

__all__ = [
    "ConductorGeometry",
    "WireGeometry",
    "RodGeometry",
    "CylindricalConductorGeometry",
    "RectangularConductorGeometry",
    "BusbarGeometry",
    "StripGeometry",
    "PCBTraceGeometry",
    "CableGeometry",
    "CustomGeometry",
    "AnyGeometry",
]
