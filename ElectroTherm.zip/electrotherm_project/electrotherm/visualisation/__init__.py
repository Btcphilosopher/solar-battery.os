"""
electrotherm.visualisation
=============================

Engineering plots for ElectroTherm results: matplotlib static figures
for reports, Plotly interactive figures for exploration, and a
lightweight ASCII "cold -> hot" conductor bar for terminal output.
"""

from __future__ import annotations

import numpy as np

from electrotherm.core.units import kelvin_to_celsius
from electrotherm.simulation.results import SteadyStateResult, TransientResult

# ---------------------------------------------------------------------------
# Matplotlib (static) plots
# ---------------------------------------------------------------------------


def plot_temperature_vs_time(result: TransientResult, ax=None, celsius: bool = True):
    import matplotlib.pyplot as plt

    if ax is None:
        _, ax = plt.subplots()
    t = np.array(result.times_s)
    T = np.array(result.temperatures_k)
    n_cells = T.shape[1]
    for i in range(n_cells):
        y = kelvin_to_celsius(T[:, i]) if celsius else T[:, i]
        label = "temperature" if n_cells == 1 else f"cell {i + 1}"
        ax.plot(t, y, label=label)
    ax.set_xlabel("time (s)")
    ax.set_ylabel("temperature (degC)" if celsius else "temperature (K)")
    ax.set_title("Temperature vs. time")
    if n_cells > 1:
        ax.legend(fontsize=8)
    ax.grid(True, alpha=0.3)
    return ax


def plot_current_vs_time(result: TransientResult, ax=None):
    import matplotlib.pyplot as plt

    if ax is None:
        _, ax = plt.subplots()
    ax.plot(result.times_s, result.currents_a, color="tab:orange")
    ax.set_xlabel("time (s)")
    ax.set_ylabel("current (A)")
    ax.set_title("Current vs. time")
    ax.grid(True, alpha=0.3)
    return ax


def plot_power_loss_vs_time(result: TransientResult, ax=None):
    import matplotlib.pyplot as plt

    if ax is None:
        _, ax = plt.subplots()
    ax.plot(result.times_s, result.power_loss_w, color="tab:red")
    ax.set_xlabel("time (s)")
    ax.set_ylabel("power loss (W)")
    ax.set_title("Joule power loss vs. time")
    ax.grid(True, alpha=0.3)
    return ax


def plot_resistance_vs_temperature(material, t_min_k: float, t_max_k: float, geometry=None, ax=None, n=200):
    import matplotlib.pyplot as plt

    if ax is None:
        _, ax = plt.subplots()
    temps = np.linspace(t_min_k, t_max_k, n)
    if geometry is not None:
        y = np.array([geometry.resistance(material, float(t)) for t in temps])
        ylabel = "resistance (ohm)"
    else:
        y = np.array([material.resistivity(float(t)) for t in temps])
        ylabel = "resistivity (ohm*m)"
    ax.plot(kelvin_to_celsius(temps), y, color="tab:blue")
    ax.set_xlabel("temperature (degC)")
    ax.set_ylabel(ylabel)
    ax.set_title(f"{ylabel.split(' ')[0].capitalize()} vs. temperature - {material.name}")
    ax.grid(True, alpha=0.3)
    return ax


def plot_temperature_distribution(temperatures_k: list[float], cell_positions_m: list[float] | None = None, ax=None):
    """Bar/line plot of the per-cell steady/instantaneous temperature
    distribution along the conductor's length (1D spatial model).
    """
    import matplotlib.pyplot as plt

    if ax is None:
        _, ax = plt.subplots()
    n = len(temperatures_k)
    x = cell_positions_m if cell_positions_m is not None else list(range(1, n + 1))
    y = kelvin_to_celsius(np.array(temperatures_k))
    ax.bar(x, y, color=plt.cm.inferno(np.interp(y, (y.min(), y.max() + 1e-9), (0.2, 0.95))))
    ax.set_xlabel("cell position" if cell_positions_m is None else "position (m)")
    ax.set_ylabel("temperature (degC)")
    ax.set_title("Temperature distribution along conductor")
    return ax


def plot_current_density(current_density_a_mm2: list[float], cell_positions_m: list[float] | None = None, ax=None):
    import matplotlib.pyplot as plt

    if ax is None:
        _, ax = plt.subplots()
    n = len(current_density_a_mm2)
    x = cell_positions_m if cell_positions_m is not None else list(range(1, n + 1))
    ax.bar(x, current_density_a_mm2, color="tab:purple")
    ax.set_xlabel("cell position" if cell_positions_m is None else "position (m)")
    ax.set_ylabel("current density (A/mm^2)")
    ax.set_title("Current density along conductor")
    return ax


def plot_transient_heatmap(result: TransientResult, ax=None):
    """2D heatmap of temperature (cell index x time) for a spatial
    transient simulation."""
    import matplotlib.pyplot as plt

    if ax is None:
        _, ax = plt.subplots()
    T = kelvin_to_celsius(np.array(result.temperatures_k)).T  # cells x time
    im = ax.imshow(T, aspect="auto", origin="lower", cmap="inferno",
                    extent=[result.times_s[0], result.times_s[-1], 1, T.shape[0]])
    ax.set_xlabel("time (s)")
    ax.set_ylabel("cell index")
    ax.set_title("Temperature heatmap (space x time)")
    plt.colorbar(im, ax=ax, label="temperature (degC)")
    return ax


# ---------------------------------------------------------------------------
# Plotly (interactive) plots
# ---------------------------------------------------------------------------


def plotly_temperature_vs_time(result: TransientResult, celsius: bool = True):
    import plotly.graph_objects as go

    t = result.times_s
    T = np.array(result.temperatures_k)
    fig = go.Figure()
    for i in range(T.shape[1]):
        y = kelvin_to_celsius(T[:, i]) if celsius else T[:, i]
        fig.add_trace(go.Scatter(x=t, y=y, mode="lines", name=f"cell {i + 1}"))
    fig.update_layout(
        title="Temperature vs. time", xaxis_title="time (s)",
        yaxis_title="temperature (degC)" if celsius else "temperature (K)",
    )
    return fig


def plotly_sweep_surface(df, x: str, y: str, z: str):
    """3D surface / heatmap of a parameter-sweep DataFrame (e.g. current x
    ambient_temperature -> max_temperature_c).
    """
    import plotly.graph_objects as go

    xs = sorted(df[x].unique().to_list())
    ys = sorted(df[y].unique().to_list())
    grid = np.zeros((len(ys), len(xs)))
    for i, yv in enumerate(ys):
        for j, xv in enumerate(xs):
            match = df.filter((df[x] == xv) & (df[y] == yv))
            grid[i, j] = match[z][0] if match.height > 0 else np.nan
    fig = go.Figure(data=go.Surface(x=xs, y=ys, z=grid))
    fig.update_layout(title=f"{z} vs. {x} & {y}", scene=dict(
        xaxis_title=x, yaxis_title=y, zaxis_title=z,
    ))
    return fig


def plotly_current_density_heatmap(temperatures_k: list[list[float]], times_s: list[float]):
    import plotly.graph_objects as go

    T = kelvin_to_celsius(np.array(temperatures_k)).T
    fig = go.Figure(data=go.Heatmap(z=T, x=times_s, y=list(range(1, T.shape[0] + 1)), colorscale="Inferno"))
    fig.update_layout(title="Temperature heatmap", xaxis_title="time (s)", yaxis_title="cell index")
    return fig


# ---------------------------------------------------------------------------
# ASCII "cold -> hot" conductor bar, for terminal / log output
# ---------------------------------------------------------------------------

_ASCII_RAMP = " .:-=+*#%@"


def ascii_conductor_bar(temperatures_c: list[float], t_cold_c: float | None = None,
                         t_hot_c: float | None = None, width: int = 40) -> str:
    """Render a text "COLD -> HOT" bar representing the temperature
    profile along the conductor, e.g.::

        COLD ─────────────── HOT
        ############%%%%%%%%%%%%
    """
    arr = np.array(temperatures_c, dtype=float)
    lo = t_cold_c if t_cold_c is not None else float(arr.min())
    hi = t_hot_c if t_hot_c is not None else float(arr.max())
    hi = hi if hi > lo else lo + 1.0

    # resample the per-cell profile onto `width` characters
    if len(arr) == 1:
        resampled = np.full(width, arr[0])
    else:
        xp = np.linspace(0, 1, len(arr))
        xi = np.linspace(0, 1, width)
        resampled = np.interp(xi, xp, arr)

    idx = np.clip(((resampled - lo) / (hi - lo) * (len(_ASCII_RAMP) - 1)).astype(int), 0, len(_ASCII_RAMP) - 1)
    bar = "".join(_ASCII_RAMP[i] for i in idx)
    header = "COLD " + "─" * (width - 10) + " HOT"
    return f"{header}\n{bar}  ({lo:.1f}C - {hi:.1f}C)"


__all__ = [
    "plot_temperature_vs_time",
    "plot_current_vs_time",
    "plot_power_loss_vs_time",
    "plot_resistance_vs_temperature",
    "plot_temperature_distribution",
    "plot_current_density",
    "plot_transient_heatmap",
    "plotly_temperature_vs_time",
    "plotly_sweep_surface",
    "plotly_current_density_heatmap",
    "ascii_conductor_bar",
]
