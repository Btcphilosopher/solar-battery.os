"""
ElectroTherm
============

A high-performance Python simulator and optimisation engine for
electro-thermal conductors, cables, busbars, traces and conductive
materials.

ElectroTherm treats electricity and temperature as a single coupled
physical system:

    Current -> Resistance -> Joule Heating -> Temperature
       ^                                          |
       |                                          v
       +---------- Material Properties <----------+

All public sub-packages are re-exported here for convenience so that
typical usage looks like::

    import electrotherm as et

    copper = et.materials.COPPER
    geom = et.geometry.WireGeometry(diameter=0.005, length=2.0)
    conductor = et.simulation.DigitalConductor(material=copper, geometry=geom)
    result = et.simulation.solve_steady_state(conductor, current=100.0,
                                               environment=et.thermal.STILL_AIR)

Every simulation output is an *engineering estimate produced by a
numerical model* and requires independent engineering validation before
being used for safety-critical or certified design work.
"""

from __future__ import annotations

__version__ = "0.1.0"

from electrotherm import core  # noqa: E402
from electrotherm import materials  # noqa: E402
from electrotherm import geometry  # noqa: E402
from electrotherm import electrical  # noqa: E402
from electrotherm import thermal  # noqa: E402
from electrotherm import numerical  # noqa: E402
from electrotherm import simulation  # noqa: E402
from electrotherm import optimisation  # noqa: E402
from electrotherm import visualisation  # noqa: E402

__all__ = [
    "__version__",
    "core",
    "materials",
    "geometry",
    "electrical",
    "thermal",
    "numerical",
    "simulation",
    "optimisation",
    "visualisation",
]
