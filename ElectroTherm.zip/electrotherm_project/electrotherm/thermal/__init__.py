"""
electrotherm.thermal
======================

Thermal solver primitives: conduction, convection and radiation heat
transfer, and configurable thermal boundary / environment models.

Heat loss from a conductor surface to its environment is modelled as
the sum of convective and radiative terms:

    Q_conv = h * A_surface * (T_surface - T_ambient)
    Q_rad  = eps * sigma * A_surface * (T_surface^4 - T_ambient^4)

``h`` (the convection coefficient, W/(m^2 K)) can either be supplied
directly or estimated from simplified natural/forced convection
correlations for a horizontal cylinder, which are adequate for
engineering-scale conductor simulation (wires, rods, cables, busbars).
"""

from __future__ import annotations

import enum
import math

import numpy as np
from pydantic import Field

from electrotherm.core.models import ETBaseModel
from electrotherm.core.units import STEFAN_BOLTZMANN, GRAVITY

# ---------------------------------------------------------------------------
# Air properties (approximate, at ~1 atm) used by the convection
# correlations. Evaluated at the film temperature T_film = (Ts+Tamb)/2.
# ---------------------------------------------------------------------------


def _air_properties(t_film_k: float) -> dict:
    """Approximate temperature-dependent properties of air at 1 atm.

    Simple linear/empirical fits valid roughly over 250-600 K, adequate
    for engineering-grade convection estimates.
    """
    t = t_film_k
    k = 0.0243 + 7.6e-5 * (t - 300.0)  # W/(m*K)
    nu = 1.51e-5 + 9.5e-8 * (t - 300.0)  # kinematic viscosity, m^2/s
    alpha = 2.12e-5 + 1.3e-7 * (t - 300.0)  # thermal diffusivity, m^2/s
    pr = nu / alpha if alpha > 0 else 0.71
    beta = 1.0 / t  # thermal expansion coefficient of ideal gas, 1/K
    return {"k": max(k, 1e-4), "nu": max(nu, 1e-7), "alpha": max(alpha, 1e-7),
            "pr": pr, "beta": beta}


def natural_convection_coefficient_cylinder(
    surface_temp_k: float,
    ambient_temp_k: float,
    diameter_m: float,
) -> float:
    """Estimate h (W/m^2K) for free (natural) convection from a
    long horizontal cylinder using the Churchill-Chu correlation.
    """
    dt = abs(surface_temp_k - ambient_temp_k)
    if dt < 1e-9 or diameter_m <= 0:
        return 2.0  # negligible-dT floor, still-air baseline
    t_film = (surface_temp_k + ambient_temp_k) / 2.0
    props = _air_properties(t_film)
    ra = (
        GRAVITY * props["beta"] * dt * diameter_m ** 3
        / (props["nu"] * props["alpha"])
    )
    pr = props["pr"]
    # Churchill-Chu (valid for Ra <= 1e12)
    numerator = 0.60 + 0.387 * ra ** (1.0 / 6.0)
    denom = (1.0 + (0.559 / pr) ** (9.0 / 16.0)) ** (8.0 / 27.0)
    nu_sqrt = numerator / denom
    nusselt = nu_sqrt ** 2
    h = nusselt * props["k"] / diameter_m
    return max(h, 1.0)


def forced_convection_coefficient_cylinder(
    surface_temp_k: float,
    ambient_temp_k: float,
    diameter_m: float,
    air_velocity_m_s: float,
) -> float:
    """Estimate h (W/m^2K) for forced convection across a cylinder
    (cross-flow) using the Churchill-Bernstein correlation.
    """
    if air_velocity_m_s <= 1e-6:
        return natural_convection_coefficient_cylinder(surface_temp_k, ambient_temp_k, diameter_m)
    t_film = (surface_temp_k + ambient_temp_k) / 2.0
    props = _air_properties(t_film)
    re = air_velocity_m_s * diameter_m / props["nu"]
    pr = props["pr"]
    term1 = 0.62 * re ** 0.5 * pr ** (1.0 / 3.0)
    term2 = (1.0 + (0.4 / pr) ** (2.0 / 3.0)) ** 0.25
    term3 = (1.0 + (re / 282000.0) ** (5.0 / 8.0)) ** (4.0 / 5.0)
    nusselt = 0.3 + (term1 / term2) * term3
    h = nusselt * props["k"] / diameter_m
    return max(h, 1.0)


def _air_properties_array(t_film_k: np.ndarray) -> dict:
    t = t_film_k
    k = 0.0243 + 7.6e-5 * (t - 300.0)
    nu = 1.51e-5 + 9.5e-8 * (t - 300.0)
    alpha = 2.12e-5 + 1.3e-7 * (t - 300.0)
    pr = np.where(alpha > 0, nu / np.maximum(alpha, 1e-12), 0.71)
    beta = 1.0 / t
    return {
        "k": np.maximum(k, 1e-4), "nu": np.maximum(nu, 1e-7),
        "alpha": np.maximum(alpha, 1e-7), "pr": pr, "beta": beta,
    }


def natural_convection_array(surface_temp_k: np.ndarray, ambient_temp_k: float,
                              diameter_m: float) -> np.ndarray:
    """Vectorised Churchill-Chu natural convection coefficient (W/m^2K)
    for an array of surface temperatures against a fixed ambient/diameter.
    """
    ts = np.atleast_1d(np.asarray(surface_temp_k, dtype=float))
    dt = np.abs(ts - ambient_temp_k)
    t_film = (ts + ambient_temp_k) / 2.0
    props = _air_properties_array(t_film)
    ra = GRAVITY * props["beta"] * dt * diameter_m ** 3 / (props["nu"] * props["alpha"])
    ra = np.maximum(ra, 1e-6)
    pr = props["pr"]
    numerator = 0.60 + 0.387 * ra ** (1.0 / 6.0)
    denom = (1.0 + (0.559 / pr) ** (9.0 / 16.0)) ** (8.0 / 27.0)
    nusselt = (numerator / denom) ** 2
    h = nusselt * props["k"] / diameter_m
    h = np.where(dt < 1e-9, 2.0, h)
    return np.maximum(h, 1.0)


def forced_convection_array(surface_temp_k: np.ndarray, ambient_temp_k: float,
                             diameter_m: float, air_velocity_m_s: float) -> np.ndarray:
    """Vectorised Churchill-Bernstein forced convection coefficient (W/m^2K)."""
    if air_velocity_m_s <= 1e-6:
        return natural_convection_array(surface_temp_k, ambient_temp_k, diameter_m)
    ts = np.atleast_1d(np.asarray(surface_temp_k, dtype=float))
    t_film = (ts + ambient_temp_k) / 2.0
    props = _air_properties_array(t_film)
    re = air_velocity_m_s * diameter_m / props["nu"]
    pr = props["pr"]
    term1 = 0.62 * re ** 0.5 * pr ** (1.0 / 3.0)
    term2 = (1.0 + (0.4 / pr) ** (2.0 / 3.0)) ** 0.25
    term3 = (1.0 + (re / 282000.0) ** (5.0 / 8.0)) ** (4.0 / 5.0)
    nusselt = 0.3 + (term1 / term2) * term3
    h = nusselt * props["k"] / diameter_m
    return np.maximum(h, 1.0)


def radiative_heat_loss(
    surface_temp_k: float,
    ambient_temp_k: float,
    surface_area_m2: float,
    emissivity: float,
) -> float:
    """Q_rad = eps * sigma * A * (Ts^4 - Tamb^4), watts."""
    return emissivity * STEFAN_BOLTZMANN * surface_area_m2 * (
        surface_temp_k ** 4 - ambient_temp_k ** 4
    )


def convective_heat_loss(surface_temp_k: float, ambient_temp_k: float,
                          surface_area_m2: float, h_w_m2k: float) -> float:
    """Q_conv = h * A * (Ts - Tamb), watts."""
    return h_w_m2k * surface_area_m2 * (surface_temp_k - ambient_temp_k)


def axial_conduction(k_w_mk: float, area_m2: float, dx_m: float, dT: float) -> float:
    """Fourier conduction between two adjacent axial cells: Q = k*A/dx * dT, watts."""
    return k_w_mk * area_m2 / dx_m * dT


# ---------------------------------------------------------------------------
# Thermal environment / boundary conditions
# ---------------------------------------------------------------------------

class CoolingType(str, enum.Enum):
    STILL_AIR = "still_air"
    FORCED_AIR = "forced_air"
    LIQUID = "liquid"
    HEATSINK = "heatsink"
    CUSTOM = "custom"


class ThermalEnvironment(ETBaseModel):
    """Boundary conditions the conductor exchanges heat with.

    ``fixed_convection_coefficient``, if provided, overrides the
    correlation-based estimate (use this for liquid cooling, heat
    sinks, or any case where a validated h is already known).
    """

    ambient_temperature: float = Field(description="kelvin")
    cooling_type: CoolingType = CoolingType.STILL_AIR
    air_velocity: float = Field(default=0.0, ge=0.0, description="m/s, used for forced_air")
    fixed_convection_coefficient: float | None = Field(
        default=None, gt=0, description="W/(m^2 K), overrides correlation if set"
    )
    #: additional thermal resistance in series with convection, e.g. a
    #: connector/contact interface or insulation jacket, K*m^2/W
    contact_resistance: float = Field(default=0.0, ge=0.0)
    #: extra thermal resistance to represent a heat sink attached to the
    #: conductor, K/W (applied as a lumped parallel path to ambient)
    heatsink_thermal_resistance: float | None = Field(default=None, gt=0)
    #: surface emissivity override; if None, the material's own
    #: emissivity is used
    emissivity_override: float | None = Field(default=None, ge=0.0, le=1.0)

    def convection_coefficient(self, surface_temp_k: float, diameter_or_char_length_m: float) -> float:
        if self.fixed_convection_coefficient is not None:
            h = self.fixed_convection_coefficient
        elif self.cooling_type == CoolingType.STILL_AIR:
            h = natural_convection_coefficient_cylinder(
                surface_temp_k, self.ambient_temperature, diameter_or_char_length_m
            )
        elif self.cooling_type == CoolingType.FORCED_AIR:
            h = forced_convection_coefficient_cylinder(
                surface_temp_k, self.ambient_temperature, diameter_or_char_length_m,
                self.air_velocity,
            )
        elif self.cooling_type == CoolingType.LIQUID:
            # Typical liquid (water/glycol) forced convection h is far higher
            # than air; use a representative correlation-free floor unless the
            # caller supplies a validated fixed_convection_coefficient.
            h = 600.0 + 400.0 * min(self.air_velocity, 5.0)
        elif self.cooling_type == CoolingType.HEATSINK:
            h = natural_convection_coefficient_cylinder(
                surface_temp_k, self.ambient_temperature, diameter_or_char_length_m
            )
        else:  # CUSTOM without fixed value -> fall back to natural convection
            h = natural_convection_coefficient_cylinder(
                surface_temp_k, self.ambient_temperature, diameter_or_char_length_m
            )

        if self.contact_resistance > 0:
            # series resistance: 1/h_eff = 1/h + R_contact
            r_conv = 1.0 / h
            h = 1.0 / (r_conv + self.contact_resistance)
        return h

    def convection_coefficient_array(self, surface_temp_k: np.ndarray,
                                      diameter_or_char_length_m: float) -> np.ndarray:
        """Vectorised counterpart of :meth:`convection_coefficient`, used by
        the spatial coupled solver for performance across many cells.
        """
        ts = np.atleast_1d(np.asarray(surface_temp_k, dtype=float))
        if self.fixed_convection_coefficient is not None:
            h = np.full_like(ts, self.fixed_convection_coefficient)
        elif self.cooling_type == CoolingType.FORCED_AIR:
            h = forced_convection_array(ts, self.ambient_temperature, diameter_or_char_length_m, self.air_velocity)
        elif self.cooling_type == CoolingType.LIQUID:
            h = np.full_like(ts, 600.0 + 400.0 * min(self.air_velocity, 5.0))
        else:
            h = natural_convection_array(ts, self.ambient_temperature, diameter_or_char_length_m)

        if self.contact_resistance > 0:
            h = 1.0 / (1.0 / h + self.contact_resistance)
        return h

    def total_heat_loss(self, surface_temp_k: float, surface_area_m2: float,
                         char_length_m: float, emissivity: float) -> float:
        eps = self.emissivity_override if self.emissivity_override is not None else emissivity
        h = self.convection_coefficient(surface_temp_k, char_length_m)
        q_conv = convective_heat_loss(surface_temp_k, self.ambient_temperature, surface_area_m2, h)
        q_rad = radiative_heat_loss(surface_temp_k, self.ambient_temperature, surface_area_m2, eps)
        q_total = q_conv + q_rad
        if self.heatsink_thermal_resistance:
            q_heatsink = (surface_temp_k - self.ambient_temperature) / self.heatsink_thermal_resistance
            q_total += q_heatsink
        return q_total


# Convenience preset environments -------------------------------------------------

STILL_AIR = ThermalEnvironment(ambient_temperature=298.15, cooling_type=CoolingType.STILL_AIR)
FORCED_AIR = ThermalEnvironment(
    ambient_temperature=298.15, cooling_type=CoolingType.FORCED_AIR, air_velocity=3.0
)
LIQUID_COOLED = ThermalEnvironment(
    ambient_temperature=298.15, cooling_type=CoolingType.LIQUID, air_velocity=1.0
)


__all__ = [
    "CoolingType",
    "ThermalEnvironment",
    "STILL_AIR",
    "FORCED_AIR",
    "LIQUID_COOLED",
    "natural_convection_coefficient_cylinder",
    "forced_convection_coefficient_cylinder",
    "natural_convection_array",
    "forced_convection_array",
    "radiative_heat_loss",
    "convective_heat_loss",
    "axial_conduction",
]
