"""
electrotherm.electrical
=========================

DC electrical solver: Ohm's law relationships and electrical load
profiles (constant voltage, constant current, variable/time-varying
load, and pulsed current).

    V = I * R
    P = V * I = I^2 * R = V^2 / R
"""

from __future__ import annotations

import math
from abc import ABC, abstractmethod
from typing import Callable

import numpy as np
from pydantic import Field

from electrotherm.core.models import ETBaseModel


# ---------------------------------------------------------------------------
# Ohm's law / power relationships
# ---------------------------------------------------------------------------

def voltage(current_a: float, resistance_ohm: float) -> float:
    """V = I * R"""
    return current_a * resistance_ohm


def current_from_voltage(voltage_v: float, resistance_ohm: float) -> float:
    """I = V / R"""
    return voltage_v / resistance_ohm


def resistance_from_vi(voltage_v: float, current_a: float) -> float:
    """R = V / I"""
    return voltage_v / current_a


def power_vi(voltage_v: float, current_a: float) -> float:
    """P = V * I"""
    return voltage_v * current_a


def power_i2r(current_a: float, resistance_ohm: float) -> float:
    """P = I^2 * R (Joule / resistive heating power)"""
    return current_a ** 2 * resistance_ohm


def power_v2r(voltage_v: float, resistance_ohm: float) -> float:
    """P = V^2 / R"""
    return voltage_v ** 2 / resistance_ohm


# ---------------------------------------------------------------------------
# Electrical load profiles
# ---------------------------------------------------------------------------

class LoadProfile(ETBaseModel, ABC):
    """A time-varying electrical excitation applied to a conductor.

    Subclasses implement :meth:`current_at` to return the source current
    (A) at time ``t`` (s). For voltage-driven sources the equivalent
    current depends on the (temperature-dependent) resistance, so those
    are resolved iteratively by the coupled solver instead of here.
    """

    @abstractmethod
    def current_at(self, t: float) -> float:
        """Return excitation current (A) at time t (s)."""

    def current_array(self, t: np.ndarray) -> np.ndarray:
        return np.array([self.current_at(float(ti)) for ti in np.atleast_1d(t)])


class ConstantCurrent(LoadProfile):
    """A fixed DC current for all time."""

    current: float = Field(description="amperes")

    def current_at(self, t: float) -> float:
        return self.current


class ConstantVoltage(LoadProfile):
    """A fixed DC voltage source.

    Note: current under a constant-voltage source depends on the
    (temperature-dependent) resistance and is therefore resolved by the
    coupled solver, not by this class directly. ``current_at`` here
    assumes a fixed nominal resistance for standalone electrical-only
    calculations / plotting.
    """

    voltage: float = Field(description="volts")
    nominal_resistance: float = Field(gt=0, description="ohm, used for standalone I=V/R estimates")

    def current_at(self, t: float) -> float:
        return self.voltage / self.nominal_resistance


class VariableLoad(LoadProfile):
    """Piecewise-linear time-varying current defined by (time, current) points."""

    times: list[float]
    currents: list[float]

    def current_at(self, t: float) -> float:
        return float(np.interp(t, self.times, self.currents))


class FunctionLoad(LoadProfile):
    """Current defined by an arbitrary Python callable ``I(t)``.

    Not JSON-serialisable (the callable is excluded from persistence);
    use :class:`VariableLoad` or :class:`PulsedCurrent` for
    reproducible, savable profiles.
    """

    model_config = {"arbitrary_types_allowed": True, "extra": "forbid"}

    fn: Callable[[float], float]

    def current_at(self, t: float) -> float:
        return float(self.fn(t))


class PulsedCurrent(LoadProfile):
    """Repeating rectangular current pulses.

        0 -> amplitude -> 0 -> amplitude -> ...

    Parameters mirror common pulsed-power terminology:

    - ``amplitude``: peak pulse current, A
    - ``baseline``: current during the "off"/cooling portion of the
      cycle, A (default 0)
    - ``period``: total cycle period, s (1/frequency)
    - ``duty_cycle``: fraction of the period the pulse is "on" (0-1)
    - ``rise_time`` / ``fall_time``: optional linear ramp times, s, for
      a more realistic trapezoidal pulse instead of an ideal step
    """

    amplitude: float = Field(description="peak pulse current, A")
    baseline: float = Field(default=0.0, description="current during cooling interval, A")
    period: float = Field(gt=0, description="seconds")
    duty_cycle: float = Field(gt=0.0, le=1.0)
    rise_time: float = Field(default=0.0, ge=0.0)
    fall_time: float = Field(default=0.0, ge=0.0)
    phase: float = Field(default=0.0, description="time offset, seconds")

    @property
    def frequency(self) -> float:
        return 1.0 / self.period

    @property
    def pulse_on_duration(self) -> float:
        return self.duty_cycle * self.period

    @property
    def cooling_interval(self) -> float:
        return self.period - self.pulse_on_duration

    def current_at(self, t: float) -> float:
        tau = (t + self.phase) % self.period
        on_time = self.pulse_on_duration
        r, f = self.rise_time, self.fall_time
        if tau < r:
            return self.baseline + (self.amplitude - self.baseline) * (tau / r if r > 0 else 1.0)
        if tau < on_time - f:
            return self.amplitude
        if tau < on_time:
            frac = (on_time - tau) / f if f > 0 else 0.0
            return self.baseline + (self.amplitude - self.baseline) * frac
        return self.baseline


class MultiStepPulseTrain(LoadProfile):
    """A general multi-level pulse train, e.g. 0A -> 500A -> 1000A -> 500A -> 0A.

    ``levels`` gives the current (A) held during each step and
    ``durations`` gives how long (s) each step lasts; the sequence
    repeats every ``sum(durations)`` seconds.
    """

    levels: list[float]
    durations: list[float]

    def _cycle_period(self) -> float:
        return sum(self.durations)

    def current_at(self, t: float) -> float:
        period = self._cycle_period()
        tau = t % period if period > 0 else 0.0
        acc = 0.0
        for level, dur in zip(self.levels, self.durations):
            if tau < acc + dur:
                return level
            acc += dur
        return self.levels[-1] if self.levels else 0.0


__all__ = [
    "voltage",
    "current_from_voltage",
    "resistance_from_vi",
    "power_vi",
    "power_i2r",
    "power_v2r",
    "LoadProfile",
    "ConstantCurrent",
    "ConstantVoltage",
    "VariableLoad",
    "FunctionLoad",
    "PulsedCurrent",
    "MultiStepPulseTrain",
]
