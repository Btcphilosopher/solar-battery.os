"""
electrotherm.materials
========================

Material engine: temperature-dependent electrical and thermal
properties for conductor materials.

Resistivity follows the standard linear temperature-coefficient model
used across electrical engineering references:

    rho(T) = rho0 * [1 + alpha * (T - T0)]

where ``rho0`` is the resistivity at reference temperature ``T0``
(conventionally 20 degC / 293.15 K) and ``alpha`` is the material's
temperature coefficient of resistance (1/K).

Thermal conductivity and specific heat are also allowed to vary with
temperature via optional linear coefficients, since for wide operating
ranges (e.g. -40 degC to melting point) assuming constant properties
introduces material error into the coupled solution.
"""

from __future__ import annotations

from pydantic import Field, model_validator

from electrotherm.core.models import ETBaseModel
from electrotherm.core.units import T_REFERENCE_K


class Material(ETBaseModel):
    """A conductive material with temperature-dependent properties.

    All quantities are in SI units. Temperatures are in kelvin.
    """

    name: str
    #: electrical resistivity at reference_temperature, ohm*m
    resistivity_ref: float = Field(gt=0)
    #: temperature at which resistivity_ref is quoted, kelvin
    reference_temperature: float = Field(default=T_REFERENCE_K, gt=0)
    #: temperature coefficient of resistance, 1/K
    temp_coefficient_resistance: float
    #: thermal conductivity at reference_temperature, W/(m*K)
    thermal_conductivity_ref: float = Field(gt=0)
    #: optional linear temperature coefficient of thermal conductivity, 1/K
    thermal_conductivity_temp_coeff: float = 0.0
    #: density, kg/m^3
    density: float = Field(gt=0)
    #: specific heat capacity at reference_temperature, J/(kg*K)
    specific_heat_ref: float = Field(gt=0)
    #: optional linear temperature coefficient of specific heat, 1/K
    specific_heat_temp_coeff: float = 0.0
    #: melting point, kelvin
    melting_point: float = Field(gt=0)
    #: recommended continuous maximum operating temperature, kelvin
    max_operating_temperature: float = Field(gt=0)
    #: surface emissivity (0-1), used for radiative heat transfer
    emissivity: float = Field(default=0.3, ge=0.0, le=1.0)
    #: relative cost per kilogram, arbitrary currency units (for
    #: optimisation cost objectives). Optional.
    cost_per_kg: float | None = Field(default=None, ge=0)

    @model_validator(mode="after")
    def _check_temperature_ordering(self) -> "Material":
        if self.max_operating_temperature >= self.melting_point:
            raise ValueError(
                f"{self.name}: max_operating_temperature must be below melting_point"
            )
        return self

    # -- temperature-dependent properties -----------------------------

    def resistivity(self, temperature_k: float) -> float:
        """Electrical resistivity at ``temperature_k`` (ohm*m).

        rho(T) = rho0 * [1 + alpha * (T - T0)]
        """
        dt = temperature_k - self.reference_temperature
        rho = self.resistivity_ref * (1.0 + self.temp_coefficient_resistance * dt)
        return max(rho, 1e-16)

    def conductivity(self, temperature_k: float) -> float:
        """Electrical conductivity at ``temperature_k`` (S/m)."""
        return 1.0 / self.resistivity(temperature_k)

    def thermal_conductivity(self, temperature_k: float) -> float:
        """Thermal conductivity at ``temperature_k`` (W/(m*K))."""
        dt = temperature_k - self.reference_temperature
        k = self.thermal_conductivity_ref * (
            1.0 + self.thermal_conductivity_temp_coeff * dt
        )
        return max(k, 1e-6)

    def specific_heat(self, temperature_k: float) -> float:
        """Specific heat capacity at ``temperature_k`` (J/(kg*K))."""
        dt = temperature_k - self.reference_temperature
        c = self.specific_heat_ref * (1.0 + self.specific_heat_temp_coeff * dt)
        return max(c, 1.0)

    def is_molten(self, temperature_k: float) -> bool:
        return temperature_k >= self.melting_point

    def thermal_diffusivity(self, temperature_k: float) -> float:
        """alpha_th = k / (rho_mass * cp), m^2/s."""
        return self.thermal_conductivity(temperature_k) / (
            self.density * self.specific_heat(temperature_k)
        )


# ---------------------------------------------------------------------------
# Built-in material library
#
# Reference values are typical engineering handbook values at 20 degC
# (293.15 K) and are provided for simulation convenience. They are not a
# substitute for a certified material datasheet.
# ---------------------------------------------------------------------------

COPPER = Material(
    name="Copper (annealed, IACS 100%)",
    resistivity_ref=1.68e-8,
    temp_coefficient_resistance=0.00393,
    thermal_conductivity_ref=401.0,
    thermal_conductivity_temp_coeff=-0.00035,
    density=8960.0,
    specific_heat_ref=385.0,
    specific_heat_temp_coeff=0.00035,
    melting_point=1357.77,
    max_operating_temperature=473.15,  # 200 degC typical PVC/XLPE-free bare copper
    emissivity=0.04,
    cost_per_kg=9.0,
)

ALUMINIUM = Material(
    name="Aluminium (1350 alloy)",
    resistivity_ref=2.65e-8,
    temp_coefficient_resistance=0.00429,
    thermal_conductivity_ref=237.0,
    thermal_conductivity_temp_coeff=-0.0002,
    density=2700.0,
    specific_heat_ref=897.0,
    specific_heat_temp_coeff=0.0003,
    melting_point=933.47,
    max_operating_temperature=423.15,  # 150 degC typical bare overhead conductor
    emissivity=0.06,
    cost_per_kg=2.2,
)

SILVER = Material(
    name="Silver",
    resistivity_ref=1.59e-8,
    temp_coefficient_resistance=0.0038,
    thermal_conductivity_ref=429.0,
    thermal_conductivity_temp_coeff=-0.0003,
    density=10490.0,
    specific_heat_ref=235.0,
    specific_heat_temp_coeff=0.0002,
    melting_point=1234.93,
    max_operating_temperature=473.15,
    emissivity=0.02,
    cost_per_kg=850.0,
)

GOLD = Material(
    name="Gold",
    resistivity_ref=2.44e-8,
    temp_coefficient_resistance=0.0034,
    thermal_conductivity_ref=317.0,
    thermal_conductivity_temp_coeff=-0.0002,
    density=19300.0,
    specific_heat_ref=129.0,
    specific_heat_temp_coeff=0.0001,
    melting_point=1337.33,
    max_operating_temperature=523.15,
    emissivity=0.02,
    cost_per_kg=65000.0,
)

NICKEL = Material(
    name="Nickel",
    resistivity_ref=6.99e-8,
    temp_coefficient_resistance=0.006,
    thermal_conductivity_ref=90.9,
    thermal_conductivity_temp_coeff=-0.0004,
    density=8908.0,
    specific_heat_ref=444.0,
    specific_heat_temp_coeff=0.0003,
    melting_point=1728.0,
    max_operating_temperature=573.15,
    emissivity=0.11,
    cost_per_kg=17.0,
)

STEEL = Material(
    name="Steel (mild / structural, generic)",
    resistivity_ref=1.43e-7,
    temp_coefficient_resistance=0.0045,
    thermal_conductivity_ref=50.2,
    thermal_conductivity_temp_coeff=-0.0003,
    density=7850.0,
    specific_heat_ref=486.0,
    specific_heat_temp_coeff=0.0002,
    melting_point=1723.0,
    max_operating_temperature=773.15,
    emissivity=0.7,
    cost_per_kg=0.8,
)

MATERIAL_LIBRARY: dict[str, Material] = {
    "copper": COPPER,
    "aluminium": ALUMINIUM,
    "aluminum": ALUMINIUM,
    "silver": SILVER,
    "gold": GOLD,
    "nickel": NICKEL,
    "steel": STEEL,
}


def get_material(name: str) -> Material:
    """Look up a built-in material by (case-insensitive) name."""
    key = name.strip().lower()
    if key not in MATERIAL_LIBRARY:
        available = ", ".join(sorted(set(MATERIAL_LIBRARY)))
        raise KeyError(f"Unknown material '{name}'. Available: {available}")
    return MATERIAL_LIBRARY[key]


def register_material(material: Material) -> None:
    """Register a custom alloy/material into the global library."""
    MATERIAL_LIBRARY[material.name.strip().lower()] = material


__all__ = [
    "Material",
    "COPPER",
    "ALUMINIUM",
    "SILVER",
    "GOLD",
    "NICKEL",
    "STEEL",
    "MATERIAL_LIBRARY",
    "get_material",
    "register_material",
]
