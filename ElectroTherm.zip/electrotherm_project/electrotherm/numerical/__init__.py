"""
electrotherm.numerical
========================

Performance / accelerator layer.

This module isolates the "hot" numerical kernels (resistivity
evaluation, Joule heating, convective/radiative loss over a cell
array, and the coupled ODE right-hand side) behind a small, stable
functional API. Each kernel has:

- a plain NumPy (vectorised) implementation, always available;
- an optional Numba ``@njit`` implementation, used automatically when
  numba is importable and ``SolverConfig.use_numba`` is True.

Because the public functions here take/return plain NumPy arrays and
floats (no Python objects), the same signatures can be reimplemented in
Rust/C++ (e.g. via pyo3/pybind11) later without touching any calling
code in :mod:`electrotherm.simulation`.
"""

from __future__ import annotations

import numpy as np

from electrotherm.core.configuration import get_config
from electrotherm.core.units import STEFAN_BOLTZMANN

try:
    from numba import njit  # type: ignore

    _HAVE_NUMBA = True
except Exception:  # pragma: no cover - numba is optional
    _HAVE_NUMBA = False

    def njit(*args, **kwargs):  # type: ignore
        # no-op decorator fallback so the rest of the module is unaffected
        if len(args) == 1 and callable(args[0]):
            return args[0]

        def _wrap(fn):
            return fn

        return _wrap


def numba_available() -> bool:
    return _HAVE_NUMBA


# ---------------------------------------------------------------------------
# Vectorised NumPy kernels (always available, used as the numba fallback too)
# ---------------------------------------------------------------------------

def resistivity_array(temperatures_k: np.ndarray, rho0: float, alpha: float, t0: float) -> np.ndarray:
    """rho(T) = rho0 * [1 + alpha*(T - T0)], floored at a small positive
    value. The floor mirrors :meth:`Material.resistivity` and matters
    numerically: without it, a solver iterate that overshoots to a very
    low temperature can drive resistivity (and hence Joule heating)
    negative, letting a nonlinear root-finder converge on an unphysical
    "cold" fixed point instead of the true equilibrium.
    """
    rho = rho0 * (1.0 + alpha * (temperatures_k - t0))
    return np.maximum(rho, 1e-16)


def resistance_array(temperatures_k: np.ndarray, rho0: float, alpha: float, t0: float,
                      lengths: np.ndarray, areas: np.ndarray) -> np.ndarray:
    rho = resistivity_array(temperatures_k, rho0, alpha, t0)
    return rho * lengths / areas


def joule_power_array(current_a: float, resistances: np.ndarray) -> np.ndarray:
    return current_a ** 2 * resistances


def convective_loss_array(temperatures_k: np.ndarray, ambient_k: float,
                           h: np.ndarray, areas: np.ndarray) -> np.ndarray:
    return h * areas * (temperatures_k - ambient_k)


def radiative_loss_array(temperatures_k: np.ndarray, ambient_k: float,
                          emissivity: np.ndarray, areas: np.ndarray) -> np.ndarray:
    return emissivity * STEFAN_BOLTZMANN * areas * (temperatures_k ** 4 - ambient_k ** 4)


def axial_conduction_array(temperatures_k: np.ndarray, k_thermal: np.ndarray,
                            cross_area: float, dx: float) -> np.ndarray:
    """Net axial conduction into each cell from its left/right neighbours
    (zero-flux / adiabatic ends).
    """
    n = temperatures_k.shape[0]
    q = np.zeros(n)
    if n < 2:
        return q
    k_face = (k_thermal[:-1] + k_thermal[1:]) / 2.0
    flux = k_face * cross_area / dx * (temperatures_k[1:] - temperatures_k[:-1])
    q[:-1] += flux
    q[1:] -= flux
    return q


# ---------------------------------------------------------------------------
# Numba-accelerated variants (compiled lazily on first call)
# ---------------------------------------------------------------------------

@njit(cache=True, fastmath=True)
def _rhs_numba(
    temperatures_k: np.ndarray,
    current_a: float,
    rho0: float,
    alpha: float,
    t0: float,
    lengths: np.ndarray,
    areas: np.ndarray,
    surface_areas: np.ndarray,
    h: np.ndarray,
    emissivity: np.ndarray,
    ambient_k: float,
    k_thermal: np.ndarray,
    cross_area: float,
    dx: float,
    thermal_mass: np.ndarray,
    sigma: float,
) -> np.ndarray:
    n = temperatures_k.shape[0]
    dTdt = np.empty(n)
    for i in range(n):
        rho = rho0 * (1.0 + alpha * (temperatures_k[i] - t0))
        if rho < 1e-16:
            rho = 1e-16
        r = rho * lengths[i] / areas[i]
        p_joule = current_a * current_a * r
        q_conv = h[i] * surface_areas[i] * (temperatures_k[i] - ambient_k)
        q_rad = emissivity[i] * sigma * surface_areas[i] * (
            temperatures_k[i] ** 4 - ambient_k ** 4
        )
        q_cond = 0.0
        if i > 0:
            k_face = (k_thermal[i - 1] + k_thermal[i]) / 2.0
            q_cond += k_face * cross_area / dx * (temperatures_k[i - 1] - temperatures_k[i])
        if i < n - 1:
            k_face = (k_thermal[i] + k_thermal[i + 1]) / 2.0
            q_cond += k_face * cross_area / dx * (temperatures_k[i + 1] - temperatures_k[i])
        dTdt[i] = (p_joule - q_conv - q_rad + q_cond) / thermal_mass[i]
    return dTdt


def coupled_rhs(
    temperatures_k: np.ndarray,
    current_a: float,
    rho0: float,
    alpha: float,
    t0: float,
    lengths: np.ndarray,
    areas: np.ndarray,
    surface_areas: np.ndarray,
    h: np.ndarray,
    emissivity: np.ndarray,
    ambient_k: float,
    k_thermal: np.ndarray,
    cross_area: float,
    dx: float,
    thermal_mass: np.ndarray,
) -> np.ndarray:
    """dT/dt for every spatial cell: (P_joule - Q_conv - Q_rad + Q_cond) / (m*cp).

    Dispatches to the numba kernel when available and enabled, otherwise
    uses the vectorised NumPy path. Both paths are numerically identical.
    """
    cfg = get_config()
    if cfg.use_numba and _HAVE_NUMBA:
        return _rhs_numba(
            temperatures_k, current_a, rho0, alpha, t0, lengths, areas,
            surface_areas, h, emissivity, ambient_k, k_thermal, cross_area,
            dx, thermal_mass, STEFAN_BOLTZMANN,
        )

    r = resistance_array(temperatures_k, rho0, alpha, t0, lengths, areas)
    p_joule = joule_power_array(current_a, r)
    q_conv = convective_loss_array(temperatures_k, ambient_k, h, surface_areas)
    q_rad = radiative_loss_array(temperatures_k, ambient_k, emissivity, surface_areas)
    q_cond = axial_conduction_array(temperatures_k, k_thermal, cross_area, dx) if dx > 0 else 0.0
    return (p_joule - q_conv - q_rad + q_cond) / thermal_mass


__all__ = [
    "numba_available",
    "resistivity_array",
    "resistance_array",
    "joule_power_array",
    "convective_loss_array",
    "radiative_loss_array",
    "axial_conduction_array",
    "coupled_rhs",
]
