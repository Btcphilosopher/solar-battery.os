import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { exec } from "child_process";
import fs from "fs";
import { CANDIDATE_TARIFFS, OFGEM_PRICE_CAPS, UK_REGIONS, generateMockSmartMeterData } from "./src/data/ukMarketData.js";
import { runEnergyOptimisation } from "./src/utils/optimiserEngine.js";
import { calculateBillFromReadings } from "./src/utils/billCalculator.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "10mb" }));

  // API Routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", app: "British Energy Optimiser" });
  });

  app.get("/api/regions", (req, res) => {
    res.json({ regions: UK_REGIONS });
  });

  app.get("/api/price-cap", (req, res) => {
    res.json({ price_caps: OFGEM_PRICE_CAPS });
  });

  app.get("/api/tariffs", (req, res) => {
    const region = (req.query.region as string) || "london";
    const filtered = CANDIDATE_TARIFFS.filter(t => t.region === region || t.region === "national_avg" || !t.region);
    res.json({ tariffs: filtered.length > 0 ? filtered : CANDIDATE_TARIFFS });
  });

  app.post("/api/optimise", (req, res) => {
    try {
      const { readings, tariff, appliances, solar, battery, ev, heatPump, objective } = req.body;
      const defaultReadings = readings || generateMockSmartMeterData("ev").readings;
      const defaultTariff = tariff || CANDIDATE_TARIFFS[1]; // Octopus Go

      const result = runEnergyOptimisation({
        readings: defaultReadings,
        tariff: defaultTariff,
        appliances: appliances || [],
        solar: solar || { enabled: false, capacity_kwp: 4.0, annual_generation_kwh: 3600, export_tariff_p_kwh: 15, self_consumption_pct: 40 },
        battery: battery || { enabled: true, capacity_kwh: 10, max_charge_kw: 3.6, max_discharge_kw: 3.6, round_trip_efficiency: 0.90, min_soc_pct: 10, max_soc_pct: 100, grid_charging_allowed: true, capital_cost: 4500 },
        ev: ev || { enabled: true, battery_capacity_kwh: 60, charging_rate_kw: 7.4, typical_daily_kwh: 28, arrival_time: "18:00", departure_time: "07:00", target_soc_pct: 100, capital_cost: 850 },
        heatPump: heatPump || { enabled: false, annual_heat_demand_kwh: 12000, seasonal_cop: 3.2, electricity_demand_kwh: 3750, flexible_thermal_storage: true, capital_cost: 9000 },
        objective: objective || { priority: "cost", weight_cost: 1.0, weight_carbon: 0.0 },
      });

      res.json({ success: true, result });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Execute R Script via Rscript if installed, or fallback
  app.post("/api/r-exec", (req, res) => {
    const rScriptPath = path.join(process.cwd(), "british-energy-optimiser", "R", "tariff_engine.R");
    
    exec("which Rscript", (err, stdout) => {
      if (err || !stdout.trim()) {
        res.json({
          executed: false,
          r_installed: false,
          message: "R environment is not installed on system. Using high-precision TypeScript mathematical engine.",
          r_code_sample: fs.existsSync(rScriptPath) ? fs.readFileSync(rScriptPath, "utf-8") : "# R Tariff Engine"
        });
        return;
      }

      exec(`Rscript -e 'source("${rScriptPath}"); print("R Tariff Engine loaded successfully")'`, (rErr, rStdout, rStderr) => {
        res.json({
          executed: true,
          r_installed: true,
          stdout: rStdout,
          stderr: rStderr,
          r_code_sample: fs.existsSync(rScriptPath) ? fs.readFileSync(rScriptPath, "utf-8") : ""
        });
      });
    });
  });

  // Get R File contents
  app.get("/api/r-files", (req, res) => {
    const file = req.query.file as string || "app.R";
    const target = path.join(process.cwd(), "british-energy-optimiser", file);
    if (fs.existsSync(target)) {
      res.json({ file, content: fs.readFileSync(target, "utf-8") });
    } else {
      res.status(404).json({ error: "File not found" });
    }
  });

  // Vite development middleware or production static server
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`British Energy Optimiser running at http://localhost:${PORT}`);
  });
}

startServer();
