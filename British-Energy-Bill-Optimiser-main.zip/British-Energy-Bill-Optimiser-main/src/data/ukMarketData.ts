import { UKRegion, PriceCapPeriod, Tariff, SmartMeterDataSet } from '../types';

export const UK_REGIONS: UKRegion[] = [
  { id: 'london', name: 'London', dnoName: 'UK Power Networks (London)', gridAreaCode: '12' },
  { id: 'eastern', name: 'Eastern England', dnoName: 'UK Power Networks (Eastern)', gridAreaCode: '10' },
  { id: 'east_midlands', name: 'East Midlands', dnoName: 'National Grid Electricity Distribution', gridAreaCode: '11' },
  { id: 'west_midlands', name: 'West Midlands', dnoName: 'National Grid Electricity Distribution', gridAreaCode: '14' },
  { id: 'north_east', name: 'North East England', dnoName: 'Northern Powergrid (Northeast)', gridAreaCode: '15' },
  { id: 'north_west', name: 'North West England', dnoName: 'Electricity North West', gridAreaCode: '16' },
  { id: 'north_wales_mersey', name: 'Merseyside & North Wales', dnoName: 'SP Energy Networks', gridAreaCode: '18' },
  { id: 'south_wales', name: 'South Wales', dnoName: 'National Grid Electricity Distribution', gridAreaCode: '21' },
  { id: 'south_west', name: 'South West England', dnoName: 'National Grid Electricity Distribution', gridAreaCode: '22' },
  { id: 'southern', name: 'Southern England', dnoName: 'SSEN Southern', gridAreaCode: '20' },
  { id: 'south_east', name: 'South East England', dnoName: 'UK Power Networks (South Eastern)', gridAreaCode: '19' },
  { id: 'yorkshire', name: 'Yorkshire', dnoName: 'Northern Powergrid (Yorkshire)', gridAreaCode: '23' },
  { id: 'northern_scotland', name: 'Northern Scotland', dnoName: 'SSEN Highlands & Islands', gridAreaCode: '17' },
  { id: 'southern_scotland', name: 'Southern Scotland', dnoName: 'SP Energy Networks (Scotland)', gridAreaCode: '13' },
];

export const OFGEM_PRICE_CAPS: PriceCapPeriod[] = [
  {
    id: 'cap_2026_q3',
    name: 'Ofgem Price Cap (Jul 1 - Sep 30, 2026)',
    effective_from: '2026-07-01',
    effective_to: '2026-09-30',
    electricity_unit_rate: 24.50, // p/kWh
    electricity_standing_charge: 60.10, // p/day
    gas_unit_rate: 6.24, // p/kWh
    gas_standing_charge: 31.40, // p/day
    region: 'national_avg',
    payment_method: 'direct_debit',
    meter_type: 'single_rate',
  },
  {
    id: 'cap_2026_q2',
    name: 'Ofgem Price Cap (Apr 1 - Jun 30, 2026)',
    effective_from: '2026-04-01',
    effective_to: '2026-06-30',
    electricity_unit_rate: 25.80,
    electricity_standing_charge: 60.10,
    gas_unit_rate: 6.45,
    gas_standing_charge: 31.40,
    region: 'national_avg',
    payment_method: 'direct_debit',
    meter_type: 'single_rate',
  },
];

// Typical 48-period dynamic Agile rates (p/kWh) sample curve
const AGILE_SAMPLE_RATES: number[] = [
  12.4, 11.2, 10.5, 9.8, 8.9, 8.2, 7.5, 7.1,  // 00:00 - 04:00 (Night dip)
  8.0, 9.4, 12.1, 15.6, 18.2, 21.0, 22.4, 21.8, // 04:00 - 08:00 (Morning peak)
  19.5, 18.2, 17.0, 16.5, 15.8, 16.2, 17.1, 18.0, // 08:00 - 12:00
  17.5, 16.9, 16.2, 15.5, 16.0, 18.4, 22.1, 26.5, // 12:00 - 16:00
  32.8, 34.5, 33.2, 29.8, 26.2, 23.0, 20.1, 18.5, // 16:00 - 20:00 (Evening peak 16:00-19:00)
  16.8, 15.2, 14.1, 13.5, 12.8, 12.0, 11.5, 11.0  // 20:00 - 24:00
];

export const CANDIDATE_TARIFFS: Tariff[] = [
  {
    id: 'svt_standard',
    supplier: 'British Gas',
    name: 'Standard Variable (Ofgem Cap)',
    type: 'variable',
    electricity_unit_rate: 24.50,
    electricity_standing_charge: 60.10,
    gas_unit_rate: 6.24,
    gas_standing_charge: 31.40,
    export_rate_p_kwh: 5.0,
    region: 'london',
    payment_method: 'direct_debit',
    meter_requirements: ['single_rate', 'smart_half_hourly'],
    contract_months: 0,
    exit_fee: 0,
    is_green: false,
    effective_date: '2026-07-01',
    description: 'Standard variable rate capped by Ofgem. Flexible no-exit-fee plan.',
  },
  {
    id: 'octopus_go',
    supplier: 'Octopus Energy',
    name: 'Octopus Go (EV Tariff)',
    type: 'ev',
    electricity_unit_rate: 26.80, // daytime rate
    electricity_standing_charge: 58.20,
    gas_unit_rate: 6.10,
    gas_standing_charge: 30.50,
    time_rates: [
      { start_time: '00:30', end_time: '04:30', rate_p_kwh: 8.50, label: 'Night EV Rate' },
      { start_time: '04:30', end_time: '00:30', rate_p_kwh: 26.80, label: 'Day Rate' },
    ],
    export_rate_p_kwh: 15.0,
    region: 'london',
    payment_method: 'direct_debit',
    meter_requirements: ['smart_half_hourly'],
    contract_months: 12,
    exit_fee: 0,
    is_green: true,
    effective_date: '2026-06-01',
    description: '4 hours of super-cheap electricity at 8.5p/kWh overnight for EV charging.',
  },
  {
    id: 'octopus_agile',
    supplier: 'Octopus Energy',
    name: 'Octopus Agile (Half-Hourly Dynamic)',
    type: 'tracker',
    electricity_unit_rate: 17.80, // average
    electricity_standing_charge: 59.50,
    gas_unit_rate: 6.15,
    gas_standing_charge: 30.80,
    half_hourly_rates: AGILE_SAMPLE_RATES,
    export_rate_p_kwh: 15.0,
    region: 'london',
    payment_method: 'direct_debit',
    meter_requirements: ['smart_half_hourly'],
    contract_months: 12,
    exit_fee: 0,
    is_green: true,
    effective_date: '2026-07-01',
    description: 'Wholesale half-hourly prices that update daily. Great for automation & batteries.',
  },
  {
    id: 'octopus_cosy',
    supplier: 'Octopus Energy',
    name: 'Octopus Cosy (Heat Pump Tariff)',
    type: 'heat_pump',
    electricity_unit_rate: 23.50,
    electricity_standing_charge: 58.50,
    gas_unit_rate: 6.10,
    gas_standing_charge: 30.50,
    time_rates: [
      { start_time: '04:00', end_time: '07:00', rate_p_kwh: 15.20, label: 'Morning Cosy Boost' },
      { start_time: '13:00', end_time: '16:00', rate_p_kwh: 15.20, label: 'Afternoon Cosy Boost' },
      { start_time: '16:00', end_time: '19:00', rate_p_kwh: 34.00, label: 'Peak Hours' },
      { start_time: '22:00', end_time: '00:00', rate_p_kwh: 15.20, label: 'Night Cosy Boost' },
    ],
    export_rate_p_kwh: 15.0,
    region: 'london',
    payment_method: 'direct_debit',
    meter_requirements: ['smart_half_hourly'],
    contract_months: 12,
    exit_fee: 0,
    is_green: true,
    effective_date: '2026-05-01',
    description: 'Designed for heat pumps with 3 low-cost heating dips during the day.',
  },
  {
    id: 'bg_fixed_12m',
    supplier: 'British Gas',
    name: 'Fixed Price 12 Months',
    type: 'fixed',
    electricity_unit_rate: 23.20,
    electricity_standing_charge: 57.80,
    gas_unit_rate: 5.95,
    gas_standing_charge: 29.80,
    export_rate_p_kwh: 5.0,
    region: 'london',
    payment_method: 'direct_debit',
    meter_requirements: ['single_rate', 'smart_half_hourly'],
    contract_months: 12,
    exit_fee: 50,
    is_green: false,
    effective_date: '2026-06-15',
    description: 'Lock in unit rates for 12 months below the current Ofgem price cap.',
  },
  {
    id: 'edf_go_electric',
    supplier: 'EDF Energy',
    name: 'GoElectric Overnight',
    type: 'ev',
    electricity_unit_rate: 27.50,
    electricity_standing_charge: 59.00,
    gas_unit_rate: 6.20,
    gas_standing_charge: 31.00,
    time_rates: [
      { start_time: '00:00', end_time: '05:00', rate_p_kwh: 7.90, label: 'Overnight EV' },
      { start_time: '05:00', end_time: '00:00', rate_p_kwh: 27.50, label: 'Standard Rate' },
    ],
    export_rate_p_kwh: 8.0,
    region: 'london',
    payment_method: 'direct_debit',
    meter_requirements: ['smart_half_hourly'],
    contract_months: 12,
    exit_fee: 35,
    is_green: true,
    effective_date: '2026-07-01',
    description: '5 hours of low-cost 7.9p/kWh electricity overnight for EV and home battery.',
  },
  {
    id: 'ovo_simpler',
    supplier: 'OVO Energy',
    name: 'OVO Simpler Energy',
    type: 'variable',
    electricity_unit_rate: 24.30,
    electricity_standing_charge: 59.80,
    gas_unit_rate: 6.18,
    gas_standing_charge: 31.10,
    export_rate_p_kwh: 4.0,
    region: 'london',
    payment_method: 'direct_debit',
    meter_requirements: ['single_rate', 'smart_half_hourly'],
    contract_months: 0,
    exit_fee: 0,
    is_green: true,
    effective_date: '2026-07-01',
    description: 'Variable tariff backed by 100% renewable electricity certification.',
  },
];

// Helper to generate a realistic 48-period consumption profile (in kWh per 30 mins)
export function generateMockSmartMeterData(type: 'family' | 'ev' | 'solar_battery' | 'heat_pump'): SmartMeterDataSet {
  const readings = [];
  const now = new Date('2026-08-10T00:00:00Z');

  // Days to generate
  const days = 14;

  for (let d = 0; d < days; d++) {
    const dayDate = new Date(now.getTime() - (days - 1 - d) * 24 * 3600 * 1000);
    const dayIsoStr = dayDate.toISOString().split('T')[0];

    for (let p = 1; p <= 48; p++) {
      const hour = Math.floor((p - 1) / 2);
      const minute = ((p - 1) % 2) * 30;
      const timeStr = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
      const isoTimestamp = `${dayIsoStr}T${timeStr}:00Z`;

      let baseElec = 0.12 + Math.random() * 0.05; // 0.24 kW baseload
      let baseGas = 0.05 + Math.random() * 0.02;

      // Family profile: morning peak (07:00-09:00), evening peak (17:30-21:00)
      if (type === 'family') {
        if (hour >= 7 && hour <= 9) baseElec += 0.35 + Math.random() * 0.2;
        if (hour >= 17 && hour <= 21) baseElec += 0.45 + Math.random() * 0.3;
        if (hour >= 6 && hour <= 8) baseGas += 0.8 + Math.random() * 0.4; // heating
        if (hour >= 18 && hour <= 21) baseGas += 0.6 + Math.random() * 0.3;
      }
      
      // EV Owner: Unoptimised night charging or evening plug-in
      if (type === 'ev') {
        if (hour >= 18 && hour <= 21) baseElec += 3.2; // 6.4 kW charging peak unoptimised!
        if (hour >= 7 && hour <= 9) baseElec += 0.3;
        if (hour >= 6 && hour <= 8) baseGas += 0.6;
      }

      // Solar & Battery: Lower grid import during day (10:00-16:00)
      if (type === 'solar_battery') {
        if (hour >= 10 && hour <= 16) baseElec = Math.max(0.01, baseElec - 0.25);
        if (hour >= 18 && hour <= 21) baseElec += 0.2;
      }

      // Heat pump: Constant moderate load through day
      if (type === 'heat_pump') {
        if (hour >= 5 && hour <= 22) baseElec += 0.45 + Math.random() * 0.1;
        baseGas = 0; // All electric home
      }

      readings.push({
        timestamp: isoTimestamp,
        settlement_period: p,
        kwh: Number(baseElec.toFixed(3)),
        gas_kwh: Number(baseGas.toFixed(3)),
        estimated: false,
      });
    }
  }

  return {
    id: `smart_data_${type}`,
    name: `${type.toUpperCase().replace('_', ' ')} Smart Meter Profile`,
    householdType: type,
    startDate: '2026-07-27',
    endDate: '2026-08-09',
    region: 'london',
    readings,
    qualityScore: 98.4,
    missingPeriodsCount: 0,
    estimatedCount: 2,
  };
}

export const GRID_CARBON_INTENSITY_G_PER_KWH: number[] = [
  120, 115, 110, 105, 100, 98, 102, 115,  // Night wind dominance (00:00 - 04:00)
  135, 160, 185, 190, 175, 150, 130, 120, // Morning peak (gas turbines) & midday solar offset
  115, 110, 120, 135, 165, 210, 240, 235, // Afternoon to Evening peak (high carbon)
  220, 205, 190, 175, 160, 150, 140, 130  // Late night cooling down
];
