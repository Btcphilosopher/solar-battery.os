/**
 * British Energy Bill Optimiser - Global Types
 */

export type MeterType = 'single_rate' | 'economy_7' | 'smart_half_hourly' | 'prepayment';
export type PaymentMethod = 'direct_debit' | 'standard_credit' | 'prepayment';

export interface UKRegion {
  id: string;
  name: string;
  dnoName: string;
  gridAreaCode: string;
}

export interface PriceCapPeriod {
  id: string;
  name: string; // e.g. "Jul - Sep 2026 Ofgem Cap"
  effective_from: string;
  effective_to: string;
  electricity_unit_rate: number; // p/kWh
  electricity_standing_charge: number; // p/day
  gas_unit_rate: number; // p/kWh
  gas_standing_charge: number; // p/day
  region: string;
  payment_method: PaymentMethod;
  meter_type: MeterType;
}

export interface TimeRateBlock {
  start_time: string; // "00:00"
  end_time: string;   // "04:30"
  rate_p_kwh: number;
  label?: string;
}

export interface Tariff {
  id: string;
  supplier: string;
  name: string;
  type: 'variable' | 'fixed' | 'time_of_use' | 'tracker' | 'ev' | 'heat_pump';
  electricity_unit_rate: number; // p/kWh (for single rate or average)
  electricity_standing_charge: number; // p/day
  gas_unit_rate: number; // p/kWh
  gas_standing_charge: number; // p/day
  time_rates?: TimeRateBlock[]; // for E7 or TOU
  half_hourly_rates?: number[]; // 48 values in p/kWh for dynamic tariffs
  export_rate_p_kwh?: number; // SEG export rate
  region: string;
  payment_method: PaymentMethod;
  meter_requirements: MeterType[];
  contract_months: number;
  exit_fee: number; // £
  is_green: boolean;
  effective_date: string;
  description: string;
}

export interface HalfHourlyReading {
  timestamp: string; // ISO format "2026-08-10T00:00:00Z"
  settlement_period: number; // 1 to 48
  kwh: number;
  gas_kwh?: number;
  estimated?: boolean;
}

export interface SmartMeterDataSet {
  id: string;
  name: string;
  householdType: string;
  startDate: string;
  endDate: string;
  region: string;
  readings: HalfHourlyReading[];
  qualityScore: number; // e.g. 96 (%)
  missingPeriodsCount: number;
  estimatedCount: number;
}

export interface Appliance {
  id: string;
  name: string;
  power_kw: number;
  duration_hours: number;
  energy_kwh: number;
  earliest_start: string; // "00:00"
  latest_finish: string;  // "08:00"
  required_by: string;    // "07:00"
  interruptible: boolean;
  flexible: boolean;
  priority: 'low' | 'medium' | 'high';
}

export interface SolarSystem {
  enabled: boolean;
  capacity_kwp: number;
  annual_generation_kwh: number;
  export_tariff_p_kwh: number;
  self_consumption_pct: number;
}

export interface HomeBattery {
  enabled: boolean;
  capacity_kwh: number;
  max_charge_kw: number;
  max_discharge_kw: number;
  round_trip_efficiency: number; // e.g. 0.90
  min_soc_pct: number; // e.g. 10
  max_soc_pct: number; // e.g. 100
  grid_charging_allowed: boolean;
  capital_cost: number; // £
}

export interface EVConfig {
  enabled: boolean;
  battery_capacity_kwh: number;
  charging_rate_kw: number; // e.g. 7.4
  typical_daily_kwh: number;
  arrival_time: string; // "18:00"
  departure_time: string; // "07:00"
  target_soc_pct: number;
  capital_cost: number;
}

export interface HeatPumpConfig {
  enabled: boolean;
  annual_heat_demand_kwh: number;
  seasonal_cop: number; // e.g. 3.2
  electricity_demand_kwh: number;
  flexible_thermal_storage: boolean;
  capital_cost: number;
}

export interface OptimiserObjective {
  priority: 'cost' | 'carbon' | 'balanced' | 'convenience';
  weight_cost: number;
  weight_carbon: number;
}

export interface SchedulePeriod {
  period: number; // 1 to 48
  time: string; // "00:30"
  rate_p_kwh: number;
  base_load_kw: number;
  ev_charge_kw: number;
  battery_charge_kw: number;
  battery_discharge_kw: number;
  solar_gen_kw: number;
  solar_export_kw: number;
  appliance_load_kw: number;
  net_grid_import_kw: number;
  battery_soc_kwh: number;
  ev_soc_kwh: number;
  cost_gbp: number;
  carbon_gco2: number;
}

export interface OptimisationResult {
  unoptimised_annual_cost: number;
  optimised_annual_cost: number;
  annual_saving_gbp: number;
  carbon_saving_kg: number;
  schedule: SchedulePeriod[];
  savings_breakdown: {
    category: string;
    annual_saving_gbp: number;
    description: string;
  }[];
  confidence: 'HIGH' | 'MEDIUM' | 'LOW';
  confidence_reasons: string[];
}

export interface BillBreakdown {
  electricity_kwh: number;
  electricity_unit_cost: number;
  electricity_standing_cost: number;
  gas_kwh: number;
  gas_unit_cost: number;
  gas_standing_cost: number;
  standing_charges_total: number;
  export_credit: number;
  subtotal: number;
  vat_amount: number; // 5% domestic VAT in UK
  grand_total: number;
  billing_period_days: number;
}

export interface WhatIfScenario {
  id: string;
  name: string;
  annual_cost: number;
  saving_vs_baseline: number;
  capex: number;
  payback_years: number;
  npv: number;
  irr: number;
  description: string;
}
