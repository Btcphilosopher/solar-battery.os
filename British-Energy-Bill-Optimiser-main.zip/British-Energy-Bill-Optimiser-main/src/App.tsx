import React, { useState, useMemo } from 'react';
import { Header } from './components/Header';
import { DashboardView } from './components/DashboardView';
import { ConsumptionView } from './components/ConsumptionView';
import { TariffEngineView } from './components/TariffEngineView';
import { OptimiserView } from './components/OptimiserView';
import { HomeAssetsView } from './components/HomeAssetsView';
import { ForecastView } from './components/ForecastView';
import { ScenariosView } from './components/ScenariosView';
import { BillImportModal } from './components/BillImportModal';
import { RCodeViewerModal } from './components/RCodeViewerModal';

import {
  Tariff,
  SmartMeterDataSet,
  SolarSystem,
  HomeBattery,
  EVConfig,
  HeatPumpConfig,
  OptimiserObjective,
} from './types';
import { CANDIDATE_TARIFFS, generateMockSmartMeterData } from './data/ukMarketData';
import { calculateBillFromReadings } from './utils/billCalculator';
import { analyzeBaseloadAndPeak } from './utils/baseloadDetector';
import { runEnergyOptimisation } from './utils/optimiserEngine';

export default function App() {
  // Navigation & Modal State
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [selectedRegion, setSelectedRegion] = useState<string>('london');
  const [isImportOpen, setIsImportOpen] = useState<boolean>(false);
  const [isRCodeModalOpen, setIsRCodeModalOpen] = useState<boolean>(false);

  // Active Tariff & Household Data
  const [currentTariff, setCurrentTariff] = useState<Tariff>(CANDIDATE_TARIFFS[0]); // British Gas Cap
  const [smartMeterData, setSmartMeterData] = useState<SmartMeterDataSet>(
    generateMockSmartMeterData('ev')
  );

  // Household Clean Tech Assets State
  const [evConfig, setEvConfig] = useState<EVConfig>({
    enabled: true,
    battery_capacity_kwh: 60,
    charging_rate_kw: 7.4,
    typical_daily_kwh: 28,
    arrival_time: '18:00',
    departure_time: '07:00',
    target_soc_pct: 100,
    capital_cost: 850,
  });

  const [batteryConfig, setBatteryConfig] = useState<HomeBattery>({
    enabled: true,
    capacity_kwh: 10,
    max_charge_kw: 3.6,
    max_discharge_kw: 3.6,
    round_trip_efficiency: 0.9,
    min_soc_pct: 10,
    max_soc_pct: 100,
    grid_charging_allowed: true,
    capital_cost: 4500,
  });

  const [solarConfig, setSolarConfig] = useState<SolarSystem>({
    enabled: true,
    capacity_kwp: 4.0,
    annual_generation_kwh: 3600,
    export_tariff_p_kwh: 15.0,
    self_consumption_pct: 40,
  });

  const [heatPumpConfig, setHeatPumpConfig] = useState<HeatPumpConfig>({
    enabled: false,
    annual_heat_demand_kwh: 12000,
    seasonal_cop: 3.2,
    electricity_demand_kwh: 3750,
    flexible_thermal_storage: true,
    capital_cost: 9000,
  });

  const [objective, setObjective] = useState<OptimiserObjective>({
    priority: 'cost',
    weight_cost: 1.0,
    weight_carbon: 0.0,
  });

  // Derived Calculations
  const billBreakdown = useMemo(
    () => calculateBillFromReadings(smartMeterData.readings, currentTariff, 365),
    [smartMeterData, currentTariff]
  );

  const baseloadAnalysis = useMemo(
    () => analyzeBaseloadAndPeak(smartMeterData.readings, currentTariff.electricity_unit_rate),
    [smartMeterData, currentTariff]
  );

  const optimisationResult = useMemo(
    () =>
      runEnergyOptimisation({
        readings: smartMeterData.readings,
        tariff: currentTariff,
        appliances: [],
        solar: solarConfig,
        battery: batteryConfig,
        ev: evConfig,
        heatPump: heatPumpConfig,
        objective,
      }),
    [smartMeterData, currentTariff, solarConfig, batteryConfig, evConfig, heatPumpConfig, objective]
  );

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800 font-sans antialiased selection:bg-sky-500 selection:text-white">
      {/* Header */}
      <Header
        selectedRegion={selectedRegion}
        onSelectRegion={setSelectedRegion}
        onOpenImport={() => setIsImportOpen(true)}
        onOpenRCodeModal={() => setIsRCodeModalOpen(true)}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {activeTab === 'dashboard' && (
          <DashboardView
            currentTariff={currentTariff}
            billBreakdown={billBreakdown}
            optimisationResult={optimisationResult}
            baseloadKw={baseloadAnalysis.avgBaseloadKw}
            annualBaseloadCost={baseloadAnalysis.annualBaseloadCostGbp}
            onNavigateToOptimiser={() => setActiveTab('optimiser')}
            onNavigateToTariffs={() => setActiveTab('tariffs')}
          />
        )}

        {activeTab === 'consumption' && (
          <ConsumptionView
            data={smartMeterData}
            onSelectProfile={(type) => setSmartMeterData(generateMockSmartMeterData(type))}
          />
        )}

        {activeTab === 'tariffs' && (
          <TariffEngineView
            currentTariff={currentTariff}
            smartMeterData={smartMeterData}
            onSelectTariff={(tariff) => setCurrentTariff(tariff)}
          />
        )}

        {activeTab === 'optimiser' && (
          <OptimiserView
            currentTariff={currentTariff}
            optimisationResult={optimisationResult}
            evConfig={evConfig}
            batteryConfig={batteryConfig}
            solarConfig={solarConfig}
            heatPumpConfig={heatPumpConfig}
            objective={objective}
            onChangeObjective={setObjective}
            onUpdateEV={setEvConfig}
            onUpdateBattery={setBatteryConfig}
          />
        )}

        {activeTab === 'assets' && (
          <HomeAssetsView
            solar={solarConfig}
            battery={batteryConfig}
            ev={evConfig}
            heatPump={heatPumpConfig}
            onUpdateSolar={setSolarConfig}
            onUpdateBattery={setBatteryConfig}
            onUpdateEV={setEvConfig}
            onUpdateHeatPump={setHeatPumpConfig}
          />
        )}

        {activeTab === 'forecast' && <ForecastView billBreakdown={billBreakdown} />}

        {activeTab === 'scenarios' && <ScenariosView />}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-6 mt-12 text-xs text-slate-500 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p>© 2026 British Energy Optimiser. Configured for Ofgem Price Caps & UK Distribution Regions.</p>
          <div className="flex space-x-4 font-medium">
            <button onClick={() => setIsRCodeModalOpen(true)} className="hover:text-sky-600 transition">
              R Engine Architecture
            </button>
            <button onClick={() => setIsImportOpen(true)} className="hover:text-sky-600 transition">
              Smart Meter CSV Import
            </button>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <BillImportModal
        isOpen={isImportOpen}
        onClose={() => setIsImportOpen(false)}
        onImportData={(dataSet) => setSmartMeterData(dataSet)}
        onImportManualBill={() => {}}
      />

      <RCodeViewerModal isOpen={isRCodeModalOpen} onClose={() => setIsRCodeModalOpen(false)} />
    </div>
  );
}
