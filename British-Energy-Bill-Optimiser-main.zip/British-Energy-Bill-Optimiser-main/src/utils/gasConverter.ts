/**
 * Standard UK Gas Meter Volumetric to kWh Conversion
 * Formula: kWh = Volume (m³) × Volume Correction Factor (1.02264) × Calorific Value (39.5 MJ/m³) ÷ 3.6
 */

export interface GasConversionParams {
  volume: number;
  unit: 'm3' | 'ft3';
  calorificValue?: number; // Default 39.5 MJ/m³ in UK
  volumeCorrectionFactor?: number; // Default 1.02264
}

export function convertGasToKwh(params: GasConversionParams): number {
  const {
    volume,
    unit,
    calorificValue = 39.5,
    volumeCorrectionFactor = 1.02264,
  } = params;

  // If Imperial (ft³), convert to m³ (1 hundred ft³ ≈ 2.83 m³)
  const volumeM3 = unit === 'ft3' ? volume * 2.83 : volume;

  // Formula
  const kwh = (volumeM3 * volumeCorrectionFactor * calorificValue) / 3.6;
  return Number(kwh.toFixed(2));
}
