import { HalfHourlyReading } from '../types';

export interface BaseloadAnalysis {
  avgBaseloadKw: number;
  minBaseloadKw: number;
  annualBaseloadKwh: number;
  annualBaseloadCostGbp: number;
  peakDemandKw: number;
  peakPeriodTime: string;
  percentile95Kw: number;
}

export function analyzeBaseloadAndPeak(
  readings: HalfHourlyReading[],
  unitRatePence: number = 24.5
): BaseloadAnalysis {
  if (!readings || readings.length === 0) {
    return {
      avgBaseloadKw: 0.2,
      minBaseloadKw: 0.15,
      annualBaseloadKwh: 1752,
      annualBaseloadCostGbp: 429,
      peakDemandKw: 3.5,
      peakPeriodTime: '18:00 - 18:30',
      percentile95Kw: 2.8,
    };
  }

  // Night periods: 01:00 to 05:00 (periods 3 to 10)
  const nightReadings = readings.filter(
    (r) => r.settlement_period >= 3 && r.settlement_period <= 10
  );

  // Convert 30-min kWh to average power in kW (kWh * 2)
  const nightPowersKw = (nightReadings.length > 0 ? nightReadings : readings).map(
    (r) => r.kwh * 2
  );

  nightPowersKw.sort((a, b) => a - b);

  // Bottom 10th percentile of night power as baseload
  const minBaseloadKw = nightPowersKw[0] || 0.15;
  const p10Index = Math.floor(nightPowersKw.length * 0.1);
  const avgBaseloadKw = nightPowersKw[p10Index] || minBaseloadKw;

  const annualBaseloadKwh = avgBaseloadKw * 24 * 365;
  const annualBaseloadCostGbp = (annualBaseloadKwh * unitRatePence) / 100;

  // Peak demand
  let maxKwh = 0;
  let maxPeriod = 37; // default 18:00
  const allPowersKw = readings.map((r) => {
    const kw = r.kwh * 2;
    if (r.kwh > maxKwh) {
      maxKwh = r.kwh;
      maxPeriod = r.settlement_period;
    }
    return kw;
  });

  allPowersKw.sort((a, b) => a - b);
  const p95Idx = Math.floor(allPowersKw.length * 0.95);
  const percentile95Kw = allPowersKw[p95Idx] || maxKwh * 2;

  const peakHour = Math.floor((maxPeriod - 1) / 2);
  const peakMin = ((maxPeriod - 1) % 2) * 30;
  const peakPeriodTime = `${peakHour.toString().padStart(2, '0')}:${peakMin
    .toString()
    .padStart(2, '0')} - ${peakHour.toString().padStart(2, '0')}:${(peakMin + 30)
    .toString()
    .padStart(2, '0')}`;

  return {
    avgBaseloadKw: Number(avgBaseloadKw.toFixed(2)),
    minBaseloadKw: Number(minBaseloadKw.toFixed(2)),
    annualBaseloadKwh: Math.round(annualBaseloadKwh),
    annualBaseloadCostGbp: Math.round(annualBaseloadCostGbp),
    peakDemandKw: Number((maxKwh * 2).toFixed(2)),
    peakPeriodTime,
    percentile95Kw: Number(percentile95Kw.toFixed(2)),
  };
}
