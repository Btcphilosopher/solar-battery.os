import { BillBreakdown } from '../types';

export interface MonthlyForecast {
  monthName: string;
  electricityCost: number;
  gasCost: number;
  standingCharge: number;
  vat: number;
  totalCost: number;
  centralEstimate: number;
  lowEstimate: number;
  highEstimate: number;
}

export interface AnnualForecastReport {
  centralEstimate: number;
  lowEstimate: number;
  highEstimate: number;
  monthlyBreakdown: MonthlyForecast[];
  winterCost: number; // Nov - Feb
  summerCost: number; // May - Aug
}

export function generate12MonthForecast(
  baselineBill: BillBreakdown,
  priceChangeFactor: number = 1.0
): AnnualForecastReport {
  const months = [
    { name: 'Jan', elecWeight: 1.25, gasWeight: 1.85 },
    { name: 'Feb', elecWeight: 1.20, gasWeight: 1.75 },
    { name: 'Mar', elecWeight: 1.10, gasWeight: 1.40 },
    { name: 'Apr', elecWeight: 0.95, gasWeight: 0.90 },
    { name: 'May', elecWeight: 0.85, gasWeight: 0.45 },
    { name: 'Jun', elecWeight: 0.80, gasWeight: 0.25 },
    { name: 'Jul', elecWeight: 0.78, gasWeight: 0.20 },
    { name: 'Aug', elecWeight: 0.80, gasWeight: 0.22 },
    { name: 'Sep', elecWeight: 0.88, gasWeight: 0.40 },
    { name: 'Oct', elecWeight: 1.02, gasWeight: 0.95 },
    { name: 'Nov', elecWeight: 1.15, gasWeight: 1.50 },
    { name: 'Dec', elecWeight: 1.22, gasWeight: 1.80 },
  ];

  const baseElecMonthly = (baselineBill.electricity_unit_cost / 12) * priceChangeFactor;
  const baseGasMonthly = (baselineBill.gas_unit_cost / 12) * priceChangeFactor;
  const monthlyStanding = baselineBill.standing_charges_total / 12;

  let totalCentral = 0;
  let totalLow = 0;
  let totalHigh = 0;
  let winterTotal = 0;
  let summerTotal = 0;

  const monthlyBreakdown: MonthlyForecast[] = months.map((m, idx) => {
    const elecCost = baseElecMonthly * m.elecWeight;
    const gasCost = baseGasMonthly * m.gasWeight;
    const subtotal = elecCost + gasCost + monthlyStanding;
    const vat = subtotal * 0.05;
    const central = Number((subtotal + vat).toFixed(2));

    const low = Number((central * 0.90).toFixed(2));
    const high = Number((central * 1.12).toFixed(2));

    totalCentral += central;
    totalLow += low;
    totalHigh += high;

    if ([0, 1, 10, 11].includes(idx)) winterTotal += central;
    if ([4, 5, 6, 7].includes(idx)) summerTotal += central;

    return {
      monthName: m.name,
      electricityCost: Number(elecCost.toFixed(2)),
      gasCost: Number(gasCost.toFixed(2)),
      standingCharge: Number(monthlyStanding.toFixed(2)),
      vat: Number(vat.toFixed(2)),
      totalCost: central,
      centralEstimate: central,
      lowEstimate: low,
      highEstimate: high,
    };
  });

  return {
    centralEstimate: Math.round(totalCentral),
    lowEstimate: Math.round(totalLow),
    highEstimate: Math.round(totalHigh),
    monthlyBreakdown,
    winterCost: Math.round(winterTotal),
    summerCost: Math.round(summerTotal),
  };
}
