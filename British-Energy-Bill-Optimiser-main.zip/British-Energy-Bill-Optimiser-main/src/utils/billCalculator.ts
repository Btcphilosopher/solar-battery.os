import { Tariff, HalfHourlyReading, BillBreakdown } from '../types';

export function calculateBillFromReadings(
  readings: HalfHourlyReading[],
  tariff: Tariff,
  days: number = 365
): BillBreakdown {
  if (!readings || readings.length === 0) {
    return {
      electricity_kwh: 0,
      electricity_unit_cost: 0,
      electricity_standing_cost: 0,
      gas_kwh: 0,
      gas_unit_cost: 0,
      gas_standing_cost: 0,
      standing_charges_total: 0,
      export_credit: 0,
      subtotal: 0,
      vat_amount: 0,
      grand_total: 0,
      billing_period_days: days,
    };
  }

  // Calculate annual scaling factor if readings cover fewer than `days`
  const sampleDays = Math.max(1, readings.length / 48);
  const scale = days / sampleDays;

  let totalElecKwh = 0;
  let totalGasKwh = 0;
  let elecUnitCostGbp = 0;

  readings.forEach((r) => {
    totalElecKwh += r.kwh;
    totalGasKwh += r.gas_kwh || 0;

    // Determine half-hourly rate
    let hhRatePence = tariff.electricity_unit_rate;

    // Check dynamic half hourly rates if present
    if (tariff.half_hourly_rates && tariff.half_hourly_rates.length === 48) {
      const idx = (r.settlement_period - 1) % 48;
      hhRatePence = tariff.half_hourly_rates[idx];
    } 
    // Check time-of-use blocks if present (e.g., Octopus Go 00:30-04:30)
    else if (tariff.time_rates && tariff.time_rates.length > 0) {
      const p = r.settlement_period;
      const hour = Math.floor((p - 1) / 2);
      const min = ((p - 1) % 2) * 30;
      const hhTime = `${hour.toString().padStart(2, '0')}:${min.toString().padStart(2, '0')}`;

      const matchedBlock = tariff.time_rates.find((b) => {
        if (b.start_time < b.end_time) {
          return hhTime >= b.start_time && hhTime < b.end_time;
        } else {
          // Crosses midnight
          return hhTime >= b.start_time || hhTime < b.end_time;
        }
      });

      if (matchedBlock) {
        hhRatePence = matchedBlock.rate_p_kwh;
      }
    }

    elecUnitCostGbp += (r.kwh * hhRatePence) / 100;
  });

  // Scale to period (e.g. annual)
  const scaledElecKwh = totalElecKwh * scale;
  const scaledGasKwh = totalGasKwh * scale;
  const scaledElecUnitCost = elecUnitCostGbp * scale;

  const gasUnitCostGbp = (scaledGasKwh * tariff.gas_unit_rate) / 100;

  const elecStandingCostGbp = (days * tariff.electricity_standing_charge) / 100;
  const gasStandingCostGbp = (days * tariff.gas_standing_charge) / 100;
  const standingChargesTotal = elecStandingCostGbp + gasStandingCostGbp;

  const subtotal = scaledElecUnitCost + gasUnitCostGbp + standingChargesTotal;
  const vatAmount = subtotal * 0.05; // 5% domestic VAT in UK
  const grandTotal = subtotal + vatAmount;

  return {
    electricity_kwh: Math.round(scaledElecKwh),
    electricity_unit_cost: Number(scaledElecUnitCost.toFixed(2)),
    electricity_standing_cost: Number(elecStandingCostGbp.toFixed(2)),
    gas_kwh: Math.round(scaledGasKwh),
    gas_unit_cost: Number(gasUnitCostGbp.toFixed(2)),
    gas_standing_cost: Number(gasStandingCostGbp.toFixed(2)),
    standing_charges_total: Number(standingChargesTotal.toFixed(2)),
    export_credit: 0,
    subtotal: Number(subtotal.toFixed(2)),
    vat_amount: Number(vatAmount.toFixed(2)),
    grand_total: Number(grandTotal.toFixed(2)),
    billing_period_days: days,
  };
}
