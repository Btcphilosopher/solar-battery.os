import React, { useState } from 'react';
import { Sliders, TrendingDown, DollarSign, Calculator, HelpCircle } from 'lucide-react';

export const ScenariosView: React.FC = () => {
  const [elecPriceChange, setElecPriceChange] = useState<number>(0);
  const [gasPriceChange, setGasPriceChange] = useState<number>(0);

  // Base costs
  const baseCurrent = 1824;
  const baseSmart = 1641;
  const baseSolar = 1512;
  const baseSolarBattery = 1403;

  // Sensitivity factor
  const elecFactor = 1 + elecPriceChange / 100;
  const gasFactor = 1 + gasPriceChange / 100;
  const avgFactor = (elecFactor + gasFactor) / 2;

  const currentCost = Math.round(baseCurrent * avgFactor);
  const smartCost = Math.round(baseSmart * avgFactor);
  const solarCost = Math.round(baseSolar * avgFactor);
  const solarBatteryCost = Math.round(baseSolarBattery * avgFactor);

  const scenarios = [
    {
      name: 'Current Baseline Setup',
      cost: currentCost,
      saving: 0,
      capex: 0,
      payback: '-',
      npv: '£0',
      description: 'Standard Variable Tariff under Ofgem Cap without clean tech assets.',
    },
    {
      name: 'Smart Tariff Switch (Octopus Go / Agile)',
      cost: smartCost,
      saving: currentCost - smartCost,
      capex: 0,
      payback: 'Immediate',
      npv: `£${((currentCost - smartCost) * 8.5).toLocaleString()}`,
      description: 'Zero CAPEX tariff optimization taking advantage of cheap night rates.',
    },
    {
      name: 'Add 4kWp Solar PV System',
      cost: solarCost,
      saving: currentCost - solarCost,
      capex: 4800,
      payback: `${(4800 / Math.max(1, currentCost - solarCost)).toFixed(1)} Years`,
      npv: `£${Math.round((currentCost - solarCost) * 7.72 - 4800).toLocaleString()}`,
      description: 'Generates ~3,600 kWh/yr with SEG export tariff revenue @ 15p/kWh.',
    },
    {
      name: 'Add 4kWp Solar + 10kWh Home Battery',
      cost: solarBatteryCost,
      saving: currentCost - solarBatteryCost,
      capex: 8800,
      payback: `${(8800 / Math.max(1, currentCost - solarBatteryCost)).toFixed(1)} Years`,
      npv: `£${Math.round((currentCost - solarBatteryCost) * 7.72 - 8800).toLocaleString()}`,
      description: 'Stores solar surplus and charges battery on cheap 8.5p/kWh night tariff.',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          What-If Scenario & Price Sensitivity Simulator
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Explore investment paybacks, 10-year NPVs, and tariff risk against future price movements.
        </p>
      </div>

      {/* Sliders Box */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <Sliders className="w-4 h-4 text-emerald-400" />
          Price Movement Sensitivity Controls
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-slate-300 font-medium">Electricity Unit Rate Change:</span>
              <span className={`font-bold font-mono ${elecPriceChange >= 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
                {elecPriceChange > 0 ? `+${elecPriceChange}%` : `${elecPriceChange}%`}
              </span>
            </div>
            <input
              type="range"
              min="-20"
              max="50"
              step="5"
              value={elecPriceChange}
              onChange={(e) => setElecPriceChange(Number(e.target.value))}
              className="w-full accent-emerald-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500">
              <span>-20% (Fall)</span>
              <span>0% (Current 24.5p)</span>
              <span>+50% (Rise 36.7p)</span>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-slate-300 font-medium">Gas Unit Rate Change:</span>
              <span className={`font-bold font-mono ${gasPriceChange >= 0 ? 'text-cyan-400' : 'text-emerald-400'}`}>
                {gasPriceChange > 0 ? `+${gasPriceChange}%` : `${gasPriceChange}%`}
              </span>
            </div>
            <input
              type="range"
              min="-20"
              max="50"
              step="5"
              value={gasPriceChange}
              onChange={(e) => setGasPriceChange(Number(e.target.value))}
              className="w-full accent-cyan-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500">
              <span>-20% (Fall)</span>
              <span>0% (Current 6.24p)</span>
              <span>+50% (Rise 9.36p)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Scenario Table */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {scenarios.map((sc, idx) => (
          <div
            key={idx}
            className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-sm space-y-4 flex flex-col justify-between"
          >
            <div className="space-y-2">
              <span className="text-[10px] uppercase font-bold text-emerald-400 tracking-wider">Option {idx + 1}</span>
              <h3 className="text-base font-bold text-white leading-snug">{sc.name}</h3>
              <p className="text-xs text-slate-400 leading-relaxed">{sc.description}</p>
            </div>

            <div className="space-y-2 pt-3 border-t border-slate-800 font-mono text-xs">
              <div className="flex justify-between">
                <span className="text-slate-400">Annual Cost:</span>
                <span className="text-white font-bold">£{sc.cost.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Annual Saving:</span>
                <span className="text-emerald-400 font-extrabold">+£{sc.saving}/yr</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">CAPEX Cost:</span>
                <span className="text-slate-300">£{sc.capex.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Payback Period:</span>
                <span className="text-amber-400 font-bold">{sc.payback}</span>
              </div>
              <div className="flex justify-between pt-1 border-t border-slate-800/80">
                <span className="text-slate-400">10-Yr NPV (@ 5%):</span>
                <span className="text-sky-400 font-bold">{sc.npv}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
