import React, { useState } from 'react';
import { X, Upload, FileText, Check, AlertCircle } from 'lucide-react';
import Papa from 'papaparse';
import { HalfHourlyReading, SmartMeterDataSet } from '../types';

interface BillImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImportData: (dataSet: SmartMeterDataSet) => void;
  onImportManualBill: (bill: {
    electricity_kwh: number;
    gas_kwh: number;
    elec_unit_rate: number;
    gas_unit_rate: number;
    days: number;
  }) => void;
}

export const BillImportModal: React.FC<BillImportModalProps> = ({
  isOpen,
  onClose,
  onImportData,
  onImportManualBill,
}) => {
  const [activeTab, setActiveTab] = useState<'csv' | 'manual' | 'pdf'>('csv');
  const [csvFile, setCsvFile] = useState<File | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Manual Form State
  const [elecKwh, setElecKwh] = useState<number>(3100);
  const [gasKwh, setGasKwh] = useState<number>(11500);
  const [elecRate, setElecRate] = useState<number>(24.5);
  const [gasRate, setGasRate] = useState<number>(6.24);
  const [billDays, setBillDays] = useState<number>(365);

  if (!isOpen) return null;

  const handleFileUpload = (file: File) => {
    setCsvFile(file);
    setErrorMsg(null);

    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        try {
          const rows = results.data as any[];
          const readings: HalfHourlyReading[] = [];

          rows.forEach((row, idx) => {
            const timestamp = row.timestamp || row.Date || row.Time || new Date().toISOString();
            const kwh = parseFloat(row.consumption_kwh || row.kWh || row.Consumption || '0.2');
            const gasKwh = parseFloat(row.gas_kwh || row.Gas || '0.0');

            if (!isNaN(kwh)) {
              readings.push({
                timestamp,
                settlement_period: (idx % 48) + 1,
                kwh,
                gas_kwh: isNaN(gasKwh) ? 0 : gasKwh,
                estimated: false,
              });
            }
          });

          if (readings.length === 0) {
            setErrorMsg('Could not parse half-hourly readings. Please ensure columns: timestamp, consumption_kwh');
            return;
          }

          const newSet: SmartMeterDataSet = {
            id: `custom_csv_${Date.now()}`,
            name: file.name.replace('.csv', ''),
            householdType: 'custom',
            startDate: readings[0]?.timestamp.split('T')[0] || '2026-08-01',
            endDate: readings[readings.length - 1]?.timestamp.split('T')[0] || '2026-08-10',
            region: 'london',
            readings,
            qualityScore: 96.0,
            missingPeriodsCount: 0,
            estimatedCount: 0,
          };

          onImportData(newSet);
          onClose();
        } catch (err: any) {
          setErrorMsg(`Parse error: ${err.message}`);
        }
      },
    });
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onImportManualBill({
      electricity_kwh: elecKwh,
      gas_kwh: gasKwh,
      elec_unit_rate: elecRate,
      gas_unit_rate: gasRate,
      days: billDays,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-xl w-full shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800">
          <h3 className="text-lg font-bold text-white flex items-center gap-2">
            <Upload className="w-5 h-5 text-emerald-400" />
            Import British Energy Bill or Smart Meter Data
          </h3>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Navigation */}
        <div className="flex border-b border-slate-800 bg-slate-950 px-5 text-xs">
          <button
            onClick={() => setActiveTab('csv')}
            className={`py-3 font-semibold border-b-2 mr-6 transition ${
              activeTab === 'csv'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            CSV Smart Meter Upload
          </button>
          <button
            onClick={() => setActiveTab('manual')}
            className={`py-3 font-semibold border-b-2 mr-6 transition ${
              activeTab === 'manual'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            Manual Bill Entry
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          {errorMsg && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl text-rose-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {activeTab === 'csv' && (
            <div className="space-y-4">
              <div className="border-2 border-dashed border-slate-700 hover:border-emerald-500 rounded-2xl p-8 text-center space-y-3 cursor-pointer transition bg-slate-950/40">
                <Upload className="w-10 h-10 text-emerald-400 mx-auto" />
                <div>
                  <label htmlFor="file-upload" className="text-sm font-semibold text-white cursor-pointer hover:underline">
                    Click to upload CSV file
                  </label>
                  <p className="text-xs text-slate-400 mt-1">
                    Expected format: <code>timestamp, consumption_kwh</code> (Half-Hourly)
                  </p>
                </div>
                <input
                  id="file-upload"
                  type="file"
                  accept=".csv"
                  className="hidden"
                  onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0])}
                />
              </div>

              <div className="p-3 bg-slate-800/50 rounded-xl text-xs text-slate-300 space-y-1">
                <div className="font-semibold text-white">Sample CSV structure:</div>
                <pre className="font-mono text-[11px] text-emerald-300">
                  timestamp, consumption_kwh{'\n'}
                  2026-08-10 00:00, 0.21{'\n'}
                  2026-08-10 00:30, 0.18{'\n'}
                  2026-08-10 01:00, 0.17
                </pre>
              </div>
            </div>
          )}

          {activeTab === 'manual' && (
            <form onSubmit={handleManualSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Annual Elec Consumption (kWh)</label>
                  <input
                    type="number"
                    value={elecKwh}
                    onChange={(e) => setElecKwh(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-mono focus:border-emerald-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Annual Gas Consumption (kWh)</label>
                  <input
                    type="number"
                    value={gasKwh}
                    onChange={(e) => setGasKwh(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-mono focus:border-emerald-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Elec Unit Rate (p/kWh)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={elecRate}
                    onChange={(e) => setElecRate(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-mono focus:border-emerald-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">Gas Unit Rate (p/kWh)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={gasRate}
                    onChange={(e) => setGasRate(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-mono focus:border-emerald-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Billing Period Days</label>
                <input
                  type="number"
                  value={billDays}
                  onChange={(e) => setBillDays(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-white font-mono focus:border-emerald-500 focus:outline-none"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold py-3 rounded-xl transition shadow"
              >
                Save & Recalculate Energy Bill
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
