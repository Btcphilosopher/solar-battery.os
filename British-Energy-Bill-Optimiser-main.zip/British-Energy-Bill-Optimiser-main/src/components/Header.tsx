import React from 'react';
import { UK_REGIONS, OFGEM_PRICE_CAPS } from '../data/ukMarketData';
import { UKRegion } from '../types';
import { ShieldAlert, Code2, Upload, HelpCircle, MapPin, Zap } from 'lucide-react';

interface HeaderProps {
  selectedRegion: string;
  onSelectRegion: (regionId: string) => void;
  onOpenImport: () => void;
  onOpenRCodeModal: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  selectedRegion,
  onSelectRegion,
  onOpenImport,
  onOpenRCodeModal,
  activeTab,
  setActiveTab,
}) => {
  const cap = OFGEM_PRICE_CAPS[0];
  const regionObj = UK_REGIONS.find((r) => r.id === selectedRegion) || UK_REGIONS[0];

  const navItems = [
    { id: 'dashboard', label: 'Dashboard' },
    { id: 'consumption', label: 'Consumption' },
    { id: 'tariffs', label: 'Tariff Finder' },
    { id: 'optimiser', label: 'TOU Optimiser' },
    { id: 'assets', label: 'Solar & Battery' },
    { id: 'forecast', label: 'Bill Forecast' },
    { id: 'scenarios', label: 'What-If Scenarios' },
  ];

  return (
    <header className="bg-[#0f172a] text-white border-b border-slate-800 sticky top-0 z-30 shadow-md">
      {/* Top Banner */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-wrap items-center justify-between gap-4">
        {/* Brand */}
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-sky-500/20 border border-sky-500/40 flex items-center justify-center text-sky-400 shadow-inner">
            <Zap className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tight text-white uppercase flex items-center gap-2">
              British Energy Optimiser
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-sky-500/20 text-sky-300 border border-sky-500/30 font-semibold tracking-wide">
                Professional
              </span>
            </h1>
            <p className="text-[11px] text-slate-400 font-mono tracking-wider uppercase">
              Household Energy Economy & TOU Scheduler
            </p>
          </div>
        </div>

        {/* Region & Ofgem Price Cap Bar */}
        <div className="flex items-center space-x-3 text-xs">
          {/* Region Selector */}
          <div className="flex items-center space-x-1.5 bg-slate-800/80 border border-slate-700/80 px-3 py-1.5 rounded-lg text-slate-200">
            <MapPin className="w-3.5 h-3.5 text-sky-400" />
            <span className="text-slate-400 font-medium">DNO:</span>
            <select
              value={selectedRegion}
              onChange={(e) => onSelectRegion(e.target.value)}
              className="bg-transparent text-white focus:outline-none cursor-pointer font-semibold"
            >
              {UK_REGIONS.map((r) => (
                <option key={r.id} value={r.id} className="bg-slate-900 text-white">
                  {r.name} ({r.gridAreaCode})
                </option>
              ))}
            </select>
          </div>

          {/* Ofgem Cap Badge */}
          <div className="hidden md:flex items-center space-x-2 bg-slate-800/80 border border-slate-700/80 px-3 py-1.5 rounded-lg text-slate-300">
            <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
            <span className="font-medium text-slate-400">Ofgem Cap:</span>
            <span className="font-bold text-sky-400">{cap.electricity_unit_rate}p/kWh</span>
            <span className="text-slate-600">|</span>
            <span className="font-bold text-cyan-400">{cap.gas_unit_rate}p/kWh</span>
          </div>

          {/* Import & R-Code Buttons */}
          <button
            onClick={onOpenImport}
            className="flex items-center space-x-1.5 bg-sky-600 hover:bg-sky-500 text-white font-semibold px-3.5 py-1.5 rounded-lg transition text-xs shadow-sm"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Import Bill / HH Data</span>
          </button>

          <button
            onClick={onOpenRCodeModal}
            className="flex items-center space-x-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 font-medium px-3 py-1.5 rounded-lg transition text-xs"
          >
            <Code2 className="w-3.5 h-3.5 text-amber-400" />
            <span>R Engine Code</span>
          </button>
        </div>
      </div>

      {/* Navigation Bar */}
      <div className="bg-slate-950/80 border-t border-slate-800 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex space-x-1 overflow-x-auto py-1 scrollbar-none">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`px-4 py-2 text-xs font-semibold rounded-md whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-sky-600 text-white shadow-sm border-l-2 border-sky-300 font-bold'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
