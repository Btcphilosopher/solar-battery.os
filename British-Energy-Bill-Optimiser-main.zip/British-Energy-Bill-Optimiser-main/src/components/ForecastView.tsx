import React, { useMemo } from 'react';
import { BillBreakdown } from '../types';
import { generate12MonthForecast } from '../utils/forecaster';
import {
  ResponsiveContainer,
  ComposedChart,
  Bar,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
} from 'recharts';
import { Calendar, TrendingUp, ShieldAlert, Zap, Flame } from 'lucide-react';

interface ForecastViewProps {
  billBreakdown: BillBreakdown;
}

export const ForecastView: React.FC<ForecastViewProps> = ({ billBreakdown }) => {
  const forecast = useMemo(() => generate12MonthForecast(billBreakdown, 1.0), [billBreakdown]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            12-Month Rolling Bill Forecast Engine
            <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-sky-50 text-sky-700 border border-sky-200 font-bold">
              Seasonal Degree-Days Weighting
            </span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Modeled seasonality for UK heating demand and daylight hours.
          </p>
        </div>

        {/* Central Estimate Display */}
        <div className="text-right bg-sky-50 p-3 px-5 rounded-xl border border-sky-200">
          <span className="text-[10px] text-sky-800 block uppercase tracking-wider font-bold">Annual Central Forecast</span>
          <span className="text-2xl font-black text-sky-700">£{forecast.centralEstimate.toLocaleString()}</span>
          <span className="text-[11px] text-slate-600 block font-mono font-medium">Range: £{forecast.lowEstimate} – £{forecast.highEstimate}</span>
        </div>
      </div>

      {/* Seasonal Breakdown Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-2">
          <div className="flex justify-between items-center text-sky-700 text-xs font-bold uppercase tracking-wider">
            <span>Winter Period (Nov - Feb)</span>
            <Flame className="w-4 h-4" />
          </div>
          <div className="text-3xl font-extrabold text-sky-700">
            £{forecast.winterCost.toLocaleString()}
          </div>
          <p className="text-xs text-slate-500 font-medium">Peak space heating demand & higher lighting load.</p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-2">
          <div className="flex justify-between items-center text-amber-700 text-xs font-bold uppercase tracking-wider">
            <span>Summer Period (May - Aug)</span>
            <Zap className="w-4 h-4" />
          </div>
          <div className="text-3xl font-extrabold text-amber-700">
            £{forecast.summerCost.toLocaleString()}
          </div>
          <p className="text-xs text-slate-500 font-medium">Baseload hot water & summer solar PV offset.</p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-2">
          <div className="flex justify-between items-center text-emerald-700 text-xs font-bold uppercase tracking-wider">
            <span>VAT & Standing Charges</span>
            <TrendingUp className="w-4 h-4" />
          </div>
          <div className="text-3xl font-extrabold text-emerald-700">
            £{Math.round(billBreakdown.standing_charges_total + billBreakdown.vat_amount).toLocaleString()}
          </div>
          <p className="text-xs text-slate-500 font-medium">Fixed annual baseline cost regardless of usage.</p>
        </div>
      </div>

      {/* 12-Month Forecast Chart */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm space-y-4">
        <h3 className="text-base font-bold text-slate-900">Monthly Energy Cost Forecast & Confidence Interval</h3>

        <div className="h-80 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={forecast.monthlyBreakdown} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" opacity={0.8} />
              <XAxis dataKey="monthName" stroke="#64748b" fontSize={11} />
              <YAxis stroke="#64748b" fontSize={11} label={{ value: 'Cost (£)', angle: -90, position: 'insideLeft', fill: '#64748b', fontSize: 11 }} />
              <Tooltip contentStyle={{ backgroundColor: '#ffffff', borderColor: '#cbd5e1', borderRadius: '0.5rem', fontSize: '12px', color: '#0f172a' }} />
              <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
              <Area type="monotone" dataKey="highEstimate" name="High Risk (+12%)" fill="#f43f5e" fillOpacity={0.1} stroke="#f43f5e" strokeDasharray="3 3" />
              <Bar dataKey="electricityCost" name="Electricity (£)" stackId="a" fill="#0284c7" />
              <Bar dataKey="gasCost" name="Gas (£)" stackId="a" fill="#0891b2" />
              <Bar dataKey="standingCharge" name="Standing Charge (£)" stackId="a" fill="#94a3b8" />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
