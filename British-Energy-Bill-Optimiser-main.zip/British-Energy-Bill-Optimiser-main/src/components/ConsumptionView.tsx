import React, { useState, useMemo } from 'react';
import { SmartMeterDataSet } from '../types';
import { evaluateDataQuality } from '../utils/dataQualityEngine';
import { analyzeBaseloadAndPeak } from '../utils/baseloadDetector';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';
import {
  Zap,
  Activity,
  AlertCircle,
  Calendar,
  CheckCircle2,
  TrendingUp,
  Clock,
  Layers,
} from 'lucide-react';

interface ConsumptionViewProps {
  data: SmartMeterDataSet;
  onSelectProfile: (type: 'family' | 'ev' | 'solar_battery' | 'heat_pump') => void;
}

export const ConsumptionView: React.FC<ConsumptionViewProps> = ({
  data,
  onSelectProfile,
}) => {
  const [viewMode, setViewMode] = useState<'half_hourly' | 'daily' | 'heatmap'>('half_hourly');

  // Quality Report
  const qualityReport = useMemo(() => evaluateDataQuality(data.readings), [data]);

  // Baseload & Peak
  const baseload = useMemo(() => analyzeBaseloadAndPeak(data.readings), [data]);

  // Average 48 settlement period profile
  const averageProfile = useMemo(() => {
    const periodSums = new Array(48).fill(0);
    const periodCounts = new Array(48).fill(0);
    const gasSums = new Array(48).fill(0);

    data.readings.forEach((r) => {
      const idx = r.settlement_period - 1;
      if (idx >= 0 && idx < 48) {
        periodSums[idx] += r.kwh;
        gasSums[idx] += r.gas_kwh || 0;
        periodCounts[idx]++;
      }
    });

    return Array.from({ length: 48 }, (_, i) => {
      const count = Math.max(1, periodCounts[i]);
      const hour = Math.floor(i / 2);
      const min = (i % 2) * 30;
      const timeStr = `${hour.toString().padStart(2, '0')}:${min.toString().padStart(2, '0')}`;
      const avgElecKwh = periodSums[i] / count;
      const avgGasKwh = gasSums[i] / count;
      return {
        period: i + 1,
        time: timeStr,
        electricity_kw: Number((avgElecKwh * 2).toFixed(2)), // Convert 30m kWh to average kW
        gas_kw: Number((avgGasKwh * 2).toFixed(2)),
        kwh: Number(avgElecKwh.toFixed(3)),
      };
    });
  }, [data]);

  // Heatmap Data (Days x 48 Periods)
  const heatmapGrid = useMemo(() => {
    const daysMap: Record<string, number[]> = {};

    data.readings.forEach((r) => {
      const dateStr = r.timestamp.split('T')[0];
      if (!daysMap[dateStr]) {
        daysMap[dateStr] = new Array(48).fill(0);
      }
      daysMap[dateStr][r.settlement_period - 1] = r.kwh;
    });

    const dates = Object.keys(daysMap).sort();
    return { dates, daysMap };
  }, [data]);

  // Max value for heatmap color intensity scaling
  const maxHeatmapKwh = useMemo(() => {
    let maxVal = 0.5;
    data.readings.forEach((r) => {
      if (r.kwh > maxVal) maxVal = r.kwh;
    });
    return maxVal;
  }, [data]);

  return (
    <div className="space-y-6">
      {/* Top Profile Selection & Quality Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            Half-Hourly Smart Meter Analytics
            <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-sky-50 text-sky-700 border border-sky-200 font-bold">
              48 Settlement Periods / Day
            </span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Profile: <strong className="text-slate-800">{data.name}</strong> ({data.readings.length} total half-hourly readings)
          </p>
        </div>

        {/* Preset Profiles Picker */}
        <div className="flex items-center space-x-2 text-xs">
          <span className="text-slate-500 font-semibold">Load Mock Preset:</span>
          {(['family', 'ev', 'solar_battery', 'heat_pump'] as const).map((type) => (
            <button
              key={type}
              onClick={() => onSelectProfile(type)}
              className={`px-3 py-1.5 rounded-lg border text-xs font-bold capitalize transition shadow-xs ${
                data.householdType === type
                  ? 'bg-sky-600 text-white border-sky-600'
                  : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
              }`}
            >
              {type.replace('_', ' ')}
            </button>
          ))}
        </div>
      </div>

      {/* Baseload, Peak Demand & Quality Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1: Quality Score */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-2">
          <div className="flex justify-between items-center text-slate-500 text-xs">
            <span className="font-bold text-[10px] uppercase tracking-wider">Data Quality</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-3xl font-extrabold text-slate-900">
            {qualityReport.scorePct}%
          </div>
          <div className="text-xs text-slate-500 flex justify-between font-medium">
            <span>Missing Periods:</span>
            <span className="text-slate-900">{qualityReport.missingPeriods}</span>
          </div>
          <div className="text-xs text-slate-500 flex justify-between font-medium">
            <span>GMT/BST Handling:</span>
            <span className="text-emerald-700 font-bold">Active</span>
          </div>
        </div>

        {/* Metric 2: Baseload */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-2">
          <div className="flex justify-between items-center text-slate-500 text-xs">
            <span className="font-bold text-[10px] uppercase tracking-wider">Continuous Baseload</span>
            <Activity className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-3xl font-extrabold text-amber-700">
            {baseload.avgBaseloadKw} kW
          </div>
          <div className="text-xs text-slate-500 flex justify-between font-medium">
            <span>Annualised Baseload:</span>
            <span className="text-slate-900">{baseload.annualBaseloadKwh} kWh</span>
          </div>
          <div className="text-xs text-slate-500 flex justify-between font-medium">
            <span>Baseload Cost:</span>
            <span className="text-amber-700 font-bold">~£{baseload.annualBaseloadCostGbp}/yr</span>
          </div>
        </div>

        {/* Metric 3: Peak Demand */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-2">
          <div className="flex justify-between items-center text-slate-500 text-xs">
            <span className="font-bold text-[10px] uppercase tracking-wider">Max Peak Demand</span>
            <TrendingUp className="w-4 h-4 text-rose-600" />
          </div>
          <div className="text-3xl font-extrabold text-rose-600">
            {baseload.peakDemandKw} kW
          </div>
          <div className="text-xs text-slate-500 flex justify-between font-medium">
            <span>Peak Time Window:</span>
            <span className="text-slate-900">{baseload.peakPeriodTime}</span>
          </div>
          <div className="text-xs text-slate-500 flex justify-between font-medium">
            <span>95th Percentile:</span>
            <span className="text-slate-900">{baseload.percentile95Kw} kW</span>
          </div>
        </div>

        {/* Metric 4: Daily Average */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-2">
          <div className="flex justify-between items-center text-slate-500 text-xs">
            <span className="font-bold text-[10px] uppercase tracking-wider">Daily Average</span>
            <Zap className="w-4 h-4 text-sky-600" />
          </div>
          <div className="text-3xl font-extrabold text-slate-900">
            {Number((data.readings.reduce((sum, r) => sum + r.kwh, 0) / (data.readings.length / 48)).toFixed(2))} kWh
          </div>
          <div className="text-xs text-slate-500 flex justify-between font-medium">
            <span>Annualised Elec:</span>
            <span className="text-sky-700 font-bold">
              {Math.round((data.readings.reduce((sum, r) => sum + r.kwh, 0) / (data.readings.length / 48)) * 365)} kWh/yr
            </span>
          </div>
        </div>
      </div>

      {/* Main View Mode Selector (Profile Chart vs Heatmap) */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-200">
          <div>
            <h3 className="text-base font-bold text-slate-900">Consumption Profile Visualiser</h3>
            <p className="text-xs text-slate-500">
              Interactive 48 settlement period curves & intensity heatmap
            </p>
          </div>

          <div className="flex space-x-1 bg-slate-100 p-1 rounded-lg border border-slate-200 text-xs font-semibold">
            <button
              onClick={() => setViewMode('half_hourly')}
              className={`px-3 py-1.5 rounded-md transition ${
                viewMode === 'half_hourly'
                  ? 'bg-sky-600 text-white font-bold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              24-Hour Profile
            </button>
            <button
              onClick={() => setViewMode('heatmap')}
              className={`px-3 py-1.5 rounded-md transition ${
                viewMode === 'heatmap'
                  ? 'bg-sky-600 text-white font-bold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              24h × Days Heatmap
            </button>
          </div>
        </div>

        {/* View Mode 1: 24-Hour Profile Chart */}
        {viewMode === 'half_hourly' && (
          <div className="space-y-4">
            <div className="h-80 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={averageProfile} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="elecGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#0284c7" stopOpacity={0.8} />
                      <stop offset="95%" stopColor="#0284c7" stopOpacity={0.0} />
                    </linearGradient>
                    <linearGradient id="gasGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#0891b2" stopOpacity={0.6} />
                      <stop offset="95%" stopColor="#0891b2" stopOpacity={0.0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" opacity={0.8} />
                  <XAxis dataKey="time" stroke="#64748b" fontSize={11} interval={3} />
                  <YAxis stroke="#64748b" fontSize={11} label={{ value: 'Average Power (kW)', angle: -90, position: 'insideLeft', fill: '#64748b', fontSize: 11 }} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#ffffff', borderColor: '#cbd5e1', borderRadius: '0.5rem', fontSize: '12px', color: '#0f172a' }}
                    formatter={(val: number) => [`${val} kW`, 'Power']}
                  />
                  <Area type="monotone" dataKey="electricity_kw" name="Electricity Power (kW)" stroke="#0284c7" fillOpacity={1} fill="url(#elecGrad)" strokeWidth={2} />
                  <Area type="monotone" dataKey="gas_kw" name="Gas Heating Power (kW)" stroke="#0891b2" fillOpacity={1} fill="url(#gasGrad)" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <div className="flex justify-center space-x-6 text-xs text-slate-600 font-semibold pt-2">
              <span className="flex items-center gap-2">
                <span className="w-3 h-3 rounded bg-sky-600"></span> Electricity Load (kW)
              </span>
              <span className="flex items-center gap-2">
                <span className="w-3 h-3 rounded bg-cyan-600"></span> Gas Load Equivalent (kW)
              </span>
            </div>
          </div>
        )}

        {/* View Mode 2: 24h x Days Consumption Heatmap */}
        {viewMode === 'heatmap' && (
          <div className="space-y-4">
            <div className="text-xs text-slate-500 font-medium flex items-center justify-between">
              <span>Rows = Days | Columns = 48 Half-Hour Settlement Periods (00:00 to 23:30)</span>
              <div className="flex items-center space-x-2">
                <span>Low</span>
                <div className="w-24 h-3 bg-gradient-to-r from-slate-200 via-sky-500 to-rose-500 rounded"></div>
                <span>High</span>
              </div>
            </div>

            <div className="overflow-x-auto border border-slate-200 rounded-xl p-3 bg-slate-50">
              <div className="min-w-[800px] space-y-1">
                {/* Header Row: Settlement Periods */}
                <div className="grid grid-cols-49 text-[10px] text-slate-500 font-mono text-center border-b border-slate-200 pb-1">
                  <div className="text-left font-bold text-slate-700">Date</div>
                  {Array.from({ length: 48 }, (_, i) => (
                    <div key={i}>{i % 4 === 0 ? `${Math.floor(i / 2)}h` : ''}</div>
                  ))}
                </div>

                {/* Days Rows */}
                {heatmapGrid.dates.slice(-10).map((date) => {
                  const dayReadings = heatmapGrid.daysMap[date] || [];
                  return (
                    <div key={date} className="grid grid-cols-49 items-center gap-0.5 text-[10px]">
                      <div className="font-mono text-slate-600 truncate text-[10px] font-medium">{date.slice(5)}</div>
                      {dayReadings.map((kwh, pIdx) => {
                        const intensity = Math.min(1.0, kwh / maxHeatmapKwh);
                        let bgColor = 'bg-slate-200';
                        if (intensity > 0.8) bgColor = 'bg-rose-500';
                        else if (intensity > 0.5) bgColor = 'bg-amber-500';
                        else if (intensity > 0.2) bgColor = 'bg-sky-500';
                        else if (intensity > 0.05) bgColor = 'bg-sky-200';

                        return (
                          <div
                            key={pIdx}
                            title={`Period ${pIdx + 1} (${Math.floor(pIdx / 2)}:${(pIdx % 2) * 30}): ${kwh} kWh`}
                            className={`h-5 rounded-xs ${bgColor} transition-opacity hover:opacity-80 cursor-pointer`}
                          />
                        );
                      })}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
