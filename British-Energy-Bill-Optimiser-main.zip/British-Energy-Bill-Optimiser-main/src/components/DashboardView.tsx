import React from 'react';
import { Tariff, BillBreakdown, OptimisationResult } from '../types';
import { OFGEM_PRICE_CAPS } from '../data/ukMarketData';
import {
  PoundSterling,
  TrendingDown,
  Zap,
  Flame,
  Clock,
  ArrowUpRight,
  Sparkles,
  ShieldCheck,
  AlertTriangle,
} from 'lucide-react';

interface DashboardViewProps {
  currentTariff: Tariff;
  billBreakdown: BillBreakdown;
  optimisationResult: OptimisationResult;
  baseloadKw: number;
  annualBaseloadCost: number;
  onNavigateToOptimiser: () => void;
  onNavigateToTariffs: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  currentTariff,
  billBreakdown,
  optimisationResult,
  baseloadKw,
  annualBaseloadCost,
  onNavigateToOptimiser,
  onNavigateToTariffs,
}) => {
  const cap = OFGEM_PRICE_CAPS[0];

  return (
    <div className="space-y-6">
      {/* Primary Question Callout Banner */}
      <div className="bg-[#0f172a] border border-slate-800 rounded-xl p-6 text-white shadow-md relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none">
          <Zap className="w-64 h-64 text-sky-400" />
        </div>
        <div className="relative z-10 max-w-3xl space-y-2">
          <div className="flex items-center space-x-2 text-sky-400 text-[10px] uppercase tracking-widest font-bold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>British Energy Optimiser Core Directive</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
            "What is the cheapest sensible way for this household to buy and use energy?"
          </h2>
          <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
            Analysing your half-hourly consumption, standing charges, 5% domestic VAT, and time-of-use flexibility against 14 DNO regional tariff rates.
          </p>
        </div>
      </div>

      {/* Top 4 Key Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Current Cost (This Month) */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Current Cost</span>
            <span className="p-2 bg-slate-100 rounded-lg text-sky-600">
              <PoundSterling className="w-4 h-4" />
            </span>
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-extrabold text-slate-900">£143.82</div>
            <div className="text-xs text-slate-500 mt-1">Estimated this month</div>
          </div>
          <div className="pt-2 border-t border-slate-100 text-xs space-y-1 text-slate-600 font-medium">
            <div className="flex justify-between">
              <span className="flex items-center gap-1.5"><Zap className="w-3 h-3 text-sky-600" /> Electricity:</span>
              <span className="font-semibold text-slate-900">£72.40</span>
            </div>
            <div className="flex justify-between">
              <span className="flex items-center gap-1.5"><Flame className="w-3 h-3 text-cyan-600" /> Gas:</span>
              <span className="font-semibold text-slate-900">£51.12</span>
            </div>
            <div className="flex justify-between">
              <span className="flex items-center gap-1.5"><Clock className="w-3 h-3 text-amber-600" /> Standing Charges:</span>
              <span className="font-semibold text-slate-900">£20.30</span>
            </div>
          </div>
        </div>

        {/* Card 2: Annual Forecast */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Annual Forecast</span>
            <span className="p-2 bg-slate-100 rounded-lg text-sky-600">
              <PoundSterling className="w-4 h-4" />
            </span>
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-extrabold text-slate-900">
              £{billBreakdown.grand_total.toLocaleString()}
            </div>
            <div className="text-xs text-slate-500 mt-1">Central estimate (365 days)</div>
          </div>
          <div className="pt-2 border-t border-slate-100 text-xs text-slate-600 space-y-1 font-medium">
            <div className="flex justify-between">
              <span>Likely Range:</span>
              <span className="text-slate-900 font-semibold">£1,520 – £1,870</span>
            </div>
            <div className="flex justify-between">
              <span>Winter Period (Nov-Feb):</span>
              <span className="text-sky-700 font-semibold">£840</span>
            </div>
          </div>
        </div>

        {/* Card 3: Potential Saving */}
        <div className="bg-sky-50 border border-sky-200 rounded-xl p-5 shadow-sm space-y-3 relative">
          <div className="flex items-center justify-between text-sky-800">
            <span className="text-[10px] font-bold uppercase tracking-wider text-sky-800">Potential Saving</span>
            <span className="p-2 bg-sky-100 rounded-lg text-sky-700 border border-sky-200">
              <TrendingDown className="w-4 h-4" />
            </span>
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-black text-sky-900">
              £{optimisationResult.annual_saving_gbp} <span className="text-xs font-semibold text-sky-700">/ year</span>
            </div>
            <div className="text-xs text-sky-700 font-medium mt-1">Via tariff switch & load shifting</div>
          </div>
          <button
            onClick={onNavigateToOptimiser}
            className="w-full mt-2 bg-sky-600 hover:bg-sky-700 text-white font-bold py-2 px-3 rounded-lg text-xs flex items-center justify-center space-x-1 transition shadow-sm"
          >
            <span>View Optimised Schedule</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Card 4: Baseload Monitor */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Baseload Power</span>
            <span className="p-2 bg-amber-50 rounded-lg text-amber-600 border border-amber-200">
              <AlertTriangle className="w-4 h-4" />
            </span>
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-extrabold text-amber-700">{baseloadKw} kW</div>
            <div className="text-xs text-slate-500 mt-1">Overnight minimum continuous load</div>
          </div>
          <div className="pt-2 border-t border-slate-100 text-xs space-y-1 text-slate-600">
            <div className="flex justify-between font-medium">
              <span>Annual Baseload Cost:</span>
              <span className="font-bold text-amber-700">£{annualBaseloadCost}/yr</span>
            </div>
            <div className="text-[11px] text-slate-500">
              Check routers, servers, fridges, immersion heaters.
            </div>
          </div>
        </div>
      </div>

      {/* Main Analytical Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column (2/3): Itemised Energy Bill Breakdown */}
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-xl p-6 shadow-sm space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-slate-200">
            <div>
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                Itemised Energy Bill Breakdown
                <span className="text-[10px] px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-mono font-semibold border border-slate-200">
                  5% Domestic UK VAT
                </span>
              </h3>
              <p className="text-xs text-slate-500">
                Transparent math for {billBreakdown.billing_period_days} days under {currentTariff.name}
              </p>
            </div>
          </div>

          <div className="space-y-4">
            {/* Electricity Section */}
            <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 space-y-2 text-sm">
              <div className="flex justify-between items-center text-sky-800 font-bold border-b border-slate-200 pb-2">
                <span className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-sky-600" /> Electricity ({billBreakdown.electricity_kwh.toLocaleString()} kWh)
                </span>
                <span>£{billBreakdown.electricity_unit_cost.toLocaleString()}</span>
              </div>
              <div className="text-xs text-slate-600 flex justify-between font-medium">
                <span>Unit Rate ({currentTariff.electricity_unit_rate}p/kWh):</span>
                <span className="text-slate-900">£{billBreakdown.electricity_unit_cost.toLocaleString()}</span>
              </div>
              <div className="text-xs text-slate-600 flex justify-between font-medium">
                <span>Standing Charge ({currentTariff.electricity_standing_charge}p/day × 365 days):</span>
                <span className="text-slate-900">£{billBreakdown.electricity_standing_cost.toLocaleString()}</span>
              </div>
            </div>

            {/* Gas Section */}
            <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 space-y-2 text-sm">
              <div className="flex justify-between items-center text-cyan-800 font-bold border-b border-slate-200 pb-2">
                <span className="flex items-center gap-2">
                  <Flame className="w-4 h-4 text-cyan-600" /> Gas ({billBreakdown.gas_kwh.toLocaleString()} kWh)
                </span>
                <span>£{billBreakdown.gas_unit_cost.toLocaleString()}</span>
              </div>
              <div className="text-xs text-slate-600 flex justify-between font-medium">
                <span>Unit Rate ({currentTariff.gas_unit_rate}p/kWh):</span>
                <span className="text-slate-900">£{billBreakdown.gas_unit_cost.toLocaleString()}</span>
              </div>
              <div className="text-xs text-slate-600 flex justify-between font-medium">
                <span>Standing Charge ({currentTariff.gas_standing_charge}p/day × 365 days):</span>
                <span className="text-slate-900">£{billBreakdown.gas_standing_cost.toLocaleString()}</span>
              </div>
            </div>

            {/* Total Math Summary */}
            <div className="bg-slate-900 text-white rounded-xl p-4 border border-slate-800 space-y-2 text-sm font-mono shadow-sm">
              <div className="flex justify-between text-slate-300">
                <span>Standing Charges Total:</span>
                <span>£{billBreakdown.standing_charges_total.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Subtotal (Excl. VAT):</span>
                <span>£{billBreakdown.subtotal.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-sky-400">
                <span>UK Domestic VAT (5%):</span>
                <span>+£{billBreakdown.vat_amount.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-white text-base font-bold pt-2 border-t border-slate-800">
                <span>GRAND TOTAL (Annual):</span>
                <span className="text-sky-400">£{billBreakdown.grand_total.toLocaleString()}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column (1/3): Current Tariff vs Ofgem Benchmark */}
        <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm space-y-6 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-sky-600" />
                Current Tariff Benchmark
              </h3>
            </div>

            <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 space-y-3 text-xs">
              <div>
                <span className="text-slate-500 font-medium block">Active Plan:</span>
                <span className="text-sm font-bold text-slate-900">{currentTariff.name}</span>
                <span className="text-[11px] text-sky-700 font-semibold block">{currentTariff.supplier}</span>
              </div>

              <div className="space-y-1.5 pt-2 border-t border-slate-200 font-medium">
                <div className="flex justify-between">
                  <span className="text-slate-600">Electricity Rate:</span>
                  <span className="font-bold text-slate-900">{currentTariff.electricity_unit_rate}p / kWh</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Electricity Standing:</span>
                  <span className="font-bold text-slate-900">{currentTariff.electricity_standing_charge}p / day</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Gas Rate:</span>
                  <span className="font-bold text-slate-900">{currentTariff.gas_unit_rate}p / kWh</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-600">Gas Standing:</span>
                  <span className="font-bold text-slate-900">{currentTariff.gas_standing_charge}p / day</span>
                </div>
              </div>
            </div>

            {/* Benchmark vs Ofgem Cap */}
            <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs space-y-1.5">
              <div className="font-bold text-amber-900 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-amber-600" />
                Ofgem Cap Benchmark ({cap.name})
              </div>
              <p className="text-slate-700 text-[11px] leading-relaxed">
                Your electricity rate ({currentTariff.electricity_unit_rate}p) is{' '}
                {currentTariff.electricity_unit_rate <= cap.electricity_unit_rate ? (
                  <span className="text-emerald-700 font-bold">below the Ofgem price cap</span>
                ) : (
                  <span className="text-rose-700 font-bold">above the cap</span>
                )}
                .
              </p>
            </div>
          </div>

          <div className="space-y-2 pt-4 border-t border-slate-200">
            <button
              onClick={onNavigateToTariffs}
              className="w-full bg-slate-900 hover:bg-slate-800 text-white font-bold py-2.5 px-4 rounded-lg text-xs transition flex items-center justify-center space-x-2 shadow-sm"
            >
              <span>Compare Candidate Tariffs</span>
              <ArrowUpRight className="w-3.5 h-3.5 text-sky-400" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
