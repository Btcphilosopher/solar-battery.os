import React from 'react';
import { SolarSystem, HomeBattery, EVConfig, HeatPumpConfig } from '../types';
import { Sun, Battery, Car, Flame, Check, Zap } from 'lucide-react';

interface HomeAssetsViewProps {
  solar: SolarSystem;
  battery: HomeBattery;
  ev: EVConfig;
  heatPump: HeatPumpConfig;
  onUpdateSolar: (solar: SolarSystem) => void;
  onUpdateBattery: (battery: HomeBattery) => void;
  onUpdateEV: (ev: EVConfig) => void;
  onUpdateHeatPump: (heatPump: HeatPumpConfig) => void;
}

export const HomeAssetsView: React.FC<HomeAssetsViewProps> = ({
  solar,
  battery,
  ev,
  heatPump,
  onUpdateSolar,
  onUpdateBattery,
  onUpdateEV,
  onUpdateHeatPump,
}) => {
  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
        <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
          Household Clean Energy & Asset Modeller
        </h2>
        <p className="text-xs text-slate-500 mt-1">
          Simulate Solar PV generation, battery storage arbitrage, EV charging, and heat pumps in the British market.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Solar PV Card */}
        <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm space-y-4">
          <div className="flex justify-between items-center pb-3 border-b border-slate-200">
            <div className="flex items-center space-x-2.5">
              <Sun className="w-5 h-5 text-amber-500" />
              <h3 className="text-base font-bold text-slate-900">Solar PV System</h3>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={solar.enabled}
                onChange={(e) => onUpdateSolar({ ...solar, enabled: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-sky-600"></div>
            </label>
          </div>

          <div className="space-y-3 text-xs font-medium">
            <div>
              <label className="text-slate-600 block mb-1">Array Capacity (kWp):</label>
              <input
                type="number"
                step="0.5"
                value={solar.capacity_kwp}
                onChange={(e) => onUpdateSolar({ ...solar, capacity_kwp: Number(e.target.value) })}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-900 font-mono font-bold"
              />
            </div>
            <div>
              <label className="text-slate-600 block mb-1">Smart Export Guarantee (SEG Rate p/kWh):</label>
              <input
                type="number"
                step="0.5"
                value={solar.export_tariff_p_kwh}
                onChange={(e) => onUpdateSolar({ ...solar, export_tariff_p_kwh: Number(e.target.value) })}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-900 font-mono font-bold"
              />
            </div>

            <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-1.5 text-[11px] text-slate-700">
              <div className="flex justify-between">
                <span>Est. Annual Generation:</span>
                <span className="font-bold text-amber-700">{Math.round(solar.capacity_kwp * 900)} kWh/yr</span>
              </div>
              <div className="flex justify-between">
                <span>Self-Consumption (Without Battery):</span>
                <span className="font-semibold text-slate-800">40% (~{Math.round(solar.capacity_kwp * 900 * 0.4)} kWh)</span>
              </div>
              <div className="flex justify-between">
                <span>SEG Grid Export Revenue:</span>
                <span className="font-bold text-sky-700">
                  £{Math.round(((solar.capacity_kwp * 900 * 0.6) * solar.export_tariff_p_kwh) / 100)}/yr
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Heat Pump Card */}
        <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm space-y-4">
          <div className="flex justify-between items-center pb-3 border-b border-slate-200">
            <div className="flex items-center space-x-2.5">
              <Flame className="w-5 h-5 text-cyan-600" />
              <h3 className="text-base font-bold text-slate-900">Heat Pump (ASHP)</h3>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={heatPump.enabled}
                onChange={(e) => onUpdateHeatPump({ ...heatPump, enabled: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-sky-600"></div>
            </label>
          </div>

          <div className="space-y-3 text-xs font-medium">
            <div>
              <label className="text-slate-600 block mb-1">Annual Heat Demand (kWh):</label>
              <input
                type="number"
                value={heatPump.annual_heat_demand_kwh}
                onChange={(e) => onUpdateHeatPump({ ...heatPump, annual_heat_demand_kwh: Number(e.target.value) })}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-900 font-mono font-bold"
              />
            </div>
            <div>
              <label className="text-slate-600 block mb-1">Seasonal COP (Coefficient of Performance):</label>
              <input
                type="number"
                step="0.1"
                value={heatPump.seasonal_cop}
                onChange={(e) => onUpdateHeatPump({ ...heatPump, seasonal_cop: Number(e.target.value) })}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2.5 text-slate-900 font-mono font-bold"
              />
            </div>

            <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-1.5 text-[11px] text-slate-700">
              <div className="flex justify-between">
                <span>Electricity Required:</span>
                <span className="font-bold text-cyan-700">
                  {Math.round(heatPump.annual_heat_demand_kwh / heatPump.seasonal_cop)} kWh/yr
                </span>
              </div>
              <div className="flex justify-between">
                <span>Gas Replacement Offset:</span>
                <span className="text-sky-700 font-bold">Replaces ~{heatPump.annual_heat_demand_kwh} kWh Gas</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
