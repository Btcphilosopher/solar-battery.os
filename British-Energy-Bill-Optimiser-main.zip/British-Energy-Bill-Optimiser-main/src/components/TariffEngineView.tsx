import React, { useState } from 'react';
import { Tariff, SmartMeterDataSet } from '../types';
import { CANDIDATE_TARIFFS, OFGEM_PRICE_CAPS } from '../data/ukMarketData';
import { calculateBillFromReadings } from '../utils/billCalculator';
import { ShieldCheck, Check, ArrowUpRight, Zap, Flame, Award, AlertCircle } from 'lucide-react';

interface TariffEngineViewProps {
  currentTariff: Tariff;
  smartMeterData: SmartMeterDataSet;
  onSelectTariff: (tariff: Tariff) => void;
}

export const TariffEngineView: React.FC<TariffEngineViewProps> = ({
  currentTariff,
  smartMeterData,
  onSelectTariff,
}) => {
  const [filterType, setFilterType] = useState<string>('all');
  const cap = OFGEM_PRICE_CAPS[0];

  // Calculate current annual baseline bill
  const currentBill = calculateBillFromReadings(smartMeterData.readings, currentTariff, 365);

  // Evaluate candidate tariffs using household HH profile
  const tariffComparisons = CANDIDATE_TARIFFS.map((cand) => {
    const bill = calculateBillFromReadings(smartMeterData.readings, cand, 365);
    const savingGbp = currentBill.grand_total - bill.grand_total;
    return {
      tariff: cand,
      bill,
      savingGbp: Number(savingGbp.toFixed(2)),
    };
  });

  // Sort by lowest annual cost
  tariffComparisons.sort((a, b) => a.bill.grand_total - b.bill.grand_total);

  const filteredComparisons = tariffComparisons.filter((item) => {
    if (filterType === 'all') return true;
    if (filterType === 'ev') return item.tariff.type === 'ev';
    if (filterType === 'fixed') return item.tariff.type === 'fixed';
    if (filterType === 'tracker') return item.tariff.type === 'tracker';
    if (filterType === 'heat_pump') return item.tariff.type === 'heat_pump';
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            British Tariff Comparison Matrix
            <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-sky-50 text-sky-700 border border-sky-200 font-bold">
              Profile-Weighted Cost Engine
            </span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Calculated against your actual 48-period half-hourly smart meter consumption curve, not headline unit rates.
          </p>
        </div>

        {/* Filter Pills */}
        <div className="flex space-x-1.5 bg-slate-100 p-1 rounded-lg border border-slate-200 text-xs font-semibold">
          {['all', 'ev', 'fixed', 'tracker', 'heat_pump'].map((f) => (
            <button
              key={f}
              onClick={() => setFilterType(f)}
              className={`px-3 py-1.5 rounded-md capitalize transition ${
                filterType === f
                  ? 'bg-sky-600 text-white font-bold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {f.replace('_', ' ')}
            </button>
          ))}
        </div>
      </div>

      {/* Baseline Callout */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 text-slate-700 text-xs flex flex-wrap items-center justify-between gap-4 shadow-sm">
        <div>
          <span className="text-[10px] text-slate-500 uppercase tracking-wider block font-bold">Your Current Baseline Tariff:</span>
          <span className="text-base font-bold text-slate-900">{currentTariff.name} ({currentTariff.supplier})</span>
        </div>
        <div className="text-right">
          <span className="text-[10px] text-slate-500 uppercase tracking-wider block font-bold">Baseline Annual Bill:</span>
          <span className="text-xl font-extrabold text-slate-900">£{currentBill.grand_total.toLocaleString()} / year</span>
        </div>
      </div>

      {/* Candidate Tariffs Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredComparisons.map(({ tariff: cand, bill, savingGbp }, idx) => {
          const isCurrent = cand.id === currentTariff.id;
          const isTopSaving = idx === 0 && savingGbp > 0;

          return (
            <div
              key={cand.id}
              className={`bg-white border rounded-xl p-6 shadow-sm flex flex-col justify-between space-y-4 relative ${
                isTopSaving
                  ? 'border-sky-500 ring-2 ring-sky-500/20 bg-sky-50/20'
                  : isCurrent
                  ? 'border-amber-400 bg-amber-50/20'
                  : 'border-slate-200'
              }`}
            >
              {isTopSaving && (
                <div className="absolute -top-3 left-6 px-3 py-0.5 rounded-full bg-sky-600 text-white text-[10px] font-bold tracking-wider uppercase flex items-center gap-1 shadow-sm">
                  <Award className="w-3 h-3" /> Cheapest Sensible Choice
                </div>
              )}

              <div className="space-y-3">
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-xs font-bold text-sky-700 uppercase tracking-wider block">
                      {cand.supplier}
                    </span>
                    <h3 className="text-base font-bold text-slate-900">{cand.name}</h3>
                  </div>
                  <span className="px-2 py-0.5 bg-slate-100 border border-slate-200 rounded text-[10px] text-slate-700 font-bold uppercase">
                    {cand.type}
                  </span>
                </div>

                <p className="text-xs text-slate-500 leading-relaxed line-clamp-2">
                  {cand.description}
                </p>

                {/* Rates Table */}
                <div className="bg-slate-50 rounded-lg p-3 border border-slate-200 text-xs space-y-1.5 font-mono">
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-medium">Elec Rate:</span>
                    <span className="text-slate-900 font-bold">{cand.electricity_unit_rate}p / kWh</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-medium">Elec Standing:</span>
                    <span className="text-slate-800">{cand.electricity_standing_charge}p / day</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-medium">Gas Rate:</span>
                    <span className="text-cyan-700 font-bold">{cand.gas_unit_rate}p / kWh</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-medium">Gas Standing:</span>
                    <span className="text-slate-800">{cand.gas_standing_charge}p / day</span>
                  </div>
                  {cand.time_rates && cand.time_rates.length > 0 && (
                    <div className="pt-1 border-t border-slate-200 text-[11px] text-sky-700 font-bold">
                      ⚡ Special Window: {cand.time_rates[0].start_time}-{cand.time_rates[0].end_time} @ {cand.time_rates[0].rate_p_kwh}p/kWh
                    </div>
                  )}
                </div>

                {/* Calculated Annual Cost & Saving */}
                <div className="pt-2 flex justify-between items-baseline border-t border-slate-200">
                  <div>
                    <span className="text-xs text-slate-500 block font-medium">Calculated Annual Bill:</span>
                    <span className="text-2xl font-black text-slate-900">
                      £{bill.grand_total.toLocaleString()}
                    </span>
                  </div>

                  {savingGbp > 0 ? (
                    <div className="text-right">
                      <span className="text-xs text-sky-700 font-bold block">Annual Saving:</span>
                      <span className="text-lg font-black text-sky-700">+£{savingGbp}/yr</span>
                    </div>
                  ) : savingGbp < 0 ? (
                    <div className="text-right">
                      <span className="text-xs text-rose-600 block font-medium">More Expensive:</span>
                      <span className="text-sm font-bold text-rose-600">-£{Math.abs(savingGbp)}/yr</span>
                    </div>
                  ) : (
                    <div className="text-right text-xs text-slate-500 font-semibold">Active Tariff</div>
                  )}
                </div>
              </div>

              {/* Action Button */}
              <button
                onClick={() => onSelectTariff(cand)}
                disabled={isCurrent}
                className={`w-full py-2.5 px-4 rounded-lg text-xs font-bold transition flex items-center justify-center space-x-1.5 ${
                  isCurrent
                    ? 'bg-slate-100 text-slate-400 border border-slate-200 cursor-not-allowed'
                    : 'bg-sky-600 hover:bg-sky-700 text-white shadow-xs'
                }`}
              >
                {isCurrent ? (
                  <span>Currently Selected</span>
                ) : (
                  <>
                    <span>Switch to this Tariff</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </>
                )}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};
