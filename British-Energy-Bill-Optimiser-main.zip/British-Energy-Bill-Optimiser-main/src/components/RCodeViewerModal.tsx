import React, { useState, useEffect } from 'react';
import { X, Code2, Play, Download, Copy, Check, Terminal } from 'lucide-react';

interface RCodeViewerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RCodeViewerModal: React.FC<RCodeViewerModalProps> = ({ isOpen, onClose }) => {
  const [selectedFile, setSelectedFile] = useState<string>('R/optimiser.R');
  const [fileContent, setFileContent] = useState<string>('');
  const [execOutput, setExecOutput] = useState<string | null>(null);
  const [copied, setCopied] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);

  const rFiles = [
    'app.R',
    'global.R',
    'R/optimiser.R',
    'R/tariff_engine.R',
    'R/bill_calculator.R',
    'R/consumption_engine.R',
    'R/forecast_engine.R',
    'R/solar_model.R',
    'R/battery_model.R',
    'modules/dashboard.R',
  ];

  useEffect(() => {
    if (isOpen) {
      fetchFileContent(selectedFile);
    }
  }, [isOpen, selectedFile]);

  const fetchFileContent = async (fileName: string) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/r-files?file=${fileName}`);
      const data = await res.json();
      setFileContent(data.content || '# R Code file');
    } catch {
      setFileContent('# Could not load file');
    } finally {
      setLoading(false);
    }
  };

  const runRExecutionTest = async () => {
    setExecOutput('Executing R script test via backend...');
    try {
      const res = await fetch('/api/r-exec', { method: 'POST' });
      const data = await res.json();
      if (data.executed) {
        setExecOutput(`R Execution Successful:\nSTDOUT:\n${data.stdout}\nSTDERR:\n${data.stderr}`);
      } else {
        setExecOutput(`R Environment Status:\n${data.message}\n\nUnderlying R Code Loaded cleanly.`);
      }
    } catch (err: any) {
      setExecOutput(`Error executing R: ${err.message}`);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(fileContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-4xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-800 bg-slate-900">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-amber-500/10 text-amber-400 rounded-xl border border-amber-500/20">
              <Code2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Underlying R Code Engine & Architecture</h3>
              <p className="text-xs text-slate-400">Inspect & run production R code (`app.R`, `global.R`, `R/*.R`)</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Toolbar */}
        <div className="flex flex-wrap items-center justify-between gap-3 p-3 px-5 bg-slate-950 border-b border-slate-800 text-xs">
          <div className="flex items-center space-x-2">
            <span className="text-slate-400 font-medium">Select R File:</span>
            <select
              value={selectedFile}
              onChange={(e) => setSelectedFile(e.target.value)}
              className="bg-slate-900 text-white border border-slate-700 rounded-lg p-1.5 font-mono focus:outline-none"
            >
              {rFiles.map((f) => (
                <option key={f} value={f}>
                  {f}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={runRExecutionTest}
              className="flex items-center space-x-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-3 py-1.5 rounded-lg transition"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Test R Execution</span>
            </button>

            <button
              onClick={handleCopy}
              className="flex items-center space-x-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium px-3 py-1.5 rounded-lg border border-slate-700 transition"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy R Code'}</span>
            </button>
          </div>
        </div>

        {/* Code Content & Execution Output */}
        <div className="p-5 space-y-4 overflow-y-auto flex-1 font-mono text-xs">
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 text-emerald-300 overflow-x-auto leading-relaxed shadow-inner">
            <pre>{fileContent}</pre>
          </div>

          {execOutput && (
            <div className="bg-slate-950 border border-amber-500/30 rounded-xl p-4 space-y-2">
              <div className="flex items-center space-x-2 text-amber-400 font-bold text-xs">
                <Terminal className="w-4 h-4" />
                <span>R Execution Terminal Output</span>
              </div>
              <pre className="text-slate-300 text-[11px] whitespace-pre-wrap font-mono">{execOutput}</pre>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
