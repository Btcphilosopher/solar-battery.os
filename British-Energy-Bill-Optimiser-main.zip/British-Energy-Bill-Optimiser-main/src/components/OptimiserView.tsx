import React, { useState } from 'react';
import {
  Tariff,
  Appliance,
  SolarSystem,
  HomeBattery,
  EVConfig,
  HeatPumpConfig,
  OptimiserObjective,
  OptimisationResult,
} from '../types';
import {
  ResponsiveContainer,
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
} from 'recharts';
import {
  Zap,
  Battery,
  Car,
  Flame,
  CheckCircle2,
  Sliders,
  DollarSign,
  Leaf,
  ShieldCheck,
  ArrowUpRight,
  Sparkles,
} from 'lucide-react';

interface OptimiserViewProps {
  currentTariff: Tariff;
  optimisationResult: OptimisationResult;
  evConfig: EVConfig;
  batteryConfig: HomeBattery;
  solarConfig: SolarSystem;
  heatPumpConfig: HeatPumpConfig;
  objective: OptimiserObjective;
  onChangeObjective: (obj: OptimiserObjective) => void;
  onUpdateEV: (ev: EVConfig) => void;
  onUpdateBattery: (battery: HomeBattery) => void;
}

export const OptimiserView: React.FC<OptimiserViewProps> = ({
  currentTariff,
  optimisationResult,
  evConfig,
  batteryConfig,
  solarConfig,
  heatPumpConfig,
  objective,
  onChangeObjective,
  onUpdateEV,
  onUpdateBattery,
}) => {
  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            Time-of-Use Flexible Load Optimiser
            <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-sky-50 text-sky-700 border border-sky-200 font-bold">
              48-Period LP / Mixed-Integer Engine
            </span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Minimises total energy cost subject to EV departure time, battery SOC limits, and tariff rate curves.
          </p>
        </div>

        {/* Priority Objective Selector */}
        <div className="flex items-center space-x-2 text-xs bg-slate-100 p-1.5 rounded-lg border border-slate-200 font-semibold">
          <span className="text-slate-500 font-bold px-2">Priority:</span>
          {(['cost', 'carbon', 'balanced', 'convenience'] as const).map((p) => (
            <button
              key={p}
              onClick={() =>
                onChangeObjective({
                  priority: p,
                  weight_cost: p === 'cost' ? 1.0 : 0.5,
                  weight_carbon: p === 'carbon' ? 1.0 : 0.2,
                })
              }
              className={`px-3 py-1.5 rounded-md font-bold capitalize transition flex items-center gap-1.5 ${
                objective.priority === p
                  ? 'bg-sky-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {p === 'cost' && <DollarSign className="w-3.5 h-3.5" />}
              {p === 'carbon' && <Leaf className="w-3.5 h-3.5" />}
              <span>{p}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Savings Summary Banner */}
      <div className="bg-sky-50 border border-sky-200 rounded-xl p-6 text-slate-900 shadow-sm grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
        <div>
          <span className="text-[10px] text-sky-800 uppercase tracking-wider font-bold block">Unoptimised Annual Cost</span>
          <span className="text-2xl font-bold text-slate-400 line-through">
            £{optimisationResult.unoptimised_annual_cost.toLocaleString()}
          </span>
          <span className="text-xs text-slate-500 font-medium block">Peak-hours charging & unmanaged load</span>
        </div>

        <div>
          <span className="text-[10px] text-sky-800 uppercase tracking-wider font-bold block">Optimised Annual Cost</span>
          <span className="text-3xl font-black text-slate-900">
            £{optimisationResult.optimised_annual_cost.toLocaleString()}
          </span>
          <span className="text-xs text-sky-700 font-semibold block">With smart scheduling & battery arbitrage</span>
        </div>

        <div className="bg-white border border-sky-200 rounded-xl p-4 text-center shadow-xs">
          <span className="text-[10px] text-sky-800 uppercase tracking-wider font-bold block">Net Potential Saving</span>
          <span className="text-3xl font-black text-sky-700">
            £{optimisationResult.annual_saving_gbp} <span className="text-xs font-semibold">/ year</span>
          </span>
          <span className="text-[11px] text-slate-600 font-medium block mt-1">
            + {optimisationResult.carbon_saving_kg} kg CO₂e saved annually
          </span>
        </div>
      </div>

      {/* Flexible Load Controls Bar */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* EV Control Box */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
          <div className="flex justify-between items-center pb-3 border-b border-slate-200">
            <div className="flex items-center space-x-2.5">
              <Car className="w-5 h-5 text-sky-600" />
              <h3 className="text-sm font-bold text-slate-900">EV Charging Configuration</h3>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={evConfig.enabled}
                onChange={(e) => onUpdateEV({ ...evConfig, enabled: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-sky-600"></div>
            </label>
          </div>

          {evConfig.enabled ? (
            <div className="space-y-3 text-xs font-medium">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-600 block mb-1">Required Daily Charge (kWh):</label>
                  <input
                    type="number"
                    value={evConfig.typical_daily_kwh}
                    onChange={(e) => onUpdateEV({ ...evConfig, typical_daily_kwh: Number(e.target.value) })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-slate-900 font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="text-slate-600 block mb-1">Charger Rate (kW):</label>
                  <input
                    type="number"
                    step="0.1"
                    value={evConfig.charging_rate_kw}
                    onChange={(e) => onUpdateEV({ ...evConfig, charging_rate_kw: Number(e.target.value) })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-slate-900 font-mono font-bold"
                  />
                </div>
              </div>
              <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-[11px] flex justify-between">
                <span>Target Departure:</span>
                <span className="font-bold text-sky-700">07:00 AM (Ready)</span>
              </div>
            </div>
          ) : (
            <p className="text-xs text-slate-500 italic">EV charging module disabled.</p>
          )}
        </div>

        {/* Battery Control Box */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-sm space-y-4">
          <div className="flex justify-between items-center pb-3 border-b border-slate-200">
            <div className="flex items-center space-x-2.5">
              <Battery className="w-5 h-5 text-sky-600" />
              <h3 className="text-sm font-bold text-slate-900">Home Battery Arbitrage</h3>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={batteryConfig.enabled}
                onChange={(e) => onUpdateBattery({ ...batteryConfig, enabled: e.target.checked })}
                className="sr-only peer"
              />
              <div className="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-sky-600"></div>
            </label>
          </div>

          {batteryConfig.enabled ? (
            <div className="space-y-3 text-xs font-medium">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-600 block mb-1">Capacity (kWh):</label>
                  <input
                    type="number"
                    value={batteryConfig.capacity_kwh}
                    onChange={(e) => onUpdateBattery({ ...batteryConfig, capacity_kwh: Number(e.target.value) })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-slate-900 font-mono font-bold"
                  />
                </div>
                <div>
                  <label className="text-slate-600 block mb-1">Max Charge/Discharge (kW):</label>
                  <input
                    type="number"
                    step="0.1"
                    value={batteryConfig.max_charge_kw}
                    onChange={(e) => onUpdateBattery({ ...batteryConfig, max_charge_kw: Number(e.target.value) })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg p-2 text-slate-900 font-mono font-bold"
                  />
                </div>
              </div>
              <div className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 text-[11px] flex justify-between">
                <span>Round-Trip Efficiency:</span>
                <span className="font-bold text-sky-700">90% Efficiency</span>
              </div>
            </div>
          ) : (
            <p className="text-xs text-slate-500 italic">Home battery module disabled.</p>
          )}
        </div>
      </div>

      {/* 48-Period Optimised Schedule Chart */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4 pb-3 border-b border-slate-200">
          <div>
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              Optimised 24-Hour Schedule (48 Settlement Periods)
            </h3>
            <p className="text-xs text-slate-500">
              Shows net grid import (kW), EV charging, battery SOC (kWh), and electricity unit rate (p/kWh)
            </p>
          </div>
        </div>

        <div className="h-80 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={optimisationResult.schedule} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" opacity={0.8} />
              <XAxis dataKey="time" stroke="#64748b" fontSize={11} interval={3} />
              <YAxis yAxisId="power" stroke="#64748b" fontSize={11} label={{ value: 'Power (kW)', angle: -90, position: 'insideLeft', fill: '#64748b', fontSize: 11 }} />
              <YAxis yAxisId="rate" orientation="right" stroke="#d97706" fontSize={11} label={{ value: 'Tariff Rate (p/kWh)', angle: 90, position: 'insideRight', fill: '#d97706', fontSize: 11 }} />
              <Tooltip
                contentStyle={{ backgroundColor: '#ffffff', borderColor: '#cbd5e1', borderRadius: '0.5rem', fontSize: '12px', color: '#0f172a' }}
              />
              <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
              <Bar yAxisId="power" dataKey="net_grid_import_kw" name="Net Grid Import (kW)" fill="#0284c7" radius={[4, 4, 0, 0]} />
              <Bar yAxisId="power" dataKey="ev_charge_kw" name="EV Charging (kW)" fill="#0891b2" radius={[4, 4, 0, 0]} />
              <Line yAxisId="power" type="monotone" dataKey="battery_soc_kwh" name="Battery SOC (kWh)" stroke="#38bdf8" strokeWidth={2} dot={false} />
              <Line yAxisId="rate" type="stepAfter" dataKey="rate_p_kwh" name="Tariff Rate (p/kWh)" stroke="#d97706" strokeWidth={2.5} dot={false} />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Human-Readable Recommendations Section */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm space-y-4">
        <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-sky-600" />
          Recommended Household Daily Actions
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          {optimisationResult.savings_breakdown.map((item, idx) => (
            <div key={idx} className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2">
              <div className="flex justify-between items-start">
                <span className="font-bold text-slate-900">{item.category}</span>
                <span className="text-sky-700 font-extrabold text-sm">+£{item.annual_saving_gbp}/yr</span>
              </div>
              <p className="text-slate-600 leading-relaxed font-medium">{item.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
