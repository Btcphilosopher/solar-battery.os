# Shiny Settings Module
settingsUI <- function(id) {
  ns <- NS(id)
  tagList(
    fluidRow(
      column(6, card(card_header("Household Region & Meter Setup"),
                     selectInput(ns("region"), "DNO Region", choices = c("London", "Eastern", "East Midlands", "West Midlands", "North East", "North West", "South West", "Southern", "Scotland")),
                     selectInput(ns("payment_method"), "Payment Method", choices = c("Direct Debit", "Standard Credit", "Prepayment")))),
      column(6, card(card_header("Flexible Household Assets"),
                     checkboxInput(ns("has_ev"), "Electric Vehicle (EV)", value = TRUE),
                     checkboxInput(ns("has_battery"), "Home Battery Storage", value = FALSE),
                     checkboxInput(ns("has_solar"), "Solar PV System", value = FALSE),
                     checkboxInput(ns("has_heatpump"), "Heat Pump", value = FALSE)))
    )
  )
}

settingsServer <- function(id, state) {
  moduleServer(id, function(input, output, session) {
    # Handlers
  })
}
