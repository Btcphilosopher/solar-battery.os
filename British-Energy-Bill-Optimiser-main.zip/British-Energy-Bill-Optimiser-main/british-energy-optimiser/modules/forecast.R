# Shiny Forecast Module
forecastUI <- function(id) {
  ns <- NS(id)
  tagList(
    fluidRow(
      column(12, card(card_header("12-Month Rolling Bill Forecast"), plotlyOutput(ns("forecast_chart"))))
    )
  )
}

forecastServer <- function(id, state) {
  moduleServer(id, function(input, output, session) {
    output$forecast_chart <- renderPlotly({
      months <- c("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
      cost <- c(210, 195, 170, 130, 95, 80, 75, 78, 90, 140, 180, 205)
      df <- data.frame(Month = factor(months, levels = months), Cost = cost)
      plot_ly(df, x = ~Month, y = ~Cost, type = "scatter", mode = "lines+markers", fill = "tozeroy")
    })
  })
}
