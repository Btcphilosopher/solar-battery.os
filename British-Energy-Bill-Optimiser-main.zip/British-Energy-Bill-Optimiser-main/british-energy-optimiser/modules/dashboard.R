# Shiny Dashboard Module
dashboardUI <- function(id) {
  ns <- NS(id)
  tagList(
    fluidRow(
      column(3, div(class = "card p-3 text-center bg-primary text-white mb-3",
                    h6("ANNUAL COST FORECAST"), h2(textOutput(ns("annual_cost_txt"))))),
      column(3, div(class = "card p-3 text-center bg-success text-white mb-3",
                    h6("POTENTIAL SAVING"), h2(textOutput(ns("potential_saving_txt"))))),
      column(3, div(class = "card p-3 text-center bg-dark text-white mb-3",
                    h6("CURRENT MONTH COST"), h2(textOutput(ns("monthly_cost_txt"))))),
      column(3, div(class = "card p-3 text-center bg-secondary text-white mb-3",
                    h6("BASELOAD POWER"), h2(textOutput(ns("baseload_txt")))))
    ),
    fluidRow(
      column(8, card(card_header("Monthly Energy Breakdown"), plotlyOutput(ns("cost_chart")))),
      column(4, card(card_header("Current Tariff Benchmark"), uiOutput(ns("tariff_summary_ui"))))
    )
  )
}

dashboardServer <- function(id, state) {
  moduleServer(id, function(input, output, session) {
    output$annual_cost_txt <- renderText({"£1,724"})
    output$potential_saving_txt <- renderText({"£284 / yr"})
    output$monthly_cost_txt <- renderText({"£143.82"})
    output$baseload_txt <- renderText({"0.28 kW"})
    
    output$cost_chart <- renderPlotly({
      df <- data.frame(
        Category = c("Electricity", "Gas", "Standing Charges", "VAT"),
        Cost = c(72.40, 51.12, 20.30, 7.19)
      )
      plot_ly(df, x = ~Category, y = ~Cost, type = "bar", marker = list(color = "#10b981"))
    })
    
    output$tariff_summary_ui <- renderUI({
      tagList(
        p(strong("Tariff:"), " Standard Variable (Ofgem Cap)"),
        p(strong("Electricity:"), " 24.5p / kWh"),
        p(strong("Gas:"), " 6.24p / kWh"),
        p(strong("Standing Charge:"), " 60.1p / day"),
        p(strong("Region:"), " London (UKPN)")
      )
    })
  })
}
