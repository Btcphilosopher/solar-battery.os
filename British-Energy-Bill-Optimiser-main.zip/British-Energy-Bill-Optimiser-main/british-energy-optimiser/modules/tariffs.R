# Shiny Tariffs Module
tariffsUI <- function(id) {
  ns <- NS(id)
  tagList(
    fluidRow(
      column(12, card(card_header("British Tariff Comparison Matrix"), DTOutput(ns("tariffs_table"))))
    )
  )
}

tariffsServer <- function(id, state) {
  moduleServer(id, function(input, output, session) {
    output$tariffs_table <- renderDT({
      datatable(data.frame(
        Supplier = c("Octopus Energy", "Octopus Energy", "British Gas", "EDF Energy"),
        Tariff = c("Octopus Go (EV)", "Octopus Agile", "Fixed 12M", "Standard Variable"),
        Annual_Cost = c("£1,540", "£1,573", "£1,612", "£1,824"),
        Saving = c("£284 / yr", "£251 / yr", "£212 / yr", "Baseline")
      ))
    })
  })
}
