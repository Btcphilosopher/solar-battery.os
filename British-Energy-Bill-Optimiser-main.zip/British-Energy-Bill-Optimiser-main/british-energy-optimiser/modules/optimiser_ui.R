# Shiny Optimiser UI Module
optimiserUI <- function(id) {
  ns <- NS(id)
  tagList(
    fluidRow(
      column(12, card(card_header("Optimal Daily Appliance & Battery Schedule"), plotlyOutput(ns("schedule_chart"))))
    )
  )
}

optimiserServer <- function(id, state) {
  moduleServer(id, function(input, output, session) {
    output$schedule_chart <- renderPlotly({
      df <- data.frame(
        Hour = 0:23,
        EV_Load = c(rep(3.7, 4), rep(0, 20)),
        Base_Load = rep(0.3, 24)
      )
      plot_ly(df, x = ~Hour, y = ~EV_Load, name = "EV Charging (kW)", type = "bar") %>%
        add_trace(y = ~Base_Load, name = "Base Load (kW)") %>%
        layout(barmode = "stack")
    })
  })
}
