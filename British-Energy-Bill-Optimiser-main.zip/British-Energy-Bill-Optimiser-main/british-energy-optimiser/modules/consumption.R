# Shiny Consumption Module
consumptionUI <- function(id) {
  ns <- NS(id)
  tagList(
    fluidRow(
      column(12, card(card_header("24-Hour Half-Hourly Consumption Profile"), plotlyOutput(ns("profile_chart"))))
    )
  )
}

consumptionServer <- function(id, state) {
  moduleServer(id, function(input, output, session) {
    output$profile_chart <- renderPlotly({
      periods <- 1:48
      kwh <- 0.15 + sin((periods/48)*pi*2 - pi/2)*0.1 + runif(48, 0, 0.05)
      df <- data.frame(period = periods, kwh = kwh)
      plot_ly(df, x = ~period, y = ~kwh, type = "scatter", mode = "lines+markers")
    })
  })
}
