# Shiny Scenarios Module
scenariosUI <- function(id) {
  ns <- NS(id)
  tagList(
    fluidRow(
      column(12, card(card_header("What-If Scenario Simulator"), DTOutput(ns("scenarios_table"))))
    )
  )
}

scenariosServer <- function(id, state) {
  moduleServer(id, function(input, output, session) {
    output$scenarios_table <- renderDT({
      datatable(data.frame(
        Option = c("Current Setup", "Smart Tariff Switch", "Add Solar PV (4kWp)", "Add Solar + 10kWh Battery"),
        Annual_Cost = c("£1,824", "£1,641", "£1,512", "£1,403"),
        Annual_Saving = c("£0", "£183", "£312", "£421"),
        Est_Payback = c("-", "Immediate", "5.8 Years", "7.2 Years")
      ))
    })
  })
}
