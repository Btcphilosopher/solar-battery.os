# British Energy Bill Optimiser in R

A production-quality British household energy bill optimiser built around the UK energy market architecture, Ofgem price caps, 14 DNO regions, half-hourly smart meter analytics, time-of-use scheduling, solar PV, home batteries, EV charging, and heat pumps.

## Features
- **UK Market Terminology**: Standing charges (p/day), Unit rates (p/kWh), Ofgem Price Cap benchmark, 14 UK electricity distribution regions.
- **Smart Meter HH Analytics**: Ingestion & 24h x Days heatmap visualization for 48 settlement periods.
- **Tariff Engine**: Normalisation of Single-rate, Economy 7, Dynamic Agile, and EV overnight tariffs.
- **Linear Programming Optimiser**: Minimises household energy bill across EV charging windows, battery storage arbitrage, and flexible appliance loads.
- **5% UK Domestic Energy VAT**: Accurate transparent bill calculation.

## How to run locally with R:
```R
# In R console:
install.packages(c("shiny", "bslib", "ggplot2", "plotly", "DT", "dplyr", "jsonlite"))
shiny::runApp("app.R")
```
