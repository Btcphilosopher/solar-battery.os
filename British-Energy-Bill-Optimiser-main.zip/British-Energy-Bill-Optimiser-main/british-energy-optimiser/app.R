# British Energy Bill Optimiser - Main Shiny Application Entry Point
source("global.R")

ui <- page_navbar(
  title = "British Energy Optimiser",
  theme = bs_theme(
    version = 5,
    bootswatch = "zephyr",
    primary = "#10b981",
    secondary = "#0284c7",
    font_scale = 0.95
  ),
  
  nav_panel("Dashboard", dashboardUI("dashboard")),
  nav_panel("Consumption Analysis", consumptionUI("consumption")),
  nav_panel("Tariff Finder", tariffsUI("tariffs")),
  nav_panel("Time-of-Use Optimiser", optimiserUI("optimiser")),
  nav_panel("Bill Forecast", forecastUI("forecast")),
  nav_panel("What-If Scenarios", scenariosUI("scenarios")),
  nav_panel("Household Settings", settingsUI("settings"))
)

server <- function(input, output, session) {
  # Reactive state container
  state <- reactiveValues(
    smart_meter_data = generate_mock_hh_data("family"),
    selected_tariff = get_default_tariff("svt_standard"),
    region = "london",
    ev_config = list(enabled = TRUE, kwh = 28, charger_kw = 7.4),
    battery_config = list(enabled = FALSE, capacity = 10, max_charge = 3.6),
    solar_config = list(enabled = FALSE, kwp = 4.0)
  )

  # Call module servers
  dashboardServer("dashboard", state)
  consumptionServer("consumption", state)
  tariffsServer("tariffs", state)
  optimiserServer("optimiser", state)
  forecastServer("forecast", state)
  scenariosServer("scenarios", state)
  settingsServer("settings", state)
}

shinyApp(ui = ui, server = server)
