# R Heat Pump Model
calculate_heat_pump_cost <- function(annual_heat_kwh = 12000, cop = 3.2, elec_rate_p = 23.5) {
  elec_kwh <- annual_heat_kwh / cop
  annual_cost <- (elec_kwh * elec_rate_p) / 100
  
  list(
    annual_heat_kwh = annual_heat_kwh,
    cop = cop,
    electricity_kwh = round(elec_kwh),
    annual_cost_gbp = round(annual_cost, 2)
  )
}
