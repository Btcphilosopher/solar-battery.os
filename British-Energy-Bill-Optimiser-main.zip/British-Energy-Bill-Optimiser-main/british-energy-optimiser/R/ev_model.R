# R EV Model
calculate_ev_charging_cost <- function(annual_miles = 8000, miles_per_kwh = 3.5, night_rate_p = 8.5, day_rate_p = 26.8) {
  annual_kwh <- annual_miles / miles_per_kwh
  smart_cost <- (annual_kwh * night_rate_p) / 100
  unsmart_cost <- (annual_kwh * day_rate_p) / 100
  
  list(
    annual_kwh = round(annual_kwh),
    smart_cost_gbp = round(smart_cost, 2),
    unsmart_cost_gbp = round(unsmart_cost, 2),
    annual_saving_gbp = round(unsmart_cost - smart_cost, 2)
  )
}
