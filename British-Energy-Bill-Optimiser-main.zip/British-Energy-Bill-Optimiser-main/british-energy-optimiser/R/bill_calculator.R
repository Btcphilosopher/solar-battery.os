# R Bill Calculator
# Computes itemised energy bill components with 5% UK domestic VAT

calculate_itemised_bill <- function(elec_kwh, gas_kwh, tariff, days = 365) {
  elec_unit_gbp <- (elec_kwh * tariff$electricity_unit_rate) / 100
  gas_unit_gbp <- (gas_kwh * tariff$gas_unit_rate) / 100
  elec_standing_gbp <- (days * tariff$electricity_standing_charge) / 100
  gas_standing_gbp <- (days * tariff$gas_standing_charge) / 100
  
  standing_total <- elec_standing_gbp + gas_standing_gbp
  subtotal <- elec_unit_gbp + gas_unit_gbp + standing_total
  vat_5pct <- subtotal * 0.05
  grand_total <- subtotal + vat_5pct
  
  list(
    electricity_kwh = elec_kwh,
    electricity_unit_cost = round(elec_unit_gbp, 2),
    gas_kwh = gas_kwh,
    gas_unit_cost = round(gas_unit_gbp, 2),
    standing_charges = round(standing_total, 2),
    subtotal = round(subtotal, 2),
    vat = round(vat_5pct, 2),
    grand_total = round(grand_total, 2)
  )
}
