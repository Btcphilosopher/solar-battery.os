# R What-If Scenario & Payback Engine
evaluate_investment_scenario <- function(capex, annual_saving, years = 10, discount_rate = 0.05) {
  payback_years <- capex / max(1, annual_saving)
  
  # Net Present Value (NPV)
  npv <- -capex
  for (t in 1:years) {
    npv <- npv + (annual_saving / ((1 + discount_rate)^t))
  }
  
  list(
    capex = capex,
    annual_saving = annual_saving,
    simple_payback_years = round(payback_years, 1),
    npv_10_years = round(npv, 2)
  )
}
