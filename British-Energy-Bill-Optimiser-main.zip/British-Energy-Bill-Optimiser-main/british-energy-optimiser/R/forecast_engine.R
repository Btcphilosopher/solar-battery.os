# R Forecast Engine
forecast_annual_bill <- function(annual_elec_kwh, annual_gas_kwh, tariff) {
  weights <- c(1.25, 1.20, 1.10, 0.95, 0.85, 0.80, 0.78, 0.80, 0.88, 1.02, 1.15, 1.22)
  months <- c("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
  
  monthly_base <- ((annual_elec_kwh * tariff$electricity_unit_rate / 100) + (annual_gas_kwh * tariff$gas_unit_rate / 100)) / 12
  monthly_standing <- (365 * (tariff$electricity_standing_charge + tariff$gas_standing_charge) / 100) / 12
  
  central <- numeric(12)
  for (i in 1:12) {
    central[i] <- round((monthly_base * weights[i] + monthly_standing) * 1.05, 2)
  }
  
  data.frame(
    month = months,
    forecast_gbp = central,
    low_range = round(central * 0.90, 2),
    high_range = round(central * 1.12, 2)
  )
}
