# R Carbon Model
calculate_carbon_emissions <- function(kwh_vector, carbon_intensity_g_kwh) {
  total_g <- sum(kwh_vector * carbon_intensity_g_kwh, na.rm = TRUE)
  total_kg <- total_g / 1000
  total_tonnes <- total_kg / 1000
  
  list(
    total_kg_co2 = round(total_kg, 2),
    total_tonnes_co2 = round(total_tonnes, 3)
  )
}
