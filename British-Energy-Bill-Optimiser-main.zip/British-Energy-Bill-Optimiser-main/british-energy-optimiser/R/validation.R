# R Validation Engine
validate_bill_data <- function(elec_kwh, gas_kwh, unit_rate_p, standing_p) {
  errors <- c()
  if (elec_kwh < 0) errors <- c(errors, "Electricity consumption cannot be negative")
  if (gas_kwh < 0) errors <- c(errors, "Gas consumption cannot be negative")
  if (unit_rate_p <= 0 || unit_rate_p > 100) errors <- c(errors, "Unusual unit rate")
  if (standing_p <= 0 || standing_p > 300) errors <- c(errors, "Unusual standing charge")
  
  list(
    valid = length(errors) == 0,
    errors = errors
  )
}
