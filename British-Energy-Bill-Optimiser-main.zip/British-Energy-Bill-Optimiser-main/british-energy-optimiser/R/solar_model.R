# R Solar PV Model
calculate_solar_generation <- function(capacity_kwp, export_rate_p = 15.0) {
  annual_kwh <- capacity_kwp * 900 # UK average 900 kWh per kWp
  self_consumption_pct <- 0.40 # 40% self consumed without battery
  
  self_kwh <- annual_kwh * self_consumption_pct
  export_kwh <- annual_kwh * (1 - self_consumption_pct)
  export_revenue <- (export_kwh * export_rate_p) / 100
  
  list(
    capacity_kwp = capacity_kwp,
    annual_kwh = annual_kwh,
    self_kwh = self_kwh,
    export_kwh = export_kwh,
    export_revenue_gbp = round(export_revenue, 2)
  )
}
