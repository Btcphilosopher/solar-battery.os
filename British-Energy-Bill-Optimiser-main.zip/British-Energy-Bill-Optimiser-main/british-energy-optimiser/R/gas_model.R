# R Gas Model
convert_gas_m3_to_kwh <- function(m3, cv = 39.5, vcf = 1.02264) {
  (m3 * vcf * cv) / 3.6
}

calculate_gas_bill <- function(kwh, rate_p = 6.24, standing_p = 31.40, days = 365) {
  unit_gbp <- (kwh * rate_p) / 100
  standing_gbp <- (days * standing_p) / 100
  subtotal <- unit_gbp + standing_gbp
  vat <- subtotal * 0.05
  
  list(
    kwh = kwh,
    unit_cost_gbp = round(unit_gbp, 2),
    standing_cost_gbp = round(standing_gbp, 2),
    vat_gbp = round(vat, 2),
    total_gbp = round(subtotal + vat, 2)
  )
}
