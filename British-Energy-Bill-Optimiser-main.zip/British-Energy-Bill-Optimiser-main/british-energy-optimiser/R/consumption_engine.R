# R Consumption Engine
# Analyzes half-hourly smart meter profiles, baseload detection, and peak demand

analyze_consumption <- function(hh_data) {
  if (is.null(hh_data) || nrow(hh_data) == 0) return(NULL)
  
  # Night periods (01:00 to 05:00)
  night_data <- hh_data[hh_data$settlement_period >= 3 & hh_data$settlement_period <= 10, ]
  night_powers <- night_data$consumption_kwh * 2 # kW
  
  baseload_kw <- min(night_powers, na.rm = TRUE)
  annual_baseload_kwh <- baseload_kw * 24 * 365
  
  max_kwh <- max(hh_data$consumption_kwh, na.rm = TRUE)
  peak_demand_kw <- max_kwh * 2
  
  list(
    avg_daily_kwh = round(sum(hh_data$consumption_kwh) / (nrow(hh_data)/48), 2),
    baseload_kw = round(baseload_kw, 2),
    annual_baseload_kwh = round(annual_baseload_kwh),
    peak_demand_kw = round(peak_demand_kw, 2)
  )
}

generate_mock_hh_data <- function(profile_type = "family") {
  days <- 14
  n <- days * 48
  settlement_period <- rep(1:48, days)
  consumption_kwh <- numeric(n)
  
  for (i in 1:n) {
    p <- settlement_period[i]
    hour <- (p - 1) %/% 2
    base <- 0.12 + runif(1, 0, 0.05)
    
    if (profile_type == "family") {
      if (hour >= 7 && hour <= 9) base <- base + 0.35
      if (hour >= 17 && hour <= 21) base <- base + 0.45
    } else if (profile_type == "ev") {
      if (hour >= 18 && hour <= 21) base <- base + 3.0
    }
    consumption_kwh[i] <- round(base, 3)
  }
  
  data.frame(
    settlement_period = settlement_period,
    consumption_kwh = consumption_kwh
  )
}
