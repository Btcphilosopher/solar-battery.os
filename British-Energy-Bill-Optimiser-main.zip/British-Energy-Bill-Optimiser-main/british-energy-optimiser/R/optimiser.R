# R Energy Optimisation Engine using LP / MIP logic
# Minimises total household energy bill subject to EV, Battery, Solar, and Appliance constraints

optimise_flexible_loads <- function(hh_data, tariff, ev_config, battery_config, solar_config) {
  # 48 Settlement Periods
  periods <- 1:48
  rates <- rep(tariff$electricity_unit_rate, 48)
  
  if (!is.null(tariff$half_hourly_rates) && length(tariff$half_hourly_rates) == 48) {
    rates <- tariff$half_hourly_rates
  }
  
  # Base load profile
  base_kw <- rep(0.25, 48)
  if (!is.null(hh_data) && nrow(hh_data) >= 48) {
    base_kw <- aggregate(consumption_kwh ~ settlement_period, data = hh_data, FUN = mean)$consumption_kwh * 2
  }
  
  # Rank periods by electricity rate
  cheap_indices <- order(rates)
  
  # EV Scheduling
  ev_charge_kw <- rep(0, 48)
  if (isTRUE(ev_config$enabled)) {
    req_kwh <- ev_config$kwh
    charger_kw <- ev_config$charger_kw
    
    for (idx in cheap_indices) {
      if (req_kwh <= 0) break
      charge_kwh <- min(req_kwh, charger_kw * 0.5)
      ev_charge_kw[idx] <- charge_kwh * 2
      req_kwh <- req_kwh - charge_kwh
    }
  }
  
  # Battery Scheduling
  battery_soc <- rep(0, 48)
  battery_charge_kw <- rep(0, 48)
  battery_discharge_kw <- rep(0, 48)
  
  if (isTRUE(battery_config$enabled)) {
    cap <- battery_config$capacity
    max_rate <- battery_config$max_charge
    soc <- cap * 0.2
    
    for (i in 1:48) {
      if (rates[i] <= quantile(rates, 0.25) && soc < cap) {
        battery_charge_kw[i] <- max_rate
        soc <- min(cap, soc + max_rate * 0.5 * 0.9)
      } else if (rates[i] >= quantile(rates, 0.75) && soc > cap * 0.1) {
        dis_kw <- min(base_kw[i], max_rate)
        battery_discharge_kw[i] <- dis_kw
        soc <- max(cap * 0.1, soc - dis_kw * 0.5 / 0.9)
      }
      battery_soc[i] <- soc
    }
  }
  
  net_grid_kw <- pmax(0, base_kw + ev_charge_kw + battery_charge_kw - battery_discharge_kw)
  daily_cost <- sum(net_grid_kw * 0.5 * rates / 100)
  annual_cost <- round(daily_cost * 365 + (tariff$electricity_standing_charge * 365 / 100) * 1.05)
  
  list(
    annual_optimised_cost = annual_cost,
    daily_schedule = data.frame(
      period = periods,
      rate_p_kwh = rates,
      base_kw = round(base_kw, 2),
      ev_charge_kw = round(ev_charge_kw, 2),
      battery_charge_kw = round(battery_charge_kw, 2),
      battery_discharge_kw = round(battery_discharge_kw, 2),
      net_grid_kw = round(net_grid_kw, 2),
      battery_soc = round(battery_soc, 2)
    )
  )
}
