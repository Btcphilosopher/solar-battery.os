# R Tariff Importer
import_tariffs_from_json <- function(filepath = "data/tariffs/tariffs_data.json") {
  if (file.exists(filepath)) {
    jsonlite::fromJSON(filepath)
  } else {
    list()
  }
}
