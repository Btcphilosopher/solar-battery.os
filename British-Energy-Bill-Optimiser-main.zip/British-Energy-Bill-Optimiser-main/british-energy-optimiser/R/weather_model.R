# R Weather Integration Model
calculate_degree_days <- function(daily_temps_c, base_temp_c = 15.5) {
  pmax(0, base_temp_c - daily_temps_c)
}
