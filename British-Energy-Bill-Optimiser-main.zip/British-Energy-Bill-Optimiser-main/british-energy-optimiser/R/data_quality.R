# R Data Quality Engine
evaluate_hh_data_quality <- function(hh_data) {
  if (is.null(hh_data) || nrow(hh_data) == 0) return(list(quality_score = 0))
  
  expected <- 48 * (nrow(hh_data) / 48)
  missing <- expected - nrow(hh_data)
  score <- max(0, 100 - (missing / expected) * 50)
  
  list(
    quality_score = round(score, 1),
    total_records = nrow(hh_data),
    missing_records = missing
  )
}
