# R Home Battery Model
calculate_battery_savings <- function(capacity_kwh, price_spread_p_kwh = 18.0, round_trip_eff = 0.90) {
  daily_cycles <- 1
  annual_kwh_shifted <- capacity_kwh * daily_cycles * 365
  gross_saving_gbp <- (annual_kwh_shifted * price_spread_p_kwh * round_trip_eff) / 100
  
  list(
    capacity_kwh = capacity_kwh,
    annual_kwh_shifted = round(annual_kwh_shifted),
    gross_saving_gbp = round(gross_saving_gbp, 2)
  )
}
