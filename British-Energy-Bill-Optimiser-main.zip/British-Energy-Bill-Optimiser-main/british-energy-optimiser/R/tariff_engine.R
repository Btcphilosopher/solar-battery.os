# R Tariff Engine
# Handles British energy market tariffs, time-of-use rates, Ofgem price cap benchmarks

calculate_tariff_cost <- function(hh_data, tariff, days = 365) {
  if (is.null(hh_data) || nrow(hh_data) == 0) return(NULL)
  
  # Calculate 48-period rate lookup
  rates <- rep(tariff$electricity_unit_rate, 48)
  
  if (!is.null(tariff$half_hourly_rates) && length(tariff$half_hourly_rates) == 48) {
    rates <- tariff$half_hourly_rates
  } else if (!is.null(tariff$time_rates) && length(tariff$time_rates) > 0) {
    for (i in 1:48) {
      hour <- (i - 1) %/% 2
      min <- ((i - 1) %% 2) * 30
      time_str <- sprintf("%02d:%02d", hour, min)
      for (b in tariff$time_rates) {
        if (time_str >= b$start_time && time_str < b$end_time) {
          rates[i] <- b$rate_p_kwh
        }
      }
    }
  }
  
  sample_days <- max(1, nrow(hh_data) / 48)
  scale <- days / sample_days
  
  total_kwh <- sum(hh_data$consumption_kwh, na.rm = TRUE) * scale
  unit_cost_gbp <- sum(hh_data$consumption_kwh * rates[hh_data$settlement_period] / 100, na.rm = TRUE) * scale
  standing_cost_gbp <- (days * tariff$electricity_standing_charge) / 100
  
  subtotal <- unit_cost_gbp + standing_cost_gbp
  vat <- subtotal * 0.05
  grand_total <- subtotal + vat
  
  list(
    tariff_name = tariff$name,
    supplier = tariff$supplier,
    annual_kwh = round(total_kwh),
    unit_cost_gbp = round(unit_cost_gbp, 2),
    standing_cost_gbp = round(standing_cost_gbp, 2),
    vat_gbp = round(vat, 2),
    annual_total_gbp = round(grand_total, 2)
  )
}
