# Test Suite for British Energy Optimiser Tariff Engine
library(testthat)

source("../../R/tariff_engine.R")
source("../../R/bill_calculator.R")

test_that("Itemised bill VAT calculation is exactly 5%", {
  tariff <- list(
    name = "Test Tariff",
    supplier = "Test",
    electricity_unit_rate = 20.0,
    electricity_standing_charge = 50.0,
    gas_unit_rate = 5.0,
    gas_standing_charge = 25.0
  )
  
  res <- calculate_itemised_bill(1000, 5000, tariff, days = 365)
  expect_equal(res$vat, round(res$subtotal * 0.05, 2))
  expect_equal(res$grand_total, round(res$subtotal + res$vat, 2))
})
