# British Energy Bill Optimiser - Global Architecture File
# Loads dependencies, sources core R modules, and initializes default datasets

suppressPackageStartupMessages({
  library(shiny)
  library(bslib)
  library(ggplot2)
  library(plotly)
  library(DT)
  library(dplyr)
  library(tidyr)
  library(lubridate)
  library(jsonlite)
})

# Source core engine modules
source("R/tariff_engine.R")
source("R/bill_calculator.R")
source("R/consumption_engine.R")
source("R/optimiser.R")
source("R/forecast_engine.R")
source("R/solar_model.R")
source("R/battery_model.R")
source("R/ev_model.R")
source("R/heatpump_model.R")
source("R/gas_model.R")
source("R/carbon_model.R")
source("R/scenario_engine.R")
source("R/weather_model.R")
source("R/data_quality.R")
source("R/tariff_importer.R")
source("R/validation.R")

# Source Shiny UI modules
source("modules/dashboard.R")
source("modules/consumption.R")
source("modules/tariffs.R")
source("modules/optimiser_ui.R")
source("modules/forecast.R")
source("modules/scenarios.R")
source("modules/settings.R")

# Default British Energy Constants
DEFAULT_VAT_RATE <- 0.05 # 5% UK Domestic Energy VAT
DEFAULT_REGION <- "london"
DEFAULT_OFGEM_CAP_ELEC_P_KWH <- 24.50
DEFAULT_OFGEM_CAP_ELEC_STANDING <- 60.10
DEFAULT_OFGEM_CAP_GAS_P_KWH <- 6.24
DEFAULT_OFGEM_CAP_GAS_STANDING <- 31.40
