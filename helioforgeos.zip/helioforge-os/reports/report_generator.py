"""Machine-readable design report generation (requirement #92)."""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from engine.digital_twin.twin import PVDigitalTwin


def generate_design_report(twin: PVDigitalTwin) -> dict:
    report = twin.design_report()
    report["generated_at_utc"] = datetime.now(timezone.utc).isoformat()
    report["engine"] = "HELIOFORGE.OS"
    return report


def write_report_json(twin: PVDigitalTwin, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    report = generate_design_report(twin)
    path.write_text(json.dumps(report, indent=2, default=str))
    return path


def compare_designs(twins: dict[str, PVDigitalTwin]) -> dict:
    """Requirement #86: side-by-side design comparison table."""
    rows = {}
    for name, twin in twins.items():
        m = twin.metrics()
        rows[name] = {
            "dc_capacity_mwp": round(m["dc_capacity_mw"], 3),
            "ac_capacity_mw": round(m["ac_capacity_mw"], 3),
            "annual_mwh": round(m["annual_energy_mwh"], 1),
            "land_ha": round(m["land_used_ha"], 2),
            "mwh_per_ha": round(m["mwh_per_hectare"], 2),
            "capex_usd": round(m["capex_usd"], 0),
            "opex_year1_usd": round(twin.economics.get("opex_year1_usd", 0.0), 0),
            "lcoe_usd_per_mwh": round(m["lcoe_usd_per_mwh"], 2),
            "npv_usd": round(m["npv_usd"], 0),
            "irr_pct": round(m["irr_pct"], 2),
            "curtailment_pct": round(m["curtailment_pct"], 2),
        }
    return rows
