"""Heatmap generation: solar resource, production, shading, land
productivity, CAPEX/revenue contribution — rendered with Plotly."""
from __future__ import annotations

from pathlib import Path

import numpy as np
import plotly.graph_objects as go

from engine.terrain.dem import DEM


def terrain_heatmap(dem: DEM, metric: str = "elevation", out_path: str | Path | None = None) -> go.Figure:
    if metric == "elevation":
        z, title = dem.z, "Elevation (m)"
    elif metric == "slope":
        z, title = dem.slope_degrees(), "Slope (deg)"
    elif metric == "aspect":
        z, title = dem.aspect_degrees(), "Aspect (deg)"
    else:
        raise ValueError(f"Unknown terrain metric '{metric}'")

    fig = go.Figure(data=go.Heatmap(z=z, x=dem.x[0, :], y=dem.y[:, 0], colorscale="Viridis"))
    fig.update_layout(title=title, xaxis_title="Easting (m)", yaxis_title="Northing (m)")
    if out_path:
        Path(out_path).parent.mkdir(parents=True, exist_ok=True)
        fig.write_html(str(out_path))
    return fig


def monthly_generation_heatmap(monthly_df, out_path: str | Path | None = None) -> go.Figure:
    fig = go.Figure(data=go.Bar(x=monthly_df["month"], y=monthly_df["generation_mwh"],
                                 marker=dict(color=monthly_df["capacity_factor_pct"], colorscale="Turbo")))
    fig.update_layout(title="Monthly Generation (MWh)", xaxis_title="Month", yaxis_title="MWh")
    if out_path:
        Path(out_path).parent.mkdir(parents=True, exist_ok=True)
        fig.write_html(str(out_path))
    return fig


def shading_heatmap(row_shading_pct: np.ndarray, out_path: str | Path | None = None) -> go.Figure:
    fig = go.Figure(data=go.Bar(x=list(range(len(row_shading_pct))), y=row_shading_pct))
    fig.update_layout(title="Annual Shading Loss by Row (%)", xaxis_title="Row #", yaxis_title="Shading loss %")
    if out_path:
        Path(out_path).parent.mkdir(parents=True, exist_ok=True)
        fig.write_html(str(out_path))
    return fig
