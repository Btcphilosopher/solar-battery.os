"""Time-series dashboard: irradiance, DC/AC power, battery SOC, export,
curtailment vs time — rendered with Plotly."""
from __future__ import annotations

from pathlib import Path

import plotly.graph_objects as go
from plotly.subplots import make_subplots

from engine.digital_twin.twin import PVDigitalTwin


def build_dashboard(twin: PVDigitalTwin, out_path: str | Path | None = None,
                     day_slice: slice | None = None) -> go.Figure:
    df = twin.energy_result.timeseries
    if day_slice is not None:
        df = df.iloc[day_slice]

    fig = make_subplots(rows=4, cols=1, shared_xaxes=True,
                         subplot_titles=("Irradiance (W/m²)", "DC / AC Power (kW / MW)",
                                         "Battery SOC (MWh)", "Grid Export / Curtailment (MW)"))

    fig.add_trace(go.Scatter(x=df["timestamp"], y=df["ghi_wm2"], name="GHI"), row=1, col=1)
    fig.add_trace(go.Scatter(x=df["timestamp"], y=df["poa_global_wm2"], name="POA"), row=1, col=1)

    fig.add_trace(go.Scatter(x=df["timestamp"], y=df["dc_power_kw"], name="DC Power (kW)"), row=2, col=1)
    fig.add_trace(go.Scatter(x=df["timestamp"], y=df["ac_power_mw"] * 1000, name="AC Power (kW)"), row=2, col=1)

    fig.add_trace(go.Scatter(x=df["timestamp"], y=df["battery_soc_mwh"], name="Battery SOC"), row=3, col=1)

    fig.add_trace(go.Scatter(x=df["timestamp"], y=df["export_mw"], name="Grid export (MW)"), row=4, col=1)
    fig.add_trace(go.Scatter(x=df["timestamp"], y=df["curtailed_mw"], name="Curtailed (MW)"), row=4, col=1)

    fig.update_layout(height=900, title=f"HELIOFORGE.OS Time-Series Dashboard — {twin.site.name}")
    if out_path:
        Path(out_path).parent.mkdir(parents=True, exist_ok=True)
        fig.write_html(str(out_path))
    return fig
