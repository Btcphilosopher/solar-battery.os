"""2D field visualisation: site boundary, PV rows, roads, obstacles."""
from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from shapely.geometry import Polygon

from engine.arrays.row_generator import generate_rows
from engine.digital_twin.twin import PVDigitalTwin


def render_field(twin: PVDigitalTwin, out_path: str | Path, title: str | None = None) -> Path:
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    fig, ax = plt.subplots(figsize=(10, 8))

    bx, by = twin.site.boundary.exterior.xy
    ax.fill(bx, by, color="#d9d2c5", alpha=0.6, label="Site boundary")
    ax.plot(bx, by, color="#5c5346", linewidth=1.5)

    if twin.land is not None and not twin.land.usable_polygon.is_empty:
        ux, uy = twin.land.usable_polygon.exterior.xy
        ax.fill(ux, uy, color="#c8e6c9", alpha=0.5, label="Usable PV land")

    for obs in twin.site.obstacles:
        ox, oy = obs.footprint.exterior.xy
        ax.fill(ox, oy, color="#8d6e63", alpha=0.8)

    if twin.land is not None:
        rows = generate_rows(twin.land.usable_polygon, twin.design.row_spacing_m, twin.design.azimuth_deg)
        for r in rows:
            rx, ry = r.line.xy
            ax.plot(rx, ry, color="#1565c0", linewidth=1.0, alpha=0.8)

    ax.set_aspect("equal", adjustable="box")
    ax.set_xlabel("Easting (m)")
    ax.set_ylabel("Northing (m)")
    ax.set_title(title or f"HELIOFORGE.OS — {twin.site.name}")
    ax.legend(loc="upper right", fontsize=8)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return out_path
