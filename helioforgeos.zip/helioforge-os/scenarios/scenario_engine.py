"""Scenario engine: named preset overlays over a base digital twin design."""
from __future__ import annotations

from dataclasses import replace

from engine.digital_twin.twin import DesignParameters, PVDigitalTwin
from engine.land.site import PVSite

SCENARIO_OVERRIDES = {
    "BASE": {},
    "HIGH_SOLAR": {"climate_profile": "desert"},
    "LOW_SOLAR": {"climate_profile": "coastal"},
    "HIGH_POWER_PRICE": {"electricity_price_usd_per_mwh": 65.0},
    "LOW_POWER_PRICE": {"electricity_price_usd_per_mwh": 30.0},
    "MAXIMUM_PV": {"row_spacing_m": 5.0, "dc_ac_ratio": 1.1},
    "MINIMUM_PV": {"row_spacing_m": 10.0, "dc_ac_ratio": 1.4},
    "BATTERY": {"storage_enabled": True},
    "NO_BATTERY": {"storage_enabled": False},
    "GRID_LIMITED": {"grid_export_limit_mw": 40.0},
}


def build_scenario_twin(site: PVSite, base_design: DesignParameters, scenario_name: str) -> PVDigitalTwin:
    if scenario_name not in SCENARIO_OVERRIDES:
        raise KeyError(f"Unknown scenario '{scenario_name}'. Available: {list(SCENARIO_OVERRIDES)}")
    overrides = SCENARIO_OVERRIDES[scenario_name]
    design = replace(base_design, **overrides)
    twin = PVDigitalTwin(site=site, design=design)
    twin.recalculate()
    return twin


def run_all_scenarios(site: PVSite, base_design: DesignParameters,
                       scenario_names: list[str] | None = None) -> dict:
    names = scenario_names or list(SCENARIO_OVERRIDES)
    results = {}
    for name in names:
        twin = build_scenario_twin(site, base_design, name)
        results[name] = twin.metrics()
    return results
