"""Async job manager for long-running optimisation runs.

Optimisation jobs never block the API: they run on a background thread
pool (optimisation is CPU-bound numerical work, so a thread executor
sidesteps holding up the asyncio event loop) and are polled by job_id.
"""
from __future__ import annotations

import uuid
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from typing import Any, Callable, Optional

_executor = ThreadPoolExecutor(max_workers=4)


@dataclass
class Job:
    job_id: str
    status: str = "PENDING"       # PENDING | RUNNING | SUCCESS | FAILED
    progress: float = 0.0
    result: Any = None
    error: Optional[str] = None


class JobManager:
    def __init__(self):
        self._jobs: dict[str, Job] = {}

    def submit(self, fn: Callable[[], Any]) -> str:
        job_id = str(uuid.uuid4())
        job = Job(job_id=job_id, status="PENDING")
        self._jobs[job_id] = job

        def runner():
            job.status = "RUNNING"
            try:
                job.result = fn()
                job.status = "SUCCESS"
                job.progress = 1.0
            except Exception as exc:  # noqa: BLE001
                job.status = "FAILED"
                job.error = str(exc)

        _executor.submit(runner)
        return job_id

    def get(self, job_id: str) -> Job | None:
        return self._jobs.get(job_id)


job_manager = JobManager()
