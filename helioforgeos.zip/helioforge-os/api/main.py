"""HELIOFORGE.OS FastAPI application.

Holds one in-memory PVDigitalTwin as the active project session. Every
GET reads its current state; every POST mutates it and (per requirement
#87) triggers a full recalculation before responding.
"""
from __future__ import annotations

import asyncio
import json

from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect

from api.jobs import job_manager
from api.schemas import (LayoutGenerateRequest, OptimisationRunRequest,
                          ScenarioRunRequest, SimulationRunRequest, SiteCreateRequest)
from engine.digital_twin.time_engine import TimeEngine
from engine.digital_twin.twin import DesignParameters, PVDigitalTwin
from engine.land.site import PVSite
from engine.land.site_generator import generate_synthetic_site
from engine.optimisation.optimizer import DesignVariable, Objective, PVOptimizer
from engine.validation.validators import validate_twin
from reports.report_generator import generate_design_report
from scenarios.scenario_engine import build_scenario_twin

app = FastAPI(title="HELIOFORGE.OS", version="0.1.0",
              description="Parametric PV design, simulation, digital-twin and optimisation engine.")

_state: dict[str, PVDigitalTwin | None] = {"twin": None}


def _require_twin() -> PVDigitalTwin:
    twin = _state["twin"]
    if twin is None:
        raise HTTPException(status_code=404, detail="No active site/project. POST /site/create first.")
    return twin


# --------------------------------------------------------------------- #
# Site
# --------------------------------------------------------------------- #
@app.post("/site/create")
def create_site(req: SiteCreateRequest):
    if req.mode == "rectangle" and req.width_m and req.height_m:
        site = PVSite.from_rectangle(req.site_id, req.name, req.width_m, req.height_m,
                                      req.latitude, req.longitude, elevation_m=req.elevation_m)
    elif req.mode == "coordinates" and req.coordinates:
        site = PVSite.from_coordinates(req.site_id, req.name, req.coordinates,
                                        req.latitude, req.longitude, elevation_m=req.elevation_m)
    elif req.mode == "geojson" and req.geojson_geometry:
        site = PVSite.from_geojson(req.site_id, req.name, req.geojson_geometry,
                                    req.latitude, req.longitude, elevation_m=req.elevation_m)
    else:
        site = generate_synthetic_site(req.site_id, req.name, req.area_hectares, req.terrain_profile,
                                        req.latitude, req.longitude, req.elevation_m)

    twin = PVDigitalTwin(site=site, design=DesignParameters())
    twin.recalculate()
    _state["twin"] = twin
    return {"site_id": site.site_id, "area_ha": site.area_hectares, "report": generate_design_report(twin)}


@app.get("/site")
def get_site():
    twin = _require_twin()
    return {"site_id": twin.site.site_id, "name": twin.site.name, "area_ha": twin.site.area_hectares,
            "latitude": twin.site.latitude, "longitude": twin.site.longitude, "land_use": twin.site.land_use}


@app.get("/site/terrain")
def get_site_terrain():
    twin = _require_twin()
    dem = twin.site.terrain
    if dem is None:
        raise HTTPException(status_code=404, detail="Site has no terrain model.")
    return {"cell_size_m": dem.cell_size_m, "shape": list(dem.z.shape),
            "elevation_min_m": float(dem.z.min()), "elevation_max_m": float(dem.z.max()),
            "mean_slope_pct": float(dem.slope_percent().mean())}


@app.get("/site/boundary")
def get_site_boundary():
    twin = _require_twin()
    return twin.land.to_dict() if twin.land else {}


# --------------------------------------------------------------------- #
# PV
# --------------------------------------------------------------------- #
@app.get("/pv/modules")
def get_modules():
    from engine.modules.presets import list_module_presets
    return {"presets": list_module_presets()}


@app.get("/pv/arrays")
def get_arrays():
    twin = _require_twin()
    return twin.array.to_dict() if twin.array else {}


@app.get("/pv/layout")
def get_layout():
    twin = _require_twin()
    return {"module_count": twin.module_count, "array": twin.array.to_dict() if twin.array else {}}


@app.post("/pv/layout/generate")
def generate_layout(req: LayoutGenerateRequest):
    twin = _require_twin()
    twin.apply_design(req.model_dump())
    twin.recalculate()
    return {"report": generate_design_report(twin), "validation": [i.__dict__ for i in validate_twin(twin)]}


@app.get("/pv/irradiance")
def get_irradiance():
    twin = _require_twin()
    if twin.energy_result is None:
        raise HTTPException(status_code=404, detail="Run /simulation/run first.")
    df = twin.energy_result.timeseries
    return {"mean_ghi_wm2": float(df["ghi_wm2"].mean()), "mean_poa_wm2": float(df["poa_global_wm2"].mean())}


@app.get("/pv/production")
def get_production():
    twin = _require_twin()
    if twin.energy_result is None:
        raise HTTPException(status_code=404, detail="Run /simulation/run first.")
    r = twin.energy_result
    return {"annual_dc_energy_mwh": r.annual_dc_energy_mwh, "annual_ac_energy_mwh": r.annual_ac_energy_mwh,
            "annual_export_mwh": r.annual_export_mwh, "annual_curtailed_mwh": r.annual_curtailed_mwh,
            "capacity_factor_pct": r.capacity_factor_pct, "performance_ratio_pct": r.performance_ratio_pct}


# --------------------------------------------------------------------- #
# Simulation
# --------------------------------------------------------------------- #
@app.post("/simulation/run")
def run_simulation(req: SimulationRunRequest):
    twin = _require_twin()
    twin.run_energy(degradation_year=req.degradation_year)
    twin.run_lifetime()
    twin.compute_economics()
    return generate_design_report(twin)


@app.get("/simulation/state")
def get_simulation_state(timestamp: str | None = None):
    twin = _require_twin()
    if twin.energy_result is None:
        raise HTTPException(status_code=404, detail="Run /simulation/run first.")
    engine = TimeEngine(twin)
    import pandas as pd
    ts = pd.Timestamp(timestamp) if timestamp else twin.energy_result.timeseries["timestamp"].iloc[4380]
    state = engine.state_at(ts)
    return state.__dict__


@app.get("/simulation/year")
def get_simulation_year():
    twin = _require_twin()
    if twin.energy_result is None:
        raise HTTPException(status_code=404, detail="Run /simulation/run first.")
    return TimeEngine(twin).year_summary()


@app.get("/simulation/day")
def get_simulation_day(month: int = 6, day: int = 21):
    twin = _require_twin()
    if twin.energy_result is None:
        raise HTTPException(status_code=404, detail="Run /simulation/run first.")
    df = TimeEngine(twin).day_profile(month, day)
    return json.loads(df.to_json(orient="records", date_format="iso"))


# --------------------------------------------------------------------- #
# Economics
# --------------------------------------------------------------------- #
@app.get("/economics")
def get_economics():
    twin = _require_twin()
    return twin.economics


@app.get("/economics/sensitivity")
def get_sensitivity():
    twin = _require_twin()
    from engine.economics.sensitivity import run_full_sensitivity

    def base_case(overrides: dict) -> float:
        mult = list(overrides.values())[0] if overrides else 1.0
        base_lcoe = twin.economics.get("lcoe_usd_per_mwh", 0.0)
        return base_lcoe * mult   # simplified linear proxy for a fast sensitivity sweep
    df = run_full_sensitivity(base_case)
    return json.loads(df.to_json(orient="records"))


# --------------------------------------------------------------------- #
# Optimisation (async jobs)
# --------------------------------------------------------------------- #
@app.post("/optimisation/run")
def run_optimisation(req: OptimisationRunRequest):
    twin = _require_twin()
    variables = [
        DesignVariable("tilt_deg", 5.0, 45.0),
        DesignVariable("azimuth_deg", 90.0, 270.0),
        DesignVariable("row_spacing_m", 4.0, 15.0),
        DesignVariable("dc_ac_ratio", 1.0, 1.6),
    ]

    def evaluate_fn(design: dict) -> dict:
        return twin.evaluate(design)

    try:
        objective = Objective(req.mode)
    except ValueError:
        objective = Objective.BALANCED
    constraints = {}
    if req.max_land_ha:
        constraints["land_used_ha"] = ("<=", req.max_land_ha)
    if req.grid_limit_mw:
        constraints["ac_capacity_mw"] = ("<=", req.grid_limit_mw)
    if req.required_annual_energy_mwh:
        constraints["annual_energy_mwh"] = (">=", req.required_annual_energy_mwh)

    optimizer = PVOptimizer(variables, evaluate_fn, objective=objective,
                             weights=req.weights, constraints=constraints)

    def job_fn():
        result = optimizer.run(max_iter=req.max_iter, popsize=req.popsize)
        return {"objective": result.objective, "best_design": result.best_design,
                "best_metrics": result.best_metrics, "n_evaluations": result.n_evaluations}

    job_id = job_manager.submit(job_fn)
    return {"job_id": job_id, "status": "PENDING"}


@app.get("/optimisation/results")
def get_optimisation_results(job_id: str):
    job = job_manager.get(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Unknown job_id.")
    return {"job_id": job.job_id, "status": job.status, "progress": job.progress,
            "result": job.result, "error": job.error}


# --------------------------------------------------------------------- #
# Scenarios
# --------------------------------------------------------------------- #
@app.post("/scenario/run")
def run_scenario(req: ScenarioRunRequest):
    twin = _require_twin()
    scenario_twin = build_scenario_twin(twin.site, twin.design, req.scenario_name)
    return {"scenario": req.scenario_name, "metrics": scenario_twin.metrics()}


# --------------------------------------------------------------------- #
# WebSockets — live digital-twin / production / optimisation / site feeds
# --------------------------------------------------------------------- #
async def _stream_loop(ws: WebSocket, payload_fn, interval_s: float = 2.0):
    await ws.accept()
    try:
        while True:
            twin = _state["twin"]
            await ws.send_json(payload_fn(twin) if twin else {"status": "no_active_project"})
            await asyncio.sleep(interval_s)
    except WebSocketDisconnect:
        pass


@app.websocket("/ws/digital-twin")
async def ws_digital_twin(ws: WebSocket):
    await _stream_loop(ws, lambda t: t.metrics())


@app.websocket("/ws/production")
async def ws_production(ws: WebSocket):
    def payload(t: PVDigitalTwin):
        if t.energy_result is None:
            return {"status": "not_simulated"}
        r = t.energy_result
        return {"annual_ac_energy_mwh": r.annual_ac_energy_mwh, "capacity_factor_pct": r.capacity_factor_pct}
    await _stream_loop(ws, payload)


@app.websocket("/ws/optimisation")
async def ws_optimisation(ws: WebSocket):
    await ws.accept()
    try:
        while True:
            job_id = await ws.receive_text()
            job = job_manager.get(job_id)
            await ws.send_json({"status": job.status if job else "unknown", "progress": job.progress if job else 0})
            await asyncio.sleep(1.0)
    except WebSocketDisconnect:
        pass


@app.websocket("/ws/site")
async def ws_site(ws: WebSocket):
    def payload(t: PVDigitalTwin):
        return {"site_id": t.site.site_id, "area_ha": t.site.area_hectares}
    await _stream_loop(ws, payload, interval_s=5.0)
