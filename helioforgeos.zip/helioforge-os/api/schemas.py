"""Pydantic request/response schemas for the HELIOFORGE.OS API."""
from __future__ import annotations

from typing import Optional

from pydantic import BaseModel


class SiteCreateRequest(BaseModel):
    site_id: str = "SITE-1"
    name: str = "New Site"
    mode: str = "synthetic"          # synthetic | rectangle | coordinates | geojson
    area_hectares: float = 250.0
    terrain_profile: str = "flat"
    latitude: float = 37.5
    longitude: float = -5.0
    elevation_m: float = 100.0
    width_m: Optional[float] = None
    height_m: Optional[float] = None
    coordinates: Optional[list[tuple[float, float]]] = None
    geojson_geometry: Optional[dict] = None


class LayoutGenerateRequest(BaseModel):
    module_preset: str = "550W"
    tracker_type: str = "fixed_tilt"
    tilt_deg: float = 25.0
    azimuth_deg: float = 180.0
    row_spacing_m: float = 6.0
    dc_ac_ratio: float = 1.25
    setback_m: float = 10.0
    grid_export_limit_mw: float = 100.0


class SimulationRunRequest(BaseModel):
    degradation_year: int = 1


class OptimisationRunRequest(BaseModel):
    mode: str = "BALANCED"
    max_land_ha: Optional[float] = None
    grid_limit_mw: Optional[float] = None
    required_annual_energy_mwh: Optional[float] = None
    weights: Optional[dict] = None
    max_iter: int = 30
    popsize: int = 10


class ScenarioRunRequest(BaseModel):
    scenario_name: str = "BASE"
