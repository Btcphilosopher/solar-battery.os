import numpy as np
import pandas as pd

from engine.solar.position import solar_position


def test_solar_noon_elevation_near_equator():
    ts = pd.date_range("2026-03-20 12:00", periods=1, freq="h")
    result = solar_position(ts, latitude=0.0, longitude=0.0, timezone_offset_hours=0.0)
    # equinox, equator, solar noon -> sun should be very close to zenith
    assert result.elevation_deg[0] > 85.0


def test_night_elevation_is_negative():
    ts = pd.date_range("2026-06-21 00:00", periods=1, freq="h")
    result = solar_position(ts, latitude=51.5, longitude=0.0)
    assert result.elevation_deg[0] < 0.0


def test_day_length_longer_in_summer_northern_hemisphere():
    summer = pd.date_range("2026-06-21 12:00", periods=1, freq="h")
    winter = pd.date_range("2026-12-21 12:00", periods=1, freq="h")
    r_summer = solar_position(summer, latitude=45.0, longitude=0.0)
    r_winter = solar_position(winter, latitude=45.0, longitude=0.0)
    assert r_summer.day_length_hours[0] > r_winter.day_length_hours[0]
