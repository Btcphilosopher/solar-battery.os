from engine.terrain.dem import generate_synthetic_dem


def test_flat_profile_has_low_slope():
    dem = generate_synthetic_dem(500, 500, profile="flat", cell_size_m=20.0)
    assert dem.slope_degrees().mean() < 5.0


def test_hilly_profile_has_higher_slope_than_flat():
    flat = generate_synthetic_dem(500, 500, profile="flat", cell_size_m=20.0, seed=1)
    hilly = generate_synthetic_dem(500, 500, profile="hilly", cell_size_m=20.0, seed=1)
    assert hilly.slope_degrees().mean() > flat.slope_degrees().mean()


def test_unsuitable_mask_flags_steep_cells():
    dem = generate_synthetic_dem(500, 500, profile="hilly", cell_size_m=20.0)
    mask = dem.unsuitable_mask(max_slope_deg=1.0)
    assert mask.sum() > 0
