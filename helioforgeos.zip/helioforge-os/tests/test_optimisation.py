from engine.optimisation.optimizer import DesignVariable, Objective, PVOptimizer


def _synthetic_evaluate(design: dict) -> dict:
    """A cheap synthetic stand-in for a digital-twin evaluation: capacity
    peaks at x=10, land grows linearly with x."""
    x = design["x"]
    capacity = 100.0 - (x - 10.0) ** 2
    return {"dc_capacity_mw": capacity, "land_used_ha": x * 2.0}


def test_optimizer_finds_capacity_maximum():
    variables = [DesignVariable("x", 0.0, 20.0)]
    optimizer = PVOptimizer(variables, _synthetic_evaluate, objective=Objective.MAX_CAPACITY)
    result = optimizer.run(max_iter=30, popsize=10, seed=1)
    assert abs(result.best_design["x"] - 10.0) < 0.5
    assert result.best_metrics["dc_capacity_mw"] > 99.0


def test_optimizer_respects_land_constraint():
    variables = [DesignVariable("x", 0.0, 20.0)]
    optimizer = PVOptimizer(variables, _synthetic_evaluate, objective=Objective.MAX_CAPACITY,
                             constraints={"land_used_ha": ("<=", 10.0)})
    result = optimizer.run(max_iter=30, popsize=10, seed=1)
    assert result.best_metrics["land_used_ha"] <= 10.5  # small tolerance for soft penalty
