import numpy as np

from engine.irradiance.clearsky import clearsky_ghi, extraterrestrial_irradiance
from engine.irradiance.decomposition import decompose_ghi
from engine.irradiance.transposition import poa_irradiance


def test_clearsky_ghi_zero_below_horizon():
    assert clearsky_ghi(np.array([95.0]))[0] == 0.0


def test_clearsky_ghi_positive_at_low_zenith():
    ghi = clearsky_ghi(np.array([10.0]))[0]
    assert ghi > 800.0


def test_decomposition_bounds():
    ghi = np.array([500.0])
    zenith = np.array([30.0])
    doy = np.array([172.0])
    dni, dhi = decompose_ghi(ghi, zenith, doy)
    assert dni[0] >= 0
    assert dhi[0] >= 0
    assert dhi[0] <= ghi[0] + 1e-6


def test_poa_south_facing_tilt_beats_horizontal_at_low_sun_northern_hemisphere():
    ghi, dni, dhi = np.array([300.0]), np.array([500.0]), np.array([100.0])
    zenith, azimuth = np.array([70.0]), np.array([180.0])
    flat = poa_irradiance(ghi, dni, dhi, zenith, azimuth, surface_tilt_deg=np.array([0.0]),
                           surface_azimuth_deg=np.array([180.0]))
    tilted = poa_irradiance(ghi, dni, dhi, zenith, azimuth, surface_tilt_deg=np.array([30.0]),
                             surface_azimuth_deg=np.array([180.0]))
    assert tilted["poa_global"][0] > flat["poa_global"][0]
