import numpy as np

from engine.storage.battery import BatteryStorage
from engine.storage.dispatch import dispatch_timeseries


def test_battery_reduces_curtailment_vs_no_battery():
    ac_power_mw = np.array([50.0, 150.0, 150.0, 50.0, 0.0, 0.0])
    export_limit_mw = 100.0

    no_batt = dispatch_timeseries(ac_power_mw, export_limit_mw, battery=None, timestep_hours=1.0)
    battery = BatteryStorage(energy_capacity_mwh=100.0, power_capacity_mw=60.0)
    with_batt = dispatch_timeseries(ac_power_mw, export_limit_mw, battery=battery, timestep_hours=1.0)

    assert np.sum(with_batt["curtailed_mw"]) <= np.sum(no_batt["curtailed_mw"]) + 1e-6


def test_battery_soc_stays_within_capacity():
    ac_power_mw = np.array([200.0] * 10)
    battery = BatteryStorage(energy_capacity_mwh=50.0, power_capacity_mw=20.0)
    result = dispatch_timeseries(ac_power_mw, export_limit_mw=50.0, battery=battery, timestep_hours=1.0)
    assert np.all(result["soc_mwh"] <= battery.usable_energy_mwh + 1e-6)
    assert np.all(result["soc_mwh"] >= -1e-6)
