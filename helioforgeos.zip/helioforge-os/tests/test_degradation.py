from engine.degradation.degradation import degradation_factor_series, lifetime_energy_table


def test_degradation_factor_series_decreasing():
    factors = degradation_factor_series(years=30, year1_pct=2.0, annual_pct=0.5)
    assert len(factors) == 30
    assert factors[0] > factors[-1]
    assert factors[0] == 0.98  # 1 - 2%


def test_lifetime_energy_table_cumulative_increasing():
    df = lifetime_energy_table(annual_energy_year1_mwh=1000.0, years=10, year1_pct=2.0, annual_pct=0.5)
    assert len(df) == 10
    assert (df["cumulative_energy_mwh"].diff().dropna() > 0).all()
    assert df["annual_energy_mwh"].iloc[0] > df["annual_energy_mwh"].iloc[-1]
