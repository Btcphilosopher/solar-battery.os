from engine.digital_twin.twin import DesignParameters, PVDigitalTwin
from engine.land.site_generator import generate_synthetic_site


def _small_twin(row_spacing_m: float = 6.0) -> PVDigitalTwin:
    site = generate_synthetic_site("T1", "Test Site", area_hectares=10.0, profile="flat",
                                    latitude=35.0, longitude=-5.0, obstacle_density="low")
    design = DesignParameters(row_spacing_m=row_spacing_m, timestep_minutes=60,
                               grid_export_limit_mw=1000.0)
    twin = PVDigitalTwin(site=site, design=design)
    twin.recalculate()
    return twin


def test_annual_energy_is_positive():
    twin = _small_twin()
    assert twin.energy_result.annual_ac_energy_mwh > 0
    assert twin.energy_result.annual_export_mwh > 0


def test_capacity_factor_within_plausible_bounds():
    twin = _small_twin()
    assert 5.0 < twin.energy_result.capacity_factor_pct < 40.0


def test_wider_row_spacing_increases_specific_yield():
    tight = _small_twin(row_spacing_m=4.0)
    wide = _small_twin(row_spacing_m=10.0)
    # less inter-row shading with wider spacing -> higher yield per kWp installed
    assert wide.energy_result.specific_yield_kwh_per_kwp >= tight.energy_result.specific_yield_kwh_per_kwp


def test_parametric_causality_row_spacing_changes_module_count():
    tight = _small_twin(row_spacing_m=4.0)
    wide = _small_twin(row_spacing_m=10.0)
    assert tight.module_count > wide.module_count
