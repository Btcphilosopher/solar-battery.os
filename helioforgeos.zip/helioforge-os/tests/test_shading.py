import numpy as np

from engine.shading.engine import inter_row_shaded_fraction


def test_tighter_pitch_increases_shading():
    elev, az = np.array([20.0]), np.array([180.0])
    wide = inter_row_shaded_fraction(elev, az, row_azimuth_deg=180.0, tilt_deg=25.0,
                                      slant_length_m=2.3, pitch_m=12.0)
    narrow = inter_row_shaded_fraction(elev, az, row_azimuth_deg=180.0, tilt_deg=25.0,
                                        slant_length_m=2.3, pitch_m=4.0)
    assert narrow[0] > wide[0]


def test_full_shading_below_horizon():
    elev, az = np.array([-5.0]), np.array([180.0])
    frac = inter_row_shaded_fraction(elev, az, row_azimuth_deg=180.0, tilt_deg=25.0,
                                      slant_length_m=2.3, pitch_m=6.0)
    assert frac[0] == 1.0


def test_high_sun_reduces_shading():
    az = np.array([180.0])
    low_sun = inter_row_shaded_fraction(np.array([10.0]), az, 180.0, 25.0, 2.3, 6.0)
    high_sun = inter_row_shaded_fraction(np.array([70.0]), az, 180.0, 25.0, 2.3, 6.0)
    assert high_sun[0] < low_sun[0]
