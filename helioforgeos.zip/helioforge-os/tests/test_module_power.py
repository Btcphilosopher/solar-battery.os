from engine.modules.presets import get_module_preset


def test_module_power_scales_with_irradiance():
    module = get_module_preset("550W")
    p_low = module.power_at(poa_wm2=500.0, cell_temp_c=25.0)
    p_high = module.power_at(poa_wm2=1000.0, cell_temp_c=25.0)
    assert p_high > p_low
    assert abs(p_high - module.nominal_power_w) < 1.0  # STC conditions -> nameplate power


def test_module_power_derates_with_temperature():
    module = get_module_preset("550W")
    p_cool = module.power_at(poa_wm2=1000.0, cell_temp_c=25.0)
    p_hot = module.power_at(poa_wm2=1000.0, cell_temp_c=65.0)
    assert p_hot < p_cool


def test_degradation_factor_monotonically_decreasing():
    module = get_module_preset("550W")
    f1 = module.degradation_factor(1)
    f10 = module.degradation_factor(10)
    f30 = module.degradation_factor(30)
    assert f1 > f10 > f30
    assert 0.0 < f30 < 1.0
