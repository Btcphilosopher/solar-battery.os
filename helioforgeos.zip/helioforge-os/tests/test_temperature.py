import numpy as np

from engine.energy.temperature import cell_temperature_c


def test_cell_temperature_above_ambient_under_irradiance():
    t_cell = cell_temperature_c(poa_wm2=np.array([1000.0]), ambient_temp_c=np.array([25.0]),
                                 wind_speed_ms=np.array([1.0]))
    assert t_cell[0] > 25.0


def test_higher_wind_reduces_module_temperature():
    low_wind = cell_temperature_c(np.array([1000.0]), np.array([25.0]), np.array([0.5]))
    high_wind = cell_temperature_c(np.array([1000.0]), np.array([25.0]), np.array([10.0]))
    assert high_wind[0] < low_wind[0]
