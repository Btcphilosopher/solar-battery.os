from engine.economics.capex import CapexAssumptions, compute_capex
from engine.economics.finance import irr, lcoe, npv, payback_period_years


def test_compute_capex_total_matches_sum_of_breakdown():
    assumptions = CapexAssumptions()
    breakdown = compute_capex(dc_capacity_wp=100_000_000, assumptions=assumptions)
    components = {k: v for k, v in breakdown.items() if k != "total_capex_usd"}
    assert abs(sum(components.values()) - breakdown["total_capex_usd"]) < 1e-6


def test_npv_of_zero_discount_rate_equals_sum():
    cashflows = [-100, 50, 50, 50]
    assert abs(npv(0.0, cashflows) - sum(cashflows)) < 1e-6


def test_irr_recovers_known_rate():
    r = 0.10
    cashflows = [-1000] + [1000 * r] * 5 + [1000]
    # roughly a bond-like cashflow; IRR should be close to r
    result = irr(cashflows)
    assert result is not None
    assert abs(result - r) < 0.02


def test_payback_period_reasonable():
    cashflows = [-1000, 300, 300, 300, 300, 300]
    payback = payback_period_years(cashflows)
    assert payback is not None
    assert 3.0 < payback < 4.0


def test_lcoe_positive():
    value = lcoe(discount_rate_pct=7.0, capex_usd=1_000_000, opex_series_usd=[20_000] * 25,
                 energy_series_mwh=[5000.0] * 25)
    assert value > 0
