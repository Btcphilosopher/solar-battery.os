import numpy as np

from engine.inverters.presets import get_inverter_preset


def test_inverter_clips_above_rated_power():
    inv = get_inverter_preset("1000kW")
    dc_input = np.array([1500.0])  # kW, well above rated AC
    ac_out, clipped = inv.ac_output_kw(dc_input)
    assert ac_out[0] <= inv.rated_ac_power_kw + 1e-6
    assert clipped[0] > 0


def test_inverter_no_clipping_below_rated_power():
    inv = get_inverter_preset("1000kW")
    dc_input = np.array([200.0])
    ac_out, clipped = inv.ac_output_kw(dc_input)
    assert clipped[0] == 0.0
    assert ac_out[0] < dc_input[0]  # some conversion loss expected
