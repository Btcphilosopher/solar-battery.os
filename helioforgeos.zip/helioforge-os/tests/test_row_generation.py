from shapely.geometry import box

from engine.arrays.array_generator import exact_module_count, generate_array
from engine.arrays.row_generator import generate_rows
from engine.modules.presets import get_module_preset


def test_generate_rows_covers_a_square_polygon():
    poly = box(0, 0, 200, 200)
    rows = generate_rows(poly, row_spacing_m=6.0, row_azimuth_deg=180.0)
    assert len(rows) > 0
    for r in rows:
        assert r.usable_length_m > 0


def test_smaller_row_spacing_yields_more_rows():
    poly = box(0, 0, 200, 200)
    wide = generate_rows(poly, row_spacing_m=10.0, row_azimuth_deg=180.0)
    narrow = generate_rows(poly, row_spacing_m=5.0, row_azimuth_deg=180.0)
    assert len(narrow) > len(wide)


def test_array_generator_module_count_positive():
    poly = box(0, 0, 300, 300)
    module = get_module_preset("550W")
    result = generate_array(poly, module, tilt_deg=25.0, azimuth_deg=180.0, row_spacing_m=6.0)
    assert exact_module_count(result.array) > 0
    assert result.array.dc_capacity_w > 0
