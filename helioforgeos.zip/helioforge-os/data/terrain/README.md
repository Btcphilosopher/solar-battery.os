# Terrain data

HELIOFORGE.OS ships with a synthetic DEM generator
(`engine/terrain/dem.py`). Drop real DEM rasters (GeoTIFF via rasterio)
here for site-specific terrain; `DEM.x/y/z` just need to be populated
from the raster grid to swap in real data.
