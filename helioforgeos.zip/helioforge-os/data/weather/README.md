# Weather data

HELIOFORGE.OS ships with a synthetic weather generator
(`engine/weather/synthetic.py`) so it runs with zero external datasets.

Drop real TMY / measured weather CSVs here (timestamp, GHI, DNI, DHI,
ambient temperature, wind speed) and point `EnergyModel` at them to
replace the synthetic profile with measured data — that integration
point is intentionally simple (a DataFrame with the same columns).
