# HELIOFORGE.OS

**Python PV digital twin, field design & optimisation engine.**

HELIOFORGE.OS is a parametric photovoltaic (PV) design, simulation,
digital-twin and optimisation platform. It lets you design anything from
rooftop PV to utility-scale solar fields, and continuously simulates
solar resource, layout, shading, energy generation, grid behaviour and
project economics as a single connected computational engine — not a
collection of static UI values.

> **Central principle:** change the physical PV design → the digital twin
> recalculates the layout → recalculates energy production → recalculates
> grid behaviour → recalculates economics → the optimiser can then search
> for a better design. See `engine/digital_twin/twin.py::recalculate()`.

## Quickstart

```bash
python -m venv .venv && source .venv/bin/activate
pip install -e .
python main.py
```

This builds a synthetic 250-hectare demo field, runs the full
site → terrain → solar resource → layout → shading → energy → grid →
economics chain, and prints a design report. Every number is generated
by the engine at run time.

Run the API:

```bash
pip install -e ".[dev]"
uvicorn api.main:app --reload
```

Run the tests:

```bash
pytest
```

## Architecture

```
                         HELIOFORGE.OS
                                │
       ┌────────────────────────┼────────────────────────┐
       │                        │                        │
    GEOSPATIAL                PV ENGINE               ECONOMICS
       │                        │                        │
       ▼                        ▼                        ▼
    TERRAIN                  IRRADIANCE               CAPEX
    BOUNDARY                 SHADING                  OPEX
    LAND                     MODULES                  REVENUE
    OBSTACLES                INVERTERS                LCOE
       │                     STORAGE                  ROI
       │                        │                        │
       └────────────────────────┼────────────────────────┘
                                ▼
                         DIGITAL TWIN
                                │
                                ▼
                           OPTIMISER
```

Every layer is a separate, independently testable Python package under
`engine/`. `engine/digital_twin/twin.py` is the authoritative state
object every other layer (API, optimiser, reports, visualisation) reads
from and writes to.

```
helioforge-os/
├── engine/           # solar, irradiance, weather, geometry, terrain, shading,
│                      # modules, arrays, inverters, transformers, cables, grid,
│                      # storage, degradation, energy, economics, construction,
│                      # land, optimisation, digital_twin, validation
├── api/               # FastAPI app, async job manager, request/response schemas
├── data/               # generic presets (modules, inverters, tariffs) + dataset drop-in points
├── scenarios/          # named scenario overlays (BASE, HIGH_SOLAR, GRID_LIMITED, ...)
├── reports/            # machine-readable design report + design-comparison generation
├── visualisation/      # 2D field renderer, heatmaps, time-series dashboard
├── tests/               # unit tests for the core physics/finance/optimisation
├── main.py              # `python main.py` demo entry point
└── config.yaml          # all default engineering/commercial assumptions
```

## Optimisation

`engine/optimisation/optimizer.py` provides `PVOptimizer`, a bounded
`scipy.optimize.differential_evolution`-based search over design
variables (tilt, azimuth, row spacing, DC/AC ratio, battery size, ...)
against pluggable objectives: `MAX_CAPACITY`, `MIN_CAPACITY`,
`MAX_ANNUAL_ENERGY`, `MAX_ENERGY_PER_HECTARE`, `MIN_LAND`, `MIN_CAPEX`,
`MIN_LCOE`, `MAX_NPV`, `MAX_IRR`, `MIN_CURTAILMENT`, and a weighted
`BALANCED` multi-objective mode. `engine/optimisation/design_modes.py`
wraps these into the platform's "smart design modes" (minimum PV,
maximum PV, minimum land, maximum land productivity, ...), and
`engine/optimisation/multi_objective.py` generates Pareto-optimal design
fronts.

The optimiser is decoupled from all physics: it calls
`PVDigitalTwin.evaluate(design_overrides) -> metrics`, so any callable
that recomputes the twin can be optimised against.

## Engineering disclaimer

HELIOFORGE.OS is a **design-stage simulation and optimisation tool**. It
is **not** a substitute for:

- site surveys
- structural engineering
- electrical engineering
- planning/permitting review
- environmental assessment
- grid interconnection studies
- fire engineering
- construction design

All physical, electrical and financial models used (irradiance,
shading, thermal, inverter, cable, LCOE/NPV/IRR, etc.) are deliberately
simplified, transparent, and fully configurable — they are suitable for
early-stage design exploration and optimisation, not for final,
certified engineering deliverables. Real-world outputs must be validated
by qualified professionals against project-specific standards before
any construction or investment decision.

## Roadmap hooks

- `engine/digital_twin/time_engine.py` exposes per-timestep field state
  (`LiveFieldState`) for a future animated 3D digital-twin frontend
  (e.g. Kotlin).
- `reports/report_generator.py` and `engine/economics/*` are structured
  for a future R analytics/optimisation layer to consume directly.
