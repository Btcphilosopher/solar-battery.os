"""Digital Elevation Model (DEM) engine.

Represents terrain as an (x, y, z) grid and derives slope/aspect. Includes
a synthetic terrain generator (Perlin-like fractal noise via summed sine
waves + smoothing) so the platform can run without external DEM datasets.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

TERRAIN_PROFILES = {
    "flat":         {"relief_m": 1.5,  "roughness": 1},
    "rolling":      {"relief_m": 8.0,  "roughness": 2},
    "hilly":        {"relief_m": 30.0, "roughness": 3},
    "desert":       {"relief_m": 5.0,  "roughness": 2},
    "agricultural": {"relief_m": 4.0,  "roughness": 1},
    "industrial":   {"relief_m": 1.0,  "roughness": 1},
    "rooftop":      {"relief_m": 0.3,  "roughness": 1},
    "coastal":      {"relief_m": 6.0,  "roughness": 2},
}


@dataclass
class DEM:
    x: np.ndarray  # (ny, nx) meters, local grid
    y: np.ndarray
    z: np.ndarray  # elevation, meters
    cell_size_m: float

    def slope_percent(self) -> np.ndarray:
        dzdy, dzdx = np.gradient(self.z, self.cell_size_m)
        return np.sqrt(dzdx**2 + dzdy**2) * 100.0

    def slope_degrees(self) -> np.ndarray:
        return np.degrees(np.arctan(self.slope_percent() / 100.0))

    def aspect_degrees(self) -> np.ndarray:
        dzdy, dzdx = np.gradient(self.z, self.cell_size_m)
        aspect = np.degrees(np.arctan2(dzdy, -dzdx))
        aspect = (90.0 - aspect) % 360.0
        return aspect

    def elevation_at(self, xq: float, yq: float) -> float:
        ix = int(np.clip(np.searchsorted(self.x[0, :], xq), 0, self.x.shape[1] - 1))
        iy = int(np.clip(np.searchsorted(self.y[:, 0], yq), 0, self.y.shape[0] - 1))
        return float(self.z[iy, ix])

    def unsuitable_mask(self, max_slope_deg: float) -> np.ndarray:
        return self.slope_degrees() > max_slope_deg


def generate_synthetic_dem(width_m: float, height_m: float, profile: str = "flat",
                            cell_size_m: float = 10.0, base_elevation_m: float = 100.0,
                            seed: int = 7) -> DEM:
    params = TERRAIN_PROFILES.get(profile, TERRAIN_PROFILES["flat"])
    nx = max(4, int(width_m / cell_size_m))
    ny = max(4, int(height_m / cell_size_m))
    xs = np.linspace(0, width_m, nx)
    ys = np.linspace(0, height_m, ny)
    x, y = np.meshgrid(xs, ys)

    rng = np.random.default_rng(seed)
    z = np.zeros_like(x)
    n_octaves = 3 + params["roughness"]
    for o in range(n_octaves):
        freq = 2 ** o
        amp = params["relief_m"] / (1.6 ** o)
        phase_x = rng.uniform(0, 2 * np.pi)
        phase_y = rng.uniform(0, 2 * np.pi)
        z += amp * np.sin(2 * np.pi * freq * x / width_m + phase_x) * \
             np.cos(2 * np.pi * freq * y / height_m + phase_y)

    z += rng.normal(0, params["relief_m"] * 0.05, z.shape)
    z += base_elevation_m
    return DEM(x=x, y=y, z=z, cell_size_m=cell_size_m)
