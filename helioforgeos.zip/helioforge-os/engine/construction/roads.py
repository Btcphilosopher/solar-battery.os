"""Access-road network estimation."""
from __future__ import annotations

import math
from dataclasses import dataclass


@dataclass
class RoadConfig:
    road_width_m: float = 6.0
    road_spacing_m: float = 250.0
    road_clearance_m: float = 2.0


def estimate_road_network(site_area_ha: float, config: RoadConfig) -> dict:
    """Rough road-length estimate: a rectilinear grid of access roads at
    ``road_spacing_m`` intervals across the site."""
    side_m = math.sqrt(site_area_ha * 10_000.0)
    n_roads = max(1, int(side_m / config.road_spacing_m))
    total_length_m = n_roads * side_m * 2  # two directions (approx grid)
    road_area_ha = (total_length_m * (config.road_width_m + 2 * config.road_clearance_m)) / 10_000.0
    return {
        "road_length_m": total_length_m,
        "road_width_m": config.road_width_m,
        "road_area_ha": road_area_ha,
    }
