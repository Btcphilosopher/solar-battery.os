"""Conceptual drainage layer: terrain-flow-based drainage corridor
identification. NOT a final civil/hydraulic engineering design."""
from __future__ import annotations

import numpy as np

from engine.terrain.dem import DEM


def identify_low_points(dem: DEM, percentile: float = 10.0) -> np.ndarray:
    """Boolean mask of cells in the lowest ``percentile`` of local elevation
    (proxy for natural drainage sinks / corridors)."""
    threshold = np.percentile(dem.z, percentile)
    return dem.z <= threshold


def flow_direction_aspect(dem: DEM) -> np.ndarray:
    """Aspect (downslope direction, degrees) doubles as an approximate
    flow-direction field for a conceptual drainage layer."""
    return dem.aspect_degrees()


def drainage_summary(dem: DEM) -> dict:
    low = identify_low_points(dem)
    cell_area_ha = (dem.cell_size_m ** 2) / 10_000.0
    return {
        "low_point_area_ha": float(low.sum()) * cell_area_ha,
        "mean_slope_pct": float(np.mean(dem.slope_percent())),
        "note": "Conceptual drainage indication only; not a hydraulic engineering design.",
    }
