"""Perimeter fencing estimation."""
from __future__ import annotations

from shapely.geometry import Polygon


def estimate_fencing(boundary: Polygon, setback_m: float = 5.0, gate_every_m: float = 500.0) -> dict:
    fence_line = boundary.buffer(-setback_m) if setback_m > 0 else boundary
    if fence_line.is_empty:
        fence_line = boundary
    perimeter_m = fence_line.length
    n_gates = max(1, int(perimeter_m / gate_every_m))
    return {
        "fence_length_m": perimeter_m,
        "access_gates": n_gates,
    }
