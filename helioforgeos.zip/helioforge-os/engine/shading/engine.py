"""Shading engine.

Inter-row self-shading uses the standard profile-angle geometric model for
parallel tilted rows (2D approximation in the plane perpendicular to the
row axis). Obstacle shading is handled separately in ``obstacles.py``.
"""
from __future__ import annotations

import numpy as np


def profile_angle_deg(solar_elevation_deg, solar_azimuth_deg, row_azimuth_deg):
    """Solar elevation projected into the plane perpendicular to the rows
    (i.e. the plane containing the row's tilt direction)."""
    delta_az = np.radians(solar_azimuth_deg - row_azimuth_deg)
    elev_r = np.radians(np.clip(solar_elevation_deg, -90, 90))
    with np.errstate(divide="ignore", invalid="ignore"):
        tan_profile = np.tan(elev_r) / np.clip(np.cos(delta_az), 1e-6, None)
    profile = np.degrees(np.arctan(tan_profile))
    # sun behind the array plane (facing away) -> treat as no direct beam contribution
    facing_away = np.cos(delta_az) < 0
    return profile, facing_away


def inter_row_shaded_fraction(solar_elevation_deg, solar_azimuth_deg, row_azimuth_deg,
                               tilt_deg, slant_length_m, pitch_m):
    """Fraction (0-1) of the row's slant length that is shadowed by the
    row in front of it, using the classic pitch/tilt/profile-angle
    geometric relation for infinite parallel rows.
    """
    gamma, facing_away = profile_angle_deg(solar_elevation_deg, solar_azimuth_deg, row_azimuth_deg)
    gamma = np.clip(gamma, 0.0001, 89.9)
    beta_r = np.radians(tilt_deg)
    gamma_r = np.radians(gamma)

    if pitch_m <= 0 or slant_length_m <= 0:
        return np.zeros_like(np.asarray(solar_elevation_deg, dtype=float))

    unshaded_len = (pitch_m * np.sin(gamma_r)) / np.sin(gamma_r + beta_r)
    unshaded_frac = np.clip(unshaded_len / slant_length_m, 0.0, 1.0)
    shaded_frac = 1.0 - unshaded_frac

    below_horizon = np.asarray(solar_elevation_deg) <= 0
    shaded_frac = np.where(below_horizon, 1.0, shaded_frac)
    shaded_frac = np.where(facing_away, 1.0, shaded_frac)
    return np.clip(shaded_frac, 0.0, 1.0)


def apply_shading_to_poa(poa_direct, poa_sky_diffuse, poa_ground_diffuse, shaded_fraction):
    """A simplified but standard treatment: direct beam is fully lost over
    the shaded fraction of the row; diffuse/ground components are only
    partially attenuated (sky-view-factor loss)."""
    direct_after = poa_direct * (1.0 - shaded_fraction)
    diffuse_after = poa_sky_diffuse * (1.0 - 0.5 * shaded_fraction)
    ground_after = poa_ground_diffuse * (1.0 - 0.5 * shaded_fraction)
    return direct_after + diffuse_after + ground_after
