"""Obstacle shadow projection (buildings, trees, hills, towers, structures)."""
from __future__ import annotations

import math
from dataclasses import dataclass

from shapely.affinity import translate
from shapely.geometry import Polygon


@dataclass
class Obstacle:
    obstacle_id: str
    footprint: Polygon    # ground footprint polygon (local x,y meters)
    height_m: float
    kind: str = "building"   # building | tree | hill | tower | structure


def shadow_polygon(obstacle: Obstacle, solar_elevation_deg: float, solar_azimuth_deg: float) -> Polygon | None:
    """Project an obstacle's shadow onto flat ground for a given sun position."""
    if solar_elevation_deg <= 0.1:
        return None
    shadow_length = obstacle.height_m / math.tan(math.radians(max(solar_elevation_deg, 0.1)))
    # shadow points away from the sun
    shadow_az_r = math.radians((solar_azimuth_deg + 180.0) % 360.0)
    dx = shadow_length * math.sin(shadow_az_r)
    dy = shadow_length * math.cos(shadow_az_r)
    projected = translate(obstacle.footprint, xoff=dx, yoff=dy)
    return obstacle.footprint.union(projected).convex_hull


def annual_shade_loss_estimate(obstacle: Obstacle, target_polygon: Polygon,
                                elevations, azimuths) -> float:
    """Rough annual-average fraction of daylight timesteps in which the
    obstacle's shadow overlaps the target polygon (proxy for shade-loss
    hours; a full irradiance-weighted calc is done in the energy model)."""
    hits = 0
    total = 0
    for elev, az in zip(elevations, azimuths):
        if elev <= 0:
            continue
        total += 1
        shp = shadow_polygon(obstacle, elev, az)
        if shp is not None and shp.intersects(target_polygon):
            hits += 1
    return hits / total if total else 0.0
