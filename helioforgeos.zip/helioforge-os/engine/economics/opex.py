"""OPEX model."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class OpexAssumptions:
    maintenance_usd_per_kwp_year: float = 6.0
    cleaning_usd_per_kwp_year: float = 1.5
    vegetation_usd_per_kwp_year: float = 0.8
    insurance_usd_per_kwp_year: float = 1.2
    land_lease_usd_per_ha_year: float = 400.0
    inverter_replacement_year: int = 12
    inverter_replacement_pct_of_capex: float = 0.02
    battery_replacement_year: int | None = None
    battery_replacement_pct_of_capex: float = 0.35

    def annual_recurring_usd(self, dc_capacity_kwp: float, area_ha: float,
                             lease_multiplier: float = 1.0) -> float:
        return (dc_capacity_kwp * (self.maintenance_usd_per_kwp_year + self.cleaning_usd_per_kwp_year
                                    + self.vegetation_usd_per_kwp_year + self.insurance_usd_per_kwp_year)
                + area_ha * self.land_lease_usd_per_ha_year * lease_multiplier)

    def opex_series(self, years: int, dc_capacity_kwp: float, area_ha: float, total_capex_usd: float,
                     battery_capex_usd: float = 0.0, lease_multiplier: float = 1.0,
                     inflation_pct: float = 2.0) -> list[float]:
        base = self.annual_recurring_usd(dc_capacity_kwp, area_ha, lease_multiplier)
        series = []
        for y in range(1, years + 1):
            opex_y = base * (1.0 + inflation_pct / 100.0) ** (y - 1)
            if y == self.inverter_replacement_year:
                opex_y += total_capex_usd * self.inverter_replacement_pct_of_capex
            if self.battery_replacement_year and y == self.battery_replacement_year:
                opex_y += battery_capex_usd * self.battery_replacement_pct_of_capex
            series.append(opex_y)
        return series
