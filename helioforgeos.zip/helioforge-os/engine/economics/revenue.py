"""Revenue model: configurable price / PPA / export tariff structures."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class RevenueAssumptions:
    electricity_price_usd_per_mwh: float = 45.0
    ppa_escalation_pct: float = 1.0
    time_of_use_multiplier: float = 1.0   # >1 if generation skews to high-price hours


def revenue_series(annual_export_mwh_series: list[float], assumptions: RevenueAssumptions) -> list[float]:
    revenues = []
    for y, export_mwh in enumerate(annual_export_mwh_series, start=1):
        price = (assumptions.electricity_price_usd_per_mwh
                 * (1.0 + assumptions.ppa_escalation_pct / 100.0) ** (y - 1)
                 * assumptions.time_of_use_multiplier)
        revenues.append(export_mwh * price)
    return revenues
