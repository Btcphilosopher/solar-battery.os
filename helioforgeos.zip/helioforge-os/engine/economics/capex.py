"""CAPEX model. All unit costs are configurable assumptions, not
authoritative market pricing."""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class CapexAssumptions:
    modules_usd_per_wp: float = 0.18
    mounting_usd_per_wp: float = 0.06
    inverters_usd_per_wp: float = 0.05
    transformers_usd_per_wp: float = 0.02
    cabling_usd_per_wp: float = 0.04
    substation_usd_per_wp: float = 0.02
    civil_works_usd_per_wp: float = 0.05
    roads_usd_per_wp: float = 0.01
    drainage_usd_per_wp: float = 0.01
    labour_usd_per_wp: float = 0.04
    engineering_usd_per_wp: float = 0.02
    development_usd_per_wp: float = 0.03
    battery_usd_per_kwh: float = 220.0

    def total_per_wp(self) -> float:
        return (self.modules_usd_per_wp + self.mounting_usd_per_wp + self.inverters_usd_per_wp
                + self.transformers_usd_per_wp + self.cabling_usd_per_wp + self.substation_usd_per_wp
                + self.civil_works_usd_per_wp + self.roads_usd_per_wp + self.drainage_usd_per_wp
                + self.labour_usd_per_wp + self.engineering_usd_per_wp + self.development_usd_per_wp)


def compute_capex(dc_capacity_wp: float, assumptions: CapexAssumptions,
                   battery_energy_kwh: float = 0.0, cost_multiplier: float = 1.0) -> dict:
    breakdown = {
        "modules": dc_capacity_wp * assumptions.modules_usd_per_wp,
        "mounting": dc_capacity_wp * assumptions.mounting_usd_per_wp,
        "inverters": dc_capacity_wp * assumptions.inverters_usd_per_wp,
        "transformers": dc_capacity_wp * assumptions.transformers_usd_per_wp,
        "cabling": dc_capacity_wp * assumptions.cabling_usd_per_wp,
        "substation": dc_capacity_wp * assumptions.substation_usd_per_wp,
        "civil_works": dc_capacity_wp * assumptions.civil_works_usd_per_wp,
        "roads": dc_capacity_wp * assumptions.roads_usd_per_wp,
        "drainage": dc_capacity_wp * assumptions.drainage_usd_per_wp,
        "labour": dc_capacity_wp * assumptions.labour_usd_per_wp,
        "engineering": dc_capacity_wp * assumptions.engineering_usd_per_wp,
        "development": dc_capacity_wp * assumptions.development_usd_per_wp,
        "battery": battery_energy_kwh * assumptions.battery_usd_per_kwh,
    }
    breakdown = {k: v * cost_multiplier for k, v in breakdown.items()}
    breakdown["total_capex_usd"] = sum(breakdown.values())
    return breakdown
