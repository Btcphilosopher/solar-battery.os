"""Monte Carlo uncertainty analysis for financial/energy outputs."""
from __future__ import annotations

from typing import Callable

import numpy as np
import pandas as pd


def run_monte_carlo(sample_fn: Callable[[np.random.Generator], float], n_samples: int = 500,
                     seed: int = 123) -> dict:
    """``sample_fn`` draws random inputs (via the provided RNG) and returns
    a single metric value (e.g. annual energy, NPV, LCOE) for that draw."""
    rng = np.random.default_rng(seed)
    samples = np.array([sample_fn(rng) for _ in range(n_samples)])
    p10, p50, p90 = np.percentile(samples, [10, 50, 90])
    return {
        "n_samples": n_samples,
        "p10": float(p10),
        "p50": float(p50),
        "p90": float(p90),
        "mean": float(np.mean(samples)),
        "std": float(np.std(samples)),
        "samples": samples,
    }


def default_pv_sample(rng: np.random.Generator, base_capex: float, base_price: float,
                       base_energy_mwh: float, base_degradation_pct: float,
                       base_availability_pct: float = 98.0) -> dict:
    """Draw one Monte Carlo sample of the standard PV uncertainty variables."""
    capex = base_capex * rng.normal(1.0, 0.08)
    price = base_price * rng.normal(1.0, 0.15)
    irradiance_factor = rng.normal(1.0, 0.06)
    degradation_pct = max(0.0, base_degradation_pct * rng.normal(1.0, 0.25))
    availability_pct = np.clip(rng.normal(base_availability_pct, 1.5), 85, 100)
    energy_mwh = base_energy_mwh * irradiance_factor * (availability_pct / base_availability_pct)
    return {
        "capex": capex, "price": price, "energy_mwh": energy_mwh,
        "degradation_pct": degradation_pct, "availability_pct": availability_pct,
    }
