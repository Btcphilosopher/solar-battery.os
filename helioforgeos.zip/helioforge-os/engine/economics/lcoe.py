"""LCOE convenience module (re-exports the core calculation in finance.py)."""
from __future__ import annotations

from engine.economics.finance import lcoe

__all__ = ["lcoe"]
