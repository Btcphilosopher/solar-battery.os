"""Financial scenario presets (power price / CAPEX combinations)."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class FinancialScenario:
    name: str
    price_multiplier: float = 1.0
    capex_multiplier: float = 1.0
    irradiance_multiplier: float = 1.0
    degradation_multiplier: float = 1.0


FINANCIAL_SCENARIOS: dict[str, FinancialScenario] = {
    "BASE": FinancialScenario("BASE"),
    "LOW_POWER_PRICE": FinancialScenario("LOW_POWER_PRICE", price_multiplier=0.75),
    "HIGH_POWER_PRICE": FinancialScenario("HIGH_POWER_PRICE", price_multiplier=1.30),
    "LOW_CAPEX": FinancialScenario("LOW_CAPEX", capex_multiplier=0.85),
    "HIGH_CAPEX": FinancialScenario("HIGH_CAPEX", capex_multiplier=1.20),
    "HIGH_SOLAR": FinancialScenario("HIGH_SOLAR", irradiance_multiplier=1.10),
    "LOW_SOLAR": FinancialScenario("LOW_SOLAR", irradiance_multiplier=0.88),
}
