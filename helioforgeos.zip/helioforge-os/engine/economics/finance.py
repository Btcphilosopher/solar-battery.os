"""Core financial mathematics: NPV, IRR, LCOE, payback — implemented
locally (no numpy_financial dependency) using scipy for IRR root-finding.
"""
from __future__ import annotations

import numpy as np
from scipy.optimize import brentq


def npv(discount_rate_pct: float, cashflows: list[float]) -> float:
    """cashflows[0] is year-0 (typically -CAPEX); cashflows[1:] are years 1..N."""
    r = discount_rate_pct / 100.0
    return sum(cf / (1.0 + r) ** t for t, cf in enumerate(cashflows))


def irr(cashflows: list[float], lower: float = -0.99, upper: float = 5.0) -> float | None:
    """Internal rate of return via root-finding on the NPV function.
    Returns None if no sign change is found in the bracket (no real IRR)."""
    def f(r):
        return sum(cf / (1.0 + r) ** t for t, cf in enumerate(cashflows))
    try:
        f_lo, f_hi = f(lower), f(upper)
        if np.sign(f_lo) == np.sign(f_hi):
            return None
        return brentq(f, lower, upper, xtol=1e-6)
    except (ValueError, ZeroDivisionError):
        return None


def payback_period_years(cashflows: list[float]) -> float | None:
    cumulative = 0.0
    for t, cf in enumerate(cashflows):
        prev = cumulative
        cumulative += cf
        if cumulative >= 0 and t > 0:
            frac = -prev / cf if cf != 0 else 0.0
            return (t - 1) + frac
    return None


def lcoe(discount_rate_pct: float, capex_usd: float, opex_series_usd: list[float],
          energy_series_mwh: list[float]) -> float:
    """Levelised cost of electricity, USD/MWh."""
    r = discount_rate_pct / 100.0
    disc_costs = capex_usd + sum(c / (1.0 + r) ** (t + 1) for t, c in enumerate(opex_series_usd))
    disc_energy = sum(e / (1.0 + r) ** (t + 1) for t, e in enumerate(energy_series_mwh))
    return disc_costs / disc_energy if disc_energy > 0 else float("inf")
