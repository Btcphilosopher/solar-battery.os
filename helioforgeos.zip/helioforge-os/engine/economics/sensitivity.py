"""Sensitivity analysis: perturb one input variable at a time and observe
the effect on a chosen output metric (typically LCOE or NPV)."""
from __future__ import annotations

from typing import Callable

import pandas as pd

DEFAULT_VARIABLES = [
    "capex", "electricity_price", "irradiance", "degradation", "interest_rate",
    "grid_connection", "battery_cost",
]


def run_sensitivity(base_case_fn: Callable[[dict], float], variable: str,
                     perturbations_pct: list[float] = (-20, -10, 0, 10, 20)) -> pd.DataFrame:
    """``base_case_fn`` takes a dict of {variable: multiplier} and returns
    the metric value (e.g. LCOE) for that perturbed scenario."""
    rows = []
    for p in perturbations_pct:
        multiplier = 1.0 + p / 100.0
        value = base_case_fn({variable: multiplier})
        rows.append({"variable": variable, "perturbation_pct": p, "metric_value": value})
    return pd.DataFrame(rows)


def run_full_sensitivity(base_case_fn: Callable[[dict], float],
                          variables: list[str] = DEFAULT_VARIABLES,
                          perturbations_pct: list[float] = (-20, -10, 0, 10, 20)) -> pd.DataFrame:
    frames = [run_sensitivity(base_case_fn, v, perturbations_pct) for v in variables]
    return pd.concat(frames, ignore_index=True)
