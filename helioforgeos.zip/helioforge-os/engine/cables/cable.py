"""Cable sizing / voltage-drop / resistive-loss estimation.

Simplified single-conductor resistive model using configurable copper/
aluminium resistivity. Not a substitute for a full electrical-code cable
sizing study.
"""
from __future__ import annotations

from dataclasses import dataclass

RESISTIVITY_OHM_MM2_PER_M = {
    "copper": 0.0172,
    "aluminium": 0.0282,
}


@dataclass
class CableSpec:
    conductor: str = "copper"       # copper | aluminium
    cross_section_mm2: float = 95.0
    length_m: float = 300.0

    @property
    def resistance_ohm(self) -> float:
        rho = RESISTIVITY_OHM_MM2_PER_M.get(self.conductor, RESISTIVITY_OHM_MM2_PER_M["copper"])
        return rho * self.length_m / self.cross_section_mm2

    def resistive_loss_kw(self, current_a: float) -> float:
        return (current_a ** 2) * self.resistance_ohm / 1000.0

    def voltage_drop_v(self, current_a: float) -> float:
        return current_a * self.resistance_ohm


def estimate_dc_cable_loss_pct(dc_capacity_kw: float, avg_run_length_m: float,
                                system_voltage_v: float = 1500.0, conductor: str = "copper",
                                cross_section_mm2: float = 95.0) -> float:
    """Rough field-average DC cable loss percentage from a representative
    string-to-combiner run length and system voltage."""
    if dc_capacity_kw <= 0:
        return 0.0
    current_a = (dc_capacity_kw * 1000.0) / system_voltage_v
    cable = CableSpec(conductor=conductor, cross_section_mm2=cross_section_mm2, length_m=avg_run_length_m)
    loss_kw = cable.resistive_loss_kw(current_a)
    return 100.0 * loss_kw / dc_capacity_kw


def estimate_ac_cable_loss_pct(ac_capacity_kw: float, avg_run_length_m: float,
                                system_voltage_v: float = 33000.0, conductor: str = "aluminium",
                                cross_section_mm2: float = 240.0) -> float:
    if ac_capacity_kw <= 0:
        return 0.0
    current_a = (ac_capacity_kw * 1000.0) / (system_voltage_v * 1.732)
    cable = CableSpec(conductor=conductor, cross_section_mm2=cross_section_mm2, length_m=avg_run_length_m)
    loss_kw = 3 * cable.resistive_loss_kw(current_a)
    return 100.0 * loss_kw / ac_capacity_kw
