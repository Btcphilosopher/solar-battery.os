"""Battery storage model."""
from __future__ import annotations

from pydantic import BaseModel, Field


class BatteryStorage(BaseModel):
    energy_capacity_mwh: float = Field(gt=0)
    power_capacity_mw: float = Field(gt=0)
    round_trip_efficiency_pct: float = Field(default=90.0)
    depth_of_discharge_pct: float = Field(default=90.0)
    degradation_annual_pct: float = Field(default=2.0)

    @property
    def usable_energy_mwh(self) -> float:
        return self.energy_capacity_mwh * (self.depth_of_discharge_pct / 100.0)

    @property
    def one_way_efficiency(self) -> float:
        return (self.round_trip_efficiency_pct / 100.0) ** 0.5

    def capacity_in_year(self, year: int) -> float:
        return self.energy_capacity_mwh * (1.0 - self.degradation_annual_pct / 100.0) ** max(0, year - 1)
