"""Energy dispatch engine.

A greedy, causally-consistent heuristic dispatch (not a full MILP optimal
dispatch): charge the battery from PV energy that would otherwise be
curtailed above the grid export limit, and discharge to fill export
headroom below the limit when energy is available and SOC allows. This
keeps the annual simulation fast (fully vectorised) while remaining
directionally correct for curtailment-reduction and export-shaping use
cases.
"""
from __future__ import annotations

import numpy as np

from engine.storage.battery import BatteryStorage


def dispatch_timeseries(ac_power_mw: np.ndarray, export_limit_mw: float,
                         battery: BatteryStorage | None, timestep_hours: float,
                         battery_year: int = 1) -> dict:
    n = len(ac_power_mw)
    if battery is None:
        export = np.minimum(ac_power_mw, export_limit_mw)
        curtailed = np.clip(ac_power_mw - export, 0.0, None)
        return {
            "export_mw": export,
            "curtailed_mw": curtailed,
            "battery_charge_mw": np.zeros(n),
            "battery_discharge_mw": np.zeros(n),
            "soc_mwh": np.zeros(n),
        }

    usable_mwh = battery.usable_energy_mwh * (battery.capacity_in_year(battery_year) / battery.energy_capacity_mwh)
    eta = battery.one_way_efficiency
    power_limit = battery.power_capacity_mw

    soc = np.zeros(n)
    charge = np.zeros(n)
    discharge = np.zeros(n)
    export = np.zeros(n)
    curtailed = np.zeros(n)

    soc_prev = usable_mwh * 0.2  # start at 20% SOC
    for t in range(n):
        p = ac_power_mw[t]
        headroom = max(0.0, export_limit_mw - p)
        surplus = max(0.0, p - export_limit_mw)

        # 1) charge from surplus above export limit (curtailment avoidance)
        charge_power = min(surplus, power_limit)
        energy_room = (usable_mwh - soc_prev) / max(eta, 1e-6)
        charge_power = min(charge_power, energy_room / timestep_hours) if timestep_hours > 0 else 0.0
        charge_power = max(charge_power, 0.0)
        soc_new = soc_prev + charge_power * eta * timestep_hours
        remaining_surplus = surplus - charge_power

        # 2) discharge to fill export headroom (revenue / export shaping)
        discharge_power = min(headroom, power_limit)
        available_energy = soc_new / max(eta, 1e-6)
        discharge_power = min(discharge_power, available_energy / timestep_hours) if timestep_hours > 0 else 0.0
        discharge_power = max(discharge_power, 0.0)
        soc_new = soc_new - discharge_power / max(eta, 1e-6) * timestep_hours
        soc_new = np.clip(soc_new, 0.0, usable_mwh)

        export_t = min(p, export_limit_mw) + discharge_power
        export_t = min(export_t, export_limit_mw + 1e-9) if headroom <= 0 else export_t
        curtailed_t = max(0.0, remaining_surplus)

        charge[t] = charge_power
        discharge[t] = discharge_power
        soc[t] = soc_new
        export[t] = min(export_t, export_limit_mw)
        curtailed[t] = curtailed_t
        soc_prev = soc_new

    return {
        "export_mw": export,
        "curtailed_mw": curtailed,
        "battery_charge_mw": charge,
        "battery_discharge_mw": discharge,
        "soc_mwh": soc,
    }
