"""Physical geometry of a single PV module instance.

This is the elementary spatial object that shading, land-use and
construction calculations key off. Bulk arrays reference a
``ModuleGeometry`` template plus a grid transform rather than
instantiating millions of individual objects (kept fast + memory-light).
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class ModuleGeometry:
    x: float               # local easting, m (row/array reference point)
    y: float                # local northing, m
    z: float                # elevation at base, m
    width_m: float           # module width (portrait short edge)
    height_m: float          # module height / slant length (long edge)
    tilt_deg: float
    azimuth_deg: float       # surface azimuth, 0=N, 90=E, 180=S, 270=W
    row_id: int = 0
    col_id: int = 0

    @property
    def footprint_area_m2(self) -> float:
        """Ground footprint (horizontal projection), not panel surface area."""
        import math
        return self.width_m * self.height_m * math.cos(math.radians(self.tilt_deg))

    @property
    def panel_area_m2(self) -> float:
        return self.width_m * self.height_m

    def corners_xy(self):
        """Approximate horizontal-plane footprint corners (rectangle)."""
        import math
        hw = self.width_m / 2.0
        hh = (self.height_m * math.cos(math.radians(self.tilt_deg))) / 2.0
        az = math.radians(self.azimuth_deg)
        # rotate a local rectangle by the row azimuth
        pts_local = [(-hw, -hh), (hw, -hh), (hw, hh), (-hw, hh)]
        pts = []
        for lx, ly in pts_local:
            gx = self.x + lx * math.cos(az) - ly * math.sin(az)
            gy = self.y + lx * math.sin(az) + ly * math.cos(az)
            pts.append((gx, gy))
        return pts
