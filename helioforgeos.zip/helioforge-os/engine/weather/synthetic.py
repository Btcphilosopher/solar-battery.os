"""Synthetic weather generator.

Produces a physically plausible ambient-temperature and clearness-index
(cloud-cover) time series when no external weather dataset is supplied,
so the simulator can run end-to-end for any synthetic site. Seeded for
reproducibility.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

CLIMATE_PROFILES = {
    "desert":       {"t_mean": 24.0, "t_amp_annual": 14.0, "t_amp_daily": 14.0, "kt_mean": 0.72, "kt_std": 0.08, "wind_mean": 3.0},
    "coastal":      {"t_mean": 17.0, "t_amp_annual": 7.0,  "t_amp_daily": 6.0,  "kt_mean": 0.58, "kt_std": 0.14, "wind_mean": 5.0},
    "temperate":    {"t_mean": 12.0, "t_amp_annual": 10.0, "t_amp_daily": 8.0,  "kt_mean": 0.52, "kt_std": 0.16, "wind_mean": 3.5},
    "agricultural": {"t_mean": 15.0, "t_amp_annual": 11.0, "t_amp_daily": 9.0,  "kt_mean": 0.55, "kt_std": 0.15, "wind_mean": 3.2},
    "industrial":   {"t_mean": 14.0, "t_amp_annual": 10.0, "t_amp_daily": 8.0,  "kt_mean": 0.50, "kt_std": 0.16, "wind_mean": 3.0},
    "rooftop":      {"t_mean": 14.0, "t_amp_annual": 10.0, "t_amp_daily": 8.0,  "kt_mean": 0.50, "kt_std": 0.16, "wind_mean": 2.5},
    "flat":         {"t_mean": 16.0, "t_amp_annual": 10.0, "t_amp_daily": 8.0,  "kt_mean": 0.56, "kt_std": 0.14, "wind_mean": 3.5},
    "rolling":      {"t_mean": 15.0, "t_amp_annual": 10.0, "t_amp_daily": 8.0,  "kt_mean": 0.55, "kt_std": 0.15, "wind_mean": 3.5},
    "hilly":        {"t_mean": 13.0, "t_amp_annual": 11.0, "t_amp_daily": 9.0,  "kt_mean": 0.53, "kt_std": 0.16, "wind_mean": 4.0},
}


def generate_synthetic_weather(timestamps: pd.DatetimeIndex, latitude: float,
                                climate: str = "flat", seed: int = 42) -> pd.DataFrame:
    """Return a DataFrame indexed by timestamp with columns:
    ambient_temp_c, wind_speed_ms, clearness_index (kt, 0-1).
    """
    profile = CLIMATE_PROFILES.get(climate, CLIMATE_PROFILES["flat"])
    rng = np.random.default_rng(seed)
    n = len(timestamps)
    doy = timestamps.dayofyear.to_numpy(dtype=float)
    hour = timestamps.hour.to_numpy(dtype=float) + timestamps.minute.to_numpy(dtype=float) / 60.0

    # southern/northern hemisphere phase shift for annual cycle
    phase = 0.0 if latitude >= 0 else np.pi
    annual = np.sin(2 * np.pi * (doy - 81) / 365.0 + phase)
    daily = -np.cos(2 * np.pi * (hour - 6) / 24.0)

    temp_noise = rng.normal(0, 1.5, n)
    temp = profile["t_mean"] + profile["t_amp_annual"] * annual + profile["t_amp_daily"] * 0.5 * daily + temp_noise

    wind = np.clip(rng.gamma(shape=2.0, scale=profile["wind_mean"] / 2.0, size=n), 0.2, 25.0)

    # autocorrelated cloud/clearness process (AR(1)) per-day, broadcast to timesteps
    n_days = int(np.ceil((timestamps[-1] - timestamps[0]).total_seconds() / 86400)) + 2
    day_kt = np.clip(rng.normal(profile["kt_mean"], profile["kt_std"], n_days), 0.05, 0.85)
    phi = 0.7
    for i in range(1, n_days):
        day_kt[i] = phi * day_kt[i - 1] + (1 - phi) * day_kt[i] + rng.normal(0, profile["kt_std"] * 0.2)
    day_kt = np.clip(day_kt, 0.05, 0.85)
    day_index = (timestamps - timestamps[0]).days.to_numpy()
    kt = day_kt[day_index] * (0.92 + 0.16 * rng.random(n))  # intra-day scatter
    kt = np.clip(kt, 0.03, 0.88)

    return pd.DataFrame({
        "timestamp": timestamps,
        "ambient_temp_c": temp,
        "wind_speed_ms": wind,
        "clearness_index": kt,
    })
