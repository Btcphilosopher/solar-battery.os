"""Inverter model: efficiency curve, DC/AC ratio, clipping."""
from __future__ import annotations

import numpy as np
from pydantic import BaseModel, Field


class Inverter(BaseModel):
    name: str
    rated_ac_power_kw: float = Field(gt=0)
    max_dc_power_kw: float | None = None
    max_dc_voltage_v: float = 1500.0
    max_dc_current_a: float = 4000.0
    mppt_inputs: int = 12
    euro_efficiency_pct: float = 98.6      # weighted "Euro efficiency"
    min_load_pct_for_curve: float = 2.0

    def efficiency_at_loading(self, loading_fraction: np.ndarray) -> np.ndarray:
        """Simplified efficiency curve: low at very low loading, plateaus
        near the Euro-efficiency value, slight droop at high loading."""
        loading = np.clip(loading_fraction, 0.0, 1.5)
        eff = self.euro_efficiency_pct / 100.0 * (1.0 - np.exp(-8.0 * np.clip(loading, 1e-4, None)))
        eff = np.where(loading < self.min_load_pct_for_curve / 100.0, 0.0, eff)
        eff = np.minimum(eff, self.euro_efficiency_pct / 100.0)
        return eff

    def ac_output_kw(self, dc_input_kw: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """Return (ac_output_kw, clipped_dc_kw). Clipping occurs when the
        pre-clip AC would exceed the inverter's rated AC power."""
        loading = dc_input_kw / self.rated_ac_power_kw
        eff = self.efficiency_at_loading(loading)
        ac_unclipped = dc_input_kw * eff
        ac_output = np.minimum(ac_unclipped, self.rated_ac_power_kw)
        clipped_kw = np.clip(ac_unclipped - ac_output, 0.0, None)
        return ac_output, clipped_kw


def dc_ac_ratio(dc_capacity_kw: float, ac_capacity_kw: float) -> float:
    if ac_capacity_kw <= 0:
        return float("nan")
    return dc_capacity_kw / ac_capacity_kw


def required_inverter_count(dc_capacity_kw: float, inverter: Inverter, dc_ac_ratio_target: float) -> int:
    target_ac_kw = dc_capacity_kw / dc_ac_ratio_target
    return max(1, int(round(target_ac_kw / inverter.rated_ac_power_kw)))
