"""Generic string/central inverter presets."""
from __future__ import annotations

from .inverter import Inverter

_PRESETS = {
    "100kW":   dict(rated_ac_power_kw=100,   max_dc_voltage_v=1000, max_dc_current_a=250, mppt_inputs=6),
    "250kW":   dict(rated_ac_power_kw=250,   max_dc_voltage_v=1000, max_dc_current_a=550, mppt_inputs=8),
    "1000kW":  dict(rated_ac_power_kw=1000,  max_dc_voltage_v=1500, max_dc_current_a=2200, mppt_inputs=10),
    "2500kW":  dict(rated_ac_power_kw=2500,  max_dc_voltage_v=1500, max_dc_current_a=4200, mppt_inputs=12),
    "5000kW":  dict(rated_ac_power_kw=5000,  max_dc_voltage_v=1500, max_dc_current_a=8000, mppt_inputs=16),
}


def get_inverter_preset(name: str) -> Inverter:
    if name not in _PRESETS:
        raise KeyError(f"Unknown inverter preset '{name}'. Available: {list(_PRESETS)}")
    return Inverter(name=f"Generic {name}", **_PRESETS[name])


def list_inverter_presets() -> list[str]:
    return list(_PRESETS)
