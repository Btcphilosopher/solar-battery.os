"""engine.solar package."""
