"""Solar position engine.

Vectorised implementation of the Spencer (1971) Fourier-series solar
declination / equation-of-time approximation combined with the standard
hour-angle solar-position equations. Accurate to a few hundredths of a
degree, which is well within the tolerance needed for PV energy yield
simulation (this is NOT a certified ephemeris/astronomical tool).
"""
from __future__ import annotations

import numpy as np
import pandas as pd


class SolarPositionResult:
    def __init__(self, timestamps, elevation, zenith, azimuth, declination,
                 hour_angle, day_length_hours):
        self.timestamps = timestamps
        self.elevation_deg = elevation
        self.zenith_deg = zenith
        self.azimuth_deg = azimuth
        self.declination_deg = declination
        self.hour_angle_deg = hour_angle
        self.day_length_hours = day_length_hours

    def to_frame(self) -> pd.DataFrame:
        return pd.DataFrame({
            "timestamp": self.timestamps,
            "elevation_deg": self.elevation_deg,
            "zenith_deg": self.zenith_deg,
            "azimuth_deg": self.azimuth_deg,
            "declination_deg": self.declination_deg,
            "hour_angle_deg": self.hour_angle_deg,
        })


def _day_angle(day_of_year: np.ndarray) -> np.ndarray:
    return 2.0 * np.pi * (day_of_year - 1) / 365.0


def solar_declination_deg(day_of_year: np.ndarray) -> np.ndarray:
    """Spencer (1971) Fourier series for solar declination, in degrees."""
    g = _day_angle(day_of_year)
    decl_rad = (
        0.006918
        - 0.399912 * np.cos(g) + 0.070257 * np.sin(g)
        - 0.006758 * np.cos(2 * g) + 0.000907 * np.sin(2 * g)
        - 0.002697 * np.cos(3 * g) + 0.00148 * np.sin(3 * g)
    )
    return np.degrees(decl_rad)


def equation_of_time_minutes(day_of_year: np.ndarray) -> np.ndarray:
    """Spencer (1971) equation of time, in minutes."""
    g = _day_angle(day_of_year)
    eot = 229.18 * (
        0.000075
        + 0.001868 * np.cos(g) - 0.032077 * np.sin(g)
        - 0.014615 * np.cos(2 * g) - 0.040849 * np.sin(2 * g)
    )
    return eot


def solar_position(timestamps: pd.DatetimeIndex, latitude: float, longitude: float,
                    timezone_offset_hours: float = 0.0) -> SolarPositionResult:
    """Compute solar position for a series of naive/local timestamps.

    ``timestamps`` are interpreted as local standard time at
    ``timezone_offset_hours`` east of UTC. Longitude is used for the
    solar-time correction, latitude for elevation/azimuth.
    """
    ts = pd.DatetimeIndex(timestamps)
    doy = ts.dayofyear.to_numpy(dtype=float)
    hour_local = ts.hour.to_numpy(dtype=float) + ts.minute.to_numpy(dtype=float) / 60.0

    decl = solar_declination_deg(doy)
    eot = equation_of_time_minutes(doy)

    # local standard time meridian
    lstm = 15.0 * timezone_offset_hours
    time_correction_min = 4.0 * (longitude - lstm) + eot
    solar_time = hour_local + time_correction_min / 60.0
    hour_angle = 15.0 * (solar_time - 12.0)  # degrees, 0 at solar noon

    lat_r = np.radians(latitude)
    decl_r = np.radians(decl)
    ha_r = np.radians(hour_angle)

    sin_elev = (np.sin(lat_r) * np.sin(decl_r)
                + np.cos(lat_r) * np.cos(decl_r) * np.cos(ha_r))
    sin_elev = np.clip(sin_elev, -1.0, 1.0)
    elevation = np.degrees(np.arcsin(sin_elev))
    zenith = 90.0 - elevation

    cos_zen_r = np.radians(zenith)
    denom = np.cos(lat_r) * np.sin(np.radians(zenith))
    denom = np.where(np.abs(denom) < 1e-9, 1e-9, denom)
    cos_az = (np.sin(decl_r) - np.sin(lat_r) * np.cos(np.radians(zenith))) / denom
    cos_az = np.clip(cos_az, -1.0, 1.0)
    azimuth = np.degrees(np.arccos(cos_az))
    azimuth = np.where(hour_angle > 0, 360.0 - azimuth, azimuth)

    day_length = (2.0 / 15.0) * np.degrees(
        np.arccos(np.clip(-np.tan(lat_r) * np.tan(decl_r), -1.0, 1.0))
    )

    return SolarPositionResult(ts, elevation, zenith, azimuth, decl, hour_angle, day_length)
