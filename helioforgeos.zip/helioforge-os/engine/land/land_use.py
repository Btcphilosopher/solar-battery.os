"""Land-use assumptions that affect land availability and cost baselines."""
from __future__ import annotations

LAND_USE_FACTORS = {
    # buildability_factor: extra derate applied on top of the geometric usable
    # area to account for typical practical constraints of that land type.
    "industrial":   {"buildability_factor": 0.97, "lease_multiplier": 1.3},
    "brownfield":   {"buildability_factor": 0.90, "lease_multiplier": 1.1},
    "agricultural": {"buildability_factor": 0.93, "lease_multiplier": 1.0},
    "desert":       {"buildability_factor": 0.95, "lease_multiplier": 0.6},
    "grassland":    {"buildability_factor": 0.96, "lease_multiplier": 0.9},
}


def buildable_area_ha(available_pv_area_ha: float, land_use: str) -> float:
    factor = LAND_USE_FACTORS.get(land_use, {"buildability_factor": 0.95})["buildability_factor"]
    return available_pv_area_ha * factor


def lease_cost_multiplier(land_use: str) -> float:
    return LAND_USE_FACTORS.get(land_use, {"lease_multiplier": 1.0})["lease_multiplier"]
