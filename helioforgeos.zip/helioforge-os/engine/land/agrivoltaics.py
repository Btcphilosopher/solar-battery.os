"""Agrivoltaic mode: elevated PV over active cropland.

Increases panel height and row spacing to preserve crop access/light, and
reports dual land-use metrics (PV capacity alongside retained crop area).
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class AgrivoltaicConfig:
    panel_height_m: float = 3.0        # ground clearance under the array
    row_spacing_multiplier: float = 1.4  # extra pitch vs standard ground-mount, for light access
    crop_light_transmission_target_pct: float = 60.0  # target % of ambient light reaching crops


def adjusted_row_spacing_m(base_row_spacing_m: float, config: AgrivoltaicConfig) -> float:
    return base_row_spacing_m * config.row_spacing_multiplier


def land_utilisation_summary(pv_capacity_kw: float, total_area_ha: float,
                              crop_area_ha: float) -> dict:
    return {
        "pv_capacity_mw": pv_capacity_kw / 1000.0,
        "total_area_ha": total_area_ha,
        "crop_area_retained_ha": crop_area_ha,
        "dual_use_land_efficiency_pct": 100.0 * crop_area_ha / total_area_ha if total_area_ha else 0.0,
        "pv_density_kw_per_ha": pv_capacity_kw / total_area_ha if total_area_ha else 0.0,
    }
