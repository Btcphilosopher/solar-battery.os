"""PVSite: the site/land model."""
from __future__ import annotations

from dataclasses import dataclass, field

from shapely.geometry import Polygon, shape

from engine.terrain.dem import DEM


@dataclass
class PVSite:
    site_id: str
    name: str
    boundary: Polygon                 # local metric coordinates (x, y), meters
    latitude: float
    longitude: float
    elevation_m: float = 0.0
    terrain: DEM | None = None
    obstacles: list = field(default_factory=list)
    land_use: str = "industrial"      # industrial | agricultural | brownfield | desert | grassland

    @property
    def area_m2(self) -> float:
        return self.boundary.area

    @property
    def area_hectares(self) -> float:
        return self.area_m2 / 10_000.0

    @classmethod
    def from_geojson(cls, site_id: str, name: str, geojson_geometry: dict,
                      latitude: float, longitude: float, **kwargs) -> "PVSite":
        poly = shape(geojson_geometry)
        return cls(site_id=site_id, name=name, boundary=poly, latitude=latitude,
                   longitude=longitude, **kwargs)

    @classmethod
    def from_rectangle(cls, site_id: str, name: str, width_m: float, height_m: float,
                        latitude: float, longitude: float, **kwargs) -> "PVSite":
        poly = Polygon([(0, 0), (width_m, 0), (width_m, height_m), (0, height_m)])
        return cls(site_id=site_id, name=name, boundary=poly, latitude=latitude,
                   longitude=longitude, **kwargs)

    @classmethod
    def from_coordinates(cls, site_id: str, name: str, coords: list[tuple[float, float]],
                          latitude: float, longitude: float, **kwargs) -> "PVSite":
        poly = Polygon(coords)
        return cls(site_id=site_id, name=name, boundary=poly, latitude=latitude,
                   longitude=longitude, **kwargs)
