"""Rooftop mode: layout generation constrained to a roof polygon."""
from __future__ import annotations

from dataclasses import dataclass

from shapely.geometry import Polygon


@dataclass
class RoofConfig:
    roof_polygon: Polygon
    roof_obstacles: list        # list[Polygon] (vents, HVAC, skylights)
    roof_pitch_deg: float = 10.0
    roof_orientation_deg: float = 180.0
    setback_m: float = 1.0


def usable_roof_polygon(config: RoofConfig) -> Polygon:
    poly = config.roof_polygon.buffer(-config.setback_m)
    for obs in config.roof_obstacles:
        poly = poly.difference(obs.buffer(0.5))
    return poly if not poly.is_empty else config.roof_polygon


def recommended_tilt_azimuth(config: RoofConfig) -> tuple[float, float]:
    """For pitched roofs, follow the roof plane; for flat roofs (<5 deg),
    recommend a standard tilted racking angle for the site latitude band."""
    if config.roof_pitch_deg < 5.0:
        return 10.0, 180.0
    return config.roof_pitch_deg, config.roof_orientation_deg
