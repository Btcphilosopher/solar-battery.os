"""Solar car park / canopy mode."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class CarParkConfig:
    n_parking_bays: int
    bay_width_m: float = 2.7
    bay_length_m: float = 5.4
    canopy_height_m: float = 2.5
    coverage_pct: float = 100.0     # % of bays with PV canopy over them


def canopy_footprint_ha(config: CarParkConfig) -> float:
    bay_area_m2 = config.bay_width_m * config.bay_length_m
    covered_bays = config.n_parking_bays * (config.coverage_pct / 100.0)
    return (covered_bays * bay_area_m2) / 10_000.0


def estimated_pv_capacity_kw(config: CarParkConfig, module_power_w: float = 550.0,
                              modules_per_bay: float = 3.0) -> float:
    covered_bays = config.n_parking_bays * (config.coverage_pct / 100.0)
    return covered_bays * modules_per_bay * module_power_w / 1000.0
