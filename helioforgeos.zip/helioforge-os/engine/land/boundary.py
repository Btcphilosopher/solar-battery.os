"""Land boundary / usable-area calculations.

Splits total site area into: setback loss, obstacle exclusion, roads,
drainage, equipment zones, and the remaining net PV-buildable polygon.
"""
from __future__ import annotations

from dataclasses import dataclass

from shapely.geometry import Polygon

from engine.land.site import PVSite


@dataclass
class LandBreakdown:
    total_area_ha: float
    setback_loss_ha: float
    obstacle_loss_ha: float
    slope_exclusion_ha: float
    road_area_ha: float
    drainage_area_ha: float
    equipment_area_ha: float
    available_pv_area_ha: float
    usable_polygon: Polygon

    @property
    def non_pv_area_ha(self) -> float:
        return self.total_area_ha - self.available_pv_area_ha

    def to_dict(self) -> dict:
        return {
            "total_site_ha": round(self.total_area_ha, 3),
            "setback_loss_ha": round(self.setback_loss_ha, 3),
            "obstacle_loss_ha": round(self.obstacle_loss_ha, 3),
            "slope_exclusion_ha": round(self.slope_exclusion_ha, 3),
            "road_area_ha": round(self.road_area_ha, 3),
            "drainage_area_ha": round(self.drainage_area_ha, 3),
            "equipment_area_ha": round(self.equipment_area_ha, 3),
            "available_pv_land_ha": round(self.available_pv_area_ha, 3),
            "non_pv_land_ha": round(self.non_pv_area_ha, 3),
        }


def compute_land_breakdown(site: PVSite, setback_m: float = 10.0, max_slope_deg: float = 15.0,
                            road_fraction: float = 0.04, drainage_fraction: float = 0.02,
                            equipment_fraction: float = 0.015) -> LandBreakdown:
    total_area_ha = site.area_hectares

    setback_poly = site.boundary.buffer(-setback_m) if setback_m > 0 else site.boundary
    if setback_poly.is_empty:
        setback_poly = site.boundary
    setback_loss_ha = (site.boundary.area - setback_poly.area) / 10_000.0

    poly_after_obstacles = setback_poly
    for obs in site.obstacles:
        poly_after_obstacles = poly_after_obstacles.difference(obs.footprint.buffer(2.0))
    obstacle_loss_ha = (setback_poly.area - poly_after_obstacles.area) / 10_000.0

    slope_exclusion_ha = 0.0
    if site.terrain is not None:
        mask = site.terrain.unsuitable_mask(max_slope_deg)
        cell_area_ha = (site.terrain.cell_size_m ** 2) / 10_000.0
        slope_exclusion_ha = float(mask.sum()) * cell_area_ha
        # cap so we never claim to exclude more than what remains
        remaining_ha = poly_after_obstacles.area / 10_000.0
        slope_exclusion_ha = min(slope_exclusion_ha, remaining_ha * 0.5)

    remaining_after_slope_ha = max(0.0, poly_after_obstacles.area / 10_000.0 - slope_exclusion_ha)
    remaining_poly = poly_after_obstacles.buffer(-max(0.0, (slope_exclusion_ha / max(remaining_after_slope_ha, 1e-6)) * 0.0))

    road_area_ha = remaining_after_slope_ha * road_fraction
    drainage_area_ha = remaining_after_slope_ha * drainage_fraction
    equipment_area_ha = remaining_after_slope_ha * equipment_fraction

    infra_fraction = road_fraction + drainage_fraction + equipment_fraction
    usable_polygon = remaining_poly.buffer(-_equivalent_ring_width(remaining_poly, infra_fraction))
    if usable_polygon.is_empty:
        usable_polygon = remaining_poly

    available_pv_area_ha = usable_polygon.area / 10_000.0

    return LandBreakdown(
        total_area_ha=total_area_ha,
        setback_loss_ha=setback_loss_ha,
        obstacle_loss_ha=obstacle_loss_ha,
        slope_exclusion_ha=slope_exclusion_ha,
        road_area_ha=road_area_ha,
        drainage_area_ha=drainage_area_ha,
        equipment_area_ha=equipment_area_ha,
        available_pv_area_ha=available_pv_area_ha,
        usable_polygon=usable_polygon,
    )


def _equivalent_ring_width(poly: Polygon, area_fraction: float) -> float:
    """Approximate inward-buffer distance that removes ``area_fraction`` of
    a polygon's area (used as a simple proxy for internal road/drainage/
    equipment-zone consumption of usable land)."""
    if poly.is_empty or area_fraction <= 0:
        return 0.0
    perimeter = poly.length
    area = poly.area
    if perimeter <= 0:
        return 0.0
    return min((area_fraction * area) / perimeter, (area / perimeter) * 0.5)
