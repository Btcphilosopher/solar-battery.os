"""Synthetic site generator: build a PVSite + terrain + obstacles from a
land-area target and a named terrain profile, no external dataset needed.
"""
from __future__ import annotations

import math

import numpy as np
from shapely.geometry import Polygon, box

from engine.land.site import PVSite
from engine.shading.obstacles import Obstacle
from engine.terrain.dem import generate_synthetic_dem

PROFILES = ["flat", "rolling", "hilly", "desert", "agricultural", "industrial", "rooftop", "coastal"]


def generate_synthetic_site(site_id: str, name: str, area_hectares: float, profile: str = "flat",
                             latitude: float = 37.5, longitude: float = -5.0,
                             elevation_m: float = 100.0, aspect_ratio: float = 1.4,
                             obstacle_density: str = "low", seed: int = 11) -> PVSite:
    if profile not in PROFILES:
        raise ValueError(f"Unknown terrain profile '{profile}'. Choose from {PROFILES}")

    area_m2 = area_hectares * 10_000.0
    height_m = math.sqrt(area_m2 / aspect_ratio)
    width_m = area_m2 / height_m

    rng = np.random.default_rng(seed)
    # add a mild irregular boundary (non-rectangular, more realistic than a perfect box)
    base = box(0, 0, width_m, height_m)
    n_notches = {"low": 0, "medium": 1, "high": 2}.get(obstacle_density, 0)
    boundary = base
    for _ in range(n_notches):
        nx = rng.uniform(0.15, 0.85) * width_m
        ny = rng.uniform(0.15, 0.85) * height_m
        nw = rng.uniform(0.08, 0.18) * width_m
        nh = rng.uniform(0.08, 0.18) * height_m
        notch = box(nx, ny, nx + nw, ny + nh)
        boundary = boundary.difference(notch)

    dem = generate_synthetic_dem(width_m, height_m, profile=profile,
                                  cell_size_m=max(5.0, min(width_m, height_m) / 40),
                                  base_elevation_m=elevation_m, seed=seed)

    n_obstacles = {"low": 1, "medium": 3, "high": 6}.get(obstacle_density, 1)
    obstacles = []
    for i in range(n_obstacles):
        ox = rng.uniform(0.1, 0.9) * width_m
        oy = rng.uniform(0.1, 0.9) * height_m
        size = rng.uniform(15, 40)
        height = rng.uniform(4, 15) if profile != "rooftop" else rng.uniform(0.5, 2.0)
        footprint = box(ox, oy, ox + size, oy + size)
        obstacles.append(Obstacle(obstacle_id=f"OBS-{i+1}", footprint=footprint,
                                   height_m=height, kind="structure"))

    land_use_map = {
        "flat": "grassland", "rolling": "grassland", "hilly": "grassland",
        "desert": "desert", "agricultural": "agricultural", "industrial": "brownfield",
        "rooftop": "industrial", "coastal": "grassland",
    }

    return PVSite(site_id=site_id, name=name, boundary=boundary, latitude=latitude,
                  longitude=longitude, elevation_m=elevation_m, terrain=dem,
                  obstacles=obstacles, land_use=land_use_map.get(profile, "grassland"))
