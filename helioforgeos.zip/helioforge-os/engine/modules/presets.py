"""Generic PV module presets by nameplate wattage class.

These are representative generic parameters for common bifacial mono-PERC
/ TOPCon-class utility modules circa the mid-2020s, NOT any specific
manufacturer's datasheet. All values are configurable/overridable.
"""
from __future__ import annotations

from .pv_module import PVModule

_PRESET_DEFS = {
    "400W": dict(width_m=1.045, height_m=1.7,  nominal_power_w=400, efficiency_pct=19.5,
                 voltage_voc_v=41.0, voltage_vmp_v=34.0, current_isc_a=12.4, current_imp_a=11.8),
    "450W": dict(width_m=1.13,  height_m=2.09, nominal_power_w=450, efficiency_pct=20.0,
                 voltage_voc_v=42.0, voltage_vmp_v=35.0, current_isc_a=13.2, current_imp_a=12.8),
    "500W": dict(width_m=1.13,  height_m=2.28, nominal_power_w=500, efficiency_pct=20.5,
                 voltage_voc_v=45.0, voltage_vmp_v=37.5, current_isc_a=13.9, current_imp_a=13.3),
    "550W": dict(width_m=1.134, height_m=2.278, nominal_power_w=550, efficiency_pct=21.3,
                 voltage_voc_v=49.5, voltage_vmp_v=41.5, current_isc_a=14.0, current_imp_a=13.2),
    "600W": dict(width_m=1.303, height_m=2.384, nominal_power_w=600, efficiency_pct=21.8,
                 voltage_voc_v=52.0, voltage_vmp_v=43.5, current_isc_a=14.6, current_imp_a=13.8),
    "700W": dict(width_m=1.303, height_m=2.60,  nominal_power_w=700, efficiency_pct=22.3,
                 voltage_voc_v=54.0, voltage_vmp_v=45.5, current_isc_a=16.0, current_imp_a=15.4),
}


def get_module_preset(name: str) -> PVModule:
    if name not in _PRESET_DEFS:
        raise KeyError(f"Unknown module preset '{name}'. Available: {list(_PRESET_DEFS)}")
    d = _PRESET_DEFS[name]
    return PVModule(name=f"Generic {name}", **d)


def list_module_presets() -> list[str]:
    return list(_PRESET_DEFS)
