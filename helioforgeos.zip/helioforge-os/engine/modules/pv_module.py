"""Generic PV module model (technology-agnostic, no manufacturer data)."""
from __future__ import annotations

from pydantic import BaseModel, Field


class PVModule(BaseModel):
    name: str
    width_m: float = Field(gt=0)
    height_m: float = Field(gt=0)
    nominal_power_w: float = Field(gt=0)
    efficiency_pct: float = Field(gt=0, le=30)
    temperature_coefficient_pct_per_c: float = Field(default=-0.35)
    voltage_voc_v: float = Field(default=49.5)
    voltage_vmp_v: float = Field(default=41.5)
    current_isc_a: float = Field(default=14.0)
    current_imp_a: float = Field(default=13.2)
    degradation_year1_pct: float = Field(default=2.0)
    degradation_annual_pct: float = Field(default=0.5)
    noct_c: float = Field(default=45.0)

    @property
    def area_m2(self) -> float:
        return self.width_m * self.height_m

    @property
    def stc_efficiency_fraction(self) -> float:
        return self.efficiency_pct / 100.0

    def power_at(self, poa_wm2: float, cell_temp_c: float) -> float:
        """DC power (W) at given plane-of-array irradiance and cell temperature."""
        temp_factor = 1.0 + (self.temperature_coefficient_pct_per_c / 100.0) * (cell_temp_c - 25.0)
        return max(0.0, self.nominal_power_w * (poa_wm2 / 1000.0) * temp_factor)

    def degradation_factor(self, year: int) -> float:
        """Fraction of original nameplate power remaining in a given operating year (1-indexed)."""
        if year <= 0:
            return 1.0
        after_y1 = 1.0 - self.degradation_year1_pct / 100.0
        remaining_years = max(0, year - 1)
        return after_y1 * (1.0 - self.degradation_annual_pct / 100.0) ** remaining_years
