"""Tracker geometry models: fixed tilt, single-axis, dual-axis.

Simplified engineering models (not manufacturer-specific tracker control
firmware). Single-axis tracking follows the standard rotation-angle
formula with an optional backtracking correction to avoid inter-row
self-shading at low sun angles.
"""
from __future__ import annotations

import numpy as np


def fixed_tilt_angles(n_steps: int, tilt_deg: float, azimuth_deg: float):
    return np.full(n_steps, tilt_deg), np.full(n_steps, azimuth_deg)


def single_axis_tracker_angles(solar_zenith_deg, solar_azimuth_deg, axis_azimuth_deg: float = 0.0,
                                max_angle_deg: float = 60.0, gcr: float | None = None,
                                backtracking: bool = True):
    """Return (tilt_deg, surface_azimuth_deg) arrays for a horizontal single-axis
    tracker whose rotation axis runs along ``axis_azimuth_deg`` (0=N-S typical).
    """
    zen_r = np.radians(solar_zenith_deg)
    az_r = np.radians(solar_azimuth_deg - axis_azimuth_deg)

    # projection of sun vector onto the plane perpendicular to the tracker axis
    tan_rot = np.tan(zen_r) * np.sin(az_r)
    rotation_deg = np.degrees(np.arctan(tan_rot))
    rotation_deg = np.clip(rotation_deg, -max_angle_deg, max_angle_deg)

    if backtracking and gcr is not None and gcr > 0:
        # true-tracking angle vs backtrack angle (standard backtracking formula)
        rot_r = np.radians(rotation_deg)
        with np.errstate(invalid="ignore", divide="ignore"):
            factor = np.clip(1.0 / gcr * np.abs(np.cos(rot_r)), 0.0, 1.0)
        backtrack_r = np.arccos(np.clip(factor, -1, 1))
        limited = np.abs(rot_r) > backtrack_r
        rot_r = np.where(limited, np.sign(rot_r) * backtrack_r, rot_r)
        rotation_deg = np.degrees(rot_r)

    tilt_deg = np.abs(rotation_deg)
    surface_azimuth_deg = np.where(rotation_deg >= 0, axis_azimuth_deg + 90.0, axis_azimuth_deg - 90.0) % 360.0
    # night / sun-behind: tilt tends to 0
    below_horizon = solar_zenith_deg >= 90.0
    tilt_deg = np.where(below_horizon, 0.0, tilt_deg)
    return tilt_deg, surface_azimuth_deg


def dual_axis_tracker_angles(solar_zenith_deg, solar_azimuth_deg):
    """Dual-axis tracker always points normal to the sun."""
    tilt_deg = np.clip(solar_zenith_deg, 0, 90)
    surface_azimuth_deg = solar_azimuth_deg
    return tilt_deg, surface_azimuth_deg
