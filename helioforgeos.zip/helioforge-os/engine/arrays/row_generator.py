"""Row generator: places physically real row centre-lines across a usable
land polygon and measures how much of each row actually falls inside the
buildable land (accounting for obstacles / excluded zones already cut out
of that polygon upstream).
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from shapely.geometry import LineString, Polygon
from shapely.affinity import rotate, translate


@dataclass
class RowLayout:
    row_id: int
    center_x: float
    center_y: float
    usable_length_m: float
    line: LineString


def generate_rows(usable_polygon: Polygon, row_spacing_m: float, row_azimuth_deg: float,
                   min_row_length_m: float = 2.0) -> list[RowLayout]:
    """Sweep parallel row lines, spaced ``row_spacing_m`` apart, across the
    usable polygon, oriented so the row runs perpendicular to the array's
    equator-facing azimuth (i.e. rows run E-W for an azimuth-180 array).
    Returns only the segments that actually intersect usable land.
    """
    if usable_polygon.is_empty or row_spacing_m <= 0:
        return []

    minx, miny, maxx, maxy = usable_polygon.bounds
    diag = math.hypot(maxx - minx, maxy - miny) + 10.0
    cx, cy = (minx + maxx) / 2.0, (miny + maxy) / 2.0

    # row centre-line direction is perpendicular to the panel-facing azimuth
    row_dir_deg = row_azimuth_deg + 90.0

    n_lines = int(diag / row_spacing_m) + 2
    rows: list[RowLayout] = []
    row_id = 0
    for i in range(-n_lines, n_lines + 1):
        offset = i * row_spacing_m
        base = LineString([(cx - diag, cy + offset), (cx + diag, cy + offset)])
        line = rotate(base, row_azimuth_deg, origin=(cx, cy))
        clipped = line.intersection(usable_polygon)
        if clipped.is_empty:
            continue
        geoms = [clipped] if clipped.geom_type == "LineString" else list(clipped.geoms)
        for seg in geoms:
            if seg.length < min_row_length_m:
                continue
            centroid = seg.centroid
            rows.append(RowLayout(row_id=row_id, center_x=centroid.x, center_y=centroid.y,
                                   usable_length_m=seg.length, line=seg))
            row_id += 1
    return rows


def modules_per_row(usable_length_m: float, module_width_m: float, edge_margin_m: float = 0.5) -> int:
    if module_width_m <= 0:
        return 0
    return max(0, int((usable_length_m - 2 * edge_margin_m) / module_width_m))
