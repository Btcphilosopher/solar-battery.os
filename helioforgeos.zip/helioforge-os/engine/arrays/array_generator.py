"""ArrayGenerator: turns a site boundary + module + layout parameters into
a physically grounded PVArray (real row geometry -> real module count).

This is the heart of requirement #87 (parametric causality): change
row spacing, tilt, azimuth, module type or setbacks here and every
downstream quantity (module count, MWp, land use, roads, CAPEX, energy)
changes with it because they are all derived from this output.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from shapely.geometry import Polygon

from engine.arrays.pv_array import PVArray
from engine.arrays.row_generator import generate_rows, modules_per_row
from engine.modules.pv_module import PVModule


@dataclass
class ArrayGenerationResult:
    array: PVArray
    row_count: int
    rows_meta: list
    footprint_area_m2: float


def generate_array(
    usable_polygon: Polygon,
    module: PVModule,
    tilt_deg: float,
    azimuth_deg: float,
    row_spacing_m: float,
    tracker_type: str = "fixed_tilt",
    modules_high: int = 1,
    array_id: str = "ARR-1",
) -> ArrayGenerationResult:
    rows = generate_rows(usable_polygon, row_spacing_m, azimuth_deg)
    if not rows:
        empty_array = PVArray(array_id=array_id, module=module, rows=0, modules_per_row=0,
                               tilt_deg=tilt_deg, azimuth_deg=azimuth_deg,
                               row_spacing_m=row_spacing_m, tracker_type=tracker_type,
                               modules_high=modules_high)
        return ArrayGenerationResult(array=empty_array, row_count=0, rows_meta=[], footprint_area_m2=0.0)

    total_modules = 0
    footprint = 0.0
    row_module_counts = []
    for r in rows:
        n_mod = modules_per_row(r.usable_length_m, module.width_m)
        row_module_counts.append(n_mod)
        total_modules += n_mod * modules_high
        footprint += n_mod * module.width_m * row_spacing_m

    avg_modules_per_row = int(round(sum(row_module_counts) / len(rows))) if rows else 0

    array = PVArray(
        array_id=array_id, module=module, rows=len(rows), modules_per_row=avg_modules_per_row,
        tilt_deg=tilt_deg, azimuth_deg=azimuth_deg, row_spacing_m=row_spacing_m,
        tracker_type=tracker_type, modules_high=modules_high,
    )
    # override module_count with the geometry-accurate total (rows can have uneven length)
    array.__dict__["_exact_module_count"] = total_modules

    return ArrayGenerationResult(array=array, row_count=len(rows), rows_meta=rows,
                                  footprint_area_m2=footprint)


def exact_module_count(array: PVArray) -> int:
    return array.__dict__.get("_exact_module_count", array.module_count)
