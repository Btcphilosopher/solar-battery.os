"""PV array: an aggregated block of rows sharing tilt/azimuth/spacing config."""
from __future__ import annotations

import math
from dataclasses import dataclass, field

from engine.modules.pv_module import PVModule


@dataclass
class PVArray:
    array_id: str
    module: PVModule
    rows: int
    modules_per_row: int
    tilt_deg: float
    azimuth_deg: float
    row_spacing_m: float          # pitch, center-to-center
    tracker_type: str = "fixed_tilt"   # fixed_tilt | single_axis | dual_axis
    modules_high: int = 1          # portrait rows stacked per structure row

    @property
    def module_count(self) -> int:
        return self.rows * self.modules_per_row * self.modules_high

    @property
    def dc_capacity_w(self) -> float:
        return self.module_count * self.module.nominal_power_w

    @property
    def slant_length_m(self) -> float:
        return self.module.height_m * self.modules_high

    @property
    def ground_cover_ratio(self) -> float:
        horizontal_proj = self.slant_length_m * math.cos(math.radians(self.tilt_deg))
        if self.row_spacing_m <= 0:
            return 0.0
        return min(1.0, horizontal_proj / self.row_spacing_m)

    @property
    def row_length_m(self) -> float:
        return self.modules_per_row * self.module.width_m

    @property
    def footprint_area_m2(self) -> float:
        """Total land footprint including inter-row gaps (rows * pitch * row length)."""
        return self.rows * self.row_spacing_m * self.row_length_m

    def to_dict(self) -> dict:
        return {
            "array_id": self.array_id,
            "module": self.module.name,
            "rows": self.rows,
            "modules_per_row": self.modules_per_row,
            "modules_high": self.modules_high,
            "module_count": self.module_count,
            "tilt_deg": self.tilt_deg,
            "azimuth_deg": self.azimuth_deg,
            "row_spacing_m": self.row_spacing_m,
            "tracker_type": self.tracker_type,
            "dc_capacity_kw": self.dc_capacity_w / 1000.0,
            "gcr": self.ground_cover_ratio,
            "footprint_area_ha": self.footprint_area_m2 / 10_000.0,
        }
