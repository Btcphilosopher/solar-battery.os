"""System loss stack: soiling, mismatch, wiring, availability."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class SystemLosses:
    soiling_pct: float = 2.0
    mismatch_pct: float = 1.5
    wiring_pct: float = 1.0
    availability_pct: float = 2.0
    dc_cable_loss_pct: float = 1.0
    ac_cable_loss_pct: float = 0.5
    transformer_loss_pct: float = 1.0
    mv_collector_loss_pct: float = 0.5

    @property
    def dc_side_derate(self) -> float:
        """Combined multiplicative derate applied before the inverter."""
        pct_list = [self.soiling_pct, self.mismatch_pct, self.wiring_pct,
                    self.availability_pct, self.dc_cable_loss_pct]
        factor = 1.0
        for p in pct_list:
            factor *= (1.0 - p / 100.0)
        return factor

    @property
    def ac_side_derate(self) -> float:
        pct_list = [self.ac_cable_loss_pct, self.transformer_loss_pct, self.mv_collector_loss_pct]
        factor = 1.0
        for p in pct_list:
            factor *= (1.0 - p / 100.0)
        return factor
