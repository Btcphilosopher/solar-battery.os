"""EnergyModel: the orchestrator that ties solar geometry, irradiance,
shading, temperature, module physics, inverters, grid and (optionally)
storage into a full annual timestep simulation.

This is the module through which requirement #87 (parametric causality)
flows for energy: change tilt/azimuth/row-spacing/DC-AC-ratio/grid-limit
upstream and every array below is recomputed from first principles.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from engine.arrays.pv_array import PVArray
from engine.arrays.tracker import (dual_axis_tracker_angles, fixed_tilt_angles,
                                    single_axis_tracker_angles)
from engine.degradation.degradation import degradation_factor_series
from engine.energy.losses import SystemLosses
from engine.energy.power_model import array_dc_power_kw
from engine.energy.temperature import cell_temperature_c
from engine.grid.grid_connection import GridConnection, curtailment_summary
from engine.inverters.inverter import Inverter, required_inverter_count
from engine.irradiance.decomposition import decompose_ghi
from engine.irradiance.clearsky import extraterrestrial_irradiance
from engine.shading.engine import inter_row_shaded_fraction
from engine.solar.position import solar_position
from engine.storage.battery import BatteryStorage
from engine.storage.dispatch import dispatch_timeseries
from engine.weather.synthetic import generate_synthetic_weather


@dataclass
class EnergySimulationResult:
    timeseries: pd.DataFrame
    monthly: pd.DataFrame
    annual_dc_energy_mwh: float
    annual_ac_energy_mwh: float
    annual_export_mwh: float
    annual_curtailed_mwh: float
    curtailment_pct: float
    capacity_factor_pct: float
    performance_ratio_pct: float
    specific_yield_kwh_per_kwp: float
    dc_capacity_kw: float
    ac_capacity_kw: float


def _timestamps_for_year(year_calendar: int, timestep_minutes: int) -> pd.DatetimeIndex:
    start = pd.Timestamp(year=year_calendar, month=1, day=1)
    end = pd.Timestamp(year=year_calendar, month=12, day=31, hour=23, minute=59)
    return pd.date_range(start, end, freq=f"{timestep_minutes}min")


def run_annual_simulation(
    array: PVArray,
    module_count: float,
    latitude: float,
    longitude: float,
    inverter: Inverter,
    dc_ac_ratio_target: float,
    grid: GridConnection,
    losses: SystemLosses,
    climate_profile: str = "flat",
    timestep_minutes: int = 60,
    calendar_year: int = 2026,
    degradation_year: int = 1,
    degradation_year1_pct: float = 2.0,
    degradation_annual_pct: float = 0.5,
    battery: BatteryStorage | None = None,
    axis_azimuth_deg: float = 0.0,
    tracking_limit_deg: float = 60.0,
    backtracking: bool = True,
    weather_seed: int = 42,
) -> EnergySimulationResult:
    ts = _timestamps_for_year(calendar_year, timestep_minutes)
    timestep_hours = timestep_minutes / 60.0

    sp = solar_position(ts, latitude, longitude)
    weather = generate_synthetic_weather(ts, latitude, climate=climate_profile, seed=weather_seed)

    doy = ts.dayofyear.to_numpy(dtype=float)
    i0 = extraterrestrial_irradiance(doy)
    zen_r = np.radians(np.clip(sp.zenith_deg, 0, 90))
    ghi = np.clip(weather["clearness_index"].to_numpy() * i0 * np.cos(zen_r), 0.0, None)
    ghi = np.where(sp.zenith_deg >= 90.0, 0.0, ghi)
    dni, dhi = decompose_ghi(ghi, sp.zenith_deg, doy)

    if array.tracker_type == "single_axis":
        tilt, saz = single_axis_tracker_angles(sp.zenith_deg, sp.azimuth_deg, axis_azimuth_deg,
                                                tracking_limit_deg, gcr=array.ground_cover_ratio,
                                                backtracking=backtracking)
    elif array.tracker_type == "dual_axis":
        tilt, saz = dual_axis_tracker_angles(sp.zenith_deg, sp.azimuth_deg)
    else:
        tilt, saz = fixed_tilt_angles(len(ts), array.tilt_deg, array.azimuth_deg)

    from engine.irradiance.transposition import poa_irradiance
    poa = poa_irradiance(ghi, dni, dhi, sp.zenith_deg, sp.azimuth_deg, tilt, saz)

    shaded_frac = inter_row_shaded_fraction(sp.elevation_deg, sp.azimuth_deg, array.azimuth_deg,
                                             tilt, array.slant_length_m, array.row_spacing_m)
    from engine.shading.engine import apply_shading_to_poa
    poa_after_shading = apply_shading_to_poa(poa["poa_direct"], poa["poa_sky_diffuse"],
                                              poa["poa_ground_diffuse"], shaded_frac)

    cell_temp = cell_temperature_c(poa_after_shading, weather["ambient_temp_c"].to_numpy(),
                                    weather["wind_speed_ms"].to_numpy())

    degr_factor = degradation_factor_series(degradation_year, degradation_year1_pct,
                                             degradation_annual_pct)[-1]

    dc_power_kw = array_dc_power_kw(poa_after_shading, cell_temp, array.module, module_count,
                                     dc_side_derate=losses.dc_side_derate,
                                     degradation_factor=degr_factor)

    dc_capacity_kw = module_count * array.module.nominal_power_w / 1000.0
    n_inverters = required_inverter_count(dc_capacity_kw, inverter, dc_ac_ratio_target)
    ac_capacity_kw = n_inverters * inverter.rated_ac_power_kw

    ac_power_kw, clipped_kw = inverter.ac_output_kw(dc_power_kw)
    # scale efficiency curve loading by the actual fleet size
    loading = dc_power_kw / max(ac_capacity_kw, 1e-6)
    eff = inverter.efficiency_at_loading(loading)
    ac_unclipped = dc_power_kw * eff
    ac_power_kw = np.minimum(ac_unclipped, ac_capacity_kw)
    clipped_kw = np.clip(ac_unclipped - ac_power_kw, 0.0, None)

    ac_power_kw = ac_power_kw * losses.ac_side_derate
    ac_power_mw = ac_power_kw / 1000.0

    dispatch = dispatch_timeseries(ac_power_mw, grid.export_limit_mw, battery, timestep_hours,
                                    battery_year=degradation_year)

    df = pd.DataFrame({
        "timestamp": ts,
        "ghi_wm2": ghi, "dni_wm2": dni, "dhi_wm2": dhi,
        "poa_global_wm2": poa_after_shading,
        "shaded_fraction": shaded_frac,
        "cell_temp_c": cell_temp,
        "dc_power_kw": dc_power_kw,
        "ac_power_mw": ac_power_mw,
        "clipped_kw": clipped_kw,
        "export_mw": dispatch["export_mw"],
        "curtailed_mw": dispatch["curtailed_mw"],
        "battery_soc_mwh": dispatch["soc_mwh"],
    })
    df["month"] = df["timestamp"].dt.month

    monthly = df.groupby("month").agg(
        ghi_wm2=("ghi_wm2", "mean"),
        generation_mwh=("ac_power_mw", lambda s: float(np.sum(s) * timestep_hours)),
        export_mwh=("export_mw", lambda s: float(np.sum(s) * timestep_hours)),
        curtailed_mwh=("curtailed_mw", lambda s: float(np.sum(s) * timestep_hours)),
    ).reset_index()
    monthly["capacity_factor_pct"] = 100.0 * (monthly["generation_mwh"] * 1000.0) / \
        (ac_capacity_kw * monthly["month"].map(lambda m: pd.Timestamp(calendar_year, m, 1).days_in_month) * 24.0)

    annual_dc_mwh = float(np.sum(dc_power_kw) * timestep_hours / 1000.0)
    annual_ac_mwh = float(np.sum(ac_power_mw) * timestep_hours)
    curt = curtailment_summary(dispatch["export_mw"], dispatch["curtailed_mw"], timestep_hours)

    capacity_factor_pct = 100.0 * annual_ac_mwh / (ac_capacity_kw / 1000.0 * 8760.0) if ac_capacity_kw > 0 else 0.0
    reference_yield_kwh_kwp = float(np.sum(poa_after_shading) * timestep_hours / 1000.0)
    actual_yield_kwh_kwp = (annual_ac_mwh * 1000.0) / dc_capacity_kw if dc_capacity_kw > 0 else 0.0
    performance_ratio_pct = 100.0 * actual_yield_kwh_kwp / reference_yield_kwh_kwp if reference_yield_kwh_kwp > 0 else 0.0

    return EnergySimulationResult(
        timeseries=df, monthly=monthly,
        annual_dc_energy_mwh=annual_dc_mwh,
        annual_ac_energy_mwh=annual_ac_mwh,
        annual_export_mwh=curt["annual_export_mwh"],
        annual_curtailed_mwh=curt["annual_curtailed_mwh"],
        curtailment_pct=curt["curtailment_pct"],
        capacity_factor_pct=capacity_factor_pct,
        performance_ratio_pct=performance_ratio_pct,
        specific_yield_kwh_per_kwp=actual_yield_kwh_kwp,
        dc_capacity_kw=dc_capacity_kw,
        ac_capacity_kw=ac_capacity_kw,
    )
