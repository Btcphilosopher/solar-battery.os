"""engine.energy package."""
