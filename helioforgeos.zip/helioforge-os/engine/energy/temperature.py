"""Cell/module temperature model.

Uses the Sandia/King "a,b" exponential wind-cooling model, a standard,
widely-used simplified thermal model for PV field simulation:

    T_module = POA * exp(a + b * wind_speed) + T_ambient
    T_cell   = T_module + POA / 1000 * delta_T

Default a/b/deltaT correspond to a typical open-rack glass/cell/polymer
module construction.
"""
from __future__ import annotations

import numpy as np

DEFAULT_A = -3.56
DEFAULT_B = -0.075
DEFAULT_DELTA_T = 3.0


def cell_temperature_c(poa_wm2: np.ndarray, ambient_temp_c: np.ndarray, wind_speed_ms: np.ndarray,
                        a: float = DEFAULT_A, b: float = DEFAULT_B, delta_t: float = DEFAULT_DELTA_T) -> np.ndarray:
    module_temp = poa_wm2 * np.exp(a + b * wind_speed_ms) + ambient_temp_c
    cell_temp = module_temp + (poa_wm2 / 1000.0) * delta_t
    return cell_temp
