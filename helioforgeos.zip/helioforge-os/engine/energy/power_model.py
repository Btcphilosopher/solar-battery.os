"""DC power model: POA irradiance + temperature + module characteristics
+ system losses -> array DC power (kW)."""
from __future__ import annotations

import numpy as np

from engine.modules.pv_module import PVModule


def array_dc_power_kw(poa_wm2: np.ndarray, cell_temp_c: np.ndarray, module: PVModule,
                       module_count: float, dc_side_derate: float = 1.0,
                       degradation_factor: float = 1.0) -> np.ndarray:
    """Vectorised DC power for an aggregated array of ``module_count``
    identical modules sharing the same POA/temperature profile."""
    temp_factor = 1.0 + (module.temperature_coefficient_pct_per_c / 100.0) * (cell_temp_c - 25.0)
    per_module_w = module.nominal_power_w * (poa_wm2 / 1000.0) * temp_factor
    per_module_w = np.clip(per_module_w, 0.0, None)
    total_w = per_module_w * module_count * dc_side_derate * degradation_factor
    return total_w / 1000.0
