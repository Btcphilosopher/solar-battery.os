"""PVDigitalTwin: the authoritative project state.

This is the single object every other layer (API, optimiser, reports,
visualisation) reads from and writes to. Its ``recalculate()`` method is
the implementation of the platform's central principle (requirement #87):

    change design -> regenerate layout -> recompute land -> recompute
    construction -> recompute energy -> recompute grid/storage ->
    recompute economics

Nothing downstream is cached across a design change; everything is
derived fresh from the current parameters each time ``recalculate()``
runs.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from engine.arrays.array_generator import exact_module_count, generate_array
from engine.arrays.pv_array import PVArray
from engine.construction.drainage import drainage_summary
from engine.construction.fencing import estimate_fencing
from engine.construction.roads import RoadConfig, estimate_road_network
from engine.degradation.degradation import lifetime_energy_table
from engine.economics.capex import CapexAssumptions, compute_capex
from engine.economics.finance import irr, lcoe, npv, payback_period_years
from engine.economics.opex import OpexAssumptions
from engine.economics.revenue import RevenueAssumptions, revenue_series
from engine.energy.energy_model import run_annual_simulation
from engine.energy.losses import SystemLosses
from engine.grid.grid_connection import GridConnection
from engine.inverters.inverter import Inverter
from engine.inverters.presets import get_inverter_preset
from engine.land.boundary import compute_land_breakdown
from engine.land.land_use import buildable_area_ha, lease_cost_multiplier
from engine.land.site import PVSite
from engine.modules.presets import get_module_preset
from engine.storage.battery import BatteryStorage


@dataclass
class DesignParameters:
    module_preset: str = "550W"
    inverter_preset: str = "2500kW"
    tracker_type: str = "fixed_tilt"      # fixed_tilt | single_axis | dual_axis
    tilt_deg: float = 25.0
    azimuth_deg: float = 180.0
    row_spacing_m: float = 6.0
    dc_ac_ratio: float = 1.25
    setback_m: float = 10.0
    max_slope_deg: float = 15.0
    grid_export_limit_mw: float = 100.0
    storage_enabled: bool = False
    battery_energy_mwh: float = 40.0
    battery_power_mw: float = 20.0
    battery_rte_pct: float = 90.0
    climate_profile: str = "flat"
    timestep_minutes: int = 60
    project_years: int = 30
    soiling_pct: float = 2.0
    mismatch_pct: float = 1.5
    wiring_pct: float = 1.0
    availability_pct: float = 2.0
    dc_cable_loss_pct: float = 1.0
    ac_cable_loss_pct: float = 0.5
    transformer_loss_pct: float = 1.0
    mv_collector_loss_pct: float = 0.5
    degradation_year1_pct: float = 2.0
    degradation_annual_pct: float = 0.5
    discount_rate_pct: float = 7.0
    inflation_pct: float = 2.0
    electricity_price_usd_per_mwh: float = 45.0
    ppa_escalation_pct: float = 1.0
    capex: CapexAssumptions = field(default_factory=CapexAssumptions)
    opex: OpexAssumptions = field(default_factory=OpexAssumptions)


class PVDigitalTwin:
    """The authoritative PV project state — a live parametric model."""

    def __init__(self, site: PVSite, design: Optional[DesignParameters] = None):
        self.site = site
        self.design = design or DesignParameters()

        # populated by recalculate()
        self.land = None
        self.array: Optional[PVArray] = None
        self.module_count: int = 0
        self.roads = None
        self.fencing = None
        self.drainage = None
        self.energy_result = None
        self.lifetime_table = None
        self.economics: dict = {}
        self.last_optimisation = None

    # ------------------------------------------------------------------ #
    # Layout / land / construction
    # ------------------------------------------------------------------ #
    def generate_layout(self) -> None:
        self.land = compute_land_breakdown(self.site, setback_m=self.design.setback_m,
                                            max_slope_deg=self.design.max_slope_deg)
        module = get_module_preset(self.design.module_preset)
        gen = generate_array(
            usable_polygon=self.land.usable_polygon,
            module=module,
            tilt_deg=self.design.tilt_deg,
            azimuth_deg=self.design.azimuth_deg,
            row_spacing_m=self.design.row_spacing_m,
            tracker_type=self.design.tracker_type,
        )
        self.array = gen.array
        self.module_count = exact_module_count(gen.array)

    def compute_construction(self) -> None:
        self.roads = estimate_road_network(self.land.total_area_ha, RoadConfig())
        self.fencing = estimate_fencing(self.site.boundary)
        self.drainage = drainage_summary(self.site.terrain) if self.site.terrain is not None else {}

    # ------------------------------------------------------------------ #
    # Energy
    # ------------------------------------------------------------------ #
    def run_energy(self, degradation_year: int = 1) -> None:
        inverter = get_inverter_preset(self.design.inverter_preset)
        losses = SystemLosses(
            soiling_pct=self.design.soiling_pct, mismatch_pct=self.design.mismatch_pct,
            wiring_pct=self.design.wiring_pct, availability_pct=self.design.availability_pct,
            dc_cable_loss_pct=self.design.dc_cable_loss_pct, ac_cable_loss_pct=self.design.ac_cable_loss_pct,
            transformer_loss_pct=self.design.transformer_loss_pct,
            mv_collector_loss_pct=self.design.mv_collector_loss_pct,
        )
        grid = GridConnection(export_limit_mw=self.design.grid_export_limit_mw)
        battery = None
        if self.design.storage_enabled:
            battery = BatteryStorage(energy_capacity_mwh=self.design.battery_energy_mwh,
                                      power_capacity_mw=self.design.battery_power_mw,
                                      round_trip_efficiency_pct=self.design.battery_rte_pct)

        self.energy_result = run_annual_simulation(
            array=self.array, module_count=self.module_count,
            latitude=self.site.latitude, longitude=self.site.longitude,
            inverter=inverter, dc_ac_ratio_target=self.design.dc_ac_ratio,
            grid=grid, losses=losses, climate_profile=self.design.climate_profile,
            timestep_minutes=self.design.timestep_minutes, degradation_year=degradation_year,
            degradation_year1_pct=self.design.degradation_year1_pct,
            degradation_annual_pct=self.design.degradation_annual_pct, battery=battery,
        )

    def run_lifetime(self) -> None:
        self.lifetime_table = lifetime_energy_table(
            annual_energy_year1_mwh=self.energy_result.annual_export_mwh,
            years=self.design.project_years,
            year1_pct=self.design.degradation_year1_pct,
            annual_pct=self.design.degradation_annual_pct,
        )

    # ------------------------------------------------------------------ #
    # Economics
    # ------------------------------------------------------------------ #
    def compute_economics(self) -> None:
        dc_capacity_wp = self.energy_result.dc_capacity_kw * 1000.0
        battery_kwh = self.design.battery_energy_mwh * 1000.0 if self.design.storage_enabled else 0.0
        capex_breakdown = compute_capex(dc_capacity_wp, self.design.capex, battery_energy_kwh=battery_kwh)
        total_capex = capex_breakdown["total_capex_usd"]

        opex_series = self.design.opex.opex_series(
            years=self.design.project_years, dc_capacity_kwp=self.energy_result.dc_capacity_kw,
            area_ha=self.land.total_area_ha, total_capex_usd=total_capex,
            battery_capex_usd=capex_breakdown.get("battery", 0.0),
            lease_multiplier=lease_cost_multiplier(self.site.land_use),
            inflation_pct=self.design.inflation_pct,
        )

        energy_series = self.lifetime_table["annual_energy_mwh"].tolist()
        revenue_assumptions = RevenueAssumptions(
            electricity_price_usd_per_mwh=self.design.electricity_price_usd_per_mwh,
            ppa_escalation_pct=self.design.ppa_escalation_pct,
        )
        revenues = revenue_series(energy_series, revenue_assumptions)

        cashflows = [-total_capex] + [r - o for r, o in zip(revenues, opex_series)]
        npv_usd = npv(self.design.discount_rate_pct, cashflows)
        irr_pct = irr(cashflows)
        payback = payback_period_years(cashflows)
        lcoe_val = lcoe(self.design.discount_rate_pct, total_capex, opex_series, energy_series)

        self.economics = {
            "capex_breakdown": capex_breakdown,
            "total_capex_usd": total_capex,
            "opex_year1_usd": opex_series[0] if opex_series else 0.0,
            "revenue_year1_usd": revenues[0] if revenues else 0.0,
            "npv_usd": npv_usd,
            "irr_pct": (irr_pct * 100.0) if irr_pct is not None else None,
            "payback_years": payback,
            "lcoe_usd_per_mwh": lcoe_val,
        }

    # ------------------------------------------------------------------ #
    # Master causality entrypoint
    # ------------------------------------------------------------------ #
    def recalculate(self) -> "PVDigitalTwin":
        self.generate_layout()
        self.compute_construction()
        self.run_energy(degradation_year=1)
        self.run_lifetime()
        self.compute_economics()
        return self

    # ------------------------------------------------------------------ #
    # Optimiser interface
    # ------------------------------------------------------------------ #
    def apply_design(self, overrides: dict) -> None:
        for k, v in overrides.items():
            if hasattr(self.design, k):
                setattr(self.design, k, v)

    def evaluate(self, overrides: dict) -> dict:
        """Apply a candidate design, recalculate the whole twin, and return
        the flat metrics dict optimisation objectives are defined over."""
        self.apply_design(overrides)
        self.recalculate()
        return self.metrics()

    def metrics(self) -> dict:
        dc_mw = self.energy_result.dc_capacity_kw / 1000.0
        ac_mw = self.energy_result.ac_capacity_kw / 1000.0
        land_ha = self.land.available_pv_area_ha
        annual_mwh = self.energy_result.annual_export_mwh
        return {
            "dc_capacity_mw": dc_mw,
            "ac_capacity_mw": ac_mw,
            "dc_ac_ratio": dc_mw / ac_mw if ac_mw else float("nan"),
            "module_count": self.module_count,
            "annual_energy_mwh": annual_mwh,
            "land_used_ha": land_ha,
            "mwh_per_hectare": annual_mwh / land_ha if land_ha else 0.0,
            "mw_per_hectare": dc_mw / land_ha if land_ha else 0.0,
            "curtailment_pct": self.energy_result.curtailment_pct,
            "capacity_factor_pct": self.energy_result.capacity_factor_pct,
            "performance_ratio_pct": self.energy_result.performance_ratio_pct,
            "capex_usd": self.economics.get("total_capex_usd", 0.0),
            "revenue_usd": self.economics.get("revenue_year1_usd", 0.0),
            "npv_usd": self.economics.get("npv_usd", 0.0),
            "irr_pct": self.economics.get("irr_pct") or 0.0,
            "lcoe_usd_per_mwh": self.economics.get("lcoe_usd_per_mwh", 0.0),
        }

    # ------------------------------------------------------------------ #
    # Reporting
    # ------------------------------------------------------------------ #
    def design_report(self) -> dict:
        m = self.metrics()
        return {
            "site": self.site.name,
            "area_ha": round(self.land.total_area_ha, 2),
            "pv_capacity_mwp": round(m["dc_capacity_mw"], 3),
            "ac_capacity_mw": round(m["ac_capacity_mw"], 3),
            "module_count": m["module_count"],
            "annual_generation_mwh": round(m["annual_energy_mwh"], 1),
            "capacity_factor_pct": round(m["capacity_factor_pct"], 2),
            "performance_ratio_pct": round(m["performance_ratio_pct"], 2),
            "land_productivity_mwh_per_ha": round(m["mwh_per_hectare"], 2),
            "curtailment_pct": round(m["curtailment_pct"], 2),
            "battery_enabled": self.design.storage_enabled,
            "grid_export_limit_mw": self.design.grid_export_limit_mw,
            "capex_usd": round(m["capex_usd"], 0),
            "opex_year1_usd": round(self.economics.get("opex_year1_usd", 0.0), 0),
            "lcoe_usd_per_mwh": round(m["lcoe_usd_per_mwh"], 2),
            "npv_usd": round(m["npv_usd"], 0),
            "irr_pct": round(m["irr_pct"], 2),
            "disclaimer": ("HELIOFORGE.OS output is a design-stage simulation. It is NOT a "
                           "substitute for certified engineering design, site surveys, "
                           "structural/electrical engineering, planning, environmental "
                           "assessment, grid studies, or fire engineering."),
        }
