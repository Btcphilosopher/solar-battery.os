"""Digital twin time engine: treats simulation time as a first-class
scrubbable variable and exposes the live field state at any timestep.
"""
from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from engine.digital_twin.twin import PVDigitalTwin


@dataclass
class LiveFieldState:
    timestamp: pd.Timestamp
    solar_elevation_deg: float | None
    ghi_wm2: float
    poa_wm2: float
    cell_temp_c: float
    dc_power_kw: float
    ac_power_mw: float
    battery_soc_mwh: float
    grid_export_mw: float
    curtailed_mw: float


class TimeEngine:
    """Wraps a twin's cached annual timeseries and lets a caller scrub
    through day/month/year to read the field's changing state."""

    def __init__(self, twin: PVDigitalTwin):
        self.twin = twin

    @property
    def timeseries(self) -> pd.DataFrame:
        if self.twin.energy_result is None:
            raise RuntimeError("Run twin.recalculate() before scrubbing the time engine.")
        return self.twin.energy_result.timeseries

    def state_at(self, timestamp: pd.Timestamp) -> LiveFieldState:
        df = self.timeseries
        idx = (df["timestamp"] - timestamp).abs().idxmin()
        row = df.loc[idx]
        return LiveFieldState(
            timestamp=row["timestamp"], solar_elevation_deg=None,
            ghi_wm2=float(row["ghi_wm2"]), poa_wm2=float(row["poa_global_wm2"]),
            cell_temp_c=float(row["cell_temp_c"]), dc_power_kw=float(row["dc_power_kw"]),
            ac_power_mw=float(row["ac_power_mw"]), battery_soc_mwh=float(row["battery_soc_mwh"]),
            grid_export_mw=float(row["export_mw"]), curtailed_mw=float(row["curtailed_mw"]),
        )

    def day_profile(self, month: int, day: int) -> pd.DataFrame:
        df = self.timeseries
        mask = (df["timestamp"].dt.month == month) & (df["timestamp"].dt.day == day)
        return df.loc[mask].reset_index(drop=True)

    def month_profile(self, month: int) -> pd.DataFrame:
        df = self.timeseries
        return df.loc[df["timestamp"].dt.month == month].reset_index(drop=True)

    def year_summary(self) -> dict:
        r = self.twin.energy_result
        return {
            "annual_dc_energy_mwh": r.annual_dc_energy_mwh,
            "annual_ac_energy_mwh": r.annual_ac_energy_mwh,
            "annual_export_mwh": r.annual_export_mwh,
            "annual_curtailed_mwh": r.annual_curtailed_mwh,
            "capacity_factor_pct": r.capacity_factor_pct,
        }
