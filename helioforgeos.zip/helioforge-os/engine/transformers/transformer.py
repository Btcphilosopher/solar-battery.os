"""Transformer model (inverter-duty step-up and MV/HV substation)."""
from __future__ import annotations

import numpy as np
from pydantic import BaseModel, Field


class Transformer(BaseModel):
    name: str
    capacity_kva: float = Field(gt=0)
    efficiency_pct: float = Field(default=99.0, gt=0, le=100)
    no_load_loss_pct: float = Field(default=0.1)
    primary_voltage_kv: float = 0.4
    secondary_voltage_kv: float = 33.0

    def losses_kw(self, load_kw: np.ndarray) -> np.ndarray:
        load_fraction = np.clip(load_kw / self.capacity_kva, 0.0, 1.5)
        no_load = self.capacity_kva * (self.no_load_loss_pct / 100.0)
        load_loss = load_kw * (1.0 - self.efficiency_pct / 100.0)
        return no_load + load_loss

    def output_kw(self, input_kw: np.ndarray) -> np.ndarray:
        return np.clip(input_kw - self.losses_kw(input_kw), 0.0, None)
