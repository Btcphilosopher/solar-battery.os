"""Grid connection & curtailment."""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class GridConnection:
    export_limit_mw: float
    connection_voltage_kv: float = 132.0

    def apply(self, ac_power_mw: np.ndarray) -> dict:
        exported = np.minimum(ac_power_mw, self.export_limit_mw)
        curtailed = np.clip(ac_power_mw - exported, 0.0, None)
        return {
            "export_mw": exported,
            "curtailed_mw": curtailed,
        }


def curtailment_summary(export_mw: np.ndarray, curtailed_mw: np.ndarray, timestep_hours: float) -> dict:
    annual_export_mwh = float(np.sum(export_mw) * timestep_hours)
    annual_curtailed_mwh = float(np.sum(curtailed_mw) * timestep_hours)
    gross = annual_export_mwh + annual_curtailed_mwh
    pct = 100.0 * annual_curtailed_mwh / gross if gross > 0 else 0.0
    return {
        "annual_export_mwh": annual_export_mwh,
        "annual_curtailed_mwh": annual_curtailed_mwh,
        "curtailment_pct": pct,
    }
