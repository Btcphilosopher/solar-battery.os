"""Design validation checks.

These are sanity/engineering-plausibility checks for a design-stage
simulation, NOT a certified engineering compliance check.
"""
from __future__ import annotations

from dataclasses import dataclass

from engine.digital_twin.twin import PVDigitalTwin


@dataclass
class ValidationIssue:
    severity: str   # "error" | "warning"
    message: str


def validate_coordinates(latitude: float, longitude: float) -> list[ValidationIssue]:
    issues = []
    if not (-90 <= latitude <= 90):
        issues.append(ValidationIssue("error", f"Latitude {latitude} out of range [-90, 90]."))
    if not (-180 <= longitude <= 180):
        issues.append(ValidationIssue("error", f"Longitude {longitude} out of range [-180, 180]."))
    return issues


def validate_row_spacing(row_spacing_m: float, module_slant_length_m: float) -> list[ValidationIssue]:
    issues = []
    if row_spacing_m <= 0:
        issues.append(ValidationIssue("error", "Row spacing must be positive."))
    elif row_spacing_m < module_slant_length_m * 0.9:
        issues.append(ValidationIssue("warning",
            f"Row spacing ({row_spacing_m:.1f} m) is close to or less than the module slant "
            f"length ({module_slant_length_m:.1f} m); rows may physically overlap."))
    return issues


def validate_inverter_loading(dc_capacity_kw: float, ac_capacity_kw: float,
                               max_dc_ac_ratio: float = 1.6) -> list[ValidationIssue]:
    issues = []
    if ac_capacity_kw <= 0:
        issues.append(ValidationIssue("error", "AC capacity must be positive."))
        return issues
    ratio = dc_capacity_kw / ac_capacity_kw
    if ratio > max_dc_ac_ratio:
        issues.append(ValidationIssue("warning",
            f"DC/AC ratio {ratio:.2f} exceeds the typical practical maximum ({max_dc_ac_ratio})."))
    if ratio < 0.9:
        issues.append(ValidationIssue("warning",
            f"DC/AC ratio {ratio:.2f} is unusually low; inverters will be under-utilised."))
    return issues


def validate_terrain(max_slope_deg: float) -> list[ValidationIssue]:
    issues = []
    if max_slope_deg <= 0 or max_slope_deg > 45:
        issues.append(ValidationIssue("warning", f"Max slope limit {max_slope_deg} deg is unusual."))
    return issues


def validate_solar_geometry(tilt_deg: float, azimuth_deg: float) -> list[ValidationIssue]:
    issues = []
    if not (0 <= tilt_deg <= 90):
        issues.append(ValidationIssue("error", f"Tilt {tilt_deg} deg out of physical range [0, 90]."))
    if not (0 <= azimuth_deg < 360):
        issues.append(ValidationIssue("error", f"Azimuth {azimuth_deg} deg out of range [0, 360)."))
    return issues


def validate_twin(twin: PVDigitalTwin) -> list[ValidationIssue]:
    issues: list[ValidationIssue] = []
    issues += validate_coordinates(twin.site.latitude, twin.site.longitude)
    issues += validate_solar_geometry(twin.design.tilt_deg, twin.design.azimuth_deg)
    issues += validate_terrain(twin.design.max_slope_deg)
    if twin.array is not None:
        issues += validate_row_spacing(twin.design.row_spacing_m, twin.array.slant_length_m)
    if twin.energy_result is not None:
        issues += validate_inverter_loading(twin.energy_result.dc_capacity_kw, twin.energy_result.ac_capacity_kw)
    if twin.array is not None and twin.module_count > 0 and twin.land is not None:
        footprint_ha = twin.array.footprint_area_m2 / 10_000.0
        if footprint_ha > twin.land.available_pv_area_ha * 1.05:
            issues.append(ValidationIssue("error",
                "Generated array footprint exceeds the available PV land polygon — "
                "modules would fall outside the buildable boundary."))
    return issues
