"""Smart design modes: MIN PV, MAX PV, MAX ENERGY, MIN LAND, MAX LAND
PRODUCTIVITY, MIN COST, MIN LCOE, MAX NPV, BALANCED — each a pre-wired
PVOptimizer configuration built around a digital twin's ``evaluate``
callback (see engine/digital_twin/twin.py).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from engine.optimisation.optimizer import DesignVariable, Objective, PVOptimizer

STANDARD_VARIABLES = [
    DesignVariable("tilt_deg", 5.0, 45.0),
    DesignVariable("azimuth_deg", 90.0, 270.0),
    DesignVariable("row_spacing_m", 4.0, 15.0),
    DesignVariable("dc_ac_ratio", 1.0, 1.6),
]


def minimum_pv_mode(evaluate_fn: Callable[[dict], dict], required_annual_energy_mwh: float,
                     max_land_ha: float, grid_limit_mw: float,
                     variables: list[DesignVariable] | None = None) -> PVOptimizer:
    constraints = {
        "annual_energy_mwh": (">=", required_annual_energy_mwh),
        "land_used_ha": ("<=", max_land_ha),
        "dc_capacity_mw": ("<=", grid_limit_mw * 2.0),
    }
    return PVOptimizer(variables or STANDARD_VARIABLES, evaluate_fn,
                        objective=Objective.MIN_CAPACITY, constraints=constraints)


def maximum_pv_mode(evaluate_fn: Callable[[dict], dict], max_land_ha: float, grid_limit_mw: float,
                     variables: list[DesignVariable] | None = None) -> PVOptimizer:
    constraints = {"land_used_ha": ("<=", max_land_ha)}
    return PVOptimizer(variables or STANDARD_VARIABLES, evaluate_fn,
                        objective=Objective.MAX_CAPACITY, constraints=constraints)


def maximum_energy_mode(evaluate_fn: Callable[[dict], dict], max_land_ha: float,
                         grid_limit_mw: float, variables: list[DesignVariable] | None = None) -> PVOptimizer:
    constraints = {"land_used_ha": ("<=", max_land_ha), "curtailment_pct": ("<=", 15.0)}
    return PVOptimizer(variables or STANDARD_VARIABLES, evaluate_fn,
                        objective=Objective.MAX_ANNUAL_ENERGY, constraints=constraints)


def minimum_land_mode(evaluate_fn: Callable[[dict], dict], target_mw: float | None = None,
                       target_mwh_year: float | None = None,
                       variables: list[DesignVariable] | None = None) -> PVOptimizer:
    constraints = {}
    if target_mw:
        constraints["dc_capacity_mw"] = (">=", target_mw)
    if target_mwh_year:
        constraints["annual_energy_mwh"] = (">=", target_mwh_year)
    return PVOptimizer(variables or STANDARD_VARIABLES, evaluate_fn,
                        objective=Objective.MIN_LAND, constraints=constraints)


def maximum_land_productivity_mode(evaluate_fn: Callable[[dict], dict],
                                    variables: list[DesignVariable] | None = None) -> PVOptimizer:
    return PVOptimizer(variables or STANDARD_VARIABLES, evaluate_fn,
                        objective=Objective.MAX_ENERGY_PER_HECTARE)


def minimum_cost_mode(evaluate_fn: Callable[[dict], dict],
                       variables: list[DesignVariable] | None = None) -> PVOptimizer:
    return PVOptimizer(variables or STANDARD_VARIABLES, evaluate_fn, objective=Objective.MIN_CAPEX)


def minimum_lcoe_mode(evaluate_fn: Callable[[dict], dict],
                       variables: list[DesignVariable] | None = None) -> PVOptimizer:
    return PVOptimizer(variables or STANDARD_VARIABLES, evaluate_fn, objective=Objective.MIN_LCOE)


def maximum_npv_mode(evaluate_fn: Callable[[dict], dict],
                      variables: list[DesignVariable] | None = None) -> PVOptimizer:
    return PVOptimizer(variables or STANDARD_VARIABLES, evaluate_fn, objective=Objective.MAX_NPV)


def balanced_mode(evaluate_fn: Callable[[dict], dict], weights: dict[str, float],
                   variables: list[DesignVariable] | None = None) -> PVOptimizer:
    return PVOptimizer(variables or STANDARD_VARIABLES, evaluate_fn, objective=Objective.BALANCED,
                        weights=weights)
