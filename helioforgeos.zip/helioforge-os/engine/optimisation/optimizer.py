"""PVOptimizer: generic bounded numerical optimiser over PV design
variables. Physics/geometry stay outside this module — callers supply an
``evaluate_fn(design_vector) -> metrics dict`` that recomputes the full
digital twin for a candidate design (tilt, azimuth, row spacing, DC/AC
ratio, battery size, ...). This keeps the optimiser decoupled from any
one physical model, per the modular architecture.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Callable

import numpy as np
from scipy.optimize import differential_evolution


class Objective(str, Enum):
    MAX_CAPACITY = "MAX_CAPACITY"
    MIN_CAPACITY = "MIN_CAPACITY"
    MAX_ANNUAL_ENERGY = "MAX_ANNUAL_ENERGY"
    MAX_ENERGY_PER_HECTARE = "MAX_ENERGY_PER_HECTARE"
    MIN_LAND = "MIN_LAND"
    MIN_CAPEX = "MIN_CAPEX"
    MIN_LCOE = "MIN_LCOE"
    MAX_NPV = "MAX_NPV"
    MAX_IRR = "MAX_IRR"
    MIN_CURTAILMENT = "MIN_CURTAILMENT"
    BALANCED = "BALANCED"


# maps each objective to (metric_key, maximise?)
_OBJECTIVE_METRIC = {
    Objective.MAX_CAPACITY: ("dc_capacity_mw", True),
    Objective.MIN_CAPACITY: ("dc_capacity_mw", False),
    Objective.MAX_ANNUAL_ENERGY: ("annual_energy_mwh", True),
    Objective.MAX_ENERGY_PER_HECTARE: ("mwh_per_hectare", True),
    Objective.MIN_LAND: ("land_used_ha", False),
    Objective.MIN_CAPEX: ("capex_usd", False),
    Objective.MIN_LCOE: ("lcoe_usd_per_mwh", False),
    Objective.MAX_NPV: ("npv_usd", True),
    Objective.MAX_IRR: ("irr_pct", True),
    Objective.MIN_CURTAILMENT: ("curtailment_pct", False),
}


@dataclass
class DesignVariable:
    name: str
    lower: float
    upper: float


@dataclass
class OptimisationResult:
    objective: str
    best_design: dict
    best_metrics: dict
    success: bool
    n_evaluations: int
    history: list = field(default_factory=list)


def _penalty(metrics: dict, constraints: dict) -> float:
    """Soft penalty for constraint violations (keeps DE derivative-free and
    robust without needing an explicit feasible region)."""
    penalty = 0.0
    for key, (op, limit) in (constraints or {}).items():
        val = metrics.get(key)
        if val is None:
            continue
        if op == "<=" and val > limit:
            penalty += ((val - limit) / max(abs(limit), 1e-6)) ** 2
        elif op == ">=" and val < limit:
            penalty += ((limit - val) / max(abs(limit), 1e-6)) ** 2
    return penalty * 1e6


class PVOptimizer:
    def __init__(self, variables: list[DesignVariable],
                 evaluate_fn: Callable[[dict], dict],
                 objective: Objective = Objective.BALANCED,
                 weights: dict[str, float] | None = None,
                 constraints: dict | None = None):
        self.variables = variables
        self.evaluate_fn = evaluate_fn
        self.objective = objective
        self.weights = weights or {}
        self.constraints = constraints or {}
        self._history: list[dict] = []

    def _vector_to_design(self, x: np.ndarray) -> dict:
        return {v.name: float(xi) for v, xi in zip(self.variables, x)}

    def _cost(self, x: np.ndarray) -> float:
        design = self._vector_to_design(x)
        metrics = self.evaluate_fn(design)
        self._history.append({"design": design, "metrics": metrics})

        if self.objective == Objective.BALANCED:
            score = 0.0
            norms = {
                "dc_capacity_mw": 1.0, "annual_energy_mwh": 1e4, "land_used_ha": 100.0,
                "capex_usd": 1e8, "revenue_usd": 1e7, "curtailment_pct": 100.0,
            }
            score += self.weights.get("capacity_weight", 0.0) * metrics.get("dc_capacity_mw", 0) / norms["dc_capacity_mw"]
            score += self.weights.get("energy_weight", 0.0) * metrics.get("annual_energy_mwh", 0) / norms["annual_energy_mwh"]
            score -= self.weights.get("land_weight", 0.0) * metrics.get("land_used_ha", 0) / norms["land_used_ha"]
            score -= self.weights.get("cost_weight", 0.0) * metrics.get("capex_usd", 0) / norms["capex_usd"]
            score += self.weights.get("revenue_weight", 0.0) * metrics.get("revenue_usd", 0) / norms["revenue_usd"]
            score -= self.weights.get("grid_weight", 0.0) * metrics.get("curtailment_pct", 0) / norms["curtailment_pct"]
            cost = -score
        else:
            key, maximise = _OBJECTIVE_METRIC[self.objective]
            val = metrics.get(key, 0.0)
            cost = -val if maximise else val

        cost += _penalty(metrics, self.constraints)
        return cost

    def run(self, max_iter: int = 40, popsize: int = 12, seed: int = 0) -> OptimisationResult:
        bounds = [(v.lower, v.upper) for v in self.variables]
        self._history = []
        result = differential_evolution(self._cost, bounds, maxiter=max_iter, popsize=popsize,
                                         seed=seed, polish=True, tol=1e-6, workers=1)
        best_design = self._vector_to_design(result.x)
        best_metrics = self.evaluate_fn(best_design)
        return OptimisationResult(
            objective=self.objective.value if isinstance(self.objective, Objective) else str(self.objective),
            best_design=best_design, best_metrics=best_metrics, success=bool(result.success),
            n_evaluations=len(self._history), history=self._history,
        )
