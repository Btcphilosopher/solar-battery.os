"""Multi-objective optimisation: weighted-sum sweeps + Pareto-front
extraction over the resulting candidate designs.
"""
from __future__ import annotations

from typing import Callable

import numpy as np

from engine.optimisation.optimizer import DesignVariable, Objective, PVOptimizer


def generate_pareto_front(evaluate_fn: Callable[[dict], dict], variables: list[DesignVariable],
                           metric_x: str, metric_x_maximise: bool,
                           metric_y: str, metric_y_maximise: bool,
                           n_weight_steps: int = 9, max_iter: int = 25, popsize: int = 10) -> list[dict]:
    """Sweep weight combinations between two competing metrics (e.g.
    energy_weight vs cost_weight) and return the resulting candidate
    designs, then filter to the non-dominated (Pareto-optimal) subset.
    """
    from scipy.optimize import differential_evolution

    candidates = []
    for w in np.linspace(0.0, 1.0, n_weight_steps):

        def cost_fn(design, w=w):
            metrics = evaluate_fn(design)
            vx = metrics.get(metric_x, 0.0) * (1 if metric_x_maximise else -1)
            vy = metrics.get(metric_y, 0.0) * (1 if metric_y_maximise else -1)
            score = w * vx + (1 - w) * vy
            return -score, metrics

        bounds = [(v.lower, v.upper) for v in variables]

        def scipy_cost(x):
            design = {v.name: float(xi) for v, xi in zip(variables, x)}
            cost, _ = cost_fn(design)
            return cost

        result = differential_evolution(scipy_cost, bounds, maxiter=max_iter, popsize=popsize,
                                         seed=int(w * 1000), polish=True, workers=1)
        design = {v.name: float(xi) for v, xi in zip(variables, result.x)}
        metrics = evaluate_fn(design)
        candidates.append({"weight_x": float(w), "design": design, "metrics": metrics})

    return pareto_filter(candidates, metric_x, metric_x_maximise, metric_y, metric_y_maximise)


def pareto_filter(candidates: list[dict], metric_x: str, metric_x_maximise: bool,
                   metric_y: str, metric_y_maximise: bool) -> list[dict]:
    def dominates(a, b):
        ax = a["metrics"].get(metric_x, 0.0) * (1 if metric_x_maximise else -1)
        ay = a["metrics"].get(metric_y, 0.0) * (1 if metric_y_maximise else -1)
        bx = b["metrics"].get(metric_x, 0.0) * (1 if metric_x_maximise else -1)
        by = b["metrics"].get(metric_y, 0.0) * (1 if metric_y_maximise else -1)
        return (ax >= bx and ay >= by) and (ax > bx or ay > by)

    pareto = []
    for c in candidates:
        if not any(dominates(other, c) for other in candidates if other is not c):
            pareto.append(c)
    return pareto
