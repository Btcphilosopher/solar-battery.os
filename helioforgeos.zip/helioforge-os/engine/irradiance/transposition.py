"""Plane-of-array (POA) irradiance transposition.

Implements the isotropic sky-diffuse model (Liu & Jordan, 1963) with a
ground-reflected component, plus the geometric angle-of-incidence (AOI)
calculation for a tilted surface of arbitrary tilt/azimuth (fixed or
tracked). Simple, transparent, and adequate for design-stage simulation.
"""
from __future__ import annotations

import numpy as np


def angle_of_incidence_deg(zenith_deg, azimuth_deg, surface_tilt_deg, surface_azimuth_deg):
    zen_r = np.radians(zenith_deg)
    az_r = np.radians(azimuth_deg)
    tilt_r = np.radians(surface_tilt_deg)
    saz_r = np.radians(surface_azimuth_deg)

    cos_aoi = (np.cos(zen_r) * np.cos(tilt_r)
               + np.sin(zen_r) * np.sin(tilt_r) * np.cos(az_r - saz_r))
    cos_aoi = np.clip(cos_aoi, -1.0, 1.0)
    return np.degrees(np.arccos(cos_aoi)), cos_aoi


def poa_irradiance(ghi, dni, dhi, zenith_deg, azimuth_deg,
                    surface_tilt_deg, surface_azimuth_deg, albedo: float = 0.20):
    """Return dict of poa_direct, poa_sky_diffuse, poa_ground_diffuse, poa_global."""
    aoi_deg, cos_aoi = angle_of_incidence_deg(zenith_deg, azimuth_deg,
                                               surface_tilt_deg, surface_azimuth_deg)
    tilt_r = np.radians(surface_tilt_deg)

    poa_direct = np.clip(dni * np.clip(cos_aoi, 0.0, None), 0.0, None)
    poa_sky_diffuse = dhi * (1 + np.cos(tilt_r)) / 2.0
    poa_ground_diffuse = ghi * albedo * (1 - np.cos(tilt_r)) / 2.0
    poa_global = poa_direct + poa_sky_diffuse + poa_ground_diffuse

    # sun below horizon -> zero everything
    below = zenith_deg >= 90.0
    poa_direct = np.where(below, 0.0, poa_direct)
    poa_global = np.where(below, 0.0, poa_global)

    return {
        "aoi_deg": aoi_deg,
        "poa_direct": poa_direct,
        "poa_sky_diffuse": poa_sky_diffuse,
        "poa_ground_diffuse": poa_ground_diffuse,
        "poa_global": poa_global,
    }
