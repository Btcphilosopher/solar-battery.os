"""engine.irradiance package."""
