"""Erbs-type decomposition of GHI into DNI/DHI using the clearness index.

Reference form: Erbs, Klein & Duffie (1982) piecewise correlation between
clearness index kt and the diffuse fraction. Simplified/robust variant
used here for scenario simulation.
"""
from __future__ import annotations

import numpy as np

from .clearsky import extraterrestrial_irradiance


def diffuse_fraction(kt: np.ndarray) -> np.ndarray:
    kt = np.clip(kt, 0.0, 1.0)
    f = np.where(
        kt <= 0.22,
        1.0 - 0.09 * kt,
        np.where(
            kt <= 0.80,
            0.9511 - 0.1604 * kt + 4.388 * kt**2 - 16.638 * kt**3 + 12.336 * kt**4,
            0.165,
        ),
    )
    return np.clip(f, 0.0, 1.0)


def decompose_ghi(ghi: np.ndarray, zenith_deg: np.ndarray, day_of_year: np.ndarray):
    """Return (dni, dhi) in W/m^2 given GHI and solar geometry."""
    zen_r = np.radians(np.clip(zenith_deg, 0, 89.9))
    cos_z = np.clip(np.cos(zen_r), 1e-3, 1.0)
    i0 = extraterrestrial_irradiance(day_of_year)
    kt = np.clip(ghi / np.clip(i0 * cos_z, 1e-6, None), 0.0, 1.0)
    fd = diffuse_fraction(kt)
    dhi = ghi * fd
    dni = np.clip((ghi - dhi) / cos_z, 0.0, i0)
    dni = np.where(zenith_deg >= 90.0, 0.0, dni)
    dhi = np.where(zenith_deg >= 90.0, 0.0, dhi)
    return dni, dhi
