"""Simplified clear-sky irradiance model.

Uses the Haurwitz (1945) clear-sky GHI model (simple, robust, needs only
solar zenith angle) plus the standard solar-constant extraterrestrial
irradiance correction for earth-sun distance. This is intentionally a
lightweight model suitable for scenario/optimisation simulation, not a
substitute for measured/satellite irradiance datasets.
"""
from __future__ import annotations

import numpy as np

SOLAR_CONSTANT_WM2 = 1361.0


def extraterrestrial_irradiance(day_of_year: np.ndarray) -> np.ndarray:
    b = 2 * np.pi * day_of_year / 365.0
    return SOLAR_CONSTANT_WM2 * (1.00011 + 0.034221 * np.cos(b) + 0.00128 * np.sin(b)
                                  + 0.000719 * np.cos(2 * b) + 0.000077 * np.sin(2 * b))


def clearsky_ghi(zenith_deg: np.ndarray) -> np.ndarray:
    """Haurwitz clear-sky global horizontal irradiance, W/m^2."""
    zen_r = np.radians(np.clip(zenith_deg, 0, 90))
    cos_z = np.cos(zen_r)
    ghi = 1098.0 * cos_z * np.exp(-0.059 / np.clip(cos_z, 1e-3, 1.0))
    ghi = np.where(zenith_deg >= 90.0, 0.0, ghi)
    return np.clip(ghi, 0.0, None)


def clearsky_dni(ghi: np.ndarray, zenith_deg: np.ndarray, day_of_year: np.ndarray) -> np.ndarray:
    """Beam component derived from a simple clearness-index approach."""
    i0 = extraterrestrial_irradiance(day_of_year)
    zen_r = np.radians(np.clip(zenith_deg, 0, 89.9))
    cos_z = np.clip(np.cos(zen_r), 1e-3, 1.0)
    kt = np.clip(ghi / np.clip(i0 * cos_z, 1e-6, None), 0.0, 0.85)
    dni = kt * i0 * np.exp(-1.0 / np.clip(cos_z, 1e-3, 1.0))
    dni = np.where(zenith_deg >= 90.0, 0.0, dni)
    return np.clip(dni, 0.0, i0)
