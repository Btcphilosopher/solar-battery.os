"""Module degradation modelling across the project lifetime."""
from __future__ import annotations

import numpy as np
import pandas as pd


def degradation_factor_series(years: int, year1_pct: float, annual_pct: float) -> np.ndarray:
    """Remaining nameplate-capacity fraction for each operating year (1-indexed).
    Year 1 takes the (typically larger) initial light-induced/settling
    degradation; subsequent years decay at the steady annual rate."""
    return np.array([
        (1.0 - year1_pct / 100.0) * (1.0 - annual_pct / 100.0) ** max(0, y - 1)
        for y in range(1, years + 1)
    ])


def lifetime_energy_table(annual_energy_year1_mwh: float, years: int, year1_pct: float,
                           annual_pct: float) -> pd.DataFrame:
    factors = degradation_factor_series(years, year1_pct, annual_pct)
    annual_energy = annual_energy_year1_mwh * factors
    cumulative = np.cumsum(annual_energy)
    return pd.DataFrame({
        "year": np.arange(1, years + 1),
        "capacity_factor_remaining_pct": factors * 100.0,
        "annual_energy_mwh": annual_energy,
        "cumulative_energy_mwh": cumulative,
    })
