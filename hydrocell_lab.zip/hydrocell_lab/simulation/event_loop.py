"""
The discrete timestep simulation loop. Each iteration:

  1. read the load profile's power demand at the current time
  2. delegate the physics (fuel supply -> current/voltage -> heat ->
     thermal update -> degradation) to StackManager.step
  3. build and log a TimestepRecord

This module intentionally contains no physics of its own - it is pure
orchestration, which keeps physics/systems logic independently testable.
"""
from __future__ import annotations

from dataclasses import dataclass

from inputs.load_profile import LoadProfile
from simulation.timestep import TimestepRecord, build_record
from systems.stack_manager import StackManager


@dataclass
class EventLoop:
    stack_manager: StackManager
    load_profile: LoadProfile
    n_cells: int
    dt_s: float = 1.0
    use_hhv: bool = True

    def run(self, duration_s: float) -> list[TimestepRecord]:
        records: list[TimestepRecord] = []
        t_s = 0.0
        steps = int(round(duration_s / self.dt_s))
        for _ in range(steps):
            demand_w = self.load_profile.power_demand_w(t_s)
            outputs = self.stack_manager.step(t_s, self.dt_s, demand_w)
            records.append(build_record(outputs, self.n_cells, self.use_hhv))
            t_s += self.dt_s
        return records
