"""
Top-level simulation engine and the experiment entry point:

    run_experiment(
        stack_size=50,
        hydrogen_flow=0.8,
        temperature_target=80,
        load_profile="vehicle_drive_cycle",
    )

This module wires together every layer (inputs -> core -> systems ->
simulation) into a single convenience call, and is the primary public API
of HydroCell Lab.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from core.electrochemistry import CellSpec
from core.fuel_stack import FuelCellStack
from inputs.air_inlet import AirInlet
from inputs.hydrogen_inlet import HydrogenInlet
from inputs.load_profile import LoadProfile, get_load_profile
from physics.degradation import DegradationParams
from simulation.event_loop import EventLoop
from simulation.timestep import TimestepRecord
from systems.cooling_system import CoolingParams, CoolingSystem
from systems.stack_manager import StackManager
from systems.thermal_system import ThermalParams, ThermalSystem

_ASSUMED_RATED_CELL_VOLTAGE_V = 0.65


@dataclass(frozen=True)
class ExperimentConfig:
    stack_size: int = 50
    hydrogen_flow_kg_per_hour: float = 0.8
    temperature_target_c: float = 80.0
    load_profile: str = "vehicle_drive_cycle"
    duration_s: float = 1800.0
    dt_s: float = 1.0
    seed: int = 42
    active_area_cm2: float = 280.0
    manufacturing_tolerance: float = 0.03
    excess_air_ratio: float = 2.0
    use_hhv: bool = True
    load_profile_kwargs: dict = field(default_factory=dict)


@dataclass
class SimulationResult:
    config: ExperimentConfig
    stack: FuelCellStack
    load_profile: LoadProfile
    rated_power_w: float
    records: list[TimestepRecord]


def _build_stack(config: ExperimentConfig) -> FuelCellStack:
    base_spec = CellSpec(active_area_cm2=config.active_area_cm2)
    return FuelCellStack.create(
        n_cells=config.stack_size,
        base_spec=base_spec,
        manufacturing_tolerance=config.manufacturing_tolerance,
        seed=config.seed,
    )


def estimate_rated_power_w(config: ExperimentConfig) -> float:
    per_cell_rated_current_a = (
        CellSpec(active_area_cm2=config.active_area_cm2).rated_current_density_a_cm2
        * config.active_area_cm2
    )
    per_cell_rated_power_w = per_cell_rated_current_a * _ASSUMED_RATED_CELL_VOLTAGE_V
    return config.stack_size * per_cell_rated_power_w


class SimulationEngine:
    """Reusable engine object: build once, run multiple experiments (e.g.
    for optimisation sweeps) while reusing the same underlying components."""

    def __init__(self, config: ExperimentConfig):
        self.config = config
        self.stack = _build_stack(config)
        self.rated_power_w = estimate_rated_power_w(config)

        self.hydrogen_inlet = HydrogenInlet.from_mass_flow_kg_per_hour(
            config.hydrogen_flow_kg_per_hour
        )
        hydrogen_mol_s = self.hydrogen_inlet.max_flow_mol_s
        self.air_inlet = AirInlet.sized_for_hydrogen_flow(
            hydrogen_mol_s, excess_air_ratio=config.excess_air_ratio
        )
        self.thermal_system = ThermalSystem(
            params=ThermalParams(), temperature_k=298.15
        )
        self.cooling_system = CoolingSystem(
            params=CoolingParams(target_temperature_k=config.temperature_target_c + 273.15)
        )
        self.degradation_params = DegradationParams()

        self.stack_manager = StackManager(
            stack=self.stack,
            hydrogen_inlet=self.hydrogen_inlet,
            air_inlet=self.air_inlet,
            thermal_system=self.thermal_system,
            cooling_system=self.cooling_system,
            degradation_params=self.degradation_params,
            use_hhv=config.use_hhv,
        )

        self.load_profile = get_load_profile(
            config.load_profile, self.rated_power_w, seed=config.seed, **config.load_profile_kwargs
        )

    def run(self) -> SimulationResult:
        loop = EventLoop(
            stack_manager=self.stack_manager,
            load_profile=self.load_profile,
            n_cells=self.config.stack_size,
            dt_s=self.config.dt_s,
            use_hhv=self.config.use_hhv,
        )
        records = loop.run(self.config.duration_s)
        return SimulationResult(
            config=self.config,
            stack=self.stack,
            load_profile=self.load_profile,
            rated_power_w=self.rated_power_w,
            records=records,
        )


def run_experiment(
    stack_size: int = 50,
    hydrogen_flow: float = 0.8,
    temperature_target: float = 80.0,
    load_profile: str = "vehicle_drive_cycle",
    duration_s: float = 1800.0,
    dt_s: float = 1.0,
    seed: int = 42,
    active_area_cm2: float = 280.0,
    **kwargs,
) -> SimulationResult:
    """Run one HydroCell Lab experiment.

    Args:
        stack_size: number of series-connected cells.
        hydrogen_flow: rated capacity of the hydrogen delivery regulator,
            in kg/h. The regulator meters flow to track actual reaction
            demand at a target fuel-utilisation setpoint (see
            `HydrogenInlet`), so this is a *ceiling*, not a fixed draw -
            it only becomes binding (causing fuel starvation) when
            instantaneous demand exceeds it.
        temperature_target: cooling system setpoint, in degrees C.
        load_profile: one of "constant", "vehicle_drive_cycle",
            "grid_fluctuating", "peak_shaving".
        duration_s: simulated duration, in seconds.
        dt_s: simulation timestep, in seconds.
        seed: RNG seed for manufacturing tolerance / stochastic load profiles.
        active_area_cm2: per-cell active area.
        **kwargs: forwarded to the load profile factory (e.g.
            `base_fraction=`, `peak_windows_s=` for the grid/peak-shaving
            profiles) and/or used to override ExperimentConfig fields
            directly (e.g. `manufacturing_tolerance=`, `excess_air_ratio=`,
            `use_hhv=`).
    """
    config_fields = {f for f in ExperimentConfig.__dataclass_fields__}
    config_overrides = {k: v for k, v in kwargs.items() if k in config_fields}
    profile_kwargs = {k: v for k, v in kwargs.items() if k not in config_fields}

    config = ExperimentConfig(
        stack_size=stack_size,
        hydrogen_flow_kg_per_hour=hydrogen_flow,
        temperature_target_c=temperature_target,
        load_profile=load_profile,
        duration_s=duration_s,
        dt_s=dt_s,
        seed=seed,
        active_area_cm2=active_area_cm2,
        load_profile_kwargs=profile_kwargs,
        **config_overrides,
    )
    engine = SimulationEngine(config)
    return engine.run()
