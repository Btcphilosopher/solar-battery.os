"""
The per-timestep log record: raw physical `StackOutputs` plus derived
efficiency metrics and demand context, ready for analysis/reporting.
"""
from __future__ import annotations

from dataclasses import dataclass

from physics.efficiency import fuel_utilization, overall_efficiency, voltage_efficiency
from physics.thermodynamics import thermoneutral_voltage
from systems.stack_manager import StackOutputs


@dataclass(frozen=True)
class TimestepRecord:
    time_s: float
    power_demand_w: float
    current_a: float
    stack_voltage_v: float
    power_output_w: float
    temperature_c: float
    hydrogen_supplied_mol_s: float
    hydrogen_consumed_mol_s: float
    oxygen_consumed_mol_s: float
    heat_generated_w: float
    cooling_power_w: float
    voltage_efficiency: float
    fuel_utilization: float
    overall_efficiency: float
    avg_catalyst_loss_fraction: float
    avg_membrane_resistance_growth_ohm_cm2: float
    min_cell_voltage_v: float
    max_cell_voltage_v: float
    fuel_starved: bool

    @property
    def temperature_k(self) -> float:
        return self.temperature_c + 273.15


def build_record(outputs: StackOutputs, n_cells: int, use_hhv: bool = True) -> TimestepRecord:
    avg_cell_voltage = outputs.stack_voltage_v / n_cells if n_cells else 0.0
    v_tn = thermoneutral_voltage(use_hhv)

    v_eff = voltage_efficiency(avg_cell_voltage, v_tn)
    fuel_eff = fuel_utilization(outputs.hydrogen_consumed_mol_s, outputs.hydrogen_supplied_mol_s)
    overall_eff = overall_efficiency(v_eff, fuel_eff)

    return TimestepRecord(
        time_s=outputs.time_s,
        power_demand_w=outputs.power_demand_w,
        current_a=outputs.current_a,
        stack_voltage_v=outputs.stack_voltage_v,
        power_output_w=outputs.power_output_w,
        temperature_c=outputs.temperature_k - 273.15,
        hydrogen_supplied_mol_s=outputs.hydrogen_supplied_mol_s,
        hydrogen_consumed_mol_s=outputs.hydrogen_consumed_mol_s,
        oxygen_consumed_mol_s=outputs.oxygen_consumed_mol_s,
        heat_generated_w=outputs.heat_generated_w,
        cooling_power_w=outputs.cooling_power_w,
        voltage_efficiency=v_eff,
        fuel_utilization=fuel_eff,
        overall_efficiency=overall_eff,
        avg_catalyst_loss_fraction=outputs.avg_catalyst_loss_fraction,
        avg_membrane_resistance_growth_ohm_cm2=outputs.avg_membrane_resistance_growth_ohm_cm2,
        min_cell_voltage_v=outputs.min_cell_voltage_v,
        max_cell_voltage_v=outputs.max_cell_voltage_v,
        fuel_starved=outputs.fuel_starved,
    )
