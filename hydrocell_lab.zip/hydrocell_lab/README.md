# HydroCell Lab

A research-grade digital twin simulator for hydrogen (PEM) fuel cell stacks,
written in pure Python 3.11+ (plus NumPy for array math and Matplotlib for
plots — no simulation frameworks).

HydroCell Lab models the electrochemical, thermal, and long-term
degradation behaviour of a hydrogen fuel cell stack at system-engineering
fidelity: accurate enough to explore design trade-offs, run efficiency
studies, and simulate stack scaling and wear — not a full CFD/quantum
chemistry tool, but not a toy either.

```
2H2 + O2 -> 2H2O + electrical energy + heat
```

---

## 1. How the simulator works

HydroCell Lab is a discrete-timestep physical simulation. Each timestep:

1. A **load profile** reports the instantaneous power demand.
2. The **hydrogen/air regulators** meter fuel and oxidant to the stack,
   tracking that demand (up to their rated capacity).
3. The **stack** solves, by bisection on its polarisation curve, the
   current that delivers the requested power — constrained by
   electrochemistry and by whatever fuel/oxidant was actually delivered.
4. **Reaction rates** (H2/O2 consumed, H2O produced) and **heat
   generation** are computed from that current via Faraday's law and the
   reaction enthalpy.
5. The **thermal system** integrates stack temperature forward one step,
   net of active cooling and ambient loss.
6. The **degradation model** accrues catalyst and membrane wear, weighted
   by how hard the stack was worked this step and how hot it was.
7. A **log record** captures everything (voltage, current, power,
   temperature, efficiencies, degradation state, fuel starvation flag).

This is implemented as a clean, layered architecture:

```
physics/     <- pure physics functions & constants (no state)
core/        <- single cell & stack objects (physics + wear state)
inputs/      <- hydrogen/air supply, load profiles
systems/     <- thermal system, cooling system, stack_manager (orchestrates one physical step)
simulation/  <- timestep record, event loop, experiment engine (orchestrates time)
analysis/    <- metrics, reports, matplotlib visualisation
```

Each layer only depends on layers below it, so the physics can be tested,
reasoned about, and extended independently of the simulation loop or
plotting code.

---

## 2. Physical model & assumptions

### Electrochemistry (per cell)

The cell voltage is the Nernst open-circuit voltage minus three loss terms:

```
V_cell = V_ocv - V_activation - V_ohmic - V_concentration
```

- **V_ocv** — Nernst equation: `E0(T) + (RT/2F) * ln(p_H2 * sqrt(p_O2) / p_H2O)`,
  with `E0(T) = 1.229 - 0.85mV/K * (T - 298.15K)` (Amphlett's linear
  approximation of the standard reversible voltage).
- **V_activation** — Tafel equation: `(RT)/(alpha*n*F) * ln(i / i0)`, the
  dominant loss at low current density.
- **V_ohmic** — linear: `i * ASR` (lumped membrane + contact + plate
  area-specific resistance).
- **V_concentration** — empirical mass-transport term:
  `-B * ln(1 - i/i_limit)`, which diverges near the limiting current
  density (modelled as a hard current ceiling per cell).

### Reaction rates & heat

Faraday's law converts current directly to molar flow:
`H2 consumed = I / (2F)`, `O2 consumed = I / (4F)`, `H2O produced = I / (2F)`
per cell. Heat generation follows from the thermoneutral voltage
`V_tn = HHV / (2F) ≈ 1.48V`: `Q = I * (V_tn - V_cell)` per cell — i.e. all
reaction enthalpy not converted to electrical work leaves as heat.

### Thermal system

Lumped single-node thermal capacitance model:
`C * dT/dt = Q_reaction - Q_cooling - h*(T - T_ambient)`, integrated with
forward Euler at the simulation timestep. Cooling is a proportional
controller tracking a target temperature.

### Fuel/air supply

Hydrogen and air are **metered, not fixed-flow**: the regulators track
actual reaction demand at a target fuel-utilisation / excess-air ratio,
capped by a rated maximum capacity — this is how real balance-of-plant
control works (closed-loop stoichiometry), and it's what makes
`hydrogen_flow` behave as a *capacity* rather than a constant leak. When
demand genuinely exceeds capacity, current is capped and the stack is
flagged fuel-starved for that step.

### Stack

Cells are connected in series (same current, voltages sum). Each cell
gets independent small manufacturing-tolerance variation (±3% by default,
seeded) and its own degradation state, so stacks naturally develop uneven
cell voltages and uneven wear over time — exactly like real hardware.

### Degradation

Two mechanisms, both accelerated by load (current density relative to
rated) and by sustained high temperature:

- **Catalyst degradation** — fractional loss of exchange current density
  `i0` (reduces effective activation kinetics).
- **Membrane fatigue** — growing area-specific resistance added to the
  ohmic loss term.

Plus a small calendar-ageing term independent of load. Degradation rates
are tuned to be *observable* over hours of simulated time rather than the
thousands of hours real stacks take — this is a simulator for exploring
mechanisms and trends, not for precise end-of-life prediction.

### Known simplifications

This is an engineering approximation, not a CFD/molecular model:

- No spatial resolution — each cell (and the whole stack) is a single
  lumped node; no along-channel gradients, no membrane water transport
  model, no explicit humidity.
- `i0` (activation kinetics) is not itself temperature-dependent (no
  Arrhenius term), so at fixed current density above `i0`, activation loss
  actually *increases* slightly with temperature in this model (the Tafel
  slope coefficient scales with T) even though real kinetics usually
  improve with temperature. This is visible as a slow efficiency decline
  as the stack warms up in the demo run — a known, documented limitation
  worth improving if you extend the model.
- Pressure effects are simplified linear scaling factors on partial
  pressure, not real gas-dynamics/pressure-drop.
- Air is dry (no water vapour partial pressure/humidity model).

---

## 3. Installation

```bash
cd hydrocell_lab
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

Requires Python 3.11+.

---

## 4. Running experiments

### Quick demo

```bash
python main.py --demo
```

Runs a 50-cell stack on a vehicle drive cycle for one simulated hour,
writes `output/report.md` and four plots, and prints the report.

### Programmatic API

```python
from simulation.engine import run_experiment
from analysis.metrics import compute_summary
from analysis.reporting import generate_report

result = run_experiment(
    stack_size=50,
    hydrogen_flow=0.8,          # kg/h - regulator *capacity*, not a fixed draw
    temperature_target=80,      # degC - cooling system setpoint
    load_profile="vehicle_drive_cycle",
    duration_s=3600.0,
    dt_s=1.0,
    seed=42,
)

metrics = compute_summary(result.records, result.config.dt_s)
print(generate_report(result, metrics))
```

`result.records` is a list of `TimestepRecord` — everything needed for
custom analysis (voltage, current, power, temperature, efficiencies,
degradation state, per-step fuel-starvation flag).

### CLI

```bash
python main.py --stack-size 80 --hydrogen-flow 1.2 --temperature-target 75 \
    --load-profile peak_shaving --duration-s 7200 --output-dir output/peak_run
```

### Load profiles

| Name                   | Behaviour                                                        |
|-------------------------|-------------------------------------------------------------------|
| `constant`              | Fixed fraction of rated power (`fraction=` kwarg, default 0.6)    |
| `vehicle_drive_cycle`   | Synthetic urban+highway cycle: idle, accel bursts, cruise, highway|
| `grid_fluctuating`      | Seeded sum-of-sinusoids grid-balancing style demand                |
| `peak_shaving`          | Base load with defined high-demand peak windows                    |

Extra kwargs to `run_experiment` not matching an `ExperimentConfig` field
are forwarded to the load profile factory (e.g. `fraction=0.8`,
`peak_windows_s=((900, 1200),)`, `base_fraction=0.5`).

### Stack scaling / design exploration

Just vary `stack_size` and `active_area_cm2` — everything else (rated
power estimate, air/H2 sizing, load-profile scaling) follows automatically:

```python
small = run_experiment(stack_size=20, active_area_cm2=150, hydrogen_flow=0.3)
large = run_experiment(stack_size=200, active_area_cm2=400, hydrogen_flow=4.0)
```

### Optimisation-style sweeps

Because `SimulationEngine`/`run_experiment` are cheap, plain Python
sweeps work fine for design exploration:

```python
best = max(
    (run_experiment(stack_size=n, hydrogen_flow=0.8, load_profile="constant")
     for n in range(20, 120, 10)),
    key=lambda r: compute_summary(r.records, r.config.dt_s).avg_overall_efficiency,
)
```

---

## 5. Project structure

```
hydrocell_lab/
├── main.py                  # CLI entry point / run_demo()
├── core/
│   ├── electrochemistry.py  # per-cell voltage = OCV - losses, with degradation applied
│   ├── fuel_cell.py         # single FuelCell (spec + degradation state)
│   ├── fuel_stack.py        # series stack, current<->power bisection solver
│   └── reaction_model.py    # Faraday's law: current -> molar flows & heat
├── inputs/
│   ├── hydrogen_inlet.py    # metered H2 supply (capacity + utilisation target)
│   ├── air_inlet.py         # metered air/O2 supply (capacity + excess-air ratio)
│   └── load_profile.py      # constant / drive cycle / grid / peak-shaving profiles
├── physics/
│   ├── nernst_model.py      # open-circuit voltage
│   ├── loss_models.py       # activation / ohmic / concentration losses
│   ├── efficiency.py        # voltage / fuel-utilisation / overall efficiency
│   ├── thermodynamics.py    # constants, Faraday's law helpers, thermoneutral voltage
│   └── degradation.py       # catalyst & membrane wear model
├── systems/
│   ├── thermal_system.py    # lumped-capacitance stack temperature model
│   ├── cooling_system.py    # proportional cooling controller
│   └── stack_manager.py     # orchestrates one physical timestep
├── simulation/
│   ├── timestep.py          # TimestepRecord (raw outputs -> derived metrics)
│   ├── event_loop.py        # the discrete timestep loop
│   └── engine.py            # SimulationEngine, ExperimentConfig, run_experiment()
└── analysis/
    ├── metrics.py            # ExperimentMetrics summary
    ├── reporting.py           # Markdown report generation
    └── visualisation.py       # matplotlib plots
```

---

## 6. Example results

Generated by `python main.py --demo` (50-cell stack, 280 cm² active area,
0.8 kg/h H2 regulator capacity, 80°C cooling target, vehicle drive cycle,
1 simulated hour):

- **Peak power:** 5.46 kW · **Average power:** 3.31 kW
- **Average overall efficiency (HHV):** 66.3 % (voltage efficiency 69.8 % ×
  fuel utilisation 95.0 %)
- **Total energy delivered:** 3.31 kWh from 0.122 kg H2 (27.0 kWh/kg)
- **No fuel starvation** at this sizing — the drive cycle's peaks stay
  within the regulator's rated capacity

See `output/` for the full report and plots from this run:

- `time_series.png` — power demand vs. delivered power, stack
  voltage/current, temperature, and efficiency, all over the drive cycle
- `polarization_curve.png` — the stack's voltage/power vs. current curve
  (the classic fuel-cell polarisation shape)
- `efficiency_heatmap.png` — voltage efficiency across current density ×
  temperature, showing the sweet spot at low current density / moderate
  temperature
- `degradation.png` — catalyst and membrane wear accrued over the 1-hour
  run (small, as expected — see `degradation_longrun.png` for a
  300-simulated-hour, 88 % load, 88°C stress test showing the trend
  clearly over a realistic wear timescale)
- `report.md` — the full Markdown report reproduced above

---

## 7. Extending the simulator

The layering is deliberate — to add a new loss mechanism, edit
`physics/loss_models.py` and thread it through
`core/electrochemistry.py`. To add a new load profile, add a class to
`inputs/load_profile.py` and register it in `_REGISTRY`. To add a new
degradation mechanism, extend `DegradationState`/`DegradationParams` in
`physics/degradation.py`. None of these require touching the simulation
loop or analysis code.

Ideas for further work (not implemented here): a vehicle range/energy-
consumption wrapper around `run_experiment`; grid-scale hydrogen storage
(tank state-of-charge feeding `HydrogenInlet` dynamically); a proper
optimisation engine searching `stack_size`/`active_area_cm2`/operating
temperature for maximum lifetime energy or efficiency; a learned or
rule-based controller adjusting `temperature_target`/`excess_air_ratio`
in response to observed degradation.
