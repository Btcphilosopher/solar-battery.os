"""
Voltage loss (polarisation) models for a PEM fuel cell:

    V_actual = V_ocv - V_activation - V_ohmic - V_concentration

Each loss term is an independent, swappable function operating on current
*density* (A/cm^2) so it composes cleanly across cells of different active
area. Parameters are plain dataclasses so degradation models can produce
modified copies without mutating the cell's nominal specification.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from physics.thermodynamics import GAS_CONSTANT, FARADAY_CONSTANT

_EPS = 1e-9


@dataclass(frozen=True)
class ActivationLossParams:
    """Tafel-equation parameters for the (dominant, cathodic) activation
    overpotential."""

    exchange_current_density_a_cm2: float = 2.0e-3
    charge_transfer_coefficient: float = 0.5


@dataclass(frozen=True)
class OhmicLossParams:
    """Lumped area-specific resistance (membrane + contact + plate)."""

    area_specific_resistance_ohm_cm2: float = 0.12


@dataclass(frozen=True)
class ConcentrationLossParams:
    """Mass-transport (concentration) loss parameters."""

    limiting_current_density_a_cm2: float = 1.4
    empirical_coefficient_v: float = 0.03


def activation_loss(
    current_density_a_cm2: float,
    temperature_k: float,
    params: ActivationLossParams,
) -> float:
    """Tafel equation: V_act = (R*T)/(alpha*n*F) * ln(i / i0).

    Clipped to be non-negative (the Tafel approximation is only valid for
    i > i0; below that we treat the activation loss as negligible rather
    than letting the log go negative, which would be unphysical).
    """
    i = max(current_density_a_cm2, 0.0)
    if i <= _EPS:
        return 0.0
    i0 = max(params.exchange_current_density_a_cm2, _EPS)
    n = 2  # electrons per H2, consistent with the rest of the model
    coeff = (GAS_CONSTANT * temperature_k) / (
        params.charge_transfer_coefficient * n * FARADAY_CONSTANT
    )
    return max(0.0, coeff * math.log(i / i0))


def ohmic_loss(current_density_a_cm2: float, params: OhmicLossParams) -> float:
    """Linear ohmic drop: V_ohm = i * ASR."""
    return max(current_density_a_cm2, 0.0) * params.area_specific_resistance_ohm_cm2


def concentration_loss(
    current_density_a_cm2: float, params: ConcentrationLossParams
) -> float:
    """Empirical mass-transport loss: V_conc = -B * ln(1 - i/i_limit).

    `current_density_a_cm2` is expected to already be clipped below
    `limiting_current_density_a_cm2` by the caller (see
    `core.electrochemistry`), since the log diverges at the limit.
    """
    i_limit = max(params.limiting_current_density_a_cm2, _EPS)
    ratio = min(max(current_density_a_cm2, 0.0) / i_limit, 0.999)
    return -params.empirical_coefficient_v * math.log(1.0 - ratio)
