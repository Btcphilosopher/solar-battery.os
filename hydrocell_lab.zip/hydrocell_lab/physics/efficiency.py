"""
Efficiency bookkeeping.

A PEMFC system's overall (net electrical / fuel HHV) efficiency decomposes
cleanly into two independent factors:

    eta_overall = eta_voltage * eta_fuel_utilisation

* Voltage efficiency: how close the operating cell voltage is to the
  thermoneutral voltage (the voltage at which *all* reaction enthalpy would
  become electricity). This captures activation/ohmic/concentration losses.

* Fuel utilisation efficiency: what fraction of the hydrogen actually fed
  to the stack takes part in the electrochemical reaction (vs. being
  purged unreacted, e.g. anode purge/venting losses).

This decomposition is standard in fuel-cell systems engineering and is
useful for diagnosing *why* a given operating point is inefficient.
"""
from __future__ import annotations


def voltage_efficiency(cell_voltage_v: float, thermoneutral_voltage_v: float) -> float:
    if thermoneutral_voltage_v <= 0:
        return 0.0
    return max(0.0, min(1.0, cell_voltage_v / thermoneutral_voltage_v))


def fuel_utilization(consumed_mol_s: float, supplied_mol_s: float) -> float:
    if supplied_mol_s <= 0:
        return 0.0
    return max(0.0, min(1.0, consumed_mol_s / supplied_mol_s))


def overall_efficiency(voltage_eff: float, fuel_util: float) -> float:
    return max(0.0, min(1.0, voltage_eff * fuel_util))


def temperature_derating_factor(
    temperature_k: float,
    optimal_k: float = 353.15,
    onset_k: float = 368.15,
    max_derate: float = 0.25,
) -> float:
    """Simplified efficiency multiplier for excessive stack temperature.

    Below `optimal_k` there is no penalty (this simulator's other loss
    terms already capture the low-temperature kinetic penalty via the
    Nernst/activation models). Above `onset_k` the membrane begins to dry
    out / degrade faster and usable efficiency falls off linearly, capped
    at `max_derate` fractional loss.
    """
    if temperature_k <= onset_k:
        return 1.0
    span = max(onset_k - optimal_k, 1.0)
    excess = temperature_k - onset_k
    derate = min(max_derate, max_derate * excess / span)
    return max(1.0 - max_derate, 1.0 - derate)
