"""
Long-term wear (degradation) model.

Two physically distinct mechanisms are tracked per cell:

* Catalyst degradation - loss of active electrochemical surface area
  (platinum dissolution/agglomeration), modelled as a fractional reduction
  in the exchange current density i0 used by the activation-loss term.

* Membrane fatigue - mechanical/chemical thinning and pinhole formation
  in the polymer membrane, modelled as a growing area-specific resistance
  added on top of the nominal ohmic resistance.

A third, smaller effect - gradual flooding/pore blockage reducing the mass
transport limit - is modelled as a fractional derate of the limiting
current density.

Degradation accrues with operating time, and is *accelerated* by high load
(current density relative to rated) and by sustained high temperature, in
line with published PEMFC durability literature (higher current density
and temperature both accelerate catalyst and membrane degradation).
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class DegradationParams:
    """Tunable rate constants. Defaults are chosen so a stack run hard
    (near-rated load, elevated temperature) accumulates a noticeable but
    not absurd amount of wear over a multi-hour simulated run, which is
    the timescale this simulator is meant to explore (real stacks degrade
    over thousands of hours; rates are scaled up for observability)."""

    catalyst_degradation_rate_per_hour: float = 4.0e-4
    membrane_growth_rate_ohm_cm2_per_hour: float = 2.5e-4
    concentration_derate_rate_per_hour: float = 1.0e-4
    baseline_degradation_rate_per_hour: float = 2.0e-5  # calendar ageing, load-independent
    load_stress_exponent: float = 2.0
    thermal_reference_k: float = 353.15  # 80 degC: above this, degradation accelerates
    thermal_acceleration_per_k: float = 0.06
    max_catalyst_loss_fraction: float = 0.6
    max_concentration_derate_fraction: float = 0.6


@dataclass
class DegradationState:
    """Per-cell accumulated wear. Mutated in place by `update`."""

    operating_hours: float = 0.0
    catalyst_loss_fraction: float = 0.0
    membrane_resistance_growth_ohm_cm2: float = 0.0
    concentration_derate_fraction: float = 0.0


def update(
    state: DegradationState,
    dt_s: float,
    current_density_a_cm2: float,
    rated_current_density_a_cm2: float,
    temperature_k: float,
    params: DegradationParams,
) -> DegradationState:
    """Advance the degradation state by one timestep, in place, and return it."""
    dt_h = dt_s / 3600.0
    if dt_h <= 0:
        return state

    load_ratio = max(current_density_a_cm2, 0.0) / max(rated_current_density_a_cm2, 1e-9)
    stress = load_ratio ** params.load_stress_exponent

    temp_excess_k = max(0.0, temperature_k - params.thermal_reference_k)
    thermal_multiplier = 1.0 + params.thermal_acceleration_per_k * temp_excess_k

    accel = stress * thermal_multiplier
    baseline = params.baseline_degradation_rate_per_hour * dt_h

    state.operating_hours += dt_h

    state.catalyst_loss_fraction = min(
        params.max_catalyst_loss_fraction,
        state.catalyst_loss_fraction
        + params.catalyst_degradation_rate_per_hour * accel * dt_h
        + baseline,
    )
    state.membrane_resistance_growth_ohm_cm2 += (
        params.membrane_growth_rate_ohm_cm2_per_hour * accel * dt_h + baseline * 0.05
    )
    state.concentration_derate_fraction = min(
        params.max_concentration_derate_fraction,
        state.concentration_derate_fraction
        + params.concentration_derate_rate_per_hour * accel * dt_h,
    )
    return state
