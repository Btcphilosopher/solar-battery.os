"""
Nernst-equation open-circuit voltage model.

The reversible (open-circuit) cell voltage depends on temperature and the
partial pressures (activities) of the reactants/product at the electrodes:

    E = E0(T) + (R*T)/(2F) * ln( p_H2 * sqrt(p_O2) / p_H2O )

This is the classic PEMFC systems-engineering form (e.g. Amphlett 1995,
Larminie & Dicks). Pressures are in atm (dimensionless activity
approximation, valid for the moderate pressures used here).
"""
from __future__ import annotations

import math

from physics.thermodynamics import FARADAY_CONSTANT, GAS_CONSTANT, reversible_voltage

_MIN_PRESSURE_ATM = 1e-6


def open_circuit_voltage(
    temperature_k: float,
    p_h2_atm: float,
    p_o2_atm: float,
    p_h2o_atm: float = 1.0,
) -> float:
    """Nernst open-circuit voltage for a single cell."""
    e0 = reversible_voltage(temperature_k)

    p_h2 = max(p_h2_atm, _MIN_PRESSURE_ATM)
    p_o2 = max(p_o2_atm, _MIN_PRESSURE_ATM)
    p_h2o = max(p_h2o_atm, _MIN_PRESSURE_ATM)

    nernst_term = (GAS_CONSTANT * temperature_k) / (2 * FARADAY_CONSTANT)
    nernst_term *= math.log((p_h2 * math.sqrt(p_o2)) / p_h2o)

    return e0 + nernst_term
