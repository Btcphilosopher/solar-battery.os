"""
Thermodynamic constants and Faraday's-law bookkeeping for the H2/O2 fuel cell
reaction:

    Anode:   H2 -> 2H+ + 2e-
    Cathode: O2 + 4H+ + 4e- -> 2H2O
    Net:     2H2 + O2 -> 2H2O + electrical energy + heat

All quantities are in SI base units unless noted (V, A, K, Pa/atm, mol, s, J).
"""
from __future__ import annotations

from dataclasses import dataclass

# --- Universal constants -----------------------------------------------
FARADAY_CONSTANT: float = 96_485.332_12  # C/mol
GAS_CONSTANT: float = 8.314_462_618  # J/(mol K)
ELECTRONS_PER_H2: int = 2  # electrons liberated per mole of H2 at the anode
ELECTRONS_PER_O2: int = 4  # electrons consumed per mole of O2 at the cathode

# --- Reaction enthalpies (molar, per mole of H2 reacted) ----------------
# HHV: product water is liquid (285.83 kJ/mol). LHV: product water is vapour
# (241.83 kJ/mol). Real stacks operating below 100 degC are usually rated
# against HHV since that is what is actually purchased/metered as fuel.
HHV_MOLAR_ENTHALPY_J: float = 285_830.0
LHV_MOLAR_ENTHALPY_J: float = 241_830.0

MOLAR_MASS_H2_KG: float = 2.016e-3  # kg/mol
MOLAR_MASS_O2_KG: float = 31.998e-3  # kg/mol

ATM_PER_BAR: float = 0.986_923


def thermoneutral_voltage(use_hhv: bool = True) -> float:
    """Voltage equivalent of the reaction enthalpy (V_tn).

    Operating a cell exactly at V_tn would release no net heat: all reaction
    enthalpy would leave as electrical work. Real cells always run below
    V_tn, so (V_tn - V_cell) * I is the heat generation rate per cell.
    """
    enthalpy = HHV_MOLAR_ENTHALPY_J if use_hhv else LHV_MOLAR_ENTHALPY_J
    return enthalpy / (ELECTRONS_PER_H2 * FARADAY_CONSTANT)


def reversible_voltage(temperature_k: float) -> float:
    """Standard reversible (open-circuit) cell voltage E0, temperature
    corrected via the common linear empirical approximation used in PEMFC
    system-engineering models (Amphlett et al.):

        E0(T) = 1.229 - 0.85e-3 * (T - 298.15)   [V]
    """
    return 1.229 - 0.85e-3 * (temperature_k - 298.15)


def hydrogen_consumption_rate_mol_s(current_a: float) -> float:
    """Molar H2 consumption rate for a single cell carrying `current_a`."""
    return max(current_a, 0.0) / (ELECTRONS_PER_H2 * FARADAY_CONSTANT)


def oxygen_consumption_rate_mol_s(current_a: float) -> float:
    """Molar O2 consumption rate for a single cell carrying `current_a`."""
    return max(current_a, 0.0) / (ELECTRONS_PER_O2 * FARADAY_CONSTANT)


def water_production_rate_mol_s(current_a: float) -> float:
    """Molar H2O production rate for a single cell (equals H2 consumption,
    since the net reaction is 2H2 + O2 -> 2H2O)."""
    return hydrogen_consumption_rate_mol_s(current_a)


@dataclass(frozen=True)
class ReactionEnergyBasis:
    """Convenience bundle so callers can pick HHV or LHV once and reuse it."""

    use_hhv: bool = True

    @property
    def molar_enthalpy_j(self) -> float:
        return HHV_MOLAR_ENTHALPY_J if self.use_hhv else LHV_MOLAR_ENTHALPY_J

    @property
    def thermoneutral_voltage_v(self) -> float:
        return thermoneutral_voltage(self.use_hhv)
