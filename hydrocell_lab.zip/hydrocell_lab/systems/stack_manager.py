"""
StackManager orchestrates one physical timestep for a fuel cell stack:
hydrogen/air supply -> achievable current for the requested power -> fuel
starvation check -> reaction rates/heat -> thermal update -> degradation
update. It knows nothing about wall-clock load profiles or logging - it
just advances the physical system by one step given a power demand.
"""
from __future__ import annotations

from dataclasses import dataclass

from core.electrochemistry import CellElectrochemicalState
from core.fuel_stack import FuelCellStack
from core.reaction_model import (
    compute_reaction_rates,
    max_current_from_hydrogen_supply,
    max_current_from_oxygen_supply,
)
from inputs.air_inlet import AirInlet
from inputs.hydrogen_inlet import HydrogenInlet
from physics.degradation import DegradationParams
from physics.thermodynamics import hydrogen_consumption_rate_mol_s, oxygen_consumption_rate_mol_s
from systems.cooling_system import CoolingSystem
from systems.thermal_system import ThermalSystem


@dataclass(frozen=True)
class StackOutputs:
    time_s: float
    power_demand_w: float
    current_a: float
    stack_voltage_v: float
    power_output_w: float
    temperature_k: float
    hydrogen_supplied_mol_s: float
    hydrogen_consumed_mol_s: float
    oxygen_consumed_mol_s: float
    heat_generated_w: float
    cooling_power_w: float
    fuel_starved: bool
    avg_catalyst_loss_fraction: float
    avg_membrane_resistance_growth_ohm_cm2: float
    min_cell_voltage_v: float
    max_cell_voltage_v: float


@dataclass
class StackManager:
    stack: FuelCellStack
    hydrogen_inlet: HydrogenInlet
    air_inlet: AirInlet
    thermal_system: ThermalSystem
    cooling_system: CoolingSystem
    degradation_params: DegradationParams
    use_hhv: bool = True

    def _environment(self) -> CellElectrochemicalState:
        return CellElectrochemicalState(
            temperature_k=self.thermal_system.temperature_k,
            p_h2_atm=self.hydrogen_inlet.partial_pressure_atm(),
            p_o2_atm=self.air_inlet.partial_pressure_o2_atm(),
            p_h2o_atm=1.0,
        )

    def step(self, t_s: float, dt_s: float, power_demand_w: float) -> StackOutputs:
        n_cells = self.stack.n_cells
        environment = self._environment()

        # Pass 1: what current would satisfy the requested power if fuel
        # and oxidant supply were unconstrained (electrochemistry-limited
        # only)? This is the demand the fuel/air metering regulators try
        # to track.
        desired_current_a, _ = self.stack.solve_current_for_power(power_demand_w, environment)
        desired_h2_mol_s = hydrogen_consumption_rate_mol_s(desired_current_a) * n_cells
        desired_o2_mol_s = oxygen_consumption_rate_mol_s(desired_current_a) * n_cells

        # The regulators meter supply to that demand (at their target
        # utilisation / excess-air ratio), capped by their rated capacity.
        h2_supplied = self.hydrogen_inlet.metered_flow_mol_s(desired_h2_mol_s, t_s)
        o2_supplied = self.air_inlet.metered_oxygen_flow_mol_s(desired_o2_mol_s, t_s)

        # Pass 2: the current actually achievable given what could be
        # delivered (binds only when demand exceeds regulator capacity).
        current_ceiling_a = min(
            max_current_from_hydrogen_supply(h2_supplied, n_cells),
            max_current_from_oxygen_supply(o2_supplied, n_cells),
        )

        current_a, was_limited = self.stack.solve_current_for_power(
            power_demand_w, environment, current_ceiling_a=current_ceiling_a
        )

        breakdown = self.stack.voltage_breakdown_at_current(current_a, environment)
        stack_voltage_v = breakdown.stack_voltage_v
        power_output_w = stack_voltage_v * current_a

        avg_cell_voltage = stack_voltage_v / n_cells if n_cells else 0.0
        reaction = compute_reaction_rates(current_a, n_cells, avg_cell_voltage, self.use_hhv)

        cooling_power_w = self.cooling_system.cooling_power_w(self.thermal_system.temperature_k)
        new_temperature_k = self.thermal_system.step(dt_s, reaction.heat_generated_w, cooling_power_w)

        self.stack.apply_degradation(dt_s, current_a, new_temperature_k, self.degradation_params)

        fuel_starved = was_limited and power_output_w < power_demand_w - 1e-6

        return StackOutputs(
            time_s=t_s,
            power_demand_w=power_demand_w,
            current_a=current_a,
            stack_voltage_v=stack_voltage_v,
            power_output_w=power_output_w,
            temperature_k=new_temperature_k,
            hydrogen_supplied_mol_s=h2_supplied,
            hydrogen_consumed_mol_s=reaction.hydrogen_consumed_mol_s,
            oxygen_consumed_mol_s=reaction.oxygen_consumed_mol_s,
            heat_generated_w=reaction.heat_generated_w,
            cooling_power_w=cooling_power_w,
            fuel_starved=fuel_starved,
            avg_catalyst_loss_fraction=self.stack.average_catalyst_loss_fraction(),
            avg_membrane_resistance_growth_ohm_cm2=self.stack.average_membrane_resistance_growth(),
            min_cell_voltage_v=min(breakdown.cell_voltages_v) if breakdown.cell_voltages_v else 0.0,
            max_cell_voltage_v=max(breakdown.cell_voltages_v) if breakdown.cell_voltages_v else 0.0,
        )
