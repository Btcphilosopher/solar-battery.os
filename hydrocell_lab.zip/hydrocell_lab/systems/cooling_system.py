"""
Active cooling system: a simple proportional controller driving cooling
power to hold the stack near its target operating temperature, capped by
the coolant loop's maximum heat-rejection capacity.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class CoolingParams:
    target_temperature_k: float = 353.15
    proportional_gain_w_per_k: float = 350.0
    max_cooling_power_w: float = 30_000.0
    baseline_cooling_w: float = 40.0  # coolant pump always running at low duty


@dataclass
class CoolingSystem:
    params: CoolingParams

    def cooling_power_w(self, current_temperature_k: float) -> float:
        error_k = current_temperature_k - self.params.target_temperature_k
        power_w = self.params.baseline_cooling_w + max(
            0.0, self.params.proportional_gain_w_per_k * error_k
        )
        return min(power_w, self.params.max_cooling_power_w)
