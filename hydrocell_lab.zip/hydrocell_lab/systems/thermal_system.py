"""
Lumped-capacitance thermal model for the stack. This is the standard
system-engineering simplification: treat the whole stack thermal mass as a
single node with one temperature, exchanging heat with (a) the reaction
heat source, (b) an active cooling system, and (c) passive loss to
ambient. Integrated explicitly (forward Euler) at the simulation
timestep.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ThermalParams:
    thermal_capacitance_j_per_k: float = 60_000.0
    ambient_temperature_k: float = 298.15
    ambient_heat_transfer_coefficient_w_per_k: float = 12.0


@dataclass
class ThermalSystem:
    params: ThermalParams
    temperature_k: float = 298.15

    def step(self, dt_s: float, heat_generated_w: float, cooling_power_w: float) -> float:
        """Advance stack temperature by dt_s given the net heat generated
        this step and the active cooling power removed, returning the new
        temperature (K)."""
        ambient_loss_w = self.params.ambient_heat_transfer_coefficient_w_per_k * (
            self.temperature_k - self.params.ambient_temperature_k
        )
        net_heat_w = heat_generated_w - cooling_power_w - ambient_loss_w
        self.temperature_k += net_heat_w * dt_s / self.params.thermal_capacitance_j_per_k
        return self.temperature_k
