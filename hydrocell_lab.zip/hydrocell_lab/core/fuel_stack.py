"""
Multi-cell fuel cell stack: cells connected electrically in series (a
standard PEM stack topology), so the same current flows through every
cell while the stack voltage is the sum of the individual cell voltages.

Because each cell can carry its own degradation state (and small
manufacturing-tolerance variation in its nominal parameters), the stack
naturally reproduces *uneven* cell degradation: some cells sag faster than
others under the same operating history, which is exactly what happens in
real stacks and is a key driver of end-of-life replacement decisions.
"""
from __future__ import annotations

import random
from dataclasses import dataclass

from core.electrochemistry import CellElectrochemicalState, CellSpec
from core.fuel_cell import FuelCell
from physics.degradation import DegradationParams
from physics.loss_models import ActivationLossParams, ConcentrationLossParams, OhmicLossParams

_BISECTION_ITERATIONS = 28
_BISECTION_TOLERANCE_W = 0.05


@dataclass(frozen=True)
class StackVoltageBreakdown:
    stack_voltage_v: float
    current_a: float
    cell_voltages_v: list[float]
    saturated: bool  # any cell hit its concentration limit


def build_cell_specs(
    n_cells: int,
    base_spec: CellSpec,
    manufacturing_tolerance: float = 0.03,
    seed: int = 42,
) -> list[CellSpec]:
    """Generate per-cell specs with small random manufacturing variation
    (+/- `manufacturing_tolerance` fraction) around `base_spec`, so a stack
    is not perfectly homogeneous - matching real production tolerances and
    enabling realistic uneven degradation/voltage spread."""
    rng = random.Random(seed)
    specs: list[CellSpec] = []
    for _ in range(n_cells):
        jitter = lambda x: x * (1.0 + rng.uniform(-manufacturing_tolerance, manufacturing_tolerance))
        specs.append(
            CellSpec(
                active_area_cm2=base_spec.active_area_cm2,
                activation_params=ActivationLossParams(
                    exchange_current_density_a_cm2=jitter(
                        base_spec.activation_params.exchange_current_density_a_cm2
                    ),
                    charge_transfer_coefficient=base_spec.activation_params.charge_transfer_coefficient,
                ),
                ohmic_params=OhmicLossParams(
                    area_specific_resistance_ohm_cm2=jitter(
                        base_spec.ohmic_params.area_specific_resistance_ohm_cm2
                    )
                ),
                concentration_params=ConcentrationLossParams(
                    limiting_current_density_a_cm2=jitter(
                        base_spec.concentration_params.limiting_current_density_a_cm2
                    ),
                    empirical_coefficient_v=base_spec.concentration_params.empirical_coefficient_v,
                ),
                rated_current_density_a_cm2=base_spec.rated_current_density_a_cm2,
            )
        )
    return specs


@dataclass
class FuelCellStack:
    cells: list[FuelCell]

    @classmethod
    def create(
        cls,
        n_cells: int,
        base_spec: CellSpec | None = None,
        manufacturing_tolerance: float = 0.03,
        seed: int = 42,
    ) -> "FuelCellStack":
        base_spec = base_spec or CellSpec()
        specs = build_cell_specs(n_cells, base_spec, manufacturing_tolerance, seed)
        cells = [FuelCell(cell_id=f"cell-{i:03d}", spec=spec) for i, spec in enumerate(specs)]
        return cls(cells=cells)

    @property
    def n_cells(self) -> int:
        return len(self.cells)

    def min_limiting_current_a(self, environment: CellElectrochemicalState) -> float:
        """The lowest per-cell limiting (mass-transport) current in the
        stack, in amps - the weakest cell sets the stack's ceiling since
        all cells share the same series current."""
        limits = []
        for cell in self.cells:
            eff_limit = cell.spec.concentration_params.limiting_current_density_a_cm2 * (
                1.0 - cell.degradation.concentration_derate_fraction
            )
            limits.append(max(eff_limit, 0.02) * cell.spec.active_area_cm2)
        return min(limits) if limits else 0.0

    def voltage_breakdown_at_current(
        self, current_a: float, environment: CellElectrochemicalState
    ) -> StackVoltageBreakdown:
        voltages = []
        saturated = False
        for cell in self.cells:
            breakdown = cell.voltage_at_current(current_a, environment)
            voltages.append(breakdown.cell_voltage_v)
            saturated = saturated or breakdown.saturated
        return StackVoltageBreakdown(
            stack_voltage_v=sum(voltages),
            current_a=current_a,
            cell_voltages_v=voltages,
            saturated=saturated,
        )

    def stack_voltage_at_current(self, current_a: float, environment: CellElectrochemicalState) -> float:
        return self.voltage_breakdown_at_current(current_a, environment).stack_voltage_v

    def stack_power_at_current(self, current_a: float, environment: CellElectrochemicalState) -> float:
        return self.stack_voltage_at_current(current_a, environment) * max(current_a, 0.0)

    def solve_current_for_power(
        self,
        target_power_w: float,
        environment: CellElectrochemicalState,
        current_ceiling_a: float | None = None,
    ) -> tuple[float, bool]:
        """Find the stack current that delivers `target_power_w`, by
        bisection on the (monotonically increasing, over the safe
        operating range below the concentration-loss knee) power curve.

        Returns (current_a, power_was_limited): `power_was_limited` is True
        if the requested power could not be reached within the allowed
        current ceiling (fuel/oxidant supply or electrochemical limit).
        """
        if target_power_w <= 0:
            return 0.0, False

        safe_limit_a = 0.97 * self.min_limiting_current_a(environment)
        ceiling = safe_limit_a if current_ceiling_a is None else min(safe_limit_a, current_ceiling_a)
        ceiling = max(ceiling, 0.0)

        if ceiling <= 1e-9:
            return 0.0, True

        max_deliverable_w = self.stack_power_at_current(ceiling, environment)
        if max_deliverable_w <= target_power_w:
            return ceiling, True

        lo, hi = 0.0, ceiling
        for _ in range(_BISECTION_ITERATIONS):
            mid = 0.5 * (lo + hi)
            p_mid = self.stack_power_at_current(mid, environment)
            if abs(p_mid - target_power_w) < _BISECTION_TOLERANCE_W:
                return mid, False
            if p_mid < target_power_w:
                lo = mid
            else:
                hi = mid
        return 0.5 * (lo + hi), False

    def apply_degradation(
        self,
        dt_s: float,
        current_a: float,
        temperature_k: float,
        params: DegradationParams,
    ) -> None:
        for cell in self.cells:
            cell.apply_degradation(dt_s, current_a, temperature_k, params)

    def average_catalyst_loss_fraction(self) -> float:
        if not self.cells:
            return 0.0
        return sum(c.degradation.catalyst_loss_fraction for c in self.cells) / len(self.cells)

    def average_membrane_resistance_growth(self) -> float:
        if not self.cells:
            return 0.0
        return sum(c.degradation.membrane_resistance_growth_ohm_cm2 for c in self.cells) / len(
            self.cells
        )
