"""
Ties the Nernst open-circuit model and the three loss models together into
a single per-cell voltage calculation, applying the cell's current
degradation state as a modifier on the underlying loss parameters.
"""
from __future__ import annotations

from dataclasses import dataclass

from physics.degradation import DegradationState
from physics.loss_models import (
    ActivationLossParams,
    ConcentrationLossParams,
    OhmicLossParams,
    activation_loss,
    concentration_loss,
    ohmic_loss,
)
from physics.nernst_model import open_circuit_voltage

_MIN_I0 = 1e-6
_MIN_I_LIMIT = 0.02


@dataclass(frozen=True)
class CellElectrochemicalState:
    """The shared operating environment a cell sees (temperature & partial
    pressures of reactants/product). In a stack all cells share this
    environment (well-mixed manifold assumption)."""

    temperature_k: float = 353.15
    p_h2_atm: float = 1.5
    p_o2_atm: float = 0.21
    p_h2o_atm: float = 1.0


@dataclass(frozen=True)
class CellSpec:
    """Nominal (undegraded) electrochemical specification of one cell."""

    active_area_cm2: float = 280.0
    activation_params: ActivationLossParams = ActivationLossParams()
    ohmic_params: OhmicLossParams = OhmicLossParams()
    concentration_params: ConcentrationLossParams = ConcentrationLossParams()
    rated_current_density_a_cm2: float = 0.6


@dataclass(frozen=True)
class CellVoltageBreakdown:
    open_circuit_voltage_v: float
    activation_loss_v: float
    ohmic_loss_v: float
    concentration_loss_v: float
    cell_voltage_v: float
    current_density_a_cm2: float
    saturated: bool  # True if the requested current exceeded the (degraded) limiting current


def effective_loss_params(
    spec: CellSpec, degradation: DegradationState
) -> tuple[ActivationLossParams, OhmicLossParams, ConcentrationLossParams]:
    """Apply the cell's accumulated wear to its nominal loss parameters."""
    activation = ActivationLossParams(
        exchange_current_density_a_cm2=max(
            spec.activation_params.exchange_current_density_a_cm2
            * (1.0 - degradation.catalyst_loss_fraction),
            _MIN_I0,
        ),
        charge_transfer_coefficient=spec.activation_params.charge_transfer_coefficient,
    )
    ohmic = OhmicLossParams(
        area_specific_resistance_ohm_cm2=(
            spec.ohmic_params.area_specific_resistance_ohm_cm2
            + degradation.membrane_resistance_growth_ohm_cm2
        )
    )
    concentration = ConcentrationLossParams(
        limiting_current_density_a_cm2=max(
            spec.concentration_params.limiting_current_density_a_cm2
            * (1.0 - degradation.concentration_derate_fraction),
            _MIN_I_LIMIT,
        ),
        empirical_coefficient_v=spec.concentration_params.empirical_coefficient_v,
    )
    return activation, ohmic, concentration


def cell_voltage(
    current_a: float,
    spec: CellSpec,
    environment: CellElectrochemicalState,
    degradation: DegradationState,
) -> CellVoltageBreakdown:
    """Compute the single-cell voltage (and loss breakdown) for a given
    terminal current, temperature/pressure environment and wear state."""
    ocv = open_circuit_voltage(
        environment.temperature_k,
        environment.p_h2_atm,
        environment.p_o2_atm,
        environment.p_h2o_atm,
    )

    activation_p, ohmic_p, concentration_p = effective_loss_params(spec, degradation)

    current_density = max(current_a, 0.0) / spec.active_area_cm2
    saturated = current_density >= concentration_p.limiting_current_density_a_cm2

    v_act = activation_loss(current_density, environment.temperature_k, activation_p)
    v_ohm = ohmic_loss(current_density, ohmic_p)

    if saturated:
        # Cell cannot sustain this current density: mass transport has
        # collapsed and the cell voltage goes to zero.
        v_conc = max(0.0, ocv - v_act - v_ohm)
        cell_v = 0.0
    else:
        v_conc = concentration_loss(current_density, concentration_p)
        cell_v = max(0.0, ocv - v_act - v_ohm - v_conc)

    return CellVoltageBreakdown(
        open_circuit_voltage_v=ocv,
        activation_loss_v=v_act,
        ohmic_loss_v=v_ohm,
        concentration_loss_v=v_conc,
        cell_voltage_v=cell_v,
        current_density_a_cm2=current_density,
        saturated=saturated,
    )
