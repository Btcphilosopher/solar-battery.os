"""
Bridges electrical current to molar reactant/product flow rates (Faraday's
law) and heat generation, and computes the fuel/oxidant supply limits on
achievable stack current.
"""
from __future__ import annotations

from dataclasses import dataclass

from physics.thermodynamics import (
    ELECTRONS_PER_H2,
    ELECTRONS_PER_O2,
    FARADAY_CONSTANT,
    hydrogen_consumption_rate_mol_s,
    oxygen_consumption_rate_mol_s,
    thermoneutral_voltage,
    water_production_rate_mol_s,
)


@dataclass(frozen=True)
class ReactionRates:
    hydrogen_consumed_mol_s: float
    oxygen_consumed_mol_s: float
    water_produced_mol_s: float
    heat_generated_w: float


def compute_reaction_rates(
    current_a: float,
    n_cells: int,
    average_cell_voltage_v: float,
    use_hhv: bool = True,
) -> ReactionRates:
    """Stack-level reactant consumption and heat generation for `n_cells`
    identical-current cells (series stack: same current through all cells)
    each operating at `average_cell_voltage_v`."""
    h2_per_cell = hydrogen_consumption_rate_mol_s(current_a)
    o2_per_cell = oxygen_consumption_rate_mol_s(current_a)
    h2o_per_cell = water_production_rate_mol_s(current_a)

    v_tn = thermoneutral_voltage(use_hhv)
    heat_w = n_cells * max(current_a, 0.0) * max(v_tn - average_cell_voltage_v, 0.0)

    return ReactionRates(
        hydrogen_consumed_mol_s=h2_per_cell * n_cells,
        oxygen_consumed_mol_s=o2_per_cell * n_cells,
        water_produced_mol_s=h2o_per_cell * n_cells,
        heat_generated_w=heat_w,
    )


def max_current_from_hydrogen_supply(hydrogen_available_mol_s: float, n_cells: int) -> float:
    """Largest stack current sustainable by a given available H2 molar
    flow, assuming that flow is shared identically across the `n_cells`
    series-connected cells (each cell sees the same current)."""
    if n_cells <= 0:
        return 0.0
    return max(hydrogen_available_mol_s, 0.0) * (ELECTRONS_PER_H2 * FARADAY_CONSTANT) / n_cells


def max_current_from_oxygen_supply(oxygen_available_mol_s: float, n_cells: int) -> float:
    """Largest stack current sustainable by a given available O2 molar flow."""
    if n_cells <= 0:
        return 0.0
    return max(oxygen_available_mol_s, 0.0) * (ELECTRONS_PER_O2 * FARADAY_CONSTANT) / n_cells
