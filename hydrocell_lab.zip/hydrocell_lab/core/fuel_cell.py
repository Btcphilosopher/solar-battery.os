"""
Single fuel cell: couples a `CellSpec` (nominal electrochemistry) with a
`DegradationState` (accumulated wear) to expose voltage/power queries and
a degradation-update step.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from core.electrochemistry import (
    CellElectrochemicalState,
    CellSpec,
    CellVoltageBreakdown,
    cell_voltage,
)
from physics.degradation import DegradationParams, DegradationState
from physics.degradation import update as update_degradation


@dataclass
class FuelCell:
    """A single hydrogen/air PEM fuel cell."""

    cell_id: str
    spec: CellSpec = field(default_factory=CellSpec)
    degradation: DegradationState = field(default_factory=DegradationState)

    def voltage_at_current(
        self, current_a: float, environment: CellElectrochemicalState
    ) -> CellVoltageBreakdown:
        return cell_voltage(current_a, self.spec, environment, self.degradation)

    def power_at_current(self, current_a: float, environment: CellElectrochemicalState) -> float:
        breakdown = self.voltage_at_current(current_a, environment)
        return breakdown.cell_voltage_v * max(current_a, 0.0)

    def apply_degradation(
        self,
        dt_s: float,
        current_a: float,
        temperature_k: float,
        params: DegradationParams,
    ) -> None:
        current_density = max(current_a, 0.0) / self.spec.active_area_cm2
        update_degradation(
            self.degradation,
            dt_s,
            current_density,
            self.spec.rated_current_density_a_cm2,
            temperature_k,
            params,
        )
