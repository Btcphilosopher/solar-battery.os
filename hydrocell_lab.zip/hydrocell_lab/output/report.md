# HydroCell Lab - Experiment Report

## Configuration
- Stack size: **50 cells**
- Active area per cell: **280 cm^2**
- Hydrogen supply: **0.800 kg/h**
- Cooling target temperature: **80.0 degC**
- Load profile: **vehicle_drive_cycle**
- Duration: **3600 s** (1.00 h), dt = 1.00 s
- Estimated rated stack power: **5.46 kW**

## Energy & Power
- Total electrical energy output: **3.310 kWh**
- Total hydrogen consumed: **0.12245 kg**
- Specific energy: **27.03 kWh/kg H2**
- Average power output: **3310.1 W**
- Peak power output: **5460.0 W**

## Efficiency
- Average overall efficiency (HHV basis): **66.27 %**
- Average voltage efficiency: **69.76 %**
- Average fuel utilisation: **95.00 %**

## Thermal
- Average stack temperature: **58.5 degC**
- Peak stack temperature: **83.0 degC**

## Degradation (this run)
- Average catalyst active-area loss: **0.0095 %**
- Average membrane resistance growth: **0.000048 ohm*cm^2**
- Minimum single-cell voltage observed: **0.9525 V**

## Reliability
- Time spent fuel/oxidant-starved (demand exceeded deliverable power): **0 s** (0.00 % of run)
