"""
HydroCell Lab - entry point.

Run directly:

    python main.py

or import and drive it programmatically:

    from simulation.engine import run_experiment
    result = run_experiment(stack_size=80, hydrogen_flow=1.2, load_profile="peak_shaving")
"""
from __future__ import annotations

import argparse
from pathlib import Path

from analysis.metrics import compute_summary
from analysis.reporting import generate_report, save_report
from analysis.visualisation import (
    plot_degradation,
    plot_efficiency_heatmap,
    plot_polarization_curve,
    plot_time_series,
)
from core.electrochemistry import CellElectrochemicalState
from simulation.engine import SimulationResult, run_experiment


def run_demo(output_dir: str | Path = "output") -> SimulationResult:
    """End-to-end example workflow:

    1. Create a fuel cell stack (via run_experiment's config)
    2. Define hydrogen input
    3. Apply a load profile (vehicle drive cycle)
    4. Run the simulation over time
    5. Output a performance + efficiency report and plots
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    print("HydroCell Lab - running demo experiment (50-cell stack, vehicle drive cycle)...")
    result = run_experiment(
        stack_size=50,
        hydrogen_flow=0.8,
        temperature_target=80,
        load_profile="vehicle_drive_cycle",
        duration_s=3600.0,  # 1 simulated hour
        dt_s=1.0,
        seed=42,
    )

    metrics = compute_summary(result.records, result.config.dt_s)
    report_text = generate_report(result, metrics)
    report_path = save_report(report_text, output_dir / "report.md")
    print(f"Report written to: {report_path}")

    ts_path = plot_time_series(result.records, output_dir / "time_series.png")
    deg_path = plot_degradation(result.records, output_dir / "degradation.png")

    environment = CellElectrochemicalState(
        temperature_k=result.records[-1].temperature_c + 273.15,
        p_h2_atm=1.48,  # representative supply partial pressure
        p_o2_atm=0.21,
    )
    pol_path = plot_polarization_curve(result.stack, environment, output_dir / "polarization_curve.png")
    heat_path = plot_efficiency_heatmap(
        result.stack.cells[0].spec, output_dir / "efficiency_heatmap.png"
    )

    print(f"Plots written to: {ts_path}, {deg_path}, {pol_path}, {heat_path}")
    print()
    print(report_text)

    return result


def main() -> None:
    parser = argparse.ArgumentParser(description="HydroCell Lab hydrogen fuel cell simulator")
    parser.add_argument("--stack-size", type=int, default=50)
    parser.add_argument("--hydrogen-flow", type=float, default=0.8, help="kg/h")
    parser.add_argument("--temperature-target", type=float, default=80.0, help="degC")
    parser.add_argument(
        "--load-profile",
        type=str,
        default="vehicle_drive_cycle",
        choices=["constant", "vehicle_drive_cycle", "grid_fluctuating", "peak_shaving"],
    )
    parser.add_argument("--duration-s", type=float, default=3600.0)
    parser.add_argument("--dt-s", type=float, default=1.0)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output-dir", type=str, default="output")
    parser.add_argument("--demo", action="store_true", help="Run the fixed demo scenario instead")
    args = parser.parse_args()

    if args.demo:
        run_demo(args.output_dir)
        return

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    result = run_experiment(
        stack_size=args.stack_size,
        hydrogen_flow=args.hydrogen_flow,
        temperature_target=args.temperature_target,
        load_profile=args.load_profile,
        duration_s=args.duration_s,
        dt_s=args.dt_s,
        seed=args.seed,
    )
    metrics = compute_summary(result.records, result.config.dt_s)
    report_text = generate_report(result, metrics)
    save_report(report_text, output_dir / "report.md")
    plot_time_series(result.records, output_dir / "time_series.png")
    plot_degradation(result.records, output_dir / "degradation.png")
    print(report_text)


if __name__ == "__main__":
    main()
