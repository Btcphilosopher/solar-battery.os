"""
Summary metrics computed from a completed simulation's TimestepRecord log.
"""
from __future__ import annotations

from dataclasses import dataclass

from physics.thermodynamics import MOLAR_MASS_H2_KG
from simulation.timestep import TimestepRecord


@dataclass(frozen=True)
class ExperimentMetrics:
    duration_s: float
    total_energy_output_wh: float
    total_hydrogen_consumed_kg: float
    avg_power_output_w: float
    peak_power_output_w: float
    avg_overall_efficiency: float
    avg_voltage_efficiency: float
    avg_fuel_utilization: float
    avg_temperature_c: float
    max_temperature_c: float
    final_catalyst_loss_pct: float
    final_membrane_resistance_growth_ohm_cm2: float
    min_cell_voltage_v: float
    fuel_starved_seconds: float
    specific_energy_wh_per_kg_h2: float


def compute_summary(records: list[TimestepRecord], dt_s: float) -> ExperimentMetrics:
    if not records:
        raise ValueError("Cannot compute metrics from an empty record list.")

    n = len(records)
    dt_h = dt_s / 3600.0

    total_energy_wh = sum(r.power_output_w for r in records) * dt_h
    total_h2_mol = sum(r.hydrogen_consumed_mol_s for r in records) * dt_s
    total_h2_kg = total_h2_mol * MOLAR_MASS_H2_KG

    avg_power = sum(r.power_output_w for r in records) / n
    peak_power = max(r.power_output_w for r in records)

    avg_overall_eff = sum(r.overall_efficiency for r in records) / n
    avg_voltage_eff = sum(r.voltage_efficiency for r in records) / n
    avg_fuel_util = sum(r.fuel_utilization for r in records) / n

    avg_temp_c = sum(r.temperature_c for r in records) / n
    max_temp_c = max(r.temperature_c for r in records)

    final = records[-1]
    min_cell_v = min(r.min_cell_voltage_v for r in records)
    starved_seconds = sum(dt_s for r in records if r.fuel_starved)

    specific_energy = total_energy_wh / total_h2_kg if total_h2_kg > 0 else 0.0

    return ExperimentMetrics(
        duration_s=n * dt_s,
        total_energy_output_wh=total_energy_wh,
        total_hydrogen_consumed_kg=total_h2_kg,
        avg_power_output_w=avg_power,
        peak_power_output_w=peak_power,
        avg_overall_efficiency=avg_overall_eff,
        avg_voltage_efficiency=avg_voltage_eff,
        avg_fuel_utilization=avg_fuel_util,
        avg_temperature_c=avg_temp_c,
        max_temperature_c=max_temp_c,
        final_catalyst_loss_pct=final.avg_catalyst_loss_fraction * 100.0,
        final_membrane_resistance_growth_ohm_cm2=final.avg_membrane_resistance_growth_ohm_cm2,
        min_cell_voltage_v=min_cell_v,
        fuel_starved_seconds=starved_seconds,
        specific_energy_wh_per_kg_h2=specific_energy,
    )
