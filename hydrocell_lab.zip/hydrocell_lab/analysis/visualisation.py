"""
Matplotlib-only visualisation helpers. Each function saves a figure to
disk and returns the path, so they compose easily in scripts/notebooks.
"""
from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")  # headless-safe backend
import matplotlib.pyplot as plt
import numpy as np

from core.electrochemistry import CellElectrochemicalState, CellSpec, cell_voltage
from core.fuel_stack import FuelCellStack
from physics.degradation import DegradationState
from physics.efficiency import voltage_efficiency
from physics.thermodynamics import thermoneutral_voltage
from simulation.timestep import TimestepRecord

_FIGSIZE = (10, 6)


def _save(fig: plt.Figure, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(path, dpi=140)
    plt.close(fig)
    return path


def plot_time_series(records: list[TimestepRecord], path: str | Path) -> Path:
    """4-panel time series: power (demand vs output), stack voltage &
    current, temperature, and efficiency."""
    t = np.array([r.time_s for r in records]) / 60.0  # minutes

    fig, axes = plt.subplots(4, 1, figsize=(10, 12), sharex=True)

    axes[0].plot(t, [r.power_demand_w for r in records], label="Demand", color="tab:gray", lw=1)
    axes[0].plot(t, [r.power_output_w for r in records], label="Output", color="tab:blue", lw=1.5)
    axes[0].set_ylabel("Power (W)")
    axes[0].legend(loc="upper right")
    axes[0].set_title("Power demand vs. delivered power")

    ax1 = axes[1]
    ax1.plot(t, [r.stack_voltage_v for r in records], color="tab:red", lw=1.5, label="Stack voltage (V)")
    ax1.set_ylabel("Voltage (V)", color="tab:red")
    ax2 = ax1.twinx()
    ax2.plot(t, [r.current_a for r in records], color="tab:green", lw=1.2, label="Current (A)")
    ax2.set_ylabel("Current (A)", color="tab:green")
    ax1.set_title("Stack voltage & current")

    axes[2].plot(t, [r.temperature_c for r in records], color="tab:orange", lw=1.5)
    axes[2].set_ylabel("Temperature (degC)")
    axes[2].set_title("Stack temperature")

    axes[3].plot(t, [r.overall_efficiency * 100 for r in records], color="tab:purple", lw=1.5)
    axes[3].set_ylabel("Overall efficiency (%)")
    axes[3].set_xlabel("Time (min)")
    axes[3].set_title("Overall (HHV) efficiency")

    fig.suptitle("HydroCell Lab - Time Series", y=1.0)
    return _save(fig, path)


def plot_degradation(records: list[TimestepRecord], path: str | Path) -> Path:
    t = np.array([r.time_s for r in records]) / 3600.0  # hours

    fig, axes = plt.subplots(2, 1, figsize=_FIGSIZE, sharex=True)
    axes[0].plot(t, [r.avg_catalyst_loss_fraction * 100 for r in records], color="tab:red")
    axes[0].set_ylabel("Catalyst active-area loss (%)")
    axes[0].set_title("Catalyst degradation over time")

    axes[1].plot(t, [r.avg_membrane_resistance_growth_ohm_cm2 for r in records], color="tab:brown")
    axes[1].set_ylabel("Membrane resistance growth\n(ohm*cm^2)")
    axes[1].set_xlabel("Time (h)")
    axes[1].set_title("Membrane fatigue over time")

    fig.suptitle("HydroCell Lab - Degradation Trends", y=1.0)
    return _save(fig, path)


def plot_polarization_curve(
    stack: FuelCellStack,
    environment: CellElectrochemicalState,
    path: str | Path,
    n_points: int = 120,
) -> Path:
    """Classic fuel-cell polarisation curve: stack voltage and power vs.
    current, swept across the stack's safe operating current range."""
    safe_limit_a = 0.97 * stack.min_limiting_current_a(environment)
    currents = np.linspace(0.0, safe_limit_a, n_points)
    voltages = np.array([stack.stack_voltage_at_current(i, environment) for i in currents])
    powers = voltages * currents

    fig, ax1 = plt.subplots(figsize=_FIGSIZE)
    ax1.plot(currents, voltages, color="tab:red", label="Stack voltage (V)")
    ax1.set_xlabel("Current (A)")
    ax1.set_ylabel("Voltage (V)", color="tab:red")
    ax1.set_title("Stack Polarisation Curve")

    ax2 = ax1.twinx()
    ax2.plot(currents, powers / 1000.0, color="tab:blue", label="Power (kW)")
    ax2.set_ylabel("Power (kW)", color="tab:blue")

    return _save(fig, path)


def plot_efficiency_heatmap(
    spec: CellSpec | None,
    path: str | Path,
    current_density_range_a_cm2: tuple[float, float] = (0.02, 1.2),
    temperature_range_c: tuple[float, float] = (30.0, 95.0),
    n_points: int = 60,
    use_hhv: bool = True,
) -> Path:
    """Voltage-efficiency heatmap over (current density, temperature),
    for a single nominal (undegraded) cell - useful for identifying the
    sweet spot of operating conditions."""
    spec = spec or CellSpec()
    degradation = DegradationState()

    i_vals = np.linspace(*current_density_range_a_cm2, n_points)
    t_vals_c = np.linspace(*temperature_range_c, n_points)
    v_tn = thermoneutral_voltage(use_hhv)

    eff_grid = np.zeros((n_points, n_points))
    for row, t_c in enumerate(t_vals_c):
        env = CellElectrochemicalState(temperature_k=t_c + 273.15, p_h2_atm=1.5, p_o2_atm=0.21)
        for col, i_density in enumerate(i_vals):
            current_a = i_density * spec.active_area_cm2
            breakdown = cell_voltage(current_a, spec, env, degradation)
            eff_grid[row, col] = voltage_efficiency(breakdown.cell_voltage_v, v_tn) * 100.0

    fig, ax = plt.subplots(figsize=_FIGSIZE)
    im = ax.imshow(
        eff_grid,
        origin="lower",
        aspect="auto",
        extent=[i_vals[0], i_vals[-1], t_vals_c[0], t_vals_c[-1]],
        cmap="viridis",
    )
    ax.set_xlabel("Current density (A/cm^2)")
    ax.set_ylabel("Temperature (degC)")
    ax.set_title("Voltage Efficiency Heatmap")
    fig.colorbar(im, ax=ax, label="Voltage efficiency (%)")

    return _save(fig, path)
