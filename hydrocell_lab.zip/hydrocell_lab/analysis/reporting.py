"""
Generates a human-readable Markdown performance/efficiency report from a
completed SimulationResult and its ExperimentMetrics.
"""
from __future__ import annotations

from pathlib import Path

from analysis.metrics import ExperimentMetrics
from simulation.engine import SimulationResult


def generate_report(result: SimulationResult, metrics: ExperimentMetrics) -> str:
    cfg = result.config
    lines: list[str] = []
    a = lines.append

    a("# HydroCell Lab - Experiment Report")
    a("")
    a("## Configuration")
    a(f"- Stack size: **{cfg.stack_size} cells**")
    a(f"- Active area per cell: **{cfg.active_area_cm2:.0f} cm^2**")
    a(f"- Hydrogen supply: **{cfg.hydrogen_flow_kg_per_hour:.3f} kg/h**")
    a(f"- Cooling target temperature: **{cfg.temperature_target_c:.1f} degC**")
    a(f"- Load profile: **{cfg.load_profile}**")
    a(f"- Duration: **{cfg.duration_s:.0f} s** ({cfg.duration_s/3600:.2f} h), dt = {cfg.dt_s:.2f} s")
    a(f"- Estimated rated stack power: **{result.rated_power_w/1000:.2f} kW**")
    a("")
    a("## Energy & Power")
    a(f"- Total electrical energy output: **{metrics.total_energy_output_wh/1000:.3f} kWh**")
    a(f"- Total hydrogen consumed: **{metrics.total_hydrogen_consumed_kg:.5f} kg**")
    a(f"- Specific energy: **{metrics.specific_energy_wh_per_kg_h2/1000:.2f} kWh/kg H2**")
    a(f"- Average power output: **{metrics.avg_power_output_w:.1f} W**")
    a(f"- Peak power output: **{metrics.peak_power_output_w:.1f} W**")
    a("")
    a("## Efficiency")
    a(f"- Average overall efficiency (HHV basis): **{metrics.avg_overall_efficiency*100:.2f} %**")
    a(f"- Average voltage efficiency: **{metrics.avg_voltage_efficiency*100:.2f} %**")
    a(f"- Average fuel utilisation: **{metrics.avg_fuel_utilization*100:.2f} %**")
    a("")
    a("## Thermal")
    a(f"- Average stack temperature: **{metrics.avg_temperature_c:.1f} degC**")
    a(f"- Peak stack temperature: **{metrics.max_temperature_c:.1f} degC**")
    a("")
    a("## Degradation (this run)")
    a(f"- Average catalyst active-area loss: **{metrics.final_catalyst_loss_pct:.4f} %**")
    a(
        "- Average membrane resistance growth: "
        f"**{metrics.final_membrane_resistance_growth_ohm_cm2:.6f} ohm*cm^2**"
    )
    a(f"- Minimum single-cell voltage observed: **{metrics.min_cell_voltage_v:.4f} V**")
    a("")
    a("## Reliability")
    a(
        f"- Time spent fuel/oxidant-starved (demand exceeded deliverable power): "
        f"**{metrics.fuel_starved_seconds:.0f} s** "
        f"({100*metrics.fuel_starved_seconds/max(metrics.duration_s,1e-9):.2f} % of run)"
    )
    a("")
    return "\n".join(lines)


def save_report(text: str, path: str | Path) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    return path
