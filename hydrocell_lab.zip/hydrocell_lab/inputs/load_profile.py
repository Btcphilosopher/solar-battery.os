"""
Electrical load profiles: given a simulation time `t_s`, return the
instantaneous power demand (W) the stack must deliver. All profiles are
deterministic functions of time (seeded where randomness is used) so
simulations are reproducible.
"""
from __future__ import annotations

import math
import random
from abc import ABC, abstractmethod
from dataclasses import dataclass, field


class LoadProfile(ABC):
    name: str = "load_profile"

    @abstractmethod
    def power_demand_w(self, t_s: float) -> float:
        """Instantaneous power demand in watts at simulation time t_s."""
        raise NotImplementedError


@dataclass
class ConstantLoad(LoadProfile):
    power_w: float
    name: str = field(default="constant", init=False)

    def power_demand_w(self, t_s: float) -> float:
        return max(self.power_w, 0.0)


@dataclass
class VehicleDriveCycle(LoadProfile):
    """A synthetic urban+highway drive cycle scaled to a fraction of the
    stack's rated power. Not a literal recorded drive-cycle trace (WLTP/
    UDDS), but reproduces the qualitative shape: idle periods, repeated
    acceleration bursts, cruise, and a sustained highway-power plateau."""

    rated_power_w: float
    cycle_period_s: float = 300.0
    name: str = field(default="vehicle_drive_cycle", init=False)

    def power_demand_w(self, t_s: float) -> float:
        phase = (t_s % self.cycle_period_s) / self.cycle_period_s
        base = 0.5 + 0.30 * math.sin(2 * math.pi * phase * 3) + 0.12 * math.sin(
            2 * math.pi * phase * 7 + 1.0
        )
        accel_kick = 0.30 * math.exp(-(((phase - 0.12) * 18) ** 2))
        accel_kick += 0.20 * math.exp(-(((phase - 0.5) * 18) ** 2))
        highway = 0.25 if 0.62 < phase < 0.88 else 0.0
        fraction = max(0.05, min(1.0, base + accel_kick + highway))
        return self.rated_power_w * fraction


@dataclass
class FluctuatingGridDemand(LoadProfile):
    """A grid-balancing-style load built from several seeded random
    sinusoidal components at different frequencies plus small seeded
    noise, so it fluctuates unpredictably but reproducibly."""

    rated_power_w: float
    seed: int = 42
    base_fraction: float = 0.55
    name: str = field(default="grid_fluctuating", init=False)
    _components: list[tuple[float, float, float]] = field(default_factory=list, init=False, repr=False)

    def __post_init__(self) -> None:
        rng = random.Random(self.seed)
        self._components = [
            (
                rng.uniform(0.03, 0.12),  # amplitude fraction
                rng.uniform(1.0 / 600.0, 1.0 / 40.0),  # frequency Hz
                rng.uniform(0, 2 * math.pi),  # phase
            )
            for _ in range(5)
        ]

    def power_demand_w(self, t_s: float) -> float:
        fraction = self.base_fraction
        for amplitude, freq_hz, phase in self._components:
            fraction += amplitude * math.sin(2 * math.pi * freq_hz * t_s + phase)
        fraction = max(0.08, min(1.0, fraction))
        return self.rated_power_w * fraction


@dataclass
class PeakShavingScenario(LoadProfile):
    """Steady base load punctuated by defined high-demand peak windows
    that a fuel cell stack is dispatched to shave (e.g. behind-the-meter
    peak-demand-charge reduction)."""

    rated_power_w: float
    base_fraction: float = 0.25
    peak_fraction: float = 0.95
    peak_windows_s: tuple[tuple[float, float], ...] = ((600.0, 900.0), (1800.0, 2100.0))
    name: str = field(default="peak_shaving", init=False)

    def power_demand_w(self, t_s: float) -> float:
        for start, end in self.peak_windows_s:
            if start <= t_s < end:
                return self.rated_power_w * self.peak_fraction
        return self.rated_power_w * self.base_fraction


_REGISTRY = {
    "constant": lambda rated_power_w, **kw: ConstantLoad(rated_power_w * kw.get("fraction", 0.6)),
    "vehicle_drive_cycle": lambda rated_power_w, **kw: VehicleDriveCycle(
        rated_power_w, cycle_period_s=kw.get("cycle_period_s", 300.0)
    ),
    "grid_fluctuating": lambda rated_power_w, **kw: FluctuatingGridDemand(
        rated_power_w, seed=kw.get("seed", 42), base_fraction=kw.get("base_fraction", 0.55)
    ),
    "peak_shaving": lambda rated_power_w, **kw: PeakShavingScenario(
        rated_power_w,
        base_fraction=kw.get("base_fraction", 0.25),
        peak_fraction=kw.get("peak_fraction", 0.95),
        peak_windows_s=kw.get("peak_windows_s", ((600.0, 900.0), (1800.0, 2100.0))),
    ),
}


def get_load_profile(name: str, rated_power_w: float, **kwargs) -> LoadProfile:
    try:
        factory = _REGISTRY[name]
    except KeyError as exc:
        raise ValueError(
            f"Unknown load profile '{name}'. Available: {sorted(_REGISTRY)}"
        ) from exc
    return factory(rated_power_w, **kwargs)
