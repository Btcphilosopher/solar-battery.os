"""
Hydrogen supply model: a metering regulator with a rated maximum molar
flow capacity, supply pressure and purity.

Real balance-of-plant hydrogen delivery is closed-loop: an injector or
proportional regulator (often with anode recirculation) meters flow to
track the stack's actual reaction demand at a target fuel-utilisation
setpoint (typically 90-98%), rather than sitting at a fixed valve
position. This model reproduces that: `metered_flow_mol_s` returns the
flow the regulator would deliver for a given instantaneous demand, capped
by `max_flow_mol_s` (the physical capacity of the supply line/tank
regulator). When demand would require more than that capacity, delivery
saturates at the capacity and the stack becomes fuel-starved - this is how
`hydrogen_flow` sizing genuinely limits achievable peak power.

Pressure is handled as a simplified scaling factor on the anode partial
pressure fed into the Nernst equation (higher supply pressure -> higher
reactant activity -> higher open-circuit voltage), rather than full gas-
dynamics/pressure-drop modelling.
"""
from __future__ import annotations

from dataclasses import dataclass

from physics.thermodynamics import ATM_PER_BAR, MOLAR_MASS_H2_KG


@dataclass
class HydrogenInlet:
    max_flow_mol_s: float
    supply_pressure_bar: float = 1.5
    purity: float = 0.999
    fuel_utilization_target: float = 0.95

    @classmethod
    def from_mass_flow(
        cls,
        kg_per_s: float,
        supply_pressure_bar: float = 1.5,
        purity: float = 0.999,
        fuel_utilization_target: float = 0.95,
    ) -> "HydrogenInlet":
        return cls(kg_per_s / MOLAR_MASS_H2_KG, supply_pressure_bar, purity, fuel_utilization_target)

    @classmethod
    def from_mass_flow_kg_per_hour(
        cls,
        kg_per_hour: float,
        supply_pressure_bar: float = 1.5,
        purity: float = 0.999,
        fuel_utilization_target: float = 0.95,
    ) -> "HydrogenInlet":
        return cls.from_mass_flow(kg_per_hour / 3600.0, supply_pressure_bar, purity, fuel_utilization_target)

    def max_flow_rate_mol_s(self, t_s: float = 0.0) -> float:
        """The largest molar hydrogen flow the regulator can deliver at
        time `t_s`. Currently constant; override/subclass for time-varying
        capacity scenarios (e.g. tank depletion)."""
        return max(self.max_flow_mol_s, 0.0) * self.purity

    def metered_flow_mol_s(self, desired_consumption_mol_s: float, t_s: float = 0.0) -> float:
        """Flow the regulator actually delivers to satisfy
        `desired_consumption_mol_s` of reaction demand at the target
        utilisation, capped at the line's maximum capacity."""
        target = max(desired_consumption_mol_s, 0.0) / max(self.fuel_utilization_target, 1e-6)
        return min(target, self.max_flow_rate_mol_s(t_s))

    def partial_pressure_atm(self) -> float:
        """Simplified pressure scaling: anode partial pressure tracks
        supply pressure linearly, discounted by purity."""
        return self.supply_pressure_bar * ATM_PER_BAR * self.purity
