"""
Air (oxidant) supply model. The compressor/blower closes the loop on
excess-air ratio (lambda): it meters air flow to track the stack's
instantaneous oxygen demand at a target stoichiometric excess, capped by
the blower's rated maximum flow capacity - mirroring how PEMFC air
subsystems are actually controlled.
"""
from __future__ import annotations

from dataclasses import dataclass

from physics.thermodynamics import ATM_PER_BAR

O2_MOLE_FRACTION: float = 0.2095


@dataclass
class AirInlet:
    max_flow_mol_s: float
    supply_pressure_bar: float = 1.5
    excess_air_ratio: float = 2.0  # lambda: supplied O2 / stoichiometrically required O2

    @classmethod
    def sized_for_hydrogen_flow(
        cls,
        hydrogen_flow_mol_s: float,
        excess_air_ratio: float = 2.0,
        supply_pressure_bar: float = 1.5,
        headroom_factor: float = 1.5,
    ) -> "AirInlet":
        """Size the blower's rated capacity so it can comfortably deliver
        `excess_air_ratio` times the stoichiometric O2 demand of a stack
        drawing up to `headroom_factor` times `hydrogen_flow_mol_s` of H2
        (stoichiometry: 1 mol O2 per 2 mol H2), leaving headroom above the
        nominal design point so the compressor is rarely the binding
        constraint (as is typical - the H2 supply line is usually sized
        tighter than the air blower)."""
        stoich_o2_mol_s = 0.5 * max(hydrogen_flow_mol_s, 0.0) * headroom_factor
        required_o2_mol_s = stoich_o2_mol_s * excess_air_ratio
        max_air_flow = required_o2_mol_s / O2_MOLE_FRACTION
        return cls(max_air_flow, supply_pressure_bar, excess_air_ratio)

    def max_oxygen_flow_mol_s(self, t_s: float = 0.0) -> float:
        return max(self.max_flow_mol_s, 0.0) * O2_MOLE_FRACTION

    def metered_oxygen_flow_mol_s(self, desired_consumption_mol_s: float, t_s: float = 0.0) -> float:
        """O2 flow the blower delivers to satisfy `desired_consumption_mol_s`
        of reaction demand at the target excess-air ratio, capped at the
        blower's maximum capacity."""
        target = max(desired_consumption_mol_s, 0.0) * self.excess_air_ratio
        return min(target, self.max_oxygen_flow_mol_s(t_s))

    def partial_pressure_o2_atm(self) -> float:
        return self.supply_pressure_bar * ATM_PER_BAR * O2_MOLE_FRACTION
