# ELECTROCOMBUSTION -- architecture

## The problem this solves

Systems where electrical, thermal, chemical and mechanical energy interact are
usually modelled one domain at a time and stitched together afterwards. The
stitching is where the errors live: a joule that leaves the electrical domain
and never arrives in the thermal one is invisible to both models.

ELECTROCOMBUSTION makes the *coupling* the primary object. Every physical
model emits directed power flows between named domains, and a ledger integrates
them. Conservation is not assumed; it is computed and reported.

## The six domains

| Domain | Bounded? | Stored energy |
|---|---|---|
| `SOURCE` | no | -- (an external reservoir) |
| `CHEMICAL` | yes | fuel LHV in the charge |
| `ELECTRICAL` | yes | battery / capacitor / inductor |
| `THERMAL` | yes | `m·cv·T` |
| `MECHANICAL` | yes | `½Iω²` |
| `ENVIRONMENT` | no | -- (an external sink) |

`SOURCE` and `ENVIRONMENT` are deliberately unbounded. Everything the model
does not track in detail -- the fuel tank, the grid, the atmosphere -- lives
there, which is what lets the four internal domains be checked exactly.

A `PowerFlow` is `(source_domain, target_domain, watts, label, component)` with
`watts >= 0` by convention: direction is always explicit, never a sign. Useful
output is distinguished from loss by the label `"load"`, not by which domain it
enters, because "electrical power leaving to the environment" describes both a
delivered kilowatt-hour and a resistive loss.

## Component purity

Every physical model is a `Component` whose `evaluate(state, dt, context)` is a
**pure function of state**: it returns a `ComponentOutput` (flows, derivatives,
diagnostics, events, severity) and mutates nothing.

This is what makes three otherwise awkward things straightforward:

- **Multi-stage integrators.** RK4 evaluates every component four times per
  step at different probe states. A component that mutated internal state
  would corrupt itself.
- **Step rejection.** Adaptive stepping tries a step, measures the error and
  may discard it. Discarding is free when nothing was mutated.
- **Speculative rollouts.** The MPC controller rolls the whole plant forward
  over a horizon, many times, per timestep. It uses `engine._trial`, which
  runs with `Context.speculative = True` so that one-shot events are not
  published from a hypothetical future.

## Conservation, and where it is exact

Thermal stored energy is `m·cv·T`, so `dU/dt = Q` **exactly**; solids set
`gas_constant = 0` so that `cv == cp`. The same Butcher weights are used for
the state update and for the flow accounting, so integrated flows and stored
energy agree to machine precision. In the reference case (a nichrome element
on 230 V heating 2 kg of steel with convective loss, 600 s at dt 0.05, RK4)
`input − losses − stored` is exactly `0.0`.

The mechanical term is quadratic in the state (`½Iω²` against `ω·τ`), so a
finite step introduces a genuine `O(dt²)` discrepancy. That residual is
**reported, not hidden**: `StepReport.conservation_residual` carries it, and
`EngineConfig.check_conservation` raises a `WARNING` event when it exceeds
tolerance. A framework that silently absorbed it would be lying about its own
accuracy.

## Layering

```
core/          units, state, flows, ledger, components, engine, events, timestep
  ↓
materials/     temperature-dependent property models + a 17-entry library
  ↓
electrical/  thermal/  combustion/  mechanical/     physics libraries
  ↓
systems/       assembled machines (genset, engine, heater, hybrid, recovery)
  ↓
optimisation/  simulation/  faults/  telemetry/     the machinery around them
  ↓
twin.py  api/  visualisation/                        interfaces
```

Each layer depends only on the ones above it. `core` imports nothing from the
physics libraries, which is why the engine can integrate a model it knows
nothing about.

## Fidelity

`Fidelity.FAST | STANDARD | DETAILED` is passed through `Context` and is
available to every component. Components that have no cheaper approximation
ignore it, which is the honest behaviour: a fidelity flag that silently does
nothing is better than one that pretends to.

## Extension points

- **Reaction chemistry.** `ReactionMechanism` is a `Protocol`. Anything with
  `rate(progress, temperature, pressure, mixture, dt)` can replace the built-in
  Wiebe / Arrhenius / eddy-dissipation models, including a wrapper around a
  detailed kinetics solver.
- **Materials.** `PropertyModel` covers constant, linear-coefficient,
  polynomial, tabulated and Arrhenius forms; `as_property` accepts a bare float.
- **Transport.** `api/service.py` is framework-agnostic. The FastAPI adapter
  and the stdlib `http.server` fallback are both optional and lazily imported.
