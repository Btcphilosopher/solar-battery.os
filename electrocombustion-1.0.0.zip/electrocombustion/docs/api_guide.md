# Quick reference

## Building and running a model

```python
from electrocombustion import ElectroCombustionEngine, EngineConfig, SystemState
from electrocombustion.electrical import DCSource, Geometry, Resistor, ResistiveHeater
from electrocombustion.materials import NICHROME
from electrocombustion.thermal import ConvectionSurface, SurfaceLoss

state = SystemState()
state.thermal.mass = 2.0
state.thermal.specific_heat = 450.0
state.thermal.gas_constant = 0.0          # a solid: cv == cp
state.thermal.temperature = 300.0
state.ambient_temperature = 300.0

engine = ElectroCombustionEngine(state, config=EngineConfig(scheme="rk4"))
engine.add(ResistiveHeater(
    "heater",
    Resistor("element", material=NICHROME, geometry=Geometry.wire(5.0, 1e-3)),
    DCSource(230.0)))
engine.add(SurfaceLoss("loss", ConvectionSurface(area=0.05, coefficient=15.0)))

result = engine.run(duration=600.0, dt=0.05)
print(result.summary())
```

## Driving inputs

Three ways, in increasing order of power:

```python
engine.run(10.0, 0.01, {"heater.duty": 0.5})              # static mapping
engine.run(10.0, 0.01, lambda t, s: {"heater.duty": t/10})  # callable of time
engine.run(10.0, 0.01, controller=supervisor)              # a controller object
```

A controller is anything with `update(state, dt) -> Mapping[str, float]`.
`SupervisoryController` and `ModelPredictiveController` both satisfy it.

## Optimisation

```python
from electrocombustion.optimisation import (
    DesignVariable, fuel_limit, optimise_operating_point, thermal_limit)

best = optimise_operating_point(
    evaluate,                                   # dict -> dict
    [DesignVariable("fuel_flow", 1e-4, 0.012, initial=0.004),
     DesignVariable("speed", 80.0, 220.0, initial=157.0)],
    [fuel_limit("fuel_flow", 0.008),
     thermal_limit("heat_rejection", 90_000.0)])

print(best.variables, best.objective_value, best.feasible)
```

The solver works in normalised coordinates and constraints are scaled by their
own magnitude, so mixing a fuel flow of 1e-3 with a heat rejection of 1e5 is
not a problem. `method="auto"` runs SLSQP, then differential evolution, then
polishes the global result with SLSQP, and returns the best **feasible**
candidate.

## Sweeps and uncertainty

```python
from electrocombustion.simulation import (
    Distribution, MonteCarlo, Parameter, operating_map)

grid = operating_map(evaluate,
                     Parameter.linear("fuel_flow", 1e-3, 0.01, 40),
                     Parameter.linear("speed", 80.0, 220.0, 25))
xs, ys, z = grid.to_grid("fuel_flow", "speed", "electrical_power")

study = MonteCarlo(evaluate, [Distribution("lhv", "normal", 42.5e6, 1e6)],
                   seed=0)
stats = study.run(4000).statistics("electrical_power")   # mean, std, P10/50/90
```

Sweep failures are captured in `SweepResult.failures` rather than aborting the
run.

## Faults and telemetry

```python
from electrocombustion.faults import FaultClassifier, SensorFault, standard_limits
from electrocombustion.telemetry import Sensor, SensorSpec, TelemetryValidator

classifier = FaultClassifier(standard_limits(max_temperature=1100.0),
                             bus=engine.bus)
diagnosis = classifier.classify(engine.state)
print(diagnosis.explain())
```

## Digital twin

```python
from electrocombustion.telemetry import CSVReplay
from electrocombustion.twin import EnergyTwin

twin = EnergyTwin(engine, {"temperature": lambda s: s.thermal.temperature})
twin.replay(CSVReplay("plant.csv"), dt=1.0)
print(twin.report())
```

## Service layer

```python
from electrocombustion.api import EngineService, SimpleAPIServer, create_app

service = EngineService(build_engine)      # a zero-argument factory
app = create_app(service)                  # FastAPI, if installed
SimpleAPIServer(service).serve_forever()   # stdlib fallback
```

`SimpleAPIServer.handle(method, path, body)` can be called directly, so routing
is testable without binding a port.

## Units

Everything is SI internally. Convert only at the boundary:

```python
from electrocombustion import convert, to_si, from_si
to_si(1500.0, "rpm")        # -> 157.08 rad/s
convert(1.0, "kWh", "MJ")   # -> 3.6
convert(1.0, "m", "kg")     # -> UnitError: different dimensions
```

`"C"` is coulomb. Celsius is `"degC"`.
