# Modelling notes -- what is trustworthy, and what is not

This document exists because the most dangerous thing a simulation can do is
produce a plausible number with no indication of its provenance.

## Simulation-grade vs engineering-validated

**Simulation-grade** means the model reproduces the correct qualitative
behaviour and is within the stated tolerance of textbook reference values.
It is suitable for design exploration, trade studies, control development and
teaching.

**Engineering-validated** means the model has been checked against measured
data from the specific machine being modelled, over the operating range of
interest, by someone accountable for the result.

**Nothing in this package is engineering-validated.** That is not a
disclaimer; it is a statement about what the package is for.

## Where the numbers come from

| Quantity | Basis | Expected accuracy |
|---|---|---|
| Stoichiometric AFR | exact elemental balance | exact for the stated formula |
| Product composition | exact mass balance, two species per element | closes to 1.1e-13 kg/kg fuel |
| Adiabatic flame temperature | first-law, iterated cp, **no dissociation** | +5 to +10 % (runs hot) |
| Air-standard cycle efficiency | closed form | exact for the idealisation |
| Indicated efficiency | air-standard × `quality` factor | as good as the quality factor |
| Conduction / convection / radiation | standard correlations | ±15-25 % typical |
| Dittus-Boelter | fitted Re > 10 000, 0.6 < Pr < 160 | outside range: warns |
| Churchill-Chu | fitted Ra < 1e12 | outside range: warns |
| Material properties | published typical values | ±5-10 %, **not certified data** |
| Machine losses | fractional split at rating, scaled | qualitatively right, quantitatively indicative |
| Thermal NOx | extended Zeldovich | order-of-magnitude, geometry-dependent |
| CO | stoichiometric + quench floor | illustrative only |

## Things the models deliberately do not do

- **No dissociation.** At stoichiometric and above, real flame temperatures are
  capped well below the adiabatic value by CO₂ and H₂O dissociation. The
  adiabatic flame temperature here is an upper bound.
- **No soot.** When there is not enough oxygen even for full conversion to CO,
  the remainder is reported as *unburned fuel*, not as solid carbon. A model
  with two species per element cannot honestly resolve soot.
- **No spatial resolution.** Everything is lumped. Biot numbers are computed
  (`biot_number`, `lumped_capacitance_valid`) so that the assumption can be
  checked, but it is not enforced.
- **No transport delay in flows.** A fuel flow commanded now arrives now.
- **No electromagnetic transients below the RL time constant.**

## The emissions and fault models are not certifications

`EmissionsModel` produces numbers with the right units and the right trends.
It must not be used for regulatory compliance.

`faults/` classifies a simulated operating point against limits *the user
supplied*. `standard_limits()` places warning/limit/fault levels at 85 %, 95 %
and 100 % of a ceiling because that is a common industrial convention, not
because it is safe for any particular machine. This is engineering analysis
support, **not a safety case**.

## Where the model tells you it is unsure

The package prefers raising to guessing:

- `Resistor` raises if given both an abstract resistance and a material +
  geometry, rather than silently preferring one.
- `HeatExchanger.required_ua` raises when the requested duty exceeds what the
  temperature difference allows, rather than returning a huge UA.
- `required_cooling` raises when the coolant is not colder than the body.
- `Shaft.steady_speed` raises when no equilibrium exists in the bracket.
- `Generator.shaft_power_for` raises when the demand cannot be met at that
  speed.
- `find_optimum` raises when no swept point satisfies the constraints, rather
  than returning the least-bad violating point.
- `Optimiser` returns `feasible=False` with the least-violating candidate when
  neither the gradient nor the global search finds a feasible point.
- `correlation_warning` returns a message when a correlation is used outside
  its fitted range.
- `SweepResult.to_grid` fills unevaluated combinations with `nan`, and the text
  renderer draws them as `?`.
