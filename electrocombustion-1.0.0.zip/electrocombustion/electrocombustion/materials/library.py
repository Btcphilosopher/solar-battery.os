"""A library of commonly used engineering materials.

Values are representative textbook figures for bulk material at or near room
temperature, with linear temperature coefficients where the linear form is a
reasonable engineering approximation over a few hundred kelvin.  They are
**simulation-grade defaults, not certified data**: for design work, replace
them with values from the actual material certificate.
"""
from __future__ import annotations

from ..core import units as U
from .material import Material
from .properties import Constant, LinearCoefficient, Polynomial, Table

#: Registry of built-in materials keyed by lowercase name.
_REGISTRY: dict[str, Material] = {}


def register(material: Material, *aliases: str) -> Material:
    """Add ``material`` (and any aliases) to the global registry."""
    _REGISTRY[material.name.lower()] = material
    for alias in aliases:
        _REGISTRY[alias.lower()] = material
    return material


def get_material(name: str) -> Material:
    """Look up a material by name (case-insensitive)."""
    try:
        return _REGISTRY[name.lower()]
    except KeyError as exc:
        raise KeyError(
            f"unknown material {name!r}; available: {sorted(set(m.name for m in _REGISTRY.values()))}"
        ) from exc


def available_materials() -> tuple[str, ...]:
    return tuple(sorted({m.name for m in _REGISTRY.values()}))


# ---------------------------------------------------------------------------
# Conductors
# ---------------------------------------------------------------------------
COPPER = register(Material(
    name="copper",
    resistivity=LinearCoefficient(1.68e-8, 3.93e-3, 293.15),
    thermal_conductivity=Polynomial((413.0, -0.0666), floor=100.0),
    density=8960.0,
    specific_heat=Polynomial((355.0, 0.099)),
    emissivity=0.04,
    melting_point=1357.77,
    max_service_temperature=1200.0,
    temperature_coefficient=3.93e-3,
), "cu")

ALUMINIUM = register(Material(
    name="aluminium",
    resistivity=LinearCoefficient(2.65e-8, 3.90e-3, 293.15),
    thermal_conductivity=Constant(237.0),
    density=2700.0,
    specific_heat=Polynomial((802.0, 0.30)),
    emissivity=0.09,
    melting_point=933.47,
    max_service_temperature=800.0,
    temperature_coefficient=3.90e-3,
), "aluminum", "al")

SILVER = register(Material(
    name="silver",
    resistivity=LinearCoefficient(1.59e-8, 3.80e-3, 293.15),
    thermal_conductivity=Constant(429.0),
    density=10490.0, specific_heat=Constant(235.0), emissivity=0.03,
    melting_point=1234.93, max_service_temperature=1100.0,
    temperature_coefficient=3.80e-3,
), "ag")

TUNGSTEN = register(Material(
    name="tungsten",
    resistivity=LinearCoefficient(5.6e-8, 4.5e-3, 293.15),
    thermal_conductivity=Constant(174.0),
    density=19300.0, specific_heat=Constant(132.0), emissivity=0.32,
    melting_point=3695.0, max_service_temperature=3200.0,
    temperature_coefficient=4.5e-3,
), "w")

NICHROME = register(Material(
    name="nichrome",
    # Ni80Cr20: deliberately low temperature coefficient, which is why it is
    # the standard resistance-heating alloy.
    resistivity=LinearCoefficient(1.10e-6, 1.5e-4, 293.15),
    thermal_conductivity=Constant(11.3),
    density=8400.0, specific_heat=Constant(450.0), emissivity=0.88,
    melting_point=1673.0, max_service_temperature=1473.0,
    temperature_coefficient=1.5e-4,
), "ni80cr20")

KANTHAL = register(Material(
    name="kanthal",
    resistivity=LinearCoefficient(1.45e-6, 5.0e-5, 293.15),
    thermal_conductivity=Constant(11.0),
    density=7100.0, specific_heat=Constant(460.0), emissivity=0.70,
    melting_point=1773.0, max_service_temperature=1573.0,
    temperature_coefficient=5.0e-5,
), "fecral")

# ---------------------------------------------------------------------------
# Structural
# ---------------------------------------------------------------------------
STEEL_CARBON = register(Material(
    name="carbon_steel",
    resistivity=LinearCoefficient(1.43e-7, 6.5e-3, 293.15),
    thermal_conductivity=Polynomial((60.5, -0.03), floor=20.0),
    density=7850.0,
    specific_heat=Polynomial((434.0, 0.15)),
    emissivity=0.80, melting_point=1723.0, max_service_temperature=800.0,
    temperature_coefficient=6.5e-3,
), "steel", "mild_steel")

STAINLESS_304 = register(Material(
    name="stainless_304",
    resistivity=LinearCoefficient(7.2e-7, 1.0e-3, 293.15),
    thermal_conductivity=Polynomial((14.9, 0.0153)),
    density=8000.0, specific_heat=Constant(500.0), emissivity=0.55,
    melting_point=1723.0, max_service_temperature=1140.0,
    temperature_coefficient=1.0e-3,
), "ss304", "stainless")

CAST_IRON = register(Material(
    name="cast_iron",
    resistivity=LinearCoefficient(1.0e-6, 5.0e-3, 293.15),
    thermal_conductivity=Constant(52.0), density=7200.0,
    specific_heat=Constant(490.0), emissivity=0.81,
    melting_point=1470.0, max_service_temperature=900.0,
    temperature_coefficient=5.0e-3,
))

INCONEL_718 = register(Material(
    name="inconel_718",
    resistivity=LinearCoefficient(1.25e-6, 4.0e-4, 293.15),
    thermal_conductivity=Polynomial((11.4, 0.0159)),
    density=8190.0, specific_heat=Constant(435.0), emissivity=0.70,
    melting_point=1609.0, max_service_temperature=1250.0,
    temperature_coefficient=4.0e-4,
), "inconel")

# ---------------------------------------------------------------------------
# Insulators / ceramics
# ---------------------------------------------------------------------------
ALUMINA = register(Material(
    name="alumina",
    resistivity=Constant(1e12),
    thermal_conductivity=Table((300.0, 500.0, 800.0, 1200.0, 1800.0),
                               (30.0, 18.0, 11.0, 7.0, 5.5)),
    density=3950.0, specific_heat=Polynomial((765.0, 0.25)), emissivity=0.45,
    melting_point=2345.0, max_service_temperature=1900.0,
), "al2o3", "ceramic")

FIREBRICK = register(Material(
    name="firebrick",
    resistivity=Constant(1e10), thermal_conductivity=Constant(1.1),
    density=2100.0, specific_heat=Constant(960.0), emissivity=0.75,
    melting_point=2000.0, max_service_temperature=1600.0,
), "refractory")

MINERAL_WOOL = register(Material(
    name="mineral_wool",
    resistivity=Constant(1e12),
    thermal_conductivity=Table((300.0, 500.0, 800.0), (0.040, 0.075, 0.140)),
    density=100.0, specific_heat=Constant(840.0), emissivity=0.90,
    max_service_temperature=1000.0,
), "insulation")

# ---------------------------------------------------------------------------
# Fluids (bulk properties for lumped models)
# ---------------------------------------------------------------------------
AIR = register(Material(
    name="air",
    resistivity=Constant(1e13),
    thermal_conductivity=Polynomial((0.00396, 7.44e-5, -2.5e-8), floor=0.005),
    density=1.184,
    specific_heat=Polynomial((1004.0, -0.0785, 3.0e-4)),
    emissivity=0.0,
    metadata={"note": "density is at 25 degC, 1 atm; use the gas law for other states"},
))

WATER = register(Material(
    name="water",
    resistivity=Constant(2.0e5),
    thermal_conductivity=Constant(0.606),
    density=997.0, specific_heat=Constant(U.CP_WATER), emissivity=0.95,
    max_service_temperature=373.15,
))

ETHYLENE_GLYCOL_50 = register(Material(
    name="glycol_50",
    resistivity=Constant(1e4), thermal_conductivity=Constant(0.40),
    density=1070.0, specific_heat=Constant(3300.0), emissivity=0.95,
    max_service_temperature=400.0,
), "coolant")

THERMAL_OIL = register(Material(
    name="thermal_oil",
    resistivity=Constant(1e11), thermal_conductivity=Constant(0.11),
    density=850.0, specific_heat=Constant(2200.0), emissivity=0.90,
    max_service_temperature=620.0,
), "oil")

#: Convenient grouping used by sweeps and documentation
CONDUCTORS = (COPPER, ALUMINIUM, SILVER, TUNGSTEN, NICHROME, KANTHAL)
STRUCTURAL = (STEEL_CARBON, STAINLESS_304, CAST_IRON, INCONEL_718)
CERAMICS = (ALUMINA, FIREBRICK, MINERAL_WOOL)
FLUIDS = (AIR, WATER, ETHYLENE_GLYCOL_50, THERMAL_OIL)
