"""The :class:`Material` container and its property accessors."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

from ..core import units as U
from .properties import Constant, PropertyModel, as_property


@dataclass(slots=True)
class Material:
    """A named material with temperature-dependent properties.

    All properties may be supplied as plain numbers (treated as constants), as
    callables, or as :class:`~.properties.PropertyModel` instances.

    Parameters
    ----------
    resistivity:
        Electrical resistivity in ohm.m.  ``inf`` marks an insulator.
    thermal_conductivity:
        W/(m.K).
    density:
        kg/m^3, treated as temperature independent (thermal expansion is
        outside the scope of the lumped models here).
    specific_heat:
        J/(kg.K).
    emissivity:
        Total hemispherical emissivity, 0..1.
    melting_point, max_service_temperature:
        K.  Used by the fault model to classify thermal overrun.
    """

    name: str
    resistivity: Any = float("inf")
    thermal_conductivity: Any = 1.0
    density: float = 1000.0
    specific_heat: Any = 1000.0
    emissivity: Any = 0.9
    melting_point: float = float("inf")
    max_service_temperature: float = float("inf")
    temperature_coefficient: float = 0.0
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.density <= 0.0:
            raise ValueError(f"{self.name}: density must be positive")
        self.resistivity = as_property(self.resistivity)
        self.thermal_conductivity = as_property(self.thermal_conductivity)
        self.specific_heat = as_property(self.specific_heat)
        self.emissivity = as_property(self.emissivity)

    # -- property accessors -------------------------------------------------
    def rho_e(self, temperature: float = U.T_STANDARD) -> float:
        """Electrical resistivity (ohm.m)."""
        return self.resistivity(temperature)

    def k(self, temperature: float = U.T_STANDARD) -> float:
        """Thermal conductivity (W/(m.K))."""
        return self.thermal_conductivity(temperature)

    def cp(self, temperature: float = U.T_STANDARD) -> float:
        """Specific heat capacity (J/(kg.K))."""
        return self.specific_heat(temperature)

    def eps(self, temperature: float = U.T_STANDARD) -> float:
        """Emissivity, clamped to the physical range 0..1."""
        return min(1.0, max(0.0, self.emissivity(temperature)))

    @property
    def is_conductor(self) -> bool:
        return self.rho_e(U.T_STANDARD) < 1e-3

    def conductivity_e(self, temperature: float = U.T_STANDARD) -> float:
        """Electrical conductivity (S/m)."""
        rho = self.rho_e(temperature)
        return 1.0 / rho if rho > 0.0 else float("inf")

    def thermal_diffusivity(self, temperature: float = U.T_STANDARD) -> float:
        """alpha = k / (rho * cp) in m^2/s."""
        return self.k(temperature) / (self.density * self.cp(temperature))

    def volumetric_heat_capacity(self, temperature: float = U.T_STANDARD) -> float:
        """rho * cp in J/(m^3.K)."""
        return self.density * self.cp(temperature)

    def within_service_limit(self, temperature: float) -> bool:
        return temperature <= self.max_service_temperature

    def describe(self, temperature: float = U.T_STANDARD) -> dict[str, float | str]:
        return {
            "name": self.name,
            "temperature": temperature,
            "resistivity": self.rho_e(temperature),
            "thermal_conductivity": self.k(temperature),
            "specific_heat": self.cp(temperature),
            "density": self.density,
            "emissivity": self.eps(temperature),
            "thermal_diffusivity": self.thermal_diffusivity(temperature),
        }

    def __repr__(self) -> str:
        return f"Material({self.name!r})"
