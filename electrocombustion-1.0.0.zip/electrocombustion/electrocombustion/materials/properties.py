"""Temperature-dependent material property models.

Properties are expressed as small callable objects so that a material can mix
constant, linear, polynomial and tabulated behaviour without the consumer
needing to know which.  Every model is callable as ``model(T_kelvin)``.
"""
from __future__ import annotations

import bisect
import math
from dataclasses import dataclass, field
from typing import Callable, Sequence


class PropertyModel:
    """Base class for a scalar property as a function of temperature."""

    def __call__(self, temperature: float) -> float:  # pragma: no cover
        raise NotImplementedError

    def derivative(self, temperature: float, h: float = 1e-3) -> float:
        """Central-difference d(property)/dT."""
        return (self(temperature + h) - self(temperature - h)) / (2.0 * h)


@dataclass(slots=True)
class Constant(PropertyModel):
    """A property that does not vary with temperature."""

    value: float

    def __call__(self, temperature: float) -> float:
        return self.value

    def derivative(self, temperature: float, h: float = 1e-3) -> float:
        return 0.0


@dataclass(slots=True)
class LinearCoefficient(PropertyModel):
    """``value = reference * (1 + alpha * (T - T_ref))``.

    This is the standard engineering form for electrical resistivity and is
    clamped to a small positive floor so that extrapolation far below the
    reference temperature cannot produce a non-physical negative value.
    """

    reference: float
    alpha: float
    t_ref: float = 293.15
    floor: float = 1e-12

    def __call__(self, temperature: float) -> float:
        value = self.reference * (1.0 + self.alpha * (temperature - self.t_ref))
        return max(self.floor, value)


@dataclass(slots=True)
class Polynomial(PropertyModel):
    """``value = sum(c_i * T**i)`` with coefficients in ascending order."""

    coefficients: Sequence[float]
    floor: float | None = None

    def __call__(self, temperature: float) -> float:
        value = 0.0
        power = 1.0
        for c in self.coefficients:
            value += c * power
            power *= temperature
        if self.floor is not None:
            return max(self.floor, value)
        return value


@dataclass(slots=True)
class Table(PropertyModel):
    """Piecewise-linear interpolation over a temperature table.

    Outside the tabulated range the endpoint value is held constant, which is
    safer than extrapolating a fitted curve into a region where no data exists.
    """

    temperatures: Sequence[float]
    values: Sequence[float]

    def __post_init__(self) -> None:
        if len(self.temperatures) != len(self.values):
            raise ValueError("temperatures and values must have equal length")
        if len(self.temperatures) < 2:
            raise ValueError("a table needs at least two points")
        if list(self.temperatures) != sorted(self.temperatures):
            raise ValueError("temperatures must be strictly increasing")

    def __call__(self, temperature: float) -> float:
        ts, vs = self.temperatures, self.values
        if temperature <= ts[0]:
            return float(vs[0])
        if temperature >= ts[-1]:
            return float(vs[-1])
        i = bisect.bisect_right(ts, temperature) - 1
        span = ts[i + 1] - ts[i]
        if span <= 0.0:  # pragma: no cover - guarded by __post_init__
            return float(vs[i])
        frac = (temperature - ts[i]) / span
        return float(vs[i] + frac * (vs[i + 1] - vs[i]))


@dataclass(slots=True)
class Arrhenius(PropertyModel):
    """``value = pre_exponential * exp(-activation_energy / (R * T))``."""

    pre_exponential: float
    activation_energy: float
    gas_constant: float = 8.314462618

    def __call__(self, temperature: float) -> float:
        if temperature <= 0.0:
            return 0.0
        return self.pre_exponential * math.exp(
            -self.activation_energy / (self.gas_constant * temperature))


def as_property(value: float | PropertyModel | Callable[[float], float]) -> PropertyModel:
    """Coerce a number, callable or model into a :class:`PropertyModel`."""
    if isinstance(value, PropertyModel):
        return value
    if callable(value):
        return _CallableProperty(value)
    return Constant(float(value))


@dataclass(slots=True)
class _CallableProperty(PropertyModel):
    fn: Callable[[float], float]

    def __call__(self, temperature: float) -> float:
        return float(self.fn(temperature))
