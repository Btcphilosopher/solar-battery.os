"""Configurable materials with temperature-dependent properties."""
from .properties import (
    Arrhenius, Constant, LinearCoefficient, Polynomial, PropertyModel, Table,
    as_property,
)
from .material import Material
from .library import (
    AIR, ALUMINA, ALUMINIUM, CAST_IRON, CERAMICS, CONDUCTORS, COPPER,
    ETHYLENE_GLYCOL_50, FIREBRICK, FLUIDS, INCONEL_718, KANTHAL, MINERAL_WOOL,
    NICHROME, SILVER, STAINLESS_304, STEEL_CARBON, STRUCTURAL, THERMAL_OIL,
    TUNGSTEN, WATER, available_materials, get_material, register,
)

__all__ = [
    "Arrhenius", "Constant", "LinearCoefficient", "Polynomial",
    "PropertyModel", "Table", "as_property", "Material",
    "AIR", "ALUMINA", "ALUMINIUM", "CAST_IRON", "CERAMICS", "CONDUCTORS",
    "COPPER", "ETHYLENE_GLYCOL_50", "FIREBRICK", "FLUIDS", "INCONEL_718",
    "KANTHAL", "MINERAL_WOOL", "NICHROME", "SILVER", "STAINLESS_304",
    "STEEL_CARBON", "STRUCTURAL", "THERMAL_OIL", "TUNGSTEN", "WATER",
    "available_materials", "get_material", "register",
]
