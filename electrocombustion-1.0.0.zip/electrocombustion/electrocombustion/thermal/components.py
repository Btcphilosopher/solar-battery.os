"""Engine-facing thermal components."""
from __future__ import annotations

import math
from dataclasses import dataclass

from ..core import units as U
from ..core.component import Component, ComponentOutput, Context, Derivatives
from ..core.events import Event, Severity
from ..core.state import EnergyDomain, PowerFlow, SystemState
from .convection import ConvectionSurface
from .heat_transfer import CoolingCircuit, HeatExchanger, ThermalBoundary
from .radiation import RadiatingSurface


class ThermalLosses(Component):
    """Heat rejection from the bulk thermal mass to ambient.

    Combines whatever boundary mechanisms are configured and routes the result
    from THERMAL to ENVIRONMENT.  Negative heat flow (ambient hotter than the
    body) is handled correctly and appears as a gain.
    """

    order = 70

    def __init__(self, name: str, boundary: ThermalBoundary) -> None:
        super().__init__(name)
        self.boundary = boundary

    def evaluate(self, state: SystemState, dt: float,
                 context: Context) -> ComponentOutput:
        ambient = context.get(f"{self.name}.ambient", state.ambient_temperature)
        q = self.boundary.heat_flow(state.thermal.temperature, ambient)
        if q >= 0.0:
            flow = PowerFlow(EnergyDomain.THERMAL, EnergyDomain.ENVIRONMENT, q,
                             "heat loss", self.name)
        else:
            flow = PowerFlow(EnergyDomain.SOURCE, EnergyDomain.THERMAL, -q,
                             "ambient heat gain", self.name)
        return ComponentOutput(
            flows=[flow],
            derivatives=Derivatives(heat_input=-q),
            diagnostics={f"{self.name}.heat_loss": q,
                         f"{self.name}.ambient": ambient},
        )


class SurfaceLoss(Component):
    """Convective and radiative loss from a simple surface."""

    order = 70

    def __init__(self, name: str, convection: ConvectionSurface | None = None,
                 radiation: RadiatingSurface | None = None) -> None:
        super().__init__(name)
        if convection is None and radiation is None:
            raise ValueError(f"{name}: give at least one loss mechanism")
        self.convection = convection
        self.radiation = radiation

    def evaluate(self, state: SystemState, dt: float,
                 context: Context) -> ComponentOutput:
        t = state.thermal.temperature
        ambient = context.get(f"{self.name}.ambient", state.ambient_temperature)
        q_conv = self.convection.heat_flow(t, ambient) if self.convection else 0.0
        q_rad = self.radiation.heat_flow(t, ambient) if self.radiation else 0.0
        q = q_conv + q_rad
        flows = []
        if q >= 0.0:
            flows.append(PowerFlow(EnergyDomain.THERMAL, EnergyDomain.ENVIRONMENT,
                                   q, "surface loss", self.name))
        else:
            flows.append(PowerFlow(EnergyDomain.SOURCE, EnergyDomain.THERMAL,
                                   -q, "ambient heat gain", self.name))
        return ComponentOutput(
            flows=flows,
            derivatives=Derivatives(heat_input=-q),
            diagnostics={f"{self.name}.convective": q_conv,
                         f"{self.name}.radiative": q_rad},
        )


class CoolingLoop(Component):
    """Active cooling with a commandable flow fraction.

    The pump power is drawn from the electrical source, so turning up cooling
    to protect a component has an honest efficiency cost in the ledger rather
    than being free.
    """

    order = 75

    def __init__(self, name: str, circuit: CoolingCircuit,
                 input_key: str | None = None) -> None:
        super().__init__(name)
        self.circuit = circuit
        self.input_key = input_key or f"{name}.flow"

    def evaluate(self, state: SystemState, dt: float,
                 context: Context) -> ComponentOutput:
        fraction = min(1.0, max(0.0, context.get(self.input_key,
                                                 self.circuit.flow_fraction)))
        previous = self.circuit.flow_fraction
        self.circuit.flow_fraction = fraction
        try:
            q = self.circuit.heat_removed(state.thermal.temperature)
            outlet = self.circuit.outlet_temperature(state.thermal.temperature)
        finally:
            self.circuit.flow_fraction = previous
        pump = self.circuit.pump_power * fraction
        flows = []
        if q >= 0.0:
            flows.append(PowerFlow(EnergyDomain.THERMAL, EnergyDomain.ENVIRONMENT,
                                   q, "coolant heat rejection", self.name))
        else:
            flows.append(PowerFlow(EnergyDomain.SOURCE, EnergyDomain.THERMAL,
                                   -q, "coolant heat gain", self.name))
        if pump > 0.0:
            flows.append(PowerFlow(EnergyDomain.SOURCE, EnergyDomain.ELECTRICAL,
                                   pump, "pump power", self.name))
            flows.append(PowerFlow(EnergyDomain.ELECTRICAL, EnergyDomain.ENVIRONMENT,
                                   pump, "pump loss", self.name))
        events = []
        severity = Severity.NORMAL
        if fraction <= 1e-6:
            severity = Severity.WARNING
            events.append(Event(state.time, "cooling_loss",
                                f"{self.name} flow has stopped",
                                Severity.WARNING, self.name))
        return ComponentOutput(
            flows=flows,
            derivatives=Derivatives(heat_input=-q),
            diagnostics={f"{self.name}.heat_removed": q,
                         f"{self.name}.flow_fraction": fraction,
                         f"{self.name}.outlet_temperature": outlet},
            events=events, severity=severity,
        )


class ThermalMass(Component):
    """A pure heat capacity with a fixed heat input, used for testing and
    for representing a soak load that has no other physics attached."""

    order = 60

    def __init__(self, name: str, heat: float = 0.0,
                 input_key: str | None = None) -> None:
        super().__init__(name)
        self.heat = float(heat)
        self.input_key = input_key or f"{name}.heat"

    def evaluate(self, state: SystemState, dt: float,
                 context: Context) -> ComponentOutput:
        q = context.get(self.input_key, self.heat)
        source = EnergyDomain.SOURCE if q >= 0.0 else EnergyDomain.THERMAL
        target = EnergyDomain.THERMAL if q >= 0.0 else EnergyDomain.ENVIRONMENT
        return ComponentOutput(
            flows=[PowerFlow(source, target, abs(q), "applied heat", self.name)],
            derivatives=Derivatives(heat_input=q),
            diagnostics={f"{self.name}.heat": q},
        )


class HeatExchangerComponent(Component):
    """Waste-heat extraction into a secondary stream."""

    order = 76

    def __init__(self, name: str, exchanger: HeatExchanger,
                 cold_inlet: float = 298.15,
                 input_key: str | None = None) -> None:
        super().__init__(name)
        self.exchanger = exchanger
        self.cold_inlet = float(cold_inlet)
        self.input_key = input_key or f"{name}.cold_inlet"

    def evaluate(self, state: SystemState, dt: float,
                 context: Context) -> ComponentOutput:
        cold_in = context.get(self.input_key, self.cold_inlet)
        hot_in = state.thermal.temperature
        q = max(0.0, self.exchanger.duty(hot_in, cold_in))
        hot_out, cold_out = self.exchanger.outlet_temperatures(hot_in, cold_in)
        return ComponentOutput(
            flows=[PowerFlow(EnergyDomain.THERMAL, EnergyDomain.ENVIRONMENT, q,
                             "recovered heat", self.name)],
            derivatives=Derivatives(heat_input=-q),
            diagnostics={f"{self.name}.duty": q,
                         f"{self.name}.effectiveness": self.exchanger.effectiveness,
                         f"{self.name}.cold_outlet": cold_out,
                         f"{self.name}.hot_outlet": hot_out},
        )
