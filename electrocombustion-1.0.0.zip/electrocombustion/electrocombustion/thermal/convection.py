"""Convective heat transfer: natural and forced correlations.

The correlations are standard textbook forms.  Each one carries its validity
range in the docstring, and :func:`nusselt_natural_vertical_plate` and friends
do not silently extrapolate beyond it -- they return the correlation value but
:func:`correlation_warning` will tell you when you have left the fitted range.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Literal

from ..core import units as U

#: Approximate properties of dry air at 1 atm, evaluated at the film temperature.
def air_properties(temperature: float) -> dict[str, float]:
    """Kinematic viscosity, conductivity, Prandtl number and beta for air.

    Fits are valid roughly 250-1200 K at atmospheric pressure.
    """
    t = max(150.0, min(2000.0, temperature))
    nu = 1.47e-5 * (t / 300.0) ** 1.75          # m^2/s
    k = 0.0263 * (t / 300.0) ** 0.85            # W/(m.K)
    pr = 0.707 - 3.0e-5 * (t - 300.0)           # -
    pr = max(0.6, min(0.75, pr))
    rho = U.P_ATM / (U.R_AIR * t)               # kg/m^3
    cp = 1004.0 - 0.0785 * t + 3.0e-4 * t * t   # J/(kg.K)
    return {"nu": nu, "k": k, "pr": pr, "beta": 1.0 / t, "rho": rho, "cp": cp,
            "mu": nu * rho}


def rayleigh_number(t_surface: float, t_fluid: float, length: float,
                    properties: dict[str, float] | None = None) -> float:
    """Rayleigh number for buoyancy-driven flow."""
    if length <= 0.0:
        raise ValueError("characteristic length must be positive")
    film = 0.5 * (t_surface + t_fluid)
    props = properties or air_properties(film)
    delta_t = abs(t_surface - t_fluid)
    gr = (U.STANDARD_GRAVITY * props["beta"] * delta_t * length ** 3
          / props["nu"] ** 2)
    return gr * props["pr"]


def reynolds_number(velocity: float, length: float,
                    kinematic_viscosity: float) -> float:
    if kinematic_viscosity <= 0.0:
        raise ValueError("kinematic viscosity must be positive")
    return abs(velocity) * length / kinematic_viscosity


def nusselt_natural_vertical_plate(rayleigh: float, prandtl: float) -> float:
    """Churchill-Chu correlation for a vertical plate.

    Valid for all Ra when laminar; for Ra > 1e9 the turbulent form is used.
    """
    if rayleigh <= 0.0:
        return 0.68
    if rayleigh < 1e9:
        denominator = (1.0 + (0.492 / prandtl) ** (9.0 / 16.0)) ** (4.0 / 9.0)
        return 0.68 + 0.670 * rayleigh ** 0.25 / denominator
    denominator = (1.0 + (0.492 / prandtl) ** (9.0 / 16.0)) ** (8.0 / 27.0)
    return (0.825 + 0.387 * rayleigh ** (1.0 / 6.0) / denominator) ** 2


def nusselt_natural_horizontal_cylinder(rayleigh: float, prandtl: float) -> float:
    """Churchill-Chu correlation for a long horizontal cylinder (Ra < 1e12)."""
    if rayleigh <= 0.0:
        return 0.36
    denominator = (1.0 + (0.559 / prandtl) ** (9.0 / 16.0)) ** (8.0 / 27.0)
    return (0.60 + 0.387 * rayleigh ** (1.0 / 6.0) / denominator) ** 2


def nusselt_forced_flat_plate(reynolds: float, prandtl: float) -> float:
    """Average Nusselt number over an isothermal flat plate.

    Laminar below Re = 5e5, mixed laminar-turbulent above.
    """
    if reynolds <= 0.0:
        return 0.0
    if reynolds < 5e5:
        return 0.664 * reynolds ** 0.5 * prandtl ** (1.0 / 3.0)
    return (0.037 * reynolds ** 0.8 - 871.0) * prandtl ** (1.0 / 3.0)


def nusselt_dittus_boelter(reynolds: float, prandtl: float,
                           heating: bool = True) -> float:
    """Dittus-Boelter correlation for fully developed turbulent pipe flow.

    Valid for Re > 10 000, 0.6 < Pr < 160, L/D > 10.  Below Re = 2300 the
    constant laminar value 3.66 (constant wall temperature) is returned
    instead, which is the physically correct limit rather than an
    extrapolation of a turbulent fit.
    """
    if reynolds < 2300.0:
        return 3.66
    n = 0.4 if heating else 0.3
    return 0.023 * reynolds ** 0.8 * prandtl ** n


def nusselt_cross_flow_cylinder(reynolds: float, prandtl: float) -> float:
    """Churchill-Bernstein correlation for cross flow over a cylinder."""
    if reynolds <= 0.0:
        return 0.3
    term = (0.62 * reynolds ** 0.5 * prandtl ** (1.0 / 3.0)
            / (1.0 + (0.4 / prandtl) ** (2.0 / 3.0)) ** 0.25)
    growth = (1.0 + (reynolds / 282_000.0) ** (5.0 / 8.0)) ** 0.8
    return 0.3 + term * growth


def correlation_warning(name: str, reynolds: float = 0.0,
                        rayleigh: float = 0.0, prandtl: float = 0.7) -> str | None:
    """Return a message if the inputs fall outside a correlation's fitted range."""
    if name == "dittus_boelter":
        if 2300.0 <= reynolds < 10_000.0:
            return "Dittus-Boelter is fitted for Re > 10 000; this is transitional flow"
        if not 0.6 <= prandtl <= 160.0:
            return "Dittus-Boelter is fitted for 0.6 < Pr < 160"
    if name == "churchill_chu_cylinder" and rayleigh > 1e12:
        return "Churchill-Chu for cylinders is fitted for Ra < 1e12"
    if name == "flat_plate" and reynolds > 1e8:
        return "flat-plate correlation is fitted for Re < 1e8"
    return None


@dataclass(slots=True)
class ConvectionSurface:
    """A convecting surface with either a fixed or correlated coefficient.

    ``mode`` selects the correlation family:
    ``"fixed"``     use ``coefficient`` directly,
    ``"natural"``   buoyancy driven, geometry set by ``geometry``,
    ``"forced"``    driven by ``velocity``.
    """

    area: float
    characteristic_length: float = 0.1
    coefficient: float = 10.0
    mode: Literal["fixed", "natural", "forced"] = "fixed"
    geometry: Literal["plate", "cylinder"] = "plate"
    velocity: float = 0.0
    fouling_factor: float = 1.0

    def __post_init__(self) -> None:
        if self.area <= 0.0:
            raise ValueError("surface area must be positive")
        if self.characteristic_length <= 0.0:
            raise ValueError("characteristic length must be positive")
        if self.mode not in ("fixed", "natural", "forced"):
            raise ValueError("mode must be 'fixed', 'natural' or 'forced'")

    def h(self, t_surface: float, t_fluid: float) -> float:
        """Convection coefficient (W/(m^2.K))."""
        if self.mode == "fixed":
            return self.coefficient * self.fouling_factor
        film = 0.5 * (t_surface + t_fluid)
        props = air_properties(film)
        length = self.characteristic_length
        if self.mode == "natural":
            ra = rayleigh_number(t_surface, t_fluid, length, props)
            nu = (nusselt_natural_horizontal_cylinder(ra, props["pr"])
                  if self.geometry == "cylinder"
                  else nusselt_natural_vertical_plate(ra, props["pr"]))
        else:
            re = reynolds_number(self.velocity, length, props["nu"])
            nu = (nusselt_cross_flow_cylinder(re, props["pr"])
                  if self.geometry == "cylinder"
                  else nusselt_forced_flat_plate(re, props["pr"]))
        nu = max(0.1, nu)
        return nu * props["k"] / length * self.fouling_factor

    def heat_flow(self, t_surface: float, t_fluid: float) -> float:
        """Convective heat flow from surface to fluid (W)."""
        return self.h(t_surface, t_fluid) * self.area * (t_surface - t_fluid)

    def resistance(self, t_surface: float, t_fluid: float) -> float:
        h = self.h(t_surface, t_fluid)
        return 1.0 / (h * self.area) if h > 0.0 else math.inf


def newton_cooling(h: float, area: float, t_surface: float,
                   t_fluid: float) -> float:
    """Newton's law of cooling, ``q = h A (Ts - Tf)`` in W."""
    return h * area * (t_surface - t_fluid)


def forced_convection_flow(mass_flow: float, cp: float, t_in: float,
                           t_out: float) -> float:
    """Enthalpy carried away by a coolant stream (W)."""
    return mass_flow * cp * (t_out - t_in)
