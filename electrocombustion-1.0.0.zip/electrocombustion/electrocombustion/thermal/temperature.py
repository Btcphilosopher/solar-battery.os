"""Lumped thermal nodes and networks."""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Callable, Iterable, Mapping, Sequence

import numpy as np

from ..core import units as U
from ..materials.material import Material


@dataclass(slots=True)
class ThermalNode:
    """A lumped thermal mass with a single temperature.

    ``capacitance`` is ``m * cp`` in J/K.  When a :class:`Material` is given it
    is recomputed at the node temperature every time it is queried, which
    matters for materials whose specific heat varies appreciably.
    """

    name: str
    temperature: float = U.T_STANDARD
    mass: float = 1.0
    specific_heat: float = 500.0
    material: Material | None = None
    fixed: bool = False
    heat_input: float = 0.0

    def __post_init__(self) -> None:
        if self.mass <= 0.0:
            raise ValueError(f"node {self.name}: mass must be positive")
        if self.specific_heat <= 0.0 and self.material is None:
            raise ValueError(f"node {self.name}: specific heat must be positive")

    def cp(self) -> float:
        if self.material is not None:
            return self.material.cp(self.temperature)
        return self.specific_heat

    @property
    def capacitance(self) -> float:
        return self.mass * self.cp()

    def energy(self, reference: float = 0.0) -> float:
        """Sensible energy above ``reference`` (J)."""
        return self.capacitance * (self.temperature - reference)

    def apply(self, heat: float, dt: float) -> float:
        """Advance the node temperature by explicit Euler; returns new T."""
        if self.fixed:
            return self.temperature
        capacitance = self.capacitance
        if capacitance <= 0.0:  # pragma: no cover - guarded in __post_init__
            return self.temperature
        self.temperature += heat * dt / capacitance
        return self.temperature

    def time_constant(self, conductance: float) -> float:
        if conductance <= 0.0:
            return math.inf
        return self.capacitance / conductance


@dataclass(slots=True)
class ThermalLink:
    """A conductive path between two nodes.

    ``conductance`` may be a constant (W/K) or a callable of the two node
    temperatures, which is how radiation and correlated convection are
    represented inside the linear network solver.
    """

    node_a: str
    node_b: str
    conductance: float | Callable[[float, float], float]
    name: str = ""

    def value(self, t_a: float, t_b: float) -> float:
        if callable(self.conductance):
            return max(0.0, float(self.conductance(t_a, t_b)))
        return max(0.0, float(self.conductance))

    def heat_flow(self, t_a: float, t_b: float) -> float:
        """Heat flow from ``node_a`` to ``node_b`` (W)."""
        return self.value(t_a, t_b) * (t_a - t_b)


class ThermalNetwork:
    """A network of lumped nodes connected by conductances.

    Supports steady-state solution (linear solve, with iteration when any
    conductance is temperature dependent) and transient integration.
    """

    def __init__(self, name: str = "network") -> None:
        self.name = name
        self.nodes: dict[str, ThermalNode] = {}
        self.links: list[ThermalLink] = []

    def add_node(self, node: ThermalNode) -> ThermalNode:
        if node.name in self.nodes:
            raise ValueError(f"duplicate thermal node {node.name!r}")
        self.nodes[node.name] = node
        return node

    def add_link(self, node_a: str, node_b: str,
                 conductance: float | Callable[[float, float], float],
                 name: str = "") -> ThermalLink:
        for n in (node_a, node_b):
            if n not in self.nodes:
                raise KeyError(f"unknown thermal node {n!r}")
        link = ThermalLink(node_a, node_b, conductance, name)
        self.links.append(link)
        return link

    def set_heat_input(self, node: str, watts: float) -> None:
        self.nodes[node].heat_input = float(watts)

    def temperatures(self) -> dict[str, float]:
        return {name: node.temperature for name, node in self.nodes.items()}

    def net_heat(self, node_name: str) -> float:
        """Net heat entering ``node_name`` (W)."""
        node = self.nodes[node_name]
        total = node.heat_input
        for link in self.links:
            t_a = self.nodes[link.node_a].temperature
            t_b = self.nodes[link.node_b].temperature
            flow = link.heat_flow(t_a, t_b)
            if link.node_a == node_name:
                total -= flow
            elif link.node_b == node_name:
                total += flow
        return total

    def derivatives(self) -> dict[str, float]:
        """dT/dt for every free node (K/s)."""
        out: dict[str, float] = {}
        for name, node in self.nodes.items():
            if node.fixed:
                out[name] = 0.0
            else:
                out[name] = self.net_heat(name) / node.capacitance
        return out

    def step(self, dt: float) -> dict[str, float]:
        """Advance one explicit Euler step and return the new temperatures."""
        derivatives = self.derivatives()
        for name, node in self.nodes.items():
            if not node.fixed:
                node.temperature += derivatives[name] * dt
        return self.temperatures()

    def step_rk4(self, dt: float) -> dict[str, float]:
        """Advance one classical RK4 step (more accurate, four evaluations)."""
        original = {n: node.temperature for n, node in self.nodes.items()}
        stages: list[dict[str, float]] = []
        for weight in (0.0, 0.5, 0.5, 1.0):
            if stages:
                for n, node in self.nodes.items():
                    if not node.fixed:
                        node.temperature = original[n] + weight * dt * stages[-1][n]
            stages.append(self.derivatives())
        for n, node in self.nodes.items():
            if node.fixed:
                node.temperature = original[n]
            else:
                k1, k2, k3, k4 = (s[n] for s in stages)
                node.temperature = original[n] + dt / 6.0 * (k1 + 2 * k2 + 2 * k3 + k4)
        return self.temperatures()

    def solve_steady(self, tolerance: float = 1e-9,
                     max_iterations: int = 100) -> dict[str, float]:
        """Solve for the steady-state temperature field.

        Fixed nodes act as boundary conditions.  Temperature-dependent
        conductances are handled by successive substitution; the iteration
        stops when the temperature update falls below ``tolerance``.
        """
        names = list(self.nodes)
        index = {n: i for i, n in enumerate(names)}
        n = len(names)
        if n == 0:
            return {}
        for _ in range(max_iterations):
            A = np.zeros((n, n))
            b = np.zeros(n)
            for name, node in self.nodes.items():
                i = index[name]
                if node.fixed:
                    A[i, i] = 1.0
                    b[i] = node.temperature
                    continue
                b[i] = node.heat_input
                for link in self.links:
                    if name not in (link.node_a, link.node_b):
                        continue
                    other = link.node_b if link.node_a == name else link.node_a
                    g = link.value(self.nodes[link.node_a].temperature,
                                   self.nodes[link.node_b].temperature)
                    A[i, i] += g
                    A[i, index[other]] -= g
            try:
                solution = np.linalg.solve(A, b)
            except np.linalg.LinAlgError as exc:
                raise ValueError(
                    "thermal network is singular: at least one node must be "
                    "fixed or connected to a fixed node"
                ) from exc
            delta = 0.0
            for name, node in self.nodes.items():
                new_t = float(solution[index[name]])
                if not node.fixed:
                    delta = max(delta, abs(new_t - node.temperature))
                    node.temperature = new_t
            if delta < tolerance:
                break
        return self.temperatures()

    def total_energy(self, reference: float = 0.0) -> float:
        return sum(node.energy(reference) for node in self.nodes.values())

    def stiffness_ratio(self) -> float:
        """Ratio of the slowest to fastest node time constant.

        A large ratio signals a stiff system where an explicit integrator will
        need a very small step; the value is what the solver module uses to
        recommend an implicit method.
        """
        constants: list[float] = []
        for name, node in self.nodes.items():
            conductance = sum(
                link.value(self.nodes[link.node_a].temperature,
                           self.nodes[link.node_b].temperature)
                for link in self.links if name in (link.node_a, link.node_b)
            )
            tau = node.time_constant(conductance)
            if math.isfinite(tau) and tau > 0.0:
                constants.append(tau)
        if len(constants) < 2:
            return 1.0
        return max(constants) / min(constants)

    def __len__(self) -> int:
        return len(self.nodes)

    def __repr__(self) -> str:
        return f"ThermalNetwork(name={self.name!r}, nodes={len(self.nodes)}, links={len(self.links)})"


def lumped_response(t_initial: float, t_ambient: float, capacitance: float,
                    conductance: float, time: float,
                    heat_input: float = 0.0) -> float:
    """Analytic first-order thermal response.

    Solves ``C dT/dt = Q - G (T - T_amb)`` giving
    ``T(t) = T_inf + (T0 - T_inf) exp(-t G / C)`` with
    ``T_inf = T_amb + Q / G``.
    """
    if capacitance <= 0.0:
        raise ValueError("capacitance must be positive")
    if conductance <= 0.0:
        return t_initial + heat_input * time / capacitance
    t_inf = t_ambient + heat_input / conductance
    return t_inf + (t_initial - t_inf) * math.exp(-time * conductance / capacitance)
