"""Composite heat-transfer models: overall coefficients and heat exchangers."""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Literal, Sequence

from ..core import units as U
from .conduction import CompositeWall, Slab
from .convection import ConvectionSurface
from .radiation import RadiatingSurface, linearised_coefficient


@dataclass(slots=True)
class ThermalBoundary:
    """A complete boundary combining convection, radiation and conduction.

    The three mechanisms act in parallel across the surface film, in series
    with any conductive wall, which is the usual arrangement for a jacketed or
    insulated component.
    """

    name: str = "boundary"
    convection: ConvectionSurface | None = None
    radiation: RadiatingSurface | None = None
    wall: CompositeWall | Slab | None = None
    ambient_temperature: float = U.T_STANDARD

    def surface_conductance(self, t_surface: float, t_ambient: float) -> float:
        """Combined film conductance (W/K)."""
        total = 0.0
        if self.convection is not None:
            total += self.convection.h(t_surface, t_ambient) * self.convection.area
        if self.radiation is not None:
            total += (self.radiation.coefficient(t_surface, t_ambient)
                      * self.radiation.area)
        return total

    def heat_flow(self, t_body: float, t_ambient: float | None = None) -> float:
        """Total heat lost from the body to ambient (W).

        When a wall is present, the surface temperature is solved so that the
        conduction through the wall matches the film transfer, rather than
        assuming the surface sits at the body temperature.
        """
        ambient = self.ambient_temperature if t_ambient is None else t_ambient
        if self.wall is None:
            return self._film_flow(t_body, ambient)
        lo, hi = min(t_body, ambient), max(t_body, ambient)
        for _ in range(60):
            t_surface = 0.5 * (lo + hi)
            through_wall = self.wall.heat_flow(t_body, t_surface)
            from_surface = self._film_flow(t_surface, ambient)
            residual = through_wall - from_surface
            if abs(residual) < 1e-9:
                break
            if (residual > 0.0) == (t_body > ambient):
                lo = t_surface
            else:
                hi = t_surface
        return self._film_flow(0.5 * (lo + hi), ambient)

    def _film_flow(self, t_surface: float, t_ambient: float) -> float:
        total = 0.0
        if self.convection is not None:
            total += self.convection.heat_flow(t_surface, t_ambient)
        if self.radiation is not None:
            total += self.radiation.heat_flow(t_surface, t_ambient)
        return total

    def resistance(self, t_body: float, t_ambient: float | None = None) -> float:
        """Effective total resistance body-to-ambient (K/W)."""
        ambient = self.ambient_temperature if t_ambient is None else t_ambient
        q = self.heat_flow(t_body, ambient)
        if q == 0.0:
            return math.inf
        return (t_body - ambient) / q


def overall_coefficient(h_inner: float, h_outer: float, wall_resistance: float,
                        area: float) -> float:
    """Overall heat-transfer coefficient U (W/(m^2.K)) for a plane wall."""
    if min(h_inner, h_outer) <= 0.0 or area <= 0.0:
        raise ValueError("film coefficients and area must be positive")
    total_resistance = 1.0 / (h_inner * area) + wall_resistance + 1.0 / (h_outer * area)
    return 1.0 / (total_resistance * area)


def lmtd(t_hot_in: float, t_hot_out: float, t_cold_in: float,
         t_cold_out: float, counterflow: bool = True) -> float:
    """Log-mean temperature difference (K).

    Falls back to the arithmetic mean when the two end differences are within
    2 % of each other, where the logarithmic form is numerically unstable and
    the arithmetic mean is accurate to better than 0.1 %.
    """
    if counterflow:
        d1 = t_hot_in - t_cold_out
        d2 = t_hot_out - t_cold_in
    else:
        d1 = t_hot_in - t_cold_in
        d2 = t_hot_out - t_cold_out
    if d1 <= 0.0 or d2 <= 0.0:
        raise ValueError(
            "temperature cross detected: the cold stream cannot exceed the hot "
            "stream at either end of the exchanger"
        )
    if abs(d1 - d2) < 0.02 * max(d1, d2):
        return 0.5 * (d1 + d2)
    return (d1 - d2) / math.log(d1 / d2)


def ntu_effectiveness(ntu: float, capacity_ratio: float,
                      arrangement: Literal["counterflow", "parallel", "crossflow",
                                           "boiling"] = "counterflow") -> float:
    """Effectiveness from NTU for the standard flow arrangements."""
    if ntu < 0.0:
        raise ValueError("NTU must be non-negative")
    cr = min(1.0, max(0.0, capacity_ratio))
    if arrangement == "boiling" or cr == 0.0:
        return 1.0 - math.exp(-ntu)
    if arrangement == "counterflow":
        if abs(cr - 1.0) < 1e-9:
            return ntu / (1.0 + ntu)
        numerator = 1.0 - math.exp(-ntu * (1.0 - cr))
        return numerator / (1.0 - cr * math.exp(-ntu * (1.0 - cr)))
    if arrangement == "parallel":
        return (1.0 - math.exp(-ntu * (1.0 + cr))) / (1.0 + cr)
    if arrangement == "crossflow":
        # both fluids unmixed, standard approximation
        exponent = ntu ** 0.22
        return 1.0 - math.exp((math.exp(-cr * ntu * exponent) - 1.0) / (cr * exponent))
    raise ValueError(f"unknown arrangement {arrangement!r}")


@dataclass(slots=True)
class HeatExchanger:
    """An effectiveness-NTU heat exchanger.

    Parameters
    ----------
    ua:
        Overall conductance ``U*A`` in W/K.
    hot_capacity_rate, cold_capacity_rate:
        ``m_dot * cp`` for each stream in W/K.
    """

    name: str = "hx"
    ua: float = 1000.0
    hot_capacity_rate: float = 1000.0
    cold_capacity_rate: float = 1000.0
    arrangement: Literal["counterflow", "parallel", "crossflow", "boiling"] = "counterflow"
    fouling: float = 1.0

    def __post_init__(self) -> None:
        if self.ua <= 0.0:
            raise ValueError("UA must be positive")
        if min(self.hot_capacity_rate, self.cold_capacity_rate) <= 0.0:
            raise ValueError("capacity rates must be positive")
        if not 0.0 < self.fouling <= 1.0:
            raise ValueError("fouling factor must lie in (0, 1]")

    @property
    def c_min(self) -> float:
        return min(self.hot_capacity_rate, self.cold_capacity_rate)

    @property
    def c_max(self) -> float:
        return max(self.hot_capacity_rate, self.cold_capacity_rate)

    @property
    def capacity_ratio(self) -> float:
        return self.c_min / self.c_max

    @property
    def ntu(self) -> float:
        return self.ua * self.fouling / self.c_min

    @property
    def effectiveness(self) -> float:
        return ntu_effectiveness(self.ntu, self.capacity_ratio, self.arrangement)

    def duty(self, t_hot_in: float, t_cold_in: float) -> float:
        """Heat transferred (W) for the given inlet temperatures."""
        return self.effectiveness * self.c_min * (t_hot_in - t_cold_in)

    def outlet_temperatures(self, t_hot_in: float,
                            t_cold_in: float) -> tuple[float, float]:
        """Return ``(t_hot_out, t_cold_out)`` in K."""
        q = self.duty(t_hot_in, t_cold_in)
        return (t_hot_in - q / self.hot_capacity_rate,
                t_cold_in + q / self.cold_capacity_rate)

    def required_ua(self, duty: float, t_hot_in: float,
                    t_cold_in: float) -> float:
        """UA needed to achieve ``duty``; raises if the duty is unreachable."""
        maximum = self.c_min * (t_hot_in - t_cold_in)
        if maximum <= 0.0:
            raise ValueError("no temperature difference available to drive heat transfer")
        target = duty / maximum
        if target >= 1.0:
            raise ValueError(
                f"duty {duty:g} W exceeds the thermodynamic maximum {maximum:g} W"
            )
        lo, hi = 1e-6, 1e6
        for _ in range(200):
            mid = math.sqrt(lo * hi)
            eff = ntu_effectiveness(mid / self.c_min, self.capacity_ratio,
                                    self.arrangement)
            if abs(eff - target) < 1e-12:
                return mid
            if eff < target:
                lo = mid
            else:
                hi = mid
        return math.sqrt(lo * hi)


@dataclass(slots=True)
class CoolingCircuit:
    """A pumped coolant loop removing heat from a body.

    The loop is characterised by its mass flow, specific heat and inlet
    temperature.  A flow fraction of zero represents a total loss of cooling,
    which is the fault case in section 19 of the specification.
    """

    name: str = "coolant"
    mass_flow: float = 0.5
    specific_heat: float = U.CP_WATER
    inlet_temperature: float = 298.15
    ua: float = 2000.0
    flow_fraction: float = 1.0
    pump_power: float = 0.0

    @property
    def capacity_rate(self) -> float:
        return self.mass_flow * self.flow_fraction * self.specific_heat

    def heat_removed(self, body_temperature: float) -> float:
        """Heat extracted from the body (W).

        Uses the exponential approach form so that the coolant outlet can never
        exceed the body temperature, no matter how small the flow.
        """
        c = self.capacity_rate
        if c <= 0.0:
            return 0.0
        effectiveness = 1.0 - math.exp(-self.ua / c)
        return effectiveness * c * (body_temperature - self.inlet_temperature)

    def outlet_temperature(self, body_temperature: float) -> float:
        c = self.capacity_rate
        if c <= 0.0:
            return self.inlet_temperature
        return self.inlet_temperature + self.heat_removed(body_temperature) / c

    def effective_conductance(self, body_temperature: float) -> float:
        delta = body_temperature - self.inlet_temperature
        if abs(delta) < 1e-12:
            return 0.0
        return self.heat_removed(body_temperature) / delta
