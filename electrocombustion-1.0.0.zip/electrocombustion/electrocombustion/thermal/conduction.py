"""Steady and transient conduction models."""
from __future__ import annotations

import math
from dataclasses import dataclass

from ..core import units as U
from ..materials.material import Material


def slab_resistance(thickness: float, area: float, conductivity: float) -> float:
    """Thermal resistance of a plane wall, ``L / (k A)`` in K/W."""
    if area <= 0.0 or conductivity <= 0.0:
        raise ValueError("area and conductivity must be positive")
    return thickness / (conductivity * area)


def cylindrical_resistance(r_inner: float, r_outer: float, length: float,
                           conductivity: float) -> float:
    """Radial conduction resistance of a cylindrical shell (K/W)."""
    if not 0.0 < r_inner < r_outer:
        raise ValueError("radii must satisfy 0 < r_inner < r_outer")
    if length <= 0.0 or conductivity <= 0.0:
        raise ValueError("length and conductivity must be positive")
    return math.log(r_outer / r_inner) / (2.0 * math.pi * conductivity * length)


def spherical_resistance(r_inner: float, r_outer: float,
                         conductivity: float) -> float:
    """Radial conduction resistance of a spherical shell (K/W)."""
    if not 0.0 < r_inner < r_outer:
        raise ValueError("radii must satisfy 0 < r_inner < r_outer")
    return (1.0 / r_inner - 1.0 / r_outer) / (4.0 * math.pi * conductivity)


def conduction_heat_flow(t_hot: float, t_cold: float, resistance: float) -> float:
    """Heat flow through a thermal resistance (W), positive hot to cold."""
    if resistance <= 0.0:
        raise ValueError("thermal resistance must be positive")
    return (t_hot - t_cold) / resistance


def fourier_number(diffusivity: float, time: float, length: float) -> float:
    """Dimensionless Fourier number ``alpha t / L^2``."""
    if length <= 0.0:
        raise ValueError("characteristic length must be positive")
    return diffusivity * time / (length * length)


def biot_number(h: float, length: float, conductivity: float) -> float:
    """Dimensionless Biot number ``h L / k``.

    ``Bi < 0.1`` is the usual justification for a lumped-capacitance model;
    :func:`lumped_capacitance_valid` applies that test explicitly.
    """
    if conductivity <= 0.0:
        raise ValueError("conductivity must be positive")
    return h * length / conductivity


def lumped_capacitance_valid(h: float, length: float, conductivity: float,
                             threshold: float = 0.1) -> bool:
    """Whether a lumped model is defensible for these parameters."""
    return biot_number(h, length, conductivity) < threshold


@dataclass(slots=True)
class Slab:
    """A plane wall of one material."""

    material: Material
    thickness: float
    area: float

    def __post_init__(self) -> None:
        if self.thickness <= 0.0 or self.area <= 0.0:
            raise ValueError("thickness and area must be positive")

    def resistance(self, temperature: float = U.T_STANDARD) -> float:
        return slab_resistance(self.thickness, self.area,
                               self.material.k(temperature))

    def mass(self) -> float:
        return self.material.density * self.thickness * self.area

    def capacitance(self, temperature: float = U.T_STANDARD) -> float:
        """Thermal capacitance m*cp (J/K)."""
        return self.mass() * self.material.cp(temperature)

    def heat_flow(self, t_hot: float, t_cold: float) -> float:
        mean = 0.5 * (t_hot + t_cold)
        return conduction_heat_flow(t_hot, t_cold, self.resistance(mean))

    def time_constant(self, temperature: float = U.T_STANDARD) -> float:
        return self.resistance(temperature) * self.capacitance(temperature)


@dataclass(slots=True)
class CompositeWall:
    """A stack of slabs in series, sharing a common area."""

    layers: tuple[Slab, ...]

    def __post_init__(self) -> None:
        if not self.layers:
            raise ValueError("a composite wall needs at least one layer")
        areas = {round(layer.area, 12) for layer in self.layers}
        if len(areas) != 1:
            raise ValueError("all layers of a composite wall must share one area")

    @property
    def area(self) -> float:
        return self.layers[0].area

    @property
    def thickness(self) -> float:
        return sum(layer.thickness for layer in self.layers)

    def resistance(self, t_hot: float, t_cold: float,
                   iterations: int = 8) -> float:
        """Total resistance, iterating so each layer uses its own mean temperature.

        With temperature-dependent conductivity the layer temperatures are not
        known in advance; the interface temperatures are relaxed until the heat
        flow is consistent through every layer.
        """
        temperatures = [t_hot + (t_cold - t_hot) * i / len(self.layers)
                        for i in range(len(self.layers) + 1)]
        total = 0.0
        for _ in range(iterations):
            resistances = [
                layer.resistance(0.5 * (temperatures[i] + temperatures[i + 1]))
                for i, layer in enumerate(self.layers)
            ]
            total = sum(resistances)
            q = (t_hot - t_cold) / total if total > 0.0 else 0.0
            temperatures = [t_hot]
            for r in resistances:
                temperatures.append(temperatures[-1] - q * r)
        return total

    def heat_flow(self, t_hot: float, t_cold: float) -> float:
        r = self.resistance(t_hot, t_cold)
        return (t_hot - t_cold) / r if r > 0.0 else 0.0

    def interface_temperatures(self, t_hot: float, t_cold: float) -> list[float]:
        """Temperatures at every layer boundary, hot side first."""
        q = self.heat_flow(t_hot, t_cold)
        temperatures = [t_hot]
        for i, layer in enumerate(self.layers):
            mean = temperatures[-1]
            temperatures.append(temperatures[-1] - q * layer.resistance(mean))
        return temperatures

    def capacitance(self, temperature: float = U.T_STANDARD) -> float:
        return sum(layer.capacitance(temperature) for layer in self.layers)

    def u_value(self, t_hot: float, t_cold: float) -> float:
        """Overall heat transfer coefficient (W/(m^2.K))."""
        r = self.resistance(t_hot, t_cold)
        return 1.0 / (r * self.area) if r > 0.0 else math.inf


@dataclass(slots=True)
class ThermalContact:
    """Interfacial contact resistance between two solids."""

    conductance: float = 5000.0   # W/(m^2.K)
    area: float = 1.0

    def resistance(self) -> float:
        if self.conductance <= 0.0 or self.area <= 0.0:
            raise ValueError("contact conductance and area must be positive")
        return 1.0 / (self.conductance * self.area)

    def heat_flow(self, t_hot: float, t_cold: float) -> float:
        return (t_hot - t_cold) / self.resistance()
