"""Radiative heat transfer between grey surfaces."""
from __future__ import annotations

import math
from dataclasses import dataclass

from ..core import units as U

SIGMA = U.STEFAN_BOLTZMANN


def blackbody_emissive_power(temperature: float) -> float:
    """``sigma T^4`` in W/m^2."""
    if temperature < 0.0:
        raise ValueError("absolute temperature cannot be negative")
    return SIGMA * temperature ** 4


def grey_body_exchange(emissivity: float, area: float, t_surface: float,
                       t_surroundings: float) -> float:
    """Net radiation from a small grey body to large surroundings (W)."""
    if not 0.0 <= emissivity <= 1.0:
        raise ValueError("emissivity must lie in 0..1")
    if area < 0.0:
        raise ValueError("area must be non-negative")
    return emissivity * SIGMA * area * (t_surface ** 4 - t_surroundings ** 4)


def two_surface_exchange(area_1: float, emissivity_1: float,
                         area_2: float, emissivity_2: float,
                         view_factor: float, t1: float, t2: float) -> float:
    """Net radiation between two grey diffuse surfaces (W).

    Uses the radiosity network resistance
    ``(1-e1)/(e1 A1) + 1/(A1 F12) + (1-e2)/(e2 A2)``.
    """
    for e in (emissivity_1, emissivity_2):
        if not 0.0 < e <= 1.0:
            raise ValueError("emissivities must lie in (0, 1]")
    if not 0.0 < view_factor <= 1.0:
        raise ValueError("view factor must lie in (0, 1]")
    resistance = ((1.0 - emissivity_1) / (emissivity_1 * area_1)
                  + 1.0 / (area_1 * view_factor)
                  + (1.0 - emissivity_2) / (emissivity_2 * area_2))
    return SIGMA * (t1 ** 4 - t2 ** 4) / resistance


def linearised_coefficient(emissivity: float, t_surface: float,
                           t_surroundings: float) -> float:
    """Equivalent radiative film coefficient ``h_rad`` in W/(m^2.K).

    ``h_rad = e sigma (Ts + Tsur)(Ts^2 + Tsur^2)`` reproduces the fourth-power
    law exactly at the linearisation point, so it can be summed with a
    convective coefficient without introducing error at that state.
    """
    return (emissivity * SIGMA * (t_surface + t_surroundings)
            * (t_surface ** 2 + t_surroundings ** 2))


def view_factor_parallel_plates(width: float, height: float,
                                separation: float) -> float:
    """View factor between identical, directly opposed rectangular plates.

    Uses the standard closed-form solution for aligned parallel rectangles.
    """
    if min(width, height, separation) <= 0.0:
        raise ValueError("plate dimensions and separation must be positive")
    x = width / separation
    y = height / separation
    x2, y2 = x * x, y * y
    term1 = math.log(math.sqrt((1.0 + x2) * (1.0 + y2) / (1.0 + x2 + y2)))
    term2 = x * math.sqrt(1.0 + y2) * math.atan(x / math.sqrt(1.0 + y2))
    term3 = y * math.sqrt(1.0 + x2) * math.atan(y / math.sqrt(1.0 + x2))
    term4 = x * math.atan(x) + y * math.atan(y)
    return 2.0 / (math.pi * x * y) * (term1 + term2 + term3 - term4)


def view_factor_coaxial_cylinders(r_inner: float, r_outer: float) -> float:
    """View factor from the inner to the outer of two long coaxial cylinders.

    For an infinitely long enclosure the inner surface sees only the outer, so
    ``F12 = 1``; the reciprocal factor is the area ratio.
    """
    if not 0.0 < r_inner < r_outer:
        raise ValueError("radii must satisfy 0 < r_inner < r_outer")
    return 1.0


@dataclass(slots=True)
class RadiatingSurface:
    """A surface exchanging radiation with its surroundings."""

    area: float
    emissivity: float = 0.9
    view_factor: float = 1.0

    def __post_init__(self) -> None:
        if self.area <= 0.0:
            raise ValueError("area must be positive")
        if not 0.0 <= self.emissivity <= 1.0:
            raise ValueError("emissivity must lie in 0..1")
        if not 0.0 < self.view_factor <= 1.0:
            raise ValueError("view factor must lie in (0, 1]")

    def heat_flow(self, t_surface: float, t_surroundings: float) -> float:
        """Net radiated power (W), positive when the surface loses heat."""
        return self.view_factor * grey_body_exchange(
            self.emissivity, self.area, t_surface, t_surroundings)

    def coefficient(self, t_surface: float, t_surroundings: float) -> float:
        return self.view_factor * linearised_coefficient(
            self.emissivity, t_surface, t_surroundings)

    def resistance(self, t_surface: float, t_surroundings: float) -> float:
        h = self.coefficient(t_surface, t_surroundings)
        return 1.0 / (h * self.area) if h > 0.0 else math.inf


def radiative_equilibrium_temperature(absorbed_power: float, area: float,
                                      emissivity: float,
                                      t_surroundings: float) -> float:
    """Surface temperature at which radiation balances ``absorbed_power``."""
    if area <= 0.0 or emissivity <= 0.0:
        raise ValueError("area and emissivity must be positive")
    quartic = t_surroundings ** 4 + absorbed_power / (emissivity * SIGMA * area)
    return max(0.0, quartic) ** 0.25
