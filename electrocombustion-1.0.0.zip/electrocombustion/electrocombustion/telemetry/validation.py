"""Telemetry validation: range, rate, plausibility and energy-balance checks.

Validation answers "should I believe this number?" before any controller or
optimiser acts on it.  Each check returns a structured result rather than a
bare boolean, because *why* a value was rejected determines what to do next.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable, Mapping, Sequence


@dataclass(slots=True)
class ValidationIssue:
    """One problem found in a telemetry record."""

    channel: str
    kind: str
    message: str
    value: float | None = None

    def __str__(self) -> str:
        return f"{self.channel}: {self.message}"


@dataclass(slots=True)
class ValidationReport:
    """The outcome of validating one record."""

    time: float
    issues: list[ValidationIssue] = field(default_factory=list)

    @property
    def valid(self) -> bool:
        return not self.issues

    def by_kind(self, kind: str) -> list[ValidationIssue]:
        return [i for i in self.issues if i.kind == kind]

    def channels(self) -> list[str]:
        return sorted({i.channel for i in self.issues})

    def as_dict(self) -> dict[str, Any]:
        return {"time": self.time, "valid": self.valid,
                "issues": [{"channel": i.channel, "kind": i.kind,
                            "message": i.message, "value": i.value}
                           for i in self.issues]}


@dataclass(slots=True)
class RangeCheck:
    """Bounds a channel to a physically possible interval."""

    channel: str
    minimum: float = -math.inf
    maximum: float = math.inf
    units: str = ""

    def check(self, value: float) -> ValidationIssue | None:
        if not math.isfinite(value):
            return ValidationIssue(self.channel, "non_finite",
                                   f"value is {value}", value)
        if value < self.minimum:
            return ValidationIssue(
                self.channel, "range",
                f"{value:.6g}{self.units} is below the minimum "
                f"{self.minimum:.6g}{self.units}", value)
        if value > self.maximum:
            return ValidationIssue(
                self.channel, "range",
                f"{value:.6g}{self.units} exceeds the maximum "
                f"{self.maximum:.6g}{self.units}", value)
        return None


@dataclass(slots=True)
class RateCheck:
    """Bounds how fast a channel may change.

    A temperature that jumps 400 K in 10 ms is a sensor fault, not a process
    event, because no real thermal mass moves that fast.
    """

    channel: str
    max_rate: float
    units: str = ""
    previous: tuple[float, float] | None = None

    def check(self, value: float, t: float) -> ValidationIssue | None:
        if self.previous is None:
            self.previous = (t, value)
            return None
        t0, v0 = self.previous
        dt = t - t0
        self.previous = (t, value)
        if dt <= 0.0:
            return None
        rate = abs(value - v0) / dt
        if rate > self.max_rate:
            return ValidationIssue(
                self.channel, "rate",
                f"changed at {rate:.6g}{self.units}/s, above the "
                f"{self.max_rate:.6g}{self.units}/s limit", value)
        return None


@dataclass(slots=True)
class StuckCheck:
    """Detects a channel that has stopped moving.

    A perfectly constant reading over many samples on a noisy signal means the
    sensor has frozen, not that the process is exceptionally steady.
    """

    channel: str
    samples: int = 50
    tolerance: float = 0.0
    history: list[float] = field(default_factory=list)

    def check(self, value: float) -> ValidationIssue | None:
        self.history.append(value)
        if len(self.history) > self.samples:
            del self.history[: len(self.history) - self.samples]
        if len(self.history) < self.samples:
            return None
        spread = max(self.history) - min(self.history)
        if spread <= self.tolerance:
            return ValidationIssue(
                self.channel, "stuck",
                f"has not moved by more than {spread:.6g} over "
                f"{self.samples} samples", value)
        return None


class TelemetryValidator:
    """Applies a set of checks to each incoming record."""

    def __init__(self) -> None:
        self.range_checks: list[RangeCheck] = []
        self.rate_checks: list[RateCheck] = []
        self.stuck_checks: list[StuckCheck] = []
        self.relations: list[tuple[str, Callable[[Mapping[str, float]], bool], str]] = []
        self.reports: list[ValidationReport] = []

    def add_range(self, channel: str, minimum: float = -math.inf,
                  maximum: float = math.inf, units: str = "") -> "TelemetryValidator":
        self.range_checks.append(RangeCheck(channel, minimum, maximum, units))
        return self

    def add_rate(self, channel: str, max_rate: float,
                 units: str = "") -> "TelemetryValidator":
        self.rate_checks.append(RateCheck(channel, max_rate, units))
        return self

    def add_stuck(self, channel: str, samples: int = 50,
                  tolerance: float = 0.0) -> "TelemetryValidator":
        self.stuck_checks.append(StuckCheck(channel, samples, tolerance))
        return self

    def add_relation(self, name: str,
                     predicate: Callable[[Mapping[str, float]], bool],
                     message: str) -> "TelemetryValidator":
        """Add a cross-channel consistency test, e.g. ``P == V*I``."""
        self.relations.append((name, predicate, message))
        return self

    def validate(self, record: Mapping[str, float],
                 time_key: str = "time") -> ValidationReport:
        t = float(record.get(time_key, 0.0))
        report = ValidationReport(t)
        for check in self.range_checks:
            if check.channel in record:
                issue = check.check(float(record[check.channel]))
                if issue:
                    report.issues.append(issue)
        for rate in self.rate_checks:
            if rate.channel in record:
                issue = rate.check(float(record[rate.channel]), t)
                if issue:
                    report.issues.append(issue)
        for stuck in self.stuck_checks:
            if stuck.channel in record:
                issue = stuck.check(float(record[stuck.channel]))
                if issue:
                    report.issues.append(issue)
        for name, predicate, message in self.relations:
            try:
                ok = bool(predicate(record))
            except Exception as exc:  # noqa: BLE001 - a failing predicate is itself a finding
                report.issues.append(ValidationIssue(name, "relation_error",
                                                     f"check raised {exc!r}"))
                continue
            if not ok:
                report.issues.append(ValidationIssue(name, "relation", message))
        self.reports.append(report)
        return report

    def failure_rate(self) -> float:
        if not self.reports:
            return 0.0
        bad = sum(1 for r in self.reports if not r.valid)
        return bad / len(self.reports)

    def summary(self) -> dict[str, Any]:
        counts: dict[str, int] = {}
        for report in self.reports:
            for issue in report.issues:
                counts[issue.kind] = counts.get(issue.kind, 0) + 1
        return {"records": len(self.reports), "invalid":
                sum(1 for r in self.reports if not r.valid),
                "failure_rate": self.failure_rate(), "by_kind": counts}

    def reset(self) -> None:
        self.reports.clear()
        for rate in self.rate_checks:
            rate.previous = None
        for stuck in self.stuck_checks:
            stuck.history.clear()


def energy_balance_check(power_in: float, power_out: float,
                         storage_rate: float = 0.0,
                         tolerance: float = 0.01) -> tuple[bool, float]:
    """Verify that measured powers balance.

    Returns ``(ok, relative_residual)``.  This is the single most useful
    validation on an energy system: it uses no model at all, only the first
    law, so a failure means the *measurements* are wrong even when every
    individual channel looks plausible.
    """
    residual = power_in - power_out - storage_rate
    scale = max(abs(power_in), abs(power_out), 1.0)
    relative = residual / scale
    return abs(relative) <= tolerance, relative


def plausibility_check(temperature: float, pressure: float, mass: float,
                       volume: float, gas_constant: float,
                       tolerance: float = 0.05) -> tuple[bool, float]:
    """Check a measured gas state against the ideal gas law.

    A cheap and surprisingly effective cross-check: the four quantities are
    usually measured independently, so agreement is meaningful evidence.
    """
    if volume <= 0.0 or temperature <= 0.0:
        return False, math.inf
    expected = mass * gas_constant * temperature / volume
    if expected <= 0.0:
        return False, math.inf
    relative = (pressure - expected) / expected
    return abs(relative) <= tolerance, relative
