"""Telemetry: sensor models, logging, replay and validation."""
from .sensors import (
    Sensor, SensorArray, SensorSpec, current_transducer, pressure_transducer,
    thermocouple,
)
from .logging import CSVReplay, RingBuffer, TelemetryLogger
from .validation import (
    RangeCheck, RateCheck, StuckCheck, TelemetryValidator, ValidationIssue,
    ValidationReport, energy_balance_check, plausibility_check,
)

__all__ = [
    "Sensor", "SensorArray", "SensorSpec", "current_transducer",
    "pressure_transducer", "thermocouple", "CSVReplay", "RingBuffer",
    "TelemetryLogger", "RangeCheck", "RateCheck", "StuckCheck",
    "TelemetryValidator", "ValidationIssue", "ValidationReport",
    "energy_balance_check", "plausibility_check",
]
