"""Sensor models: noise, bias, drift, quantisation, lag and failure.

A perfect measurement is the least realistic thing in a simulation.  These
models let a control study face the same corrupted signal the real controller
will see.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Callable, Literal, Sequence

import numpy as np


@dataclass(slots=True)
class SensorSpec:
    """Static characteristics of a sensor."""

    name: str
    units: str = ""
    range_min: float = -math.inf
    range_max: float = math.inf
    noise_sigma: float = 0.0
    bias: float = 0.0
    drift_rate: float = 0.0          # units per second
    resolution: float = 0.0          # quantisation step; 0 = continuous
    time_constant: float = 0.0       # first-order lag (s)
    scale_error: float = 1.0         # multiplicative gain error
    failure_probability: float = 0.0  # per sample

    def __post_init__(self) -> None:
        if self.range_min > self.range_max:
            raise ValueError(f"{self.name}: range bounds are inverted")
        if self.noise_sigma < 0.0 or self.resolution < 0.0:
            raise ValueError(f"{self.name}: noise and resolution must be non-negative")
        if self.time_constant < 0.0:
            raise ValueError(f"{self.name}: time constant must be non-negative")
        if not 0.0 <= self.failure_probability <= 1.0:
            raise ValueError(f"{self.name}: failure probability must lie in 0..1")


class Sensor:
    """A stateful sensor applying its spec to a true value.

    Order of operations matters and mirrors real instrumentation: gain error
    and bias act on the physical quantity, drift accumulates, the transducer
    lags, noise is added at the front end, and quantisation happens last in the
    ADC.
    """

    def __init__(self, spec: SensorSpec, seed: int | None = None) -> None:
        self.spec = spec
        self.rng = np.random.default_rng(seed)
        self.filtered: float | None = None
        self.elapsed = 0.0
        self.failed = False
        self.samples = 0
        self.last_reading = 0.0

    def read(self, true_value: float, dt: float = 0.0) -> float:
        """Return the indicated measurement for a true value."""
        spec = self.spec
        self.samples += 1
        self.elapsed += dt

        if spec.failure_probability > 0.0 and not self.failed:
            if self.rng.random() < spec.failure_probability:
                self.failed = True
        if self.failed:
            self.last_reading = spec.range_min if math.isfinite(spec.range_min) else 0.0
            return self.last_reading

        value = true_value * spec.scale_error + spec.bias
        value += spec.drift_rate * self.elapsed

        if spec.time_constant > 0.0 and dt > 0.0:
            if self.filtered is None:
                self.filtered = value
            alpha = dt / (spec.time_constant + dt)
            self.filtered += alpha * (value - self.filtered)
            value = self.filtered
        elif spec.time_constant > 0.0:
            if self.filtered is None:
                self.filtered = value
            value = self.filtered

        if spec.noise_sigma > 0.0:
            value += float(self.rng.normal(0.0, spec.noise_sigma))

        value = min(spec.range_max, max(spec.range_min, value))

        if spec.resolution > 0.0:
            value = round(value / spec.resolution) * spec.resolution

        self.last_reading = value
        return value

    def error(self, true_value: float) -> float:
        """Difference between the last reading and the true value."""
        return self.last_reading - true_value

    def reset(self) -> None:
        self.filtered = None
        self.elapsed = 0.0
        self.failed = False
        self.samples = 0
        self.last_reading = 0.0

    def calibrate(self, reference: float, indicated: float) -> None:
        """Adjust the bias so a known reference reads correctly."""
        self.spec.bias -= indicated - reference


class SensorArray:
    """A named collection of sensors sampled together."""

    def __init__(self, seed: int | None = None) -> None:
        self.sensors: dict[str, tuple[Sensor, Callable[[object], float]]] = {}
        self._seed = seed
        self._counter = 0

    def add(self, spec: SensorSpec,
            accessor: Callable[[object], float]) -> Sensor:
        if spec.name in self.sensors:
            raise ValueError(f"duplicate sensor {spec.name!r}")
        seed = None if self._seed is None else self._seed + self._counter
        self._counter += 1
        sensor = Sensor(spec, seed)
        self.sensors[spec.name] = (sensor, accessor)
        return sensor

    def sample(self, state: object, dt: float = 0.0) -> dict[str, float]:
        return {name: sensor.read(float(accessor(state)), dt)
                for name, (sensor, accessor) in self.sensors.items()}

    def truth(self, state: object) -> dict[str, float]:
        return {name: float(accessor(state))
                for name, (_, accessor) in self.sensors.items()}

    def errors(self, state: object) -> dict[str, float]:
        truth = self.truth(state)
        return {name: sensor.last_reading - truth[name]
                for name, (sensor, _) in self.sensors.items()}

    def failed(self) -> list[str]:
        return [name for name, (sensor, _) in self.sensors.items() if sensor.failed]

    def reset(self) -> None:
        for sensor, _ in self.sensors.values():
            sensor.reset()

    def __len__(self) -> int:
        return len(self.sensors)


def thermocouple(name: str = "T", type_letter: str = "K",
                 seed: int | None = None) -> Sensor:
    """A representative thermocouple with its class-2 tolerance as noise.

    Type K class 2 tolerance is the greater of 2.5 K or 0.0075|T|; the constant
    part is used here as the noise sigma, which is conservative at high
    temperature and about right in the middle of the range.
    """
    ranges = {"K": (73.0, 1645.0), "J": (63.0, 1033.0), "T": (73.0, 673.0),
              "N": (73.0, 1573.0), "S": (223.0, 2033.0)}
    lo, hi = ranges.get(type_letter.upper(), (73.0, 1645.0))
    return Sensor(SensorSpec(name, "K", lo, hi, noise_sigma=2.5, bias=0.0,
                             resolution=0.1, time_constant=1.5), seed)


def current_transducer(name: str = "I", rating: float = 200.0,
                       seed: int | None = None) -> Sensor:
    """A Hall-effect current transducer with 1 % accuracy."""
    return Sensor(SensorSpec(name, "A", -rating, rating,
                             noise_sigma=0.005 * rating,
                             bias=0.002 * rating, resolution=rating / 4096.0,
                             time_constant=1e-3), seed)


def pressure_transducer(name: str = "p", rating: float = 1e7,
                        seed: int | None = None) -> Sensor:
    """A piezoresistive pressure transducer with 0.5 % accuracy."""
    return Sensor(SensorSpec(name, "Pa", 0.0, rating,
                             noise_sigma=0.002 * rating,
                             bias=0.001 * rating, resolution=rating / 65536.0,
                             time_constant=5e-4), seed)
