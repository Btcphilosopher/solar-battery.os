"""Telemetry logging: ring buffers, CSV export and replay."""
from __future__ import annotations

import csv
import io
import json
import math
import os
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable, Iterator, Mapping, Sequence


class RingBuffer:
    """A fixed-capacity buffer of telemetry records.

    Bounded memory is not an optimisation here: a long-running digital twin
    with unbounded history will exhaust memory, and silently dropping the
    oldest data is better than crashing -- provided it is explicit, which
    :attr:`dropped` makes it.
    """

    def __init__(self, capacity: int = 100_000) -> None:
        if capacity < 1:
            raise ValueError("capacity must be at least 1")
        self.capacity = capacity
        self._data: deque[dict[str, Any]] = deque(maxlen=capacity)
        self.dropped = 0

    def append(self, record: Mapping[str, Any]) -> None:
        if len(self._data) == self.capacity:
            self.dropped += 1
        self._data.append(dict(record))

    def extend(self, records: Iterable[Mapping[str, Any]]) -> None:
        for record in records:
            self.append(record)

    def latest(self, n: int = 1) -> list[dict[str, Any]]:
        if n < 1:
            raise ValueError("n must be at least 1")
        return list(self._data)[-n:]

    def series(self, key: str) -> list[float]:
        return [row[key] for row in self._data if key in row]

    def keys(self) -> list[str]:
        found: list[str] = []
        for row in self._data:
            for key in row:
                if key not in found:
                    found.append(key)
        return found

    def clear(self) -> None:
        self._data.clear()
        self.dropped = 0

    def __len__(self) -> int:
        return len(self._data)

    def __iter__(self) -> Iterator[dict[str, Any]]:
        return iter(list(self._data))

    def __getitem__(self, index: int) -> dict[str, Any]:
        return list(self._data)[index]


class TelemetryLogger:
    """Records timestamped records and writes them out.

    ``stride`` decimates the log without changing the simulation timestep,
    which is how a 1 kHz model produces a 10 Hz log without either lying about
    its resolution or producing an unusable file.
    """

    def __init__(self, capacity: int = 100_000, stride: int = 1,
                 fields: Sequence[str] | None = None) -> None:
        if stride < 1:
            raise ValueError("stride must be at least 1")
        self.buffer = RingBuffer(capacity)
        self.stride = stride
        self.fields = list(fields) if fields else None
        self.counter = 0

    def log(self, record: Mapping[str, Any]) -> bool:
        """Record a sample; returns whether it was kept."""
        self.counter += 1
        if (self.counter - 1) % self.stride != 0:
            return False
        if self.fields is not None:
            record = {k: record[k] for k in self.fields if k in record}
        self.buffer.append(record)
        return True

    def to_csv(self, path: str) -> str:
        """Write the buffer to a CSV file; returns the path."""
        rows = list(self.buffer)
        if not rows:
            raise ValueError("no telemetry to write")
        keys = self.fields or self.buffer.keys()
        with open(path, "w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=keys, extrasaction="ignore")
            writer.writeheader()
            writer.writerows(rows)
        return path

    def to_csv_string(self) -> str:
        rows = list(self.buffer)
        keys = self.fields or self.buffer.keys()
        out = io.StringIO()
        writer = csv.DictWriter(out, fieldnames=keys, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
        return out.getvalue()

    def to_json(self, path: str) -> str:
        with open(path, "w", encoding="utf-8") as handle:
            json.dump(list(self.buffer), handle, indent=2, default=str)
        return path

    def statistics(self, key: str) -> dict[str, float]:
        values = [v for v in self.buffer.series(key)
                  if isinstance(v, (int, float)) and math.isfinite(v)]
        if not values:
            raise KeyError(f"no numeric samples for {key!r}")
        n = len(values)
        mean = sum(values) / n
        variance = sum((v - mean) ** 2 for v in values) / (n - 1) if n > 1 else 0.0
        ordered = sorted(values)
        return {"count": float(n), "mean": mean, "std": math.sqrt(variance),
                "min": ordered[0], "max": ordered[-1],
                "median": ordered[n // 2]}

    def clear(self) -> None:
        self.buffer.clear()
        self.counter = 0

    def __len__(self) -> int:
        return len(self.buffer)


class CSVReplay:
    """Replays a recorded CSV as a telemetry stream.

    Used to drive a digital twin from historical data.  Numeric conversion is
    attempted per field and falls back to the raw string, so mixed-type logs
    replay without silently coercing labels to ``nan``.
    """

    def __init__(self, path: str, time_key: str = "time") -> None:
        if not os.path.exists(path):
            raise FileNotFoundError(f"telemetry file not found: {path}")
        self.path = path
        self.time_key = time_key
        self.records: list[dict[str, Any]] = []
        self._load()

    def _load(self) -> None:
        with open(self.path, newline="", encoding="utf-8") as handle:
            for raw in csv.DictReader(handle):
                record: dict[str, Any] = {}
                for key, value in raw.items():
                    if value is None or value == "":
                        continue
                    try:
                        record[key] = float(value)
                    except ValueError:
                        record[key] = value
                self.records.append(record)

    @property
    def duration(self) -> float:
        if len(self.records) < 2:
            return 0.0
        return float(self.records[-1].get(self.time_key, 0.0)
                     - self.records[0].get(self.time_key, 0.0))

    def at(self, t: float) -> dict[str, Any]:
        """Nearest record at or before time ``t``."""
        best = self.records[0] if self.records else {}
        for record in self.records:
            if float(record.get(self.time_key, 0.0)) <= t:
                best = record
            else:
                break
        return dict(best)

    def interpolate(self, t: float, key: str) -> float:
        """Linearly interpolate one numeric channel at time ``t``."""
        previous: tuple[float, float] | None = None
        for record in self.records:
            timestamp = float(record.get(self.time_key, 0.0))
            value = record.get(key)
            if not isinstance(value, (int, float)):
                continue
            if timestamp >= t:
                if previous is None:
                    return float(value)
                t0, v0 = previous
                span = timestamp - t0
                if span <= 0.0:
                    return float(value)
                return v0 + (float(value) - v0) * (t - t0) / span
            previous = (timestamp, float(value))
        return previous[1] if previous else 0.0

    def channels(self) -> list[str]:
        found: list[str] = []
        for record in self.records:
            for key in record:
                if key not in found:
                    found.append(key)
        return found

    def __len__(self) -> int:
        return len(self.records)

    def __iter__(self) -> Iterator[dict[str, Any]]:
        return iter(self.records)
