"""Objective and constraint builders for power optimisation."""
from __future__ import annotations

import math
from typing import Callable, Mapping, Sequence

from .optimiser import Constraint, DesignVariable, Objective, Optimiser, OptimisationResult


def net_electrical_objective(output_key: str = "electrical_power",
                             parasitic_key: str | None = "parasitic_power"
                             ) -> Objective:
    """Maximise net electrical output, subtracting any parasitic load.

    Optimising gross output is a common and expensive mistake: it happily
    spends 12 kW of cooling to gain 8 kW of generation.  Netting the
    parasitics off makes the trade-off explicit.
    """
    def fn(result: Mapping[str, float]) -> float:
        gross = result.get(output_key, 0.0)
        parasitic = result.get(parasitic_key, 0.0) if parasitic_key else 0.0
        return gross - parasitic

    return Objective("net_electrical_power", fn, "maximise")


def power_density_objective(power_key: str = "electrical_power",
                            mass_key: str = "mass") -> Objective:
    """Maximise power per unit mass."""
    def fn(result: Mapping[str, float]) -> float:
        mass = result.get(mass_key, 0.0)
        return result.get(power_key, 0.0) / mass if mass > 0.0 else 0.0

    return Objective("power_density", fn, "maximise")


def temperature_limit(key: str = "temperature", limit: float = 1200.0,
                      name: str = "temperature_limit") -> Constraint:
    """Cap a temperature reported by the model."""
    return Constraint(name, lambda r: r.get(key, 0.0), limit, "upper")


def current_limit(key: str = "current", limit: float = 100.0,
                  name: str = "current_limit") -> Constraint:
    return Constraint(name, lambda r: r.get(key, 0.0), limit, "upper")


def pressure_limit(key: str = "pressure", limit: float = 1e7,
                   name: str = "pressure_limit") -> Constraint:
    return Constraint(name, lambda r: r.get(key, 0.0), limit, "upper")


def fuel_limit(key: str = "fuel_flow", limit: float = 0.01,
               name: str = "fuel_limit") -> Constraint:
    return Constraint(name, lambda r: r.get(key, 0.0), limit, "upper")


def thermal_limit(key: str = "heat_rejection", limit: float = 1e5,
                  name: str = "thermal_limit") -> Constraint:
    """Cap the heat that must be rejected, i.e. the cooling capacity."""
    return Constraint(name, lambda r: r.get(key, 0.0), limit, "upper")


def minimum_output(key: str = "electrical_power", floor: float = 0.0,
                   name: str = "minimum_output") -> Constraint:
    return Constraint(name, lambda r: r.get(key, 0.0), floor, "lower")


def optimise_operating_point(
        evaluate: Callable[[dict[str, float]], Mapping[str, float]],
        variables: Sequence[DesignVariable],
        constraints: Sequence[Constraint] = (),
        objective: Objective | None = None,
        method: str = "auto") -> OptimisationResult:
    """Find the operating point maximising net electrical output.

    This is the function behind the headline API in section 15 of the
    specification: give it the levers, the limits, and a model, and it returns
    the best feasible setting of the levers.
    """
    obj = objective or net_electrical_objective()
    return Optimiser(evaluate, variables, obj, constraints,
                     method=method).solve()  # type: ignore[arg-type]


def dispatch_optimisation(capacities: Sequence[float], costs: Sequence[float],
                          demand: float,
                          efficiencies: Sequence[float] | None = None
                          ) -> dict[str, float]:
    """Least-cost dispatch across sources with fixed marginal costs.

    With constant marginal costs the optimum is a merit-order stack, so this
    is solved exactly rather than numerically.  Returns the allocation plus
    the achieved cost, and reports any unmet demand rather than silently
    scaling the answer.
    """
    if len(capacities) != len(costs):
        raise ValueError("capacities and costs must have equal length")
    etas = list(efficiencies) if efficiencies else [1.0] * len(capacities)
    if len(etas) != len(capacities):
        raise ValueError("efficiencies must match the number of sources")
    order = sorted(range(len(capacities)), key=lambda i: costs[i] / max(etas[i], 1e-9))
    allocation = [0.0] * len(capacities)
    remaining = max(0.0, demand)
    for i in order:
        take = min(capacities[i], remaining)
        allocation[i] = take
        remaining -= take
        if remaining <= 0.0:
            break
    total_cost = sum(allocation[i] * costs[i] / max(etas[i], 1e-9)
                     for i in range(len(allocation)))
    return {"allocation": allocation, "cost": total_cost,
            "unmet": remaining}  # type: ignore[dict-item]
