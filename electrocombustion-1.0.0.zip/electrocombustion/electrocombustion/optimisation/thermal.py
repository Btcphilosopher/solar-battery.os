"""Thermal optimisation: cooling sizing and temperature management."""
from __future__ import annotations

import math
from typing import Callable, Mapping, Sequence

from ..thermal.heat_transfer import CoolingCircuit, HeatExchanger
from .optimiser import Constraint, DesignVariable, Objective, Optimiser, OptimisationResult


def minimise_peak_temperature(key: str = "peak_temperature") -> Objective:
    """Minimise the highest temperature reached."""
    return Objective("peak_temperature", lambda r: r.get(key, 0.0), "minimise")


def minimise_cooling_power(key: str = "cooling_power") -> Objective:
    """Minimise the parasitic power spent on cooling."""
    return Objective("cooling_power", lambda r: r.get(key, 0.0), "minimise")


def required_cooling(heat_load: float, body_temperature: float,
                     coolant_inlet: float, ua: float,
                     specific_heat: float = 4181.0) -> float:
    """Coolant mass flow needed to remove ``heat_load`` watts (kg/s).

    Inverts the exponential-approach form used by :class:`CoolingCircuit`.
    Raises when the requested duty exceeds what the temperature difference and
    UA can physically achieve, which is the honest failure mode: no amount of
    flow will remove heat that has no driving temperature difference.
    """
    delta = body_temperature - coolant_inlet
    if delta <= 0.0:
        raise ValueError(
            "no temperature difference available: the coolant is not colder "
            "than the body"
        )
    if heat_load <= 0.0:
        return 0.0
    ceiling = ua * delta
    if heat_load >= ceiling:
        raise ValueError(
            f"heat load {heat_load:g} W exceeds the UA-limited maximum "
            f"{ceiling:g} W at this temperature difference"
        )
    lo, hi = 1e-9, 1e4
    for _ in range(300):
        mid = math.sqrt(lo * hi)
        circuit = CoolingCircuit(mass_flow=mid, specific_heat=specific_heat,
                                 inlet_temperature=coolant_inlet, ua=ua)
        removed = circuit.heat_removed(body_temperature)
        if abs(removed - heat_load) < 1e-9:
            return mid
        if removed < heat_load:
            lo = mid
        else:
            hi = mid
    return math.sqrt(lo * hi)


def size_heat_exchanger(duty: float, t_hot_in: float, t_cold_in: float,
                        hot_capacity_rate: float, cold_capacity_rate: float,
                        arrangement: str = "counterflow") -> float:
    """UA required to achieve ``duty`` watts (W/K)."""
    hx = HeatExchanger(ua=1.0, hot_capacity_rate=hot_capacity_rate,
                       cold_capacity_rate=cold_capacity_rate,
                       arrangement=arrangement)  # type: ignore[arg-type]
    return hx.required_ua(duty, t_hot_in, t_cold_in)


def thermal_margin_constraint(key: str = "temperature", limit: float = 1200.0,
                              margin: float = 50.0,
                              name: str = "thermal_margin") -> Constraint:
    """Keep a temperature at least ``margin`` kelvin below ``limit``."""
    return Constraint(name, lambda r: r.get(key, 0.0), limit - margin, "upper")


def optimise_cooling(evaluate: Callable[[dict[str, float]], Mapping[str, float]],
                     variables: Sequence[DesignVariable],
                     temperature_key: str = "temperature",
                     temperature_limit: float = 1200.0,
                     power_key: str = "cooling_power",
                     method: str = "auto") -> OptimisationResult:
    """Find the cheapest cooling that keeps the temperature within limit."""
    objective = minimise_cooling_power(power_key)
    constraint = Constraint("temperature", lambda r: r.get(temperature_key, 0.0),
                            temperature_limit, "upper")
    return Optimiser(evaluate, variables, objective, [constraint],
                     method=method).solve()  # type: ignore[arg-type]
