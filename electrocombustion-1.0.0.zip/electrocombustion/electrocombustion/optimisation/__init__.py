"""Optimisation and control: the engine's decision-making layer."""
from .optimiser import (
    Constraint, DesignVariable, Objective, OptimisationResult, Optimiser,
    maximise_output, minimise_cost,
)
from .control import (
    BangBangController, FeedforwardController, GainSchedule, PIDController,
    RateLimiter, SupervisoryController,
)
from .power import (
    current_limit, dispatch_optimisation, fuel_limit, minimum_output,
    net_electrical_objective, optimise_operating_point, power_density_objective,
    pressure_limit, temperature_limit, thermal_limit,
)
from .thermal import (
    minimise_cooling_power, minimise_peak_temperature, optimise_cooling,
    required_cooling, size_heat_exchanger, thermal_margin_constraint,
)
from .efficiency import (
    carbon_objective, exergy_efficiency_objective, optimise_efficiency,
    sensitivity, specific_consumption_objective, thermal_efficiency_objective,
    weighted_objective,
)
from .mpc import (
    MPCConfig, ModelPredictiveController, economic_cost, tracking_cost,
)

__all__ = [
    "Constraint", "DesignVariable", "Objective", "OptimisationResult",
    "Optimiser", "maximise_output", "minimise_cost", "BangBangController",
    "FeedforwardController", "GainSchedule", "PIDController", "RateLimiter",
    "SupervisoryController", "current_limit", "dispatch_optimisation",
    "fuel_limit", "minimum_output", "net_electrical_objective",
    "optimise_operating_point", "power_density_objective", "pressure_limit",
    "temperature_limit", "thermal_limit", "minimise_cooling_power",
    "minimise_peak_temperature", "optimise_cooling", "required_cooling",
    "size_heat_exchanger", "thermal_margin_constraint", "carbon_objective",
    "exergy_efficiency_objective", "optimise_efficiency", "sensitivity",
    "specific_consumption_objective", "thermal_efficiency_objective",
    "weighted_objective", "MPCConfig", "ModelPredictiveController",
    "economic_cost", "tracking_cost",
]
