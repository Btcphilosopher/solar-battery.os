"""Efficiency optimisation objectives and helpers."""
from __future__ import annotations

import math
from typing import Callable, Mapping, Sequence

from .optimiser import (
    Constraint, DesignVariable, Objective, Optimiser, OptimisationResult,
)


def thermal_efficiency_objective(output_key: str = "electrical_power",
                                 input_key: str = "chemical_power") -> Objective:
    """Maximise output over input.

    Guarded so that a zero-input point returns zero efficiency instead of a
    division error, which matters because optimisers do probe the boundary.
    """
    def fn(result: Mapping[str, float]) -> float:
        denominator = result.get(input_key, 0.0)
        if denominator <= 0.0:
            return 0.0
        return result.get(output_key, 0.0) / denominator

    return Objective("thermal_efficiency", fn, "maximise")


def exergy_efficiency_objective(work_key: str = "electrical_power",
                                heat_key: str = "heat_input",
                                source_temperature_key: str = "source_temperature",
                                ambient_key: str = "ambient_temperature"
                                ) -> Objective:
    """Maximise second-law (exergy) efficiency.

    Compares the work produced against the *available* work in the heat
    supplied, ``Q (1 - T0/T)``.  This is the more meaningful figure when
    comparing devices operating between different temperatures, because a 20 %
    efficient device running on 400 K heat may be closer to its limit than a
    45 % efficient device running on 1500 K heat.
    """
    def fn(result: Mapping[str, float]) -> float:
        heat = result.get(heat_key, 0.0)
        t_source = result.get(source_temperature_key, 0.0)
        t_ambient = result.get(ambient_key, 298.15)
        if heat <= 0.0 or t_source <= t_ambient or t_ambient <= 0.0:
            return 0.0
        available = heat * (1.0 - t_ambient / t_source)
        if available <= 0.0:
            return 0.0
        return result.get(work_key, 0.0) / available

    return Objective("exergy_efficiency", fn, "maximise")


def specific_consumption_objective(fuel_key: str = "fuel_flow",
                                   output_key: str = "electrical_power"
                                   ) -> Objective:
    """Minimise fuel consumed per unit output (kg/J)."""
    def fn(result: Mapping[str, float]) -> float:
        output = result.get(output_key, 0.0)
        if output <= 0.0:
            return 1e12
        return result.get(fuel_key, 0.0) / output

    return Objective("specific_consumption", fn, "minimise")


def carbon_objective(co2_key: str = "co2_rate",
                     output_key: str = "electrical_power") -> Objective:
    """Minimise CO2 per unit useful output."""
    def fn(result: Mapping[str, float]) -> float:
        output = result.get(output_key, 0.0)
        if output <= 0.0:
            return 1e12
        return result.get(co2_key, 0.0) / output

    return Objective("carbon_intensity", fn, "minimise")


def weighted_objective(objectives: Sequence[tuple[Objective, float]],
                       name: str = "weighted") -> Objective:
    """Combine several objectives into one weighted cost.

    Each component keeps its own sense, so maximising efficiency while
    minimising emissions composes correctly without sign bookkeeping at the
    call site.
    """
    if not objectives:
        raise ValueError("at least one objective is required")

    def fn(result: Mapping[str, float]) -> float:
        total = 0.0
        for objective, weight in objectives:
            total += weight * objective.cost(result)
        return total

    return Objective(name, fn, "minimise")


def optimise_efficiency(evaluate: Callable[[dict[str, float]], Mapping[str, float]],
                        variables: Sequence[DesignVariable],
                        constraints: Sequence[Constraint] = (),
                        output_key: str = "electrical_power",
                        input_key: str = "chemical_power",
                        method: str = "auto") -> OptimisationResult:
    """Maximise conversion efficiency subject to the given constraints."""
    objective = thermal_efficiency_objective(output_key, input_key)
    return Optimiser(evaluate, variables, objective, constraints,
                     method=method).solve()  # type: ignore[arg-type]


def sensitivity(evaluate: Callable[[dict[str, float]], Mapping[str, float]],
                base: Mapping[str, float], key: str,
                perturbation: float = 0.01) -> dict[str, float]:
    """One-at-a-time sensitivity of ``key`` to each input.

    Returns the normalised elasticity ``(dy/y)/(dx/x)`` for each variable,
    which is dimensionless and therefore directly comparable across inputs of
    different units.
    """
    baseline = dict(evaluate(dict(base)))
    reference = baseline.get(key, 0.0)
    out: dict[str, float] = {}
    for name, value in base.items():
        step = abs(value) * perturbation if value != 0.0 else perturbation
        perturbed = dict(base)
        perturbed[name] = value + step
        result = dict(evaluate(perturbed))
        delta = result.get(key, 0.0) - reference
        if reference != 0.0 and value != 0.0:
            out[name] = (delta / reference) / (step / value)
        else:
            out[name] = delta / step
    return out
