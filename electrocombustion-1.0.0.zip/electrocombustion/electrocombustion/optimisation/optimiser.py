"""The constrained optimisation core.

Section 15 of the specification makes optimisation a first-class component
rather than an add-on.  This module provides the vocabulary -- design
variables, objectives, constraints -- and a solver façade over SciPy that
degrades gracefully to a pure-Python search when SciPy is unavailable.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable, Literal, Mapping, Sequence

import numpy as np

try:  # pragma: no cover - exercised implicitly by the import
    from scipy.optimize import differential_evolution, minimize
    _HAVE_SCIPY = True
except ImportError:  # pragma: no cover - fallback path
    _HAVE_SCIPY = False


@dataclass(slots=True)
class DesignVariable:
    """A decision variable with bounds and an optional scale.

    ``scale`` is the magnitude of a meaningful change in the variable.  The
    optimiser works in scaled coordinates, which is what stops a problem
    mixing fuel flows (1e-3) with electrical power (1e5) from being
    ill-conditioned.
    """

    name: str
    lower: float
    upper: float
    initial: float | None = None
    scale: float | None = None

    def __post_init__(self) -> None:
        if self.lower > self.upper:
            raise ValueError(f"{self.name}: lower bound exceeds upper bound")
        if self.initial is None:
            self.initial = 0.5 * (self.lower + self.upper)
        if not self.lower <= self.initial <= self.upper:
            raise ValueError(f"{self.name}: initial value is outside the bounds")
        if self.scale is None:
            span = self.upper - self.lower
            self.scale = span if span > 0.0 else max(abs(self.initial), 1.0)
        if self.scale <= 0.0:
            raise ValueError(f"{self.name}: scale must be positive")

    def clip(self, value: float) -> float:
        return min(self.upper, max(self.lower, value))

    def normalise(self, value: float) -> float:
        span = self.upper - self.lower
        return (value - self.lower) / span if span > 0.0 else 0.0

    def denormalise(self, unit_value: float) -> float:
        return self.lower + (self.upper - self.lower) * min(1.0, max(0.0, unit_value))


@dataclass(slots=True)
class Constraint:
    """An inequality or equality constraint on the model output.

    ``fn`` maps the evaluated model result to a scalar.  For ``kind='upper'``
    the constraint is ``fn(result) <= bound``; for ``'lower'`` it is
    ``fn(result) >= bound``; for ``'equal'`` it is ``|fn(result) - bound| <=
    tolerance``.
    """

    name: str
    fn: Callable[[Mapping[str, float]], float]
    bound: float
    kind: Literal["upper", "lower", "equal"] = "upper"
    tolerance: float = 1e-6
    penalty_weight: float = 1e6
    scale: float | None = None

    def __post_init__(self) -> None:
        if self.scale is None:
            self.scale = max(abs(self.bound), 1e-9)
        if self.scale <= 0.0:
            raise ValueError(f"{self.name}: scale must be positive")

    def scaled_margin(self, result: Mapping[str, float]) -> float:
        """:meth:`margin` divided by the constraint scale.

        Solvers weight all constraints equally, so a limit expressed in
        kilograms per second (1e-3) and one in watts (1e5) would otherwise be
        treated as though the second mattered a hundred million times more.
        """
        return self.margin(result) / float(self.scale)

    def violation(self, result: Mapping[str, float]) -> float:
        """Amount by which the constraint is violated (0 when satisfied)."""
        value = float(self.fn(result))
        if self.kind == "upper":
            return max(0.0, value - self.bound)
        if self.kind == "lower":
            return max(0.0, self.bound - value)
        return max(0.0, abs(value - self.bound) - self.tolerance)

    def satisfied(self, result: Mapping[str, float]) -> bool:
        """Whether the constraint holds within its *relative* tolerance.

        The tolerance is scaled by the constraint's own magnitude.  An
        absolute tolerance cannot work here: an optimum almost always sits
        exactly on a constraint boundary, so a 90 kW limit tested to 1e-6 W
        would report every genuine optimum as infeasible.
        """
        return self.violation(result) <= max(self.tolerance * float(self.scale),
                                             self.tolerance)

    def margin(self, result: Mapping[str, float]) -> float:
        """Signed slack: positive when satisfied, negative when violated."""
        value = float(self.fn(result))
        if self.kind == "upper":
            return self.bound - value
        if self.kind == "lower":
            return value - self.bound
        return self.tolerance - abs(value - self.bound)


@dataclass(slots=True)
class Objective:
    """What the optimiser is trying to achieve.

    ``fn`` maps the model result to a scalar figure of merit.  ``sense`` is
    ``'maximise'`` or ``'minimise'``; the solver always minimises internally
    and negates as required.
    """

    name: str
    fn: Callable[[Mapping[str, float]], float]
    sense: Literal["maximise", "minimise"] = "maximise"
    weight: float = 1.0

    def value(self, result: Mapping[str, float]) -> float:
        return float(self.fn(result))

    def cost(self, result: Mapping[str, float]) -> float:
        """Signed value the solver minimises."""
        v = self.value(result)
        return -v * self.weight if self.sense == "maximise" else v * self.weight


@dataclass(slots=True)
class OptimisationResult:
    """Outcome of an optimisation run."""

    variables: dict[str, float]
    objective_value: float
    result: dict[str, float]
    success: bool
    iterations: int
    message: str = ""
    constraint_margins: dict[str, float] = field(default_factory=dict)
    feasible: bool = True
    history: list[tuple[dict[str, float], float]] = field(default_factory=list)

    def __getitem__(self, key: str) -> float:
        if key in self.variables:
            return self.variables[key]
        return self.result[key]

    def summary(self) -> dict[str, Any]:
        return {
            "objective": self.objective_value, "success": self.success,
            "feasible": self.feasible, "iterations": self.iterations,
            "variables": dict(self.variables),
            "constraints": dict(self.constraint_margins),
            "message": self.message,
        }

    def __repr__(self) -> str:
        status = "feasible" if self.feasible else "INFEASIBLE"
        return (f"OptimisationResult(objective={self.objective_value:.6g}, "
                f"{status}, iterations={self.iterations})")


class Optimiser:
    """Constrained optimiser over a user-supplied evaluation function.

    Parameters
    ----------
    evaluate:
        ``fn(variables: dict[str, float]) -> dict[str, float]``.  The returned
        mapping is what objectives and constraints are computed from, so it
        should contain every quantity the caller cares about.
    variables:
        The design space.
    objective:
        What to optimise.
    constraints:
        Operating limits.  Handled natively by SLSQP and by penalty otherwise.
    """

    def __init__(self, evaluate: Callable[[dict[str, float]], Mapping[str, float]],
                 variables: Sequence[DesignVariable], objective: Objective,
                 constraints: Sequence[Constraint] = (),
                 method: Literal["slsqp", "nelder-mead", "differential_evolution",
                                 "grid", "auto"] = "auto",
                 record_history: bool = False) -> None:
        if not variables:
            raise ValueError("at least one design variable is required")
        self.evaluate = evaluate
        self.variables = list(variables)
        self.objective = objective
        self.constraints = list(constraints)
        self.method = method
        self.record_history = record_history
        self.evaluations = 0
        self.history: list[tuple[dict[str, float], float]] = []

    # -- helpers ------------------------------------------------------------
    def _unpack(self, vector: Sequence[float]) -> dict[str, float]:
        """Map a *normalised* solver vector back to physical values."""
        return {v.name: v.clip(v.denormalise(float(x)))
                for v, x in zip(self.variables, vector)}

    def _run_model(self, vector: Sequence[float]) -> tuple[dict[str, float], dict[str, float]]:
        values = self._unpack(vector)
        result = dict(self.evaluate(values))
        self.evaluations += 1
        return values, result

    def _cost(self, vector: Sequence[float], penalise: bool = True) -> float:
        values, result = self._run_model(vector)
        cost = self.objective.cost(result)
        if penalise:
            reference = max(abs(self.objective.cost(result)), 1.0)
            for constraint in self.constraints:
                violation = constraint.violation(result) / float(constraint.scale)
                if violation > 0.0:
                    cost += constraint.penalty_weight * reference * violation ** 2
        if self.record_history:
            self.history.append((values, cost))
        if not math.isfinite(cost):
            return 1e30
        return cost

    def _bounds(self) -> list[tuple[float, float]]:
        """Solver bounds; always the unit box because we work normalised."""
        return [(0.0, 1.0) for _ in self.variables]

    def _x0(self) -> list[float]:
        return [v.normalise(float(v.initial)) for v in self.variables]

    def _finalise(self, vector: Sequence[float], success: bool,
                  iterations: int, message: str) -> OptimisationResult:
        values, result = self._run_model(vector)
        margins = {c.name: c.margin(result) for c in self.constraints}
        feasible = all(c.satisfied(result) for c in self.constraints)
        return OptimisationResult(
            variables=values, objective_value=self.objective.value(result),
            result=result, success=success, iterations=iterations,
            message=message, constraint_margins=margins, feasible=feasible,
            history=list(self.history),
        )

    # -- solvers ------------------------------------------------------------
    def solve(self, **kwargs: Any) -> OptimisationResult:
        """Run the optimisation and return the best feasible point found."""
        method = self.method
        if method == "auto":
            return self._solve_auto(**kwargs)
        if method == "slsqp":
            return self._solve_slsqp(**kwargs)
        if method == "nelder-mead":
            return self._solve_scipy("Nelder-Mead", **kwargs)
        if method == "differential_evolution":
            return self._solve_de(**kwargs)
        if method == "grid":
            return self._solve_grid(**kwargs)
        raise ValueError(f"unknown optimisation method {method!r}")

    def _solve_auto(self, **kwargs: Any) -> OptimisationResult:
        """Gradient search, global search, then a polish of the global result.

        SLSQP is fast and usually right, but it stalls or reports false
        convergence on problems whose objective is only piecewise smooth --
        which happens whenever the model contains a bisection, a clamp or a
        regime switch, i.e. most real energy models.  Differential evolution
        finds the right basin but leaves the answer a little off the
        constraint boundary, so it is polished with a constrained gradient
        step from its own result.  The best *feasible* candidate wins.

        If nothing feasible is found, the least-violating candidate is
        returned with ``feasible=False`` rather than a silently invalid
        answer.
        """
        if not _HAVE_SCIPY:
            return self._solve_grid(**kwargs)
        candidates: list[OptimisationResult] = []
        candidates.append(self._solve_slsqp(**kwargs))
        self.history.clear()
        globally = self._solve_de(**kwargs)
        candidates.append(globally)
        start = [v.normalise(globally.variables[v.name]) for v in self.variables]
        self.history.clear()
        candidates.append(self._solve_slsqp(start=start, **kwargs))
        feasible = [c for c in candidates if c.feasible]
        pool = feasible or candidates
        sense = self.objective.sense
        best = (max(pool, key=lambda c: c.objective_value) if sense == "maximise"
                else min(pool, key=lambda c: c.objective_value))
        if not feasible:
            best.message = (f"{best.message}; no feasible point found by "
                            f"gradient or global search")
        return best

    def _solve_slsqp(self, max_iterations: int = 200,
                     start: Sequence[float] | None = None,
                     **kwargs: Any) -> OptimisationResult:
        if not _HAVE_SCIPY:  # pragma: no cover - fallback
            return self._solve_grid(**kwargs)
        scipy_constraints = []
        for constraint in self.constraints:
            def make(c: Constraint):
                def fn(x: np.ndarray) -> float:
                    _, result = self._run_model(x)
                    return c.scaled_margin(result)
                return fn
            scipy_constraints.append({"type": "ineq", "fun": make(constraint)})
        outcome = minimize(
            lambda x: self._cost(x, penalise=not scipy_constraints),
            list(start) if start is not None else self._x0(),
            method="SLSQP", bounds=self._bounds(),
            constraints=scipy_constraints,
            options={"maxiter": max_iterations, "ftol": kwargs.get("ftol", 1e-9)},
        )
        return self._finalise(outcome.x, bool(outcome.success),
                              int(outcome.get("nit", 0)), str(outcome.message))

    def _solve_scipy(self, method: str, max_iterations: int = 500,
                     **kwargs: Any) -> OptimisationResult:
        if not _HAVE_SCIPY:  # pragma: no cover - fallback
            return self._solve_grid(**kwargs)
        outcome = minimize(self._cost, self._x0(), method=method,
                           bounds=self._bounds(),
                           options={"maxiter": max_iterations})
        return self._finalise(outcome.x, bool(outcome.success),
                              int(outcome.get("nit", 0)), str(outcome.message))

    def _solve_de(self, max_iterations: int = 100, seed: int | None = 0,
                  population: int = 15, **kwargs: Any) -> OptimisationResult:
        if not _HAVE_SCIPY:  # pragma: no cover - fallback
            return self._solve_grid(**kwargs)
        outcome = differential_evolution(
            self._cost, self._bounds(), maxiter=max_iterations, seed=seed,
            popsize=population, polish=True, tol=kwargs.get("tol", 1e-8))
        return self._finalise(outcome.x, bool(outcome.success),
                              int(outcome.nit), str(outcome.message))

    def _solve_grid(self, resolution: int = 11, refinements: int = 3,
                    **kwargs: Any) -> OptimisationResult:
        """Successive grid refinement.

        A dependency-free fallback: coarse grid, then repeatedly halve the
        search box around the incumbent.  Robust and predictable, though far
        more expensive than a gradient method in higher dimensions.
        """
        bounds = self._bounds()
        best_vector = self._x0()
        best_cost = self._cost(best_vector)
        for _ in range(refinements):
            axes = [np.linspace(lo, hi, resolution) for lo, hi in bounds]
            for index in np.ndindex(*(resolution,) * len(axes)):
                vector = [axes[d][index[d]] for d in range(len(axes))]
                cost = self._cost(vector)
                if cost < best_cost:
                    best_cost = cost
                    best_vector = vector
            new_bounds = []
            for (lo, hi), centre in zip(bounds, best_vector):
                span = (hi - lo) / 4.0
                new_bounds.append((max(lo, centre - span), min(hi, centre + span)))
            bounds = new_bounds
        return self._finalise(best_vector, True, refinements * resolution ** len(bounds),
                              "grid refinement complete")


def maximise_output(evaluate: Callable[[dict[str, float]], Mapping[str, float]],
                    variables: Sequence[DesignVariable],
                    output_key: str = "electrical_power",
                    constraints: Sequence[Constraint] = (),
                    **kwargs: Any) -> OptimisationResult:
    """Convenience wrapper: maximise one output subject to constraints."""
    objective = Objective(output_key, lambda r: r.get(output_key, 0.0), "maximise")
    return Optimiser(evaluate, variables, objective, constraints, **kwargs).solve()


def minimise_cost(evaluate: Callable[[dict[str, float]], Mapping[str, float]],
                  variables: Sequence[DesignVariable],
                  cost_key: str = "cost",
                  constraints: Sequence[Constraint] = (),
                  **kwargs: Any) -> OptimisationResult:
    """Convenience wrapper: minimise one output subject to constraints."""
    objective = Objective(cost_key, lambda r: r.get(cost_key, 0.0), "minimise")
    return Optimiser(evaluate, variables, objective, constraints, **kwargs).solve()
