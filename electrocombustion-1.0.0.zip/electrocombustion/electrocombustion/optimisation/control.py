"""Control: PID, feedforward, gain scheduling and supervisory logic."""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Callable, Mapping, Sequence

from ..core.state import SystemState


@dataclass(slots=True)
class PIDController:
    """A PID controller with anti-windup and output rate limiting.

    Anti-windup uses back-calculation: when the output saturates, the integral
    term is unwound in proportion to the saturation error.  This is preferable
    to simply freezing the integrator because it recovers faster and does not
    depend on the order in which limits are hit.
    """

    kp: float = 1.0
    ki: float = 0.0
    kd: float = 0.0
    setpoint: float = 0.0
    output_min: float = -math.inf
    output_max: float = math.inf
    rate_limit: float = math.inf
    derivative_filter: float = 0.1
    anti_windup_gain: float = 1.0
    integral: float = 0.0
    previous_error: float = 0.0
    previous_derivative: float = 0.0
    output: float = 0.0
    initialised: bool = False

    def __post_init__(self) -> None:
        if self.output_min > self.output_max:
            raise ValueError("output_min must not exceed output_max")
        if not 0.0 <= self.derivative_filter <= 1.0:
            raise ValueError("derivative filter must lie in 0..1")

    def reset(self, output: float = 0.0) -> None:
        self.integral = 0.0
        self.previous_error = 0.0
        self.previous_derivative = 0.0
        self.output = output
        self.initialised = False

    def update(self, measurement: float, dt: float,
               setpoint: float | None = None) -> float:
        """Compute the control output for one timestep."""
        if dt <= 0.0:
            raise ValueError("dt must be positive")
        target = self.setpoint if setpoint is None else setpoint
        error = target - measurement

        if not self.initialised:
            self.previous_error = error
            self.initialised = True

        raw_derivative = (error - self.previous_error) / dt
        alpha = self.derivative_filter
        derivative = (alpha * raw_derivative
                      + (1.0 - alpha) * self.previous_derivative)

        self.integral += error * dt
        unclamped = (self.kp * error + self.ki * self.integral
                     + self.kd * derivative)

        clamped = min(self.output_max, max(self.output_min, unclamped))
        if math.isfinite(self.rate_limit):
            maximum_change = self.rate_limit * dt
            clamped = min(self.output + maximum_change,
                          max(self.output - maximum_change, clamped))

        if self.ki != 0.0 and clamped != unclamped:
            self.integral += self.anti_windup_gain * (clamped - unclamped) / self.ki * dt

        self.previous_error = error
        self.previous_derivative = derivative
        self.output = clamped
        return clamped

    @property
    def saturated(self) -> bool:
        return self.output <= self.output_min or self.output >= self.output_max

    def tune_ziegler_nichols(self, ultimate_gain: float,
                             ultimate_period: float) -> None:
        """Apply classical Ziegler-Nichols PID tuning.

        This is a starting point, not a finished tune: ZN is aggressive and
        typically needs the derivative term softening on a plant with any
        measurement noise.
        """
        if ultimate_gain <= 0.0 or ultimate_period <= 0.0:
            raise ValueError("ultimate gain and period must be positive")
        self.kp = 0.6 * ultimate_gain
        self.ki = 1.2 * ultimate_gain / ultimate_period
        self.kd = 0.075 * ultimate_gain * ultimate_period


@dataclass(slots=True)
class GainSchedule:
    """Interpolates PID gains against a scheduling variable.

    Used when a plant's dynamics change substantially over its operating
    range -- for example a heater whose time constant falls as radiation takes
    over from convection.
    """

    points: Sequence[float]
    gains: Sequence[tuple[float, float, float]]

    def __post_init__(self) -> None:
        if len(self.points) != len(self.gains):
            raise ValueError("points and gains must have equal length")
        if len(self.points) < 2:
            raise ValueError("a gain schedule needs at least two points")
        if list(self.points) != sorted(self.points):
            raise ValueError("scheduling points must be increasing")

    def __call__(self, variable: float) -> tuple[float, float, float]:
        pts, gains = self.points, self.gains
        if variable <= pts[0]:
            return gains[0]
        if variable >= pts[-1]:
            return gains[-1]
        for i in range(len(pts) - 1):
            if pts[i] <= variable <= pts[i + 1]:
                span = pts[i + 1] - pts[i]
                frac = (variable - pts[i]) / span if span > 0.0 else 0.0
                return tuple(
                    g0 + frac * (g1 - g0)
                    for g0, g1 in zip(gains[i], gains[i + 1])
                )  # type: ignore[return-value]
        return gains[-1]  # pragma: no cover

    def apply(self, controller: PIDController, variable: float) -> None:
        controller.kp, controller.ki, controller.kd = self(variable)


@dataclass(slots=True)
class FeedforwardController:
    """Adds a model-based feedforward term to a feedback controller.

    Feedforward handles the known part of the problem; feedback cleans up the
    rest.  Keeping them separate makes it obvious which is doing the work.
    """

    model: Callable[[float], float]
    feedback: PIDController | None = None
    gain: float = 1.0

    def update(self, setpoint: float, measurement: float, dt: float) -> float:
        term = self.gain * float(self.model(setpoint))
        if self.feedback is not None:
            term += self.feedback.update(measurement, dt, setpoint)
        return term


class SupervisoryController:
    """Maps state to engine inputs using named control loops.

    Each loop is a PID plus an accessor that extracts its measurement from the
    :class:`SystemState`, and writes its output to a named input key.  This is
    the object the engine's ``run(controller=...)`` argument expects.
    """

    def __init__(self) -> None:
        self.loops: dict[str, tuple[PIDController, Callable[[SystemState], float], str]] = {}
        self.static_inputs: dict[str, float] = {}
        self.schedules: dict[str, tuple[GainSchedule, Callable[[SystemState], float]]] = {}
        self.last_outputs: dict[str, float] = {}

    def add_loop(self, name: str, controller: PIDController,
                 measurement: Callable[[SystemState], float],
                 output_key: str) -> "SupervisoryController":
        self.loops[name] = (controller, measurement, output_key)
        return self

    def add_schedule(self, loop: str, schedule: GainSchedule,
                     variable: Callable[[SystemState], float]) -> "SupervisoryController":
        if loop not in self.loops:
            raise KeyError(f"no control loop named {loop!r}")
        self.schedules[loop] = (schedule, variable)
        return self

    def set_input(self, key: str, value: float) -> "SupervisoryController":
        self.static_inputs[key] = float(value)
        return self

    def set_setpoint(self, loop: str, value: float) -> "SupervisoryController":
        if loop not in self.loops:
            raise KeyError(f"no control loop named {loop!r}")
        self.loops[loop][0].setpoint = float(value)
        return self

    def update(self, state: SystemState, dt: float) -> dict[str, float]:
        """Return the input mapping for this timestep."""
        outputs = dict(self.static_inputs)
        for name, (controller, measurement, key) in self.loops.items():
            if name in self.schedules:
                schedule, variable = self.schedules[name]
                schedule.apply(controller, variable(state))
            value = controller.update(measurement(state), dt)
            outputs[key] = value
            self.last_outputs[name] = value
        return outputs

    def reset(self) -> None:
        for controller, _, _ in self.loops.values():
            controller.reset()
        self.last_outputs.clear()


@dataclass(slots=True)
class BangBangController:
    """Hysteretic on/off control.

    The deadband is what stops a thermostat chattering; without it the
    controller switches every timestep once the measurement reaches setpoint.
    """

    setpoint: float = 0.0
    deadband: float = 1.0
    on_value: float = 1.0
    off_value: float = 0.0
    inverted: bool = False
    state: bool = False

    def update(self, measurement: float, dt: float = 0.0) -> float:
        high = self.setpoint + self.deadband / 2.0
        low = self.setpoint - self.deadband / 2.0
        if self.inverted:
            if measurement > high:
                self.state = True
            elif measurement < low:
                self.state = False
        else:
            if measurement < low:
                self.state = True
            elif measurement > high:
                self.state = False
        return self.on_value if self.state else self.off_value

    @property
    def duty_estimate(self) -> float:
        return 1.0 if self.state else 0.0


@dataclass(slots=True)
class RateLimiter:
    """Limits how fast a signal may change."""

    rate: float
    value: float = 0.0

    def __post_init__(self) -> None:
        if self.rate <= 0.0:
            raise ValueError("rate limit must be positive")

    def __call__(self, target: float, dt: float) -> float:
        maximum = self.rate * dt
        delta = min(maximum, max(-maximum, target - self.value))
        self.value += delta
        return self.value
