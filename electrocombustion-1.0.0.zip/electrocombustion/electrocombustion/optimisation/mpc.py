"""Model predictive control over the ELECTROCOMBUSTION engine.

MPC needs three things: a model it can roll forward, a cost it can evaluate on
the rollout, and a way to enforce constraints.  The engine's components are
pure functions of state, so speculative rollouts are safe -- nothing is
mutated and no events are published during a rollout.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Callable, Mapping, Sequence

from ..core.engine import ElectroCombustionEngine
from ..core.state import SystemState
from .optimiser import Constraint, DesignVariable, Objective, Optimiser


@dataclass(slots=True)
class MPCConfig:
    """Horizon and discretisation for the predictive controller."""

    horizon: int = 10
    control_horizon: int = 3
    dt: float = 0.1
    move_penalty: float = 0.0
    terminal_weight: float = 1.0

    def __post_init__(self) -> None:
        if self.horizon < 1:
            raise ValueError("prediction horizon must be at least one step")
        if not 1 <= self.control_horizon <= self.horizon:
            raise ValueError("control horizon must lie in 1..horizon")
        if self.dt <= 0.0:
            raise ValueError("dt must be positive")


class ModelPredictiveController:
    """Receding-horizon controller driving a set of engine inputs.

    Parameters
    ----------
    engine:
        The plant.  It is never advanced by the controller; only speculative
        copies are rolled forward.
    variables:
        The manipulated inputs, with their bounds.
    stage_cost:
        ``fn(state, inputs) -> float`` evaluated at every predicted step.
    constraints:
        Applied to a summary of the rollout, e.g. peak temperature.
    """

    def __init__(self, engine: ElectroCombustionEngine,
                 variables: Sequence[DesignVariable],
                 stage_cost: Callable[[SystemState, Mapping[str, float]], float],
                 config: MPCConfig | None = None,
                 constraints: Sequence[Constraint] = (),
                 method: str = "auto") -> None:
        if not variables:
            raise ValueError("MPC needs at least one manipulated variable")
        self.engine = engine
        self.variables = list(variables)
        self.stage_cost = stage_cost
        self.config = config or MPCConfig()
        self.constraints = list(constraints)
        self.method = method
        self.last_plan: dict[str, float] = {v.name: float(v.initial) for v in variables}
        self.rollout_count = 0

    def rollout(self, inputs: Mapping[str, float],
                state: SystemState | None = None) -> dict[str, float]:
        """Predict the response to a constant input over the horizon.

        Returns a summary containing the accumulated stage cost and the
        extreme values the constraints care about.
        """
        cfg = self.config
        current = (state or self.engine.state).copy()
        total_cost = 0.0
        peak_temperature = current.thermal.temperature
        peak_speed = abs(current.mechanical.speed)
        final_cost = 0.0
        for step in range(cfg.horizon):
            current = self.engine._trial(current, cfg.dt, dict(inputs))
            cost = float(self.stage_cost(current, inputs))
            weight = cfg.terminal_weight if step == cfg.horizon - 1 else 1.0
            total_cost += cost * weight
            final_cost = cost
            peak_temperature = max(peak_temperature, current.thermal.temperature)
            peak_speed = max(peak_speed, abs(current.mechanical.speed))
        self.rollout_count += 1
        summary = {
            "cost": total_cost, "final_cost": final_cost,
            "peak_temperature": peak_temperature, "peak_speed": peak_speed,
            "final_temperature": current.thermal.temperature,
            "final_speed": current.mechanical.speed,
            "final_time": current.time,
        }
        summary.update({k: float(v) for k, v in inputs.items()})
        return summary

    def solve(self, state: SystemState | None = None) -> dict[str, float]:
        """Compute the optimal input for the current step.

        Only the first move of the plan is returned, which is what makes this
        receding-horizon rather than open-loop optimal control.
        """
        move_penalty = self.config.move_penalty
        previous = dict(self.last_plan)

        def evaluate(values: dict[str, float]) -> dict[str, float]:
            summary = self.rollout(values, state)
            if move_penalty > 0.0:
                movement = sum((values[k] - previous.get(k, values[k])) ** 2
                               for k in values)
                summary["cost"] += move_penalty * movement
            return summary

        objective = Objective("cost", lambda r: r.get("cost", 0.0), "minimise")
        for variable in self.variables:
            variable.initial = previous.get(variable.name, variable.initial)
        optimiser = Optimiser(evaluate, self.variables, objective,
                              self.constraints, method=self.method)  # type: ignore[arg-type]
        result = optimiser.solve()
        self.last_plan = dict(result.variables)
        return dict(result.variables)

    def update(self, state: SystemState, dt: float) -> dict[str, float]:
        """Controller interface expected by ``ElectroCombustionEngine.run``."""
        return self.solve(state)

    def reset(self) -> None:
        self.last_plan = {v.name: float(v.initial) for v in self.variables}
        self.rollout_count = 0


def tracking_cost(target: float,
                  measurement: Callable[[SystemState], float],
                  weight: float = 1.0,
                  effort_keys: Sequence[str] = (),
                  effort_weight: float = 0.0
                  ) -> Callable[[SystemState, Mapping[str, float]], float]:
    """Build a quadratic tracking cost with an optional effort penalty."""
    def cost(state: SystemState, inputs: Mapping[str, float]) -> float:
        error = measurement(state) - target
        total = weight * error * error
        if effort_weight > 0.0:
            total += effort_weight * sum(float(inputs.get(k, 0.0)) ** 2
                                         for k in effort_keys)
        return total

    return cost


def economic_cost(value: Callable[[SystemState], float],
                  price: float = 1.0,
                  effort: Callable[[Mapping[str, float]], float] | None = None,
                  effort_price: float = 0.0
                  ) -> Callable[[SystemState, Mapping[str, float]], float]:
    """Build an economic (profit-maximising) MPC cost.

    Economic MPC optimises the actual objective rather than a tracking error,
    which is usually what an energy system wants: nobody cares that the
    temperature is exactly 800 K, they care what it costs to run.
    """
    def cost(state: SystemState, inputs: Mapping[str, float]) -> float:
        revenue = price * float(value(state))
        spend = effort_price * float(effort(inputs)) if effort else 0.0
        return spend - revenue

    return cost
