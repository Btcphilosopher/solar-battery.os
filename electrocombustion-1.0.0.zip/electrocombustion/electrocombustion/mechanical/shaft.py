"""Shaft dynamics, gearing and couplings."""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Callable, Sequence

from .torque import TorqueModel


@dataclass(slots=True)
class Shaft:
    """A rotating shaft with inertia and damping.

    The equation of motion is ``J dω/dt = T_net - c ω - T_friction``.  Kinetic
    energy is ``0.5 J ω²``, and mechanical power flow is ``T ω``, which is what
    keeps the mechanical domain consistent with the engine's energy ledger.
    """

    name: str = "shaft"
    inertia: float = 1.0
    damping: float = 0.0
    friction_torque: float = 0.0
    speed: float = 0.0
    angle: float = 0.0
    max_speed: float = math.inf

    def __post_init__(self) -> None:
        if self.inertia <= 0.0:
            raise ValueError("shaft inertia must be positive")
        if self.damping < 0.0:
            raise ValueError("damping must be non-negative")

    @property
    def kinetic_energy(self) -> float:
        return 0.5 * self.inertia * self.speed ** 2

    @property
    def rpm(self) -> float:
        return self.speed * 60.0 / (2.0 * math.pi)

    def parasitic_torque(self, speed: float | None = None) -> float:
        """Damping plus friction, always opposing motion (N.m)."""
        w = self.speed if speed is None else speed
        friction = 0.0
        if self.friction_torque > 0.0:
            if abs(w) < 1e-3:
                friction = self.friction_torque * w / 1e-3
            else:
                friction = math.copysign(self.friction_torque, w)
        return -self.damping * w - friction

    def acceleration(self, applied_torque: float,
                     speed: float | None = None) -> float:
        """Angular acceleration (rad/s^2) for an applied torque."""
        net = applied_torque + self.parasitic_torque(speed)
        return net / self.inertia

    def step(self, applied_torque: float, dt: float) -> float:
        """Advance one explicit Euler step; returns the new speed."""
        self.speed += self.acceleration(applied_torque) * dt
        if abs(self.speed) > self.max_speed:
            self.speed = math.copysign(self.max_speed, self.speed)
        self.angle = (self.angle + self.speed * dt) % (2.0 * math.pi)
        return self.speed

    def steady_speed(self, applied_torque: float, tolerance: float = 1e-9,
                     bracket: tuple[float, float] = (0.0, 1e5)) -> float:
        """Speed at which the applied torque balances the parasitic torque."""
        lo, hi = bracket
        f_lo = applied_torque + self.parasitic_torque(lo)
        f_hi = applied_torque + self.parasitic_torque(hi)
        if f_lo * f_hi > 0.0:
            raise ValueError(
                f"{self.name}: no equilibrium speed on [{lo:g}, {hi:g}] rad/s "
                f"for an applied torque of {applied_torque:g} N.m"
            )
        for _ in range(200):
            mid = 0.5 * (lo + hi)
            f_mid = applied_torque + self.parasitic_torque(mid)
            if abs(f_mid) < tolerance or (hi - lo) < tolerance:
                return mid
            if f_lo * f_mid <= 0.0:
                hi, f_hi = mid, f_mid
            else:
                lo, f_lo = mid, f_mid
        return 0.5 * (lo + hi)  # pragma: no cover

    def time_constant(self) -> float:
        """Mechanical time constant J/c (s); infinite without damping."""
        return self.inertia / self.damping if self.damping > 0.0 else math.inf


@dataclass(slots=True)
class Gearbox:
    """An ideal-ratio gearbox with a constant efficiency.

    ``ratio`` is output speed divided by input speed.  Losses appear as heat
    and are reported separately so they can be routed into the thermal domain
    rather than silently vanishing.
    """

    name: str = "gearbox"
    ratio: float = 1.0
    efficiency: float = 0.97
    inertia: float = 0.0

    def __post_init__(self) -> None:
        if self.ratio == 0.0:
            raise ValueError("gear ratio cannot be zero")
        if not 0.0 < self.efficiency <= 1.0:
            raise ValueError("efficiency must lie in (0, 1]")

    def output_speed(self, input_speed: float) -> float:
        return input_speed * self.ratio

    def input_speed(self, output_speed: float) -> float:
        return output_speed / self.ratio

    def output_torque(self, input_torque: float) -> float:
        """Torque delivered at the output shaft (N.m)."""
        return input_torque / self.ratio * self.efficiency

    def input_torque(self, output_torque: float) -> float:
        """Torque required at the input to deliver ``output_torque``."""
        return output_torque * self.ratio / self.efficiency

    def losses(self, input_torque: float, input_speed: float) -> float:
        """Power lost in the gearbox (W)."""
        return abs(input_torque * input_speed) * (1.0 - self.efficiency)

    def reflected_inertia(self, load_inertia: float) -> float:
        """Load inertia referred to the input shaft."""
        return self.inertia + load_inertia * self.ratio ** 2


@dataclass(slots=True)
class Coupling:
    """A compliant shaft coupling with stiffness and damping.

    Models the torsional dynamics between two shafts:
    ``T = k (θ1 - θ2) + c (ω1 - ω2)``.  Useful when a driveline resonance
    matters; for stiff couplings the two shafts can simply be merged.
    """

    stiffness: float = 1e5
    damping: float = 10.0
    twist: float = 0.0
    backlash: float = 0.0

    def torque(self, twist: float, relative_speed: float) -> float:
        effective = twist
        if self.backlash > 0.0:
            half = self.backlash / 2.0
            if abs(twist) <= half:
                effective = 0.0
            else:
                effective = twist - math.copysign(half, twist)
        return self.stiffness * effective + self.damping * relative_speed

    def step(self, speed_a: float, speed_b: float, dt: float) -> float:
        """Integrate the twist and return the transmitted torque."""
        relative = speed_a - speed_b
        self.twist += relative * dt
        return self.torque(self.twist, relative)

    def natural_frequency(self, inertia_a: float, inertia_b: float) -> float:
        """Torsional natural frequency of the two-inertia system (rad/s)."""
        if min(inertia_a, inertia_b) <= 0.0:
            raise ValueError("both inertias must be positive")
        equivalent = 1.0 / (1.0 / inertia_a + 1.0 / inertia_b)
        return math.sqrt(self.stiffness / equivalent)


@dataclass(slots=True)
class Clutch:
    """A friction clutch with slipping and locked states.

    While slipping, the transmitted torque is the friction capacity and the
    speed difference generates heat at ``T_slip * Δω``; this dissipation is
    reported so it can be added to the thermal domain.
    """

    capacity: float = 200.0
    engagement: float = 1.0
    lock_speed_tolerance: float = 0.5
    locked: bool = False

    def transmitted_torque(self, demand: float, slip_speed: float) -> float:
        capacity = self.capacity * min(1.0, max(0.0, self.engagement))
        if abs(slip_speed) < self.lock_speed_tolerance and abs(demand) <= capacity:
            self.locked = True
            return demand
        self.locked = False
        return math.copysign(min(abs(demand), capacity), demand) if demand else 0.0

    def slip_power(self, torque: float, slip_speed: float) -> float:
        """Heat generated by slipping (W)."""
        return abs(torque * slip_speed) if not self.locked else 0.0
