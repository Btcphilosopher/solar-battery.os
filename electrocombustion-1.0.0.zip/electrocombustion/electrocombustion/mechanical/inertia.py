"""Rotational inertia composition and reflection through gearing."""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Iterable, Sequence


def disc_inertia(mass: float, radius: float) -> float:
    """Solid disc about its axis, ``0.5 m r^2`` (kg.m^2)."""
    if mass < 0.0 or radius < 0.0:
        raise ValueError("mass and radius must be non-negative")
    return 0.5 * mass * radius ** 2


def annulus_inertia(mass: float, r_inner: float, r_outer: float) -> float:
    """Hollow cylinder, ``0.5 m (r_i^2 + r_o^2)``."""
    if not 0.0 <= r_inner <= r_outer:
        raise ValueError("radii must satisfy 0 <= r_inner <= r_outer")
    return 0.5 * mass * (r_inner ** 2 + r_outer ** 2)


def cylinder_inertia(density: float, radius: float, length: float) -> float:
    """Solid cylinder from its dimensions."""
    mass = density * math.pi * radius ** 2 * length
    return disc_inertia(mass, radius)


def reflected_inertia(inertia: float, gear_ratio: float) -> float:
    """Inertia on the far side of a gearset seen from the near side.

    ``gear_ratio`` is output speed divided by input speed.  A reduction
    (ratio < 1) makes the load inertia appear *smaller* at the input by the
    square of the ratio, which is why gearing is used to match inertias.
    """
    return inertia * gear_ratio ** 2


def reflected_torque(torque: float, gear_ratio: float,
                     efficiency: float = 1.0) -> float:
    """Torque seen at the input for a load torque at the output."""
    if not 0.0 < efficiency <= 1.0:
        raise ValueError("efficiency must lie in (0, 1]")
    return torque * gear_ratio / efficiency


def equivalent_inertia(translating_mass: float, radius: float) -> float:
    """Inertia equivalent of a mass moving linearly at ``radius``."""
    return translating_mass * radius ** 2


@dataclass(slots=True)
class InertiaStack:
    """A set of inertias on one shaft, optionally through gear ratios.

    Each entry is ``(inertia, ratio)`` where ``ratio`` is the speed of that
    element relative to the reference shaft.
    """

    elements: list[tuple[float, float]] = field(default_factory=list)

    def add(self, inertia: float, ratio: float = 1.0) -> "InertiaStack":
        if inertia < 0.0:
            raise ValueError("inertia must be non-negative")
        self.elements.append((float(inertia), float(ratio)))
        return self

    @property
    def total(self) -> float:
        """Equivalent inertia referred to the reference shaft (kg.m^2)."""
        return sum(j * r ** 2 for j, r in self.elements)

    def kinetic_energy(self, speed: float) -> float:
        """Total kinetic energy at reference-shaft speed ``speed`` (J)."""
        return 0.5 * self.total * speed ** 2

    def acceleration(self, net_torque: float) -> float:
        """Angular acceleration for a net torque (rad/s^2)."""
        if self.total <= 0.0:
            raise ValueError("total inertia must be positive to accelerate")
        return net_torque / self.total

    def spin_up_time(self, torque: float, target_speed: float) -> float:
        """Time to reach ``target_speed`` under constant net torque (s)."""
        if torque <= 0.0:
            return math.inf
        return self.total * target_speed / torque

    def __len__(self) -> int:
        return len(self.elements)
