"""Engine-facing mechanical components."""
from __future__ import annotations

import math
from dataclasses import dataclass

from ..core.component import Component, ComponentOutput, Context, Derivatives
from ..core.events import Event, Severity
from ..core.state import EnergyDomain, PowerFlow, SystemState
from .efficiency import FrictionModel
from .shaft import Gearbox, Shaft
from .torque import TorqueModel


class ShaftDynamics(Component):
    """Applies friction and damping to the engine's shaft state.

    The shaft *inertia* is carried on the system state, so this component only
    contributes the parasitic torque and the corresponding heat.  Mechanical
    power lost to friction becomes thermal energy rather than disappearing.
    """

    order = 80

    def __init__(self, name: str, friction: FrictionModel | None = None,
                 damping: float = 0.0, inertia: float | None = None,
                 loss_to_thermal: bool = True) -> None:
        super().__init__(name)
        self.friction = friction or FrictionModel(0.0, damping, 0.0)
        self.inertia = inertia
        self.loss_to_thermal = loss_to_thermal

    def initialise(self, state: SystemState, context: Context) -> None:
        if self.inertia is not None:
            state.mechanical.inertia = self.inertia

    def evaluate(self, state: SystemState, dt: float,
                 context: Context) -> ComponentOutput:
        speed = state.mechanical.speed
        torque = self.friction.resisting_torque(speed)
        dissipated = abs(torque * speed)
        target = EnergyDomain.THERMAL if self.loss_to_thermal else EnergyDomain.ENVIRONMENT
        flows = []
        if dissipated > 0.0:
            flows.append(PowerFlow(EnergyDomain.MECHANICAL, target, dissipated,
                                   "mechanical friction", self.name))
        return ComponentOutput(
            flows=flows,
            derivatives=Derivatives(
                torque=torque,
                heat_input=dissipated if self.loss_to_thermal else 0.0),
            diagnostics={f"{self.name}.friction_torque": torque,
                         f"{self.name}.friction_power": dissipated},
        )


class MechanicalLoad(Component):
    """An external load absorbing shaft power.

    Power leaves the MECHANICAL domain labelled ``"load"`` when
    ``useful=True``, so shaft output is counted as delivered work rather than
    as loss.
    """

    order = 85

    def __init__(self, name: str, model: TorqueModel, useful: bool = True) -> None:
        super().__init__(name)
        self.model = model
        self.useful = useful

    def evaluate(self, state: SystemState, dt: float,
                 context: Context) -> ComponentOutput:
        speed = state.mechanical.speed
        torque = self.model.torque(speed, state.time)
        power = abs(torque * speed)
        label = "load" if self.useful else "mechanical loss"
        flows = []
        if power > 0.0:
            flows.append(PowerFlow(EnergyDomain.MECHANICAL,
                                   EnergyDomain.ENVIRONMENT, power, label,
                                   self.name))
        return ComponentOutput(
            flows=flows,
            derivatives=Derivatives(torque=torque),
            diagnostics={f"{self.name}.load_torque": torque,
                         f"{self.name}.load_power": power},
        )


class TorqueSource(Component):
    """A commanded torque applied to the shaft, drawn from an abstract source.

    Useful for driving a system from a prescribed torque without modelling the
    prime mover, while still keeping the ledger closed.
    """

    order = 40

    def __init__(self, name: str, torque: float = 0.0,
                 input_key: str | None = None,
                 max_power: float = math.inf) -> None:
        super().__init__(name)
        self.torque = float(torque)
        self.input_key = input_key or f"{name}.torque"
        self.max_power = max_power

    def evaluate(self, state: SystemState, dt: float,
                 context: Context) -> ComponentOutput:
        torque = context.get(self.input_key, self.torque)
        speed = state.mechanical.speed
        power = torque * speed
        if abs(power) > self.max_power and abs(speed) > 1e-9:
            power = math.copysign(self.max_power, power)
            torque = power / speed
        flows = []
        if power > 0.0:
            flows.append(PowerFlow(EnergyDomain.SOURCE, EnergyDomain.MECHANICAL,
                                   power, "shaft input", self.name))
        elif power < 0.0:
            flows.append(PowerFlow(EnergyDomain.MECHANICAL, EnergyDomain.ENVIRONMENT,
                                   -power, "shaft braking", self.name))
        return ComponentOutput(
            flows=flows,
            derivatives=Derivatives(torque=torque),
            diagnostics={f"{self.name}.torque": torque,
                         f"{self.name}.power": power},
        )


class GearboxComponent(Component):
    """A gearbox inserted between the shaft and a load.

    Because the engine carries a single shaft speed, the gearbox is
    represented by its *loss*: the reflected load torque appears at the input
    and the difference becomes heat.
    """

    order = 82

    def __init__(self, name: str, gearbox: Gearbox,
                 load: TorqueModel | None = None) -> None:
        super().__init__(name)
        self.gearbox = gearbox
        self.load = load

    def evaluate(self, state: SystemState, dt: float,
                 context: Context) -> ComponentOutput:
        speed = state.mechanical.speed
        if self.load is None:
            return ComponentOutput()
        output_speed = self.gearbox.output_speed(speed)
        load_torque = self.load.torque(output_speed, state.time)
        input_torque = self.gearbox.input_torque(load_torque)
        delivered = abs(load_torque * output_speed)
        absorbed = abs(input_torque * speed)
        loss = max(0.0, absorbed - delivered)
        flows = []
        if delivered > 0.0:
            flows.append(PowerFlow(EnergyDomain.MECHANICAL,
                                   EnergyDomain.ENVIRONMENT, delivered,
                                   "load", self.name))
        if loss > 0.0:
            flows.append(PowerFlow(EnergyDomain.MECHANICAL, EnergyDomain.THERMAL,
                                   loss, "gearbox loss", self.name))
        return ComponentOutput(
            flows=flows,
            derivatives=Derivatives(torque=input_torque, heat_input=loss),
            diagnostics={f"{self.name}.input_torque": input_torque,
                         f"{self.name}.output_speed": output_speed,
                         f"{self.name}.loss": loss},
        )
