"""Mechanical efficiency and friction models."""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Iterable, Sequence


def chain_efficiency(*efficiencies: float) -> float:
    """Overall efficiency of components in series."""
    total = 1.0
    for eta in efficiencies:
        if not 0.0 < eta <= 1.0:
            raise ValueError("each efficiency must lie in (0, 1]")
        total *= eta
    return total


def mechanical_efficiency(brake_power: float, indicated_power: float) -> float:
    """Brake power over indicated power (0..1)."""
    if indicated_power <= 0.0:
        return 0.0
    return max(0.0, brake_power / indicated_power)


@dataclass(slots=True)
class FrictionModel:
    """Speed-dependent friction losses of a rotating assembly.

    ``T_friction = a + b*omega + c*omega^2``

    The constant term represents seal drag and boundary friction, the linear
    term viscous shear, and the quadratic term windage.  Given as a torque so
    it composes directly with the shaft equation of motion.
    """

    constant: float = 0.5
    linear: float = 0.01
    quadratic: float = 1e-5

    def torque(self, speed: float) -> float:
        """Friction torque magnitude at ``speed`` (N.m), always positive."""
        w = abs(speed)
        return self.constant + self.linear * w + self.quadratic * w * w

    def power(self, speed: float) -> float:
        """Power dissipated by friction (W)."""
        return self.torque(speed) * abs(speed)

    def resisting_torque(self, speed: float) -> float:
        """Signed torque opposing motion (N.m)."""
        if abs(speed) < 1e-6:
            return 0.0
        return -math.copysign(self.torque(speed), speed)


@dataclass(slots=True)
class EfficiencyMap:
    """A bilinear speed-torque efficiency map.

    ``values[i][j]`` is the efficiency at ``speeds[i]``, ``torques[j]``.
    Queries outside the mapped region are clamped to the nearest edge rather
    than extrapolated, since extrapolating an efficiency map is how you end up
    with efficiencies above one.
    """

    speeds: Sequence[float]
    torques: Sequence[float]
    values: Sequence[Sequence[float]]

    def __post_init__(self) -> None:
        if len(self.values) != len(self.speeds):
            raise ValueError("values must have one row per speed")
        for row in self.values:
            if len(row) != len(self.torques):
                raise ValueError("each values row must have one entry per torque")
            for v in row:
                if not 0.0 < v <= 1.0:
                    raise ValueError("efficiencies must lie in (0, 1]")
        if list(self.speeds) != sorted(self.speeds):
            raise ValueError("speeds must be increasing")
        if list(self.torques) != sorted(self.torques):
            raise ValueError("torques must be increasing")

    def _bracket(self, values: Sequence[float], x: float) -> tuple[int, int, float]:
        if x <= values[0]:
            return 0, 0, 0.0
        if x >= values[-1]:
            last = len(values) - 1
            return last, last, 0.0
        for i in range(len(values) - 1):
            if values[i] <= x <= values[i + 1]:
                span = values[i + 1] - values[i]
                return i, i + 1, (x - values[i]) / span if span > 0 else 0.0
        return len(values) - 1, len(values) - 1, 0.0  # pragma: no cover

    def __call__(self, speed: float, torque: float) -> float:
        i0, i1, fs = self._bracket(self.speeds, speed)
        j0, j1, ft = self._bracket(self.torques, abs(torque))
        v00 = self.values[i0][j0]
        v01 = self.values[i0][j1]
        v10 = self.values[i1][j0]
        v11 = self.values[i1][j1]
        lower = v00 + (v01 - v00) * ft
        upper = v10 + (v11 - v10) * ft
        return lower + (upper - lower) * fs

    def best_point(self) -> tuple[float, float, float]:
        """Return ``(speed, torque, efficiency)`` at the map's best point."""
        best = (self.speeds[0], self.torques[0], 0.0)
        for i, speed in enumerate(self.speeds):
            for j, torque in enumerate(self.torques):
                if self.values[i][j] > best[2]:
                    best = (speed, torque, self.values[i][j])
        return best


def carnot_efficiency(t_hot: float, t_cold: float) -> float:
    """Carnot limit ``1 - Tc/Th`` (0..1).

    Raises if the temperatures are non-physical.  The result is an upper bound
    no real device reaches; the recovery models scale it by a fraction that
    represents the actual cycle.
    """
    if t_hot <= 0.0 or t_cold <= 0.0:
        raise ValueError("absolute temperatures must be positive")
    if t_cold >= t_hot:
        return 0.0
    return 1.0 - t_cold / t_hot


def otto_efficiency(compression_ratio: float, gamma: float = 1.4) -> float:
    """Air-standard Otto cycle thermal efficiency."""
    if compression_ratio <= 1.0:
        raise ValueError("compression ratio must exceed 1")
    return 1.0 - compression_ratio ** (1.0 - gamma)


def diesel_efficiency(compression_ratio: float, cutoff_ratio: float,
                      gamma: float = 1.4) -> float:
    """Air-standard Diesel cycle thermal efficiency."""
    if compression_ratio <= 1.0:
        raise ValueError("compression ratio must exceed 1")
    if cutoff_ratio <= 1.0:
        return otto_efficiency(compression_ratio, gamma)
    numerator = cutoff_ratio ** gamma - 1.0
    denominator = gamma * (cutoff_ratio - 1.0)
    return 1.0 - compression_ratio ** (1.0 - gamma) * numerator / denominator


def brayton_efficiency(pressure_ratio: float, gamma: float = 1.4) -> float:
    """Air-standard Brayton cycle thermal efficiency."""
    if pressure_ratio <= 1.0:
        raise ValueError("pressure ratio must exceed 1")
    return 1.0 - pressure_ratio ** ((1.0 - gamma) / gamma)
