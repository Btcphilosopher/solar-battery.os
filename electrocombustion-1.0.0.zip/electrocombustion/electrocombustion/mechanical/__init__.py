"""Mechanical models: torque, shafts, inertia and efficiency."""
from .torque import (
    CallableTorque, ConstantPowerLoad, ConstantTorque, CoulombFriction,
    QuadraticLoad, TorqueCurve, TorqueModel, ViscousLoad, combine,
    power_from_torque, rad_s_to_rpm, rpm_to_rad_s, torque_from_power,
)
from .inertia import (
    InertiaStack, annulus_inertia, cylinder_inertia, disc_inertia,
    equivalent_inertia, reflected_inertia, reflected_torque,
)
from .shaft import Clutch, Coupling, Gearbox, Shaft
from .efficiency import (
    EfficiencyMap, FrictionModel, brayton_efficiency, carnot_efficiency,
    chain_efficiency, diesel_efficiency, mechanical_efficiency,
    otto_efficiency,
)
from .components import (
    GearboxComponent, MechanicalLoad, ShaftDynamics, TorqueSource,
)

__all__ = [
    "CallableTorque", "ConstantPowerLoad", "ConstantTorque", "CoulombFriction",
    "QuadraticLoad", "TorqueCurve", "TorqueModel", "ViscousLoad", "combine",
    "power_from_torque", "rad_s_to_rpm", "rpm_to_rad_s", "torque_from_power",
    "InertiaStack", "annulus_inertia", "cylinder_inertia", "disc_inertia",
    "equivalent_inertia", "reflected_inertia", "reflected_torque", "Clutch",
    "Coupling", "Gearbox", "Shaft", "EfficiencyMap", "FrictionModel",
    "brayton_efficiency", "carnot_efficiency", "chain_efficiency",
    "diesel_efficiency", "mechanical_efficiency", "otto_efficiency",
    "GearboxComponent", "MechanicalLoad", "ShaftDynamics", "TorqueSource",
]
