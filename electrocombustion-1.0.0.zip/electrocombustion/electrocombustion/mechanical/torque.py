"""Torque sources and load models."""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Callable


def power_from_torque(torque: float, speed: float) -> float:
    """``P = T omega`` in W."""
    return torque * speed


def torque_from_power(power: float, speed: float, minimum_speed: float = 1e-6
                      ) -> float:
    """``T = P / omega``; guarded against the singularity at zero speed."""
    if abs(speed) < minimum_speed:
        return 0.0
    return power / speed


def rpm_to_rad_s(rpm: float) -> float:
    return rpm * 2.0 * math.pi / 60.0


def rad_s_to_rpm(speed: float) -> float:
    return speed * 60.0 / (2.0 * math.pi)


class TorqueModel:
    """Base class for anything producing or absorbing torque."""

    def torque(self, speed: float, t: float = 0.0) -> float:  # pragma: no cover
        raise NotImplementedError

    def power(self, speed: float, t: float = 0.0) -> float:
        return self.torque(speed, t) * speed


@dataclass(slots=True)
class ConstantTorque(TorqueModel):
    """A speed-independent torque."""

    value: float = 0.0

    def torque(self, speed: float, t: float = 0.0) -> float:
        return self.value


@dataclass(slots=True)
class ViscousLoad(TorqueModel):
    """Linear damping torque ``-c omega`` (bearings, viscous shear)."""

    damping: float = 0.01

    def torque(self, speed: float, t: float = 0.0) -> float:
        return -self.damping * speed


@dataclass(slots=True)
class QuadraticLoad(TorqueModel):
    """Fan or propeller load, ``-k omega |omega|``.

    The absolute value keeps the torque opposing motion in both directions
    rather than becoming a driving torque in reverse.
    """

    coefficient: float = 1e-3

    def torque(self, speed: float, t: float = 0.0) -> float:
        return -self.coefficient * speed * abs(speed)


@dataclass(slots=True)
class ConstantPowerLoad(TorqueModel):
    """A load absorbing constant power above a cut-in speed.

    The rating is named ``rating`` rather than ``power`` so that it does not
    shadow :meth:`TorqueModel.power`, which every torque model must keep
    callable.
    """

    rating: float = 1000.0
    minimum_speed: float = 1.0

    def torque(self, speed: float, t: float = 0.0) -> float:
        if abs(speed) < self.minimum_speed:
            return 0.0
        return -self.rating / speed


@dataclass(slots=True)
class CoulombFriction(TorqueModel):
    """Dry friction: constant magnitude, opposing motion.

    Below ``stiction_speed`` the torque is blended linearly to zero, which
    avoids the discontinuity that would otherwise make the ODE non-smooth at
    standstill.
    """

    magnitude: float = 1.0
    stiction_speed: float = 0.1

    def torque(self, speed: float, t: float = 0.0) -> float:
        if abs(speed) < self.stiction_speed:
            return -self.magnitude * speed / self.stiction_speed
        return -math.copysign(self.magnitude, speed)


@dataclass(slots=True)
class TorqueCurve(TorqueModel):
    """A tabulated torque-speed characteristic with linear interpolation."""

    speeds: tuple[float, ...]
    torques: tuple[float, ...]

    def __post_init__(self) -> None:
        if len(self.speeds) != len(self.torques):
            raise ValueError("speed and torque tables must have equal length")
        if len(self.speeds) < 2:
            raise ValueError("a torque curve needs at least two points")
        if list(self.speeds) != sorted(self.speeds):
            raise ValueError("speeds must be increasing")

    def torque(self, speed: float, t: float = 0.0) -> float:
        s, tq = self.speeds, self.torques
        if speed <= s[0]:
            return tq[0]
        if speed >= s[-1]:
            return tq[-1]
        for i in range(len(s) - 1):
            if s[i] <= speed <= s[i + 1]:
                span = s[i + 1] - s[i]
                if span <= 0.0:
                    return tq[i]
                frac = (speed - s[i]) / span
                return tq[i] + frac * (tq[i + 1] - tq[i])
        return tq[-1]  # pragma: no cover

    def peak(self) -> tuple[float, float]:
        """Return ``(speed, torque)`` at the maximum tabulated torque."""
        i = max(range(len(self.torques)), key=lambda j: self.torques[j])
        return self.speeds[i], self.torques[i]

    def peak_power(self, samples: int = 500) -> tuple[float, float]:
        """Return ``(speed, power)`` at maximum power over the curve."""
        best = (0.0, -math.inf)
        lo, hi = self.speeds[0], self.speeds[-1]
        for i in range(samples + 1):
            speed = lo + (hi - lo) * i / samples
            p = self.torque(speed) * speed
            if p > best[1]:
                best = (speed, p)
        return best


@dataclass(slots=True)
class CallableTorque(TorqueModel):
    """Wraps an arbitrary ``fn(speed, t) -> torque``."""

    fn: Callable[[float, float], float]

    def torque(self, speed: float, t: float = 0.0) -> float:
        return float(self.fn(speed, t))


def combine(*models: TorqueModel) -> Callable[[float, float], float]:
    """Return a callable summing several torque models."""
    def total(speed: float, t: float = 0.0) -> float:
        return sum(m.torque(speed, t) for m in models)
    return total
