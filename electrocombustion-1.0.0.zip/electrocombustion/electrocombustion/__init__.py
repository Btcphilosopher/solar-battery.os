"""ELECTROCOMBUSTION -- a general computational engine for coupled
electrical, thermal, chemical and mechanical energy systems.

The package is organised as a set of physical model libraries (``electrical``,
``thermal``, ``combustion``, ``mechanical``, ``materials``) that produce
:class:`~electrocombustion.core.component.Component` objects, a set of
pre-assembled ``systems``, and the numerical machinery (``simulation``,
``optimisation``) that drives them.

Everything is SI internally.  Every joule is accounted for through the
:class:`~electrocombustion.core.state.EnergyLedger`.
"""
from .core import (
    AdaptiveTimestep, CallableComponent, ChemicalState, Component,
    ComponentGroup, ComponentOutput, ConservationError, Context, Derivatives,
    ElectricalState, ElectroCombustionEngine, EnergyDomain, EnergyLedger,
    EngineConfig, Event, EventBus, Fidelity, FixedTimestep, MechanicalState,
    PowerFlow, Quantity, RunResult, Severity, SystemState, ThermalState,
    Threshold, TimeGrid, compatible, convert, dimension_of, to_si, from_si,
)

from . import (
    api, combustion, electrical, faults, materials, mechanical, optimisation,
    simulation, systems, telemetry, thermal, visualisation,
)
from .twin import EnergyTwin, TwinSnapshot
from .faults import Diagnosis, FaultClassifier, LimitRegistry, standard_limits
from .telemetry import Sensor, SensorArray, SensorSpec, TelemetryLogger
from .optimisation import (
    Constraint, DesignVariable, Objective, OptimisationResult, Optimiser,
    PIDController, SupervisoryController,
)
from .simulation import (
    Distribution, MonteCarlo, Parameter, ParameterSweep, Scenario,
    TransientSolver,
)
from .visualisation import energy_waterfall, ledger_report


__version__ = "1.0.0"

__all__ = [
    "__version__",
    "AdaptiveTimestep", "CallableComponent", "ChemicalState", "Component",
    "ComponentGroup", "ComponentOutput", "ConservationError", "Context",
    "Derivatives", "ElectricalState", "ElectroCombustionEngine", "EnergyDomain",
    "EnergyLedger", "EngineConfig", "Event", "EventBus", "Fidelity",
    "FixedTimestep", "MechanicalState", "PowerFlow", "Quantity", "RunResult",
    "Severity", "SystemState", "ThermalState", "Threshold", "TimeGrid",
    "compatible", "convert", "dimension_of", "to_si", "from_si",
    "api", "combustion", "electrical", "faults", "materials", "mechanical",
    "optimisation", "simulation", "systems", "telemetry", "thermal",
    "visualisation", "EnergyTwin", "TwinSnapshot", "Diagnosis",
    "FaultClassifier", "LimitRegistry", "standard_limits", "Sensor",
    "SensorArray", "SensorSpec", "TelemetryLogger", "Constraint",
    "DesignVariable", "Objective", "OptimisationResult", "Optimiser",
    "PIDController", "SupervisoryController", "Distribution", "MonteCarlo",
    "Parameter", "ParameterSweep", "Scenario", "TransientSolver",
    "energy_waterfall", "ledger_report",
]
