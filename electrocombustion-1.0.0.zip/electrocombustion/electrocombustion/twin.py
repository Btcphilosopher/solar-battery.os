"""The digital energy twin.

A twin pairs a live (or replayed) data stream with a model of the same system
and continuously compares them.  The model tells you what *should* be
happening; the residual tells you what is actually different.  Both are needed:
a model alone cannot detect a fault, and data alone cannot explain one.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable, Mapping, Sequence

from .core.engine import ElectroCombustionEngine
from .core.events import Severity
from .core.state import EnergyDomain, SystemState
from .faults.classifier import Diagnosis, FaultClassifier
from .telemetry.logging import CSVReplay, TelemetryLogger
from .telemetry.validation import TelemetryValidator, energy_balance_check


@dataclass(slots=True)
class TwinSnapshot:
    """One synchronised model/measurement comparison."""

    time: float
    modelled: dict[str, float]
    measured: dict[str, float]
    residuals: dict[str, float]
    severity: Severity = Severity.NORMAL

    def worst_channel(self) -> tuple[str, float] | None:
        if not self.residuals:
            return None
        name = max(self.residuals, key=lambda k: abs(self.residuals[k]))
        return name, self.residuals[name]

    def as_dict(self) -> dict[str, Any]:
        return {"time": self.time, "severity": self.severity.value,
                "modelled": dict(self.modelled),
                "measured": dict(self.measured),
                "residuals": dict(self.residuals)}


class EnergyTwin:
    """A digital twin of an ELECTROCOMBUSTION system.

    Parameters
    ----------
    engine:
        The model.  Advanced in lockstep with the incoming data.
    channels:
        Maps a measurement name to a function extracting the modelled
        equivalent from the state, so the residual is always comparing like
        with like.
    """

    def __init__(self, engine: ElectroCombustionEngine,
                 channels: Mapping[str, Callable[[SystemState], float]] | None = None,
                 classifier: FaultClassifier | None = None,
                 validator: TelemetryValidator | None = None,
                 logger: TelemetryLogger | None = None,
                 history_limit: int = 100_000) -> None:
        self.engine = engine
        self.channels = dict(channels or {})
        self.classifier = classifier
        self.validator = validator
        self.logger = logger or TelemetryLogger(history_limit)
        self.snapshots: list[TwinSnapshot] = []
        self.history_limit = history_limit
        self.diagnoses: list[Diagnosis] = []

    # -- channels -----------------------------------------------------------
    def add_channel(self, name: str,
                    accessor: Callable[[SystemState], float]) -> "EnergyTwin":
        self.channels[name] = accessor
        return self

    def modelled(self) -> dict[str, float]:
        state = self.engine.state
        return {name: float(accessor(state))
                for name, accessor in self.channels.items()}

    # -- stepping -----------------------------------------------------------
    def step(self, dt: float, measurement: Mapping[str, float] | None = None,
             inputs: Mapping[str, float] | None = None) -> TwinSnapshot:
        """Advance the model by ``dt`` and compare against a measurement."""
        self.engine.step(dt, inputs)
        modelled = self.modelled()
        measured = {k: float(v) for k, v in (measurement or {}).items()
                    if k in self.channels}
        residuals = {k: modelled[k] - measured[k] for k in measured}
        severity = Severity.NORMAL
        if self.classifier is not None:
            diagnosis = self.classifier.classify(self.engine.state)
            self.diagnoses.append(diagnosis)
            severity = diagnosis.severity
        if self.validator is not None and measurement is not None:
            record = dict(measurement)
            record.setdefault("time", self.engine.state.time)
            report = self.validator.validate(record)
            if not report.valid and severity is Severity.NORMAL:
                severity = Severity.WARNING
        snapshot = TwinSnapshot(self.engine.state.time, modelled, measured,
                                residuals, severity)
        self.snapshots.append(snapshot)
        if len(self.snapshots) > self.history_limit:
            del self.snapshots[: len(self.snapshots) - self.history_limit]
        record = {"time": snapshot.time}
        record.update({f"model.{k}": v for k, v in modelled.items()})
        record.update({f"measured.{k}": v for k, v in measured.items()})
        record.update({f"residual.{k}": v for k, v in residuals.items()})
        self.logger.log(record)
        return snapshot

    def replay(self, source: CSVReplay, dt: float,
               inputs: Callable[[Mapping[str, float]], Mapping[str, float]] | None = None
               ) -> list[TwinSnapshot]:
        """Drive the twin from a recorded telemetry file.

        The model is stepped once per record, using the record's own timestamps
        to derive the step size where possible, so a log with irregular
        sampling replays at its true rate rather than a nominal one.
        """
        out: list[TwinSnapshot] = []
        previous_time: float | None = None
        for record in source:
            timestamp = float(record.get(source.time_key, 0.0))
            step = dt if previous_time is None else max(1e-12, timestamp - previous_time)
            previous_time = timestamp
            commanded = dict(inputs(record)) if inputs else None
            numeric = {k: float(v) for k, v in record.items()
                       if isinstance(v, (int, float))}
            out.append(self.step(step, numeric, commanded))
        return out

    # -- reporting ----------------------------------------------------------
    def residual_statistics(self, channel: str) -> dict[str, float]:
        values = [s.residuals[channel] for s in self.snapshots
                  if channel in s.residuals]
        if not values:
            raise KeyError(f"no residuals recorded for {channel!r}")
        n = len(values)
        mean = sum(values) / n
        variance = sum((v - mean) ** 2 for v in values) / (n - 1) if n > 1 else 0.0
        return {"count": float(n), "mean": mean, "std": math.sqrt(variance),
                "max_abs": max(abs(v) for v in values),
                "rms": math.sqrt(sum(v * v for v in values) / n)}

    def energy_summary(self) -> dict[str, float]:
        return self.engine.energy_summary()

    def balance_check(self, tolerance: float = 0.01) -> tuple[bool, float]:
        """First-law check on the accumulated ledger."""
        ledger = self.engine.ledger
        return energy_balance_check(ledger.total_input,
                                    ledger.total_losses,
                                    ledger.total_stored, tolerance)

    def worst_severity(self) -> Severity:
        return Severity.worst(s.severity for s in self.snapshots)

    def timeline(self) -> list[tuple[float, str]]:
        out: list[tuple[float, str]] = []
        previous: Severity | None = None
        for snapshot in self.snapshots:
            if snapshot.severity is not previous:
                out.append((snapshot.time, snapshot.severity.value))
                previous = snapshot.severity
        return out

    def summary(self) -> dict[str, Any]:
        energy = self.engine.energy_summary()
        ok, residual = self.balance_check()
        return {
            "time": self.engine.state.time,
            "snapshots": len(self.snapshots),
            "channels": sorted(self.channels),
            "severity": self.worst_severity().value,
            "energy_in": energy["input"],
            "energy_delivered": energy["delivered"],
            "energy_losses": energy["losses"],
            "efficiency": self.engine.efficiency(),
            "balanced": ok, "balance_residual": residual,
        }

    def report(self) -> str:
        """A short plain-text status report."""
        summary = self.summary()
        lines = [
            f"digital twin at t = {summary['time']:.4g} s",
            f"  state          : {summary['severity']}",
            f"  energy in      : {summary['energy_in'] / 1e6:.4f} MJ",
            f"  delivered      : {summary['energy_delivered'] / 1e6:.4f} MJ",
            f"  losses         : {summary['energy_losses'] / 1e6:.4f} MJ",
            f"  efficiency     : {summary['efficiency'] * 100:.2f} %",
            f"  first-law check: "
            f"{'balanced' if summary['balanced'] else 'IMBALANCED'} "
            f"({summary['balance_residual']:+.3e} relative)",
        ]
        for channel in sorted(self.channels):
            try:
                stats = self.residual_statistics(channel)
            except KeyError:
                continue
            lines.append(f"  residual {channel:<12}: rms {stats['rms']:.4g}, "
                         f"max {stats['max_abs']:.4g}")
        return "\n".join(lines)

    def reset(self) -> None:
        self.engine.reset()
        self.snapshots.clear()
        self.diagnoses.clear()
        self.logger.clear()
        if self.classifier is not None:
            self.classifier.reset()
        if self.validator is not None:
            self.validator.reset()
