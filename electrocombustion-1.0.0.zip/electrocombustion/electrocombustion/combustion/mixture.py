"""Fuel-air mixture description and thermodynamic properties."""
from __future__ import annotations

import math
from dataclasses import dataclass, field

from ..core import units as U
from .fuel import Fuel


@dataclass(slots=True)
class Mixture:
    """A fuel-oxidiser mixture at a given equivalence ratio.

    ``equivalence_ratio`` (phi) is the actual fuel-air ratio divided by the
    stoichiometric one: phi > 1 is rich, phi < 1 is lean.  ``lambda_`` is its
    reciprocal, which is the convention used in engine control.
    """

    fuel: Fuel
    equivalence_ratio: float = 1.0
    pressure: float = U.P_ATM
    temperature: float = 298.15
    oxidiser_oxygen_fraction: float = U.O2_MOLE_FRACTION_AIR
    diluent_fraction: float = 0.0

    def __post_init__(self) -> None:
        if self.equivalence_ratio <= 0.0:
            raise ValueError("equivalence ratio must be positive")
        if not 0.0 < self.oxidiser_oxygen_fraction <= 1.0:
            raise ValueError("oxidiser oxygen fraction must lie in (0, 1]")
        if not 0.0 <= self.diluent_fraction < 1.0:
            raise ValueError("diluent fraction must lie in [0, 1)")
        if self.temperature <= 0.0:
            raise ValueError("temperature must be positive")

    # -- ratios -------------------------------------------------------------
    @property
    def lambda_(self) -> float:
        return 1.0 / self.equivalence_ratio

    @property
    def excess_air(self) -> float:
        """Excess air as a fraction, e.g. 0.2 for 20 % excess."""
        return self.lambda_ - 1.0

    @property
    def stoichiometric_afr(self) -> float:
        """Stoichiometric air-fuel ratio, adjusted for oxygen enrichment."""
        base = self.fuel.stoichiometric_afr
        scale = U.O2_MOLE_FRACTION_AIR / self.oxidiser_oxygen_fraction
        return base * scale

    @property
    def afr(self) -> float:
        """Actual air-fuel ratio by mass."""
        return self.stoichiometric_afr / self.equivalence_ratio

    @property
    def fuel_fraction(self) -> float:
        """Fuel mass fraction of the total charge."""
        return 1.0 / (1.0 + self.afr)

    @property
    def is_rich(self) -> bool:
        return self.equivalence_ratio > 1.0

    @property
    def is_lean(self) -> bool:
        return self.equivalence_ratio < 1.0

    @property
    def is_flammable(self) -> bool:
        return self.fuel.is_flammable(self.equivalence_ratio)

    # -- properties ---------------------------------------------------------
    @property
    def molar_mass(self) -> float:
        """Mean molar mass of the unburned charge (kg/mol).

        Computed from mass fractions, which is exact:
        ``1/M = sum(y_i / M_i)``.
        """
        y_fuel = self.fuel_fraction
        y_air = 1.0 - y_fuel
        inverse = y_fuel / self.fuel.molar_mass + y_air / U.M_AIR
        return 1.0 / inverse

    @property
    def gas_constant(self) -> float:
        """Specific gas constant of the charge (J/(kg.K))."""
        return U.R_UNIVERSAL / self.molar_mass

    def specific_heat(self, temperature: float | None = None) -> float:
        """Charge specific heat at constant pressure (J/(kg.K)).

        A mass-weighted blend of air and fuel vapour, with air's temperature
        dependence taken from the standard polynomial fit.  For liquid fuels at
        low load the fuel contribution is small, so the accuracy is dominated
        by the air term.
        """
        t = self.temperature if temperature is None else temperature
        cp_air = 1004.0 - 0.0785 * t + 3.0e-4 * t * t
        cp_fuel = 1700.0 if self.fuel.phase == "gas" else 2100.0
        y_fuel = self.fuel_fraction
        return (1.0 - y_fuel) * cp_air + y_fuel * cp_fuel

    def gamma(self, temperature: float | None = None) -> float:
        """Ratio of specific heats."""
        cp = self.specific_heat(temperature)
        cv = cp - self.gas_constant
        return cp / cv if cv > 0.0 else U.GAMMA_AIR_STD

    def density(self, pressure: float | None = None,
                temperature: float | None = None) -> float:
        """Charge density from the ideal gas law (kg/m^3)."""
        p = self.pressure if pressure is None else pressure
        t = self.temperature if temperature is None else temperature
        return p / (self.gas_constant * t)

    # -- energetics ---------------------------------------------------------
    @property
    def combustion_efficiency(self) -> float:
        """Fraction of the fuel's LHV actually released.

        For lean and stoichiometric mixtures this is close to unity.  For rich
        mixtures it is limited by the oxygen available *and* by the energy
        left in the carbon monoxide that oxygen starvation produces -- see
        :meth:`~electrocombustion.combustion.fuel.Fuel.released_fraction`.  A
        small non-ideality (2 %) is applied even when oxygen is plentiful,
        representing wall quenching and crevice effects.
        """
        released = self.fuel.released_fraction(self.equivalence_ratio)
        return released * 0.98

    def heat_release_per_kg_fuel(self) -> float:
        """Energy actually released per kg of fuel supplied (J/kg)."""
        return self.fuel.lhv * self.combustion_efficiency

    def heat_release_per_kg_charge(self) -> float:
        """Energy released per kg of total charge (J/kg)."""
        return self.heat_release_per_kg_fuel() * self.fuel_fraction

    def adiabatic_flame_temperature(self, initial_temperature: float | None = None
                                    ) -> float:
        """Constant-pressure adiabatic flame temperature (K).

        A first-law estimate: released energy divided by the product heat
        capacity, added to the initial temperature.  The product heat capacity
        is evaluated iteratively at the mean temperature because cp rises
        substantially over the range involved.  This is a *simulation-grade*
        estimate, typically within 5-10 % of an equilibrium calculation; it
        does not model dissociation, which caps real flame temperatures well
        below the adiabatic value at high phi.
        """
        t0 = self.temperature if initial_temperature is None else initial_temperature
        q = self.heat_release_per_kg_charge()
        t = t0 + q / 1200.0
        for _ in range(40):
            mean = 0.5 * (t0 + t)
            cp = 1004.0 - 0.0785 * mean + 3.0e-4 * mean * mean
            cp = max(900.0, min(1600.0, cp))
            new_t = t0 + q / cp
            if abs(new_t - t) < 1e-6:
                t = new_t
                break
            t = 0.5 * (t + new_t)
        return t

    def laminar_flame_speed(self, temperature: float | None = None,
                            pressure: float | None = None) -> float:
        """Laminar flame speed (m/s) with phi, T and p corrections.

        Uses the standard power-law form
        ``S_L = S_L0 * f(phi) * (T/T0)^alpha * (p/p0)^beta`` with
        alpha = 1.75 and beta = -0.25, and a parabolic phi dependence peaking
        slightly rich.  Returns zero outside the flammability limits.
        """
        if not self.is_flammable:
            return 0.0
        t = self.temperature if temperature is None else temperature
        p = self.pressure if pressure is None else pressure
        base = self.fuel.laminar_flame_speed
        if base <= 0.0:
            return 0.0
        phi_peak = 1.08
        width = 0.45
        shape = max(0.0, 1.0 - ((self.equivalence_ratio - phi_peak) / width) ** 2)
        return base * shape * (t / 298.15) ** 1.75 * (p / U.P_ATM) ** -0.25

    def describe(self) -> dict[str, float | str | bool]:
        return {
            "fuel": self.fuel.name,
            "equivalence_ratio": self.equivalence_ratio,
            "lambda": self.lambda_,
            "afr": self.afr,
            "fuel_fraction": self.fuel_fraction,
            "molar_mass": self.molar_mass,
            "gas_constant": self.gas_constant,
            "gamma": self.gamma(),
            "combustion_efficiency": self.combustion_efficiency,
            "flammable": self.is_flammable,
            "adiabatic_flame_temperature": self.adiabatic_flame_temperature(),
        }


def mixture_from_flows(fuel: Fuel, fuel_flow: float, air_flow: float,
                       **kwargs) -> Mixture:
    """Build a :class:`Mixture` from mass flow rates (kg/s)."""
    if fuel_flow <= 0.0:
        raise ValueError("fuel flow must be positive to define a mixture")
    afr = air_flow / fuel_flow
    if afr <= 0.0:
        raise ValueError("air flow must be positive to define a mixture")
    phi = fuel.stoichiometric_afr / afr
    return Mixture(fuel, phi, **kwargs)


def equivalence_ratio_from_lambda(lambda_value: float) -> float:
    if lambda_value <= 0.0:
        raise ValueError("lambda must be positive")
    return 1.0 / lambda_value


def air_flow_for(fuel: Fuel, fuel_flow: float,
                 equivalence_ratio: float = 1.0) -> float:
    """Air mass flow (kg/s) needed for a target equivalence ratio."""
    return fuel.air_required(fuel_flow, equivalence_ratio)
