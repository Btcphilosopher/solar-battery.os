"""Engine-facing combustion components."""
from __future__ import annotations

import math
from dataclasses import dataclass

from ..core import units as U
from ..core.component import Component, ComponentOutput, Context, Derivatives
from ..core.events import Event, Severity
from ..core.state import EnergyDomain, PowerFlow, SystemState
from .fuel import Fuel
from .heat_release import heat_release_rate
from .ignition import IgnitionModel
from .mixture import Mixture
from .reaction import ReactionMechanism


class Burner(Component):
    """A continuous-flow combustor.

    Fuel and air enter at commanded rates; the mixture is formed, the
    equivalence ratio computed, and the released heat delivered to the thermal
    domain.  Unreleased chemical energy (from rich operation or from failing
    the ignition criteria) leaves as unburned fuel, so the ledger closes.
    """

    order = 15

    def __init__(self, name: str, fuel: Fuel, fuel_flow: float = 0.0,
                 equivalence_ratio: float = 1.0,
                 ignition: IgnitionModel | None = None,
                 fuel_key: str | None = None, phi_key: str | None = None,
                 air_key: str | None = None) -> None:
        super().__init__(name)
        self.fuel = fuel
        self.fuel_flow = float(fuel_flow)
        self.equivalence_ratio = float(equivalence_ratio)
        self.ignition = ignition
        self.fuel_key = fuel_key or f"{name}.fuel_flow"
        self.phi_key = phi_key or f"{name}.phi"
        self.air_key = air_key or f"{name}.air_flow"

    def _mixture(self, state: SystemState, context: Context) -> tuple[Mixture, float]:
        fuel_flow = max(0.0, context.get(self.fuel_key, self.fuel_flow))
        air_flow = context.get(self.air_key, -1.0)
        if air_flow >= 0.0 and fuel_flow > 0.0:
            phi = self.fuel.stoichiometric_afr / max(1e-12, air_flow / fuel_flow)
        else:
            phi = max(1e-6, context.get(self.phi_key, self.equivalence_ratio))
        mixture = Mixture(self.fuel, phi, state.thermal.pressure,
                          state.thermal.temperature)
        return mixture, fuel_flow

    def evaluate(self, state: SystemState, dt: float,
                 context: Context) -> ComponentOutput:
        mixture, fuel_flow = self._mixture(state, context)
        chemical_power = fuel_flow * self.fuel.lhv
        burning = True
        reason: str | None = None
        if self.ignition is not None and not context.speculative:
            burning = self.ignition.update(mixture, state.thermal.temperature,
                                           state.thermal.pressure,
                                           state.time, dt)
            if not burning:
                reason = self.ignition.criteria.failure_reason(
                    mixture, state.thermal.temperature, state.thermal.pressure,
                    self.ignition.accumulated_energy)
        elif self.ignition is not None:
            burning = self.ignition.ignited

        efficiency = mixture.combustion_efficiency if burning else 0.0
        released = chemical_power * efficiency
        unburned = chemical_power - released

        flows: list[PowerFlow] = []
        if chemical_power > 0.0:
            flows.append(PowerFlow(EnergyDomain.SOURCE, EnergyDomain.CHEMICAL,
                                   chemical_power, "fuel input", self.name))
        if released > 0.0:
            flows.append(PowerFlow(EnergyDomain.CHEMICAL, EnergyDomain.THERMAL,
                                   released, "heat release", self.name))
        if unburned > 0.0:
            flows.append(PowerFlow(EnergyDomain.CHEMICAL, EnergyDomain.ENVIRONMENT,
                                   unburned, "unburned fuel", self.name))

        events: list[Event] = []
        severity = Severity.NORMAL
        if not burning and chemical_power > 0.0:
            severity = Severity.WARNING
            events.append(Event(state.time, "no_ignition",
                                reason or f"{self.name} is not burning",
                                Severity.WARNING, self.name))
        return ComponentOutput(
            flows=flows,
            derivatives=Derivatives(heat_input=released,
                                    fuel_burn_rate=fuel_flow if burning else 0.0),
            diagnostics={f"{self.name}.fuel_flow": fuel_flow,
                         f"{self.name}.phi": mixture.equivalence_ratio,
                         f"{self.name}.air_flow": fuel_flow * mixture.afr,
                         f"{self.name}.heat_release": released,
                         f"{self.name}.combustion_efficiency": efficiency,
                         f"{self.name}.burning": burning,
                         f"{self.name}.flame_temperature":
                             mixture.adiabatic_flame_temperature(
                                 state.thermal.temperature) if burning else
                             state.thermal.temperature},
            events=events, severity=severity,
        )


class TransientCombustor(Component):
    """A combustor whose burn rate is set by a reaction mechanism.

    Unlike :class:`Burner`, which releases heat as fast as fuel arrives, this
    component holds a charge and burns it at the rate the mechanism dictates,
    which is what produces realistic pressure and temperature transients.
    """

    order = 15

    def __init__(self, name: str, fuel: Fuel, mechanism: ReactionMechanism,
                 charge_mass: float = 1e-3, equivalence_ratio: float = 1.0,
                 ignition: IgnitionModel | None = None) -> None:
        super().__init__(name)
        self.fuel = fuel
        self.mechanism = mechanism
        self.charge_mass = float(charge_mass)
        self.equivalence_ratio = float(equivalence_ratio)
        self.ignition = ignition
        self.progress = 0.0
        self.active = False

    def initialise(self, state: SystemState, context: Context) -> None:
        state.chemical.equivalence_ratio = self.equivalence_ratio
        mixture = Mixture(self.fuel, self.equivalence_ratio)
        state.chemical.fuel_mass = self.charge_mass * mixture.fuel_fraction
        state.extras["chemical_stored_energy"] = (
            state.chemical.fuel_mass * mixture.heat_release_per_kg_fuel())

    def evaluate(self, state: SystemState, dt: float,
                 context: Context) -> ComponentOutput:
        phi = max(1e-6, context.get(f"{self.name}.phi", self.equivalence_ratio))
        mixture = Mixture(self.fuel, phi, state.thermal.pressure,
                          state.thermal.temperature)
        progress = state.chemical.reaction_progress
        active = self.active
        if self.ignition is not None and not context.speculative:
            active = self.ignition.update(mixture, state.thermal.temperature,
                                          state.thermal.pressure, state.time, dt)
            self.active = active
        rate = 0.0
        if active and progress < 1.0:
            rate = max(0.0, self.mechanism.rate(progress,
                                                state.thermal.temperature,
                                                state.thermal.pressure,
                                                mixture, dt))
            rate = min(rate, (1.0 - progress) / max(dt, 1e-12))
        fuel_mass = self.charge_mass * mixture.fuel_fraction
        available = fuel_mass * mixture.heat_release_per_kg_fuel()
        released = rate * available
        burn_rate = rate * fuel_mass
        flows: list[PowerFlow] = []
        if released > 0.0:
            flows.append(PowerFlow(EnergyDomain.CHEMICAL, EnergyDomain.THERMAL,
                                   released, "heat release", self.name))
        return ComponentOutput(
            flows=flows,
            derivatives=Derivatives(heat_input=released,
                                    fuel_burn_rate=burn_rate,
                                    chemical_storage_rate=-released),
            diagnostics={f"{self.name}.progress": progress,
                         f"{self.name}.burn_rate": rate,
                         f"{self.name}.heat_release": released,
                         f"{self.name}.active": active},
        )


class FuelSupply(Component):
    """Meters fuel into the chemical domain without burning it.

    Useful when the combustion model lives elsewhere (for example inside a
    system-level engine model) but the fuel accounting should still be
    explicit in the ledger.
    """

    order = 12

    def __init__(self, name: str, fuel: Fuel, flow: float = 0.0,
                 input_key: str | None = None) -> None:
        super().__init__(name)
        self.fuel = fuel
        self.flow = float(flow)
        self.input_key = input_key or f"{name}.fuel_flow"

    def evaluate(self, state: SystemState, dt: float,
                 context: Context) -> ComponentOutput:
        flow = max(0.0, context.get(self.input_key, self.flow))
        power = flow * self.fuel.lhv
        return ComponentOutput(
            flows=[PowerFlow(EnergyDomain.SOURCE, EnergyDomain.CHEMICAL, power,
                             "fuel input", self.name)],
            derivatives=Derivatives(chemical_storage_rate=power),
            diagnostics={f"{self.name}.fuel_flow": flow,
                         f"{self.name}.chemical_power": power},
        )
