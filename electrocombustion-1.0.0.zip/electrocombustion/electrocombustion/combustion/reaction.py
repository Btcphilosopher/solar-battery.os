"""Reaction progress models and the interface for detailed chemistry.

Three engineering-grade models are provided out of the box (Wiebe, single-step
Arrhenius, eddy-dissipation).  They all satisfy the same
:class:`ReactionMechanism` protocol, so a detailed chemistry solver can be
dropped in later without any change to the components that consume it.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Protocol, runtime_checkable

from ..core import units as U
from .mixture import Mixture


@runtime_checkable
class ReactionMechanism(Protocol):
    """Anything that can report a reaction rate.

    Implementations must return ``dx/dt``, the rate of change of the burned
    mass fraction (1/s), given the current progress and thermodynamic state.
    """

    def rate(self, progress: float, temperature: float, pressure: float,
             mixture: Mixture, dt: float) -> float:
        ...


@dataclass(slots=True)
class WiebeFunction:
    """The classical Wiebe burn-rate law.

    ``x(tau) = 1 - exp(-a * tau**(m+1))`` where ``tau`` is normalised burn
    duration.  ``a = 6.908`` gives 99.9 % completion at ``tau = 1``, and
    ``m = 2`` is the usual shape factor for premixed spark ignition.  This is a
    *phenomenological* fit, not a chemical mechanism: it prescribes the shape
    of the heat release rather than deriving it.
    """

    duration: float = 0.01
    shape: float = 2.0
    efficiency_factor: float = 6.908
    start_time: float = 0.0
    kernel: float = 1e-6

    def __post_init__(self) -> None:
        if self.duration <= 0.0:
            raise ValueError("burn duration must be positive")
        if self.shape <= -1.0:
            raise ValueError("Wiebe shape factor must exceed -1")

    def fraction(self, t: float) -> float:
        """Cumulative burned fraction at absolute time ``t``."""
        tau = (t - self.start_time) / self.duration
        if tau <= 0.0:
            return 0.0
        if tau >= 1.0:
            return 1.0 - math.exp(-self.efficiency_factor)
        return 1.0 - math.exp(-self.efficiency_factor * tau ** (self.shape + 1.0))

    def derivative(self, t: float) -> float:
        """``dx/dt`` at absolute time ``t`` (1/s)."""
        tau = (t - self.start_time) / self.duration
        if tau <= 0.0 or tau >= 1.0:
            return 0.0
        a, m = self.efficiency_factor, self.shape
        return (a * (m + 1.0) / self.duration * tau ** m
                * math.exp(-a * tau ** (m + 1.0)))

    def rate(self, progress: float, temperature: float, pressure: float,
             mixture: Mixture, dt: float) -> float:
        """Rate expressed from progress, by inverting the Wiebe law.

        This lets the Wiebe function be used as a state-based mechanism inside
        a general solver, rather than requiring an explicit crank-angle clock.

        For any shape factor ``m > 0`` the law has zero rate at ``x = 0``, so
        ``x = 0`` is a fixed point of the state-based form and a naive
        integration from rest would never leave the origin.  That is a genuine
        property of the Wiebe law, not a numerical artefact: the law describes
        a burn that is *already established*.  The ``kernel`` parameter
        supplies the ignition kernel the law assumes, by evaluating the rate at
        a small non-zero progress whenever the burn has been activated but has
        not yet started.  Set ``kernel = 0`` to recover the raw law.
        """
        x = min(max(progress, 0.0), 1.0 - 1e-12)
        if x < self.kernel:
            x = self.kernel
        a, m = self.efficiency_factor, self.shape
        inner = -math.log(1.0 - x) / a
        tau = inner ** (1.0 / (m + 1.0)) if inner > 0.0 else 0.0
        if tau >= 1.0:
            return 0.0
        return (a * (m + 1.0) / self.duration * tau ** m
                * math.exp(-a * tau ** (m + 1.0)))

    def duration_for_completion(self, target: float = 0.99) -> float:
        """Time to reach ``target`` burned fraction (s)."""
        if not 0.0 < target < 1.0:
            raise ValueError("target must lie in (0, 1)")
        inner = -math.log(1.0 - target) / self.efficiency_factor
        return self.duration * inner ** (1.0 / (self.shape + 1.0))


@dataclass(slots=True)
class ArrheniusReaction:
    """Single-step global Arrhenius kinetics.

    ``dx/dt = A * (1-x)^n * [O2]^m * exp(-Ea/(R T))``

    Global one-step rates are calibrated fits, not elementary chemistry.  They
    capture the temperature sensitivity of the heat release well enough for
    system studies and badly for anything involving intermediate species.
    """

    pre_exponential: float = 5e8
    activation_energy: float = 1.3e8   # J/kmol -> see gas_constant below
    fuel_exponent: float = 1.0
    oxygen_exponent: float = 0.5
    gas_constant: float = U.R_UNIVERSAL * 1000.0   # J/(kmol.K)

    def rate(self, progress: float, temperature: float, pressure: float,
             mixture: Mixture, dt: float) -> float:
        if temperature <= 0.0:
            return 0.0
        remaining = max(0.0, 1.0 - progress)
        if remaining <= 0.0:
            return 0.0
        exponent = self.activation_energy / (self.gas_constant * temperature)
        if exponent > 700.0:
            return 0.0
        arrhenius = self.pre_exponential * math.exp(-exponent)
        oxygen = max(0.0, 1.0 - progress) if mixture.is_rich else 1.0
        density = mixture.density(pressure, temperature)
        concentration = density / mixture.molar_mass
        return (arrhenius * remaining ** self.fuel_exponent
                * (concentration * oxygen) ** self.oxygen_exponent
                / max(concentration, 1e-12) ** self.oxygen_exponent)

    def ignition_temperature(self, threshold_rate: float = 1.0,
                             bracket: tuple[float, float] = (300.0, 4000.0)) -> float:
        """Temperature at which the rate reaches ``threshold_rate`` (K)."""
        lo, hi = bracket
        dummy = None
        for _ in range(200):
            mid = 0.5 * (lo + hi)
            exponent = self.activation_energy / (self.gas_constant * mid)
            rate = (self.pre_exponential * math.exp(-exponent)
                    if exponent < 700.0 else 0.0)
            if abs(rate - threshold_rate) < 1e-9:
                return mid
            if rate < threshold_rate:
                lo = mid
            else:
                hi = mid
        return 0.5 * (lo + hi)


@dataclass(slots=True)
class EddyDissipation:
    """Mixing-limited combustion (Magnussen eddy-dissipation).

    Appropriate for turbulent diffusion flames where chemistry is fast and the
    rate is set by how quickly fuel and oxidiser mix.  ``mixing_time`` is the
    integral turbulent timescale.
    """

    mixing_time: float = 0.02
    constant: float = 4.0

    def __post_init__(self) -> None:
        if self.mixing_time <= 0.0:
            raise ValueError("mixing time must be positive")

    def rate(self, progress: float, temperature: float, pressure: float,
             mixture: Mixture, dt: float) -> float:
        remaining = max(0.0, 1.0 - progress)
        oxygen_limit = 1.0 if mixture.is_lean else 1.0 / mixture.equivalence_ratio
        return self.constant / self.mixing_time * remaining * oxygen_limit


@dataclass(slots=True)
class FlamePropagation:
    """Turbulent flame propagation through a fixed volume.

    Burn rate is the turbulent flame speed times the flame area times the
    unburned density.  Flame area is approximated as growing with the
    two-thirds power of the burned volume fraction and closing at the end of
    the burn, which reproduces the characteristic S-shaped mass fraction curve
    without prescribing it the way a Wiebe function does.
    """

    chamber_volume: float = 5e-4
    turbulence_intensity: float = 2.0
    characteristic_length: float = 0.04

    def flame_area(self, progress: float) -> float:
        x = min(1.0, max(0.0, progress))
        radius = (3.0 * self.chamber_volume / (4.0 * math.pi)) ** (1.0 / 3.0)
        sphere = 4.0 * math.pi * radius ** 2
        return sphere * (x ** (2.0 / 3.0)) * (1.0 - x) ** 0.5 * 3.0

    def turbulent_flame_speed(self, mixture: Mixture, temperature: float,
                              pressure: float) -> float:
        laminar = mixture.laminar_flame_speed(temperature, pressure)
        if laminar <= 0.0:
            return 0.0
        # Damkoehler: S_T/S_L = 1 + u'/S_L  (thin-flamelet limit)
        return laminar + self.turbulence_intensity

    def rate(self, progress: float, temperature: float, pressure: float,
             mixture: Mixture, dt: float) -> float:
        if progress >= 1.0:
            return 0.0
        speed = self.turbulent_flame_speed(mixture, temperature, pressure)
        if speed <= 0.0:
            return 0.0
        area = self.flame_area(max(progress, 1e-6))
        return min(1.0 / max(dt, 1e-9), speed * area / self.chamber_volume)


@dataclass(slots=True)
class ReactionProgress:
    """Integrates a :class:`ReactionMechanism` and tracks completion."""

    mechanism: ReactionMechanism
    progress: float = 0.0
    active: bool = False

    def step(self, temperature: float, pressure: float, mixture: Mixture,
             dt: float) -> float:
        """Advance the progress variable and return the increment."""
        if not self.active or self.progress >= 1.0:
            return 0.0
        rate = self.mechanism.rate(self.progress, temperature, pressure,
                                   mixture, dt)
        increment = min(1.0 - self.progress, max(0.0, rate) * dt)
        self.progress += increment
        return increment

    def rate(self, temperature: float, pressure: float, mixture: Mixture,
             dt: float) -> float:
        """Instantaneous ``dx/dt`` without mutating the progress."""
        if not self.active or self.progress >= 1.0:
            return 0.0
        return max(0.0, self.mechanism.rate(self.progress, temperature,
                                            pressure, mixture, dt))

    @property
    def complete(self) -> bool:
        return self.progress >= 1.0 - 1e-9

    def reset(self) -> None:
        self.progress = 0.0
        self.active = False
