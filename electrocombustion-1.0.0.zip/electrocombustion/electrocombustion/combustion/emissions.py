"""Emissions estimation.

These are **illustrative correlations**, not regulatory models.  CO2 follows
directly from carbon balance and is as accurate as the fuel formula.  NOx and
CO are strongly geometry-, mixing- and residence-time dependent; the forms
below capture the right qualitative trends (NOx peaking slightly lean and
rising steeply with flame temperature, CO rising steeply rich) and should not
be used for compliance work.
"""
from __future__ import annotations

import math
from dataclasses import dataclass

from ..core import units as U
from .fuel import Fuel
from .mixture import Mixture


def co2_rate(fuel: Fuel, fuel_burn_rate: float) -> float:
    """CO2 production rate (kg/s) from carbon balance."""
    return fuel_burn_rate * fuel.carbon_intensity


def co2_per_kwh(fuel: Fuel, efficiency: float) -> float:
    """kg CO2 per kWh of useful output at the given conversion efficiency."""
    if not 0.0 < efficiency <= 1.0:
        raise ValueError("efficiency must lie in (0, 1]")
    return fuel.specific_co2_per_joule * 3.6e6 / efficiency


def thermal_nox_rate(flame_temperature: float, residence_time: float,
                     oxygen_mole_fraction: float, pressure: float = U.P_ATM
                     ) -> float:
    """Extended-Zeldovich thermal NO formation rate (mol/(m^3.s)).

    ``d[NO]/dt = 6e16 / sqrt(T) * exp(-69090/T) * [N2] * [O2]^0.5``

    The exponential dominates: NO formation is negligible below about 1800 K
    and doubles roughly every 40 K above it, which is why this is the term
    that matters for combustor design.
    """
    t = flame_temperature
    if t <= 0.0 or residence_time <= 0.0:
        return 0.0
    exponent = 69090.0 / t
    if exponent > 700.0:
        return 0.0
    concentration = pressure / (U.R_UNIVERSAL * t)   # mol/m^3 total
    n2 = concentration * U.N2_MOLE_FRACTION_AIR
    o2 = max(0.0, concentration * oxygen_mole_fraction)
    return 6.0e16 / math.sqrt(t) * math.exp(-exponent) * n2 * math.sqrt(o2)


def co_fraction(mixture: Mixture, flame_temperature: float) -> float:
    """Approximate CO mole fraction in the products.

    Rich mixtures produce CO stoichiometrically, which the fuel model already
    resolves.  Lean mixtures produce CO from incomplete oxidation and
    quenching, modelled here as a small temperature-dependent floor.
    """
    products = mixture.fuel.products(mixture.equivalence_ratio)
    total = sum(v for k, v in products.items() if k != "FUEL")
    if total <= 0.0:
        return 0.0
    stoichiometric_co = products["CO"] / total
    quench = 2e-3 * math.exp(-(flame_temperature - 1200.0) / 400.0)
    return stoichiometric_co + max(0.0, min(5e-3, quench))


@dataclass(slots=True)
class EmissionsModel:
    """Bundles the emission correlations for one combustor.

    ``residence_time`` and ``post_flame_oxygen`` are the two parameters that
    actually control the NOx result; both are set by the combustor geometry
    and are the honest place to put the uncertainty.
    """

    residence_time: float = 0.01
    post_flame_oxygen: float = 0.02
    combustor_volume: float = 1e-3
    nox_scaling: float = 1.0

    def evaluate(self, mixture: Mixture, fuel_burn_rate: float,
                 flame_temperature: float, pressure: float = U.P_ATM
                 ) -> dict[str, float]:
        """Return mass rates in kg/s plus the underlying fractions."""
        co2 = co2_rate(mixture.fuel, fuel_burn_rate)
        rate = thermal_nox_rate(flame_temperature, self.residence_time,
                                self.post_flame_oxygen, pressure)
        nox_mol_per_s = rate * self.combustor_volume * self.nox_scaling
        nox = nox_mol_per_s * 0.0300061          # kg/mol NO
        co_frac = co_fraction(mixture, flame_temperature)
        exhaust_mass = fuel_burn_rate * (1.0 + mixture.afr)
        co = co_frac * exhaust_mass * (U.M_C + U.M_O) / U.M_AIR
        unburned = fuel_burn_rate * mixture.fuel.products(
            mixture.equivalence_ratio)["FUEL"]
        return {"co2": co2, "nox": nox, "co": co, "unburned_fuel": unburned,
                "co_fraction": co_frac,
                "nox_formation_rate": rate}

    def specific_emissions(self, mixture: Mixture, fuel_burn_rate: float,
                           flame_temperature: float, power: float,
                           pressure: float = U.P_ATM) -> dict[str, float]:
        """Emissions per unit useful energy (kg/kWh)."""
        base = self.evaluate(mixture, fuel_burn_rate, flame_temperature, pressure)
        if power <= 0.0:
            return {f"{k}_per_kwh": math.inf for k in ("co2", "nox", "co")}
        factor = 3.6e6 / power
        return {f"{k}_per_kwh": base[k] * factor for k in ("co2", "nox", "co")}
