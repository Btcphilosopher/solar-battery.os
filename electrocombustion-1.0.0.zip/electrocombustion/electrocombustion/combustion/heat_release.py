"""Heat release from combustion: rates, efficiency and energy accounting."""
from __future__ import annotations

import math
from dataclasses import dataclass, field

from ..core import units as U
from .fuel import Fuel
from .mixture import Mixture
from .reaction import ReactionMechanism, ReactionProgress


def heat_release_rate(fuel: Fuel, fuel_burn_rate: float,
                      combustion_efficiency: float = 1.0) -> float:
    """Thermal power released by burning fuel at ``fuel_burn_rate`` (W)."""
    if fuel_burn_rate < 0.0:
        raise ValueError("fuel burn rate cannot be negative")
    return fuel_burn_rate * fuel.lhv * combustion_efficiency


def fuel_rate_for_power(fuel: Fuel, thermal_power: float,
                        combustion_efficiency: float = 1.0) -> float:
    """Fuel mass flow (kg/s) needed to release ``thermal_power`` watts."""
    denominator = fuel.lhv * combustion_efficiency
    if denominator <= 0.0:
        raise ValueError("effective heating value must be positive")
    return thermal_power / denominator


def specific_fuel_consumption(fuel_flow: float, power: float) -> float:
    """Brake-specific fuel consumption in kg/(W.s), i.e. kg/J.

    Multiply by 3.6e9 for the familiar g/kWh.
    """
    if power <= 0.0:
        return math.inf
    return fuel_flow / power


def thermal_efficiency(power_out: float, fuel_flow: float, fuel: Fuel) -> float:
    """Fuel-to-output efficiency on an LHV basis (0..1)."""
    input_power = fuel_flow * fuel.lhv
    if input_power <= 0.0:
        return 0.0
    return power_out / input_power


@dataclass(slots=True)
class HeatReleaseProfile:
    """Time-resolved heat release driven by a reaction mechanism.

    Tracks the burned mass fraction, converts it to a heat release rate, and
    keeps a cumulative energy total so that the released energy can be checked
    against the chemical energy supplied.
    """

    mixture: Mixture
    charge_mass: float = 1e-3
    mechanism: ReactionMechanism | None = None
    progress: ReactionProgress | None = None
    released_energy: float = 0.0

    def __post_init__(self) -> None:
        if self.charge_mass <= 0.0:
            raise ValueError("charge mass must be positive")
        if self.progress is None:
            if self.mechanism is None:
                raise ValueError("supply a mechanism or a ReactionProgress")
            self.progress = ReactionProgress(self.mechanism)

    @property
    def fuel_mass(self) -> float:
        """Fuel contained in the charge (kg)."""
        return self.charge_mass * self.mixture.fuel_fraction

    @property
    def available_energy(self) -> float:
        """Energy the charge can release, after combustion efficiency (J)."""
        return self.fuel_mass * self.mixture.heat_release_per_kg_fuel()

    def activate(self) -> None:
        assert self.progress is not None
        self.progress.active = True

    def step(self, temperature: float, pressure: float, dt: float) -> float:
        """Advance one step; returns the heat release rate over it (W)."""
        assert self.progress is not None
        increment = self.progress.step(temperature, pressure, self.mixture, dt)
        energy = increment * self.available_energy
        self.released_energy += energy
        return energy / dt if dt > 0.0 else 0.0

    def rate(self, temperature: float, pressure: float, dt: float) -> float:
        """Instantaneous heat release rate without advancing (W)."""
        assert self.progress is not None
        return self.progress.rate(temperature, pressure, self.mixture, dt) \
            * self.available_energy

    def fuel_burn_rate(self, temperature: float, pressure: float,
                       dt: float) -> float:
        """Instantaneous fuel consumption (kg/s)."""
        assert self.progress is not None
        return self.progress.rate(temperature, pressure, self.mixture, dt) \
            * self.fuel_mass

    @property
    def burned_fraction(self) -> float:
        assert self.progress is not None
        return self.progress.progress

    @property
    def complete(self) -> bool:
        assert self.progress is not None
        return self.progress.complete

    def residual_energy(self) -> float:
        """Energy still locked in the unburned charge (J)."""
        return max(0.0, self.available_energy - self.released_energy)

    def reset(self) -> None:
        assert self.progress is not None
        self.progress.reset()
        self.released_energy = 0.0


@dataclass(slots=True)
class HeatSplit:
    """Distribution of released heat between work, coolant and exhaust.

    The three fractions must sum to at most 1; whatever remains is attributed
    to radiation and unaccounted losses so the split is always closed.
    """

    work: float = 0.35
    coolant: float = 0.28
    exhaust: float = 0.30

    def __post_init__(self) -> None:
        for name in ("work", "coolant", "exhaust"):
            value = getattr(self, name)
            if not 0.0 <= value <= 1.0:
                raise ValueError(f"{name} fraction must lie in 0..1")
        if self.work + self.coolant + self.exhaust > 1.0 + 1e-12:
            raise ValueError("heat split fractions cannot sum above 1")

    @property
    def other(self) -> float:
        return max(0.0, 1.0 - self.work - self.coolant - self.exhaust)

    def apply(self, heat: float) -> dict[str, float]:
        return {"work": heat * self.work, "coolant": heat * self.coolant,
                "exhaust": heat * self.exhaust, "other": heat * self.other}
