"""Pressure development in closed and open combustion volumes."""
from __future__ import annotations

import math
from dataclasses import dataclass, field

from ..core import units as U
from .mixture import Mixture


def ideal_gas_pressure(mass: float, volume: float, temperature: float,
                       gas_constant: float = U.R_AIR) -> float:
    """``p = m R T / V`` in Pa."""
    if volume <= 0.0:
        raise ValueError("volume must be positive")
    return mass * gas_constant * temperature / volume


def ideal_gas_temperature(pressure: float, volume: float, mass: float,
                          gas_constant: float = U.R_AIR) -> float:
    if mass <= 0.0:
        raise ValueError("mass must be positive")
    return pressure * volume / (mass * gas_constant)


def polytropic_pressure(p1: float, v1: float, v2: float,
                        exponent: float = 1.35) -> float:
    """Pressure after a polytropic volume change ``p V^n = const``."""
    if min(v1, v2) <= 0.0:
        raise ValueError("volumes must be positive")
    return p1 * (v1 / v2) ** exponent


def polytropic_temperature(t1: float, v1: float, v2: float,
                           exponent: float = 1.35) -> float:
    if min(v1, v2) <= 0.0:
        raise ValueError("volumes must be positive")
    return t1 * (v1 / v2) ** (exponent - 1.0)


def polytropic_work(p1: float, v1: float, v2: float,
                    exponent: float = 1.35) -> float:
    """Work done *by* the gas during a polytropic process (J)."""
    if abs(exponent - 1.0) < 1e-9:
        return p1 * v1 * math.log(v2 / v1)
    p2 = polytropic_pressure(p1, v1, v2, exponent)
    return (p1 * v1 - p2 * v2) / (exponent - 1.0)


def constant_volume_pressure_rise(pressure: float, temperature: float,
                                  heat: float, mass: float, cv: float) -> float:
    """Pressure after adding ``heat`` joules at constant volume (Pa)."""
    if mass <= 0.0 or cv <= 0.0 or temperature <= 0.0:
        raise ValueError("mass, cv and temperature must be positive")
    delta_t = heat / (mass * cv)
    return pressure * (temperature + delta_t) / temperature


@dataclass(slots=True)
class PressureVessel:
    """A fixed-volume vessel of reacting gas.

    Tracks mass, temperature and pressure through heat addition and mass
    exchange.  The energy balance is on internal energy, ``m cv dT = dQ``,
    which keeps it consistent with the engine's thermal accounting.
    """

    volume: float = 1e-3
    mass: float = 1.2e-3
    temperature: float = 298.15
    gas_constant: float = U.R_AIR
    specific_heat_cv: float = 718.0
    burst_pressure: float = math.inf

    def __post_init__(self) -> None:
        if self.volume <= 0.0 or self.mass <= 0.0:
            raise ValueError("volume and mass must be positive")
        if self.specific_heat_cv <= 0.0:
            raise ValueError("cv must be positive")

    @property
    def pressure(self) -> float:
        return ideal_gas_pressure(self.mass, self.volume, self.temperature,
                                  self.gas_constant)

    @property
    def density(self) -> float:
        return self.mass / self.volume

    @property
    def internal_energy(self) -> float:
        return self.mass * self.specific_heat_cv * self.temperature

    @property
    def gamma(self) -> float:
        cp = self.specific_heat_cv + self.gas_constant
        return cp / self.specific_heat_cv

    def add_heat(self, heat: float) -> float:
        """Add ``heat`` joules at constant volume; returns the new pressure."""
        self.temperature += heat / (self.mass * self.specific_heat_cv)
        return self.pressure

    def add_mass(self, mass: float, temperature: float) -> None:
        """Mix in ``mass`` kg of gas at ``temperature`` K.

        Energy is conserved by mixing on an internal-energy basis rather than
        by averaging temperatures, which would be wrong whenever the streams
        differ in mass.
        """
        if mass <= 0.0:
            raise ValueError("added mass must be positive")
        energy = self.internal_energy + mass * self.specific_heat_cv * temperature
        self.mass += mass
        self.temperature = energy / (self.mass * self.specific_heat_cv)

    def vent(self, mass: float) -> float:
        """Remove ``mass`` kg at the current state; returns enthalpy lost (J)."""
        removed = min(mass, self.mass * 0.999999)
        cp = self.specific_heat_cv + self.gas_constant
        self.mass -= removed
        return removed * cp * self.temperature

    @property
    def is_overpressure(self) -> bool:
        return self.pressure > self.burst_pressure

    def choked_mass_flow(self, area: float, downstream_pressure: float) -> float:
        """Mass flow through an orifice of ``area`` m^2 (kg/s).

        Uses the compressible orifice relation, switching to the choked form
        when the pressure ratio falls below the critical value.
        """
        if area <= 0.0:
            return 0.0
        p0 = self.pressure
        if p0 <= downstream_pressure:
            return 0.0
        g = self.gamma
        critical = (2.0 / (g + 1.0)) ** (g / (g - 1.0))
        density = self.density
        if downstream_pressure / p0 <= critical:
            return (area * p0 * math.sqrt(g * density / p0)
                    * (2.0 / (g + 1.0)) ** ((g + 1.0) / (2.0 * (g - 1.0))))
        ratio = downstream_pressure / p0
        term = (2.0 * g / (g - 1.0)) * (ratio ** (2.0 / g)
                                        - ratio ** ((g + 1.0) / g))
        return area * math.sqrt(max(0.0, p0 * density * term))


@dataclass(slots=True)
class CylinderGeometry:
    """Reciprocating cylinder geometry and its volume/crank relation.

    Included so that reciprocating machines can be represented, but the engine
    core never assumes one: this is an optional geometry helper, not a
    hard-coded engine model.
    """

    bore: float = 0.086
    stroke: float = 0.086
    connecting_rod: float = 0.145
    compression_ratio: float = 10.5

    def __post_init__(self) -> None:
        if min(self.bore, self.stroke, self.connecting_rod) <= 0.0:
            raise ValueError("bore, stroke and rod length must be positive")
        if self.compression_ratio <= 1.0:
            raise ValueError("compression ratio must exceed 1")

    @property
    def displacement(self) -> float:
        return math.pi / 4.0 * self.bore ** 2 * self.stroke

    @property
    def clearance_volume(self) -> float:
        return self.displacement / (self.compression_ratio - 1.0)

    def volume(self, crank_angle: float) -> float:
        """Instantaneous volume at ``crank_angle`` radians after TDC."""
        a = self.stroke / 2.0
        l = self.connecting_rod
        s = (a * math.cos(crank_angle)
             + math.sqrt(max(0.0, l ** 2 - (a * math.sin(crank_angle)) ** 2)))
        displaced = math.pi / 4.0 * self.bore ** 2 * (l + a - s)
        return self.clearance_volume + displaced

    def volume_derivative(self, crank_angle: float, h: float = 1e-6) -> float:
        """dV/dtheta in m^3/rad."""
        return (self.volume(crank_angle + h) - self.volume(crank_angle - h)) / (2 * h)

    def piston_area(self) -> float:
        return math.pi / 4.0 * self.bore ** 2

    def torque_from_pressure(self, pressure: float, crank_angle: float,
                             ambient: float = U.P_ATM) -> float:
        """Crank torque produced by cylinder pressure (N.m)."""
        return (pressure - ambient) * self.volume_derivative(crank_angle)
