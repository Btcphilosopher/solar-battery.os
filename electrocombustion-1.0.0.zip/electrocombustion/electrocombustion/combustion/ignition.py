"""Ignition models: spark energy, autoignition delay and flammability."""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Literal

from ..core import units as U
from .fuel import Fuel
from .mixture import Mixture


@dataclass(slots=True)
class IgnitionCriteria:
    """Conditions that must be met for a mixture to ignite."""

    minimum_temperature: float = 0.0     # K; 0 disables the test
    minimum_energy: float = 0.0          # J deposited by the igniter
    require_flammable: bool = True
    minimum_pressure: float = 0.0        # Pa

    def satisfied(self, mixture: Mixture, temperature: float,
                  pressure: float, deposited_energy: float) -> bool:
        if self.require_flammable and not mixture.is_flammable:
            return False
        if self.minimum_temperature > 0.0 and temperature < self.minimum_temperature:
            return False
        if self.minimum_pressure > 0.0 and pressure < self.minimum_pressure:
            return False
        if self.minimum_energy > 0.0 and deposited_energy < self.minimum_energy:
            return False
        return True

    def failure_reason(self, mixture: Mixture, temperature: float,
                       pressure: float, deposited_energy: float) -> str | None:
        """Explain why ignition did not occur; ``None`` when it did."""
        if self.require_flammable and not mixture.is_flammable:
            lo, hi = mixture.fuel.flammability_limits
            return (f"phi={mixture.equivalence_ratio:.3g} is outside the "
                    f"flammability limits {lo:g}..{hi:g}")
        if self.minimum_temperature > 0.0 and temperature < self.minimum_temperature:
            return (f"charge at {temperature:.6g} K is below the "
                    f"{self.minimum_temperature:.6g} K ignition threshold")
        if self.minimum_pressure > 0.0 and pressure < self.minimum_pressure:
            return f"pressure {pressure:.6g} Pa is below the ignition threshold"
        if self.minimum_energy > 0.0 and deposited_energy < self.minimum_energy:
            return (f"deposited energy {deposited_energy:.4g} J is below the "
                    f"{self.minimum_energy:.4g} J minimum ignition energy")
        return None


def minimum_ignition_energy(mixture: Mixture) -> float:
    """Approximate minimum spark energy for ignition (J).

    Scales the quenching-distance-based estimate with equivalence ratio: the
    MIE is lowest slightly rich and rises steeply toward the flammability
    limits.  Representative absolute values are used per fuel where known;
    otherwise a hydrocarbon default of 0.25 mJ applies.
    """
    base = {"hydrogen": 1.6e-5, "methane": 2.8e-4, "propane": 2.5e-4,
            "gasoline": 2.4e-4, "diesel": 3.0e-4, "ethanol": 2.6e-4,
            "methanol": 2.1e-4, "ammonia": 8.0e-3}.get(mixture.fuel.name, 2.5e-4)
    phi = mixture.equivalence_ratio
    lo, hi = mixture.fuel.flammability_limits
    if not lo <= phi <= hi:
        return math.inf
    # U-shaped penalty, minimum near phi = 1.1
    normalised = (phi - 1.1) / (0.5 * (hi - lo))
    return base * (1.0 + 8.0 * normalised ** 2)


def autoignition_delay(mixture: Mixture, temperature: float, pressure: float,
                       pre_exponential: float = 3.5e-3,
                       activation_temperature: float = 15_000.0,
                       pressure_exponent: float = -1.0) -> float:
    """Arrhenius ignition-delay correlation (s).

    ``tau = A * p^n * exp(Ea / (R T))`` in the standard engineering form used
    for diesel and knock modelling.  The default constants are generic; for
    quantitative work they must be fitted to the fuel and apparatus of
    interest.  Returns ``inf`` at temperatures where the exponent overflows,
    which is the honest representation of "does not ignite on any relevant
    timescale".
    """
    if temperature <= 0.0 or pressure <= 0.0:
        return math.inf
    exponent = activation_temperature / temperature
    if exponent > 700.0:
        return math.inf
    cetane_scale = 1.0
    if mixture.fuel.cetane_number:
        cetane_scale = 50.0 / max(20.0, mixture.fuel.cetane_number)
    return (pre_exponential * cetane_scale
            * (pressure / U.P_ATM) ** pressure_exponent
            * math.exp(exponent))


def knock_integral(temperatures: list[float], pressures: list[float],
                   mixture: Mixture, dt: float) -> float:
    """Livengood-Wu knock integral over a temperature/pressure history.

    Returns the accumulated ``sum(dt / tau)``; autoignition is predicted when
    this reaches 1.0.
    """
    if len(temperatures) != len(pressures):
        raise ValueError("temperature and pressure histories must be the same length")
    total = 0.0
    for t, p in zip(temperatures, pressures):
        tau = autoignition_delay(mixture, t, p)
        if math.isfinite(tau) and tau > 0.0:
            total += dt / tau
    return total


@dataclass(slots=True)
class Igniter:
    """A spark or glow igniter depositing energy into the charge."""

    name: str = "igniter"
    energy: float = 0.05          # J per event
    duration: float = 1e-3        # s
    efficiency: float = 0.3       # fraction reaching the kernel
    period: float = 0.0           # s between events; 0 = single shot
    start_time: float = 0.0

    def is_firing(self, t: float) -> bool:
        if t < self.start_time:
            return False
        if self.period <= 0.0:
            return t < self.start_time + self.duration
        phase = (t - self.start_time) % self.period
        return phase < self.duration

    def power(self, t: float) -> float:
        """Instantaneous igniter power draw (W)."""
        if not self.is_firing(t) or self.duration <= 0.0:
            return 0.0
        return self.energy / self.duration

    def deposited(self, t: float) -> float:
        """Power actually delivered to the kernel (W)."""
        return self.power(t) * self.efficiency


@dataclass(slots=True)
class IgnitionModel:
    """Combined ignition logic for a combustor.

    Tracks whether the charge is burning, applies the ignition criteria, and
    handles flame-out when the mixture leaves its flammable range or the
    temperature collapses.
    """

    criteria: IgnitionCriteria = field(default_factory=IgnitionCriteria)
    igniter: Igniter | None = None
    mode: Literal["spark", "compression", "continuous"] = "spark"
    flameout_temperature: float = 0.0
    ignited: bool = False
    ignition_time: float | None = None
    accumulated_energy: float = 0.0

    def update(self, mixture: Mixture, temperature: float, pressure: float,
               t: float, dt: float) -> bool:
        """Advance the ignition state; returns whether combustion is active."""
        deposited = 0.0
        if self.igniter is not None:
            deposited = self.igniter.deposited(t) * dt
            self.accumulated_energy += deposited
        if self.ignited:
            if self.flameout_temperature > 0.0 and temperature < self.flameout_temperature:
                self.ignited = False
            elif self.criteria.require_flammable and not mixture.is_flammable:
                self.ignited = False
            return self.ignited
        if self.mode == "compression":
            tau = autoignition_delay(mixture, temperature, pressure)
            if math.isfinite(tau) and dt >= tau:
                self.ignited = True
        elif self.mode == "continuous":
            self.ignited = self.criteria.satisfied(
                mixture, temperature, pressure, math.inf)
        else:
            if self.criteria.satisfied(mixture, temperature, pressure,
                                       self.accumulated_energy):
                self.ignited = True
        if self.ignited and self.ignition_time is None:
            self.ignition_time = t
        return self.ignited

    def reset(self) -> None:
        self.ignited = False
        self.ignition_time = None
        self.accumulated_energy = 0.0
