"""Fuel definitions and stoichiometry.

A fuel is described by its elemental formula ``C_x H_y O_z N_w S_v`` and its
heating value.  Everything else -- molar mass, stoichiometric air-fuel ratio,
product composition -- is *derived* from the formula rather than tabulated, so
a user-defined fuel is a first-class citizen with no special cases.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Mapping

from ..core import units as U

#: Molar enthalpy of ``CO + 1/2 O2 -> CO2`` at 298 K (J/mol).  Needed to debit
#: the energy still locked in carbon monoxide when a mixture runs rich.
CO_TO_CO2_ENTHALPY = 282_980.0


@dataclass(frozen=True, slots=True)
class Fuel:
    """A combustible substance.

    Parameters
    ----------
    lhv:
        Lower heating value (J/kg).  This is the value used for energy
        accounting, because the water in the products normally leaves as
        vapour.
    hhv:
        Higher heating value (J/kg).  Defaults to LHV plus the latent heat of
        the water formed, computed from the hydrogen content.
    carbon, hydrogen, oxygen, nitrogen, sulphur:
        Atoms per molecule.  Fractional values are allowed for surrogate blends
        such as diesel (C12.3 H22.2).
    """

    name: str
    lhv: float
    carbon: float = 0.0
    hydrogen: float = 0.0
    oxygen: float = 0.0
    nitrogen: float = 0.0
    sulphur: float = 0.0
    hhv: float | None = None
    density: float = 0.0                 # kg/m^3 (liquid or gas at reference)
    phase: str = "gas"
    adiabatic_flame_temperature: float = 0.0  # K at stoichiometric, 298 K air
    laminar_flame_speed: float = 0.0     # m/s at stoichiometric, 1 atm
    autoignition_temperature: float = 0.0     # K
    flammability_limits: tuple[float, float] = (0.5, 1.5)  # phi lower, upper
    research_octane: float | None = None
    cetane_number: float | None = None
    metadata: Mapping[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.lhv <= 0.0:
            raise ValueError(f"{self.name}: lower heating value must be positive")
        if self.carbon <= 0.0 and self.hydrogen <= 0.0:
            raise ValueError(
                f"{self.name}: a fuel must contain carbon or hydrogen"
            )
        lo, hi = self.flammability_limits
        if not 0.0 < lo < hi:
            raise ValueError(f"{self.name}: flammability limits must satisfy 0 < lo < hi")

    # -- composition --------------------------------------------------------
    @property
    def molar_mass(self) -> float:
        """Molar mass (kg/mol) derived from the elemental formula."""
        return (self.carbon * U.M_C + self.hydrogen * U.M_H
                + self.oxygen * U.M_O + self.nitrogen * U.M_N
                + self.sulphur * U.M_S)

    @property
    def oxygen_demand(self) -> float:
        """Moles of O2 required per mole of fuel for complete combustion.

        ``x + y/4 - z/2 + v`` from the balanced equation
        ``C_xH_yO_z + (x + y/4 - z/2) O2 -> x CO2 + y/2 H2O``.
        """
        demand = (self.carbon + self.hydrogen / 4.0 - self.oxygen / 2.0
                  + self.sulphur)
        if demand <= 0.0:
            raise ValueError(
                f"{self.name}: oxygen demand is non-positive; check the formula"
            )
        return demand

    @property
    def stoichiometric_afr(self) -> float:
        """Stoichiometric air-fuel ratio by mass (kg air / kg fuel)."""
        air_moles = self.oxygen_demand / U.O2_MOLE_FRACTION_AIR
        return air_moles * U.M_AIR / self.molar_mass

    @property
    def stoichiometric_ofr(self) -> float:
        """Stoichiometric pure-oxygen to fuel ratio by mass."""
        return self.oxygen_demand * U.M_O2 / self.molar_mass

    @property
    def higher_heating_value(self) -> float:
        """HHV (J/kg): supplied, or derived from the hydrogen content."""
        if self.hhv is not None:
            return self.hhv
        water_mass = (self.hydrogen / 2.0) * U.M_H2O / self.molar_mass
        return self.lhv + water_mass * U.LATENT_HEAT_VAPORISATION_WATER

    @property
    def carbon_intensity(self) -> float:
        """kg CO2 produced per kg fuel burned completely."""
        if self.carbon <= 0.0:
            return 0.0
        return self.carbon * U.M_CO2 / self.molar_mass

    @property
    def specific_co2_per_joule(self) -> float:
        """kg CO2 per joule of LHV released."""
        return self.carbon_intensity / self.lhv

    def products(self, equivalence_ratio: float = 1.0) -> dict[str, float]:
        """Moles of each species per mole of fuel supplied.

        Keys are ``CO2``, ``CO``, ``H2O``, ``SO2``, ``O2`` (excess), ``INERT``
        (the nitrogen + argon fraction of the combustion air), ``N2``
        (fuel-bound nitrogen) and ``FUEL`` (unburned fuel).

        The oxidation hierarchy for oxygen-starved mixtures is: sulphur and
        hydrogen first, then carbon to CO, then CO to CO2.  When there is not
        even enough oxygen to take all the carbon to CO, the remainder is
        reported as unburned fuel rather than as soot, because a
        two-species-per-element model cannot honestly resolve solid carbon.
        Mass balance closes exactly in every branch -- see
        :meth:`mass_balance_residual`.
        """
        phi = max(1e-9, equivalence_ratio)
        demand = self.oxygen_demand
        air_moles = demand / phi / U.O2_MOLE_FRACTION_AIR
        o2_supplied = air_moles * U.O2_MOLE_FRACTION_AIR
        inert = air_moles * (1.0 - U.O2_MOLE_FRACTION_AIR)
        o2_available = o2_supplied + self.oxygen / 2.0

        o2_for_h2o = self.hydrogen / 4.0
        o2_for_s = self.sulphur
        priority = o2_for_h2o + o2_for_s

        if o2_available >= priority + self.carbon:
            # complete combustion, possibly with excess oxygen
            burned = 1.0
            co2 = self.carbon
            co = 0.0
            excess = o2_available - priority - self.carbon
        elif o2_available >= priority + 0.5 * self.carbon:
            burned = 1.0
            remaining = o2_available - priority
            co2 = 2.0 * remaining - self.carbon
            co = self.carbon - co2
            excess = 0.0
        else:
            # not enough oxygen even for full conversion to CO: burn a fraction
            # of the fuel to CO + H2O and leave the rest unreacted
            # Only the burned fraction releases its own fuel-bound oxygen, so
            # the balance is  o2_from_air = b * (priority + 0.5C - O_fuel/2).
            per_mole = priority + 0.5 * self.carbon - self.oxygen / 2.0
            burned = min(1.0, o2_supplied / per_mole) if per_mole > 0.0 else 0.0
            co2 = 0.0
            co = self.carbon * burned
            excess = 0.0
            o2_for_h2o *= burned
            o2_for_s *= burned

        h2o = self.hydrogen / 2.0 * burned
        so2 = self.sulphur * burned
        return {
            "CO2": co2, "CO": co, "H2O": h2o, "SO2": so2,
            "O2": max(0.0, excess), "INERT": inert,
            "N2": self.nitrogen / 2.0 * burned,
            "FUEL": 1.0 - burned,
        }

    def product_mass(self, equivalence_ratio: float = 1.0) -> dict[str, float]:
        """Product masses per kilogram of fuel supplied."""
        moles = self.products(equivalence_ratio)
        molar = {"CO2": U.M_CO2, "CO": U.M_C + U.M_O, "H2O": U.M_H2O,
                 "SO2": U.M_SO2, "O2": U.M_O2, "INERT": U.M_INERT_AIR,
                 "N2": U.M_N2, "FUEL": self.molar_mass}
        m_fuel = self.molar_mass
        return {k: v * molar[k] / m_fuel for k, v in moles.items()}

    def burned_fraction(self, equivalence_ratio: float = 1.0) -> float:
        """Fraction of the supplied fuel that finds enough oxygen to react."""
        return 1.0 - self.products(equivalence_ratio)["FUEL"]

    def released_fraction(self, equivalence_ratio: float = 1.0) -> float:
        """Fraction of the fuel's LHV actually released at this mixture (0..1).

        This is *not* the same as :meth:`burned_fraction`.  A rich mixture
        oxidises carbon only as far as CO, and CO still holds most of its
        combustion energy: taking C to CO releases roughly a quarter of what
        taking it to CO2 releases.  Crediting the full LHV to any fuel that
        merely reacted would make the flame temperature keep rising past
        stoichiometric, which is wrong -- real flame temperature peaks just
        rich of stoichiometric and then falls.

        The debit is the standard molar enthalpy of the ``CO + 1/2 O2 -> CO2``
        step, 282.98 kJ/mol, applied to the CO left in the products.
        """
        products = self.products(equivalence_ratio)
        burned = 1.0 - products["FUEL"]
        molar_lhv = self.lhv * self.molar_mass
        if molar_lhv <= 0.0:
            return 0.0
        debit = products["CO"] * CO_TO_CO2_ENTHALPY
        return max(0.0, min(1.0, burned - debit / molar_lhv))

    def mass_balance_residual(self, equivalence_ratio: float = 1.0) -> float:
        """``|mass_in - mass_out|`` per kilogram of fuel.

        This should be at machine-precision level for every equivalence ratio;
        it exists so that the property can be asserted rather than assumed.
        """
        air = self.stoichiometric_afr / max(1e-9, equivalence_ratio)
        mass_in = 1.0 + air
        mass_out = sum(self.product_mass(equivalence_ratio).values())
        return abs(mass_in - mass_out)

    def air_required(self, fuel_mass: float,
                     equivalence_ratio: float = 1.0) -> float:
        """Air mass (kg) for ``fuel_mass`` at the given equivalence ratio."""
        if equivalence_ratio <= 0.0:
            raise ValueError("equivalence ratio must be positive")
        return fuel_mass * self.stoichiometric_afr / equivalence_ratio

    def energy(self, fuel_mass: float, use_hhv: bool = False) -> float:
        """Chemical energy in ``fuel_mass`` kilograms (J)."""
        return fuel_mass * (self.higher_heating_value if use_hhv else self.lhv)

    def volumetric_energy(self) -> float:
        """Energy per cubic metre (J/m^3); zero when density is unknown."""
        return self.lhv * self.density

    def is_flammable(self, equivalence_ratio: float) -> bool:
        lo, hi = self.flammability_limits
        return lo <= equivalence_ratio <= hi

    def describe(self) -> dict[str, float | str]:
        return {
            "name": self.name, "formula": self.formula,
            "molar_mass": self.molar_mass, "lhv": self.lhv,
            "hhv": self.higher_heating_value,
            "stoichiometric_afr": self.stoichiometric_afr,
            "carbon_intensity": self.carbon_intensity,
            "phase": self.phase,
        }

    @property
    def formula(self) -> str:
        parts = []
        for symbol, count in (("C", self.carbon), ("H", self.hydrogen),
                              ("O", self.oxygen), ("N", self.nitrogen),
                              ("S", self.sulphur)):
            if count <= 0.0:
                continue
            if abs(count - round(count)) < 1e-9:
                count_str = "" if round(count) == 1 else str(int(round(count)))
            else:
                count_str = f"{count:g}"
            parts.append(f"{symbol}{count_str}")
        return "".join(parts)

    def __repr__(self) -> str:
        return f"Fuel({self.name!r}, {self.formula})"


# ---------------------------------------------------------------------------
# Fuel library
# ---------------------------------------------------------------------------
_FUELS: dict[str, Fuel] = {}


def register_fuel(fuel: Fuel, *aliases: str) -> Fuel:
    _FUELS[fuel.name.lower()] = fuel
    for alias in aliases:
        _FUELS[alias.lower()] = fuel
    return fuel


def get_fuel(name: str) -> Fuel:
    try:
        return _FUELS[name.lower()]
    except KeyError as exc:
        raise KeyError(
            f"unknown fuel {name!r}; available: {sorted({f.name for f in _FUELS.values()})}"
        ) from exc


def available_fuels() -> tuple[str, ...]:
    return tuple(sorted({f.name for f in _FUELS.values()}))


METHANE = register_fuel(Fuel(
    name="methane", lhv=50.0e6, hhv=55.5e6, carbon=1, hydrogen=4,
    density=0.657, phase="gas", adiabatic_flame_temperature=2226.0,
    laminar_flame_speed=0.38, autoignition_temperature=810.0,
    flammability_limits=(0.5, 1.7), research_octane=120.0,
), "ch4", "natural_gas")

PROPANE = register_fuel(Fuel(
    name="propane", lhv=46.35e6, hhv=50.35e6, carbon=3, hydrogen=8,
    density=1.808, phase="gas", adiabatic_flame_temperature=2267.0,
    laminar_flame_speed=0.43, autoignition_temperature=743.0,
    flammability_limits=(0.51, 2.5), research_octane=112.0,
), "c3h8", "lpg")

HYDROGEN = register_fuel(Fuel(
    name="hydrogen", lhv=120.0e6, hhv=141.8e6, carbon=0.0, hydrogen=2,
    density=0.0838, phase="gas", adiabatic_flame_temperature=2483.0,
    laminar_flame_speed=2.10, autoignition_temperature=773.0,
    flammability_limits=(0.1, 7.1), research_octane=130.0,
), "h2")

GASOLINE = register_fuel(Fuel(
    name="gasoline", lhv=43.4e6, hhv=46.5e6, carbon=7.9, hydrogen=14.8,
    density=745.0, phase="liquid", adiabatic_flame_temperature=2138.0,
    laminar_flame_speed=0.40, autoignition_temperature=553.0,
    flammability_limits=(0.7, 1.4), research_octane=95.0,
), "petrol", "iso-octane_surrogate")

DIESEL = register_fuel(Fuel(
    name="diesel", lhv=42.8e6, hhv=45.6e6, carbon=12.3, hydrogen=22.2,
    density=832.0, phase="liquid", adiabatic_flame_temperature=2100.0,
    laminar_flame_speed=0.35, autoignition_temperature=483.0,
    flammability_limits=(0.3, 1.3), cetane_number=51.0,
), "derv", "gasoil")

ETHANOL = register_fuel(Fuel(
    name="ethanol", lhv=26.8e6, hhv=29.7e6, carbon=2, hydrogen=6, oxygen=1,
    density=789.0, phase="liquid", adiabatic_flame_temperature=2193.0,
    laminar_flame_speed=0.39, autoignition_temperature=636.0,
    flammability_limits=(0.55, 3.4), research_octane=109.0,
), "c2h5oh", "e100")

METHANOL = register_fuel(Fuel(
    name="methanol", lhv=19.9e6, hhv=22.7e6, carbon=1, hydrogen=4, oxygen=1,
    density=792.0, phase="liquid", adiabatic_flame_temperature=2143.0,
    laminar_flame_speed=0.36, autoignition_temperature=738.0,
    flammability_limits=(0.5, 4.0), research_octane=109.0,
), "ch3oh")

AMMONIA = register_fuel(Fuel(
    name="ammonia", lhv=18.6e6, hhv=22.5e6, carbon=0.0, hydrogen=3, nitrogen=1,
    density=0.696, phase="gas", adiabatic_flame_temperature=1850.0,
    laminar_flame_speed=0.07, autoignition_temperature=924.0,
    flammability_limits=(0.63, 1.4),
), "nh3")

BIOGAS = register_fuel(Fuel(
    name="biogas", lhv=21.5e6, carbon=0.6, hydrogen=2.4, oxygen=0.4,
    density=1.15, phase="gas", adiabatic_flame_temperature=1900.0,
    laminar_flame_speed=0.25, autoignition_temperature=850.0,
    flammability_limits=(0.6, 1.6),
    metadata={"note": "60 % CH4 / 40 % CO2 surrogate; CO2 carried as oxygen+carbon"},
))

KEROSENE = register_fuel(Fuel(
    name="kerosene", lhv=43.0e6, hhv=46.2e6, carbon=12.0, hydrogen=23.0,
    density=800.0, phase="liquid", adiabatic_flame_temperature=2093.0,
    laminar_flame_speed=0.38, autoignition_temperature=483.0,
    flammability_limits=(0.5, 1.4),
), "jet_a", "jet-a1")

FUEL_LIBRARY = (METHANE, PROPANE, HYDROGEN, GASOLINE, DIESEL, ETHANOL,
                METHANOL, AMMONIA, BIOGAS, KEROSENE)
