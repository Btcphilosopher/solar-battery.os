"""Voltage sources: DC, AC, time-varying, PWM and droop-controlled."""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Callable, Sequence


class VoltageSource:
    """Base class for a source of electromotive force.

    ``voltage(t)`` returns the *instantaneous* terminal EMF for AC waveforms
    and the constant value for DC.  ``rms(t)`` returns the RMS value over a
    cycle, which is what the power and thermal models consume.
    """

    def __init__(self, name: str = "source", internal_resistance: float = 0.0) -> None:
        self.name = name
        if internal_resistance < 0.0:
            raise ValueError("internal resistance must be non-negative")
        self.internal_resistance = float(internal_resistance)

    def voltage(self, t: float = 0.0) -> float:  # pragma: no cover
        raise NotImplementedError

    def rms(self, t: float = 0.0) -> float:
        return abs(self.voltage(t))

    @property
    def frequency(self) -> float:
        return 0.0

    @property
    def is_ac(self) -> bool:
        return self.frequency > 0.0

    def terminal_voltage(self, current: float, t: float = 0.0) -> float:
        """EMF less the internal resistive drop."""
        return self.rms(t) - current * self.internal_resistance

    def __repr__(self) -> str:
        return f"{type(self).__name__}(name={self.name!r})"


class DCSource(VoltageSource):
    """A constant-voltage DC source."""

    def __init__(self, voltage: float, name: str = "dc",
                 internal_resistance: float = 0.0) -> None:
        super().__init__(name, internal_resistance)
        self._voltage = float(voltage)

    def voltage(self, t: float = 0.0) -> float:
        return self._voltage

    def rms(self, t: float = 0.0) -> float:
        return abs(self._voltage)

    def set(self, voltage: float) -> None:
        self._voltage = float(voltage)


class ACSource(VoltageSource):
    """A sinusoidal AC source defined by its RMS amplitude.

    ``voltage(t)`` returns the instantaneous value ``sqrt(2) * V_rms *
    sin(2*pi*f*t + phase)``; ``rms(t)`` returns ``V_rms`` directly rather than
    the instantaneous magnitude, since averaging is what downstream power
    models expect.
    """

    def __init__(self, rms_voltage: float, frequency: float = 50.0,
                 phase: float = 0.0, name: str = "ac",
                 internal_resistance: float = 0.0, phases: int = 1) -> None:
        super().__init__(name, internal_resistance)
        if frequency <= 0.0:
            raise ValueError("AC frequency must be positive")
        if phases not in (1, 3):
            raise ValueError("phases must be 1 or 3")
        self.rms_voltage = float(rms_voltage)
        self._frequency = float(frequency)
        self.phase = float(phase)
        self.phases = phases

    @property
    def frequency(self) -> float:
        return self._frequency

    @property
    def peak(self) -> float:
        return math.sqrt(2.0) * self.rms_voltage

    @property
    def omega(self) -> float:
        return 2.0 * math.pi * self._frequency

    def voltage(self, t: float = 0.0) -> float:
        return self.peak * math.sin(self.omega * t + self.phase)

    def rms(self, t: float = 0.0) -> float:
        return self.rms_voltage

    def phase_voltages(self, t: float = 0.0) -> tuple[float, ...]:
        """Instantaneous per-phase voltages for a balanced three-phase set."""
        if self.phases != 3:
            return (self.voltage(t),)
        shift = 2.0 * math.pi / 3.0
        return tuple(
            self.peak * math.sin(self.omega * t + self.phase - k * shift)
            for k in range(3)
        )

    @property
    def line_voltage(self) -> float:
        """Line-to-line RMS voltage for a three-phase source."""
        return self.rms_voltage * math.sqrt(3.0) if self.phases == 3 else self.rms_voltage


class TimeVaryingSource(VoltageSource):
    """A source whose RMS voltage follows an arbitrary callable of time."""

    def __init__(self, profile: Callable[[float], float], name: str = "profile",
                 internal_resistance: float = 0.0, frequency: float = 0.0) -> None:
        super().__init__(name, internal_resistance)
        self.profile = profile
        self._frequency = float(frequency)

    @property
    def frequency(self) -> float:
        return self._frequency

    def voltage(self, t: float = 0.0) -> float:
        return float(self.profile(t))


class RampSource(TimeVaryingSource):
    """Linear ramp from ``start`` to ``end`` over ``duration`` seconds."""

    def __init__(self, start: float, end: float, duration: float,
                 name: str = "ramp", internal_resistance: float = 0.0) -> None:
        if duration <= 0.0:
            raise ValueError("ramp duration must be positive")

        def profile(t: float) -> float:
            frac = min(1.0, max(0.0, t / duration))
            return start + frac * (end - start)

        super().__init__(profile, name, internal_resistance)


class PWMSource(VoltageSource):
    """A DC bus chopped at a fixed duty cycle.

    The instantaneous waveform is the switched value; the RMS value of an ideal
    rectangular chop of amplitude ``V`` at duty ``D`` is ``V*sqrt(D)``, while
    the *mean* is ``V*D``.  Both are exposed because resistive heating follows
    the RMS and average current follows the mean.
    """

    def __init__(self, bus_voltage: float, duty: float = 1.0,
                 switching_frequency: float = 10_000.0, name: str = "pwm",
                 internal_resistance: float = 0.0) -> None:
        super().__init__(name, internal_resistance)
        self.bus_voltage = float(bus_voltage)
        self.switching_frequency = float(switching_frequency)
        self.duty = duty

    @property
    def duty(self) -> float:
        return self._duty

    @duty.setter
    def duty(self, value: float) -> None:
        self._duty = min(1.0, max(0.0, float(value)))

    def voltage(self, t: float = 0.0) -> float:
        period = 1.0 / self.switching_frequency
        phase = (t % period) / period
        return self.bus_voltage if phase < self._duty else 0.0

    def rms(self, t: float = 0.0) -> float:
        return abs(self.bus_voltage) * math.sqrt(self._duty)

    @property
    def mean(self) -> float:
        return self.bus_voltage * self._duty


class DroopSource(VoltageSource):
    """A source whose voltage falls linearly with delivered current.

    This is the standard first-order model of a generator or a stiff supply
    under load: ``V = V_noload * (1 - droop * I / I_rated)``.
    """

    def __init__(self, no_load_voltage: float, rated_current: float,
                 droop: float = 0.05, name: str = "droop") -> None:
        super().__init__(name, 0.0)
        if rated_current <= 0.0:
            raise ValueError("rated current must be positive")
        self.no_load_voltage = float(no_load_voltage)
        self.rated_current = float(rated_current)
        self.droop = float(droop)
        self.current = 0.0

    def voltage(self, t: float = 0.0) -> float:
        sag = self.droop * self.current / self.rated_current
        return max(0.0, self.no_load_voltage * (1.0 - sag))

    def with_current(self, current: float) -> float:
        self.current = float(current)
        return self.voltage()


@dataclass(slots=True)
class VoltageProfile:
    """A piecewise-linear voltage schedule defined by (time, voltage) points."""

    points: Sequence[tuple[float, float]]

    def __post_init__(self) -> None:
        if len(self.points) < 1:
            raise ValueError("a voltage profile needs at least one point")
        self.points = sorted(self.points, key=lambda p: p[0])

    def __call__(self, t: float) -> float:
        pts = self.points
        if t <= pts[0][0]:
            return pts[0][1]
        if t >= pts[-1][0]:
            return pts[-1][1]
        for (t0, v0), (t1, v1) in zip(pts, pts[1:]):
            if t0 <= t <= t1:
                span = t1 - t0
                if span <= 0.0:
                    return v1
                return v0 + (v1 - v0) * (t - t0) / span
        return pts[-1][1]  # pragma: no cover - unreachable

    def as_source(self, name: str = "profile") -> TimeVaryingSource:
        return TimeVaryingSource(self, name)
