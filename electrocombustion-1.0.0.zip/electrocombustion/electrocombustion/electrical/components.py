"""Engine-facing electrical components.

These wrap the physics in :mod:`electrical` into
:class:`~electrocombustion.core.component.Component` objects that emit power
flows and derivative contributions.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Callable

from ..core import units as U
from ..core.component import Component, ComponentOutput, Context, Derivatives
from ..core.events import Event, Severity
from ..core.state import EnergyDomain, PowerFlow, SystemState
from .conversion import Battery, PowerConverter
from .current import CurrentLimiter
from .machines import ElectricalMachine
from .resistance import Resistor
from .voltage import VoltageSource


class ResistiveHeater(Component):
    """A resistive element energised from a voltage source.

    The element's resistance is evaluated at the *current bulk temperature*,
    which closes the electro-thermal feedback loop described in section 6 of
    the specification: current raises temperature, temperature raises
    resistance, resistance changes the drawn power.

    ``duty`` (0..1) scales the applied RMS voltage squared, i.e. it represents
    time-proportional or phase-angle control rather than a change of source.
    """

    order = 10

    def __init__(self, name: str, resistor: Resistor, source: VoltageSource,
                 duty: float = 1.0, input_key: str | None = None,
                 current_limiter: CurrentLimiter | None = None) -> None:
        super().__init__(name)
        self.resistor = resistor
        self.source = source
        self.duty = float(duty)
        self.input_key = input_key or f"{name}.duty"
        self.current_limiter = current_limiter

    def evaluate(self, state: SystemState, dt: float,
                 context: Context) -> ComponentOutput:
        duty = min(1.0, max(0.0, context.get(self.input_key, self.duty)))
        temperature = state.thermal.temperature
        resistance = self.resistor.value(temperature)
        voltage = self.source.rms(state.time) * math.sqrt(duty)
        current = voltage / resistance if resistance > 0.0 else 0.0
        limited = False
        if self.current_limiter is not None:
            allowed = self.current_limiter.apply(current)
            limited = allowed != current
            current = allowed
            voltage = current * resistance
        power = current * current * resistance

        flows = [
            PowerFlow(EnergyDomain.SOURCE, EnergyDomain.ELECTRICAL, power,
                      "electrical input", self.name),
            PowerFlow(EnergyDomain.ELECTRICAL, EnergyDomain.THERMAL, power,
                      "joule heating", self.name),
        ]
        events: list[Event] = []
        if limited:
            events.append(Event(state.time, "current_limit",
                                f"{self.name} current limited",
                                Severity.WARNING, self.name,
                                {"current": current}))
        return ComponentOutput(
            flows=flows,
            derivatives=Derivatives(heat_input=power),
            diagnostics={f"{self.name}.current": current,
                         f"{self.name}.voltage": voltage,
                         f"{self.name}.resistance": resistance,
                         f"{self.name}.power": power,
                         f"{self.name}.duty": duty},
            events=events,
            severity=Severity.WARNING if limited else Severity.NORMAL,
        )


class ElectricalLoad(Component):
    """An external electrical load that consumes delivered power.

    Power leaves the ELECTRICAL domain labelled ``"load"``, which is how the
    ledger distinguishes useful output from loss.
    """

    order = 90

    def __init__(self, name: str, power: float = 0.0,
                 input_key: str | None = None,
                 profile: Callable[[float], float] | None = None) -> None:
        super().__init__(name)
        self.power = float(power)
        self.input_key = input_key or f"{name}.power"
        self.profile = profile

    def demand(self, state: SystemState, context: Context) -> float:
        if self.profile is not None:
            return max(0.0, float(self.profile(state.time)))
        return max(0.0, context.get(self.input_key, self.power))

    def evaluate(self, state: SystemState, dt: float,
                 context: Context) -> ComponentOutput:
        power = self.demand(state, context)
        flows = [PowerFlow(EnergyDomain.ELECTRICAL, EnergyDomain.ENVIRONMENT,
                           power, "load", self.name)]
        return ComponentOutput(
            flows=flows,
            diagnostics={f"{self.name}.load_power": power},
        )


class GridSupply(Component):
    """An unlimited electrical supply delivering a commanded power."""

    order = 5

    def __init__(self, name: str = "grid", power: float = 0.0,
                 input_key: str | None = None,
                 profile: Callable[[float], float] | None = None,
                 max_power: float = math.inf) -> None:
        super().__init__(name)
        self.power = float(power)
        self.input_key = input_key or f"{name}.power"
        self.profile = profile
        self.max_power = max_power

    def evaluate(self, state: SystemState, dt: float,
                 context: Context) -> ComponentOutput:
        requested = (float(self.profile(state.time)) if self.profile is not None
                     else context.get(self.input_key, self.power))
        power = min(self.max_power, max(0.0, requested))
        curtailed = requested > self.max_power
        events = []
        if curtailed:
            events.append(Event(state.time, "supply_limit",
                                f"{self.name} limited to {self.max_power:g} W",
                                Severity.WARNING, self.name))
        return ComponentOutput(
            flows=[PowerFlow(EnergyDomain.SOURCE, EnergyDomain.ELECTRICAL,
                             power, "electrical input", self.name)],
            diagnostics={f"{self.name}.power": power},
            events=events,
            severity=Severity.WARNING if curtailed else Severity.NORMAL,
        )


class ConverterComponent(Component):
    """A power converter whose losses become heat in the thermal domain."""

    order = 50

    def __init__(self, name: str, converter: PowerConverter,
                 output_power: float = 0.0, input_key: str | None = None,
                 loss_to_thermal: bool = True) -> None:
        super().__init__(name)
        self.converter = converter
        self.output_power = float(output_power)
        self.input_key = input_key or f"{name}.output"
        self.loss_to_thermal = loss_to_thermal

    def evaluate(self, state: SystemState, dt: float,
                 context: Context) -> ComponentOutput:
        target = max(0.0, context.get(self.input_key, self.output_power))
        losses = self.converter.losses(target) if target > 0.0 else (
            self.converter.loss_model.no_load if self.converter.loss_model else 0.0)
        flows = [
            PowerFlow(EnergyDomain.SOURCE, EnergyDomain.ELECTRICAL,
                      target + losses, "converter input", self.name),
            PowerFlow(EnergyDomain.ELECTRICAL, EnergyDomain.ENVIRONMENT,
                      target, "load", self.name),
        ]
        derivatives = Derivatives()
        if losses > 0.0:
            if self.loss_to_thermal:
                flows.append(PowerFlow(EnergyDomain.ELECTRICAL,
                                       EnergyDomain.THERMAL, losses,
                                       "converter loss", self.name))
                derivatives = Derivatives(heat_input=losses)
            else:
                flows.append(PowerFlow(EnergyDomain.ELECTRICAL,
                                       EnergyDomain.ENVIRONMENT, losses,
                                       "converter loss", self.name))
        overloaded = self.converter.overloaded(target)
        return ComponentOutput(
            flows=flows, derivatives=derivatives,
            diagnostics={f"{self.name}.output": target,
                         f"{self.name}.losses": losses,
                         f"{self.name}.efficiency":
                             self.converter.efficiency_at(target)},
            severity=Severity.LIMIT if overloaded else Severity.NORMAL,
            events=[Event(state.time, "overload",
                          f"{self.name} above rating", Severity.LIMIT, self.name)]
            if overloaded else [],
        )


class BatteryComponent(Component):
    """A battery that charges or discharges at a commanded current.

    Positive current discharges the pack.  Internal resistance loss is routed
    to the thermal domain so pack heating is visible in the energy waterfall.
    """

    order = 20

    def __init__(self, name: str, battery: Battery, current: float = 0.0,
                 input_key: str | None = None,
                 loss_to_thermal: bool = True) -> None:
        super().__init__(name)
        self.battery = battery
        self.current = float(current)
        self.input_key = input_key or f"{name}.current"
        self.loss_to_thermal = loss_to_thermal

    def evaluate(self, state: SystemState, dt: float,
                 context: Context) -> ComponentOutput:
        command = context.get(self.input_key, self.current)
        current = min(self.battery.max_current,
                      max(-self.battery.max_current, command))
        terminal_power = self.battery.power(current)
        losses = self.battery.losses(current)
        flows: list[PowerFlow] = []
        derivatives = Derivatives()
        if terminal_power >= 0.0:
            flows.append(PowerFlow(EnergyDomain.SOURCE, EnergyDomain.ELECTRICAL,
                                   terminal_power, "battery discharge", self.name))
        else:
            flows.append(PowerFlow(EnergyDomain.ELECTRICAL, EnergyDomain.SOURCE,
                                   -terminal_power, "battery charge", self.name))
        if losses > 0.0:
            target = EnergyDomain.THERMAL if self.loss_to_thermal else EnergyDomain.ENVIRONMENT
            flows.append(PowerFlow(EnergyDomain.SOURCE, target, losses,
                                   "battery internal loss", self.name))
            if self.loss_to_thermal:
                derivatives = Derivatives(heat_input=losses)
        soc_low = self.battery.soc < 0.05
        return ComponentOutput(
            flows=flows, derivatives=derivatives,
            diagnostics={f"{self.name}.current": current,
                         f"{self.name}.soc": self.battery.soc,
                         f"{self.name}.terminal_voltage":
                             self.battery.terminal_voltage(current),
                         f"{self.name}.power": terminal_power},
            severity=Severity.WARNING if soc_low else Severity.NORMAL,
        )

    def commit(self, current: float, dt: float) -> float:
        """Integrate the state of charge; call once per accepted step."""
        return self.battery.step(current, dt)


class MotorComponent(Component):
    """An electric motor driving the shaft from a supply voltage."""

    order = 30

    def __init__(self, name: str, machine: ElectricalMachine,
                 voltage: float = 0.0, input_key: str | None = None) -> None:
        super().__init__(name)
        self.machine = machine
        self.voltage = float(voltage)
        self.input_key = input_key or f"{name}.voltage"

    def evaluate(self, state: SystemState, dt: float,
                 context: Context) -> ComponentOutput:
        voltage = max(0.0, context.get(self.input_key, self.voltage))
        speed = state.mechanical.speed
        result = self.machine.as_motor(voltage, speed)
        electrical_in = max(0.0, result["electrical_power"])
        shaft_power = result["shaft_power"]
        loss_total = electrical_in - shaft_power
        flows = [
            PowerFlow(EnergyDomain.SOURCE, EnergyDomain.ELECTRICAL,
                      electrical_in, "motor supply", self.name),
        ]
        if shaft_power > 0.0:
            flows.append(PowerFlow(EnergyDomain.ELECTRICAL,
                                   EnergyDomain.MECHANICAL, shaft_power,
                                   "motor shaft power", self.name))
        if loss_total > 0.0:
            flows.append(PowerFlow(EnergyDomain.ELECTRICAL, EnergyDomain.THERMAL,
                                   loss_total, "motor loss", self.name))
        return ComponentOutput(
            flows=flows,
            derivatives=Derivatives(torque=result["shaft_torque"],
                                    heat_input=max(0.0, loss_total)),
            diagnostics={f"{self.name}.current": result["current"],
                         f"{self.name}.torque": result["shaft_torque"],
                         f"{self.name}.efficiency": result["efficiency"]},
        )
