"""Rotating electrical machine models shared by motors and generators.

The models are lumped-parameter and speed/torque based.  They are accurate
enough for system-level energy accounting and control studies, and they are
explicitly *not* a substitute for finite-element machine design.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

from ..core import units as U


@dataclass(slots=True)
class MachineLosses:
    """Speed- and current-dependent loss breakdown for a rotating machine.

    ``copper``    ohmic loss in the windings, proportional to I^2.
    ``iron``      hysteresis and eddy-current loss, modelled as
                  ``k_h * f + k_e * f^2`` scaled by flux.
    ``windage``   aerodynamic and bearing drag, ``k_w * omega^3 + k_f * omega``.
    """

    copper: float = 0.0
    iron: float = 0.0
    windage: float = 0.0
    stray: float = 0.0

    @property
    def total(self) -> float:
        return self.copper + self.iron + self.windage + self.stray

    def as_dict(self) -> dict[str, float]:
        return {"copper": self.copper, "iron": self.iron,
                "windage": self.windage, "stray": self.stray,
                "total": self.total}


@dataclass(slots=True)
class ElectricalMachine:
    """A DC-equivalent rotating machine usable as motor or generator.

    Parameters
    ----------
    kt:
        Torque constant (N.m/A).  For a DC-equivalent machine the back-EMF
        constant in V.s/rad equals ``kt``, which is a consequence of energy
        conservation rather than a coincidence.
    armature_resistance:
        Winding resistance (ohm).
    rated_speed, rated_torque:
        Used to normalise the loss coefficients and to flag overload.
    """

    name: str = "machine"
    kt: float = 1.0
    armature_resistance: float = 0.05
    armature_inductance: float = 1e-3
    rated_speed: float = 314.16
    rated_torque: float = 100.0
    hysteresis_coefficient: float = 0.5
    eddy_coefficient: float = 1e-3
    windage_coefficient: float = 1e-6
    friction_torque: float = 0.5
    stray_fraction: float = 0.005
    pole_pairs: int = 2
    flux: float = 1.0

    def __post_init__(self) -> None:
        if self.kt <= 0.0:
            raise ValueError("torque constant must be positive")
        if self.armature_resistance <= 0.0:
            raise ValueError("armature resistance must be positive")
        if self.rated_speed <= 0.0 or self.rated_torque <= 0.0:
            raise ValueError("rated speed and torque must be positive")

    # -- fundamental relations ---------------------------------------------
    def back_emf(self, speed: float) -> float:
        """Induced EMF at shaft ``speed`` (V)."""
        return self.kt * self.flux * speed

    def torque(self, current: float) -> float:
        """Electromagnetic torque for armature ``current`` (N.m)."""
        return self.kt * self.flux * current

    def current_for_torque(self, torque: float) -> float:
        denominator = self.kt * self.flux
        if denominator == 0.0:
            raise ValueError("flux collapsed: cannot produce torque")
        return torque / denominator

    def electrical_frequency(self, speed: float) -> float:
        """Fundamental electrical frequency (Hz)."""
        return abs(speed) * self.pole_pairs / (2.0 * math.pi)

    # -- losses -------------------------------------------------------------
    def losses(self, current: float, speed: float,
               resistance: float | None = None) -> MachineLosses:
        r = self.armature_resistance if resistance is None else resistance
        copper = current * current * r
        f = self.electrical_frequency(speed)
        iron = (self.hysteresis_coefficient * f
                + self.eddy_coefficient * f * f) * self.flux ** 2
        windage = (self.windage_coefficient * abs(speed) ** 3
                   + self.friction_torque * abs(speed))
        mechanical_power = abs(self.torque(current) * speed)
        stray = self.stray_fraction * mechanical_power
        return MachineLosses(copper, iron, windage, stray)

    # -- operating modes ----------------------------------------------------
    def as_generator(self, speed: float, load_resistance: float,
                     resistance: float | None = None) -> dict[str, float]:
        """Operate as a generator into a resistive load.

        Returns terminal voltage, current, delivered electrical power, the
        mechanical power absorbed and the resulting efficiency.
        """
        if load_resistance <= 0.0:
            raise ValueError("load resistance must be positive")
        r_a = self.armature_resistance if resistance is None else resistance
        emf = self.back_emf(speed)
        current = emf / (r_a + load_resistance)
        terminal = current * load_resistance
        electrical_out = terminal * current
        losses = self.losses(current, speed, r_a)
        mechanical_in = electrical_out + losses.iron + losses.windage + losses.stray + losses.copper
        efficiency = electrical_out / mechanical_in if mechanical_in > 0.0 else 0.0
        return {
            "emf": emf, "current": current, "terminal_voltage": terminal,
            "electrical_power": electrical_out, "shaft_power": mechanical_in,
            "mechanical_power": mechanical_in,
            "efficiency": efficiency, "torque": mechanical_in / speed if speed else 0.0,
            **{f"loss_{k}": v for k, v in losses.as_dict().items()},
        }

    def as_motor(self, voltage: float, speed: float,
                 resistance: float | None = None) -> dict[str, float]:
        """Operate as a motor from a fixed supply voltage."""
        r_a = self.armature_resistance if resistance is None else resistance
        emf = self.back_emf(speed)
        current = (voltage - emf) / r_a
        electromagnetic_torque = self.torque(current)
        losses = self.losses(current, speed, r_a)
        electrical_in = voltage * current
        shaft_power = electromagnetic_torque * speed - losses.windage - losses.stray - losses.iron
        efficiency = shaft_power / electrical_in if electrical_in > 0.0 else 0.0
        shaft_torque = shaft_power / speed if speed else electromagnetic_torque
        return {
            "emf": emf, "current": current, "electrical_power": electrical_in,
            "electromagnetic_torque": electromagnetic_torque,
            "shaft_torque": shaft_torque, "shaft_power": shaft_power,
            "efficiency": efficiency,
            **{f"loss_{k}": v for k, v in losses.as_dict().items()},
        }

    def stall_current(self, voltage: float) -> float:
        return voltage / self.armature_resistance

    def no_load_speed(self, voltage: float) -> float:
        return voltage / (self.kt * self.flux)

    def is_overloaded(self, torque: float, speed: float) -> bool:
        return abs(torque) > self.rated_torque or abs(speed) > 1.2 * self.rated_speed

    @property
    def electrical_time_constant(self) -> float:
        return self.armature_inductance / self.armature_resistance


@dataclass(slots=True)
class SynchronousMachine(ElectricalMachine):
    """A synchronous machine with a controllable field and load angle.

    Adds the classical round-rotor power relation
    ``P = (E * V / X_s) * sin(delta)`` on top of the DC-equivalent loss model,
    which is what makes grid-tied behaviour (load angle, pull-out torque)
    representable.
    """

    synchronous_reactance: float = 1.0
    field_current: float = 1.0
    excitation_constant: float = 1.0

    def excitation_voltage(self, speed: float) -> float:
        return self.excitation_constant * self.field_current * speed

    def power_angle_output(self, terminal_voltage: float, speed: float,
                           load_angle: float) -> float:
        """Real power exported at a given load angle (W)."""
        if self.synchronous_reactance <= 0.0:
            raise ValueError("synchronous reactance must be positive")
        e = self.excitation_voltage(speed)
        return e * terminal_voltage / self.synchronous_reactance * math.sin(load_angle)

    def pull_out_power(self, terminal_voltage: float, speed: float) -> float:
        """Maximum steady-state power before the machine loses synchronism."""
        return self.power_angle_output(terminal_voltage, speed, math.pi / 2.0)

    def load_angle_for(self, power: float, terminal_voltage: float,
                       speed: float) -> float:
        """Load angle required to export ``power``; raises beyond pull-out."""
        limit = self.pull_out_power(terminal_voltage, speed)
        if limit <= 0.0:
            raise ValueError("machine cannot export power at this excitation/speed")
        ratio = power / limit
        if abs(ratio) > 1.0:
            raise ValueError(
                f"requested {power:g} W exceeds pull-out power {limit:g} W"
            )
        return math.asin(ratio)
