"""Power conversion: converters, rectifiers, inverters and batteries."""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Callable, Sequence

from ..core import units as U


@dataclass(slots=True)
class LossModel:
    """Quadratic converter loss model.

    ``P_loss = P_no_load + k1 * P_out + k2 * (P_out / P_rated)^2 * P_rated``

    The three terms correspond to standing losses (gate drive, control,
    magnetising), conduction losses proportional to throughput, and
    ohmic/switching losses growing with the square of loading.  This form
    reproduces the characteristic converter efficiency curve: poor at very
    light load, peaking around 40-70 % load, falling again at full load.
    """

    rated_power: float
    no_load: float = 0.0
    linear: float = 0.01
    quadratic: float = 0.02

    def __post_init__(self) -> None:
        if self.rated_power <= 0.0:
            raise ValueError("rated power must be positive")
        for name in ("no_load", "linear", "quadratic"):
            if getattr(self, name) < 0.0:
                raise ValueError(f"{name} loss coefficient must be non-negative")

    def losses(self, output_power: float) -> float:
        """Loss (W) for a given delivered output power."""
        p = abs(output_power)
        load = p / self.rated_power
        return self.no_load + self.linear * p + self.quadratic * load * load * self.rated_power

    def efficiency(self, output_power: float) -> float:
        """Output over input at the given output power (0..1)."""
        p = abs(output_power)
        if p <= 0.0:
            return 0.0
        return p / (p + self.losses(p))

    def peak_efficiency(self, samples: int = 400) -> tuple[float, float]:
        """Return ``(load_fraction, efficiency)`` at the efficiency peak."""
        best = (0.0, 0.0)
        for i in range(1, samples + 1):
            frac = i / samples
            eta = self.efficiency(frac * self.rated_power)
            if eta > best[1]:
                best = (frac, eta)
        return best


@dataclass(slots=True)
class EfficiencyCurve:
    """Tabulated efficiency as a function of load fraction (0..1)."""

    load_fractions: Sequence[float]
    efficiencies: Sequence[float]

    def __post_init__(self) -> None:
        if len(self.load_fractions) != len(self.efficiencies):
            raise ValueError("curve arrays must have equal length")
        if len(self.load_fractions) < 2:
            raise ValueError("efficiency curve needs at least two points")
        pairs = sorted(zip(self.load_fractions, self.efficiencies))
        self.load_fractions = [p[0] for p in pairs]
        self.efficiencies = [p[1] for p in pairs]
        for eta in self.efficiencies:
            if not 0.0 < eta <= 1.0:
                raise ValueError("efficiencies must lie in (0, 1]")

    def __call__(self, load_fraction: float) -> float:
        xs, ys = self.load_fractions, self.efficiencies
        x = min(max(load_fraction, xs[0]), xs[-1])
        for (x0, y0), (x1, y1) in zip(zip(xs, ys), zip(xs[1:], ys[1:])):
            if x0 <= x <= x1:
                span = x1 - x0
                return y0 if span <= 0.0 else y0 + (y1 - y0) * (x - x0) / span
        return ys[-1]  # pragma: no cover


class PowerConverter:
    """A generic bidirectional power converter.

    Efficiency may be a constant, an :class:`EfficiencyCurve`, or derived from
    a :class:`LossModel`.  The converter reports input power, output power and
    loss for a requested output, so the energy ledger can be closed exactly.
    """

    def __init__(self, name: str = "converter", rated_power: float = 1e6,
                 efficiency: float | EfficiencyCurve | None = 0.95,
                 loss_model: LossModel | None = None) -> None:
        if rated_power <= 0.0:
            raise ValueError("rated power must be positive")
        if efficiency is None and loss_model is None:
            raise ValueError("supply either an efficiency or a loss model")
        if isinstance(efficiency, float) and not 0.0 < efficiency <= 1.0:
            raise ValueError("efficiency must lie in (0, 1]")
        self.name = name
        self.rated_power = float(rated_power)
        self.efficiency_spec = efficiency
        self.loss_model = loss_model

    def efficiency_at(self, output_power: float) -> float:
        """Conversion efficiency when delivering ``output_power`` (0..1)."""
        p = abs(output_power)
        if self.loss_model is not None:
            return self.loss_model.efficiency(p)
        if isinstance(self.efficiency_spec, EfficiencyCurve):
            return self.efficiency_spec(p / self.rated_power)
        return float(self.efficiency_spec or 0.0)

    def input_for_output(self, output_power: float) -> float:
        """Input power required to deliver ``output_power`` (W)."""
        p = abs(output_power)
        if p == 0.0:
            return self.loss_model.no_load if self.loss_model else 0.0
        eta = self.efficiency_at(p)
        if eta <= 0.0:
            raise ValueError(f"{self.name}: efficiency collapsed to zero at {p:g} W")
        return p / eta

    def output_for_input(self, input_power: float, tol: float = 1e-9,
                         max_iterations: int = 100) -> float:
        """Deliverable output power for a given input, by fixed-point iteration.

        With a load-dependent efficiency the relation is implicit; the
        iteration is contractive for physically sensible loss models and
        converges in a handful of steps.  Returns 0.0 when the input cannot
        even cover the no-load loss.
        """
        p_in = abs(input_power)
        if p_in <= 0.0:
            return 0.0
        if self.loss_model is not None and p_in <= self.loss_model.no_load:
            return 0.0
        guess = p_in * self.efficiency_at(p_in)
        for _ in range(max_iterations):
            eta = self.efficiency_at(guess)
            update = p_in * eta
            if abs(update - guess) < tol * max(1.0, abs(guess)):
                return max(0.0, update)
            guess = 0.5 * (guess + update)
        return max(0.0, guess)

    def losses(self, output_power: float) -> float:
        """Dissipation when delivering ``output_power`` (W)."""
        return self.input_for_output(output_power) - abs(output_power)

    def overloaded(self, output_power: float) -> bool:
        return abs(output_power) > self.rated_power

    def load_fraction(self, output_power: float) -> float:
        return abs(output_power) / self.rated_power

    def __repr__(self) -> str:
        return f"PowerConverter(name={self.name!r}, rated={self.rated_power:g} W)"


class Rectifier(PowerConverter):
    """AC to DC conversion with a displacement power factor."""

    def __init__(self, name: str = "rectifier", rated_power: float = 1e6,
                 efficiency: float | EfficiencyCurve | None = 0.97,
                 loss_model: LossModel | None = None,
                 power_factor: float = 0.95) -> None:
        super().__init__(name, rated_power, efficiency, loss_model)
        if not 0.0 < power_factor <= 1.0:
            raise ValueError("power factor must lie in (0, 1]")
        self.power_factor = power_factor

    def ac_current(self, dc_power: float, ac_voltage: float) -> float:
        """RMS AC line current needed for a given DC output (A)."""
        if ac_voltage <= 0.0:
            raise ValueError("AC voltage must be positive")
        p_in = self.input_for_output(dc_power)
        return p_in / (ac_voltage * self.power_factor)


class Inverter(PowerConverter):
    """DC to AC conversion with an output frequency and modulation limit."""

    def __init__(self, name: str = "inverter", rated_power: float = 1e6,
                 efficiency: float | EfficiencyCurve | None = 0.96,
                 loss_model: LossModel | None = None,
                 frequency: float = 50.0, modulation_limit: float = 1.15) -> None:
        super().__init__(name, rated_power, efficiency, loss_model)
        self.frequency = frequency
        self.modulation_limit = modulation_limit

    def max_ac_voltage(self, dc_link_voltage: float) -> float:
        """Peak achievable RMS line voltage with space-vector modulation."""
        return dc_link_voltage * self.modulation_limit / (2.0 * math.sqrt(2.0)) * math.sqrt(3.0)


class DCDCConverter(PowerConverter):
    """DC-DC conversion with a bounded voltage ratio."""

    def __init__(self, name: str = "dcdc", rated_power: float = 1e5,
                 efficiency: float | EfficiencyCurve | None = 0.98,
                 loss_model: LossModel | None = None,
                 ratio_limits: tuple[float, float] = (0.1, 10.0)) -> None:
        super().__init__(name, rated_power, efficiency, loss_model)
        self.ratio_limits = ratio_limits

    def output_voltage(self, input_voltage: float, ratio: float) -> float:
        lo, hi = self.ratio_limits
        return input_voltage * min(hi, max(lo, ratio))

    def output_current(self, input_voltage: float, input_current: float,
                       ratio: float) -> float:
        v_out = self.output_voltage(input_voltage, ratio)
        if v_out <= 0.0:
            return 0.0
        p_in = input_voltage * input_current
        return self.output_for_input(p_in) / v_out


@dataclass(slots=True)
class Battery:
    """An equivalent-circuit battery with coulomb counting.

    The open-circuit voltage varies linearly between ``ocv_empty`` and
    ``ocv_full`` across the state of charge.  Internal resistance produces
    round-trip loss, so charging and discharging the same energy does not
    return the same energy -- which is the point of modelling it at all.
    """

    capacity: float = 3600.0 * 100.0     # C (coulombs); 100 Ah default
    nominal_voltage: float = 400.0
    ocv_full: float = 420.0
    ocv_empty: float = 340.0
    internal_resistance: float = 0.05
    soc: float = 0.5
    max_current: float = 200.0
    name: str = "battery"

    def __post_init__(self) -> None:
        if self.capacity <= 0.0:
            raise ValueError("capacity must be positive")
        if self.internal_resistance < 0.0:
            raise ValueError("internal resistance must be non-negative")
        if not 0.0 <= self.soc <= 1.0:
            raise ValueError("state of charge must lie in 0..1")
        if self.ocv_full <= self.ocv_empty:
            raise ValueError("full-charge OCV must exceed empty-charge OCV")

    @property
    def open_circuit_voltage(self) -> float:
        return self.ocv_empty + (self.ocv_full - self.ocv_empty) * self.soc

    def terminal_voltage(self, current: float) -> float:
        """Terminal voltage; ``current`` positive on discharge (V)."""
        return self.open_circuit_voltage - current * self.internal_resistance

    def power(self, current: float) -> float:
        """Terminal power delivered (W); negative when charging."""
        return self.terminal_voltage(current) * current

    def losses(self, current: float) -> float:
        """Internal I^2 R dissipation (W)."""
        return current * current * self.internal_resistance

    def stored_energy(self) -> float:
        """Energy retrievable at the open-circuit voltage (J).

        This is an idealised figure: the energy actually delivered is lower by
        the internal resistance loss at the discharge rate used.
        """
        return self.soc * self.capacity * self.open_circuit_voltage

    def max_discharge_power(self) -> float:
        """Power at the current limit (W)."""
        return self.terminal_voltage(self.max_current) * self.max_current

    def step(self, current: float, dt: float) -> float:
        """Advance the state of charge; returns the *actual* current used.

        Current is clamped to the rating and to the available charge, so a
        request that would over-discharge the pack is honoured only as far as
        the pack allows.
        """
        i = min(self.max_current, max(-self.max_current, current))
        charge = i * dt
        available = self.soc * self.capacity
        headroom = (1.0 - self.soc) * self.capacity
        if charge > available:
            charge = available
            i = charge / dt if dt > 0.0 else 0.0
        elif -charge > headroom:
            charge = -headroom
            i = charge / dt if dt > 0.0 else 0.0
        self.soc = min(1.0, max(0.0, self.soc - charge / self.capacity))
        return i

    def round_trip_efficiency(self, current: float) -> float:
        """Round-trip efficiency at a symmetric charge/discharge current."""
        v_oc = self.open_circuit_voltage
        v_dis = v_oc - current * self.internal_resistance
        v_chg = v_oc + current * self.internal_resistance
        if v_chg <= 0.0 or v_dis <= 0.0:
            return 0.0
        return v_dis / v_chg
