"""Electrical resistance models with temperature dependence.

The central object is :class:`Resistor`, which can be defined either
abstractly (a reference resistance plus a temperature coefficient) or
physically (a material plus a geometry, from which resistance is computed).
The physical route is preferred because it keeps the electrical and thermal
models consistent: the same object knows its own mass and surface area.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any

from ..core import units as U
from ..materials.material import Material


@dataclass(slots=True)
class Geometry:
    """Conductor geometry used to derive resistance and heat-transfer area.

    Parameters
    ----------
    length:
        Conduction path length (m).
    area:
        Cross-sectional area normal to the current (m^2).
    surface_area:
        External area available for heat transfer (m^2).  Defaults to the
        lateral area of an equivalent cylinder.
    """

    length: float
    area: float
    surface_area: float | None = None

    def __post_init__(self) -> None:
        if self.length <= 0.0:
            raise ValueError("length must be positive")
        if self.area <= 0.0:
            raise ValueError("cross-sectional area must be positive")
        if self.surface_area is None:
            radius = math.sqrt(self.area / math.pi)
            self.surface_area = 2.0 * math.pi * radius * self.length
        if self.surface_area <= 0.0:
            raise ValueError("surface area must be positive")

    @property
    def volume(self) -> float:
        return self.length * self.area

    @classmethod
    def wire(cls, length: float, diameter: float) -> "Geometry":
        """Round wire of the given ``length`` and ``diameter`` (m)."""
        if diameter <= 0.0:
            raise ValueError("diameter must be positive")
        area = math.pi * (diameter / 2.0) ** 2
        return cls(length, area, math.pi * diameter * length)

    @classmethod
    def strip(cls, length: float, width: float, thickness: float) -> "Geometry":
        """Rectangular strip conductor."""
        if width <= 0.0 or thickness <= 0.0:
            raise ValueError("width and thickness must be positive")
        return cls(length, width * thickness,
                   2.0 * (width + thickness) * length)


@dataclass(slots=True)
class Resistor:
    """A resistance whose value varies with temperature.

    Either supply ``resistance`` (ohm at ``t_ref``) with ``alpha``, or supply
    ``material`` and ``geometry`` and let the resistance be derived from
    resistivity.  Supplying both raises :class:`ValueError`, because the two
    definitions would silently disagree.
    """

    name: str = "resistor"
    resistance: float | None = None
    alpha: float = 0.0
    t_ref: float = 293.15
    material: Material | None = None
    geometry: Geometry | None = None
    minimum: float = 1e-9

    def __post_init__(self) -> None:
        physical = self.material is not None and self.geometry is not None
        abstract = self.resistance is not None
        if physical and abstract:
            raise ValueError(
                f"{self.name}: give either resistance+alpha or material+geometry, not both"
            )
        if not physical and not abstract:
            raise ValueError(
                f"{self.name}: specify resistance, or material and geometry"
            )
        if (self.material is None) != (self.geometry is None) and not abstract:
            raise ValueError(f"{self.name}: material and geometry must be given together")
        if abstract and self.resistance is not None and self.resistance < 0.0:
            raise ValueError(f"{self.name}: resistance must be non-negative")

    @property
    def is_physical(self) -> bool:
        return self.material is not None and self.geometry is not None

    def value(self, temperature: float = U.T_STANDARD) -> float:
        """Resistance at ``temperature`` (ohm)."""
        if self.is_physical:
            assert self.material is not None and self.geometry is not None
            rho = self.material.rho_e(temperature)
            r = rho * self.geometry.length / self.geometry.area
        else:
            assert self.resistance is not None
            r = self.resistance * (1.0 + self.alpha * (temperature - self.t_ref))
        return max(self.minimum, r)

    def conductance(self, temperature: float = U.T_STANDARD) -> float:
        return 1.0 / self.value(temperature)

    def mass(self) -> float:
        """Conductor mass (kg); zero for an abstract resistor."""
        if self.is_physical:
            assert self.material is not None and self.geometry is not None
            return self.material.density * self.geometry.volume
        return 0.0

    def heat_capacity(self, temperature: float = U.T_STANDARD) -> float:
        """Thermal capacitance m*cp (J/K); zero for an abstract resistor."""
        if self.is_physical:
            assert self.material is not None
            return self.mass() * self.material.cp(temperature)
        return 0.0

    def dissipation(self, current: float, temperature: float = U.T_STANDARD) -> float:
        """Joule heating I^2 R (W)."""
        return current * current * self.value(temperature)

    def voltage_drop(self, current: float, temperature: float = U.T_STANDARD) -> float:
        return current * self.value(temperature)

    def current_for(self, voltage: float, temperature: float = U.T_STANDARD) -> float:
        return voltage / self.value(temperature)

    def temperature_for_resistance(self, resistance: float,
                                   bracket: tuple[float, float] = (1.0, 3000.0),
                                   tol: float = 1e-9) -> float:
        """Invert ``value(T) = resistance`` by bisection.

        Raises :class:`ValueError` if the target is not bracketed, which is the
        honest outcome for a non-monotonic or out-of-range property model.
        """
        lo, hi = bracket
        f_lo = self.value(lo) - resistance
        f_hi = self.value(hi) - resistance
        if f_lo * f_hi > 0.0:
            raise ValueError(
                f"{self.name}: resistance {resistance:g} ohm not bracketed on "
                f"[{lo:g}, {hi:g}] K (R spans {self.value(lo):g}..{self.value(hi):g})"
            )
        for _ in range(200):
            mid = 0.5 * (lo + hi)
            f_mid = self.value(mid) - resistance
            if abs(f_mid) < tol or (hi - lo) < tol:
                return mid
            if f_lo * f_mid <= 0.0:
                hi, f_hi = mid, f_mid
            else:
                lo, f_lo = mid, f_mid
        return 0.5 * (lo + hi)  # pragma: no cover - bisection always converges


def series(*resistors: Resistor, temperature: float = U.T_STANDARD) -> float:
    """Total resistance of resistors in series (ohm)."""
    return sum(r.value(temperature) for r in resistors)


def parallel(*resistors: Resistor, temperature: float = U.T_STANDARD) -> float:
    """Total resistance of resistors in parallel (ohm)."""
    conductance = sum(r.conductance(temperature) for r in resistors)
    if conductance <= 0.0:
        return math.inf
    return 1.0 / conductance


def parallel_values(*values: float) -> float:
    """Parallel combination of raw resistance values (ohm)."""
    total = 0.0
    for v in values:
        if v <= 0.0:
            return 0.0
        total += 1.0 / v
    return 1.0 / total if total > 0.0 else math.inf


@dataclass(slots=True)
class ContactResistance:
    """Pressure-dependent electrical contact resistance.

    Uses the standard empirical form ``R = c / F**n`` with ``n`` near 0.5-1.0
    for clean metallic contacts.  Degradation multiplies the coefficient and is
    the hook used by the fault model to simulate a loosening joint.
    """

    coefficient: float = 1e-4
    force: float = 100.0
    exponent: float = 0.7
    degradation: float = 1.0

    def value(self, temperature: float = U.T_STANDARD) -> float:
        force = max(self.force, 1e-6)
        return self.degradation * self.coefficient / force ** self.exponent
