"""Electrical power: DC, single-phase AC, three-phase and energy integration."""
from __future__ import annotations

import cmath
import math
from dataclasses import dataclass
from typing import Iterable, Sequence

import numpy as np

SQRT3 = math.sqrt(3.0)


def dc_power(voltage: float, current: float) -> float:
    """``P = V I`` (W)."""
    return voltage * current


def resistive_power(current: float, resistance: float) -> float:
    """``P = I^2 R`` (W)."""
    return current * current * resistance


def power_from_voltage(voltage: float, resistance: float) -> float:
    """``P = V^2 / R`` (W)."""
    if resistance <= 0.0:
        raise ValueError("resistance must be positive")
    return voltage * voltage / resistance


@dataclass(frozen=True, slots=True)
class ACPower:
    """The complete power triangle for an AC circuit.

    ``real`` is in watts, ``reactive`` in var, ``apparent`` in VA.  The sign
    convention is generator-positive: a lagging (inductive) load has positive
    reactive power.
    """

    real: float
    reactive: float

    @property
    def apparent(self) -> float:
        return math.hypot(self.real, self.reactive)

    @property
    def power_factor(self) -> float:
        s = self.apparent
        return self.real / s if s > 0.0 else 1.0

    @property
    def phase_angle(self) -> float:
        """Angle between voltage and current (rad), positive for lagging."""
        return math.atan2(self.reactive, self.real)

    @property
    def is_lagging(self) -> bool:
        return self.reactive > 0.0

    def as_complex(self) -> complex:
        return complex(self.real, self.reactive)

    @classmethod
    def from_vi(cls, voltage: float, current: float,
                power_factor: float = 1.0, lagging: bool = True) -> "ACPower":
        """Build from RMS voltage, RMS current and power factor."""
        pf = min(1.0, max(-1.0, power_factor))
        apparent = voltage * current
        real = apparent * pf
        reactive = apparent * math.sqrt(max(0.0, 1.0 - pf * pf))
        return cls(real, reactive if lagging else -reactive)

    @classmethod
    def from_impedance(cls, voltage: float, impedance: complex) -> "ACPower":
        """Power drawn by ``impedance`` at RMS ``voltage``."""
        magnitude = abs(impedance)
        if magnitude == 0.0:
            raise ValueError("impedance magnitude must be non-zero")
        current = voltage / magnitude
        apparent = voltage * current
        angle = cmath.phase(impedance)
        return cls(apparent * math.cos(angle), apparent * math.sin(angle))

    def __add__(self, other: "ACPower") -> "ACPower":
        return ACPower(self.real + other.real, self.reactive + other.reactive)


def three_phase_power(line_voltage: float, line_current: float,
                      power_factor: float = 1.0) -> float:
    """Balanced three-phase real power ``sqrt(3) V_LL I_L cos(phi)`` (W)."""
    return SQRT3 * line_voltage * line_current * power_factor


def three_phase_current(power: float, line_voltage: float,
                        power_factor: float = 1.0) -> float:
    """Line current required to deliver ``power`` (A)."""
    denominator = SQRT3 * line_voltage * power_factor
    if denominator <= 0.0:
        raise ValueError("line voltage and power factor must be positive")
    return power / denominator


def power_factor_correction(real_power: float, pf_now: float,
                            pf_target: float, frequency: float,
                            voltage: float) -> float:
    """Capacitance (F) needed to raise the power factor to ``pf_target``.

    Returns zero if the target is already met, rather than a negative
    capacitance, since over-correction is a different design decision.
    """
    for pf in (pf_now, pf_target):
        if not 0.0 < pf <= 1.0:
            raise ValueError("power factors must lie in (0, 1]")
    if pf_target <= pf_now:
        return 0.0
    q_now = real_power * math.tan(math.acos(pf_now))
    q_target = real_power * math.tan(math.acos(pf_target))
    q_c = q_now - q_target
    denominator = 2.0 * math.pi * frequency * voltage * voltage
    if denominator <= 0.0:
        raise ValueError("frequency and voltage must be positive")
    return q_c / denominator


def instantaneous_power(voltage_samples: Sequence[float],
                        current_samples: Sequence[float]) -> np.ndarray:
    """Element-wise ``v(t) * i(t)`` (W)."""
    v = np.asarray(voltage_samples, dtype=float)
    i = np.asarray(current_samples, dtype=float)
    if v.shape != i.shape:
        raise ValueError("voltage and current sample arrays must have the same shape")
    return v * i


def average_power(voltage_samples: Sequence[float],
                  current_samples: Sequence[float]) -> float:
    """Mean of the instantaneous power over the sample window (W)."""
    p = instantaneous_power(voltage_samples, current_samples)
    return float(np.mean(p)) if p.size else 0.0


def energy(power_samples: Sequence[float], dt: float) -> float:
    """Trapezoidal integral of a power series (J)."""
    p = np.asarray(power_samples, dtype=float)
    if p.size < 2:
        return float(p.sum() * dt) if p.size else 0.0
    return float(np.trapezoid(p, dx=dt))


def energy_cost(joules: float, tariff_per_kwh: float) -> float:
    """Cost of ``joules`` at ``tariff_per_kwh`` in the tariff's currency."""
    return joules / 3.6e6 * tariff_per_kwh


@dataclass(slots=True)
class PowerBudget:
    """A tally of power flowing into and out of an electrical node."""

    supplied: float = 0.0
    delivered: float = 0.0
    losses: float = 0.0

    def add_supply(self, watts: float) -> None:
        self.supplied += watts

    def add_delivery(self, watts: float) -> None:
        self.delivered += watts

    def add_loss(self, watts: float) -> None:
        self.losses += watts

    @property
    def residual(self) -> float:
        """``supplied - delivered - losses``; should be ~0 for a closed node."""
        return self.supplied - self.delivered - self.losses

    @property
    def efficiency(self) -> float:
        return self.delivered / self.supplied if self.supplied > 0.0 else 0.0

    def as_dict(self) -> dict[str, float]:
        return {"supplied": self.supplied, "delivered": self.delivered,
                "losses": self.losses, "residual": self.residual,
                "efficiency": self.efficiency}
