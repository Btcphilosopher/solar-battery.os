"""Current calculation: Ohm's law, resistive networks and RL/RC transients."""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Iterable, Mapping, Sequence

import numpy as np

from ..core import units as U
from .resistance import Resistor, parallel_values


def ohm_current(voltage: float, resistance: float) -> float:
    """``I = V / R`` with a guard against division by zero."""
    if resistance <= 0.0:
        raise ValueError("resistance must be positive to compute current")
    return voltage / resistance


def series_current(voltage: float, resistances: Sequence[float],
                   source_resistance: float = 0.0) -> float:
    """Current through a series string driven by ``voltage``."""
    total = sum(resistances) + source_resistance
    if total <= 0.0:
        raise ValueError("total series resistance must be positive")
    return voltage / total


@dataclass(slots=True)
class Branch:
    """One branch of a resistive network."""

    node_a: str
    node_b: str
    resistance: float
    source_voltage: float = 0.0
    name: str = ""

    def __post_init__(self) -> None:
        if self.resistance <= 0.0:
            raise ValueError(f"branch {self.name or '?'}: resistance must be positive")


class ResistiveNetwork:
    """Modified nodal analysis for a DC resistive network.

    Each branch is a resistance optionally in series with an ideal voltage
    source.  One node must be declared as ground.  The solution returns node
    potentials and branch currents, and is exact for a linear network.
    """

    def __init__(self, ground: str = "gnd") -> None:
        self.ground = ground
        self.branches: list[Branch] = []
        self.fixed: dict[str, float] = {ground: 0.0}
        self.injections: dict[str, float] = {}

    def add_branch(self, node_a: str, node_b: str, resistance: float,
                   source_voltage: float = 0.0, name: str = "") -> Branch:
        branch = Branch(node_a, node_b, resistance, source_voltage, name)
        self.branches.append(branch)
        return branch

    def add_resistor(self, node_a: str, node_b: str, resistor: Resistor,
                     temperature: float = U.T_STANDARD) -> Branch:
        return self.add_branch(node_a, node_b, resistor.value(temperature),
                               name=resistor.name)

    def set_voltage(self, node: str, voltage: float) -> None:
        """Pin a node to a fixed potential (an ideal source to ground)."""
        self.fixed[node] = float(voltage)

    def inject_current(self, node: str, current: float) -> None:
        """Inject ``current`` amperes into ``node`` (positive = into node)."""
        self.injections[node] = self.injections.get(node, 0.0) + float(current)

    @property
    def nodes(self) -> list[str]:
        names: list[str] = []
        for b in self.branches:
            for n in (b.node_a, b.node_b):
                if n not in names:
                    names.append(n)
        for n in list(self.fixed) + list(self.injections):
            if n not in names:
                names.append(n)
        return names

    def solve(self) -> dict[str, float]:
        """Return node potentials in volts."""
        nodes = self.nodes
        if self.ground not in nodes:
            raise ValueError(f"ground node {self.ground!r} is not present in the network")
        index = {n: i for i, n in enumerate(nodes)}
        n = len(nodes)
        G = np.zeros((n, n))
        rhs = np.zeros(n)
        for b in self.branches:
            ia, ib = index[b.node_a], index[b.node_b]
            g = 1.0 / b.resistance
            G[ia, ia] += g
            G[ib, ib] += g
            G[ia, ib] -= g
            G[ib, ia] -= g
            if b.source_voltage:
                # source drives current from node_b to node_a through R
                rhs[ia] += b.source_voltage * g
                rhs[ib] -= b.source_voltage * g
        for node, current in self.injections.items():
            rhs[index[node]] += current
        for node, voltage in self.fixed.items():
            i = index[node]
            G[i, :] = 0.0
            G[i, i] = 1.0
            rhs[i] = voltage
        try:
            solution = np.linalg.solve(G, rhs)
        except np.linalg.LinAlgError as exc:
            raise ValueError(
                "network is singular: check that every node has a path to ground"
            ) from exc
        return {node: float(solution[index[node]]) for node in nodes}

    def branch_currents(self, potentials: Mapping[str, float] | None = None
                        ) -> dict[str, float]:
        """Current through each branch, positive from ``node_a`` to ``node_b``."""
        v = potentials if potentials is not None else self.solve()
        out: dict[str, float] = {}
        for i, b in enumerate(self.branches):
            key = b.name or f"branch{i}"
            out[key] = (v[b.node_a] - v[b.node_b] + b.source_voltage) / b.resistance
        return out

    def power_dissipated(self, potentials: Mapping[str, float] | None = None) -> float:
        """Total I^2 R dissipation across all branches (W)."""
        v = potentials if potentials is not None else self.solve()
        total = 0.0
        for b in self.branches:
            current = (v[b.node_a] - v[b.node_b] + b.source_voltage) / b.resistance
            total += current * current * b.resistance
        return total


@dataclass(slots=True)
class RLCircuit:
    """First-order series RL circuit: ``L di/dt + R i = V``.

    Provides both the analytic solution (constant ``V`` and ``R``) and a
    derivative suitable for numerical integration when they vary.
    """

    resistance: float
    inductance: float

    def __post_init__(self) -> None:
        if self.resistance <= 0.0:
            raise ValueError("resistance must be positive")
        if self.inductance <= 0.0:
            raise ValueError("inductance must be positive")

    @property
    def time_constant(self) -> float:
        return self.inductance / self.resistance

    def steady_current(self, voltage: float) -> float:
        return voltage / self.resistance

    def current(self, t: float, voltage: float, initial: float = 0.0) -> float:
        """Analytic current at time ``t`` for a step applied at ``t=0``."""
        final = self.steady_current(voltage)
        return final + (initial - final) * math.exp(-t / self.time_constant)

    def derivative(self, current: float, voltage: float) -> float:
        """``di/dt`` in A/s."""
        return (voltage - current * self.resistance) / self.inductance

    def stored_energy(self, current: float) -> float:
        """Magnetic energy ``0.5 L i^2`` (J)."""
        return 0.5 * self.inductance * current * current

    def impedance(self, frequency: float) -> complex:
        return complex(self.resistance, 2.0 * math.pi * frequency * self.inductance)


@dataclass(slots=True)
class RCCircuit:
    """First-order series RC circuit."""

    resistance: float
    capacitance: float

    def __post_init__(self) -> None:
        if self.resistance <= 0.0 or self.capacitance <= 0.0:
            raise ValueError("resistance and capacitance must be positive")

    @property
    def time_constant(self) -> float:
        return self.resistance * self.capacitance

    def voltage(self, t: float, supply: float, initial: float = 0.0) -> float:
        return supply + (initial - supply) * math.exp(-t / self.time_constant)

    def derivative(self, voltage: float, supply: float) -> float:
        return (supply - voltage) / self.time_constant

    def stored_energy(self, voltage: float) -> float:
        return 0.5 * self.capacitance * voltage * voltage

    def impedance(self, frequency: float) -> complex:
        if frequency <= 0.0:
            return complex(self.resistance, -math.inf)
        return complex(self.resistance,
                       -1.0 / (2.0 * math.pi * frequency * self.capacitance))


@dataclass(slots=True)
class CurrentLimiter:
    """Hard current limit with optional foldback.

    ``foldback`` reduces the allowed current in proportion to how far the
    demand exceeds the limit, mimicking a supply that backs off rather than
    clipping.  ``0`` gives a plain clamp.
    """

    limit: float
    foldback: float = 0.0

    def __post_init__(self) -> None:
        if self.limit <= 0.0:
            raise ValueError("current limit must be positive")
        if not 0.0 <= self.foldback <= 1.0:
            raise ValueError("foldback must be in 0..1")

    def apply(self, demand: float) -> float:
        magnitude = abs(demand)
        if magnitude <= self.limit:
            return demand
        excess = (magnitude - self.limit) / self.limit
        allowed = self.limit * (1.0 - self.foldback * min(1.0, excess))
        return math.copysign(max(0.0, allowed), demand)

    def is_limiting(self, demand: float) -> bool:
        return abs(demand) > self.limit


def rms(samples: Iterable[float]) -> float:
    """Root-mean-square of a sample sequence."""
    values = np.asarray(list(samples), dtype=float)
    if values.size == 0:
        return 0.0
    return float(np.sqrt(np.mean(values ** 2)))


def current_density(current: float, area: float) -> float:
    """Current density in A/m^2."""
    if area <= 0.0:
        raise ValueError("area must be positive")
    return current / area
