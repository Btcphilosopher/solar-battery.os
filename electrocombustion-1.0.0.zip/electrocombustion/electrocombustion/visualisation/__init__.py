"""Visualisation: dependency-free text output and optional matplotlib plots."""
from .text import (
    bar, energy_waterfall, format_energy, format_power, ledger_report,
    operating_map_text, severity_timeline, sparkline, table,
)
from . import plots

__all__ = [
    "bar", "energy_waterfall", "format_energy", "format_power",
    "ledger_report", "operating_map_text", "severity_timeline", "sparkline",
    "table", "plots",
]
