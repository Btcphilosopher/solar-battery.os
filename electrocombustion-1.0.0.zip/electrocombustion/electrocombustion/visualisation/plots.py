"""Optional matplotlib plotting.

Matplotlib is not a hard dependency.  Importing this module without it raises
a clear error rather than failing deep inside a plotting call, and
:func:`available` lets calling code branch before it tries.
"""
from __future__ import annotations

from typing import Any, Mapping, Sequence


def available() -> bool:
    """Whether matplotlib can be imported."""
    try:  # pragma: no cover - depends on the environment
        import matplotlib  # noqa: F401
        return True
    except ImportError:  # pragma: no cover
        return False


def _pyplot():
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        return plt
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError(
            "matplotlib is not installed; use electrocombustion.visualisation."
            "text for dependency-free output"
        ) from exc


def plot_series(times: Sequence[float], series: Mapping[str, Sequence[float]],
                path: str, title: str = "", ylabel: str = "") -> str:
    """Line plot of one or more time series; returns the saved path."""
    plt = _pyplot()
    figure, axis = plt.subplots(figsize=(9, 5))
    for name, values in series.items():
        axis.plot(times[: len(values)], values, label=name, linewidth=1.4)
    axis.set_xlabel("time (s)")
    axis.set_ylabel(ylabel)
    if title:
        axis.set_title(title)
    if len(series) > 1:
        axis.legend(loc="best", fontsize=8)
    axis.grid(True, alpha=0.3)
    figure.tight_layout()
    figure.savefig(path, dpi=120)
    plt.close(figure)
    return path


def plot_waterfall(rows: Sequence[tuple[str, float]], path: str,
                   title: str = "energy waterfall") -> str:
    """Horizontal bar chart of the energy waterfall."""
    plt = _pyplot()
    labels = [name for name, _ in rows]
    values = [value for _, value in rows]
    figure, axis = plt.subplots(figsize=(9, 0.5 * len(rows) + 2))
    axis.barh(labels, values, color="#C9A84C")
    axis.set_xlabel("energy (J)")
    axis.set_title(title)
    axis.grid(True, axis="x", alpha=0.3)
    figure.tight_layout()
    figure.savefig(path, dpi=120)
    plt.close(figure)
    return path


def plot_operating_map(xs: Sequence[float], ys: Sequence[float], grid: Any,
                       path: str, title: str = "operating map",
                       xlabel: str = "", ylabel: str = "",
                       levels: int = 20) -> str:
    """Filled contour plot of a two-dimensional sweep."""
    plt = _pyplot()
    figure, axis = plt.subplots(figsize=(8, 6))
    contour = axis.contourf(xs, ys, grid, levels=levels, cmap="viridis")
    figure.colorbar(contour, ax=axis)
    axis.set_xlabel(xlabel)
    axis.set_ylabel(ylabel)
    axis.set_title(title)
    figure.tight_layout()
    figure.savefig(path, dpi=120)
    plt.close(figure)
    return path


def plot_distribution(values: Sequence[float], path: str,
                      title: str = "distribution", bins: int = 40,
                      percentiles: Sequence[float] = (10, 50, 90)) -> str:
    """Histogram with percentile markers, for Monte Carlo output."""
    plt = _pyplot()
    import numpy as np
    figure, axis = plt.subplots(figsize=(8, 5))
    axis.hist(values, bins=bins, color="#00E5FF", alpha=0.75,
              edgecolor="#101010")
    for q in percentiles:
        marker = float(np.percentile(values, q))
        axis.axvline(marker, linestyle="--", linewidth=1.2, color="#C9A84C")
        axis.text(marker, axis.get_ylim()[1] * 0.95, f"P{q:g}",
                  rotation=90, va="top", fontsize=8)
    axis.set_title(title)
    axis.grid(True, alpha=0.3)
    figure.tight_layout()
    figure.savefig(path, dpi=120)
    plt.close(figure)
    return path
