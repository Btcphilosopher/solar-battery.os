"""Dependency-free text visualisation.

Everything here works with nothing but the standard library, so a headless
build server can still render an energy waterfall.  The matplotlib helpers
live in :mod:`.plots` and are imported lazily.
"""
from __future__ import annotations

import math
from typing import Iterable, Mapping, Sequence

BLOCKS = " ▁▂▃▄▅▆▇█"


def sparkline(values: Sequence[float], width: int = 40) -> str:
    """A one-line sparkline of a numeric series."""
    data = [v for v in values if math.isfinite(v)]
    if not data:
        return ""
    if len(data) > width:
        stride = len(data) / width
        data = [data[int(i * stride)] for i in range(width)]
    low, high = min(data), max(data)
    span = high - low
    if span <= 0.0:
        return BLOCKS[4] * len(data)
    return "".join(
        BLOCKS[min(len(BLOCKS) - 1, int((v - low) / span * (len(BLOCKS) - 1)))]
        for v in data
    )


def bar(value: float, maximum: float, width: int = 30,
        fill: str = "█", empty: str = "·") -> str:
    """A horizontal bar scaled to ``maximum``."""
    if maximum <= 0.0:
        return empty * width
    filled = int(round(min(1.0, max(0.0, value / maximum)) * width))
    return fill * filled + empty * (width - filled)


def format_energy(joules: float) -> str:
    """Human-readable energy with an appropriate prefix."""
    magnitude = abs(joules)
    for threshold, suffix, divisor in (
            (1e9, "GJ", 1e9), (1e6, "MJ", 1e6), (1e3, "kJ", 1e3)):
        if magnitude >= threshold:
            return f"{joules / divisor:.4g} {suffix}"
    return f"{joules:.4g} J"


def format_power(watts: float) -> str:
    magnitude = abs(watts)
    for threshold, suffix, divisor in (
            (1e9, "GW", 1e9), (1e6, "MW", 1e6), (1e3, "kW", 1e3)):
        if magnitude >= threshold:
            return f"{watts / divisor:.4g} {suffix}"
    return f"{watts:.4g} W"


def energy_waterfall(rows: Sequence[tuple[str, float]], width: int = 34,
                     title: str = "energy waterfall") -> str:
    """Render an energy waterfall as aligned text.

    Percentages are taken against the largest single transfer, which is
    normally the total input, so the chart reads as "what fraction of the
    energy went where".
    """
    if not rows:
        return f"{title}: (no energy recorded)"
    peak = max(abs(v) for _, v in rows) or 1.0
    label_width = max(len(name) for name, _ in rows)
    lines = [title, "-" * (label_width + width + 22)]
    for name, value in rows:
        lines.append(
            f"{name:<{label_width}}  {bar(abs(value), peak, width)}  "
            f"{format_energy(value):>10}  {value / peak * 100:5.1f} %"
        )
    return "\n".join(lines)


def ledger_report(ledger, title: str = "energy ledger") -> str:
    """Format an :class:`~electrocombustion.core.state.EnergyLedger`."""
    rows = list(ledger.waterfall())
    body = energy_waterfall(rows, title=title)
    delivered = ledger.labelled_total("load")
    total_in = ledger.total_input
    efficiency = delivered / total_in * 100.0 if total_in > 0.0 else 0.0
    footer = (
        f"\n  input      {format_energy(total_in):>12}"
        f"\n  delivered  {format_energy(delivered):>12}"
        f"\n  losses     {format_energy(ledger.total_losses):>12}"
        f"\n  stored     {format_energy(ledger.total_stored):>12}"
        f"\n  efficiency {efficiency:>11.2f} %"
    )
    return body + footer


def table(rows: Sequence[Mapping[str, object]],
          columns: Sequence[str] | None = None,
          precision: int = 4, limit: int = 30) -> str:
    """Render a list of dictionaries as a fixed-width table."""
    if not rows:
        return "(no rows)"
    keys = list(columns) if columns else list(rows[0].keys())
    shown = rows[:limit]

    def render(value: object) -> str:
        if isinstance(value, float):
            return f"{value:.{precision}g}"
        return str(value)

    widths = {k: max(len(k), *(len(render(r.get(k, ""))) for r in shown))
              for k in keys}
    header = "  ".join(k.ljust(widths[k]) for k in keys)
    divider = "  ".join("-" * widths[k] for k in keys)
    lines = [header, divider]
    for row in shown:
        lines.append("  ".join(render(row.get(k, "")).ljust(widths[k]) for k in keys))
    if len(rows) > limit:
        lines.append(f"... {len(rows) - limit} more rows")
    return "\n".join(lines)


def operating_map_text(xs: Sequence[float], ys: Sequence[float],
                       grid: Sequence[Sequence[float]],
                       levels: str = " .:-=+*#%@") -> str:
    """Render a 2D operating map as an ASCII contour plot.

    ``nan`` cells are drawn as ``?`` so gaps from failed evaluations stay
    visible instead of blending into the surface.
    """
    finite = [v for row in grid for v in row if isinstance(v, float) and math.isfinite(v)]
    if not finite:
        return "(no finite values in map)"
    low, high = min(finite), max(finite)
    span = high - low or 1.0
    lines = []
    for j in range(len(ys) - 1, -1, -1):
        cells = []
        for i in range(len(xs)):
            value = grid[j][i]
            if not (isinstance(value, float) and math.isfinite(value)):
                cells.append("?")
                continue
            index = int((value - low) / span * (len(levels) - 1))
            cells.append(levels[min(len(levels) - 1, max(0, index))])
        lines.append(f"{ys[j]:10.4g} |" + "".join(cells))
    lines.append(" " * 11 + "+" + "-" * len(xs))
    lines.append(f"{'':11} {xs[0]:.4g} .. {xs[-1]:.4g}")
    lines.append(f"scale: {low:.4g} [{levels.strip()}] {high:.4g}")
    return "\n".join(lines)


def severity_timeline(entries: Sequence[tuple[float, str]]) -> str:
    """Render a severity timeline as text."""
    if not entries:
        return "(no state changes recorded)"
    return "\n".join(f"t={t:10.4g} s  ->  {state}" for t, state in entries)
