"""Parameter sweeps and operating-map generation."""
from __future__ import annotations

import itertools
import math
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable, Iterator, Mapping, Sequence

import numpy as np


@dataclass(slots=True)
class Parameter:
    """One swept dimension."""

    name: str
    values: Sequence[float]

    def __post_init__(self) -> None:
        if len(self.values) == 0:
            raise ValueError(f"parameter {self.name}: no values to sweep")

    @classmethod
    def linear(cls, name: str, lower: float, upper: float,
               count: int) -> "Parameter":
        if count < 1:
            raise ValueError("count must be at least 1")
        return cls(name, list(np.linspace(lower, upper, count)))

    @classmethod
    def logarithmic(cls, name: str, lower: float, upper: float,
                    count: int) -> "Parameter":
        if lower <= 0.0 or upper <= 0.0:
            raise ValueError("logarithmic sweeps need positive bounds")
        return cls(name, list(np.logspace(math.log10(lower), math.log10(upper),
                                          count)))

    def __len__(self) -> int:
        return len(self.values)


@dataclass(slots=True)
class SweepResult:
    """Tabular result of a sweep."""

    parameters: list[str]
    rows: list[dict[str, float]] = field(default_factory=list)
    failures: list[dict[str, Any]] = field(default_factory=list)

    def __len__(self) -> int:
        return len(self.rows)

    def column(self, key: str) -> list[float]:
        return [row[key] for row in self.rows if key in row]

    def best(self, key: str, maximise: bool = True) -> dict[str, float]:
        """Row with the extreme value of ``key``."""
        if not self.rows:
            raise ValueError("sweep produced no rows")
        candidates = [r for r in self.rows if key in r]
        if not candidates:
            raise KeyError(f"no row contains {key!r}")
        return (max(candidates, key=lambda r: r[key]) if maximise
                else min(candidates, key=lambda r: r[key]))

    def to_grid(self, x: str, y: str, value: str) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Reshape into ``(x_values, y_values, Z)`` for contour plotting.

        Missing combinations become ``nan`` rather than being silently filled,
        so a partially failed sweep is visible instead of misleading.
        """
        xs = sorted({row[x] for row in self.rows})
        ys = sorted({row[y] for row in self.rows})
        lookup = {(row[x], row[y]): row.get(value, math.nan) for row in self.rows}
        grid = np.full((len(ys), len(xs)), math.nan)
        for j, yv in enumerate(ys):
            for i, xv in enumerate(xs):
                grid[j, i] = lookup.get((xv, yv), math.nan)
        return np.asarray(xs), np.asarray(ys), grid

    def to_csv(self, path: str) -> str:
        """Write the sweep to CSV; returns the path."""
        import csv
        if not self.rows:
            raise ValueError("nothing to write: the sweep produced no rows")
        keys: list[str] = []
        for row in self.rows:
            for k in row:
                if k not in keys:
                    keys.append(k)
        with open(path, "w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=keys)
            writer.writeheader()
            for row in self.rows:
                writer.writerow(row)
        return path

    def summary(self) -> dict[str, Any]:
        return {"points": len(self.rows), "failures": len(self.failures),
                "parameters": list(self.parameters)}


class ParameterSweep:
    """Evaluates a model across a grid or sample of the parameter space.

    ``evaluate`` maps a parameter dictionary to a result dictionary.  Failures
    are captured rather than aborting the sweep, because in a ten-thousand
    point sweep a handful of non-convergent corners is normal and losing the
    other 9 990 points to one exception is not acceptable.
    """

    def __init__(self, evaluate: Callable[[dict[str, float]], Mapping[str, float]],
                 parameters: Sequence[Parameter],
                 base: Mapping[str, float] | None = None) -> None:
        if not parameters:
            raise ValueError("a sweep needs at least one parameter")
        self.evaluate = evaluate
        self.parameters = list(parameters)
        self.base = dict(base or {})

    @property
    def size(self) -> int:
        total = 1
        for parameter in self.parameters:
            total *= len(parameter)
        return total

    def points(self) -> Iterator[dict[str, float]]:
        names = [p.name for p in self.parameters]
        for combination in itertools.product(*(p.values for p in self.parameters)):
            point = dict(self.base)
            point.update(dict(zip(names, combination)))
            yield point

    def run(self, progress: Callable[[int, int], None] | None = None,
            stop_on_error: bool = False) -> SweepResult:
        result = SweepResult([p.name for p in self.parameters])
        total = self.size
        for index, point in enumerate(self.points()):
            try:
                outcome = dict(self.evaluate(dict(point)))
            except Exception as exc:  # noqa: BLE001 - deliberate: record and continue
                result.failures.append({"point": point, "error": repr(exc)})
                if stop_on_error:
                    raise
                continue
            row = dict(point)
            row.update(outcome)
            result.rows.append(row)
            if progress is not None:
                progress(index + 1, total)
        return result

    def latin_hypercube(self, samples: int, seed: int | None = None) -> SweepResult:
        """Sample the space with a Latin hypercube instead of a full grid.

        For more than three dimensions a full grid becomes unaffordable long
        before it becomes informative; LHS gives far better coverage per
        evaluation.
        """
        if samples < 1:
            raise ValueError("samples must be at least 1")
        rng = np.random.default_rng(seed)
        dimensions = len(self.parameters)
        cuts = np.zeros((samples, dimensions))
        for d in range(dimensions):
            permutation = rng.permutation(samples)
            cuts[:, d] = (permutation + rng.random(samples)) / samples
        result = SweepResult([p.name for p in self.parameters])
        for row_index in range(samples):
            point = dict(self.base)
            for d, parameter in enumerate(self.parameters):
                values = np.asarray(parameter.values, dtype=float)
                lo, hi = float(values.min()), float(values.max())
                point[parameter.name] = lo + cuts[row_index, d] * (hi - lo)
            try:
                outcome = dict(self.evaluate(dict(point)))
            except Exception as exc:  # noqa: BLE001
                result.failures.append({"point": point, "error": repr(exc)})
                continue
            row = dict(point)
            row.update(outcome)
            result.rows.append(row)
        return result


def operating_map(evaluate: Callable[[dict[str, float]], Mapping[str, float]],
                  x: Parameter, y: Parameter,
                  base: Mapping[str, float] | None = None) -> SweepResult:
    """Two-dimensional operating map, the standard engine/generator view."""
    return ParameterSweep(evaluate, [x, y], base).run()


def find_optimum(result: SweepResult, key: str, maximise: bool = True,
                 constraints: Mapping[str, tuple[float, float]] | None = None
                 ) -> dict[str, float]:
    """Best point in a completed sweep, subject to optional bounds.

    Raises when no point satisfies the constraints, rather than returning the
    least-bad violating point disguised as an answer.
    """
    rows = result.rows
    if constraints:
        filtered = []
        for row in rows:
            ok = True
            for name, (lo, hi) in constraints.items():
                value = row.get(name)
                if value is None or not lo <= value <= hi:
                    ok = False
                    break
            if ok:
                filtered.append(row)
        rows = filtered
    if not rows:
        raise ValueError("no sweep point satisfies the given constraints")
    return (max(rows, key=lambda r: r.get(key, -math.inf)) if maximise
            else min(rows, key=lambda r: r.get(key, math.inf)))
