"""Monte Carlo uncertainty propagation."""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Callable, Literal, Mapping, Sequence

import numpy as np


@dataclass(slots=True)
class Distribution:
    """A univariate distribution over one uncertain input.

    Supported kinds: ``normal`` (mean, sigma), ``uniform`` (low, high),
    ``lognormal`` (mean and sigma of the underlying normal), ``triangular``
    (low, mode, high) and ``fixed``.  Truncation bounds are applied by
    resampling, which preserves the shape rather than piling probability mass
    onto the bounds the way clipping does.
    """

    name: str
    kind: Literal["normal", "uniform", "lognormal", "triangular", "fixed"] = "normal"
    a: float = 0.0
    b: float = 1.0
    c: float | None = None
    lower: float | None = None
    upper: float | None = None

    def __post_init__(self) -> None:
        if self.kind == "uniform" and self.a > self.b:
            raise ValueError(f"{self.name}: uniform bounds are inverted")
        if self.kind in ("normal", "lognormal") and self.b < 0.0:
            raise ValueError(f"{self.name}: sigma must be non-negative")
        if self.kind == "triangular":
            if self.c is None:
                self.c = 0.5 * (self.a + self.b)
            if not self.a <= self.c <= self.b:
                raise ValueError(f"{self.name}: triangular mode outside bounds")

    def sample(self, rng: np.random.Generator, size: int = 1) -> np.ndarray:
        for _ in range(64):
            values = self._raw(rng, size)
            if self.lower is None and self.upper is None:
                return values
            mask = np.ones(size, dtype=bool)
            if self.lower is not None:
                mask &= values >= self.lower
            if self.upper is not None:
                mask &= values <= self.upper
            if mask.all():
                return values
            replacements = self.sample(rng, int((~mask).sum()))
            values[~mask] = replacements
            return values
        return values  # pragma: no cover - loop always returns

    def _raw(self, rng: np.random.Generator, size: int) -> np.ndarray:
        if self.kind == "normal":
            return rng.normal(self.a, self.b, size)
        if self.kind == "uniform":
            return rng.uniform(self.a, self.b, size)
        if self.kind == "lognormal":
            return rng.lognormal(self.a, self.b, size)
        if self.kind == "triangular":
            assert self.c is not None
            return rng.triangular(self.a, self.c, self.b, size)
        return np.full(size, self.a)

    @property
    def nominal(self) -> float:
        if self.kind in ("normal", "lognormal", "fixed"):
            return self.a if self.kind != "lognormal" else math.exp(self.a)
        if self.kind == "uniform":
            return 0.5 * (self.a + self.b)
        return float(self.c if self.c is not None else 0.5 * (self.a + self.b))


@dataclass(slots=True)
class MonteCarloResult:
    """Samples and summary statistics from a Monte Carlo study."""

    samples: list[dict[str, float]] = field(default_factory=list)
    inputs: list[dict[str, float]] = field(default_factory=list)
    failures: list[dict[str, Any]] = field(default_factory=list)

    def __len__(self) -> int:
        return len(self.samples)

    def values(self, key: str) -> np.ndarray:
        return np.asarray([s[key] for s in self.samples if key in s], dtype=float)

    def percentile(self, key: str, q: float) -> float:
        data = self.values(key)
        if data.size == 0:
            raise KeyError(f"no samples contain {key!r}")
        return float(np.percentile(data, q))

    def statistics(self, key: str) -> dict[str, float]:
        """Mean, standard deviation and the P10/P50/P90 band."""
        data = self.values(key)
        if data.size == 0:
            raise KeyError(f"no samples contain {key!r}")
        return {
            "mean": float(np.mean(data)), "std": float(np.std(data, ddof=1))
            if data.size > 1 else 0.0,
            "min": float(np.min(data)), "max": float(np.max(data)),
            "p10": float(np.percentile(data, 10)),
            "p50": float(np.percentile(data, 50)),
            "p90": float(np.percentile(data, 90)),
            "count": float(data.size),
        }

    def probability(self, key: str, threshold: float,
                    direction: Literal["above", "below"] = "above") -> float:
        """Fraction of samples on one side of ``threshold``."""
        data = self.values(key)
        if data.size == 0:
            raise KeyError(f"no samples contain {key!r}")
        hits = data > threshold if direction == "above" else data < threshold
        return float(np.mean(hits))

    def sensitivity(self, key: str) -> dict[str, float]:
        """Rank correlation between each input and ``key``.

        Spearman rank correlation is used rather than Pearson because the
        model response is usually monotonic but not linear, and rank
        correlation captures that without assuming a functional form.
        """
        target = self.values(key)
        if target.size < 3:
            return {}
        out: dict[str, float] = {}
        for name in (self.inputs[0] if self.inputs else {}):
            column = np.asarray([row[name] for row in self.inputs], dtype=float)
            column = column[: target.size]
            if np.allclose(column, column[0]):
                out[name] = 0.0
                continue
            out[name] = _spearman(column, target)
        return out

    def summary(self, keys: Sequence[str]) -> dict[str, dict[str, float]]:
        return {k: self.statistics(k) for k in keys}


def _rank(values: np.ndarray) -> np.ndarray:
    order = np.argsort(values, kind="mergesort")
    ranks = np.empty_like(order, dtype=float)
    ranks[order] = np.arange(len(values), dtype=float)
    return ranks


def _spearman(x: np.ndarray, y: np.ndarray) -> float:
    rx, ry = _rank(x), _rank(y)
    rx = rx - rx.mean()
    ry = ry - ry.mean()
    denominator = math.sqrt(float((rx ** 2).sum() * (ry ** 2).sum()))
    if denominator == 0.0:
        return 0.0
    return float((rx * ry).sum() / denominator)


class MonteCarlo:
    """Propagates input uncertainty through a model."""

    def __init__(self, evaluate: Callable[[dict[str, float]], Mapping[str, float]],
                 distributions: Sequence[Distribution],
                 base: Mapping[str, float] | None = None,
                 seed: int | None = 0) -> None:
        if not distributions:
            raise ValueError("at least one distribution is required")
        self.evaluate = evaluate
        self.distributions = list(distributions)
        self.base = dict(base or {})
        self.seed = seed

    def run(self, samples: int = 1000,
            progress: Callable[[int, int], None] | None = None
            ) -> MonteCarloResult:
        if samples < 1:
            raise ValueError("samples must be at least 1")
        rng = np.random.default_rng(self.seed)
        draws = {d.name: d.sample(rng, samples) for d in self.distributions}
        result = MonteCarloResult()
        for i in range(samples):
            point = dict(self.base)
            for name, values in draws.items():
                point[name] = float(values[i])
            try:
                outcome = dict(self.evaluate(dict(point)))
            except Exception as exc:  # noqa: BLE001 - record and continue
                result.failures.append({"point": point, "error": repr(exc)})
                continue
            result.inputs.append({d.name: point[d.name] for d in self.distributions})
            result.samples.append(outcome)
            if progress is not None:
                progress(i + 1, samples)
        return result

    def nominal(self) -> dict[str, float]:
        """Evaluate at the nominal (central) values of every distribution."""
        point = dict(self.base)
        for d in self.distributions:
            point[d.name] = d.nominal
        return dict(self.evaluate(point))

    def convergence(self, key: str, samples: int = 1000,
                    checkpoints: int = 10) -> list[tuple[int, float, float]]:
        """Track how the mean and P90 settle as samples accumulate.

        Reporting this is the honest way to justify a sample count: if the
        statistics are still moving at N, N was too small.
        """
        result = self.run(samples)
        data = result.values(key)
        out: list[tuple[int, float, float]] = []
        for i in range(1, checkpoints + 1):
            n = max(2, int(len(data) * i / checkpoints))
            window = data[:n]
            out.append((n, float(np.mean(window)),
                        float(np.percentile(window, 90))))
        return out
