"""Numerical solvers: transient integration and steady-state solution."""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Callable, Literal, Sequence

import numpy as np

try:  # pragma: no cover
    from scipy.integrate import solve_ivp
    from scipy.optimize import root
    _HAVE_SCIPY = True
except ImportError:  # pragma: no cover
    _HAVE_SCIPY = False


Derivative = Callable[[float, np.ndarray], np.ndarray]


@dataclass(slots=True)
class SolverResult:
    """Output of a transient integration."""

    times: np.ndarray
    states: np.ndarray
    success: bool = True
    message: str = ""
    steps: int = 0
    rejected: int = 0

    @property
    def final(self) -> np.ndarray:
        return self.states[-1]

    def column(self, index: int) -> np.ndarray:
        return self.states[:, index]

    def interpolate(self, t: float) -> np.ndarray:
        """Linear interpolation of the solution at ``t``."""
        if t <= self.times[0]:
            return self.states[0]
        if t >= self.times[-1]:
            return self.states[-1]
        i = int(np.searchsorted(self.times, t)) - 1
        span = self.times[i + 1] - self.times[i]
        frac = (t - self.times[i]) / span if span > 0.0 else 0.0
        return self.states[i] + frac * (self.states[i + 1] - self.states[i])


def rk4_step(f: Derivative, t: float, y: np.ndarray, dt: float) -> np.ndarray:
    """One classical fourth-order Runge-Kutta step."""
    k1 = f(t, y)
    k2 = f(t + dt / 2.0, y + dt / 2.0 * k1)
    k3 = f(t + dt / 2.0, y + dt / 2.0 * k2)
    k4 = f(t + dt, y + dt * k3)
    return y + dt / 6.0 * (k1 + 2.0 * k2 + 2.0 * k3 + k4)


def euler_step(f: Derivative, t: float, y: np.ndarray, dt: float) -> np.ndarray:
    return y + dt * f(t, y)


def heun_step(f: Derivative, t: float, y: np.ndarray, dt: float) -> np.ndarray:
    k1 = f(t, y)
    k2 = f(t + dt, y + dt * k1)
    return y + dt / 2.0 * (k1 + k2)


def implicit_euler_step(f: Derivative, t: float, y: np.ndarray, dt: float,
                        tolerance: float = 1e-10,
                        max_iterations: int = 50) -> np.ndarray:
    """One backward-Euler step solved by damped Newton with a numerical Jacobian.

    Unconditionally stable, which is what makes it the right choice for stiff
    thermal networks where an explicit method would need an impractically
    small step.
    """
    y_next = y + dt * f(t + dt, y)
    n = len(y)
    for _ in range(max_iterations):
        residual = y_next - y - dt * f(t + dt, y_next)
        if np.max(np.abs(residual)) < tolerance:
            return y_next
        jacobian = np.eye(n)
        for j in range(n):
            step = max(1e-8, 1e-6 * abs(y_next[j]))
            perturbed = y_next.copy()
            perturbed[j] += step
            column = (perturbed - y - dt * f(t + dt, perturbed) - residual) / step
            jacobian[:, j] = column
        try:
            delta = np.linalg.solve(jacobian, -residual)
        except np.linalg.LinAlgError:  # pragma: no cover - singular Jacobian
            return y_next
        y_next = y_next + delta
    return y_next


class TransientSolver:
    """Integrates an ODE system with a selectable scheme.

    ``method`` may be ``euler``, ``heun``, ``rk4``, ``implicit_euler``, or
    ``scipy`` (which delegates to ``solve_ivp`` with adaptive stepping and
    dense output).
    """

    METHODS = ("euler", "heun", "rk4", "implicit_euler", "scipy")

    def __init__(self, method: str = "rk4", rtol: float = 1e-6,
                 atol: float = 1e-9) -> None:
        if method not in self.METHODS:
            raise ValueError(f"unknown method {method!r}; choose from {self.METHODS}")
        self.method = method
        self.rtol = rtol
        self.atol = atol

    def integrate(self, f: Derivative, y0: Sequence[float],
                  t_span: tuple[float, float], dt: float,
                  events: Sequence[Callable] | None = None) -> SolverResult:
        y = np.asarray(y0, dtype=float)
        t0, t_end = t_span
        if t_end < t0:
            raise ValueError("t_end must not precede t0")
        if dt <= 0.0:
            raise ValueError("dt must be positive")

        if self.method == "scipy":
            if not _HAVE_SCIPY:  # pragma: no cover
                raise RuntimeError("SciPy is required for the 'scipy' method")
            n = max(2, int(round((t_end - t0) / dt)) + 1)
            grid = np.linspace(t0, t_end, n)
            outcome = solve_ivp(f, (t0, t_end), y, t_eval=grid, rtol=self.rtol,
                                atol=self.atol, method="LSODA",
                                events=list(events) if events else None)
            return SolverResult(outcome.t, outcome.y.T, bool(outcome.success),
                                str(outcome.message), int(outcome.nfev))

        stepper = {"euler": euler_step, "heun": heun_step, "rk4": rk4_step,
                   "implicit_euler": implicit_euler_step}[self.method]
        times = [t0]
        states = [y.copy()]
        t = t0
        steps = 0
        while t < t_end - 1e-12:
            step = min(dt, t_end - t)
            y = stepper(f, t, y, step)
            t += step
            steps += 1
            times.append(t)
            states.append(y.copy())
        return SolverResult(np.asarray(times), np.asarray(states), True,
                            "integration complete", steps)

    def adaptive(self, f: Derivative, y0: Sequence[float],
                 t_span: tuple[float, float], dt: float,
                 dt_min: float = 1e-9, dt_max: float = 1.0) -> SolverResult:
        """Adaptive integration by step doubling with a PI step controller."""
        y = np.asarray(y0, dtype=float)
        t, t_end = t_span
        times = [t]
        states = [y.copy()]
        steps = rejected = 0
        h = dt
        while t < t_end - 1e-12:
            h = min(h, t_end - t)
            coarse = rk4_step(f, t, y, h)
            half = rk4_step(f, t, y, h / 2.0)
            fine = rk4_step(f, t + h / 2.0, half, h / 2.0)
            scale = self.atol + self.rtol * np.maximum(np.abs(y), np.abs(fine))
            error = float(np.max(np.abs(coarse - fine) / scale)) / 15.0
            if error <= 1.0 or h <= dt_min * 1.0000001:
                t += h
                y = fine + (fine - coarse) / 15.0   # local extrapolation
                times.append(t)
                states.append(y.copy())
                steps += 1
            else:
                rejected += 1
            factor = 0.9 * (1.0 / max(error, 1e-16)) ** 0.2
            h = min(dt_max, max(dt_min, h * min(4.0, max(0.1, factor))))
        return SolverResult(np.asarray(times), np.asarray(states), True,
                            "adaptive integration complete", steps, rejected)


class SteadyStateSolver:
    """Finds ``f(y) = 0`` for a residual function.

    Uses SciPy's ``root`` when available and a damped Newton iteration with a
    numerical Jacobian otherwise.  Damping is what makes it survive the strong
    non-linearity of radiation terms, where an undamped step can overshoot to
    a negative absolute temperature.
    """

    def __init__(self, tolerance: float = 1e-10, max_iterations: int = 200,
                 damping: float = 1.0) -> None:
        if not 0.0 < damping <= 1.0:
            raise ValueError("damping must lie in (0, 1]")
        self.tolerance = tolerance
        self.max_iterations = max_iterations
        self.damping = damping

    def solve(self, residual: Callable[[np.ndarray], np.ndarray],
              guess: Sequence[float],
              use_scipy: bool = True) -> tuple[np.ndarray, bool, int]:
        y = np.asarray(guess, dtype=float)
        if use_scipy and _HAVE_SCIPY:
            outcome = root(residual, y, method="hybr",
                           tol=self.tolerance)
            return np.asarray(outcome.x), bool(outcome.success), int(outcome.nfev)
        n = len(y)
        for iteration in range(1, self.max_iterations + 1):
            r = np.asarray(residual(y), dtype=float)
            if np.max(np.abs(r)) < self.tolerance:
                return y, True, iteration
            jacobian = np.zeros((n, n))
            for j in range(n):
                step = max(1e-8, 1e-6 * abs(y[j]))
                perturbed = y.copy()
                perturbed[j] += step
                jacobian[:, j] = (np.asarray(residual(perturbed)) - r) / step
            try:
                delta = np.linalg.solve(jacobian, -r)
            except np.linalg.LinAlgError:  # pragma: no cover
                return y, False, iteration
            y = y + self.damping * delta
        return y, False, self.max_iterations


def stiffness_ratio(jacobian: np.ndarray) -> float:
    """Ratio of the largest to smallest eigenvalue magnitude.

    A ratio above roughly 1e3 means an explicit integrator will be limited by
    stability rather than accuracy, and an implicit method will be faster
    despite costing more per step.
    """
    eigenvalues = np.linalg.eigvals(jacobian)
    magnitudes = np.abs(eigenvalues)
    magnitudes = magnitudes[magnitudes > 1e-300]
    if magnitudes.size < 2:
        return 1.0
    return float(magnitudes.max() / magnitudes.min())


def recommend_method(jacobian: np.ndarray, threshold: float = 1e3) -> str:
    """Suggest an integration method from the system's stiffness."""
    return "implicit_euler" if stiffness_ratio(jacobian) > threshold else "rk4"
