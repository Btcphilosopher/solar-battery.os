"""Scenario definition and execution."""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Callable, Mapping, Sequence

from ..core.engine import ElectroCombustionEngine, RunResult
from ..core.events import Severity
from ..core.state import SystemState


@dataclass(slots=True)
class Segment:
    """One phase of a scenario with its own inputs and duration."""

    name: str
    duration: float
    inputs: Mapping[str, float] = field(default_factory=dict)
    dt: float | None = None
    ramp_from: Mapping[str, float] | None = None

    def __post_init__(self) -> None:
        if self.duration <= 0.0:
            raise ValueError(f"segment {self.name}: duration must be positive")

    def value_at(self, key: str, elapsed: float) -> float:
        """Input value at ``elapsed`` seconds into the segment."""
        target = float(self.inputs.get(key, 0.0))
        if not self.ramp_from:
            return target
        start = float(self.ramp_from.get(key, target))
        fraction = min(1.0, max(0.0, elapsed / self.duration))
        return start + (target - start) * fraction

    def mapping_at(self, elapsed: float) -> dict[str, float]:
        keys = set(self.inputs) | set(self.ramp_from or {})
        return {k: self.value_at(k, elapsed) for k in keys}


@dataclass(slots=True)
class Scenario:
    """An ordered sequence of segments run against an engine."""

    name: str
    segments: list[Segment] = field(default_factory=list)
    dt: float = 0.01
    description: str = ""

    def add(self, name: str, duration: float, dt: float | None = None,
            ramp_from: Mapping[str, float] | None = None,
            **inputs: float) -> "Scenario":
        self.segments.append(Segment(name, duration, dict(inputs), dt, ramp_from))
        return self

    @property
    def duration(self) -> float:
        return sum(s.duration for s in self.segments)

    def inputs_at(self, t: float) -> dict[str, float]:
        """Input mapping at absolute scenario time ``t``."""
        elapsed = t
        for segment in self.segments:
            if elapsed <= segment.duration or segment is self.segments[-1]:
                return segment.mapping_at(min(elapsed, segment.duration))
            elapsed -= segment.duration
        return {}

    def run(self, engine: ElectroCombustionEngine,
            controller: Any | None = None) -> "ScenarioResult":
        """Execute the scenario, returning per-segment diagnostics."""
        start = engine.state.time
        marks: list[dict[str, Any]] = []
        for segment in self.segments:
            offset = engine.state.time
            step = segment.dt or self.dt

            def inputs(t: float, state: SystemState, seg=segment, base=offset):
                return seg.mapping_at(t - base)

            before = engine.energy_summary()
            engine.run(segment.duration, step, inputs, controller)
            after = engine.energy_summary()
            marks.append({
                "segment": segment.name,
                "t_start": offset, "t_end": engine.state.time,
                "energy_in": after["input"] - before["input"],
                "energy_delivered": after["delivered"] - before["delivered"],
                "temperature": engine.state.thermal.temperature,
                "speed": engine.state.mechanical.speed,
                "severity": engine.bus.worst_severity().value,
            })
        return ScenarioResult(self, engine, start, engine.state.time, marks)


@dataclass(slots=True)
class ScenarioResult:
    """Outcome of a scenario run."""

    scenario: Scenario
    engine: ElectroCombustionEngine
    t_start: float
    t_end: float
    segments: list[dict[str, Any]] = field(default_factory=list)

    @property
    def duration(self) -> float:
        return self.t_end - self.t_start

    def summary(self) -> dict[str, Any]:
        energy = self.engine.energy_summary()
        return {
            "scenario": self.scenario.name, "duration": self.duration,
            "segments": len(self.segments),
            "energy_in": energy["input"], "energy_delivered": energy["delivered"],
            "losses": energy["losses"], "residual": energy["residual"],
            "efficiency": self.engine.efficiency(),
            "severity": self.engine.bus.worst_severity().value,
            "peak_temperature": max(
                (row["temperature"] for row in self.segments),
                default=self.engine.state.thermal.temperature),
        }

    def segment(self, name: str) -> dict[str, Any]:
        for row in self.segments:
            if row["segment"] == name:
                return row
        raise KeyError(f"no segment named {name!r}")


def step_scenario(name: str, key: str, before: float, after: float,
                  hold: float = 10.0, dt: float = 0.01) -> Scenario:
    """A two-segment step-response scenario."""
    scenario = Scenario(name, dt=dt, description=f"step {key} {before} -> {after}")
    scenario.add("before", hold, **{key: before})
    scenario.add("after", hold, **{key: after})
    return scenario


def ramp_scenario(name: str, key: str, start: float, end: float,
                  duration: float = 30.0, dt: float = 0.01,
                  settle: float = 10.0) -> Scenario:
    """A ramp followed by a hold at the final value."""
    scenario = Scenario(name, dt=dt, description=f"ramp {key} {start} -> {end}")
    scenario.add("ramp", duration, ramp_from={key: start}, **{key: end})
    if settle > 0.0:
        scenario.add("settle", settle, **{key: end})
    return scenario


def duty_cycle_scenario(name: str, key: str, high: float, low: float,
                        period: float, cycles: int = 5, duty: float = 0.5,
                        dt: float = 0.01) -> Scenario:
    """A repeating on/off duty cycle."""
    if not 0.0 < duty < 1.0:
        raise ValueError("duty must lie in (0, 1)")
    scenario = Scenario(name, dt=dt, description=f"{cycles} cycles of {key}")
    for i in range(cycles):
        scenario.add(f"on{i}", period * duty, **{key: high})
        scenario.add(f"off{i}", period * (1.0 - duty), **{key: low})
    return scenario
