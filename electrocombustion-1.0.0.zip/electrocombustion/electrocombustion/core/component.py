"""The component protocol every physical model implements.

A component is a **pure function of state**.  It never mutates the state it is
handed; it returns a :class:`ComponentOutput` describing the power flows it
causes and the state derivatives it contributes.  Purity is what makes
multi-stage integrators (RK4), rollback on step rejection, and MPC rollouts
possible without any component needing to know about them.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterable, Mapping, Sequence

from .events import Event, EventBus, Severity
from .state import EnergyDomain, PowerFlow, SystemState, Fidelity


@dataclass(slots=True)
class Derivatives:
    """Additive contributions to the state derivative.

    Attributes
    ----------
    heat_input:
        Net thermal power into the bulk thermal mass (W).
    torque:
        Net torque applied to the shaft (N.m).
    electrical_storage_rate:
        Rate of change of stored electrical energy, e.g. battery (W).
    chemical_storage_rate:
        Rate of change of stored chemical energy (W).
    fuel_burn_rate:
        Mass rate of fuel consumed by reaction (kg/s).
    mass_rate:
        Rate of change of the thermal control mass (kg/s).
    """

    heat_input: float = 0.0
    torque: float = 0.0
    electrical_storage_rate: float = 0.0
    chemical_storage_rate: float = 0.0
    fuel_burn_rate: float = 0.0
    mass_rate: float = 0.0

    def __add__(self, other: "Derivatives") -> "Derivatives":
        return Derivatives(
            self.heat_input + other.heat_input,
            self.torque + other.torque,
            self.electrical_storage_rate + other.electrical_storage_rate,
            self.chemical_storage_rate + other.chemical_storage_rate,
            self.fuel_burn_rate + other.fuel_burn_rate,
            self.mass_rate + other.mass_rate,
        )

    def scaled(self, factor: float) -> "Derivatives":
        return Derivatives(
            self.heat_input * factor, self.torque * factor,
            self.electrical_storage_rate * factor,
            self.chemical_storage_rate * factor,
            self.fuel_burn_rate * factor, self.mass_rate * factor,
        )

    def as_vector(self) -> tuple[float, ...]:
        return (self.heat_input, self.torque, self.electrical_storage_rate,
                self.chemical_storage_rate, self.fuel_burn_rate, self.mass_rate)


@dataclass(slots=True)
class ComponentOutput:
    """What a component returns from :meth:`Component.evaluate`."""

    flows: list[PowerFlow] = field(default_factory=list)
    derivatives: Derivatives = field(default_factory=Derivatives)
    diagnostics: dict[str, Any] = field(default_factory=dict)
    events: list[Event] = field(default_factory=list)
    severity: Severity = Severity.NORMAL

    def merge(self, other: "ComponentOutput") -> "ComponentOutput":
        return ComponentOutput(
            flows=self.flows + other.flows,
            derivatives=self.derivatives + other.derivatives,
            diagnostics={**self.diagnostics, **other.diagnostics},
            events=self.events + other.events,
            severity=Severity.worst((self.severity, other.severity)),
        )

    def power_into(self, domain: EnergyDomain) -> float:
        net = 0.0
        for raw in self.flows:
            flow = raw.normalised()
            if flow.target is domain:
                net += flow.watts
            if flow.source is domain:
                net -= flow.watts
        return net

    @property
    def total_loss(self) -> float:
        return sum(f.normalised().watts for f in self.flows
                   if f.normalised().target is EnergyDomain.ENVIRONMENT)


@dataclass(slots=True)
class Context:
    """Everything a component may read that is not part of the state.

    ``inputs`` carries externally commanded values (controller outputs, user
    setpoints).  ``bus`` is available for out-of-band notification, but
    components should prefer returning events so that speculative evaluations
    (MPC rollouts, rejected steps) do not pollute the log.
    """

    inputs: dict[str, float] = field(default_factory=dict)
    fidelity: Fidelity = Fidelity.STANDARD
    bus: EventBus | None = None
    speculative: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)

    def get(self, key: str, default: float = 0.0) -> float:
        value = self.inputs.get(key, default)
        return float(value)

    def with_inputs(self, **overrides: float) -> "Context":
        merged = dict(self.inputs)
        merged.update(overrides)
        return Context(merged, self.fidelity, self.bus, self.speculative,
                       dict(self.metadata))

    def speculate(self) -> "Context":
        return Context(dict(self.inputs), self.fidelity, self.bus, True,
                       dict(self.metadata))


class Component:
    """Base class for all physical models.

    Subclasses must implement :meth:`evaluate`.  They may override
    :meth:`initialise` to seed state and :meth:`describe` for reporting.
    """

    #: components with a lower order are evaluated first within a stage
    order: int = 100

    def __init__(self, name: str) -> None:
        if not name:
            raise ValueError("component name must be non-empty")
        self.name = name
        self.enabled = True

    # -- lifecycle ----------------------------------------------------------
    def initialise(self, state: SystemState, context: Context) -> None:
        """Optional hook run once before the first step."""

    def finalise(self, state: SystemState, context: Context) -> None:
        """Optional hook run after the last step."""

    # -- evaluation ---------------------------------------------------------
    def evaluate(self, state: SystemState, dt: float,
                 context: Context) -> ComponentOutput:  # pragma: no cover
        raise NotImplementedError(
            f"{type(self).__name__} must implement evaluate()"
        )

    # -- reporting ----------------------------------------------------------
    def describe(self) -> dict[str, Any]:
        return {"name": self.name, "type": type(self).__name__,
                "enabled": self.enabled, "order": self.order}

    def __repr__(self) -> str:
        return f"{type(self).__name__}(name={self.name!r})"


class ComponentGroup(Component):
    """A composite component that evaluates children in order."""

    def __init__(self, name: str, components: Sequence[Component] = ()) -> None:
        super().__init__(name)
        self.components: list[Component] = list(components)

    def add(self, component: Component) -> Component:
        """Register a component, rejecting a duplicate name.

        Names are how diagnostics, inputs and per-component balance checks are
        keyed, so two components sharing one is not a cosmetic problem: the
        second would silently shadow the first's diagnostics and input keys.
        """
        if any(c.name == component.name for c in self.components):
            raise ValueError(
                f"a component named {component.name!r} is already registered; "
                f"names must be unique because diagnostics and input keys are "
                f"derived from them"
            )
        self.components.append(component)
        return component

    def initialise(self, state: SystemState, context: Context) -> None:
        for c in self.components:
            if c.enabled:
                c.initialise(state, context)

    def finalise(self, state: SystemState, context: Context) -> None:
        for c in self.components:
            if c.enabled:
                c.finalise(state, context)

    def evaluate(self, state: SystemState, dt: float,
                 context: Context) -> ComponentOutput:
        out = ComponentOutput()
        for c in sorted((c for c in self.components if c.enabled),
                        key=lambda c: c.order):
            out = out.merge(c.evaluate(state, dt, context))
        return out

    def describe(self) -> dict[str, Any]:
        base = super().describe()
        base["children"] = [c.describe() for c in self.components]
        return base

    def __len__(self) -> int:
        return len(self.components)

    def __iter__(self):
        return iter(self.components)


class CallableComponent(Component):
    """Adapter turning a plain function into a :class:`Component`.

    The function signature is ``fn(state, dt, context) -> ComponentOutput``.
    Useful for one-off couplings and for tests.
    """

    def __init__(self, name: str, fn, order: int = 100) -> None:
        super().__init__(name)
        self._fn = fn
        self.order = order

    def evaluate(self, state: SystemState, dt: float,
                 context: Context) -> ComponentOutput:
        result = self._fn(state, dt, context)
        if result is None:
            return ComponentOutput()
        if isinstance(result, ComponentOutput):
            return result
        if isinstance(result, (list, tuple)):
            return ComponentOutput(flows=list(result))
        raise TypeError(
            f"callable component {self.name!r} returned {type(result).__name__}; "
            "expected ComponentOutput, a sequence of PowerFlow, or None"
        )
