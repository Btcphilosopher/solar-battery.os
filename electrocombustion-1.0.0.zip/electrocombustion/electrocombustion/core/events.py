"""Event bus, severity classification and event logging."""
from __future__ import annotations

import time as _time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Iterable, Iterator


class Severity(str, Enum):
    """Operating-state classification used across the engine.

    The four levels mirror the fault model in the specification.  They are an
    *engineering-analysis* classification, not a safety certification.
    """

    NORMAL = "NORMAL"
    WARNING = "WARNING"
    LIMIT = "LIMIT"
    FAULT = "FAULT"

    @property
    def rank(self) -> int:
        return {"NORMAL": 0, "WARNING": 1, "LIMIT": 2, "FAULT": 3}[self.value]

    def __lt__(self, other: "Severity") -> bool:
        return self.rank < other.rank

    def __le__(self, other: "Severity") -> bool:
        return self.rank <= other.rank

    @classmethod
    def worst(cls, severities: Iterable["Severity"]) -> "Severity":
        worst = cls.NORMAL
        for s in severities:
            if s.rank > worst.rank:
                worst = s
        return worst


@dataclass(frozen=True, slots=True)
class Event:
    """A time-stamped occurrence emitted by a component or the engine."""

    time: float
    kind: str
    message: str = ""
    severity: Severity = Severity.NORMAL
    source: str = ""
    data: dict[str, Any] = field(default_factory=dict)
    wall_clock: float = field(default_factory=_time.time)

    def __str__(self) -> str:
        origin = f"[{self.source}] " if self.source else ""
        return f"t={self.time:.6g}s {self.severity.value} {origin}{self.kind}: {self.message}"


Listener = Callable[[Event], None]


class EventBus:
    """Publish/subscribe hub with per-kind and wildcard subscriptions."""

    WILDCARD = "*"

    def __init__(self, history_limit: int | None = 10_000) -> None:
        self._listeners: dict[str, list[Listener]] = {}
        self._history: list[Event] = []
        self.history_limit = history_limit
        self.counts: dict[str, int] = {}

    def subscribe(self, kind: str, listener: Listener) -> Callable[[], None]:
        """Register ``listener`` for ``kind``; returns an unsubscribe callable."""
        self._listeners.setdefault(kind, []).append(listener)

        def _unsubscribe() -> None:
            try:
                self._listeners[kind].remove(listener)
            except (KeyError, ValueError):  # pragma: no cover - defensive
                pass

        return _unsubscribe

    def subscribe_all(self, listener: Listener) -> Callable[[], None]:
        return self.subscribe(self.WILDCARD, listener)

    def emit(self, event: Event) -> Event:
        """Publish ``event`` to all matching listeners and record it."""
        self.counts[event.kind] = self.counts.get(event.kind, 0) + 1
        self._history.append(event)
        if self.history_limit is not None and len(self._history) > self.history_limit:
            del self._history[: len(self._history) - self.history_limit]
        for listener in tuple(self._listeners.get(event.kind, ())):
            listener(event)
        for listener in tuple(self._listeners.get(self.WILDCARD, ())):
            listener(event)
        return event

    def publish(self, time: float, kind: str, message: str = "",
                severity: Severity = Severity.NORMAL, source: str = "",
                **data: Any) -> Event:
        """Convenience constructor + :meth:`emit`."""
        return self.emit(Event(time, kind, message, severity, source, dict(data)))

    # -- history ------------------------------------------------------------
    @property
    def history(self) -> tuple[Event, ...]:
        return tuple(self._history)

    def filter(self, kind: str | None = None,
               min_severity: Severity = Severity.NORMAL,
               source: str | None = None) -> list[Event]:
        return [
            e for e in self._history
            if (kind is None or e.kind == kind)
            and e.severity.rank >= min_severity.rank
            and (source is None or e.source == source)
        ]

    def worst_severity(self) -> Severity:
        return Severity.worst(e.severity for e in self._history)

    def clear(self) -> None:
        self._history.clear()
        self.counts.clear()

    def __len__(self) -> int:
        return len(self._history)

    def __iter__(self) -> Iterator[Event]:
        return iter(self._history)


@dataclass(slots=True)
class Threshold:
    """A named limit that classifies a scalar signal into a :class:`Severity`.

    ``warning``, ``limit`` and ``fault`` are ordered thresholds.  For an upper
    bound (``direction='upper'``) they must be increasing; for a lower bound
    they must be decreasing.
    """

    name: str
    warning: float | None = None
    limit: float | None = None
    fault: float | None = None
    direction: str = "upper"
    units: str = ""

    def __post_init__(self) -> None:
        if self.direction not in ("upper", "lower"):
            raise ValueError("direction must be 'upper' or 'lower'")
        levels = [v for v in (self.warning, self.limit, self.fault) if v is not None]
        if len(levels) > 1:
            ordered = levels == sorted(levels) if self.direction == "upper" \
                else levels == sorted(levels, reverse=True)
            if not ordered:
                raise ValueError(
                    f"threshold levels for {self.name!r} must be monotonic "
                    f"for direction={self.direction!r}"
                )

    def _exceeds(self, value: float, level: float) -> bool:
        return value >= level if self.direction == "upper" else value <= level

    def classify(self, value: float) -> Severity:
        if self.fault is not None and self._exceeds(value, self.fault):
            return Severity.FAULT
        if self.limit is not None and self._exceeds(value, self.limit):
            return Severity.LIMIT
        if self.warning is not None and self._exceeds(value, self.warning):
            return Severity.WARNING
        return Severity.NORMAL

    def margin(self, value: float) -> float:
        """Signed distance to the ``limit`` level (positive = inside limit)."""
        if self.limit is None:
            return float("inf")
        return self.limit - value if self.direction == "upper" else value - self.limit
