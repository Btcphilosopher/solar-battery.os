"""Timestep control: fixed, adaptive and event-aware stepping."""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Callable, Iterator, Sequence


@dataclass(slots=True)
class TimestepResult:
    """Outcome of one attempted step."""

    accepted: bool
    dt_used: float
    dt_next: float
    error: float = 0.0
    reason: str = ""


class TimestepController:
    """Base class for timestep policies."""

    def __init__(self, dt: float) -> None:
        if dt <= 0.0:
            raise ValueError("dt must be positive")
        self.dt = float(dt)
        self.initial_dt = float(dt)
        self.rejections = 0
        self.acceptances = 0

    def propose(self) -> float:
        return self.dt

    def report(self, error: float) -> TimestepResult:  # pragma: no cover
        raise NotImplementedError

    def reset(self) -> None:
        self.dt = self.initial_dt
        self.rejections = 0
        self.acceptances = 0


class FixedTimestep(TimestepController):
    """Constant timestep; every step is accepted."""

    def report(self, error: float = 0.0) -> TimestepResult:
        self.acceptances += 1
        return TimestepResult(True, self.dt, self.dt, error, "fixed")


class AdaptiveTimestep(TimestepController):
    """PI-controlled adaptive timestep based on a normalised error estimate.

    ``error`` is expected to be the ratio ``estimated_error / tolerance``; a
    value <= 1 is acceptable.  The step size is scaled by a standard
    proportional-integral law with safety factor and clamped growth/shrink
    limits, which damps the oscillation a pure proportional law produces near
    a stiffness boundary.
    """

    def __init__(self, dt: float, dt_min: float = 1e-9, dt_max: float = 1.0,
                 order: int = 4, safety: float = 0.9,
                 max_growth: float = 4.0, max_shrink: float = 0.1,
                 ki: float = 0.08, kp: float = 0.30) -> None:
        super().__init__(dt)
        if dt_min > dt_max:
            raise ValueError("dt_min must not exceed dt_max")
        self.dt_min = float(dt_min)
        self.dt_max = float(dt_max)
        self.order = int(order)
        self.safety = float(safety)
        self.max_growth = float(max_growth)
        self.max_shrink = float(max_shrink)
        self.ki = float(ki)
        self.kp = float(kp)
        self._previous_error = 1.0

    def report(self, error: float) -> TimestepResult:
        error = max(float(error), 1e-16)
        exponent_i = self.ki
        exponent_p = self.kp
        # PI law:  factor = safety * err^-ki * (err_prev/err)^kp
        factor = (self.safety * error ** (-exponent_i)
                  * (self._previous_error / error) ** exponent_p)
        # Fall back to the classic order-based law when the PI law is extreme
        if not math.isfinite(factor) or factor <= 0.0:
            factor = self.safety * error ** (-1.0 / (self.order + 1))
        factor = min(self.max_growth, max(self.max_shrink, factor))
        accepted = error <= 1.0
        dt_used = self.dt
        dt_next = min(self.dt_max, max(self.dt_min, self.dt * factor))
        if accepted:
            self.acceptances += 1
            self._previous_error = error
            self.dt = dt_next
            reason = "accepted"
        else:
            self.rejections += 1
            self.dt = max(self.dt_min, min(dt_next, self.dt * 0.9))
            dt_next = self.dt
            reason = "rejected: error above tolerance"
        return TimestepResult(accepted, dt_used, dt_next, error, reason)


class ScheduledTimestep(TimestepController):
    """Fixed stepping that is clipped so scheduled times are hit exactly.

    Useful when control actions, logging or events must occur on an exact grid
    (for example a 10 Hz controller inside a 1 kHz plant model).
    """

    def __init__(self, dt: float, checkpoints: Sequence[float] = ()) -> None:
        super().__init__(dt)
        self.checkpoints = sorted(float(t) for t in checkpoints)
        self._index = 0

    def propose_at(self, t: float) -> float:
        """Largest step from ``t`` that does not overshoot the next checkpoint."""
        while self._index < len(self.checkpoints) and self.checkpoints[self._index] <= t + 1e-15:
            self._index += 1
        if self._index >= len(self.checkpoints):
            return self.dt
        gap = self.checkpoints[self._index] - t
        return max(min(self.dt, gap), 1e-15)

    def report(self, error: float = 0.0) -> TimestepResult:
        self.acceptances += 1
        return TimestepResult(True, self.dt, self.dt, error, "scheduled")

    def reset(self) -> None:
        super().reset()
        self._index = 0


@dataclass(slots=True)
class TimeGrid:
    """An inclusive time grid ``[t0, t_end]`` with a nominal step."""

    t0: float
    t_end: float
    dt: float

    def __post_init__(self) -> None:
        if self.dt <= 0.0:
            raise ValueError("dt must be positive")
        if self.t_end < self.t0:
            raise ValueError("t_end must not precede t0")

    @property
    def n_steps(self) -> int:
        return max(0, int(round((self.t_end - self.t0) / self.dt)))

    def times(self) -> list[float]:
        return [self.t0 + i * self.dt for i in range(self.n_steps + 1)]

    def __iter__(self) -> Iterator[float]:
        return iter(self.times())

    def __len__(self) -> int:
        return self.n_steps + 1


@dataclass(slots=True)
class ConvergenceCriteria:
    """Convergence test for steady-state and iterative solvers."""

    rel_tol: float = 1e-8
    abs_tol: float = 1e-10
    max_iterations: int = 200
    stall_patience: int = 20

    def converged(self, residual: float, scale: float = 1.0) -> bool:
        return abs(residual) <= max(self.abs_tol, self.rel_tol * abs(scale))

    def check_iterations(self, iteration: int) -> bool:
        """``True`` while iteration budget remains."""
        return iteration < self.max_iterations
