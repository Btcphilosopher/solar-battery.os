"""Physical constants, unit conversion and dimensional bookkeeping.

Every quantity inside ELECTROCOMBUSTION is stored in **base SI units**.
Conversion happens only at the boundary (user input / reporting output).

Base units used internally
--------------------------
mass kg, length m, time s, temperature K, amount mol, current A,
energy J, power W, pressure Pa.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Callable, Mapping

# ---------------------------------------------------------------------------
# Universal constants (CODATA 2018 where applicable)
# ---------------------------------------------------------------------------
R_UNIVERSAL = 8.314462618          # J/(mol.K)   molar gas constant
STEFAN_BOLTZMANN = 5.670374419e-8  # W/(m^2.K^4)
AVOGADRO = 6.02214076e23           # 1/mol
BOLTZMANN = 1.380649e-23           # J/K
ELEMENTARY_CHARGE = 1.602176634e-19  # C
FARADAY = 96485.33212              # C/mol
STANDARD_GRAVITY = 9.80665         # m/s^2
ZERO_CELSIUS = 273.15              # K

P_ATM = 101_325.0                  # Pa
T_STANDARD = 298.15                # K  (25 degC)
T_NORMAL = 273.15                  # K  (0 degC)

# Dry-air composition and properties -----------------------------------------
M_AIR = 0.0289647                  # kg/mol   mean molar mass of dry air
O2_MOLE_FRACTION_AIR = 0.20946     # mol O2 / mol dry air
N2_MOLE_FRACTION_AIR = 0.78084
AR_MOLE_FRACTION_AIR = 0.00934
R_AIR = R_UNIVERSAL / M_AIR        # ~287.05 J/(kg.K)
CP_AIR_STD = 1005.0                # J/(kg.K) near 300 K
GAMMA_AIR_STD = 1.4

# Atomic / molar masses for the stoichiometry solver (kg/mol)
M_C = 0.0120107
M_H = 0.00100794
M_O = 0.0159994
M_N = 0.0140067
M_S = 0.032065
M_O2 = 2 * M_O
M_N2 = 2 * M_N
M_CO2 = M_C + 2 * M_O
M_H2O = 2 * M_H + M_O
M_SO2 = M_S + 2 * M_O
M_AR = 0.039948                    # kg/mol argon

#: Effective molar mass of the non-oxygen fraction of dry air (N2 + Ar + trace).
#: Derived so that ``x_O2*M_O2 + (1-x_O2)*M_INERT_AIR == M_AIR`` exactly, which
#: is what lets combustion product mass balance close to machine precision.
M_INERT_AIR = (M_AIR - O2_MOLE_FRACTION_AIR * M_O2) / (1.0 - O2_MOLE_FRACTION_AIR)

LATENT_HEAT_VAPORISATION_WATER = 2.442e6  # J/kg at 25 degC
CP_WATER = 4181.0                          # J/(kg.K)


# ---------------------------------------------------------------------------
# Temperature conversions (affine)
# ---------------------------------------------------------------------------
def celsius_to_kelvin(t_c: float) -> float:
    return t_c + ZERO_CELSIUS


def kelvin_to_celsius(t_k: float) -> float:
    return t_k - ZERO_CELSIUS


def fahrenheit_to_kelvin(t_f: float) -> float:
    return (t_f - 32.0) * 5.0 / 9.0 + ZERO_CELSIUS


def kelvin_to_fahrenheit(t_k: float) -> float:
    return (t_k - ZERO_CELSIUS) * 9.0 / 5.0 + 32.0


def rankine_to_kelvin(t_r: float) -> float:
    return t_r * 5.0 / 9.0


# ---------------------------------------------------------------------------
# Multiplicative unit registry:  value_SI = value_unit * factor
# ---------------------------------------------------------------------------
_SCALE_UNITS: Mapping[str, float] = {
    "J": 1.0, "kJ": 1e3, "MJ": 1e6, "GJ": 1e9,
    "Wh": 3600.0, "kWh": 3.6e6, "MWh": 3.6e9,
    "cal": 4.184, "kcal": 4184.0, "BTU": 1055.05585262,
    "W": 1.0, "kW": 1e3, "MW": 1e6, "GW": 1e9,
    "hp": 745.699872, "PS": 735.49875,
    "Pa": 1.0, "kPa": 1e3, "MPa": 1e6,
    "bar": 1e5, "mbar": 100.0, "atm": P_ATM,
    "psi": 6894.757293168, "torr": 133.322387415,
    "kg": 1.0, "g": 1e-3, "mg": 1e-6, "t": 1e3, "lb": 0.45359237,
    "kg/s": 1.0, "g/s": 1e-3, "kg/h": 1.0 / 3600.0, "t/h": 1000.0 / 3600.0,
    "m": 1.0, "mm": 1e-3, "cm": 1e-2, "km": 1e3, "in": 0.0254, "ft": 0.3048,
    "m2": 1.0, "cm2": 1e-4, "mm2": 1e-6,
    "m3": 1.0, "L": 1e-3, "cm3": 1e-6, "mL": 1e-6,
    "m3/s": 1.0, "L/s": 1e-3, "L/min": 1e-3 / 60.0, "m3/h": 1.0 / 3600.0,
    "s": 1.0, "ms": 1e-3, "us": 1e-6, "min": 60.0, "h": 3600.0, "day": 86400.0,
    "rad/s": 1.0, "rpm": 2.0 * math.pi / 60.0, "Hz": 2.0 * math.pi,
    "V": 1.0, "mV": 1e-3, "kV": 1e3,
    "A": 1.0, "mA": 1e-3, "kA": 1e3,
    "ohm": 1.0, "mohm": 1e-3, "kohm": 1e3, "Mohm": 1e6,
    "F": 1.0, "uF": 1e-6, "nF": 1e-9,
    "H": 1.0, "mH": 1e-3, "uH": 1e-6,
    "C": 1.0, "Ah": 3600.0, "mAh": 3.6,
    "Nm": 1.0, "N": 1.0, "kN": 1e3, "lbf": 4.4482216152605,
    "-": 1.0, "": 1.0, "%": 0.01,
}

_AFFINE_UNITS: Mapping[str, tuple[Callable[[float], float], Callable[[float], float]]] = {
    "K": (lambda x: x, lambda x: x),
    "degC": (celsius_to_kelvin, kelvin_to_celsius),
    "degF": (fahrenheit_to_kelvin, kelvin_to_fahrenheit),
    "degR": (rankine_to_kelvin, lambda x: x * 9.0 / 5.0),
}


# ---------------------------------------------------------------------------
# Dimensions.  Conversion between units of different dimension is an error,
# not a silent rescaling: ``convert(1.0, "m", "kg")`` returning 1.0 would be
# worse than useless, because it looks like it worked.
# ---------------------------------------------------------------------------
_DIMENSIONS: Mapping[str, str] = {
    **{u: "energy" for u in ("J", "kJ", "MJ", "GJ", "Wh", "kWh", "MWh",
                             "cal", "kcal", "BTU")},
    **{u: "power" for u in ("W", "kW", "MW", "GW", "hp", "PS")},
    **{u: "pressure" for u in ("Pa", "kPa", "MPa", "bar", "mbar", "atm",
                               "psi", "torr")},
    **{u: "mass" for u in ("kg", "g", "mg", "t", "lb")},
    **{u: "mass_flow" for u in ("kg/s", "g/s", "kg/h", "t/h")},
    **{u: "length" for u in ("m", "mm", "cm", "km", "in", "ft")},
    **{u: "area" for u in ("m2", "cm2", "mm2")},
    **{u: "volume" for u in ("m3", "L", "cm3", "mL")},
    **{u: "volume_flow" for u in ("m3/s", "L/s", "L/min", "m3/h")},
    **{u: "time" for u in ("s", "ms", "us", "min", "h", "day")},
    **{u: "angular_velocity" for u in ("rad/s", "rpm", "Hz")},
    **{u: "voltage" for u in ("V", "mV", "kV")},
    **{u: "current" for u in ("A", "mA", "kA")},
    **{u: "resistance" for u in ("ohm", "mohm", "kohm", "Mohm")},
    **{u: "capacitance" for u in ("F", "uF", "nF")},
    **{u: "inductance" for u in ("H", "mH", "uH")},
    **{u: "charge" for u in ("C", "Ah", "mAh")},
    **{u: "force" for u in ("N", "kN", "lbf")},
    "Nm": "torque",
    **{u: "dimensionless" for u in ("-", "", "%")},
    **{u: "temperature" for u in ("K", "degC", "degF", "degR")},
}


class UnitError(ValueError):
    """Raised when a unit string is unknown or dimensionally incompatible."""


def to_si(value: float, unit: str) -> float:
    """Convert ``value`` expressed in ``unit`` into base SI.

    ``"C"`` is treated as **coulomb**; use ``"degC"`` for Celsius.
    """
    if unit in _AFFINE_UNITS:
        return float(_AFFINE_UNITS[unit][0](value))
    try:
        return float(value) * _SCALE_UNITS[unit]
    except KeyError as exc:
        raise UnitError(f"unknown unit {unit!r}") from exc


def from_si(value: float, unit: str) -> float:
    """Convert a base-SI ``value`` into ``unit``."""
    if unit in _AFFINE_UNITS:
        return float(_AFFINE_UNITS[unit][1](value))
    try:
        return float(value) / _SCALE_UNITS[unit]
    except KeyError as exc:
        raise UnitError(f"unknown unit {unit!r}") from exc


def dimension_of(unit: str) -> str:
    """The physical dimension a unit belongs to."""
    try:
        return _DIMENSIONS[unit]
    except KeyError as exc:
        raise UnitError(f"unknown unit {unit!r}") from exc


def compatible(from_unit: str, to_unit: str) -> bool:
    """Whether two units describe the same physical dimension."""
    return dimension_of(from_unit) == dimension_of(to_unit)


def convert(value: float, from_unit: str, to_unit: str) -> float:
    """Convert between two units of the same dimension via base SI.

    Raises :class:`UnitError` when the dimensions differ, rather than
    returning a number that happens to be arithmetically consistent and
    physically meaningless.
    """
    if not compatible(from_unit, to_unit):
        raise UnitError(
            f"cannot convert {from_unit!r} ({dimension_of(from_unit)}) to "
            f"{to_unit!r} ({dimension_of(to_unit)}): different dimensions"
        )
    return from_si(to_si(value, from_unit), to_unit)


def known_units() -> tuple[str, ...]:
    return tuple(sorted(set(_SCALE_UNITS) | set(_AFFINE_UNITS)))


@dataclass(frozen=True, slots=True)
class Quantity:
    """A value with an attached unit, stored as given and converted on demand.

    Deliberately lightweight: it lets user-facing configuration be
    unit-explicit without putting a unit library in the numerical hot path.
    Arithmetic is *not* dimension-checked.
    """

    value: float
    unit: str = "-"

    @property
    def si(self) -> float:
        return to_si(self.value, self.unit)

    def to(self, unit: str) -> "Quantity":
        return Quantity(convert(self.value, self.unit, unit), unit)

    def __float__(self) -> float:
        return self.si

    def __str__(self) -> str:
        return f"{self.value:g} {self.unit}".strip()


def as_si(value: float | Quantity, unit: str | None = None) -> float:
    """Coerce a possibly-``Quantity`` input to a base-SI float."""
    if isinstance(value, Quantity):
        return value.si
    if unit is None:
        return float(value)
    return to_si(float(value), unit)
