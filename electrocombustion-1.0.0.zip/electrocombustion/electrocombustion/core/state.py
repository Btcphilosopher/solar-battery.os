"""System state representation and explicit energy accounting.

The engine is built around a single principle: *every joule is accounted for*.
Components never mutate state directly.  They emit :class:`PowerFlow` records
describing where power comes from and where it goes, and the integrator
applies them.  This makes conservation checkable rather than assumed.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field, replace
from enum import Enum
from typing import Any, Iterable, Iterator, Mapping

from . import units as U


class Fidelity(str, Enum):
    """Model fidelity level.

    ``FAST``      constant properties, linearised transport, no iteration.
    ``STANDARD``  temperature-dependent properties, standard correlations.
    ``DETAILED``  full non-linear property models, iterative closure.
    """

    FAST = "FAST"
    STANDARD = "STANDARD"
    DETAILED = "DETAILED"

    @property
    def rank(self) -> int:
        return {"FAST": 0, "STANDARD": 1, "DETAILED": 2}[self.value]

    def at_least(self, other: "Fidelity") -> bool:
        return self.rank >= other.rank


class EnergyDomain(str, Enum):
    """The five reservoirs between which power flows.

    ``SOURCE`` and ``ENVIRONMENT`` are unbounded boundary reservoirs: the grid,
    the fuel tank, the atmosphere.  Everything else is an internal store whose
    contents must balance against the flows crossing its boundary.
    """

    SOURCE = "SOURCE"
    ELECTRICAL = "ELECTRICAL"
    CHEMICAL = "CHEMICAL"
    THERMAL = "THERMAL"
    MECHANICAL = "MECHANICAL"
    ENVIRONMENT = "ENVIRONMENT"

    @property
    def is_boundary(self) -> bool:
        return self in (EnergyDomain.SOURCE, EnergyDomain.ENVIRONMENT)


INTERNAL_DOMAINS: tuple[EnergyDomain, ...] = (
    EnergyDomain.ELECTRICAL,
    EnergyDomain.CHEMICAL,
    EnergyDomain.THERMAL,
    EnergyDomain.MECHANICAL,
)


@dataclass(frozen=True, slots=True)
class PowerFlow:
    """A directed transfer of power between two energy domains.

    Parameters
    ----------
    source, target:
        Domains the power leaves and enters.
    watts:
        Magnitude, **non-negative by convention**.  A negative transfer must be
        expressed by swapping source and target so that direction is always
        explicit; :meth:`normalised` does this automatically.
    label:
        Human-readable description, e.g. ``"joule heating"``.
    component:
        Name of the emitting component, used for per-component balance checks.
    """

    source: EnergyDomain
    target: EnergyDomain
    watts: float
    label: str = ""
    component: str = ""

    def __post_init__(self) -> None:
        if self.source is self.target:
            raise ValueError(
                f"a power flow must cross domains, not {self.source.value} "
                f"-> {self.target.value}"
            )

    def normalised(self) -> "PowerFlow":
        """Return an equivalent flow with non-negative magnitude."""
        if self.watts < 0.0:
            return PowerFlow(self.target, self.source, -self.watts,
                             self.label, self.component)
        return self

    @property
    def is_loss(self) -> bool:
        return self.target is EnergyDomain.ENVIRONMENT

    def scaled(self, factor: float) -> "PowerFlow":
        return replace(self, watts=self.watts * factor)

    def __str__(self) -> str:
        arrow = f"{self.source.value}->{self.target.value}"
        return f"{arrow} {self.watts:.4g} W ({self.label or 'unlabelled'})"


@dataclass(slots=True)
class ElectricalState:
    """Instantaneous electrical state at a single bus."""

    voltage: float = 0.0          # V   (RMS for AC)
    current: float = 0.0          # A   (RMS for AC)
    frequency: float = 0.0        # Hz  (0 for DC)
    power_factor: float = 1.0     # -
    real_power: float = 0.0       # W
    reactive_power: float = 0.0   # var
    resistance: float = math.inf  # ohm (effective load resistance)
    stored_energy: float = 0.0    # J   (battery / capacitor content)

    @property
    def apparent_power(self) -> float:
        return math.hypot(self.real_power, self.reactive_power)

    def as_dict(self) -> dict[str, float]:
        return {
            "voltage": self.voltage, "current": self.current,
            "frequency": self.frequency, "power_factor": self.power_factor,
            "real_power": self.real_power, "reactive_power": self.reactive_power,
            "apparent_power": self.apparent_power,
            "resistance": self.resistance, "stored_energy": self.stored_energy,
        }


@dataclass(slots=True)
class ThermalState:
    """Bulk thermodynamic state of a control mass."""

    temperature: float = U.T_STANDARD   # K
    pressure: float = U.P_ATM           # Pa
    mass: float = 1.0                   # kg
    volume: float = 1.0                 # m^3
    specific_heat: float = U.CP_AIR_STD  # J/(kg.K) at constant pressure
    gas_constant: float = U.R_AIR       # J/(kg.K)
    heat_flow: float = 0.0              # W  net heat into the control mass

    @property
    def density(self) -> float:
        return self.mass / self.volume if self.volume > 0.0 else 0.0

    @property
    def cv(self) -> float:
        """Constant-volume specific heat from Mayer's relation."""
        return self.specific_heat - self.gas_constant

    @property
    def gamma(self) -> float:
        cv = self.cv
        return self.specific_heat / cv if cv > 0.0 else U.GAMMA_AIR_STD

    @property
    def internal_energy(self) -> float:
        """Sensible internal energy referenced to 0 K (J)."""
        return self.mass * self.cv * self.temperature

    @property
    def enthalpy(self) -> float:
        """Sensible enthalpy referenced to 0 K (J)."""
        return self.mass * self.specific_heat * self.temperature

    @property
    def heat_capacity(self) -> float:
        """Total thermal capacitance m*cp (J/K)."""
        return self.mass * self.specific_heat

    def as_dict(self) -> dict[str, float]:
        return {
            "temperature": self.temperature, "pressure": self.pressure,
            "mass": self.mass, "volume": self.volume, "density": self.density,
            "specific_heat": self.specific_heat, "cv": self.cv,
            "gamma": self.gamma, "enthalpy": self.enthalpy,
            "internal_energy": self.internal_energy,
            "heat_capacity": self.heat_capacity, "heat_flow": self.heat_flow,
        }


@dataclass(slots=True)
class ChemicalState:
    """Fuel and reaction bookkeeping."""

    fuel_mass: float = 0.0            # kg  unburned fuel in the control volume
    fuel_flow: float = 0.0            # kg/s
    air_flow: float = 0.0             # kg/s
    equivalence_ratio: float = 1.0    # phi  (-)
    reaction_progress: float = 0.0    # 0..1
    heat_release_rate: float = 0.0    # W
    burned_mass: float = 0.0          # kg cumulative
    ignited: bool = False

    @property
    def lambda_(self) -> float:
        """Excess-air ratio, lambda = 1/phi."""
        return 1.0 / self.equivalence_ratio if self.equivalence_ratio > 0.0 else math.inf

    def as_dict(self) -> dict[str, float | bool]:
        return {
            "fuel_mass": self.fuel_mass, "fuel_flow": self.fuel_flow,
            "air_flow": self.air_flow,
            "equivalence_ratio": self.equivalence_ratio,
            "lambda": self.lambda_,
            "reaction_progress": self.reaction_progress,
            "heat_release_rate": self.heat_release_rate,
            "burned_mass": self.burned_mass, "ignited": self.ignited,
        }


@dataclass(slots=True)
class MechanicalState:
    """Rotating-shaft state."""

    speed: float = 0.0        # rad/s
    torque: float = 0.0       # N.m  net torque on the shaft
    inertia: float = 1.0      # kg.m^2
    angle: float = 0.0        # rad
    power: float = 0.0        # W    delivered shaft power

    @property
    def kinetic_energy(self) -> float:
        return 0.5 * self.inertia * self.speed ** 2

    @property
    def rpm(self) -> float:
        return self.speed * 60.0 / (2.0 * math.pi)

    def as_dict(self) -> dict[str, float]:
        return {
            "speed": self.speed, "rpm": self.rpm, "torque": self.torque,
            "inertia": self.inertia, "angle": self.angle, "power": self.power,
            "kinetic_energy": self.kinetic_energy,
        }


@dataclass(slots=True)
class SystemState:
    """Complete state of an ELECTROCOMBUSTION system at one instant."""

    time: float = 0.0
    electrical: ElectricalState = field(default_factory=ElectricalState)
    thermal: ThermalState = field(default_factory=ThermalState)
    chemical: ChemicalState = field(default_factory=ChemicalState)
    mechanical: MechanicalState = field(default_factory=MechanicalState)
    ambient_temperature: float = U.T_STANDARD
    ambient_pressure: float = U.P_ATM
    fidelity: Fidelity = Fidelity.STANDARD
    extras: dict[str, Any] = field(default_factory=dict)

    def stored_energy(self, domain: EnergyDomain) -> float:
        """Energy currently held in ``domain`` (J).

        Boundary domains have no meaningful content and return ``0.0``.
        """
        if domain is EnergyDomain.ELECTRICAL:
            return self.electrical.stored_energy
        if domain is EnergyDomain.THERMAL:
            return self.thermal.internal_energy
        if domain is EnergyDomain.MECHANICAL:
            return self.mechanical.kinetic_energy
        if domain is EnergyDomain.CHEMICAL:
            return self.extras.get("chemical_stored_energy", 0.0)
        return 0.0

    def snapshot(self) -> dict[str, Any]:
        """Flat, JSON-friendly dictionary of the whole state."""
        out: dict[str, Any] = {
            "time": self.time,
            "ambient_temperature": self.ambient_temperature,
            "ambient_pressure": self.ambient_pressure,
            "fidelity": self.fidelity.value,
        }
        for prefix, sub in (
            ("electrical", self.electrical), ("thermal", self.thermal),
            ("chemical", self.chemical), ("mechanical", self.mechanical),
        ):
            for key, value in sub.as_dict().items():
                out[f"{prefix}.{key}"] = value
        for key, value in self.extras.items():
            if isinstance(value, (int, float, bool, str)):
                out[f"extras.{key}"] = value
        return out

    def copy(self) -> "SystemState":
        return SystemState(
            time=self.time,
            electrical=replace(self.electrical),
            thermal=replace(self.thermal),
            chemical=replace(self.chemical),
            mechanical=replace(self.mechanical),
            ambient_temperature=self.ambient_temperature,
            ambient_pressure=self.ambient_pressure,
            fidelity=self.fidelity,
            extras=dict(self.extras),
        )


class ConservationError(RuntimeError):
    """Raised when energy accounting falls outside the configured tolerance."""


@dataclass(slots=True)
class EnergyLedger:
    """Cumulative energy accounting across all domains.

    The ledger integrates :class:`PowerFlow` records and tracks, per domain:
    energy in, energy out, and the implied stored content.  It also keeps
    per-(source, target) totals so an energy waterfall can be produced.
    """

    energy_in: dict[EnergyDomain, float] = field(default_factory=dict)
    energy_out: dict[EnergyDomain, float] = field(default_factory=dict)
    transfers: dict[tuple[EnergyDomain, EnergyDomain], float] = field(default_factory=dict)
    labelled: dict[str, float] = field(default_factory=dict)
    elapsed: float = 0.0

    def __post_init__(self) -> None:
        for domain in EnergyDomain:
            self.energy_in.setdefault(domain, 0.0)
            self.energy_out.setdefault(domain, 0.0)

    # -- accumulation -------------------------------------------------------
    def accumulate(self, flows: Iterable[PowerFlow], dt: float) -> None:
        """Integrate a set of flows over ``dt`` seconds."""
        if dt < 0.0:
            raise ValueError("dt must be non-negative")
        for raw in flows:
            flow = raw.normalised()
            energy = flow.watts * dt
            if energy == 0.0:
                continue
            self.energy_out[flow.source] = self.energy_out.get(flow.source, 0.0) + energy
            self.energy_in[flow.target] = self.energy_in.get(flow.target, 0.0) + energy
            key = (flow.source, flow.target)
            self.transfers[key] = self.transfers.get(key, 0.0) + energy
            if flow.label:
                self.labelled[flow.label] = self.labelled.get(flow.label, 0.0) + energy
        self.elapsed += dt

    # -- queries ------------------------------------------------------------
    def net(self, domain: EnergyDomain) -> float:
        """Energy accumulated in ``domain`` (in minus out), in J."""
        return self.energy_in.get(domain, 0.0) - self.energy_out.get(domain, 0.0)

    @property
    def total_input(self) -> float:
        """Energy drawn from unbounded sources (J)."""
        return self.energy_out.get(EnergyDomain.SOURCE, 0.0)

    @property
    def total_losses(self) -> float:
        """Energy rejected to the environment (J)."""
        return self.energy_in.get(EnergyDomain.ENVIRONMENT, 0.0)

    @property
    def total_stored(self) -> float:
        """Net energy retained by internal domains (J)."""
        return sum(self.net(d) for d in INTERNAL_DOMAINS)

    def useful_output(self, domain: EnergyDomain = EnergyDomain.ELECTRICAL) -> float:
        """Energy delivered from ``domain`` to the environment as useful work.

        By default this is *not* the same as losses: a component that delivers
        power to an external load labels it explicitly, and
        :meth:`labelled_total` retrieves it.
        """
        return self.labelled.get("load", 0.0) if domain else 0.0

    def labelled_total(self, label: str) -> float:
        return self.labelled.get(label, 0.0)

    def balance_residual(self, state: SystemState, initial: SystemState) -> float:
        """Absolute mismatch between integrated flows and stored-energy change.

        Returns ``|sum(net domain flows) - sum(actual stored deltas)|`` in J.
        """
        flow_side = sum(self.net(d) for d in INTERNAL_DOMAINS)
        store_side = sum(
            state.stored_energy(d) - initial.stored_energy(d) for d in INTERNAL_DOMAINS
        )
        return abs(flow_side - store_side)

    def check(self, state: SystemState, initial: SystemState,
              rel_tol: float = 1e-6, abs_tol: float = 1e-6) -> None:
        """Raise :class:`ConservationError` if the ledger fails to balance."""
        residual = self.balance_residual(state, initial)
        scale = max(abs(self.total_input), abs(self.total_losses), 1.0)
        if residual > max(abs_tol, rel_tol * scale):
            raise ConservationError(
                f"energy imbalance {residual:.6g} J exceeds tolerance "
                f"(input={self.total_input:.6g} J, losses={self.total_losses:.6g} J)"
            )

    def waterfall(self) -> list[tuple[str, float]]:
        """Ordered (stage, energy) pairs describing the conversion chain."""
        order = [
            (EnergyDomain.SOURCE, EnergyDomain.CHEMICAL, "fuel input"),
            (EnergyDomain.SOURCE, EnergyDomain.ELECTRICAL, "electrical input"),
            (EnergyDomain.SOURCE, EnergyDomain.THERMAL, "heat input"),
            (EnergyDomain.SOURCE, EnergyDomain.MECHANICAL, "shaft input"),
            (EnergyDomain.CHEMICAL, EnergyDomain.THERMAL, "chemical -> thermal"),
            (EnergyDomain.ELECTRICAL, EnergyDomain.THERMAL, "electrical -> thermal"),
            (EnergyDomain.THERMAL, EnergyDomain.MECHANICAL, "thermal -> mechanical"),
            (EnergyDomain.MECHANICAL, EnergyDomain.ELECTRICAL, "mechanical -> electrical"),
            (EnergyDomain.ELECTRICAL, EnergyDomain.MECHANICAL, "electrical -> mechanical"),
            (EnergyDomain.MECHANICAL, EnergyDomain.THERMAL, "mechanical -> thermal"),
            (EnergyDomain.ELECTRICAL, EnergyDomain.CHEMICAL, "electrical -> chemical"),
            (EnergyDomain.THERMAL, EnergyDomain.ENVIRONMENT, "heat rejection"),
            (EnergyDomain.MECHANICAL, EnergyDomain.ENVIRONMENT, "mechanical loss"),
            (EnergyDomain.ELECTRICAL, EnergyDomain.ENVIRONMENT, "electrical out/loss"),
            (EnergyDomain.CHEMICAL, EnergyDomain.ENVIRONMENT, "unburned fuel"),
        ]
        rows: list[tuple[str, float]] = []
        covered: set[tuple[EnergyDomain, EnergyDomain]] = set()
        for src, tgt, name in order:
            covered.add((src, tgt))
            value = self.transfers.get((src, tgt), 0.0)
            if value != 0.0:
                rows.append((name, value))
        # Anything not in the canonical order is still real energy and must not
        # disappear from the report just because it was not anticipated.
        for (src, tgt), value in self.transfers.items():
            if (src, tgt) not in covered and value != 0.0:
                rows.append((f"{src.value} -> {tgt.value}", value))
        return rows

    def as_dict(self) -> dict[str, float]:
        out = {f"in.{d.value}": v for d, v in self.energy_in.items()}
        out.update({f"out.{d.value}": v for d, v in self.energy_out.items()})
        out["total_input"] = self.total_input
        out["total_losses"] = self.total_losses
        out["total_stored"] = self.total_stored
        out["elapsed"] = self.elapsed
        return out

    def __iter__(self) -> Iterator[tuple[str, float]]:
        return iter(self.waterfall())


def domain_balance(flows, domain: EnergyDomain) -> float:
    """Net power (W) entering ``domain`` across a set of flows."""
    net = 0.0
    for raw in flows:
        flow = raw.normalised()
        if flow.target is domain:
            net += flow.watts
        if flow.source is domain:
            net -= flow.watts
    return net


def component_balance_residual(flows, storage_rate: float = 0.0) -> float:
    """Residual of a component's own power balance, in watts.

    A component emits flows that leave one domain and enter another.  Summed
    over *all* domains the flows cancel identically, so the meaningful check is
    against the component's declared internal storage rate: the net power
    entering the internal (non-boundary) domains must equal the rate at which
    the component accumulates energy.
    """
    net_internal = sum(domain_balance(flows, d) for d in INTERNAL_DOMAINS)
    return net_internal - storage_rate


def flows_balance(flows, storage_rate: float = 0.0, tol: float = 1e-9) -> bool:
    """``True`` when :func:`component_balance_residual` is within ``tol``."""
    return abs(component_balance_residual(flows, storage_rate)) <= tol
