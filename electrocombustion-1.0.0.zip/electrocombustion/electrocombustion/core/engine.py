"""The ELECTROCOMBUSTION engine: orchestration, integration and accounting.

The engine owns the :class:`SystemState`, the component graph, the energy
ledger and the event bus.  It advances the system in time using an explicit
integrator, applying every component's derivative contributions and recording
every power flow.

Integration scheme
------------------
``euler``  first order, one evaluation per step.
``heun``   second order, two evaluations, trapezoidal energy accounting.
``rk4``    classical fourth order, four evaluations, Butcher-weighted energy
           accounting so the ledger stays consistent with the integrated state.

Energy accounting under multi-stage integration uses the same Butcher weights
as the state update.  For the thermal domain (whose stored energy is linear in
temperature) this makes conservation *exact* to machine precision; for the
mechanical domain (kinetic energy is quadratic in speed) a small residual of
the same order as the integrator's local truncation error remains, and the
engine reports it rather than hiding it.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable, Mapping, Sequence

from .component import Component, ComponentGroup, ComponentOutput, Context, Derivatives
from .events import Event, EventBus, Severity, Threshold
from .state import (
    ConservationError, EnergyDomain, EnergyLedger, Fidelity, INTERNAL_DOMAINS,
    PowerFlow, SystemState,
)
from .timestep import AdaptiveTimestep, FixedTimestep, TimestepController

#: Butcher tableaux for the supported explicit schemes: (nodes, weights)
_SCHEMES: dict[str, tuple[tuple[float, ...], tuple[float, ...]]] = {
    "euler": ((0.0,), (1.0,)),
    "heun": ((0.0, 1.0), (0.5, 0.5)),
    "rk4": ((0.0, 0.5, 0.5, 1.0), (1.0 / 6, 1.0 / 3, 1.0 / 3, 1.0 / 6)),
}


@dataclass(slots=True)
class EngineConfig:
    """Engine-level numerical and reporting configuration."""

    scheme: str = "rk4"
    fidelity: Fidelity = Fidelity.STANDARD
    check_conservation: bool = True
    conservation_rel_tol: float = 1e-4
    conservation_abs_tol: float = 1e-6
    raise_on_imbalance: bool = False
    min_temperature: float = 1.0        # K, floor to keep property models valid
    max_temperature: float = 6000.0     # K, ceiling before the model is nonsense
    record_history: bool = True
    history_stride: int = 1

    def __post_init__(self) -> None:
        if self.scheme not in _SCHEMES:
            raise ValueError(
                f"unknown scheme {self.scheme!r}; choose from {sorted(_SCHEMES)}"
            )
        if self.history_stride < 1:
            raise ValueError("history_stride must be >= 1")


@dataclass(slots=True)
class StepReport:
    """Diagnostics from a single accepted step."""

    time: float
    dt: float
    flows: list[PowerFlow]
    diagnostics: dict[str, Any]
    severity: Severity
    conservation_residual: float
    derivatives: Derivatives


class ElectroCombustionEngine:
    """Top-level simulation engine.

    Parameters
    ----------
    state:
        Initial :class:`SystemState`.  Copied on construction.
    components:
        Physical models to evaluate each step.
    config:
        :class:`EngineConfig` controlling integration and accounting.
    """

    def __init__(self, state: SystemState | None = None,
                 components: Sequence[Component] = (),
                 config: EngineConfig | None = None,
                 bus: EventBus | None = None) -> None:
        self.config = config or EngineConfig()
        self.state = (state.copy() if state is not None else SystemState())
        self.state.fidelity = self.config.fidelity
        self.initial_state = self.state.copy()
        self.root = ComponentGroup("root", components)
        self.bus = bus or EventBus()
        self.ledger = EnergyLedger()
        self.thresholds: list[tuple[Threshold, Callable[[SystemState], float]]] = []
        self.history: list[dict[str, Any]] = []
        self.reports: list[StepReport] = []
        self.step_count = 0
        self._initialised = False
        self._last_output: ComponentOutput | None = None

    # ------------------------------------------------------------------
    # composition
    # ------------------------------------------------------------------
    def add(self, component: Component) -> Component:
        """Register a component and return it for chaining."""
        self.root.add(component)
        return component

    def add_all(self, components: Iterable[Component]) -> "ElectroCombustionEngine":
        for c in components:
            self.add(c)
        return self

    def get(self, name: str) -> Component:
        for c in self.root:
            if c.name == name:
                return c
        raise KeyError(f"no component named {name!r}")

    def add_threshold(self, threshold: Threshold,
                      accessor: Callable[[SystemState], float]) -> Threshold:
        """Attach an operating limit evaluated after every step."""
        self.thresholds.append((threshold, accessor))
        return threshold

    # ------------------------------------------------------------------
    # evaluation
    # ------------------------------------------------------------------
    def _context(self, inputs: Mapping[str, float] | None,
                 speculative: bool = False) -> Context:
        return Context(dict(inputs or {}), self.config.fidelity,
                       None if speculative else self.bus, speculative)

    def evaluate(self, state: SystemState, dt: float,
                 context: Context) -> ComponentOutput:
        """Evaluate the whole component graph without mutating anything."""
        return self.root.evaluate(state, dt, context)

    def _apply(self, base: SystemState, derivatives: Derivatives,
               dt: float) -> SystemState:
        """Return a new state advanced by ``dt`` using ``derivatives``."""
        s = base.copy()
        th = s.thermal
        capacity = th.mass * th.cv
        if capacity > 0.0:
            th.temperature = th.temperature + derivatives.heat_input * dt / capacity
        th.temperature = min(self.config.max_temperature,
                             max(self.config.min_temperature, th.temperature))
        th.heat_flow = derivatives.heat_input
        if derivatives.mass_rate:
            th.mass = max(1e-12, th.mass + derivatives.mass_rate * dt)

        mech = s.mechanical
        if mech.inertia > 0.0:
            mech.speed = mech.speed + derivatives.torque * dt / mech.inertia
        mech.torque = derivatives.torque
        mech.angle = mech.angle + mech.speed * dt
        mech.power = mech.torque * mech.speed

        elec = s.electrical
        elec.stored_energy = max(
            0.0, elec.stored_energy + derivatives.electrical_storage_rate * dt)

        chem = s.chemical
        burned = derivatives.fuel_burn_rate * dt
        chem.fuel_mass = max(0.0, chem.fuel_mass - burned)
        chem.burned_mass += max(0.0, burned)
        stored = s.extras.get("chemical_stored_energy", 0.0)
        s.extras["chemical_stored_energy"] = max(
            0.0, stored + derivatives.chemical_storage_rate * dt)

        s.time = base.time + dt
        return s

    # ------------------------------------------------------------------
    # stepping
    # ------------------------------------------------------------------
    def step(self, dt: float, inputs: Mapping[str, float] | None = None) -> StepReport:
        """Advance the system by ``dt`` seconds and return diagnostics."""
        if dt <= 0.0:
            raise ValueError("dt must be positive")
        context = self._context(inputs)
        if not self._initialised:
            self.root.initialise(self.state, context)
            self._initialised = True

        nodes, weights = _SCHEMES[self.config.scheme]
        stage_outputs: list[ComponentOutput] = []
        base = self.state
        for node in nodes:
            probe = base if node == 0.0 else self._apply(
                base, stage_outputs[-1].derivatives, node * dt)
            stage_outputs.append(self.evaluate(probe, dt, context))

        total_derivatives = Derivatives()
        for weight, out in zip(weights, stage_outputs):
            total_derivatives = total_derivatives + out.derivatives.scaled(weight)

        weighted_flows = _blend_flows(stage_outputs, weights)

        before = self.state
        self.state = self._apply(before, total_derivatives, dt)
        self.ledger.accumulate(weighted_flows, dt)

        residual = _step_residual(before, self.state, weighted_flows, dt)
        severity = Severity.worst(o.severity for o in stage_outputs)
        severity = Severity.worst((severity, self._check_thresholds()))
        self._publish(stage_outputs, residual, dt)

        report = StepReport(
            time=self.state.time, dt=dt, flows=weighted_flows,
            diagnostics=dict(stage_outputs[-1].diagnostics), severity=severity,
            conservation_residual=residual, derivatives=total_derivatives,
        )
        self.reports.append(report)
        self._last_output = stage_outputs[-1]
        self.step_count += 1
        if self.config.record_history and self.step_count % self.config.history_stride == 0:
            self.history.append(self.snapshot())
        return report

    def _publish(self, outputs: Sequence[ComponentOutput], residual: float,
                 dt: float) -> None:
        """Emit events raised anywhere in the step, then check conservation.

        A multi-stage scheme evaluates every component several times per step.
        Publishing only the final stage loses any one-shot event raised
        earlier -- a fault that announces itself on first evaluation would
        never reach the bus under RK4.  Events are therefore collected across
        all stages and de-duplicated within the step, so a one-shot event is
        published exactly once and a repeated one is not multiplied by the
        stage count.
        """
        seen: set[tuple[str, str, str]] = set()
        for output in outputs:
            for event in output.events:
                key = (event.kind, event.source, event.message)
                if key in seen:
                    continue
                seen.add(key)
                self.bus.emit(event)
        if not self.config.check_conservation:
            return
        scale = max(abs(self.ledger.total_input), abs(self.ledger.total_losses), 1.0)
        tol = max(self.config.conservation_abs_tol,
                  self.config.conservation_rel_tol * scale)
        if residual > tol:
            message = (f"energy residual {residual:.4g} J exceeds tolerance "
                       f"{tol:.4g} J over dt={dt:.4g} s")
            self.bus.publish(self.state.time, "conservation", message,
                             Severity.WARNING, "engine", residual=residual, tolerance=tol)
            if self.config.raise_on_imbalance:
                raise ConservationError(message)

    def _check_thresholds(self) -> Severity:
        worst = Severity.NORMAL
        for threshold, accessor in self.thresholds:
            value = accessor(self.state)
            severity = threshold.classify(value)
            if severity is not Severity.NORMAL:
                self.bus.publish(
                    self.state.time, "threshold",
                    f"{threshold.name}={value:.6g}{threshold.units} is {severity.value}",
                    severity, "engine", threshold=threshold.name, value=value,
                    margin=threshold.margin(value))
            if severity.rank > worst.rank:
                worst = severity
        return worst

    def run(self, duration: float, dt: float,
            inputs: Mapping[str, float] | Callable[[float, SystemState], Mapping[str, float]] | None = None,
            controller: Any | None = None) -> "RunResult":
        """Advance the system for ``duration`` seconds in steps of ``dt``.

        ``inputs`` may be a static mapping or a callable ``(t, state) -> mapping``
        allowing time-varying commands.  ``controller``, if given, must expose
        ``update(state, dt) -> Mapping[str, float]`` and its output is merged
        over ``inputs``.
        """
        if duration < 0.0:
            raise ValueError("duration must be non-negative")
        n_steps = int(math.floor(duration / dt + 1e-9))
        remainder = duration - n_steps * dt
        start_time = self.state.time
        for i in range(n_steps):
            self._step_with(inputs, controller, dt)
        if remainder > 1e-12:
            self._step_with(inputs, controller, remainder)
        return RunResult(self, start_time, self.state.time)

    def _step_with(self, inputs, controller, dt: float) -> StepReport:
        commanded: dict[str, float] = {}
        if callable(inputs):
            commanded.update(inputs(self.state.time, self.state))
        elif inputs:
            commanded.update(inputs)
        if controller is not None:
            commanded.update(controller.update(self.state, dt))
        return self.step(dt, commanded)

    def run_adaptive(self, duration: float,
                     controller: TimestepController | None = None,
                     inputs: Mapping[str, float] | None = None,
                     error_estimator: Callable[[SystemState, SystemState], float] | None = None,
                     ) -> "RunResult":
        """Advance using an adaptive timestep driven by step doubling.

        The error estimate compares one full step against two half steps of the
        configured scheme, normalised by ``error_estimator`` (default: relative
        temperature and speed change).
        """
        stepper = controller or AdaptiveTimestep(1e-3)
        estimator = error_estimator or _default_error_estimator
        start_time = self.state.time
        target = start_time + duration
        guard = 0
        while self.state.time < target - 1e-12:
            guard += 1
            if guard > 2_000_000:  # pragma: no cover - runaway guard
                raise RuntimeError("adaptive stepping failed to reach the end time")
            dt = min(stepper.propose(), target - self.state.time)
            snapshot = self.state.copy()
            ledger_snapshot = _copy_ledger(self.ledger)
            coarse = self._trial(snapshot, dt, inputs)
            half = self._trial(snapshot, dt / 2.0, inputs)
            fine = self._trial(half, dt / 2.0, inputs)
            error = estimator(coarse, fine)
            result = stepper.report(error)
            if result.accepted:
                self.state = snapshot
                self.ledger = ledger_snapshot
                self._step_with(inputs, None, dt)
            else:
                self.state = snapshot
                self.ledger = ledger_snapshot
        return RunResult(self, start_time, self.state.time)

    def _trial(self, state: SystemState, dt: float,
               inputs: Mapping[str, float] | None) -> SystemState:
        """Speculatively advance ``state`` without touching engine bookkeeping."""
        context = self._context(inputs, speculative=True)
        nodes, weights = _SCHEMES[self.config.scheme]
        stage_outputs: list[ComponentOutput] = []
        for node in nodes:
            probe = state if node == 0.0 else self._apply(
                state, stage_outputs[-1].derivatives, node * dt)
            stage_outputs.append(self.evaluate(probe, dt, context))
        total = Derivatives()
        for weight, out in zip(weights, stage_outputs):
            total = total + out.derivatives.scaled(weight)
        return self._apply(state, total, dt)

    # ------------------------------------------------------------------
    # reporting
    # ------------------------------------------------------------------
    def snapshot(self) -> dict[str, Any]:
        snap = self.state.snapshot()
        snap["ledger.input"] = self.ledger.total_input
        snap["ledger.losses"] = self.ledger.total_losses
        snap["ledger.stored"] = self.ledger.total_stored
        if self._last_output is not None:
            for key, value in self._last_output.diagnostics.items():
                if isinstance(value, (int, float, bool)):
                    snap[f"diag.{key}"] = value
        return snap

    def energy_summary(self) -> dict[str, float]:
        """Headline energy figures for the run so far (J)."""
        return {
            "input": self.ledger.total_input,
            "losses": self.ledger.total_losses,
            "stored": self.ledger.total_stored,
            "delivered": self.ledger.labelled_total("load"),
            "residual": self.ledger.balance_residual(self.state, self.initial_state),
        }

    def efficiency(self) -> float:
        """Delivered useful energy divided by total energy input (0..1).

        Returns ``0.0`` when no energy has been drawn, rather than raising, so
        that this is safe to call inside optimisation loops.
        """
        total_in = self.ledger.total_input
        if total_in <= 0.0:
            return 0.0
        return self.ledger.labelled_total("load") / total_in

    def reset(self, state: SystemState | None = None) -> None:
        """Return the engine to its initial (or a supplied) state."""
        self.state = (state.copy() if state is not None else self.initial_state.copy())
        self.ledger = EnergyLedger()
        self.history.clear()
        self.reports.clear()
        self.bus.clear()
        self.step_count = 0
        self._initialised = False
        self._last_output = None

    def describe(self) -> dict[str, Any]:
        return {"config": {"scheme": self.config.scheme,
                           "fidelity": self.config.fidelity.value},
                "components": [c.describe() for c in self.root]}

    def __repr__(self) -> str:
        return (f"ElectroCombustionEngine(t={self.state.time:.4g}s, "
                f"components={len(self.root)}, steps={self.step_count})")


@dataclass(slots=True)
class RunResult:
    """Handle to the outcome of a :meth:`ElectroCombustionEngine.run` call."""

    engine: "ElectroCombustionEngine"
    t_start: float
    t_end: float

    @property
    def duration(self) -> float:
        return self.t_end - self.t_start

    @property
    def state(self) -> SystemState:
        return self.engine.state

    @property
    def ledger(self) -> EnergyLedger:
        return self.engine.ledger

    @property
    def history(self) -> list[dict[str, Any]]:
        return self.engine.history

    def severity(self) -> Severity:
        return self.engine.bus.worst_severity()

    def summary(self) -> dict[str, Any]:
        out = self.engine.energy_summary()
        out["duration"] = self.duration
        out["steps"] = self.engine.step_count
        out["severity"] = self.severity().value
        return out

    def series(self, key: str) -> list[float]:
        """Extract one recorded signal from the history."""
        return [row[key] for row in self.engine.history if key in row]


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def _blend_flows(outputs: Sequence[ComponentOutput],
                 weights: Sequence[float]) -> list[PowerFlow]:
    """Combine stage flows using the integrator's Butcher weights.

    Flows are keyed by (source, target, label, component) so that the waterfall
    keeps its resolution instead of collapsing into a single aggregate number.
    """
    accumulator: dict[tuple[Any, ...], float] = {}
    for weight, out in zip(weights, outputs):
        for raw in out.flows:
            flow = raw.normalised()
            key = (flow.source, flow.target, flow.label, flow.component)
            accumulator[key] = accumulator.get(key, 0.0) + weight * flow.watts
    blended: list[PowerFlow] = []
    for (source, target, label, component), watts in accumulator.items():
        if watts != 0.0:
            blended.append(PowerFlow(source, target, watts, label, component))
    return blended


def _step_residual(before: SystemState, after: SystemState,
                   flows: Sequence[PowerFlow], dt: float) -> float:
    """Mismatch between integrated flows and the realised stored-energy change."""
    flow_side = 0.0
    for domain in INTERNAL_DOMAINS:
        for raw in flows:
            flow = raw.normalised()
            if flow.target is domain:
                flow_side += flow.watts * dt
            if flow.source is domain:
                flow_side -= flow.watts * dt
    store_side = sum(after.stored_energy(d) - before.stored_energy(d)
                     for d in INTERNAL_DOMAINS)
    return abs(flow_side - store_side)


def _copy_ledger(ledger: EnergyLedger) -> EnergyLedger:
    clone = EnergyLedger()
    clone.energy_in = dict(ledger.energy_in)
    clone.energy_out = dict(ledger.energy_out)
    clone.transfers = dict(ledger.transfers)
    clone.labelled = dict(ledger.labelled)
    clone.elapsed = ledger.elapsed
    return clone


def _default_error_estimator(coarse: SystemState, fine: SystemState) -> float:
    """Normalised step-doubling error over temperature and shaft speed."""
    dt_err = abs(coarse.thermal.temperature - fine.thermal.temperature)
    dw_err = abs(coarse.mechanical.speed - fine.mechanical.speed)
    t_scale = max(abs(fine.thermal.temperature), 1.0)
    w_scale = max(abs(fine.mechanical.speed), 1.0)
    # tolerance folded in: 1e-4 relative is "error == 1"
    return max(dt_err / (1e-4 * t_scale), dw_err / (1e-4 * w_scale))
