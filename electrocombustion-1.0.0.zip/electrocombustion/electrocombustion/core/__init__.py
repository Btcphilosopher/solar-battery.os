"""Core abstractions: units, state, components, events, stepping, engine."""
from .units import (
    Quantity, UnitError, as_si, compatible, convert, dimension_of, from_si,
    to_si, known_units,
    R_UNIVERSAL, STEFAN_BOLTZMANN, P_ATM, T_STANDARD, ZERO_CELSIUS,
    celsius_to_kelvin, kelvin_to_celsius,
)
from .state import (
    ChemicalState, ConservationError, ElectricalState, EnergyDomain,
    EnergyLedger, Fidelity, INTERNAL_DOMAINS, MechanicalState, PowerFlow,
    SystemState, ThermalState, component_balance_residual, domain_balance,
    flows_balance,
)
from .events import Event, EventBus, Severity, Threshold
from .timestep import (
    AdaptiveTimestep, ConvergenceCriteria, FixedTimestep, ScheduledTimestep,
    TimeGrid, TimestepController, TimestepResult,
)
from .component import (
    CallableComponent, Component, ComponentGroup, ComponentOutput, Context,
    Derivatives,
)
from .engine import (
    ElectroCombustionEngine, EngineConfig, RunResult, StepReport,
)

__all__ = [
    "Quantity", "UnitError", "as_si", "compatible", "convert",
    "dimension_of", "from_si", "to_si",
    "known_units", "R_UNIVERSAL", "STEFAN_BOLTZMANN", "P_ATM", "T_STANDARD",
    "ZERO_CELSIUS", "celsius_to_kelvin", "kelvin_to_celsius",
    "ChemicalState", "ConservationError", "ElectricalState", "EnergyDomain",
    "EnergyLedger", "Fidelity", "INTERNAL_DOMAINS", "MechanicalState",
    "PowerFlow", "SystemState", "ThermalState", "component_balance_residual",
    "domain_balance", "flows_balance",
    "Event", "EventBus", "Severity", "Threshold",
    "AdaptiveTimestep", "ConvergenceCriteria", "FixedTimestep",
    "ScheduledTimestep", "TimeGrid", "TimestepController", "TimestepResult",
    "CallableComponent", "Component", "ComponentGroup", "ComponentOutput",
    "Context", "Derivatives",
    "ElectroCombustionEngine", "EngineConfig", "RunResult", "StepReport",
]
