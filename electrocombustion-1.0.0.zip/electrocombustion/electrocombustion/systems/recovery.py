"""Waste-heat recovery: ORC, thermoelectric and recuperative devices."""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Literal

from ..core import units as U
from ..core.component import Component, ComponentOutput, Context, Derivatives
from ..core.events import Event, Severity
from ..core.state import EnergyDomain, PowerFlow, SystemState
from ..mechanical.efficiency import carnot_efficiency
from ..thermal.heat_transfer import HeatExchanger


@dataclass(slots=True)
class RecoverySpec:
    """A heat-to-power recovery device.

    ``carnot_fraction`` is the fraction of the Carnot limit the device
    achieves.  Representative values: 0.45-0.60 for a well-designed organic
    Rankine cycle, 0.05-0.12 for a thermoelectric generator, 0.55-0.70 for a
    steam bottoming cycle.  Expressing it this way makes the second-law
    assumption explicit instead of hiding it in a single efficiency number.
    """

    name: str = "recovery"
    kind: Literal["orc", "thermoelectric", "steam", "recuperator"] = "orc"
    carnot_fraction: float = 0.5
    cold_temperature: float = 303.15
    minimum_source_temperature: float = 350.0
    maximum_heat: float = 1e6
    parasitic_power: float = 0.0
    heat_exchanger: HeatExchanger | None = None

    def __post_init__(self) -> None:
        if not 0.0 < self.carnot_fraction <= 1.0:
            raise ValueError("carnot fraction must lie in (0, 1]")
        if self.cold_temperature <= 0.0:
            raise ValueError("cold-side temperature must be positive")


class WasteHeatRecovery:
    """Converts a rejected heat stream into useful power."""

    def __init__(self, spec: RecoverySpec | None = None) -> None:
        self.spec = spec or RecoverySpec()

    def conversion_efficiency(self, source_temperature: float) -> float:
        """Heat-to-power efficiency at the given source temperature (0..1)."""
        spec = self.spec
        if source_temperature <= spec.minimum_source_temperature:
            return 0.0
        limit = carnot_efficiency(source_temperature, spec.cold_temperature)
        if spec.kind == "recuperator":
            return 0.0
        return limit * spec.carnot_fraction

    def heat_captured(self, available_heat: float,
                      source_temperature: float) -> float:
        """Heat actually drawn into the recovery device (W)."""
        if source_temperature <= self.spec.minimum_source_temperature:
            return 0.0
        return min(max(0.0, available_heat), self.spec.maximum_heat)

    def power(self, available_heat: float, source_temperature: float) -> float:
        """Net power produced after parasitics (W).

        Returns zero rather than a negative number when parasitics exceed the
        gross output; a device that consumes more than it makes should be
        reported as producing nothing, and the parasitic draw is still visible
        via :meth:`breakdown`.
        """
        captured = self.heat_captured(available_heat, source_temperature)
        gross = captured * self.conversion_efficiency(source_temperature)
        return max(0.0, gross - self.spec.parasitic_power)

    def breakdown(self, available_heat: float,
                  source_temperature: float) -> dict[str, float]:
        captured = self.heat_captured(available_heat, source_temperature)
        eta = self.conversion_efficiency(source_temperature)
        gross = captured * eta
        net = max(0.0, gross - self.spec.parasitic_power)
        return {
            "available": available_heat, "captured": captured,
            "efficiency": eta, "gross_power": gross,
            "parasitic": self.spec.parasitic_power, "net_power": net,
            "rejected": captured - gross,
            "carnot_limit": carnot_efficiency(source_temperature,
                                              self.spec.cold_temperature)
            if source_temperature > self.spec.cold_temperature else 0.0,
        }

    def payback_temperature(self, tolerance: float = 1e-6) -> float:
        """Lowest source temperature at which net output is positive (K).

        Below this the parasitic load exceeds the gross production and the
        device is a net consumer.
        """
        if self.spec.parasitic_power <= 0.0:
            return self.spec.minimum_source_temperature
        lo = self.spec.minimum_source_temperature
        hi = max(lo * 4.0, 3000.0)
        heat = self.spec.maximum_heat
        if self.power(heat, hi) <= 0.0:
            return math.inf
        for _ in range(200):
            mid = 0.5 * (lo + hi)
            if self.power(heat, mid) > 0.0:
                hi = mid
            else:
                lo = mid
            if hi - lo < tolerance:
                break
        return 0.5 * (lo + hi)


class RecoveryComponent(Component):
    """Recovers heat from the thermal domain into the electrical domain."""

    order = 78

    def __init__(self, name: str, recovery: WasteHeatRecovery | None = None,
                 heat_available: float | None = None,
                 input_key: str | None = None) -> None:
        super().__init__(name)
        self.recovery = recovery or WasteHeatRecovery()
        self.heat_available = heat_available
        self.input_key = input_key or f"{name}.heat"

    def evaluate(self, state: SystemState, dt: float,
                 context: Context) -> ComponentOutput:
        temperature = state.thermal.temperature
        if self.heat_available is not None:
            available = self.heat_available
        else:
            available = context.get(self.input_key,
                                    self.recovery.spec.maximum_heat)
        result = self.recovery.breakdown(available, temperature)
        captured = result["captured"]
        net = result["net_power"]
        rejected = captured - net
        flows: list[PowerFlow] = []
        if net > 0.0:
            flows.append(PowerFlow(EnergyDomain.THERMAL, EnergyDomain.ELECTRICAL,
                                   net, "recovered power", self.name))
        if rejected > 0.0:
            flows.append(PowerFlow(EnergyDomain.THERMAL, EnergyDomain.ENVIRONMENT,
                                   rejected, "recovery rejection", self.name))
        return ComponentOutput(
            flows=flows,
            derivatives=Derivatives(heat_input=-captured),
            diagnostics={f"{self.name}.{k}": v for k, v in result.items()},
        )
