"""Electrical heating systems with thermal feedback."""
from __future__ import annotations

import math
from dataclasses import dataclass, field

from ..core import units as U
from ..core.component import Component, ComponentOutput, Context, Derivatives
from ..core.events import Event, Severity
from ..core.state import EnergyDomain, PowerFlow, SystemState
from ..electrical.resistance import Geometry, Resistor
from ..electrical.voltage import VoltageSource
from ..materials.material import Material
from ..thermal.convection import ConvectionSurface
from ..thermal.radiation import RadiatingSurface


@dataclass(slots=True)
class HeaterSpec:
    """Design of a resistive heating element."""

    name: str = "heater"
    material: Material | None = None
    length: float = 5.0
    diameter: float = 1e-3
    supply_voltage: float = 230.0
    target_power: float | None = None
    max_temperature: float = 1200.0
    emissivity: float | None = None

    def __post_init__(self) -> None:
        if self.material is None:
            raise ValueError("a heater spec must name a material")
        if self.length <= 0.0 or self.diameter <= 0.0:
            raise ValueError("length and diameter must be positive")

    def geometry(self) -> Geometry:
        return Geometry.wire(self.length, self.diameter)

    def resistor(self) -> Resistor:
        assert self.material is not None
        return Resistor(self.name, material=self.material,
                        geometry=self.geometry())

    def cold_resistance(self, temperature: float = 293.15) -> float:
        return self.resistor().value(temperature)

    def cold_power(self) -> float:
        return self.supply_voltage ** 2 / self.cold_resistance()

    def length_for_power(self, power: float, temperature: float = 293.15,
                         tolerance: float = 1e-9) -> float:
        """Element length that yields ``power`` watts at ``temperature``.

        Because resistance is proportional to length, this has a closed form:
        ``L = V^2 A / (P rho)``.
        """
        assert self.material is not None
        if power <= 0.0:
            raise ValueError("target power must be positive")
        area = math.pi * (self.diameter / 2.0) ** 2
        rho = self.material.rho_e(temperature)
        return self.supply_voltage ** 2 * area / (power * rho)


class ElectricHeaterSystem:
    """A resistive heater with its own surface losses.

    Bundles the element, its convective and radiative surfaces, and provides
    the steady-state solution: the temperature at which the electrical input
    equals the surface loss, accounting for the resistance rising with
    temperature.
    """

    def __init__(self, spec: HeaterSpec, ambient: float = 298.15,
                 convection_coefficient: float = 15.0) -> None:
        self.spec = spec
        self.resistor = spec.resistor()
        self.ambient = ambient
        geometry = spec.geometry()
        assert geometry.surface_area is not None
        emissivity = (spec.emissivity if spec.emissivity is not None
                      else (spec.material.eps() if spec.material else 0.9))
        self.convection = ConvectionSurface(
            area=geometry.surface_area,
            characteristic_length=spec.diameter,
            coefficient=convection_coefficient, mode="fixed")
        self.radiation = RadiatingSurface(area=geometry.surface_area,
                                          emissivity=emissivity)

    def electrical_power(self, temperature: float, duty: float = 1.0) -> float:
        resistance = self.resistor.value(temperature)
        voltage_squared = self.spec.supply_voltage ** 2 * min(1.0, max(0.0, duty))
        return voltage_squared / resistance

    def loss(self, temperature: float) -> float:
        return (self.convection.heat_flow(temperature, self.ambient)
                + self.radiation.heat_flow(temperature, self.ambient))

    def steady_temperature(self, duty: float = 1.0,
                           bracket: tuple[float, float] = (200.0, 4000.0),
                           tolerance: float = 1e-6) -> float:
        """Equilibrium temperature where input power equals surface loss.

        Solved by bisection on ``P_in(T) - P_loss(T)``, which is monotonically
        decreasing because losses grow faster than the resistive power falls.
        """
        lo, hi = bracket
        f = lambda t: self.electrical_power(t, duty) - self.loss(t)
        f_lo, f_hi = f(lo), f(hi)
        if f_lo * f_hi > 0.0:
            raise ValueError(
                f"{self.spec.name}: no equilibrium between {lo:g} and {hi:g} K "
                f"(residual {f_lo:g} .. {f_hi:g} W)"
            )
        for _ in range(300):
            mid = 0.5 * (lo + hi)
            f_mid = f(mid)
            if abs(f_mid) < tolerance or (hi - lo) < tolerance:
                return mid
            if f_lo * f_mid <= 0.0:
                hi, f_hi = mid, f_mid
            else:
                lo, f_lo = mid, f_mid
        return 0.5 * (lo + hi)  # pragma: no cover

    def duty_for_temperature(self, target: float,
                             tolerance: float = 1e-6) -> float:
        """Duty cycle whose equilibrium temperature is ``target``.

        Closed form: at equilibrium ``V^2 D / R(T) = Q_loss(T)``.
        """
        loss = self.loss(target)
        if loss <= 0.0:
            return 0.0
        resistance = self.resistor.value(target)
        duty = loss * resistance / self.spec.supply_voltage ** 2
        return min(1.0, max(0.0, duty))

    def exceeds_service_limit(self, temperature: float) -> bool:
        assert self.spec.material is not None
        return not self.spec.material.within_service_limit(temperature)


class HeaterComponent(Component):
    """Engine component wrapping :class:`ElectricHeaterSystem`."""

    order = 10

    def __init__(self, name: str, system: ElectricHeaterSystem,
                 duty: float = 1.0, input_key: str | None = None) -> None:
        super().__init__(name)
        self.system = system
        self.duty = float(duty)
        self.input_key = input_key or f"{name}.duty"

    def evaluate(self, state: SystemState, dt: float,
                 context: Context) -> ComponentOutput:
        duty = min(1.0, max(0.0, context.get(self.input_key, self.duty)))
        temperature = state.thermal.temperature
        power = self.system.electrical_power(temperature, duty)
        loss = self.system.loss(temperature)
        flows = [
            PowerFlow(EnergyDomain.SOURCE, EnergyDomain.ELECTRICAL, power,
                      "electrical input", self.name),
            PowerFlow(EnergyDomain.ELECTRICAL, EnergyDomain.THERMAL, power,
                      "joule heating", self.name),
        ]
        if loss >= 0.0:
            flows.append(PowerFlow(EnergyDomain.THERMAL, EnergyDomain.ENVIRONMENT,
                                   loss, "surface loss", self.name))
        else:
            flows.append(PowerFlow(EnergyDomain.SOURCE, EnergyDomain.THERMAL,
                                   -loss, "ambient heat gain", self.name))
        over = self.system.exceeds_service_limit(temperature)
        return ComponentOutput(
            flows=flows,
            derivatives=Derivatives(heat_input=power - loss),
            diagnostics={f"{self.name}.power": power,
                         f"{self.name}.loss": loss,
                         f"{self.name}.duty": duty,
                         f"{self.name}.resistance":
                             self.system.resistor.value(temperature)},
            severity=Severity.LIMIT if over else Severity.NORMAL,
            events=[Event(state.time, "over_temperature",
                          f"{self.name} above material service limit",
                          Severity.LIMIT, self.name)] if over else [],
        )
