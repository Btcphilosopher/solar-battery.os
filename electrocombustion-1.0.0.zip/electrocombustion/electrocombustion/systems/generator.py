"""Generator sets: mechanical shaft power to electrical output."""
from __future__ import annotations

import math
from dataclasses import dataclass, field

from ..core import units as U
from ..core.component import Component, ComponentOutput, Context, Derivatives
from ..core.events import Event, Severity
from ..core.state import EnergyDomain, PowerFlow, SystemState
from ..electrical.conversion import LossModel
from ..electrical.machines import ElectricalMachine


@dataclass(slots=True)
class GeneratorSpec:
    """Design parameters of a generator.

    ``rated_power`` and ``rated_speed`` set the operating point at which the
    loss coefficients are normalised.  The loss split follows the usual
    machine breakdown: copper losses scale with the square of load, iron
    losses with speed, and windage with the cube of speed.
    """

    name: str = "generator"
    rated_power: float = 50_000.0
    rated_speed: float = 157.08          # rad/s (1500 rpm)
    rated_voltage: float = 400.0
    peak_efficiency: float = 0.94
    copper_loss_fraction: float = 0.035
    iron_loss_fraction: float = 0.015
    windage_loss_fraction: float = 0.008
    no_load_power: float = 0.0
    power_factor: float = 0.9

    def __post_init__(self) -> None:
        if self.rated_power <= 0.0 or self.rated_speed <= 0.0:
            raise ValueError("rated power and speed must be positive")
        if not 0.0 < self.peak_efficiency < 1.0:
            raise ValueError("peak efficiency must lie in (0, 1)")


class Generator:
    """A speed- and load-dependent generator model.

    Given the shaft power available and the shaft speed, returns the electrical
    power produced and the loss breakdown.  Losses are computed from the
    fractional split at rated conditions and scaled to the actual operating
    point, so the efficiency curve has the correct shape: poor at light load
    (fixed losses dominate) and falling again at overload (copper losses
    dominate).
    """

    def __init__(self, spec: GeneratorSpec | None = None) -> None:
        self.spec = spec or GeneratorSpec()

    def losses(self, shaft_power: float, speed: float) -> dict[str, float]:
        s = self.spec
        load = abs(shaft_power) / s.rated_power
        speed_ratio = abs(speed) / s.rated_speed if s.rated_speed > 0.0 else 0.0
        copper = s.copper_loss_fraction * s.rated_power * load ** 2
        iron = s.iron_loss_fraction * s.rated_power * speed_ratio ** 1.5
        windage = s.windage_loss_fraction * s.rated_power * speed_ratio ** 3
        return {"copper": copper, "iron": iron, "windage": windage,
                "no_load": s.no_load_power,
                "total": copper + iron + windage + s.no_load_power}

    def electrical_power(self, shaft_power: float, speed: float) -> float:
        """Electrical output for a given shaft input (W), never negative."""
        losses = self.losses(shaft_power, speed)["total"]
        return max(0.0, shaft_power - losses)

    def shaft_power_for(self, electrical_power: float, speed: float,
                        tolerance: float = 1e-6) -> float:
        """Shaft power required to deliver ``electrical_power`` (W).

        Inverts the loss model by bisection.  Raises if the requested output
        cannot be produced at this speed at any shaft power, which is the
        honest answer rather than returning a silently clipped number.
        """
        if electrical_power <= 0.0:
            return self.losses(0.0, speed)["total"]
        lo, hi = electrical_power, electrical_power * 4.0 + self.spec.rated_power
        if self.electrical_power(hi, speed) < electrical_power:
            raise ValueError(
                f"{self.spec.name}: cannot deliver {electrical_power:g} W at "
                f"{speed:g} rad/s; maximum is {self.electrical_power(hi, speed):g} W"
            )
        for _ in range(200):
            mid = 0.5 * (lo + hi)
            if abs(self.electrical_power(mid, speed) - electrical_power) < tolerance:
                return mid
            if self.electrical_power(mid, speed) < electrical_power:
                lo = mid
            else:
                hi = mid
        return 0.5 * (lo + hi)

    def efficiency(self, shaft_power: float, speed: float) -> float:
        if shaft_power <= 0.0:
            return 0.0
        return self.electrical_power(shaft_power, speed) / shaft_power

    def terminal_current(self, electrical_power: float,
                         voltage: float | None = None) -> float:
        v = voltage or self.spec.rated_voltage
        denominator = math.sqrt(3.0) * v * self.spec.power_factor
        return electrical_power / denominator if denominator > 0.0 else 0.0

    def load_fraction(self, electrical_power: float) -> float:
        return electrical_power / self.spec.rated_power

    def efficiency_curve(self, points: int = 20,
                         speed: float | None = None) -> list[tuple[float, float]]:
        """Sampled ``(load_fraction, efficiency)`` pairs for reporting."""
        w = speed if speed is not None else self.spec.rated_speed
        out = []
        for i in range(1, points + 1):
            fraction = i / points
            shaft = self.shaft_power_for(fraction * self.spec.rated_power, w)
            out.append((fraction, self.efficiency(shaft, w)))
        return out


class GeneratorComponent(Component):
    """Couples a :class:`Generator` to the engine's shaft and bus.

    Takes a commanded electrical output, converts it to the shaft torque
    required at the present speed, and routes the losses into the thermal
    domain.  If the shaft cannot support the demand the component reports it
    as a LIMIT event rather than silently producing energy from nowhere.
    """

    order = 45

    def __init__(self, name: str, generator: Generator | None = None,
                 demand: float = 0.0, input_key: str | None = None,
                 minimum_speed: float = 1.0) -> None:
        super().__init__(name)
        self.generator = generator or Generator()
        self.demand = float(demand)
        self.input_key = input_key or f"{name}.demand"
        self.minimum_speed = minimum_speed

    def evaluate(self, state: SystemState, dt: float,
                 context: Context) -> ComponentOutput:
        speed = state.mechanical.speed
        requested = max(0.0, context.get(self.input_key, self.demand))
        if speed < self.minimum_speed:
            return ComponentOutput(
                diagnostics={f"{self.name}.electrical_power": 0.0,
                             f"{self.name}.efficiency": 0.0},
                severity=Severity.WARNING if requested > 0.0 else Severity.NORMAL,
                events=[Event(state.time, "generator_stalled",
                              f"{self.name} below minimum speed",
                              Severity.WARNING, self.name)] if requested > 0.0 else [],
            )
        try:
            shaft_power = self.generator.shaft_power_for(requested, speed)
            limited = False
        except ValueError:
            shaft_power = self.generator.spec.rated_power * 4.0
            requested = self.generator.electrical_power(shaft_power, speed)
            limited = True
        losses = shaft_power - requested
        torque = -shaft_power / speed
        flows = [
            PowerFlow(EnergyDomain.MECHANICAL, EnergyDomain.ELECTRICAL,
                      requested, "generator output", self.name),
        ]
        if losses > 0.0:
            flows.append(PowerFlow(EnergyDomain.MECHANICAL, EnergyDomain.THERMAL,
                                   losses, "generator loss", self.name))
        return ComponentOutput(
            flows=flows,
            derivatives=Derivatives(torque=torque, heat_input=losses),
            diagnostics={f"{self.name}.electrical_power": requested,
                         f"{self.name}.shaft_power": shaft_power,
                         f"{self.name}.torque": torque,
                         f"{self.name}.efficiency":
                             self.generator.efficiency(shaft_power, speed),
                         f"{self.name}.load_fraction":
                             self.generator.load_fraction(requested)},
            severity=Severity.LIMIT if limited else Severity.NORMAL,
            events=[Event(state.time, "generator_limit",
                          f"{self.name} at capacity", Severity.LIMIT, self.name)]
            if limited else [],
        )
