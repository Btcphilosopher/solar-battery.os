"""Generic combustion engine models.

The engine here is a *configurable thermodynamic converter*, not a model of a
specific machine.  A cycle model supplies the indicated efficiency, friction
supplies the parasitic torque, and a heat split routes the rejected energy.
Any of the three can be replaced independently.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Callable, Literal

from ..core import units as U
from ..core.component import Component, ComponentOutput, Context, Derivatives
from ..core.events import Event, Severity
from ..core.state import EnergyDomain, PowerFlow, SystemState
from ..combustion.fuel import Fuel
from ..combustion.heat_release import HeatSplit
from ..combustion.mixture import Mixture
from ..mechanical.efficiency import (
    FrictionModel, brayton_efficiency, diesel_efficiency, otto_efficiency,
)


@dataclass(slots=True)
class CycleModel:
    """Air-standard cycle efficiency with a realism derating factor.

    ``kind`` selects the ideal cycle; ``quality`` is the fraction of the ideal
    efficiency actually achieved, capturing finite burn duration, heat
    transfer, blowby and gas exchange.  Typical values are 0.70-0.80 for
    spark-ignition and 0.75-0.85 for compression-ignition engines.  Keeping it
    as an explicit single number is more honest than burying the same derating
    inside a tuned "indicated efficiency" constant.
    """

    kind: Literal["otto", "diesel", "brayton", "constant"] = "otto"
    compression_ratio: float = 10.5
    cutoff_ratio: float = 2.0
    pressure_ratio: float = 12.0
    gamma: float = 1.35
    quality: float = 0.75
    constant_efficiency: float = 0.35

    def __post_init__(self) -> None:
        if not 0.0 < self.quality <= 1.0:
            raise ValueError("cycle quality must lie in (0, 1]")

    @property
    def ideal_efficiency(self) -> float:
        if self.kind == "otto":
            return otto_efficiency(self.compression_ratio, self.gamma)
        if self.kind == "diesel":
            return diesel_efficiency(self.compression_ratio, self.cutoff_ratio,
                                     self.gamma)
        if self.kind == "brayton":
            return brayton_efficiency(self.pressure_ratio, self.gamma)
        if self.kind == "constant":
            return self.constant_efficiency
        raise ValueError(f"unknown cycle {self.kind!r}")

    @property
    def indicated_efficiency(self) -> float:
        """Ideal efficiency after the quality derating."""
        return self.ideal_efficiency * self.quality

    def efficiency_at(self, load_fraction: float, speed_ratio: float = 1.0
                      ) -> float:
        """Indicated efficiency adjusted for part load and speed.

        Efficiency falls at very light load (pumping and heat-transfer losses
        take a larger share) and at very high speed (less time per cycle for
        complete combustion).  The shape factors are generic; replace them with
        a measured map when one is available.
        """
        load = max(0.0, min(2.0, load_fraction))
        load_factor = 1.0 - 0.45 * math.exp(-6.0 * load)
        speed_factor = 1.0 - 0.08 * max(0.0, speed_ratio - 1.0) ** 2
        return self.indicated_efficiency * load_factor * max(0.4, speed_factor)


@dataclass(slots=True)
class EngineSpec:
    """Configuration of a generic combustion engine."""

    name: str = "engine"
    fuel: Fuel | None = None
    rated_power: float = 100_000.0
    rated_speed: float = 314.16
    displacement: float = 2.0e-3
    cycle: CycleModel = field(default_factory=CycleModel)
    friction: FrictionModel = field(default_factory=FrictionModel)
    heat_split: HeatSplit = field(default_factory=HeatSplit)
    equivalence_ratio: float = 1.0
    minimum_speed: float = 50.0

    def __post_init__(self) -> None:
        if self.fuel is None:
            raise ValueError("an engine spec must name a fuel")
        if self.rated_power <= 0.0 or self.rated_speed <= 0.0:
            raise ValueError("rated power and speed must be positive")


class CombustionEngine:
    """A generic fuel-to-shaft converter.

    The chain is: chemical power in -> indicated power (via the cycle model)
    -> brake power (after friction) -> heat rejected to coolant and exhaust.
    Every stage is reported so the waterfall can be drawn.
    """

    def __init__(self, spec: EngineSpec) -> None:
        self.spec = spec

    def chemical_power(self, fuel_flow: float) -> float:
        assert self.spec.fuel is not None
        return fuel_flow * self.spec.fuel.lhv

    def mixture(self, equivalence_ratio: float | None = None) -> Mixture:
        assert self.spec.fuel is not None
        phi = (self.spec.equivalence_ratio if equivalence_ratio is None
               else equivalence_ratio)
        return Mixture(self.spec.fuel, phi)

    def evaluate(self, fuel_flow: float, speed: float,
                 equivalence_ratio: float | None = None) -> dict[str, float]:
        """Full energy breakdown at an operating point.

        Returns chemical, indicated and brake power, friction, the heat split
        and the resulting brake thermal efficiency.
        """
        spec = self.spec
        mixture = self.mixture(equivalence_ratio)
        chemical = self.chemical_power(fuel_flow)
        released = chemical * mixture.combustion_efficiency
        unburned = chemical - released
        load = chemical / spec.rated_power if spec.rated_power > 0.0 else 0.0
        speed_ratio = speed / spec.rated_speed if spec.rated_speed > 0.0 else 0.0
        eta_i = spec.cycle.efficiency_at(load, speed_ratio)
        indicated = released * eta_i
        rejected = released - indicated
        friction_torque = spec.friction.torque(speed)
        friction_power = friction_torque * abs(speed)
        brake = max(0.0, indicated - friction_power)
        split = spec.heat_split.apply(rejected)
        brake_efficiency = brake / chemical if chemical > 0.0 else 0.0
        torque = brake / speed if speed > spec.minimum_speed else 0.0
        return {
            "chemical_power": chemical, "released_power": released,
            "unburned_power": unburned, "indicated_power": indicated,
            "friction_power": friction_power, "brake_power": brake,
            "rejected_power": rejected, "coolant_power": split["coolant"],
            "exhaust_power": split["exhaust"], "other_power": split["other"]
                + split["work"],
            "indicated_efficiency": eta_i,
            "brake_efficiency": brake_efficiency,
            "torque": torque, "equivalence_ratio": mixture.equivalence_ratio,
            "combustion_efficiency": mixture.combustion_efficiency,
        }

    def fuel_for_power(self, brake_power: float, speed: float,
                       tolerance: float = 1e-6) -> float:
        """Fuel flow needed for a target brake power (kg/s).

        Bisects the forward model because the efficiency depends on load.
        Raises when the target exceeds what the engine can produce at this
        speed.
        """
        if brake_power <= 0.0:
            return 0.0
        assert self.spec.fuel is not None
        lo = 0.0
        hi = brake_power * 6.0 / self.spec.fuel.lhv + 1e-6
        for _ in range(60):
            if self.evaluate(hi, speed)["brake_power"] >= brake_power:
                break
            hi *= 2.0
        else:
            raise ValueError(
                f"{self.spec.name}: cannot reach {brake_power:g} W at {speed:g} rad/s"
            )
        for _ in range(200):
            mid = 0.5 * (lo + hi)
            value = self.evaluate(mid, speed)["brake_power"]
            if abs(value - brake_power) < tolerance:
                return mid
            if value < brake_power:
                lo = mid
            else:
                hi = mid
        return 0.5 * (lo + hi)

    def bsfc(self, fuel_flow: float, speed: float) -> float:
        """Brake-specific fuel consumption in g/kWh."""
        brake = self.evaluate(fuel_flow, speed)["brake_power"]
        if brake <= 0.0:
            return math.inf
        return fuel_flow / brake * 3.6e9

    def operating_map(self, fuel_flows: list[float],
                      speeds: list[float]) -> list[dict[str, float]]:
        """Evaluate the engine over a grid of fuel flows and speeds."""
        rows = []
        for flow in fuel_flows:
            for speed in speeds:
                row = self.evaluate(flow, speed)
                row["fuel_flow"] = flow
                row["speed"] = speed
                rows.append(row)
        return rows


class CombustionEngineComponent(Component):
    """Couples a :class:`CombustionEngine` into the simulation graph."""

    order = 25

    def __init__(self, name: str, engine: CombustionEngine,
                 fuel_flow: float = 0.0, fuel_key: str | None = None,
                 phi_key: str | None = None,
                 coolant_to_thermal: bool = True) -> None:
        super().__init__(name)
        self.engine = engine
        self.fuel_flow = float(fuel_flow)
        self.fuel_key = fuel_key or f"{name}.fuel_flow"
        self.phi_key = phi_key or f"{name}.phi"
        self.coolant_to_thermal = coolant_to_thermal

    def evaluate(self, state: SystemState, dt: float,
                 context: Context) -> ComponentOutput:
        flow = max(0.0, context.get(self.fuel_key, self.fuel_flow))
        phi = context.get(self.phi_key, self.engine.spec.equivalence_ratio)
        speed = state.mechanical.speed
        r = self.engine.evaluate(flow, speed, phi)

        flows: list[PowerFlow] = []
        if r["chemical_power"] > 0.0:
            flows.append(PowerFlow(EnergyDomain.SOURCE, EnergyDomain.CHEMICAL,
                                   r["chemical_power"], "fuel input", self.name))
        if r["released_power"] > 0.0:
            flows.append(PowerFlow(EnergyDomain.CHEMICAL, EnergyDomain.THERMAL,
                                   r["released_power"], "heat release", self.name))
        if r["unburned_power"] > 0.0:
            flows.append(PowerFlow(EnergyDomain.CHEMICAL, EnergyDomain.ENVIRONMENT,
                                   r["unburned_power"], "unburned fuel", self.name))
        if r["brake_power"] > 0.0:
            flows.append(PowerFlow(EnergyDomain.THERMAL, EnergyDomain.MECHANICAL,
                                   r["brake_power"], "brake power", self.name))
        if r["friction_power"] > 0.0:
            flows.append(PowerFlow(EnergyDomain.THERMAL, EnergyDomain.ENVIRONMENT,
                                   r["friction_power"], "engine friction", self.name))
        exhaust = r["exhaust_power"]
        if exhaust > 0.0:
            flows.append(PowerFlow(EnergyDomain.THERMAL, EnergyDomain.ENVIRONMENT,
                                   exhaust, "exhaust heat", self.name))

        heat_to_bulk = (r["released_power"] - r["brake_power"]
                        - r["friction_power"] - exhaust)
        torque = r["torque"]
        return ComponentOutput(
            flows=flows,
            derivatives=Derivatives(heat_input=heat_to_bulk, torque=torque,
                                    fuel_burn_rate=flow),
            diagnostics={f"{self.name}.{k}": v for k, v in r.items()},
            severity=Severity.NORMAL,
        )
