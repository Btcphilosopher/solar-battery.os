"""Hybrid systems: combining electrical and combustion power sources."""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Callable, Literal, Sequence

from ..core import units as U
from ..core.component import Component, ComponentOutput, Context, Derivatives
from ..core.events import Event, Severity
from ..core.state import EnergyDomain, PowerFlow, SystemState


@dataclass(slots=True)
class SourceSpec:
    """One power source available to a hybrid controller.

    ``cost`` is an abstract per-joule cost used by the optimal split strategy:
    it can carry money, carbon, fuel mass or any other scalar the caller wants
    minimised.  ``efficiency`` may be a constant or a callable of load
    fraction.
    """

    name: str
    capacity: float
    cost: float = 1.0
    efficiency: float | Callable[[float], float] = 0.9
    minimum: float = 0.0
    ramp_rate: float = math.inf
    available: bool = True

    def __post_init__(self) -> None:
        if self.capacity <= 0.0:
            raise ValueError(f"{self.name}: capacity must be positive")
        if self.minimum < 0.0 or self.minimum > self.capacity:
            raise ValueError(f"{self.name}: minimum must lie in 0..capacity")

    def efficiency_at(self, power: float) -> float:
        fraction = abs(power) / self.capacity
        eta = (self.efficiency(fraction) if callable(self.efficiency)
               else float(self.efficiency))
        return min(1.0, max(1e-6, eta))

    def input_for(self, power: float) -> float:
        """Primary energy rate needed to deliver ``power`` (W)."""
        return abs(power) / self.efficiency_at(power)

    def marginal_cost(self, power: float) -> float:
        """Cost per joule delivered at this operating point."""
        return self.cost / self.efficiency_at(power)


Strategy = Literal["electric_priority", "fuel_priority", "proportional",
                   "optimal_split", "load_following"]


class HybridController:
    """Splits a power demand between several sources.

    The strategies are:

    ``electric_priority``   use the first (electrical) source to its capacity,
                            then the rest in order.
    ``fuel_priority``       the reverse.
    ``proportional``        share in proportion to capacity.
    ``optimal_split``       greedy dispatch by marginal cost, which for convex
                            cost curves is the true optimum and for
                            non-convex ones is a good, explainable heuristic.
    ``load_following``      keep each source near its best-efficiency point.
    """

    def __init__(self, sources: Sequence[SourceSpec],
                 strategy: Strategy = "optimal_split") -> None:
        if not sources:
            raise ValueError("a hybrid controller needs at least one source")
        self.sources = list(sources)
        self.strategy = strategy
        self.last_dispatch: dict[str, float] = {s.name: 0.0 for s in sources}

    @property
    def total_capacity(self) -> float:
        return sum(s.capacity for s in self.sources if s.available)

    def dispatch(self, demand: float, dt: float = math.inf) -> dict[str, float]:
        """Allocate ``demand`` watts across the sources.

        Ramp-rate limits are applied against the previous dispatch, so a source
        that cannot move fast enough forces the others to make up the shortfall
        -- or leaves the demand unmet, which the caller can detect by summing
        the result.
        """
        available = [s for s in self.sources if s.available]
        if not available or demand <= 0.0:
            self.last_dispatch = {s.name: 0.0 for s in self.sources}
            return dict(self.last_dispatch)

        limits = {}
        for s in available:
            previous = self.last_dispatch.get(s.name, 0.0)
            headroom = s.ramp_rate * dt if math.isfinite(s.ramp_rate * dt) else math.inf
            upper = min(s.capacity, previous + headroom)
            lower = max(0.0, previous - headroom)
            limits[s.name] = (lower, upper)

        allocation = {s.name: 0.0 for s in self.sources}
        remaining = demand

        if self.strategy == "proportional":
            total = sum(limits[s.name][1] for s in available)
            for s in available:
                share = limits[s.name][1] / total if total > 0.0 else 0.0
                allocation[s.name] = min(limits[s.name][1], demand * share)
            remaining = demand - sum(allocation.values())
        elif self.strategy in ("electric_priority", "fuel_priority"):
            order = available if self.strategy == "electric_priority" else list(reversed(available))
            for s in order:
                take = min(limits[s.name][1], remaining)
                allocation[s.name] = take
                remaining -= take
        elif self.strategy == "load_following":
            # target each source at 70 % of capacity before recruiting the next
            for s in available:
                sweet = 0.7 * s.capacity
                take = min(limits[s.name][1], sweet, remaining)
                allocation[s.name] = take
                remaining -= take
            for s in available:
                if remaining <= 0.0:
                    break
                extra = min(limits[s.name][1] - allocation[s.name], remaining)
                allocation[s.name] += extra
                remaining -= extra
        else:  # optimal_split
            steps = 50
            increment = demand / steps
            for _ in range(steps):
                best = None
                best_cost = math.inf
                for s in available:
                    current = allocation[s.name]
                    if current + increment > limits[s.name][1] + 1e-12:
                        continue
                    cost = s.marginal_cost(current + increment)
                    if cost < best_cost:
                        best_cost = cost
                        best = s
                if best is None:
                    break
                allocation[best.name] += increment
            remaining = demand - sum(allocation.values())

        for s in available:
            lower = limits[s.name][0]
            if 0.0 < allocation[s.name] < s.minimum:
                allocation[s.name] = min(s.minimum, limits[s.name][1])
            allocation[s.name] = max(allocation[s.name], 0.0)

        self.last_dispatch = allocation
        return dict(allocation)

    def unmet_demand(self, demand: float,
                     allocation: dict[str, float] | None = None) -> float:
        """Demand the sources could not meet (W)."""
        a = allocation if allocation is not None else self.last_dispatch
        return max(0.0, demand - sum(a.values()))

    def total_cost(self, allocation: dict[str, float] | None = None) -> float:
        a = allocation if allocation is not None else self.last_dispatch
        total = 0.0
        for s in self.sources:
            power = a.get(s.name, 0.0)
            if power > 0.0:
                total += power * s.marginal_cost(power)
        return total

    def blended_efficiency(self, allocation: dict[str, float] | None = None
                           ) -> float:
        a = allocation if allocation is not None else self.last_dispatch
        delivered = sum(a.values())
        if delivered <= 0.0:
            return 0.0
        consumed = sum(s.input_for(a.get(s.name, 0.0)) for s in self.sources)
        return delivered / consumed if consumed > 0.0 else 0.0


class HybridComponent(Component):
    """Applies a :class:`HybridController` dispatch inside the engine.

    Each source contributes a flow from SOURCE into ELECTRICAL sized by the
    primary energy it consumes, with the difference between consumed and
    delivered appearing as loss, so the split is fully visible in the ledger.
    """

    order = 35

    def __init__(self, name: str, controller: HybridController,
                 demand: float = 0.0, input_key: str | None = None,
                 loss_to_thermal: bool = False) -> None:
        super().__init__(name)
        self.controller = controller
        self.demand = float(demand)
        self.input_key = input_key or f"{name}.demand"
        self.loss_to_thermal = loss_to_thermal

    def evaluate(self, state: SystemState, dt: float,
                 context: Context) -> ComponentOutput:
        demand = max(0.0, context.get(self.input_key, self.demand))
        allocation = self.controller.dispatch(demand, dt)
        flows: list[PowerFlow] = []
        total_loss = 0.0
        diagnostics: dict[str, float] = {}
        for source in self.controller.sources:
            power = allocation.get(source.name, 0.0)
            if power <= 0.0:
                continue
            consumed = source.input_for(power)
            loss = consumed - power
            total_loss += loss
            flows.append(PowerFlow(EnergyDomain.SOURCE, EnergyDomain.ELECTRICAL,
                                   consumed, f"{source.name} supply", self.name))
            if loss > 0.0:
                target = (EnergyDomain.THERMAL if self.loss_to_thermal
                          else EnergyDomain.ENVIRONMENT)
                flows.append(PowerFlow(EnergyDomain.ELECTRICAL, target, loss,
                                       f"{source.name} loss", self.name))
            diagnostics[f"{self.name}.{source.name}"] = power
        unmet = self.controller.unmet_demand(demand, allocation)
        diagnostics[f"{self.name}.unmet"] = unmet
        diagnostics[f"{self.name}.cost"] = self.controller.total_cost(allocation)
        diagnostics[f"{self.name}.efficiency"] = self.controller.blended_efficiency(allocation)
        events = []
        if unmet > 1e-9:
            events.append(Event(state.time, "unmet_demand",
                                f"{self.name} short by {unmet:.4g} W",
                                Severity.LIMIT, self.name))
        return ComponentOutput(
            flows=flows,
            derivatives=Derivatives(
                heat_input=total_loss if self.loss_to_thermal else 0.0),
            diagnostics=diagnostics, events=events,
            severity=Severity.LIMIT if unmet > 1e-9 else Severity.NORMAL,
        )
