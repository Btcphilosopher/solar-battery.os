"""Service and transport layer.

``service`` is framework-agnostic; ``rest`` and ``streaming`` adapt it to HTTP
and to streaming transports.  Optional dependencies are imported lazily so the
package works with none of them installed.
"""
from .service import EngineService, ServiceError, SessionInfo, dumps, json_safe
from .rest import SimpleAPIServer, create_app, fastapi_available
from .streaming import (
    RecordingSubscriber, StreamConfig, TelemetryBroadcaster, websocket_adapter,
)

__all__ = [
    "EngineService", "ServiceError", "SessionInfo", "dumps", "json_safe",
    "SimpleAPIServer", "create_app", "fastapi_available",
    "RecordingSubscriber", "StreamConfig", "TelemetryBroadcaster",
    "websocket_adapter",
]
