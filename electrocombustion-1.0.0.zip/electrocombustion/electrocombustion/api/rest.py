"""HTTP adapters for :class:`~.service.EngineService`.

Two transports are provided and both are optional:

* :func:`create_app` builds a FastAPI application when FastAPI is installed.
* :class:`SimpleAPIServer` uses only ``http.server`` from the standard
  library, so the API is usable in an environment with no web dependencies at
  all.

Neither is imported at module load time.
"""
from __future__ import annotations

import json
from typing import Any, Callable, Mapping

from .service import EngineService, ServiceError, dumps, json_safe


def fastapi_available() -> bool:
    try:  # pragma: no cover - environment dependent
        import fastapi  # noqa: F401
        return True
    except ImportError:  # pragma: no cover
        return False


def create_app(service: EngineService, title: str = "ELECTROCOMBUSTION"):
    """Build a FastAPI application exposing the service.

    Raises a clear ``RuntimeError`` when FastAPI is absent rather than an
    obscure ``ImportError`` from deep inside the call.
    """
    try:  # pragma: no cover - environment dependent
        from fastapi import FastAPI, HTTPException
        from pydantic import BaseModel
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError(
            "FastAPI is not installed; use SimpleAPIServer for a "
            "dependency-free HTTP transport"
        ) from exc

    app = FastAPI(title=title)

    class StepRequest(BaseModel):
        dt: float
        inputs: dict[str, float] = {}

    class RunRequest(BaseModel):
        duration: float
        dt: float
        inputs: dict[str, float] = {}

    def guard(fn: Callable[[], Any]) -> Any:
        try:
            return json_safe(fn())
        except ServiceError as exc:
            raise HTTPException(status_code=exc.status, detail=str(exc)) from exc

    @app.get("/health")
    def health() -> Any:
        return guard(service.health)

    @app.post("/sessions")
    def create_session() -> Any:
        return guard(service.create_session)

    @app.get("/sessions")
    def list_sessions() -> Any:
        return guard(service.list_sessions)

    @app.delete("/sessions/{session_id}")
    def delete_session(session_id: str) -> Any:
        return guard(lambda: service.delete_session(session_id))

    @app.get("/sessions/{session_id}/state")
    def state(session_id: str) -> Any:
        return guard(lambda: service.state(session_id))

    @app.get("/sessions/{session_id}/describe")
    def describe(session_id: str) -> Any:
        return guard(lambda: service.describe(session_id))

    @app.post("/sessions/{session_id}/step")
    def step(session_id: str, request: StepRequest) -> Any:
        return guard(lambda: service.step(session_id, request.dt, request.inputs))

    @app.post("/sessions/{session_id}/run")
    def run(session_id: str, request: RunRequest) -> Any:
        return guard(lambda: service.run(session_id, request.duration,
                                         request.dt, request.inputs))

    @app.get("/sessions/{session_id}/energy")
    def energy(session_id: str) -> Any:
        return guard(lambda: service.energy(session_id))

    @app.get("/sessions/{session_id}/events")
    def events(session_id: str, limit: int = 100) -> Any:
        return guard(lambda: service.events(session_id, limit))

    @app.post("/sessions/{session_id}/reset")
    def reset(session_id: str) -> Any:
        return guard(lambda: service.reset(session_id))

    return app


class SimpleAPIServer:
    """A dependency-free HTTP server over the service.

    Intended for local use and testing, not for production traffic: it is
    single-threaded, unauthenticated and does no rate limiting.  That is
    stated plainly rather than implied.
    """

    def __init__(self, service: EngineService, host: str = "127.0.0.1",
                 port: int = 8000) -> None:
        self.service = service
        self.host = host
        self.port = port
        self._server: Any = None

    def _routes(self) -> dict[tuple[str, str], Callable[..., Any]]:
        s = self.service
        return {
            ("GET", "/health"): lambda body, parts: s.health(),
            ("POST", "/sessions"): lambda body, parts: s.create_session(),
            ("GET", "/sessions"): lambda body, parts: s.list_sessions(),
        }

    def handle(self, method: str, path: str,
               body: Mapping[str, Any] | None = None) -> tuple[int, dict[str, Any]]:
        """Route one request; returns ``(status, payload)``.

        Exposed separately from the socket server so the routing can be tested
        without binding a port.
        """
        parts = [p for p in path.split("/") if p]
        payload = dict(body or {})
        try:
            if method == "GET" and parts == ["health"]:
                return 200, self.service.health()
            if method == "POST" and parts == ["sessions"]:
                return 201, self.service.create_session()
            if method == "GET" and parts == ["sessions"]:
                return 200, self.service.list_sessions()
            if len(parts) >= 2 and parts[0] == "sessions":
                session_id = parts[1]
                tail = parts[2:]
                if method == "DELETE" and not tail:
                    return 200, self.service.delete_session(session_id)
                if method == "GET" and tail == ["state"]:
                    return 200, self.service.state(session_id)
                if method == "GET" and tail == ["describe"]:
                    return 200, self.service.describe(session_id)
                if method == "GET" and tail == ["energy"]:
                    return 200, self.service.energy(session_id)
                if method == "GET" and tail == ["events"]:
                    return 200, self.service.events(session_id)
                if method == "POST" and tail == ["step"]:
                    return 200, self.service.step(
                        session_id, float(payload.get("dt", 0.0)),
                        payload.get("inputs"))
                if method == "POST" and tail == ["run"]:
                    return 200, self.service.run(
                        session_id, float(payload.get("duration", 0.0)),
                        float(payload.get("dt", 0.0)), payload.get("inputs"))
                if method == "POST" and tail == ["reset"]:
                    return 200, self.service.reset(session_id)
            return 404, {"error": f"no route for {method} {path}"}
        except ServiceError as exc:
            return exc.status, {"error": str(exc)}
        except (TypeError, ValueError) as exc:
            return 400, {"error": f"bad request: {exc}"}

    def serve_forever(self) -> None:  # pragma: no cover - blocking network call
        from http.server import BaseHTTPRequestHandler, HTTPServer

        outer = self

        class Handler(BaseHTTPRequestHandler):
            def _respond(self, status: int, payload: Any) -> None:
                encoded = dumps(payload).encode("utf-8")
                self.send_response(status)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(encoded)))
                self.end_headers()
                self.wfile.write(encoded)

            def _body(self) -> dict[str, Any]:
                length = int(self.headers.get("Content-Length", 0) or 0)
                if length <= 0:
                    return {}
                try:
                    return json.loads(self.rfile.read(length).decode("utf-8"))
                except json.JSONDecodeError:
                    return {}

            def do_GET(self) -> None:  # noqa: N802 - required by the base class
                status, payload = outer.handle("GET", self.path)
                self._respond(status, payload)

            def do_POST(self) -> None:  # noqa: N802
                status, payload = outer.handle("POST", self.path, self._body())
                self._respond(status, payload)

            def do_DELETE(self) -> None:  # noqa: N802
                status, payload = outer.handle("DELETE", self.path)
                self._respond(status, payload)

            def log_message(self, *args: Any) -> None:
                pass

        self._server = HTTPServer((self.host, self.port), Handler)
        self._server.serve_forever()

    def shutdown(self) -> None:  # pragma: no cover
        if self._server is not None:
            self._server.shutdown()
