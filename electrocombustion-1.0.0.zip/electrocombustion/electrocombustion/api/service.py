"""Framework-agnostic service layer.

The service exposes the engine as a set of plain functions taking and
returning JSON-compatible dictionaries.  No web framework is imported here, so
the same object can be driven by FastAPI, the stdlib HTTP server, a message
queue, or a test -- and the transport can be swapped without touching the
logic.
"""
from __future__ import annotations

import json
import math
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Mapping, Sequence

from ..core.engine import ElectroCombustionEngine
from ..core.events import Severity
from ..core.state import SystemState
from ..faults.classifier import FaultClassifier
from ..optimisation.optimiser import (
    Constraint, DesignVariable, Objective, Optimiser,
)


class ServiceError(Exception):
    """Raised for a request the service cannot satisfy.

    Carries an HTTP-style status so transports can map it without inventing
    their own error taxonomy.
    """

    def __init__(self, message: str, status: int = 400) -> None:
        super().__init__(message)
        self.status = status


@dataclass(slots=True)
class SessionInfo:
    """Metadata about a running simulation session."""

    session_id: str
    created: float
    last_used: float
    steps: int = 0

    def touch(self) -> None:
        self.last_used = time.time()


class EngineService:
    """Session-oriented service wrapping one or more engines.

    Engines are created by a caller-supplied factory, so the service knows
    nothing about what is being simulated.  That is what lets the same API
    serve a heater, a genset and a burner without modification.
    """

    def __init__(self, factory: Callable[[], ElectroCombustionEngine],
                 max_sessions: int = 64,
                 max_duration: float = 3600.0,
                 max_steps: int = 5_000_000) -> None:
        self.factory = factory
        self.max_sessions = max_sessions
        self.max_duration = max_duration
        self.max_steps = max_steps
        self.engines: dict[str, ElectroCombustionEngine] = {}
        self.sessions: dict[str, SessionInfo] = {}

    # -- sessions -----------------------------------------------------------
    def create_session(self) -> dict[str, Any]:
        if len(self.engines) >= self.max_sessions:
            self._evict_oldest()
        session_id = uuid.uuid4().hex
        self.engines[session_id] = self.factory()
        now = time.time()
        self.sessions[session_id] = SessionInfo(session_id, now, now)
        return {"session_id": session_id, "created": now}

    def _evict_oldest(self) -> None:
        if not self.sessions:
            return
        oldest = min(self.sessions.values(), key=lambda s: s.last_used)
        self.delete_session(oldest.session_id)

    def engine(self, session_id: str) -> ElectroCombustionEngine:
        engine = self.engines.get(session_id)
        if engine is None:
            raise ServiceError(f"unknown session {session_id!r}", 404)
        self.sessions[session_id].touch()
        return engine

    def delete_session(self, session_id: str) -> dict[str, Any]:
        self.engines.pop(session_id, None)
        self.sessions.pop(session_id, None)
        return {"deleted": session_id}

    def list_sessions(self) -> dict[str, Any]:
        return {"sessions": [
            {"session_id": s.session_id, "created": s.created,
             "last_used": s.last_used, "steps": s.steps}
            for s in self.sessions.values()]}

    # -- simulation ---------------------------------------------------------
    def describe(self, session_id: str) -> dict[str, Any]:
        return self.engine(session_id).describe()

    def state(self, session_id: str) -> dict[str, Any]:
        engine = self.engine(session_id)
        return engine.snapshot()

    def step(self, session_id: str, dt: float,
             inputs: Mapping[str, float] | None = None) -> dict[str, Any]:
        if dt <= 0.0:
            raise ServiceError("dt must be positive")
        engine = self.engine(session_id)
        report = engine.step(dt, inputs)
        self.sessions[session_id].steps += 1
        return {"time": engine.state.time, "severity": report.severity.value,
                "state": engine.snapshot(),
                "conservation_residual": report.conservation_residual}

    def run(self, session_id: str, duration: float, dt: float,
            inputs: Mapping[str, float] | None = None) -> dict[str, Any]:
        if duration <= 0.0 or dt <= 0.0:
            raise ServiceError("duration and dt must be positive")
        if duration > self.max_duration:
            raise ServiceError(
                f"duration {duration:g} s exceeds the service limit of "
                f"{self.max_duration:g} s", 413)
        steps = int(duration / dt)
        if steps > self.max_steps:
            raise ServiceError(
                f"{steps} steps exceeds the service limit of {self.max_steps}; "
                f"increase dt or shorten the run", 413)
        engine = self.engine(session_id)
        mapping = dict(inputs or {})
        result = engine.run(duration, dt, lambda t, s: mapping)
        summary = result.summary()
        self.sessions[session_id].steps += int(summary.get("steps", 0))
        return {"summary": summary, "state": engine.snapshot()}

    def energy(self, session_id: str) -> dict[str, Any]:
        engine = self.engine(session_id)
        return {"summary": engine.energy_summary(),
                "waterfall": [{"label": k, "energy": v}
                              for k, v in engine.ledger.waterfall()],
                "efficiency": engine.efficiency()}

    def events(self, session_id: str, limit: int = 100) -> dict[str, Any]:
        engine = self.engine(session_id)
        events = engine.bus.history[-limit:]
        return {"events": [e.as_dict() for e in events],
                "worst": engine.bus.worst_severity().value}

    def reset(self, session_id: str) -> dict[str, Any]:
        engine = self.engine(session_id)
        engine.reset()
        self.sessions[session_id].steps = 0
        return {"reset": session_id, "state": engine.snapshot()}

    # -- optimisation -------------------------------------------------------
    def optimise(self, evaluate: Callable[[dict[str, float]], Mapping[str, float]],
                 variables: Sequence[Mapping[str, Any]],
                 objective_key: str = "electrical_power",
                 sense: str = "maximise",
                 constraints: Sequence[Mapping[str, Any]] = (),
                 method: str = "auto") -> dict[str, Any]:
        """Run an optimisation described by JSON-compatible dictionaries."""
        design = []
        for spec in variables:
            try:
                design.append(DesignVariable(
                    str(spec["name"]), float(spec["lower"]), float(spec["upper"]),
                    float(spec["initial"]) if "initial" in spec else None))
            except KeyError as exc:
                raise ServiceError(f"design variable missing {exc}") from exc
            except (TypeError, ValueError) as exc:
                raise ServiceError(f"invalid design variable: {exc}") from exc
        built: list[Constraint] = []
        for spec in constraints:
            try:
                key = str(spec["key"])
                built.append(Constraint(
                    str(spec.get("name", key)),
                    lambda r, k=key: r.get(k, 0.0),
                    float(spec["bound"]), str(spec.get("kind", "upper")),
                ))  # type: ignore[arg-type]
            except KeyError as exc:
                raise ServiceError(f"constraint missing {exc}") from exc
        objective = Objective(objective_key,
                              lambda r: r.get(objective_key, 0.0),
                              sense)  # type: ignore[arg-type]
        optimiser = Optimiser(evaluate, design, objective, built,
                              method=method)  # type: ignore[arg-type]
        result = optimiser.solve()
        return {"summary": result.summary(), "result": result.result,
                "evaluations": optimiser.evaluations}

    # -- health -------------------------------------------------------------
    def health(self) -> dict[str, Any]:
        return {"status": "ok", "sessions": len(self.engines),
                "capacity": self.max_sessions}


def json_safe(value: Any) -> Any:
    """Convert a value into something ``json.dumps`` will accept.

    Non-finite floats are the practical problem: ``inf`` appears legitimately
    (an infinite time constant, an unreachable limit) but is not valid JSON,
    so it is rendered as a string rather than silently becoming ``null``.
    """
    if isinstance(value, float):
        if math.isnan(value):
            return "NaN"
        if math.isinf(value):
            return "Infinity" if value > 0 else "-Infinity"
        return value
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(v) for v in value]
    if isinstance(value, Severity):
        return value.value
    return value


def dumps(payload: Any, indent: int | None = None) -> str:
    """JSON-encode a payload, handling non-finite floats safely."""
    return json.dumps(json_safe(payload), indent=indent, default=str)
