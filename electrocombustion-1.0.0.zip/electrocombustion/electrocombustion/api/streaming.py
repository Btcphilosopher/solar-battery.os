"""Streaming telemetry: a transport-agnostic broadcaster.

The broadcaster knows how to serialise a simulation step into a message and
fan it out to subscribers.  What a "subscriber" is -- a WebSocket, an MQTT
topic, a queue, a list in a test -- is entirely up to the caller.  This is why
no async framework is imported here.
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable, Mapping, Sequence

from ..core.engine import ElectroCombustionEngine
from ..core.events import Event, Severity
from ..core.state import SystemState
from .service import dumps, json_safe

Subscriber = Callable[[Mapping[str, Any]], None]


@dataclass(slots=True)
class StreamConfig:
    """How often and how much to publish."""

    interval: float = 0.1
    """Minimum simulated time between messages; 0 publishes on every call."""

    channels: tuple[str, ...] = ()
    include_events: bool = True
    include_energy: bool = False
    max_queue: int = 1000

    def __post_init__(self) -> None:
        if self.interval < 0.0:
            raise ValueError(
                "publish interval must be non-negative; use 0 to publish on "
                "every call"
            )


class TelemetryBroadcaster:
    """Publishes simulation state to any number of subscribers.

    A subscriber that raises is removed rather than being allowed to abort the
    simulation; a dropped consumer must not take the model down with it.  The
    removals are recorded in :attr:`failed` so the loss is visible.
    """

    def __init__(self, config: StreamConfig | None = None) -> None:
        self.config = config or StreamConfig()
        self.subscribers: list[Subscriber] = []
        self.failed: list[tuple[Subscriber, str]] = []
        self.published = 0
        self._last_publish = -math.inf

    def subscribe(self, subscriber: Subscriber) -> Subscriber:
        self.subscribers.append(subscriber)
        return subscriber

    def unsubscribe(self, subscriber: Subscriber) -> None:
        if subscriber in self.subscribers:
            self.subscribers.remove(subscriber)

    def build_message(self, engine: ElectroCombustionEngine,
                      extra: Mapping[str, Any] | None = None) -> dict[str, Any]:
        state = engine.state
        message: dict[str, Any] = {
            "time": state.time,
            "wall_clock": time.time(),
            "temperature": state.thermal.temperature,
            "pressure": state.thermal.pressure,
            "voltage": state.electrical.voltage,
            "current": state.electrical.current,
            "speed": state.mechanical.speed,
            "severity": engine.bus.worst_severity().value,
        }
        if self.config.channels:
            snapshot = engine.snapshot()
            for channel in self.config.channels:
                if channel in snapshot:
                    message[channel] = snapshot[channel]
                elif channel in state.diagnostics:
                    message[channel] = state.diagnostics[channel]
        if self.config.include_energy:
            message["energy"] = engine.energy_summary()
        if self.config.include_events:
            recent = [e.as_dict() for e in engine.bus.history[-5:]]
            if recent:
                message["events"] = recent
        if extra:
            message.update(dict(extra))
        return json_safe(message)

    def publish(self, engine: ElectroCombustionEngine,
                force: bool = False,
                extra: Mapping[str, Any] | None = None) -> dict[str, Any] | None:
        """Publish if the interval has elapsed; returns the message or None."""
        now = engine.state.time
        if not force and now - self._last_publish < self.config.interval:
            return None
        self._last_publish = now
        message = self.build_message(engine, extra)
        for subscriber in list(self.subscribers):
            try:
                subscriber(message)
            except Exception as exc:  # noqa: BLE001 - isolate failing consumers
                self.failed.append((subscriber, repr(exc)))
                self.unsubscribe(subscriber)
        self.published += 1
        return message

    def publish_json(self, engine: ElectroCombustionEngine,
                     force: bool = False) -> str | None:
        message = self.publish(engine, force)
        return dumps(message) if message is not None else None

    def reset(self) -> None:
        self._last_publish = -math.inf
        self.published = 0
        self.failed.clear()


class RecordingSubscriber:
    """A subscriber that keeps the last ``capacity`` messages.

    Useful for tests and for a late-joining client that wants recent history
    before the live stream starts.
    """

    def __init__(self, capacity: int = 1000) -> None:
        if capacity < 1:
            raise ValueError("capacity must be at least 1")
        self.capacity = capacity
        self.messages: list[dict[str, Any]] = []

    def __call__(self, message: Mapping[str, Any]) -> None:
        self.messages.append(dict(message))
        if len(self.messages) > self.capacity:
            del self.messages[: len(self.messages) - self.capacity]

    def latest(self) -> dict[str, Any] | None:
        return self.messages[-1] if self.messages else None

    def series(self, key: str) -> list[float]:
        return [m[key] for m in self.messages
                if isinstance(m.get(key), (int, float))]

    def __len__(self) -> int:
        return len(self.messages)


def websocket_adapter(send: Callable[[str], Any]) -> Subscriber:
    """Adapt a WebSocket ``send`` callable into a subscriber.

    Works with any library whose send function takes a string, synchronous or
    otherwise; async frameworks should wrap their coroutine in a scheduling
    call before passing it in.
    """
    def subscriber(message: Mapping[str, Any]) -> None:
        send(dumps(message))

    return subscriber
