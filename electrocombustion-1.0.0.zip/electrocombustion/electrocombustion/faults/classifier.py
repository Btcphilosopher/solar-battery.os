"""Operating-state classification and anomaly detection.

The classifier answers two different questions and keeps them separate:

* *Are we inside the limits we were given?*  -- deterministic, from
  :class:`~.limits.LimitRegistry`.
* *Does this look like the behaviour we expected?*  -- statistical, from a
  residual against a reference model.

Neither is a safety case.  Both are useful.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Callable, Mapping, Sequence

from ..core.events import Event, EventBus, Severity
from ..core.state import SystemState
from .limits import LimitCheck, LimitRegistry


@dataclass(slots=True)
class Diagnosis:
    """A classified operating state with its evidence."""

    severity: Severity
    time: float
    breaches: list[LimitCheck] = field(default_factory=list)
    anomalies: dict[str, float] = field(default_factory=dict)
    notes: list[str] = field(default_factory=list)

    @property
    def healthy(self) -> bool:
        return self.severity is Severity.NORMAL

    def as_dict(self) -> dict[str, Any]:
        return {
            "time": self.time, "severity": self.severity.value,
            "healthy": self.healthy,
            "breaches": [b.as_dict() for b in self.breaches],
            "anomalies": dict(self.anomalies), "notes": list(self.notes),
        }

    def explain(self) -> str:
        """A one-line human-readable explanation of the classification."""
        if self.healthy and not self.anomalies:
            return f"t={self.time:.6g}s NORMAL: all monitored limits satisfied"
        parts: list[str] = []
        for breach in self.breaches:
            parts.append(f"{breach.name}={breach.value:.6g}{breach.units} "
                         f"({breach.severity.value})")
        for name, score in self.anomalies.items():
            parts.append(f"{name} residual {score:.3g} sigma")
        return f"t={self.time:.6g}s {self.severity.value}: " + "; ".join(parts)


class FaultClassifier:
    """Combines limit checking with residual-based anomaly detection."""

    def __init__(self, limits: LimitRegistry | None = None,
                 anomaly_threshold: float = 3.0,
                 bus: EventBus | None = None) -> None:
        self.limits = limits or LimitRegistry()
        self.anomaly_threshold = anomaly_threshold
        self.bus = bus
        self.references: dict[str, tuple[Callable[[SystemState], float],
                                         Callable[[SystemState], float], float]] = {}
        self.history: list[Diagnosis] = []

    def add_reference(self, name: str,
                      measured: Callable[[SystemState], float],
                      expected: Callable[[SystemState], float],
                      sigma: float) -> None:
        """Register a residual test.

        ``sigma`` is the expected standard deviation of ``measured -
        expected`` under healthy operation, which must be established from
        data or from the sensor model; guessing it makes the detector
        meaningless.
        """
        if sigma <= 0.0:
            raise ValueError(f"{name}: sigma must be positive")
        self.references[name] = (measured, expected, sigma)

    def anomalies(self, state: SystemState) -> dict[str, float]:
        out: dict[str, float] = {}
        for name, (measured, expected, sigma) in self.references.items():
            residual = float(measured(state)) - float(expected(state))
            score = abs(residual) / sigma
            if score >= self.anomaly_threshold:
                out[name] = score
        return out

    def classify(self, state: SystemState) -> Diagnosis:
        breaches = self.limits.breaches(state)
        anomalies = self.anomalies(state)
        severity = Severity.worst(b.severity for b in breaches)
        if anomalies and severity is Severity.NORMAL:
            severity = Severity.WARNING
        notes: list[str] = []
        tightest = self.limits.tightest_margin(state)
        if tightest is not None and not breaches:
            notes.append(f"closest limit: {tightest.name} with "
                         f"{tightest.margin:.4g}{tightest.units} of margin")
        diagnosis = Diagnosis(severity, state.time, breaches, anomalies, notes)
        self.history.append(diagnosis)
        if self.bus is not None and severity is not Severity.NORMAL:
            self.bus.publish(state.time, "diagnosis", diagnosis.explain(),
                             severity, "classifier")
        return diagnosis

    def worst(self) -> Severity:
        return Severity.worst(d.severity for d in self.history)

    def timeline(self) -> list[tuple[float, str]]:
        """Compressed severity timeline: one entry per change of state."""
        out: list[tuple[float, str]] = []
        previous: Severity | None = None
        for diagnosis in self.history:
            if diagnosis.severity is not previous:
                out.append((diagnosis.time, diagnosis.severity.value))
                previous = diagnosis.severity
        return out

    def time_in_state(self, severity: Severity) -> float:
        """Total time spent in a given severity (s).

        Computed from consecutive diagnosis timestamps, so it is only as
        accurate as the classification interval.
        """
        total = 0.0
        for previous, current in zip(self.history, self.history[1:]):
            if previous.severity is severity:
                total += current.time - previous.time
        return total

    def reset(self) -> None:
        self.history.clear()


class TrendMonitor:
    """Detects slow drift that never breaches a limit but should not be ignored.

    A resistance creeping up 2 % a month is invisible to a threshold test until
    the day it is not.  This tracks the slope of a signal by least squares over
    a moving window.
    """

    def __init__(self, window: int = 200, slope_threshold: float = 1e-3) -> None:
        if window < 3:
            raise ValueError("window must be at least 3 samples")
        self.window = window
        self.slope_threshold = slope_threshold
        self.samples: list[tuple[float, float]] = []

    def add(self, t: float, value: float) -> None:
        self.samples.append((t, value))
        if len(self.samples) > self.window:
            del self.samples[: len(self.samples) - self.window]

    def slope(self) -> float:
        """Least-squares slope over the window (units per second)."""
        n = len(self.samples)
        if n < 3:
            return 0.0
        mean_t = sum(t for t, _ in self.samples) / n
        mean_v = sum(v for _, v in self.samples) / n
        numerator = sum((t - mean_t) * (v - mean_v) for t, v in self.samples)
        denominator = sum((t - mean_t) ** 2 for t, _ in self.samples)
        return numerator / denominator if denominator > 0.0 else 0.0

    @property
    def drifting(self) -> bool:
        return abs(self.slope()) > self.slope_threshold

    def projected(self, horizon: float) -> float:
        """Extrapolate the current value forward by ``horizon`` seconds."""
        if not self.samples:
            return 0.0
        return self.samples[-1][1] + self.slope() * horizon

    def time_to(self, target: float) -> float:
        """Estimated time until the signal reaches ``target`` (s).

        Returns ``inf`` when the trend is flat or moving away, which is the
        correct answer rather than a huge misleading number.
        """
        if not self.samples:
            return math.inf
        slope = self.slope()
        gap = target - self.samples[-1][1]
        if slope == 0.0 or (gap / slope) < 0.0:
            return math.inf
        return gap / slope
