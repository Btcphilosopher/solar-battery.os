"""Fault injection, limit checking and operating-state classification.

Nothing in this package constitutes a safety certification.  It supports
engineering analysis of how a modelled system behaves when things go wrong.
"""
from .limits import LimitCheck, LimitRegistry, standard_limits
from .injectors import (
    CoolingLossFault, FaultInjector, FuelInterruptionFault, OverloadFault,
    ParasiticHeatFault, ResistanceDriftFault, SensorFault,
)
from .classifier import Diagnosis, FaultClassifier, TrendMonitor

__all__ = [
    "LimitCheck", "LimitRegistry", "standard_limits", "CoolingLossFault",
    "FaultInjector", "FuelInterruptionFault", "OverloadFault",
    "ParasiticHeatFault", "ResistanceDriftFault", "SensorFault", "Diagnosis",
    "FaultClassifier", "TrendMonitor",
]
