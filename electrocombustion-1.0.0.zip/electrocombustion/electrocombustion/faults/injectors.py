"""Fault injection.

Each injector is a :class:`~electrocombustion.core.component.Component` that
degrades some part of the system when armed.  Injecting a fault does not stop
the simulation: it changes the physics and lets the consequences propagate,
which is the whole point of having an energy-conserving model.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Callable

from ..core.component import Component, ComponentOutput, Context, Derivatives
from ..core.events import Event, Severity
from ..core.state import EnergyDomain, PowerFlow, SystemState


class FaultInjector(Component):
    """Base class for a fault that arms at a given time.

    ``severity`` is what the fault reports once active.  ``ramp`` lets a fault
    develop over time rather than appearing instantaneously, which is usually
    the more realistic and the more revealing case.
    """

    order = 95

    def __init__(self, name: str, start_time: float = 0.0,
                 duration: float = math.inf, ramp: float = 0.0,
                 severity: Severity = Severity.FAULT) -> None:
        super().__init__(name)
        self.start_time = float(start_time)
        self.duration = float(duration)
        self.ramp = float(ramp)
        self.severity = severity
        self._announced = False

    def intensity(self, t: float) -> float:
        """Fault severity fraction at time ``t`` (0 = healthy, 1 = full)."""
        if t < self.start_time:
            return 0.0
        if t > self.start_time + self.duration:
            return 0.0
        if self.ramp <= 0.0:
            return 1.0
        return min(1.0, (t - self.start_time) / self.ramp)

    def is_active(self, t: float) -> bool:
        return self.intensity(t) > 0.0

    def _event(self, t: float, message: str) -> list[Event]:
        if self._announced:
            return []
        self._announced = True
        return [Event(t, "fault_injected", message, self.severity, self.name)]

    def reset(self) -> None:
        self._announced = False


class CoolingLossFault(FaultInjector):
    """Reduces coolant flow, up to complete loss of cooling."""

    def __init__(self, name: str, target_key: str, start_time: float = 0.0,
                 residual_flow: float = 0.0, **kwargs: Any) -> None:
        super().__init__(name, start_time, **kwargs)
        self.target_key = target_key
        self.residual_flow = float(residual_flow)

    def evaluate(self, state: SystemState, dt: float,
                 context: Context) -> ComponentOutput:
        level = self.intensity(state.time)
        if level <= 0.0:
            return ComponentOutput()
        nominal = context.get(self.target_key, 1.0)
        degraded = nominal * (1.0 - level) + self.residual_flow * level
        context.inputs[self.target_key] = degraded
        return ComponentOutput(
            diagnostics={f"{self.name}.flow": degraded,
                         f"{self.name}.intensity": level},
            events=self._event(state.time,
                               f"{self.name}: coolant flow degraded to "
                               f"{degraded:.3g} of nominal"),
            severity=self.severity,
        )


class ResistanceDriftFault(FaultInjector):
    """Increases a resistance, as a corroding joint or degrading element does."""

    def __init__(self, name: str, resistor: Any, multiplier: float = 2.0,
                 start_time: float = 0.0, **kwargs: Any) -> None:
        super().__init__(name, start_time, severity=Severity.WARNING, **kwargs)
        self.resistor = resistor
        self.multiplier = float(multiplier)
        self._original: float | None = None

    def evaluate(self, state: SystemState, dt: float,
                 context: Context) -> ComponentOutput:
        level = self.intensity(state.time)
        if self._original is None:
            self._original = getattr(self.resistor, "resistance", None)
        if level <= 0.0:
            if self._original is not None:
                self.resistor.resistance = self._original
            return ComponentOutput()
        if self._original is None:
            return ComponentOutput(
                events=self._event(state.time,
                                   f"{self.name}: target has no abstract "
                                   f"resistance to drift"),
                severity=Severity.WARNING)
        factor = 1.0 + (self.multiplier - 1.0) * level
        self.resistor.resistance = self._original * factor
        return ComponentOutput(
            diagnostics={f"{self.name}.factor": factor},
            events=self._event(state.time,
                               f"{self.name}: resistance drifting toward "
                               f"{self.multiplier:g}x nominal"),
            severity=self.severity,
        )


class FuelInterruptionFault(FaultInjector):
    """Cuts or restricts fuel supply."""

    def __init__(self, name: str, fuel_key: str, start_time: float = 0.0,
                 residual_fraction: float = 0.0, **kwargs: Any) -> None:
        super().__init__(name, start_time, **kwargs)
        self.fuel_key = fuel_key
        self.residual_fraction = float(residual_fraction)

    def evaluate(self, state: SystemState, dt: float,
                 context: Context) -> ComponentOutput:
        level = self.intensity(state.time)
        if level <= 0.0:
            return ComponentOutput()
        nominal = context.get(self.fuel_key, 0.0)
        degraded = nominal * (1.0 - level * (1.0 - self.residual_fraction))
        context.inputs[self.fuel_key] = degraded
        return ComponentOutput(
            diagnostics={f"{self.name}.fuel_flow": degraded},
            events=self._event(state.time, f"{self.name}: fuel supply interrupted"),
            severity=self.severity,
        )


class ParasiticHeatFault(FaultInjector):
    """Injects unwanted heat, e.g. a shorted turn or a seized bearing."""

    def __init__(self, name: str, power: float, start_time: float = 0.0,
                 **kwargs: Any) -> None:
        super().__init__(name, start_time, **kwargs)
        self.power = float(power)

    def evaluate(self, state: SystemState, dt: float,
                 context: Context) -> ComponentOutput:
        level = self.intensity(state.time)
        if level <= 0.0:
            return ComponentOutput()
        heat = self.power * level
        return ComponentOutput(
            flows=[PowerFlow(EnergyDomain.SOURCE, EnergyDomain.THERMAL, heat,
                             "fault heating", self.name)],
            derivatives=Derivatives(heat_input=heat),
            diagnostics={f"{self.name}.heat": heat},
            events=self._event(state.time,
                               f"{self.name}: injecting {heat:.4g} W of parasitic heat"),
            severity=self.severity,
        )


class OverloadFault(FaultInjector):
    """Drives an input beyond its normal range."""

    def __init__(self, name: str, target_key: str, multiplier: float = 1.5,
                 start_time: float = 0.0, **kwargs: Any) -> None:
        super().__init__(name, start_time, severity=Severity.LIMIT, **kwargs)
        self.target_key = target_key
        self.multiplier = float(multiplier)

    def evaluate(self, state: SystemState, dt: float,
                 context: Context) -> ComponentOutput:
        level = self.intensity(state.time)
        if level <= 0.0:
            return ComponentOutput()
        factor = 1.0 + (self.multiplier - 1.0) * level
        nominal = context.get(self.target_key, 0.0)
        context.inputs[self.target_key] = nominal * factor
        return ComponentOutput(
            diagnostics={f"{self.name}.factor": factor},
            events=self._event(state.time,
                               f"{self.name}: {self.target_key} overloaded to "
                               f"{factor:.3g}x"),
            severity=self.severity,
        )


class SensorFault(FaultInjector):
    """Corrupts a measurement without changing the physics.

    Distinguishing a sensor fault from a process fault is one of the main
    reasons to have a model at all: the plant is fine, the reading is not, and
    a controller that trusts the reading will make the plant worse.
    """

    def __init__(self, name: str, channel: str, mode: str = "bias",
                 magnitude: float = 10.0, stuck_value: float = 0.0,
                 start_time: float = 0.0, **kwargs: Any) -> None:
        super().__init__(name, start_time, severity=Severity.WARNING, **kwargs)
        if mode not in ("bias", "stuck", "drift", "dropout"):
            raise ValueError("mode must be bias, stuck, drift or dropout")
        self.channel = channel
        self.mode = mode
        self.magnitude = float(magnitude)
        self.stuck_value = float(stuck_value)

    def corrupt(self, value: float, t: float) -> float:
        level = self.intensity(t)
        if level <= 0.0:
            return value
        if self.mode == "bias":
            return value + self.magnitude * level
        if self.mode == "stuck":
            return self.stuck_value
        if self.mode == "drift":
            return value + self.magnitude * level * (t - self.start_time)
        return 0.0

    def evaluate(self, state: SystemState, dt: float,
                 context: Context) -> ComponentOutput:
        level = self.intensity(state.time)
        if level <= 0.0:
            return ComponentOutput()
        return ComponentOutput(
            diagnostics={f"{self.name}.mode": self.mode},
            events=self._event(state.time,
                               f"{self.name}: {self.channel} sensor {self.mode} fault"),
            severity=self.severity,
        )
