"""Operating-limit registry and state classification.

This is an **engineering-analysis** classification, not a safety
certification.  It tells you whether a simulated operating point sits inside
the limits you gave it.  It does not tell you that a machine is safe.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Callable, Iterable, Mapping, Sequence

from ..core.events import Severity, Threshold
from ..core.state import SystemState


@dataclass(slots=True)
class LimitCheck:
    """The result of testing one signal against one threshold."""

    name: str
    value: float
    severity: Severity
    margin: float
    units: str = ""

    @property
    def breached(self) -> bool:
        return self.severity is not Severity.NORMAL

    def as_dict(self) -> dict[str, object]:
        return {"name": self.name, "value": self.value,
                "severity": self.severity.value, "margin": self.margin,
                "units": self.units, "breached": self.breached}


class LimitRegistry:
    """A named collection of thresholds evaluated against the system state."""

    def __init__(self) -> None:
        self.entries: dict[str, tuple[Threshold, Callable[[SystemState], float]]] = {}

    def add(self, threshold: Threshold,
            accessor: Callable[[SystemState], float]) -> Threshold:
        if threshold.name in self.entries:
            raise ValueError(f"duplicate limit {threshold.name!r}")
        self.entries[threshold.name] = (threshold, accessor)
        return threshold

    def add_simple(self, name: str, accessor: Callable[[SystemState], float],
                   warning: float | None = None, limit: float | None = None,
                   fault: float | None = None, direction: str = "upper",
                   units: str = "") -> Threshold:
        return self.add(Threshold(name, warning, limit, fault, direction, units),
                        accessor)

    def evaluate(self, state: SystemState) -> list[LimitCheck]:
        checks: list[LimitCheck] = []
        for name, (threshold, accessor) in self.entries.items():
            value = float(accessor(state))
            checks.append(LimitCheck(name, value, threshold.classify(value),
                                     threshold.margin(value), threshold.units))
        return checks

    def worst(self, state: SystemState) -> Severity:
        return Severity.worst(c.severity for c in self.evaluate(state))

    def breaches(self, state: SystemState) -> list[LimitCheck]:
        return [c for c in self.evaluate(state) if c.breached]

    def tightest_margin(self, state: SystemState) -> LimitCheck | None:
        """The limit closest to being breached, or ``None`` if empty."""
        checks = [c for c in self.evaluate(state) if math.isfinite(c.margin)]
        if not checks:
            return None
        return min(checks, key=lambda c: c.margin)

    def __len__(self) -> int:
        return len(self.entries)


def standard_limits(max_temperature: float = 1200.0,
                    max_current: float = 200.0,
                    max_pressure: float = 1.5e7,
                    max_speed: float = 700.0,
                    min_temperature: float = 250.0) -> LimitRegistry:
    """A conventional starting set of operating limits.

    The warning/limit/fault levels are placed at 85 %, 95 % and 100 % of the
    supplied ceiling, which is a common industrial convention.  Replace them
    with the real values from the equipment datasheet before drawing any
    conclusion about a physical machine.
    """
    registry = LimitRegistry()
    registry.add_simple(
        "temperature", lambda s: s.thermal.temperature,
        0.85 * max_temperature, 0.95 * max_temperature, max_temperature,
        "upper", "K")
    registry.add_simple(
        "under_temperature", lambda s: s.thermal.temperature,
        min_temperature * 1.1, min_temperature * 1.02, min_temperature,
        "lower", "K")
    registry.add_simple(
        "current", lambda s: abs(s.electrical.current),
        0.85 * max_current, 0.95 * max_current, max_current, "upper", "A")
    registry.add_simple(
        "pressure", lambda s: s.thermal.pressure,
        0.85 * max_pressure, 0.95 * max_pressure, max_pressure, "upper", "Pa")
    registry.add_simple(
        "speed", lambda s: abs(s.mechanical.speed),
        0.85 * max_speed, 0.95 * max_speed, max_speed, "upper", "rad/s")
    return registry
