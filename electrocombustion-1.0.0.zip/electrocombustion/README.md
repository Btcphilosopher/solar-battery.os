# ELECTROCOMBUSTION

A general-purpose Python framework for systems where **electrical, thermal,
chemical and mechanical energy interact**.

It is not a simulator for one machine. It is a set of composable physical
models, an energy-conserving solver, and the optimisation, uncertainty and
diagnostic machinery you need around them — usable for engines, generator sets,
hybrid power systems, industrial burners, thermal plant, electrical heating,
waste-heat recovery and experimental energy systems.

```python
from electrocombustion.optimisation import DesignVariable, optimise_operating_point, thermal_limit

best = optimise_operating_point(
    plant_model,
    [DesignVariable("fuel_flow", 1e-4, 0.012), DesignVariable("speed", 80, 220)],
    [thermal_limit("heat_rejection", 90_000.0)])

# 122.9 kW electrical, sitting exactly on the 90 kW cooling limit
```

---

## What makes it different

**Every joule is accounted for.** Components emit directed `PowerFlow`s between
six named energy domains and an `EnergyLedger` integrates them. The first law
is *checked*, not assumed. In the reference electro-thermal case,
`input − losses − stored` comes out **exactly 0.0**; the residual on the
quadratic mechanical term is reported in `StepReport.conservation_residual`
rather than quietly absorbed.

**Components are pure functions of state.** That is what makes RK4, step
rejection and speculative MPC rollouts all work without special cases.

**Optimisation is a first-class component, not an afterthought.** Design
variables are solved in normalised coordinates and constraints are scaled by
their own magnitude, so a problem mixing 1e-3 fuel flows with 1e5 watts is well
conditioned. The `auto` method runs a gradient search, a global search, and a
constrained polish of the global result, and returns the best *feasible* point.

**The models say when they are unsure.** Correlations warn outside their fitted
range. Inversions raise rather than clipping. Sweeps mark unevaluated cells
`nan`, and the text renderer draws them as `?`.

---

## Install

```bash
pip install -e .
pip install -e ".[full]"     # + matplotlib, FastAPI
```

Requires Python 3.11+, NumPy and SciPy. Matplotlib and FastAPI are optional and
lazily imported — the text visualisation and the stdlib HTTP transport work
with neither installed.

## Quick start

```python
from electrocombustion import ElectroCombustionEngine, EngineConfig, SystemState
from electrocombustion.electrical import DCSource, Geometry, Resistor, ResistiveHeater
from electrocombustion.materials import NICHROME
from electrocombustion.thermal import ConvectionSurface, SurfaceLoss

state = SystemState()
state.thermal.mass, state.thermal.specific_heat = 2.0, 450.0
state.thermal.gas_constant = 0.0          # a solid: cv == cp
state.thermal.temperature = state.ambient_temperature = 300.0

engine = ElectroCombustionEngine(state, config=EngineConfig(scheme="rk4"))
engine.add(ResistiveHeater(
    "heater",
    Resistor("element", material=NICHROME, geometry=Geometry.wire(5.0, 1e-3)),
    DCSource(230.0)))
engine.add(SurfaceLoss("loss", ConvectionSurface(area=0.05, coefficient=15.0)))

engine.run(600.0, 0.05)
print(engine.energy_summary())
```

## Package layout

| Package | Contents |
|---|---|
| `core/` | units, state, power flows, ledger, components, engine, events, timestepping |
| `materials/` | temperature-dependent property models, 17-material library |
| `electrical/` | resistance, sources, networks, AC/DC power, converters, batteries, machines |
| `thermal/` | conduction, convection, radiation, thermal networks, heat exchangers |
| `combustion/` | fuels, mixtures, ignition, reaction kinetics, heat release, pressure, emissions |
| `mechanical/` | torque models, inertia, shafts, gearing, cycle efficiencies |
| `systems/` | generator, combustion engine, hybrid controller, electric heater, waste-heat recovery |
| `optimisation/` | constrained optimiser, PID/feedforward/supervisory control, MPC |
| `simulation/` | solvers, scenarios, parameter sweeps, Monte Carlo |
| `faults/` | limit registry, fault injectors, operating-state classifier, trend monitor |
| `telemetry/` | sensor models, ring-buffer logging, CSV replay, validation |
| `twin.py` | digital energy twin: model vs measurement, with residual tracking |
| `api/` | framework-agnostic service, FastAPI adapter, stdlib fallback, streaming |
| `visualisation/` | dependency-free text output, optional matplotlib plots |

## Examples

```bash
python examples/01_resistive_heater.py     # electro-thermal feedback, exact ledger
python examples/02_diesel_genset.py        # full chemical→…→load waterfall
python examples/03_optimisation.py         # constrained optimum on a cooling limit
python examples/04_control_and_faults.py   # PID, then a sensor fault it trusts
python examples/05_uncertainty.py          # P10/P50/P90 and rank sensitivities
python examples/06_digital_twin.py         # residual detects invisible degradation
```

---

## Simulation-grade, not engineering-validated

This distinction matters enough to state plainly.

**Simulation-grade** means correct qualitative behaviour, within a stated
tolerance of textbook reference values, suitable for design exploration, trade
studies, control development and teaching.

**Engineering-validated** means checked against measured data from the specific
machine, over the operating range of interest, by someone accountable for the
result.

**Nothing here is engineering-validated.**

Verified against reference values:

| Check | Model | Reference |
|---|---|---|
| Stoichiometric AFR, methane | 17.240 | 17.2 |
| Stoichiometric AFR, diesel | 14.510 | 14.5 |
| Stoichiometric AFR, hydrogen | 34.298 | 34.3 |
| Adiabatic flame temperature, methane | 2236 K | 2226 K |
| Adiabatic flame temperature, hydrogen | 2530 K | 2483 K |
| Otto efficiency, CR 10 | 0.6019 | closed form |
| Diesel efficiency, CR 18, rc 2 | 0.6316 | closed form |
| Brayton efficiency, PR 12 | 0.5083 | closed form |
| Product mass balance, 10 fuels × 200 φ | max residual 1.1e-13 kg/kg | exact |
| RK4 vs analytic exponential decay | error 9.9e-11 | exact |
| Thermal network transient vs `lumped_response` | agreement to 1e-12 | exact |
| Heat exchanger ε, UA 5000, C 2000/4000 | 0.8328 | ε-NTU |

Known limitations are documented in `docs/modelling_notes.md`: no dissociation,
no soot, no spatial resolution, correlation ranges, and the fact that the
emissions model is illustrative and the fault classifier is **not a safety
certification**.

## Testing

```bash
pytest                                    # 1155 tests
pytest --cov=electrocombustion            # 88 % coverage
```

The suite is built around invariants rather than golden values wherever
possible: energy conservation, mass balance, analytic solutions, monotonicity,
and inversion round-trips. Several real bugs were found this way — a rich
mixture being credited with the full heating value of fuel that had only
oxidised to CO (which made flame temperature rise past stoichiometric), events
raised in early Runge-Kutta stages being silently discarded, and a unit
converter that would happily turn metres into kilograms.

## Documentation

- `docs/architecture.md` — the domain model, component purity, where
  conservation is exact and where it is not
- `docs/modelling_notes.md` — provenance and accuracy of every model
- `docs/api_guide.md` — quick reference

## Licence

MIT.
