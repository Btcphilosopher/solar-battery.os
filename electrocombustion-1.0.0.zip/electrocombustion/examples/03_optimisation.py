"""Example 3 -- constrained optimisation of a generator set.

Section 15 of the specification makes optimisation a first-class component.
This finds the fuel flow and shaft speed that maximise net electrical output
subject to a fuel cap and the capacity of the cooling system.

The interesting part is that the optimum sits exactly *on* the thermal
constraint: the machine is cooling-limited, not fuel-limited.

Run:  python examples/03_optimisation.py
"""
from __future__ import annotations

from electrocombustion.combustion import DIESEL
from electrocombustion.mechanical import FrictionModel
from electrocombustion.optimisation import (
    DesignVariable, fuel_limit, optimise_efficiency, optimise_operating_point,
    sensitivity, thermal_limit,
)
from electrocombustion.simulation import Parameter, operating_map
from electrocombustion.systems import (
    CombustionEngine, CycleModel, EngineSpec, Generator, GeneratorSpec,
)
from electrocombustion.visualisation import format_power, operating_map_text


COOLING_CAPACITY = 90_000.0     # W
FUEL_CAP = 0.008                # kg/s

PRIME_MOVER = CombustionEngine(EngineSpec(
    fuel=DIESEL, rated_power=100_000.0, rated_speed=157.08,
    cycle=CycleModel(kind="diesel", compression_ratio=18.0, cutoff_ratio=2.2,
                     gamma=1.35, quality=0.80),
    friction=FrictionModel(constant=15.0, linear=0.05, quadratic=2e-4),
))
ALTERNATOR = Generator(GeneratorSpec(rated_power=90_000.0, rated_speed=157.08))


def evaluate(variables: dict[str, float]) -> dict[str, float]:
    """The plant model the optimiser drives."""
    result = PRIME_MOVER.evaluate(variables["fuel_flow"], variables["speed"])
    return {
        "electrical_power": ALTERNATOR.electrical_power(result["brake_power"],
                                                        variables["speed"]),
        "chemical_power": result["chemical_power"],
        "fuel_flow": variables["fuel_flow"],
        "speed": variables["speed"],
        "heat_rejection": result["coolant_power"] + result["exhaust_power"],
    }


def variables() -> list[DesignVariable]:
    return [DesignVariable("fuel_flow", 1e-4, 0.012, initial=0.004),
            DesignVariable("speed", 80.0, 220.0, initial=157.0)]


def main() -> None:
    constraints = [fuel_limit("fuel_flow", FUEL_CAP),
                   thermal_limit("heat_rejection", COOLING_CAPACITY)]

    print("maximising net electrical output")
    best = optimise_operating_point(evaluate, variables(), constraints)
    print(f"  fuel flow      : {best['fuel_flow'] * 1000:.3f} g/s")
    print(f"  shaft speed    : {best['speed']:.1f} rad/s "
          f"({best['speed'] * 60 / 6.28319:.0f} rpm)")
    print(f"  output         : {format_power(best.objective_value)}")
    print(f"  heat rejection : {format_power(best.result['heat_rejection'])} "
          f"of {format_power(COOLING_CAPACITY)} available")
    print(f"  feasible       : {best.feasible}")
    for name, margin in best.constraint_margins.items():
        binding = "BINDING" if abs(margin) < 1.0 else "slack"
        print(f"    {name:<14}: margin {margin:+.4g}  ({binding})")

    print("\nmaximising efficiency instead")
    frugal = optimise_efficiency(evaluate, variables(), constraints)
    print(f"  fuel flow      : {frugal['fuel_flow'] * 1000:.3f} g/s")
    print(f"  efficiency     : {frugal.objective_value * 100:.2f} %")
    print(f"  output         : "
          f"{format_power(frugal.result['electrical_power'])}")
    print("  -- the efficiency optimum runs the machine far lighter than the")
    print("     power optimum: these are genuinely different questions.")

    print("\nsensitivity of output at the power optimum (elasticities)")
    for name, value in sensitivity(evaluate, best.variables,
                                   "electrical_power").items():
        print(f"  d(ln P)/d(ln {name}) = {value:+.3f}")

    print("\noperating map (electrical power)")
    grid = operating_map(evaluate,
                         Parameter.linear("fuel_flow", 1e-3, 0.010, 40),
                         Parameter.linear("speed", 80.0, 220.0, 20))
    xs, ys, values = grid.to_grid("fuel_flow", "speed", "electrical_power")
    print(operating_map_text(xs, ys, values.tolist()))
    print(f"({len(grid)} points evaluated, {len(grid.failures)} failures)")


if __name__ == "__main__":
    main()
