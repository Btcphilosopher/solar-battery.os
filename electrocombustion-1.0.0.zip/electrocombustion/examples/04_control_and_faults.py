"""Example 4 -- closed-loop control, then a sensor fault the controller trusts.

A PID controller holds a furnace at setpoint by modulating heater duty.  At
``FAULT_TIME`` the temperature sensor sticks: it keeps reporting the setpoint
no matter what the furnace actually does.  The controller is working perfectly
and the plant is undamaged, but because the *measurement* is wrong the
controller drives the furnace into an overtemperature fault.

This is why a model is worth having.  A limit checker watching the sensor sees
nothing wrong.  A twin comparing the sensor against a model sees the residual
open up immediately.

Run:  python examples/04_control_and_faults.py
"""
from __future__ import annotations

from electrocombustion import ElectroCombustionEngine, EngineConfig, SystemState
from electrocombustion.faults import FaultClassifier, SensorFault, standard_limits
from electrocombustion.materials import KANTHAL
from electrocombustion.optimisation import PIDController
from electrocombustion.systems import ElectricHeaterSystem, HeaterComponent, HeaterSpec
from electrocombustion.thermal import CoolingCircuit, CoolingLoop
from electrocombustion.visualisation import severity_timeline, sparkline

SETPOINT = 900.0        # K
FAULT_TIME = 600.0      # s
STUCK_READING = 820.0    # K -- what the failed sensor keeps reporting
MAX_TEMPERATURE = 1100.0
DT = 0.5


def build() -> ElectroCombustionEngine:
    state = SystemState()
    state.thermal.mass = 30.0
    state.thermal.specific_heat = 800.0
    state.thermal.gas_constant = 0.0
    state.thermal.temperature = 850.0       # preheated: the demonstration is
    state.ambient_temperature = 293.15      # about the fault, not the warm-up

    engine = ElectroCombustionEngine(state, config=EngineConfig(scheme="rk4"))
    heater = ElectricHeaterSystem(
        HeaterSpec(material=KANTHAL, length=10.0, diameter=2e-3,
                   supply_voltage=400.0),
        ambient=293.15, convection_coefficient=20.0)
    engine.add(HeaterComponent("heater", heater, input_key="heater.duty"))
    engine.add(CoolingLoop("cooling",
                           CoolingCircuit(mass_flow=0.008,
                                          inlet_temperature=293.15, ua=40.0)))
    return engine


def main() -> None:
    engine = build()
    classifier = FaultClassifier(standard_limits(max_temperature=MAX_TEMPERATURE),
                                 bus=engine.bus)
    controller = PIDController(kp=0.004, ki=6e-5, kd=2.0, setpoint=SETPOINT,
                               output_min=0.0, output_max=1.0, rate_limit=0.05)
    sensor_fault = SensorFault("t_sensor", channel="temperature", mode="stuck",
                               stuck_value=STUCK_READING,
                               start_time=FAULT_TIME)

    truth: list[float] = []
    indicated: list[float] = []
    duties: list[float] = []

    for _ in range(2400):
        actual = engine.state.thermal.temperature
        reading = sensor_fault.corrupt(actual, engine.state.time)
        duty = controller.update(reading, DT)
        engine.step(DT, {"heater.duty": duty})
        classifier.classify(engine.state)
        truth.append(actual)
        indicated.append(reading)
        duties.append(duty)

    index = int(FAULT_TIME / DT)
    print(f"setpoint                 : {SETPOINT:.0f} K")
    print(f"true temperature at fault: {truth[index]:.1f} K")
    print(f"duty at fault            : {duties[index] * 100:.1f} %")
    print(f"final true temperature   : {truth[-1]:.1f} K")
    print(f"final indicated          : {indicated[-1]:.1f} K  <-- frozen, "
          f"and below setpoint, so the controller keeps heating")
    print(f"final duty               : {duties[-1] * 100:.1f} %")
    print(f"peak true temperature    : {max(truth):.1f} K")
    print()
    print(f"true      : {sparkline(truth, width=60)}")
    print(f"indicated : {sparkline(indicated, width=60)}")
    print(f"duty      : {sparkline(duties, width=60)}")
    print()
    print("classifier timeline (watching the true state)")
    print(severity_timeline(classifier.timeline()))
    print()
    print(f"worst state reached: {classifier.worst().value}")
    print(f"final diagnosis    : {classifier.history[-1].explain()}")
    print()
    residual = truth[-1] - indicated[-1]
    print(f"model-minus-sensor residual at the end: {residual:+.1f} K")
    print("A limit checker reading only the sensor would report NORMAL "
          "throughout.")


if __name__ == "__main__":
    main()
