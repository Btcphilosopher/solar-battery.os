"""Example 5 -- uncertainty propagation and a P10/P50/P90 band.

Nothing about a real machine is known exactly.  This propagates uncertainty in
fuel heating value, generator efficiency, ambient temperature and cooling
capacity through the genset model, and reports the distribution of net output
rather than a single number pretending to be exact.

Run:  python examples/05_uncertainty.py
"""
from __future__ import annotations

from electrocombustion.combustion import DIESEL, Fuel
from electrocombustion.mechanical import FrictionModel
from electrocombustion.simulation import Distribution, MonteCarlo
from electrocombustion.systems import (
    CombustionEngine, CycleModel, EngineSpec, Generator, GeneratorSpec,
)
from electrocombustion.visualisation import format_power, sparkline

SAMPLES = 4000


def evaluate(point: dict[str, float]) -> dict[str, float]:
    """One realisation of the genset with uncertain parameters."""
    fuel = Fuel(name="diesel_sample", carbon=DIESEL.carbon,
                hydrogen=DIESEL.hydrogen, lhv=point["lhv"],
                density=DIESEL.density, phase=DIESEL.phase)
    prime_mover = CombustionEngine(EngineSpec(
        fuel=fuel, rated_power=100_000.0, rated_speed=157.08,
        cycle=CycleModel(kind="diesel", compression_ratio=18.0,
                         cutoff_ratio=2.2, gamma=1.35,
                         quality=point["cycle_quality"]),
        friction=FrictionModel(constant=point["friction"], linear=0.05,
                               quadratic=2e-4),
    ))
    alternator = Generator(GeneratorSpec(
        rated_power=90_000.0, rated_speed=157.08,
        copper_loss_fraction=point["copper_loss"]))

    result = prime_mover.evaluate(0.006, 157.08)
    electrical = alternator.electrical_power(result["brake_power"], 157.08)
    rejected = result["coolant_power"] + result["exhaust_power"]
    return {
        "electrical_power": electrical,
        "efficiency": electrical / result["chemical_power"],
        "heat_rejection": rejected,
        "cooling_margin": point["cooling_capacity"] - rejected,
    }


def main() -> None:
    distributions = [
        # LHV varies with refinery batch and with temperature.
        Distribution("lhv", "normal", DIESEL.lhv, 0.02 * DIESEL.lhv,
                     lower=0.9 * DIESEL.lhv, upper=1.1 * DIESEL.lhv),
        # Cycle quality is the single most uncertain modelling assumption.
        Distribution("cycle_quality", "triangular", 0.72, 0.86, c=0.80),
        # Friction depends on oil temperature, wear and build tolerance.
        Distribution("friction", "uniform", 10.0, 22.0),
        # Copper losses vary with winding temperature.
        Distribution("copper_loss", "normal", 0.035, 0.004, lower=0.02),
        # Radiator capacity depends on ambient and on fouling.
        Distribution("cooling_capacity", "normal", 90_000.0, 8_000.0,
                     lower=60_000.0),
    ]

    study = MonteCarlo(evaluate, distributions, seed=20260818)

    nominal = study.nominal()
    print("nominal (central) case")
    print(f"  electrical output: {format_power(nominal['electrical_power'])}")
    print(f"  efficiency       : {nominal['efficiency'] * 100:.2f} %")

    result = study.run(SAMPLES)
    stats = result.statistics("electrical_power")
    print(f"\n{len(result)} samples ({len(result.failures)} failures)")
    print("  net electrical output")
    for label in ("p10", "p50", "p90"):
        print(f"    {label.upper():<4}: {format_power(stats[label])}")
    print(f"    mean: {format_power(stats['mean'])}"
          f"  std {format_power(stats['std'])}")
    spread = (stats["p90"] - stats["p10"]) / stats["p50"] * 100.0
    print(f"    P10-P90 spread is {spread:.1f} % of the median")

    print("\n  probability the cooling system is inadequate: "
          f"{result.probability('cooling_margin', 0.0, 'below') * 100:.1f} %")

    print("\n  sensitivity (Spearman rank correlation with output)")
    ranked = sorted(result.sensitivity("electrical_power").items(),
                    key=lambda item: -abs(item[1]))
    for name, value in ranked:
        print(f"    {name:<18}: {value:+.3f}")
    print("  -- rank correlation, not linear: the model is monotonic in these")
    print("     inputs but not linear in any of them.")

    print("\n  convergence of the mean and P90 with sample count")
    for n, mean, p90 in study.convergence("electrical_power", SAMPLES, 6):
        print(f"    n={n:<5} mean {format_power(mean):>9}  "
              f"P90 {format_power(p90):>9}")

    values = sorted(result.values("electrical_power").tolist())
    print(f"\n  sorted output distribution: {sparkline(values, width=60)}")


if __name__ == "__main__":
    main()
