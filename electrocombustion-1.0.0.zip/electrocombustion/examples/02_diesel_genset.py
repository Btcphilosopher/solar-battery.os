"""Example 2 -- the full energy waterfall of a diesel generator set.

Chemical -> thermal -> mechanical -> electrical -> load, with every loss
accounted for.  This is the canonical multi-domain chain the framework exists
to model.

Run:  python examples/02_diesel_genset.py
"""
from __future__ import annotations

from electrocombustion import ElectroCombustionEngine, EngineConfig, SystemState
from electrocombustion.combustion import DIESEL
from electrocombustion.electrical import ElectricalLoad
from electrocombustion.mechanical import FrictionModel
from electrocombustion.systems import (
    CombustionEngine, CombustionEngineComponent, CycleModel, EngineSpec,
    Generator, GeneratorComponent, GeneratorSpec,
)
from electrocombustion.thermal import ConvectionSurface, SurfaceLoss
from electrocombustion.visualisation import format_power, ledger_report


FUEL_FLOW = 0.005          # kg/s
DEMAND = 40_000.0          # W electrical
SPEED = 157.08             # rad/s == 1500 rpm


def build_prime_mover() -> CombustionEngine:
    return CombustionEngine(EngineSpec(
        name="6-cylinder diesel", fuel=DIESEL,
        rated_power=100_000.0, rated_speed=SPEED,
        cycle=CycleModel(kind="diesel", compression_ratio=18.0,
                         cutoff_ratio=2.2, gamma=1.35, quality=0.80),
        friction=FrictionModel(constant=15.0, linear=0.05, quadratic=2e-4),
    ))


def main() -> None:
    prime_mover = build_prime_mover()

    print("steady-state operating point")
    breakdown = prime_mover.evaluate(FUEL_FLOW, SPEED)
    for key in ("chemical_power", "indicated_power", "friction_power",
                "brake_power", "coolant_power", "exhaust_power"):
        print(f"  {key:<18}: {format_power(breakdown[key]):>10}")
    print(f"  brake efficiency  : {breakdown['brake_efficiency'] * 100:>9.2f} %")
    print(f"  bsfc              : {prime_mover.bsfc(FUEL_FLOW, SPEED):>9.1f} g/kWh")

    state = SystemState()
    state.thermal.mass = 400.0                 # engine block + coolant
    state.thermal.specific_heat = 700.0
    state.thermal.gas_constant = 0.0
    state.thermal.temperature = 350.0
    state.ambient_temperature = 293.15
    state.mechanical.inertia = 5.0
    state.mechanical.speed = SPEED

    engine = ElectroCombustionEngine(state, config=EngineConfig(scheme="rk4"))
    engine.add(CombustionEngineComponent("ice", prime_mover, fuel_flow=FUEL_FLOW))
    engine.add(GeneratorComponent("gen", Generator(GeneratorSpec(
        rated_power=50_000.0, rated_speed=SPEED)), demand=DEMAND))
    engine.add(ElectricalLoad("load", power=DEMAND))
    engine.add(SurfaceLoss("radiator",
                           ConvectionSurface(area=6.0, coefficient=25.0)))

    engine.run(120.0, 0.01)

    print()
    print(ledger_report(engine.ledger, "genset energy waterfall"))
    print(f"\nblock temperature after 2 minutes: "
          f"{engine.state.thermal.temperature:.1f} K")
    print(f"fuel-to-load efficiency          : {engine.efficiency() * 100:.2f} %")


if __name__ == "__main__":
    main()
