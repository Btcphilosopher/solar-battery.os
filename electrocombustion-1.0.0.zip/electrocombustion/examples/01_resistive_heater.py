"""Example 1 -- electro-thermal coupling in a resistive heater.

Demonstrates the feedback loop that motivates the whole framework: current
heats the element, the element's resistance rises with temperature, and the
rising resistance reduces the current.  The energy ledger closes exactly.

Run:  python examples/01_resistive_heater.py
"""
from __future__ import annotations

from electrocombustion import ElectroCombustionEngine, EngineConfig, SystemState
from electrocombustion.electrical import DCSource, Geometry, Resistor, ResistiveHeater
from electrocombustion.materials import NICHROME, STEEL_CARBON
from electrocombustion.thermal import ConvectionSurface, RadiatingSurface, SurfaceLoss
from electrocombustion.visualisation import ledger_report, sparkline


def build() -> ElectroCombustionEngine:
    state = SystemState()
    state.thermal.mass = 2.0                       # kg of steel
    state.thermal.specific_heat = STEEL_CARBON.cp(400.0)
    state.thermal.gas_constant = 0.0               # a solid: cv == cp
    state.thermal.temperature = 300.0
    state.ambient_temperature = 300.0

    engine = ElectroCombustionEngine(state, config=EngineConfig(scheme="rk4"))
    element = Resistor("element", material=NICHROME,
                       geometry=Geometry.wire(length=5.0, diameter=1e-3))
    engine.add(ResistiveHeater("heater", element, DCSource(230.0)))
    engine.add(SurfaceLoss("skin",
                           ConvectionSurface(area=0.05, coefficient=15.0),
                           RadiatingSurface(area=0.05, emissivity=0.7)))
    return engine


def main() -> None:
    engine = build()
    element = engine.get("heater").resistor

    print("nichrome element, 5 m of 1 mm wire on 230 V")
    print(f"  cold resistance  : {element.value(300.0):.3f} ohm")
    print(f"  cold power       : {230.0 ** 2 / element.value(300.0) / 1e3:.2f} kW")

    temperatures = []
    for _ in range(1200):
        engine.step(0.5)
        temperatures.append(engine.state.thermal.temperature)

    final = engine.state.thermal.temperature
    print(f"  final temperature: {final:.1f} K ({final - 273.15:.1f} degC)")
    print(f"  hot resistance   : {element.value(final):.3f} ohm")
    print(f"  hot power        : {230.0 ** 2 / element.value(final) / 1e3:.2f} kW")
    print(f"  temperature trace: {sparkline(temperatures)}")
    print()
    print(ledger_report(engine.ledger, "heater energy ledger"))

    summary = engine.energy_summary()
    residual = summary["input"] - summary["losses"] - summary["stored"]
    print(f"\nfirst-law residual: {residual:+.3e} J")


if __name__ == "__main__":
    main()
