"""Conduction, convection, radiation, networks and heat exchangers."""
from __future__ import annotations

import math

import pytest

from electrocombustion.core import units as U
from electrocombustion.materials import ALUMINA, COPPER, MINERAL_WOOL, STEEL_CARBON
from electrocombustion.thermal import (
    CompositeWall, ConvectionSurface, CoolingCircuit, HeatExchanger,
    RadiatingSurface, Slab, ThermalBoundary, ThermalContact, ThermalLink,
    ThermalNetwork, ThermalNode, air_properties, biot_number,
    blackbody_emissive_power, conduction_heat_flow, correlation_warning,
    cylindrical_resistance, forced_convection_flow, fourier_number,
    grey_body_exchange, linearised_coefficient, lmtd, lumped_capacitance_valid,
    lumped_response, newton_cooling, ntu_effectiveness, nusselt_cross_flow_cylinder,
    nusselt_dittus_boelter, nusselt_natural_vertical_plate, overall_coefficient,
    radiative_equilibrium_temperature, rayleigh_number, reynolds_number,
    slab_resistance, spherical_resistance, two_surface_exchange,
    view_factor_coaxial_cylinders, view_factor_parallel_plates,
)


class TestConduction:
    def test_slab_resistance_formula(self):
        assert slab_resistance(0.1, 2.0, 50.0) == pytest.approx(0.1 / (2.0 * 50.0))

    def test_slab_resistance_rejects_zero_area(self):
        with pytest.raises(ValueError):
            slab_resistance(0.1, 0.0, 50.0)

    def test_thicker_slab_resists_more(self):
        assert slab_resistance(0.2, 1.0, 10.0) > slab_resistance(0.1, 1.0, 10.0)

    def test_cylindrical_resistance_is_logarithmic(self):
        r1 = cylindrical_resistance(0.01, 0.02, 1.0, 1.0)
        r2 = cylindrical_resistance(0.01, 0.04, 1.0, 1.0)
        assert r2 == pytest.approx(2.0 * r1)

    def test_cylindrical_requires_outer_greater_than_inner(self):
        with pytest.raises(ValueError):
            cylindrical_resistance(0.02, 0.01, 1.0, 1.0)

    def test_spherical_resistance_is_positive(self):
        assert spherical_resistance(0.01, 0.02, 1.0) > 0.0

    def test_conduction_heat_flow_follows_ohms_law(self):
        assert conduction_heat_flow(400.0, 300.0, 0.5) == pytest.approx(200.0)

    def test_conduction_reverses_with_the_gradient(self):
        assert conduction_heat_flow(300.0, 400.0, 0.5) == pytest.approx(-200.0)

    def test_biot_number_formula(self):
        assert biot_number(10.0, 0.1, 50.0) == pytest.approx(0.02)

    def test_lumped_capacitance_valid_for_small_biot(self):
        assert lumped_capacitance_valid(10.0, 0.01, 400.0)

    def test_lumped_capacitance_invalid_for_large_biot(self):
        assert not lumped_capacitance_valid(1000.0, 0.5, 1.0)

    def test_fourier_number_grows_with_time(self):
        assert fourier_number(1e-5, 100.0, 0.1) > fourier_number(1e-5, 10.0, 0.1)

    def test_slab_object_resistance(self):
        slab = Slab(COPPER, thickness=0.01, area=0.5)
        assert slab.resistance(350.0) == pytest.approx(
            slab_resistance(0.01, 0.5, COPPER.k(350.0)), rel=1e-9)

    def test_slab_mass(self):
        slab = Slab(STEEL_CARBON, thickness=0.02, area=0.5)
        assert slab.mass() == pytest.approx(STEEL_CARBON.density * 0.02 * 0.5)

    def test_slab_capacitance_is_positive(self):
        assert Slab(COPPER, 0.01, 0.5).capacitance(300.0) > 0.0

    def test_insulation_resists_far_more_than_metal(self):
        metal = Slab(COPPER, 0.05, 1.0).resistance(350.0)
        wool = Slab(MINERAL_WOOL, 0.05, 1.0).resistance(350.0)
        assert wool > 100.0 * metal

    def test_composite_wall_adds_resistances(self):
        a = Slab(STEEL_CARBON, 0.01, 1.0)
        b = Slab(MINERAL_WOOL, 0.05, 1.0)
        wall = CompositeWall((a, b))
        total = wall.resistance(500.0, 300.0)
        assert total == pytest.approx(a.resistance(400.0) + b.resistance(400.0),
                                      rel=0.15)

    def test_composite_wall_u_value_is_the_reciprocal(self):
        wall = CompositeWall((Slab(MINERAL_WOOL, 0.1, 1.0),))
        expected = 1.0 / (wall.resistance(400.0, 300.0) * wall.area)
        assert wall.u_value(400.0, 300.0) == pytest.approx(expected, rel=1e-9)

    def test_composite_interface_temperatures_are_monotonic(self):
        wall = CompositeWall((Slab(STEEL_CARBON, 0.01, 1.0),
                              Slab(MINERAL_WOOL, 0.05, 1.0)))
        temps = wall.interface_temperatures(500.0, 300.0)
        assert all(a >= b for a, b in zip(temps, temps[1:]))

    def test_composite_thickness_sums(self):
        wall = CompositeWall((Slab(STEEL_CARBON, 0.01, 1.0),
                              Slab(MINERAL_WOOL, 0.05, 1.0)))
        assert wall.thickness == pytest.approx(0.06)

    def test_thermal_contact_resistance(self):
        contact = ThermalContact(conductance=5000.0, area=0.01)
        assert contact.resistance() == pytest.approx(1.0 / (5000.0 * 0.01))


class TestConvection:
    def test_air_properties_are_physical(self):
        props = air_properties(300.0)
        assert props["rho"] > 0.0
        assert props["k"] > 0.0
        assert 0.5 < props["pr"] < 1.0

    def test_air_density_falls_with_temperature(self):
        assert air_properties(800.0)["rho"] < air_properties(300.0)["rho"]

    def test_reynolds_number_formula(self):
        assert reynolds_number(2.0, 0.5, 1e-5) == pytest.approx(1e5)

    def test_rayleigh_number_is_zero_without_a_gradient(self):
        assert rayleigh_number(300.0, 300.0, 0.1) == pytest.approx(0.0)

    def test_rayleigh_number_grows_with_gradient(self):
        assert rayleigh_number(500.0, 300.0, 0.1) > rayleigh_number(350.0, 300.0, 0.1)

    def test_dittus_boelter_returns_laminar_value_below_transition(self):
        assert nusselt_dittus_boelter(1000.0, 0.7) == pytest.approx(3.66)

    def test_dittus_boelter_turbulent(self):
        assert nusselt_dittus_boelter(1e5, 0.7) > 100.0

    def test_dittus_boelter_heating_exceeds_cooling(self):
        assert (nusselt_dittus_boelter(1e5, 5.0, heating=True)
                > nusselt_dittus_boelter(1e5, 5.0, heating=False))

    def test_natural_convection_nusselt_is_at_least_unity(self):
        assert nusselt_natural_vertical_plate(1e6, 0.7) > 1.0

    def test_cross_flow_cylinder_nusselt_grows_with_reynolds(self):
        assert (nusselt_cross_flow_cylinder(1e5, 0.7)
                > nusselt_cross_flow_cylinder(1e3, 0.7))

    def test_newton_cooling_formula(self):
        assert newton_cooling(10.0, 2.0, 400.0, 300.0) == pytest.approx(2000.0)

    def test_newton_cooling_is_signed(self):
        assert newton_cooling(10.0, 2.0, 300.0, 400.0) < 0.0

    def test_forced_convection_flow_energy_balance(self):
        assert forced_convection_flow(0.5, 4181.0, 300.0, 320.0) == pytest.approx(
            0.5 * 4181.0 * 20.0)

    def test_correlation_warning_fires_in_the_transitional_band(self):
        assert correlation_warning("dittus_boelter", reynolds=5000.0) is not None

    def test_correlation_warning_fires_outside_the_prandtl_range(self):
        assert correlation_warning("dittus_boelter", reynolds=5e4,
                                   prandtl=500.0) is not None

    def test_correlation_warning_silent_inside_range(self):
        assert correlation_warning("dittus_boelter", reynolds=5e4,
                                   prandtl=0.7) is None

    def test_convection_surface_fixed_coefficient(self):
        surface = ConvectionSurface(area=0.5, coefficient=25.0, mode="fixed")
        assert surface.h(400.0, 300.0) == pytest.approx(25.0)

    def test_convection_surface_heat_flow(self):
        surface = ConvectionSurface(area=0.5, coefficient=25.0, mode="fixed")
        assert surface.heat_flow(400.0, 300.0) == pytest.approx(1250.0)

    def test_natural_convection_coefficient_grows_with_gradient(self):
        surface = ConvectionSurface(area=0.5, characteristic_length=0.2,
                                    mode="natural")
        assert surface.h(600.0, 300.0) > surface.h(320.0, 300.0)

    def test_fouling_reduces_heat_flow(self):
        clean = ConvectionSurface(area=1.0, coefficient=50.0)
        fouled = ConvectionSurface(area=1.0, coefficient=50.0, fouling_factor=0.5)
        assert fouled.heat_flow(400.0, 300.0) < clean.heat_flow(400.0, 300.0)


class TestRadiation:
    def test_blackbody_emissive_power(self):
        assert blackbody_emissive_power(1000.0) == pytest.approx(
            U.STEFAN_BOLTZMANN * 1e12)

    def test_grey_body_is_less_than_blackbody(self):
        grey = grey_body_exchange(0.5, 1.0, 1000.0, 300.0)
        black = grey_body_exchange(1.0, 1.0, 1000.0, 300.0)
        assert grey < black

    def test_radiation_scales_as_the_fourth_power(self):
        low = grey_body_exchange(1.0, 1.0, 500.0, 0.001)
        high = grey_body_exchange(1.0, 1.0, 1000.0, 0.001)
        assert high / low == pytest.approx(16.0, rel=1e-3)

    def test_radiation_is_zero_at_equilibrium(self):
        assert grey_body_exchange(0.8, 1.0, 400.0, 400.0) == pytest.approx(0.0)

    def test_radiation_reverses_when_surroundings_are_hotter(self):
        assert grey_body_exchange(0.8, 1.0, 300.0, 500.0) < 0.0

    def test_two_surface_exchange_is_bounded_by_blackbody(self):
        real = two_surface_exchange(1.0, 0.6, 1.0, 0.6, 1.0, 800.0, 300.0)
        ideal = two_surface_exchange(1.0, 1.0, 1.0, 1.0, 1.0, 800.0, 300.0)
        assert real < ideal

    def test_linearised_coefficient_is_positive(self):
        assert linearised_coefficient(0.9, 800.0, 300.0) > 0.0

    def test_linearised_coefficient_reproduces_the_flux(self):
        h = linearised_coefficient(0.9, 800.0, 300.0)
        exact = grey_body_exchange(0.9, 1.0, 800.0, 300.0)
        assert h * 1.0 * (800.0 - 300.0) == pytest.approx(exact, rel=1e-6)

    def test_view_factor_is_bounded(self):
        f = view_factor_parallel_plates(1.0, 1.0, 0.5)
        assert 0.0 <= f <= 1.0

    def test_view_factor_grows_as_plates_approach(self):
        near = view_factor_parallel_plates(1.0, 1.0, 0.1)
        far = view_factor_parallel_plates(1.0, 1.0, 5.0)
        assert near > far

    def test_coaxial_inner_surface_sees_only_the_outer(self):
        assert view_factor_coaxial_cylinders(0.5, 1.0) == pytest.approx(1.0)

    def test_coaxial_rejects_inverted_radii(self):
        with pytest.raises(ValueError):
            view_factor_coaxial_cylinders(1.0, 0.5)

    def test_radiative_equilibrium_temperature(self):
        t = radiative_equilibrium_temperature(1000.0, 1.0, 1.0, 300.0)
        assert grey_body_exchange(1.0, 1.0, t, 300.0) == pytest.approx(1000.0,
                                                                      rel=1e-6)

    def test_radiating_surface_heat_flow(self):
        surface = RadiatingSurface(area=2.0, emissivity=0.8)
        assert surface.heat_flow(800.0, 300.0) == pytest.approx(
            grey_body_exchange(0.8, 2.0, 800.0, 300.0))

    def test_view_factor_reduces_radiation(self):
        full = RadiatingSurface(area=1.0, emissivity=0.9, view_factor=1.0)
        partial = RadiatingSurface(area=1.0, emissivity=0.9, view_factor=0.3)
        assert partial.heat_flow(800.0, 300.0) < full.heat_flow(800.0, 300.0)


class TestThermalNetwork:
    def build(self) -> ThermalNetwork:
        network = ThermalNetwork()
        network.add_node(ThermalNode("body", temperature=300.0, mass=1.0,
                                     specific_heat=500.0))
        network.add_node(ThermalNode("ambient", temperature=300.0, fixed=True))
        network.add_link("body", "ambient", 5.0)
        return network

    def test_steady_state_temperature(self):
        network = self.build()
        network.set_heat_input("body", 1000.0)
        result = network.solve_steady()
        assert result["body"] == pytest.approx(500.0, rel=1e-6)

    def test_steady_state_with_no_input_is_ambient(self):
        network = self.build()
        assert network.solve_steady()["body"] == pytest.approx(300.0, rel=1e-6)

    def test_fixed_node_stays_fixed(self):
        network = self.build()
        network.set_heat_input("body", 1000.0)
        network.step(1.0)
        assert network.temperatures()["ambient"] == pytest.approx(300.0)

    def test_transient_matches_the_analytic_solution(self):
        network = self.build()
        network.set_heat_input("body", 1000.0)
        for _ in range(1000):
            network.step_rk4(0.1)
        expected = lumped_response(300.0, 300.0, 500.0, 5.0, 100.0, 1000.0)
        assert network.temperatures()["body"] == pytest.approx(expected, rel=1e-9)

    def test_heating_raises_the_temperature(self):
        network = self.build()
        network.set_heat_input("body", 500.0)
        network.step(10.0)
        assert network.temperatures()["body"] > 300.0

    def test_duplicate_node_is_rejected(self):
        network = self.build()
        with pytest.raises(ValueError):
            network.add_node(ThermalNode("body"))

    def test_link_to_unknown_node_is_rejected(self):
        network = self.build()
        with pytest.raises(KeyError):
            network.add_link("body", "nowhere", 1.0)

    def test_total_energy_rises_with_temperature(self):
        network = self.build()
        before = network.total_energy()
        network.set_heat_input("body", 1000.0)
        network.step(1.0)
        assert network.total_energy() > before

    def test_stiffness_ratio_is_at_least_one(self):
        network = self.build()
        assert network.stiffness_ratio() >= 1.0

    def test_lumped_response_starts_at_the_initial_value(self):
        assert lumped_response(400.0, 300.0, 1000.0, 5.0, 0.0) == pytest.approx(400.0)

    def test_lumped_response_decays_to_ambient(self):
        assert lumped_response(400.0, 300.0, 1000.0, 5.0, 1e6) == pytest.approx(
            300.0, abs=1e-6)


class TestHeatTransfer:
    def test_lmtd_counterflow(self):
        assert lmtd(400.0, 350.0, 300.0, 330.0) == pytest.approx(59.436, rel=1e-3)

    def test_lmtd_equal_differences_uses_the_arithmetic_mean(self):
        assert lmtd(400.0, 350.0, 250.0, 300.0) == pytest.approx(100.0, rel=1e-9)

    def test_lmtd_rejects_a_temperature_cross(self):
        with pytest.raises(ValueError):
            lmtd(400.0, 350.0, 300.0, 450.0)

    def test_overall_coefficient_is_below_the_worst_film(self):
        u = overall_coefficient(1000.0, 50.0, 0.0, 1.0)
        assert u < 50.0

    def test_ntu_effectiveness_rises_with_ntu(self):
        assert (ntu_effectiveness(3.0, 0.5) > ntu_effectiveness(1.0, 0.5))

    def test_ntu_effectiveness_is_bounded(self):
        assert 0.0 <= ntu_effectiveness(10.0, 1.0) <= 1.0

    def test_boiling_effectiveness_formula(self):
        assert ntu_effectiveness(2.0, 0.0, "boiling") == pytest.approx(
            1.0 - math.exp(-2.0))

    def test_counterflow_beats_parallel_flow(self):
        assert (ntu_effectiveness(2.0, 0.8, "counterflow")
                > ntu_effectiveness(2.0, 0.8, "parallel"))

    def test_heat_exchanger_effectiveness(self):
        hx = HeatExchanger(ua=5000.0, hot_capacity_rate=2000.0,
                           cold_capacity_rate=4000.0)
        assert hx.effectiveness == pytest.approx(0.8328, rel=1e-3)

    def test_heat_exchanger_duty(self):
        hx = HeatExchanger(ua=5000.0, hot_capacity_rate=2000.0,
                           cold_capacity_rate=4000.0)
        assert hx.duty(600.0, 300.0) == pytest.approx(499_700.0, rel=1e-3)

    def test_heat_exchanger_ntu(self):
        hx = HeatExchanger(ua=4000.0, hot_capacity_rate=2000.0,
                           cold_capacity_rate=4000.0)
        assert hx.ntu == pytest.approx(2.0)

    def test_capacity_ratio_is_bounded(self):
        hx = HeatExchanger(hot_capacity_rate=2000.0, cold_capacity_rate=4000.0)
        assert 0.0 <= hx.capacity_ratio <= 1.0

    def test_outlet_temperatures_move_toward_each_other(self):
        hx = HeatExchanger(ua=5000.0, hot_capacity_rate=2000.0,
                           cold_capacity_rate=4000.0)
        hot_out, cold_out = hx.outlet_temperatures(600.0, 300.0)
        assert hot_out < 600.0
        assert cold_out > 300.0

    def test_counterflow_permits_a_temperature_cross(self):
        """With C_hot < C_cold the cold stream can leave above the hot one."""
        hx = HeatExchanger(ua=5000.0, hot_capacity_rate=2000.0,
                           cold_capacity_rate=4000.0)
        hot_out, cold_out = hx.outlet_temperatures(600.0, 300.0)
        assert cold_out > hot_out

    def test_outlet_energy_balance_closes(self):
        hx = HeatExchanger(ua=5000.0, hot_capacity_rate=2000.0,
                           cold_capacity_rate=4000.0)
        hot_out, cold_out = hx.outlet_temperatures(600.0, 300.0)
        given = 2000.0 * (600.0 - hot_out)
        taken = 4000.0 * (cold_out - 300.0)
        assert given == pytest.approx(taken, rel=1e-9)

    def test_required_ua_inverts_duty(self):
        hx = HeatExchanger(ua=1.0, hot_capacity_rate=2000.0,
                           cold_capacity_rate=4000.0)
        ua = hx.required_ua(400_000.0, 600.0, 300.0)
        sized = HeatExchanger(ua=ua, hot_capacity_rate=2000.0,
                              cold_capacity_rate=4000.0)
        assert sized.duty(600.0, 300.0) == pytest.approx(400_000.0, rel=1e-4)

    def test_required_ua_rejects_impossible_duty(self):
        hx = HeatExchanger(ua=1.0, hot_capacity_rate=2000.0,
                           cold_capacity_rate=4000.0)
        with pytest.raises(ValueError):
            hx.required_ua(1e9, 600.0, 300.0)

    def test_fouling_reduces_duty(self):
        clean = HeatExchanger(ua=5000.0, hot_capacity_rate=2000.0,
                              cold_capacity_rate=4000.0, fouling=1.0)
        dirty = HeatExchanger(ua=5000.0, hot_capacity_rate=2000.0,
                              cold_capacity_rate=4000.0, fouling=0.6)
        assert dirty.duty(600.0, 300.0) < clean.duty(600.0, 300.0)

    def test_cooling_circuit_removes_heat(self):
        circuit = CoolingCircuit(mass_flow=0.5, inlet_temperature=300.0,
                                 ua=2000.0)
        assert circuit.heat_removed(400.0) > 0.0

    def test_cooling_circuit_removes_nothing_at_equilibrium(self):
        circuit = CoolingCircuit(mass_flow=0.5, inlet_temperature=400.0,
                                 ua=2000.0)
        assert circuit.heat_removed(400.0) == pytest.approx(0.0, abs=1e-9)

    def test_more_flow_removes_more_heat(self):
        slow = CoolingCircuit(mass_flow=0.1, inlet_temperature=300.0, ua=2000.0)
        fast = CoolingCircuit(mass_flow=1.0, inlet_temperature=300.0, ua=2000.0)
        assert fast.heat_removed(400.0) > slow.heat_removed(400.0)

    def test_outlet_is_warmer_than_inlet(self):
        circuit = CoolingCircuit(mass_flow=0.5, inlet_temperature=300.0,
                                 ua=2000.0)
        assert circuit.outlet_temperature(400.0) > 300.0

    def test_effective_conductance_is_capped_by_capacity_rate(self):
        circuit = CoolingCircuit(mass_flow=0.5, ua=1e9)
        assert circuit.effective_conductance(400.0) <= circuit.capacity_rate + 1e-6

    def test_thermal_boundary_combines_paths(self):
        boundary = ThermalBoundary(
            convection=ConvectionSurface(area=1.0, coefficient=20.0),
            radiation=RadiatingSurface(area=1.0, emissivity=0.9),
            ambient_temperature=300.0)
        assert boundary.heat_flow(600.0) > 0.0

    def test_thermal_boundary_is_zero_at_ambient(self):
        boundary = ThermalBoundary(
            convection=ConvectionSurface(area=1.0, coefficient=20.0),
            ambient_temperature=300.0)
        assert boundary.heat_flow(300.0) == pytest.approx(0.0, abs=1e-9)

    def test_adding_a_wall_reduces_the_heat_flow(self):
        bare = ThermalBoundary(
            convection=ConvectionSurface(area=1.0, coefficient=20.0),
            ambient_temperature=300.0)
        clad = ThermalBoundary(
            convection=ConvectionSurface(area=1.0, coefficient=20.0),
            wall=Slab(MINERAL_WOOL, 0.05, 1.0), ambient_temperature=300.0)
        assert clad.heat_flow(600.0) < bare.heat_flow(600.0)
