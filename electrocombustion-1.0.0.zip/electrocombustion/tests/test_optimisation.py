"""Optimisation, control and model predictive control."""
from __future__ import annotations

import math

import pytest

from electrocombustion.core.engine import ElectroCombustionEngine, EngineConfig
from electrocombustion.core.state import SystemState
from electrocombustion.mechanical import TorqueSource
from electrocombustion.optimisation import (
    BangBangController, Constraint, DesignVariable, FeedforwardController,
    GainSchedule, MPCConfig, ModelPredictiveController, Objective,
    OptimisationResult, Optimiser, PIDController, RateLimiter,
    SupervisoryController, carbon_objective, current_limit,
    dispatch_optimisation, economic_cost, exergy_efficiency_objective,
    fuel_limit, maximise_output, minimise_cost, minimum_output,
    net_electrical_objective, optimise_efficiency, optimise_operating_point,
    required_cooling, sensitivity, size_heat_exchanger,
    specific_consumption_objective, temperature_limit,
    thermal_efficiency_objective, thermal_limit, thermal_margin_constraint,
    tracking_cost, weighted_objective,
)


def quadratic(values):
    """A concave problem whose maximum is at x = 3, y = -2."""
    x, y = values["x"], values["y"]
    return {"output": 100.0 - (x - 3.0) ** 2 - (y + 2.0) ** 2,
            "x": x, "y": y, "sum": x + y}


class TestDesignVariable:
    def test_initial_defaults_to_the_midpoint(self):
        variable = DesignVariable("x", 0.0, 10.0)
        assert variable.initial == pytest.approx(5.0)

    def test_inverted_bounds_are_rejected(self):
        with pytest.raises(ValueError):
            DesignVariable("x", 10.0, 0.0)

    def test_initial_outside_bounds_is_rejected(self):
        with pytest.raises(ValueError):
            DesignVariable("x", 0.0, 10.0, initial=20.0)

    def test_clip_respects_the_bounds(self):
        variable = DesignVariable("x", 0.0, 10.0)
        assert variable.clip(-5.0) == pytest.approx(0.0)
        assert variable.clip(50.0) == pytest.approx(10.0)

    def test_normalise_maps_to_the_unit_interval(self):
        variable = DesignVariable("x", 10.0, 20.0)
        assert variable.normalise(15.0) == pytest.approx(0.5)

    def test_denormalise_inverts_normalise(self):
        variable = DesignVariable("x", 1e-4, 1e-2)
        assert variable.denormalise(variable.normalise(3e-3)) == pytest.approx(3e-3)

    def test_scale_defaults_to_the_span(self):
        assert DesignVariable("x", 0.0, 4.0).scale == pytest.approx(4.0)


class TestConstraint:
    def test_upper_constraint_is_satisfied_below_the_bound(self):
        c = Constraint("t", lambda r: r["t"], 100.0, "upper")
        assert c.satisfied({"t": 50.0})

    def test_upper_constraint_violation_is_the_overshoot(self):
        c = Constraint("t", lambda r: r["t"], 100.0, "upper")
        assert c.violation({"t": 130.0}) == pytest.approx(30.0)

    def test_lower_constraint_is_satisfied_above_the_bound(self):
        c = Constraint("p", lambda r: r["p"], 10.0, "lower")
        assert c.satisfied({"p": 20.0})

    def test_equality_constraint_uses_its_tolerance(self):
        c = Constraint("e", lambda r: r["e"], 5.0, "equal", tolerance=0.1)
        assert c.satisfied({"e": 5.05})
        assert not c.satisfied({"e": 6.0})

    def test_margin_is_positive_when_satisfied(self):
        c = Constraint("t", lambda r: r["t"], 100.0, "upper")
        assert c.margin({"t": 60.0}) == pytest.approx(40.0)

    def test_scale_defaults_to_the_bound(self):
        assert Constraint("t", lambda r: 0.0, 90_000.0).scale == pytest.approx(
            90_000.0)

    def test_scaled_margin_is_dimensionless(self):
        c = Constraint("t", lambda r: r["t"], 1000.0, "upper")
        assert c.scaled_margin({"t": 500.0}) == pytest.approx(0.5)

    def test_tolerance_is_relative_to_the_constraint_scale(self):
        """An optimum sits on the boundary; absolute tolerances reject it."""
        c = Constraint("q", lambda r: r["q"], 90_000.0, "upper")
        assert c.satisfied({"q": 90_000.0 + 0.01})


class TestOptimiser:
    def variables(self):
        return [DesignVariable("x", -10.0, 10.0, 0.0),
                DesignVariable("y", -10.0, 10.0, 0.0)]

    def test_unconstrained_maximum_is_found(self):
        result = maximise_output(quadratic, self.variables(), "output")
        assert result.variables["x"] == pytest.approx(3.0, abs=1e-3)
        assert result.variables["y"] == pytest.approx(-2.0, abs=1e-3)

    def test_objective_value_at_the_optimum(self):
        result = maximise_output(quadratic, self.variables(), "output")
        assert result.objective_value == pytest.approx(100.0, abs=1e-4)

    def test_a_constraint_moves_the_optimum(self):
        constraint = Constraint("x", lambda r: r["x"], 1.0, "upper")
        result = maximise_output(quadratic, self.variables(), "output",
                                 [constraint])
        assert result.variables["x"] <= 1.0 + 1e-6
        assert result.feasible

    def test_minimisation_finds_the_minimum(self):
        variables = [DesignVariable("x", -5.0, 5.0, 1.0),
                     DesignVariable("y", -5.0, 5.0, 1.0)]
        result = minimise_cost(
            lambda v: {"cost": (v["x"] - 1.0) ** 2 + (v["y"] - 2.0) ** 2},
            variables, "cost")
        assert result.variables["x"] == pytest.approx(1.0, abs=1e-3)

    def test_grid_method_works_without_gradients(self):
        optimiser = Optimiser(quadratic, self.variables(),
                              Objective("output", lambda r: r["output"]),
                              method="grid")
        result = optimiser.solve()
        assert result.objective_value > 99.0

    def test_differential_evolution_finds_the_optimum(self):
        optimiser = Optimiser(quadratic, self.variables(),
                              Objective("output", lambda r: r["output"]),
                              method="differential_evolution")
        assert optimiser.solve().objective_value == pytest.approx(100.0, abs=1e-3)

    def test_evaluation_count_is_recorded(self):
        optimiser = Optimiser(quadratic, self.variables(),
                              Objective("output", lambda r: r["output"]))
        optimiser.solve()
        assert optimiser.evaluations > 0

    def test_history_is_recorded_when_asked(self):
        optimiser = Optimiser(quadratic, self.variables(),
                              Objective("output", lambda r: r["output"]),
                              record_history=True)
        result = optimiser.solve()
        assert len(result.history) > 0

    def test_result_indexing_reaches_variables_and_outputs(self):
        result = maximise_output(quadratic, self.variables(), "output")
        assert result["x"] == pytest.approx(result.variables["x"])
        assert result["sum"] == pytest.approx(result.result["sum"])

    def test_summary_is_serialisable(self):
        result = maximise_output(quadratic, self.variables(), "output")
        assert set(result.summary()) >= {"objective", "feasible", "variables"}

    def test_no_variables_is_rejected(self):
        with pytest.raises(ValueError):
            Optimiser(quadratic, [], Objective("output", lambda r: 0.0))

    def test_unknown_method_is_rejected(self):
        optimiser = Optimiser(quadratic, self.variables(),
                              Objective("output", lambda r: 0.0),
                              method="telepathy")
        with pytest.raises(ValueError):
            optimiser.solve()

    def test_infeasible_problem_is_reported_not_hidden(self):
        constraints = [Constraint("a", lambda r: r["x"], -20.0, "upper"),
                       Constraint("b", lambda r: r["x"], 20.0, "lower")]
        result = maximise_output(quadratic, self.variables(), "output",
                                 constraints)
        assert not result.feasible

    def test_badly_scaled_problem_still_converges(self):
        """Mixed magnitudes are what break a naive gradient search."""
        def model(v):
            return {"power": v["fuel"] * 1e7 - v["speed"] ** 2 * 0.5,
                    "fuel": v["fuel"], "speed": v["speed"]}

        variables = [DesignVariable("fuel", 1e-4, 1e-2, 1e-3),
                     DesignVariable("speed", 50.0, 300.0, 150.0)]
        constraint = Constraint("fuel_cap", lambda r: r["fuel"], 5e-3, "upper")
        result = maximise_output(model, variables, "power", [constraint])
        assert result.feasible
        assert result.variables["fuel"] == pytest.approx(5e-3, rel=1e-3)


class TestSystemOptimisation:
    def model(self, diesel_engine, genset):
        def evaluate(v):
            r = diesel_engine.evaluate(v["fuel_flow"], v["speed"])
            return {
                "electrical_power": genset.electrical_power(r["brake_power"],
                                                            v["speed"]),
                "chemical_power": r["chemical_power"],
                "fuel_flow": v["fuel_flow"], "speed": v["speed"],
                "heat_rejection": r["coolant_power"] + r["exhaust_power"],
            }
        return evaluate

    def variables(self):
        return [DesignVariable("fuel_flow", 1e-4, 0.012, 0.004),
                DesignVariable("speed", 80.0, 220.0, 157.0)]

    def test_optimum_respects_a_thermal_limit(self, diesel_engine, genset):
        constraints = [fuel_limit("fuel_flow", 0.008),
                       thermal_limit("heat_rejection", 90_000.0)]
        result = optimise_operating_point(self.model(diesel_engine, genset),
                                          self.variables(), constraints)
        assert result.feasible
        assert result.result["heat_rejection"] <= 90_000.0 * (1.0 + 1e-6)

    def test_optimum_sits_on_the_active_constraint(self, diesel_engine, genset):
        constraints = [fuel_limit("fuel_flow", 0.008),
                       thermal_limit("heat_rejection", 90_000.0)]
        result = optimise_operating_point(self.model(diesel_engine, genset),
                                          self.variables(), constraints)
        assert result.result["heat_rejection"] == pytest.approx(90_000.0,
                                                                rel=1e-3)

    def test_tighter_limits_reduce_the_output(self, diesel_engine, genset):
        model = self.model(diesel_engine, genset)
        loose = optimise_operating_point(
            model, self.variables(), [thermal_limit("heat_rejection", 120_000.0)])
        tight = optimise_operating_point(
            model, self.variables(), [thermal_limit("heat_rejection", 60_000.0)])
        assert tight.objective_value < loose.objective_value

    def test_efficiency_optimum_differs_from_the_power_optimum(self,
                                                               diesel_engine,
                                                               genset):
        model = self.model(diesel_engine, genset)
        power = optimise_operating_point(model, self.variables())
        efficiency = optimise_efficiency(model, self.variables())
        assert efficiency.variables["fuel_flow"] < power.variables["fuel_flow"]


class TestObjectives:
    def test_net_objective_subtracts_parasitics(self):
        objective = net_electrical_objective()
        assert objective.value({"electrical_power": 100.0,
                                "parasitic_power": 30.0}) == pytest.approx(70.0)

    def test_thermal_efficiency_objective(self):
        objective = thermal_efficiency_objective()
        assert objective.value({"electrical_power": 40.0,
                                "chemical_power": 100.0}) == pytest.approx(0.4)

    def test_efficiency_is_zero_without_input(self):
        objective = thermal_efficiency_objective()
        assert objective.value({"electrical_power": 40.0,
                                "chemical_power": 0.0}) == pytest.approx(0.0)

    def test_exergy_efficiency_exceeds_first_law_efficiency(self):
        result = {"electrical_power": 30.0, "heat_input": 100.0,
                  "source_temperature": 600.0, "ambient_temperature": 300.0}
        first_law = 0.30
        assert exergy_efficiency_objective().value(result) > first_law

    def test_exergy_is_zero_when_the_source_is_at_ambient(self):
        result = {"electrical_power": 30.0, "heat_input": 100.0,
                  "source_temperature": 300.0, "ambient_temperature": 300.0}
        assert exergy_efficiency_objective().value(result) == pytest.approx(0.0)

    def test_specific_consumption_penalises_zero_output(self):
        objective = specific_consumption_objective()
        assert objective.value({"fuel_flow": 0.01,
                                "electrical_power": 0.0}) > 1e6

    def test_carbon_objective_is_minimised(self):
        assert carbon_objective().sense == "minimise"

    def test_weighted_objective_combines_senses(self):
        combined = weighted_objective([
            (thermal_efficiency_objective(), 1.0),
            (carbon_objective(), 0.5),
        ])
        value = combined.value({"electrical_power": 40.0,
                                "chemical_power": 100.0, "co2_rate": 0.01})
        assert math.isfinite(value)

    def test_empty_weighted_objective_is_rejected(self):
        with pytest.raises(ValueError):
            weighted_objective([])

    def test_sensitivity_returns_an_elasticity_per_input(self):
        result = sensitivity(lambda v: {"y": 2.0 * v["a"] + v["b"]},
                             {"a": 10.0, "b": 5.0}, "y")
        assert set(result) == {"a", "b"}

    def test_sensitivity_ranks_the_dominant_input_higher(self):
        result = sensitivity(lambda v: {"y": 10.0 * v["a"] + v["b"]},
                             {"a": 10.0, "b": 10.0}, "y")
        assert result["a"] > result["b"]


class TestThermalOptimisation:
    def test_required_cooling_removes_the_load(self):
        flow = required_cooling(20_000.0, 400.0, 300.0, 2000.0)
        assert flow > 0.0

    def test_required_cooling_rejects_an_impossible_duty(self):
        with pytest.raises(ValueError):
            required_cooling(1e9, 400.0, 300.0, 2000.0)

    def test_required_cooling_rejects_a_cold_body(self):
        with pytest.raises(ValueError):
            required_cooling(1000.0, 300.0, 400.0, 2000.0)

    def test_no_load_needs_no_flow(self):
        assert required_cooling(0.0, 400.0, 300.0, 2000.0) == pytest.approx(0.0)

    def test_size_heat_exchanger_returns_a_usable_ua(self):
        ua = size_heat_exchanger(300_000.0, 600.0, 300.0, 2000.0, 4000.0)
        assert ua > 0.0

    def test_thermal_margin_constraint_reserves_headroom(self):
        constraint = thermal_margin_constraint("temperature", 1200.0, 50.0)
        assert constraint.satisfied({"temperature": 1140.0})
        assert not constraint.satisfied({"temperature": 1180.0})


class TestDispatch:
    def test_merit_order_uses_the_cheapest_first(self):
        result = dispatch_optimisation([30.0, 80.0], [1.0, 0.2], 50.0)
        assert result["allocation"][1] == pytest.approx(50.0)

    def test_unmet_demand_is_reported(self):
        result = dispatch_optimisation([10.0, 10.0], [1.0, 2.0], 50.0)
        assert result["unmet"] == pytest.approx(30.0)

    def test_efficiency_changes_the_merit_order(self):
        result = dispatch_optimisation([30.0, 80.0], [1.0, 1.0], 20.0,
                                       efficiencies=[0.9, 0.3])
        assert result["allocation"][0] == pytest.approx(20.0)

    def test_mismatched_lists_are_rejected(self):
        with pytest.raises(ValueError):
            dispatch_optimisation([10.0], [1.0, 2.0], 5.0)


class TestPID:
    def test_proportional_response(self):
        pid = PIDController(kp=2.0, ki=0.0, kd=0.0)
        assert pid.update(0.0, 0.1, setpoint=10.0) == pytest.approx(20.0)

    def test_zero_error_gives_zero_output(self):
        pid = PIDController(kp=2.0)
        assert pid.update(10.0, 0.1, setpoint=10.0) == pytest.approx(0.0)

    def test_integral_accumulates(self):
        pid = PIDController(kp=0.0, ki=1.0)
        first = pid.update(0.0, 1.0, setpoint=1.0)
        second = pid.update(0.0, 1.0, setpoint=1.0)
        assert second > first

    def test_output_is_clamped(self):
        pid = PIDController(kp=100.0, output_min=-5.0, output_max=5.0)
        assert pid.update(0.0, 0.1, setpoint=10.0) == pytest.approx(5.0)

    def test_saturation_is_reported(self):
        pid = PIDController(kp=100.0, output_max=5.0)
        pid.update(0.0, 0.1, setpoint=10.0)
        assert pid.saturated

    def test_anti_windup_prevents_integral_runaway(self):
        pid = PIDController(kp=1.0, ki=10.0, output_max=1.0)
        for _ in range(100):
            pid.update(0.0, 0.1, setpoint=10.0)
        wound = pid.integral
        pid.update(20.0, 0.1, setpoint=10.0)
        assert abs(pid.integral) < abs(wound) + 1e-9

    def test_rate_limit_restricts_the_step(self):
        pid = PIDController(kp=100.0, rate_limit=1.0)
        assert pid.update(0.0, 0.1, setpoint=10.0) <= 0.1 + 1e-9

    def test_reset_clears_the_integral(self):
        pid = PIDController(kp=1.0, ki=1.0)
        pid.update(0.0, 1.0, setpoint=1.0)
        pid.reset()
        assert pid.integral == pytest.approx(0.0)

    def test_zero_dt_is_rejected(self):
        with pytest.raises(ValueError):
            PIDController().update(0.0, 0.0)

    def test_inverted_output_limits_are_rejected(self):
        with pytest.raises(ValueError):
            PIDController(output_min=5.0, output_max=-5.0)

    def test_pid_converges_on_a_first_order_plant(self):
        pid = PIDController(kp=2.0, ki=1.0, output_min=0.0, output_max=100.0)
        value = 0.0
        for _ in range(2000):
            command = pid.update(value, 0.01, setpoint=10.0)
            value += (command - value) * 0.01
        assert value == pytest.approx(10.0, rel=0.02)

    def test_ziegler_nichols_sets_all_three_gains(self):
        pid = PIDController()
        pid.tune_ziegler_nichols(4.0, 2.0)
        assert pid.kp > 0.0 and pid.ki > 0.0 and pid.kd > 0.0

    def test_ziegler_nichols_rejects_bad_inputs(self):
        with pytest.raises(ValueError):
            PIDController().tune_ziegler_nichols(0.0, 1.0)


class TestOtherControllers:
    def test_gain_schedule_interpolates(self):
        schedule = GainSchedule((0.0, 100.0), ((1.0, 0.1, 0.0),
                                               (2.0, 0.2, 0.0)))
        assert schedule(50.0)[0] == pytest.approx(1.5)

    def test_gain_schedule_clamps(self):
        schedule = GainSchedule((0.0, 100.0), ((1.0, 0.1, 0.0),
                                               (2.0, 0.2, 0.0)))
        assert schedule(-50.0)[0] == pytest.approx(1.0)

    def test_gain_schedule_applies_to_a_controller(self):
        pid = PIDController()
        schedule = GainSchedule((0.0, 100.0), ((1.0, 0.1, 0.0),
                                               (2.0, 0.2, 0.0)))
        schedule.apply(pid, 100.0)
        assert pid.kp == pytest.approx(2.0)

    def test_gain_schedule_rejects_unsorted_points(self):
        with pytest.raises(ValueError):
            GainSchedule((100.0, 0.0), ((1.0, 0.0, 0.0), (2.0, 0.0, 0.0)))

    def test_feedforward_alone_uses_the_model(self):
        controller = FeedforwardController(model=lambda s: 2.0 * s)
        assert controller.update(10.0, 0.0, 0.1) == pytest.approx(20.0)

    def test_feedforward_adds_the_feedback_term(self):
        controller = FeedforwardController(model=lambda s: 2.0 * s,
                                           feedback=PIDController(kp=1.0))
        assert controller.update(10.0, 5.0, 0.1) == pytest.approx(25.0)

    def test_bang_bang_switches_on_below_the_band(self):
        controller = BangBangController(setpoint=100.0, deadband=10.0)
        assert controller.update(80.0) == pytest.approx(1.0)

    def test_bang_bang_switches_off_above_the_band(self):
        controller = BangBangController(setpoint=100.0, deadband=10.0)
        controller.update(80.0)
        assert controller.update(120.0) == pytest.approx(0.0)

    def test_bang_bang_holds_inside_the_deadband(self):
        controller = BangBangController(setpoint=100.0, deadband=10.0)
        controller.update(80.0)
        assert controller.update(100.0) == pytest.approx(1.0)

    def test_rate_limiter_restricts_the_change(self):
        limiter = RateLimiter(rate=1.0)
        assert limiter(100.0, 0.1) == pytest.approx(0.1)

    def test_rate_limiter_reaches_the_target_eventually(self):
        limiter = RateLimiter(rate=1.0)
        for _ in range(200):
            limiter(10.0, 0.1)
        assert limiter.value == pytest.approx(10.0)

    def test_rate_limiter_rejects_a_zero_rate(self):
        with pytest.raises(ValueError):
            RateLimiter(rate=0.0)

    def test_supervisory_controller_returns_named_inputs(self):
        supervisor = SupervisoryController()
        supervisor.add_loop("temperature", PIDController(kp=1.0, setpoint=400.0),
                            lambda s: s.thermal.temperature, "heater.duty")
        outputs = supervisor.update(SystemState(), 0.1)
        assert "heater.duty" in outputs

    def test_supervisory_static_inputs_pass_through(self):
        supervisor = SupervisoryController().set_input("fuel", 0.01)
        assert supervisor.update(SystemState(), 0.1)["fuel"] == pytest.approx(0.01)

    def test_setting_a_setpoint_on_an_unknown_loop_raises(self):
        with pytest.raises(KeyError):
            SupervisoryController().set_setpoint("nothing", 1.0)


class TestMPC:
    def build(self):
        state = SystemState()
        state.mechanical.inertia = 2.0
        engine = ElectroCombustionEngine(state,
                                         config=EngineConfig(scheme="rk4"))
        engine.add(TorqueSource("src", input_key="src.torque"))
        return engine

    def test_config_rejects_a_zero_horizon(self):
        with pytest.raises(ValueError):
            MPCConfig(horizon=0)

    def test_config_rejects_a_control_horizon_beyond_the_prediction(self):
        with pytest.raises(ValueError):
            MPCConfig(horizon=5, control_horizon=10)

    def test_rollout_does_not_advance_the_engine(self):
        engine = self.build()
        controller = ModelPredictiveController(
            engine, [DesignVariable("src.torque", 0.0, 50.0, 10.0)],
            tracking_cost(20.0, lambda s: s.mechanical.speed),
            MPCConfig(horizon=5, dt=0.1))
        controller.rollout({"src.torque": 10.0})
        assert engine.state.time == pytest.approx(0.0)

    def test_rollout_reports_a_cost(self):
        engine = self.build()
        controller = ModelPredictiveController(
            engine, [DesignVariable("src.torque", 0.0, 50.0, 10.0)],
            tracking_cost(20.0, lambda s: s.mechanical.speed),
            MPCConfig(horizon=5, dt=0.1))
        assert "cost" in controller.rollout({"src.torque": 10.0})

    def test_controller_drives_towards_the_target(self):
        engine = self.build()
        controller = ModelPredictiveController(
            engine, [DesignVariable("src.torque", 0.0, 100.0, 0.0)],
            tracking_cost(20.0, lambda s: s.mechanical.speed),
            MPCConfig(horizon=10, dt=0.1))
        move = controller.solve()
        assert move["src.torque"] > 0.0

    def test_controller_backs_off_once_at_target(self):
        engine = self.build()
        engine.state.mechanical.speed = 20.0
        controller = ModelPredictiveController(
            engine, [DesignVariable("src.torque", -50.0, 50.0, 0.0)],
            tracking_cost(20.0, lambda s: s.mechanical.speed),
            MPCConfig(horizon=10, dt=0.1))
        assert abs(controller.solve()["src.torque"]) < 5.0

    def test_no_variables_is_rejected(self):
        engine = self.build()
        with pytest.raises(ValueError):
            ModelPredictiveController(
                engine, [], tracking_cost(1.0, lambda s: s.mechanical.speed))

    def test_tracking_cost_is_zero_on_target(self):
        cost = tracking_cost(20.0, lambda s: s.mechanical.speed)
        state = SystemState()
        state.mechanical.speed = 20.0
        assert cost(state, {}) == pytest.approx(0.0)

    def test_effort_penalty_raises_the_cost(self):
        cost = tracking_cost(20.0, lambda s: s.mechanical.speed,
                             effort_keys=("u",), effort_weight=1.0)
        state = SystemState()
        state.mechanical.speed = 20.0
        assert cost(state, {"u": 3.0}) == pytest.approx(9.0)

    def test_economic_cost_rewards_output(self):
        cost = economic_cost(lambda s: s.mechanical.speed, price=2.0)
        state = SystemState()
        state.mechanical.speed = 10.0
        assert cost(state, {}) == pytest.approx(-20.0)

    def test_rollout_count_increases(self):
        engine = self.build()
        controller = ModelPredictiveController(
            engine, [DesignVariable("src.torque", 0.0, 50.0, 10.0)],
            tracking_cost(20.0, lambda s: s.mechanical.speed),
            MPCConfig(horizon=3, dt=0.1))
        controller.rollout({"src.torque": 10.0})
        controller.rollout({"src.torque": 20.0})
        assert controller.rollout_count == 2
