"""Engine-facing components across every domain.

These are the pieces that couple the physics libraries to the solver, so the
tests here check the *coupling*: that flows are emitted in the right direction,
that losses land in the right domain, and that the ledger closes.
"""
from __future__ import annotations

import math

import pytest

from electrocombustion.combustion import (
    Burner, FuelSupply, IgnitionCriteria, IgnitionModel, Igniter, METHANE,
    TransientCombustor, WiebeFunction,
)
from electrocombustion.core.component import Context
from electrocombustion.core.engine import ElectroCombustionEngine, EngineConfig
from electrocombustion.core.events import Severity
from electrocombustion.core.state import EnergyDomain, SystemState
from electrocombustion.electrical import (
    Battery, BatteryComponent, ConverterComponent, DCSource, ElectricalLoad,
    ElectricalMachine, Geometry, GridSupply, MotorComponent, PowerConverter,
    Resistor, ResistiveHeater,
)
from electrocombustion.materials import NICHROME
from electrocombustion.mechanical import (
    ConstantTorque, FrictionModel, Gearbox, GearboxComponent, MechanicalLoad,
    QuadraticLoad, ShaftDynamics, TorqueSource, ViscousLoad,
)
from electrocombustion.systems import (
    CombustionEngine, CombustionEngineComponent, CycleModel, ElectricHeaterSystem,
    EngineSpec, Generator, GeneratorComponent, GeneratorSpec, HeaterComponent,
    HeaterSpec, HybridComponent, HybridController, RecoveryComponent,
    RecoverySpec, SourceSpec, WasteHeatRecovery,
)
from electrocombustion.thermal import (
    ConvectionSurface, CoolingCircuit, CoolingLoop, HeatExchanger,
    HeatExchangerComponent, RadiatingSurface, SurfaceLoss, ThermalBoundary,
    ThermalLosses, ThermalMass,
)


def solid_engine(temperature: float = 300.0,
                 mass: float = 2.0) -> ElectroCombustionEngine:
    state = SystemState()
    state.thermal.mass = mass
    state.thermal.specific_heat = 500.0
    state.thermal.gas_constant = 0.0
    state.thermal.temperature = temperature
    state.ambient_temperature = 300.0
    return ElectroCombustionEngine(state, config=EngineConfig(scheme="rk4"))


def flows_of(component, state=None, dt=0.1, **inputs):
    context = Context(inputs=dict(inputs))
    return component.evaluate(state or SystemState(), dt, context)


def net_into(output, domain: EnergyDomain) -> float:
    total = 0.0
    for flow in output.flows:
        if flow.target is domain:
            total += flow.watts
        if flow.source is domain:
            total -= flow.watts
    return total


class TestElectricalComponents:
    def heater(self) -> ResistiveHeater:
        return ResistiveHeater(
            "heater",
            Resistor("element", material=NICHROME,
                     geometry=Geometry.wire(5.0, 1e-3)),
            DCSource(230.0))

    def test_resistive_heater_draws_from_the_source(self):
        output = flows_of(self.heater())
        assert net_into(output, EnergyDomain.ELECTRICAL) == pytest.approx(0.0)

    def test_resistive_heater_delivers_all_power_as_heat(self):
        output = flows_of(self.heater())
        assert net_into(output, EnergyDomain.THERMAL) > 0.0

    def test_resistive_heater_power_matches_ohms_law(self):
        heater = self.heater()
        state = SystemState()
        output = flows_of(heater, state)
        resistance = heater.resistor.value(state.thermal.temperature)
        assert output.derivatives.heat_input == pytest.approx(
            230.0 ** 2 / resistance, rel=1e-9)

    def test_duty_scales_the_power(self):
        heater = self.heater()
        full = flows_of(heater).derivatives.heat_input
        half = flows_of(heater, **{"heater.duty": 0.5}).derivatives.heat_input
        assert half == pytest.approx(0.5 * full, rel=1e-9)

    def test_heater_power_falls_as_the_element_heats(self):
        heater = self.heater()
        cold = SystemState()
        hot = SystemState()
        hot.thermal.temperature = 1200.0
        assert (flows_of(heater, hot).derivatives.heat_input
                < flows_of(heater, cold).derivatives.heat_input)

    def test_electrical_load_is_labelled_as_delivered(self):
        output = flows_of(ElectricalLoad("load", power=500.0))
        assert any(f.label == "load" for f in output.flows)

    def test_load_profile_is_time_dependent(self):
        load = ElectricalLoad("load", profile=lambda t: 100.0 * t)
        state = SystemState()
        state.time = 3.0
        assert flows_of(load, state).flows[0].watts == pytest.approx(300.0)

    def test_grid_supply_is_capped(self):
        supply = GridSupply("grid", power=5000.0, max_power=1000.0)
        assert flows_of(supply).flows[0].watts == pytest.approx(1000.0)

    def test_grid_supply_at_the_cap_reports_a_limit(self):
        supply = GridSupply("grid", power=5000.0, max_power=1000.0)
        assert flows_of(supply).severity is not Severity.NORMAL

    def test_converter_losses_reach_the_thermal_domain(self):
        component = ConverterComponent(
            "conv", PowerConverter("c", rated_power=10_000.0, efficiency=0.9),
            output_power=5000.0)
        assert net_into(flows_of(component), EnergyDomain.THERMAL) > 0.0

    def test_converter_input_exceeds_its_output(self):
        component = ConverterComponent(
            "conv", PowerConverter("c", rated_power=10_000.0, efficiency=0.9),
            output_power=5000.0)
        output = flows_of(component)
        supplied = sum(f.watts for f in output.flows
                       if f.source is EnergyDomain.SOURCE)
        assert supplied > 5000.0

    def test_battery_discharge_supplies_the_bus(self):
        component = BatteryComponent("batt", Battery(capacity=36_000.0, soc=0.8),
                                     current=50.0)
        assert net_into(flows_of(component), EnergyDomain.ELECTRICAL) > 0.0

    def test_battery_charging_absorbs_from_the_bus(self):
        component = BatteryComponent("batt", Battery(capacity=36_000.0, soc=0.5),
                                     current=-50.0)
        assert net_into(flows_of(component), EnergyDomain.ELECTRICAL) < 0.0

    def test_battery_internal_losses_are_reported(self):
        component = BatteryComponent("batt", Battery(capacity=36_000.0, soc=0.8),
                                     current=50.0)
        output = flows_of(component)
        assert any("loss" in f.label for f in output.flows)

    def test_motor_component_produces_torque(self):
        component = MotorComponent(
            "motor", ElectricalMachine("m", kt=0.5, rated_torque=100.0),
            voltage=48.0)
        assert flows_of(component).derivatives.torque > 0.0

    def test_motor_component_delivers_mechanical_power_when_turning(self):
        component = MotorComponent(
            "motor", ElectricalMachine("m", kt=0.5, rated_torque=100.0),
            voltage=48.0)
        state = SystemState()
        state.mechanical.speed = 50.0
        output = flows_of(component, state)
        assert any(f.target is EnergyDomain.MECHANICAL for f in output.flows)

    def test_a_stalled_motor_turns_everything_into_heat(self):
        """At zero speed there is no mechanical output, only copper loss."""
        component = MotorComponent(
            "motor", ElectricalMachine("m", kt=0.5, rated_torque=100.0),
            voltage=48.0)
        output = flows_of(component)
        assert not any(f.target is EnergyDomain.MECHANICAL for f in output.flows)
        assert net_into(output, EnergyDomain.THERMAL) > 0.0


class TestThermalComponents:
    def test_surface_loss_removes_heat(self):
        component = SurfaceLoss("loss",
                                ConvectionSurface(area=0.5, coefficient=20.0))
        state = SystemState()
        state.thermal.temperature = 600.0
        state.ambient_temperature = 300.0
        assert flows_of(component, state).derivatives.heat_input < 0.0

    def test_surface_loss_is_zero_at_ambient(self):
        component = SurfaceLoss("loss",
                                ConvectionSurface(area=0.5, coefficient=20.0))
        state = SystemState()
        state.thermal.temperature = 300.0
        state.ambient_temperature = 300.0
        assert flows_of(component, state).derivatives.heat_input == (
            pytest.approx(0.0, abs=1e-9))

    def test_surface_loss_reverses_when_ambient_is_hotter(self):
        component = SurfaceLoss("loss",
                                ConvectionSurface(area=0.5, coefficient=20.0))
        state = SystemState()
        state.thermal.temperature = 300.0
        state.ambient_temperature = 500.0
        assert flows_of(component, state).derivatives.heat_input > 0.0

    def test_radiation_adds_to_the_loss(self):
        state = SystemState()
        state.thermal.temperature = 900.0
        state.ambient_temperature = 300.0
        convective = SurfaceLoss("a", ConvectionSurface(area=0.5,
                                                        coefficient=20.0))
        combined = SurfaceLoss("b", ConvectionSurface(area=0.5,
                                                      coefficient=20.0),
                               RadiatingSurface(area=0.5, emissivity=0.9))
        assert (flows_of(combined, state).derivatives.heat_input
                < flows_of(convective, state).derivatives.heat_input)

    def test_thermal_losses_through_a_boundary(self):
        boundary = ThermalBoundary(
            convection=ConvectionSurface(area=1.0, coefficient=25.0),
            ambient_temperature=300.0)
        state = SystemState()
        state.thermal.temperature = 600.0
        assert flows_of(ThermalLosses("wall", boundary),
                        state).derivatives.heat_input < 0.0

    def test_cooling_loop_removes_heat(self):
        component = CoolingLoop("cool", CoolingCircuit(mass_flow=0.5,
                                                       inlet_temperature=300.0,
                                                       ua=2000.0))
        state = SystemState()
        state.thermal.temperature = 500.0
        assert flows_of(component, state).derivatives.heat_input < 0.0

    def test_cooling_loop_flow_can_be_commanded(self):
        component = CoolingLoop("cool", CoolingCircuit(mass_flow=0.5,
                                                       inlet_temperature=300.0,
                                                       ua=2000.0))
        state = SystemState()
        state.thermal.temperature = 500.0
        slow = flows_of(component, state, **{"cool.flow": 0.05})
        fast = flows_of(component, state, **{"cool.flow": 1.0})
        assert fast.derivatives.heat_input < slow.derivatives.heat_input

    def test_cooling_loop_pump_power_is_charged_honestly(self):
        component = CoolingLoop("cool",
                                CoolingCircuit(mass_flow=0.5,
                                               inlet_temperature=300.0,
                                               ua=2000.0, pump_power=200.0))
        state = SystemState()
        state.thermal.temperature = 500.0
        output = flows_of(component, state)
        assert any("pump" in f.label for f in output.flows)

    def test_thermal_mass_injects_commanded_heat(self):
        component = ThermalMass("soak", heat=750.0)
        assert flows_of(component).derivatives.heat_input == pytest.approx(750.0)

    def test_thermal_mass_accepts_a_negative_command(self):
        component = ThermalMass("soak", heat=-750.0)
        assert flows_of(component).derivatives.heat_input == pytest.approx(-750.0)

    def test_heat_exchanger_component_rejects_heat(self):
        component = HeatExchangerComponent(
            "hx", HeatExchanger(ua=5000.0, hot_capacity_rate=2000.0,
                                cold_capacity_rate=4000.0),
            cold_inlet=300.0)
        state = SystemState()
        state.thermal.temperature = 600.0
        assert flows_of(component, state).derivatives.heat_input < 0.0

    def test_heat_exchanger_does_nothing_without_a_gradient(self):
        component = HeatExchangerComponent(
            "hx", HeatExchanger(ua=5000.0, hot_capacity_rate=2000.0,
                                cold_capacity_rate=4000.0),
            cold_inlet=400.0)
        state = SystemState()
        state.thermal.temperature = 400.0
        assert flows_of(component, state).derivatives.heat_input == (
            pytest.approx(0.0, abs=1e-9))


class TestCombustionComponents:
    def test_burner_releases_heat(self):
        burner = Burner("burner", METHANE, fuel_flow=0.001)
        assert flows_of(burner).derivatives.heat_input > 0.0

    def test_burner_chemical_input_matches_the_fuel(self):
        burner = Burner("burner", METHANE, fuel_flow=0.001)
        output = flows_of(burner)
        supplied = sum(f.watts for f in output.flows
                       if f.source is EnergyDomain.SOURCE)
        assert supplied == pytest.approx(0.001 * METHANE.lhv, rel=1e-9)

    def test_burner_energy_balance_closes(self):
        burner = Burner("burner", METHANE, fuel_flow=0.001)
        output = flows_of(burner)
        assert net_into(output, EnergyDomain.CHEMICAL) == pytest.approx(0.0,
                                                                       abs=1e-6)

    def test_rich_burner_leaves_unburned_fuel(self):
        burner = Burner("burner", METHANE, fuel_flow=0.001,
                        equivalence_ratio=2.5)
        output = flows_of(burner)
        assert any("unburned" in f.label for f in output.flows)

    def test_burner_fuel_flow_can_be_commanded(self):
        burner = Burner("burner", METHANE)
        assert flows_of(burner, **{"burner.fuel_flow": 0.002}
                        ).derivatives.heat_input > 0.0

    def test_air_flow_determines_the_equivalence_ratio(self):
        burner = Burner("burner", METHANE, fuel_flow=0.001)
        stoichiometric = 0.001 * METHANE.stoichiometric_afr
        output = flows_of(burner, **{"burner.air_flow": stoichiometric})
        assert output.diagnostics["burner.phi"] == pytest.approx(1.0, rel=1e-6)

    def test_burner_without_ignition_reports_a_warning(self):
        ignition = IgnitionModel(
            criteria=IgnitionCriteria(minimum_temperature=500.0),
            mode="spark", igniter=Igniter(energy=0.0, duration=0.0))
        burner = Burner("burner", METHANE, fuel_flow=0.001, ignition=ignition)
        state = SystemState()
        state.thermal.temperature = 250.0
        output = flows_of(burner, state)
        assert output.severity is Severity.WARNING

    def test_unlit_burner_releases_no_heat(self):
        ignition = IgnitionModel(
            criteria=IgnitionCriteria(minimum_temperature=500.0),
            mode="spark", igniter=Igniter(energy=0.0, duration=0.0))
        burner = Burner("burner", METHANE, fuel_flow=0.001, ignition=ignition)
        state = SystemState()
        state.thermal.temperature = 250.0
        assert flows_of(burner, state).derivatives.heat_input == pytest.approx(0.0)

    def test_fuel_supply_meters_without_burning(self):
        supply = FuelSupply("fuel", METHANE, flow=0.001)
        output = flows_of(supply)
        assert output.derivatives.heat_input == pytest.approx(0.0)
        assert output.derivatives.chemical_storage_rate > 0.0

    def test_transient_combustor_burns_progressively(self):
        combustor = TransientCombustor("comb", METHANE,
                                       WiebeFunction(duration=0.01),
                                       charge_mass=1e-3)
        combustor.active = True
        state = SystemState()
        state.thermal.temperature = 1500.0
        state.chemical.reaction_progress = 0.3
        assert flows_of(combustor, state, dt=1e-4).derivatives.heat_input > 0.0

    def test_transient_combustor_stops_when_complete(self):
        combustor = TransientCombustor("comb", METHANE,
                                       WiebeFunction(duration=0.01))
        combustor.active = True
        state = SystemState()
        state.chemical.reaction_progress = 1.0
        assert flows_of(combustor, state, dt=1e-4).derivatives.heat_input == (
            pytest.approx(0.0))

    def test_inactive_combustor_releases_nothing(self):
        combustor = TransientCombustor("comb", METHANE,
                                       WiebeFunction(duration=0.01))
        state = SystemState()
        state.thermal.temperature = 1500.0
        assert flows_of(combustor, state, dt=1e-4).derivatives.heat_input == (
            pytest.approx(0.0))


class TestMechanicalComponents:
    def test_shaft_dynamics_opposes_motion(self):
        state = SystemState()
        state.mechanical.speed = 100.0
        component = ShaftDynamics("shaft", FrictionModel(1.0, 0.01, 0.0))
        assert flows_of(component, state).derivatives.torque < 0.0

    def test_shaft_friction_becomes_heat(self):
        state = SystemState()
        state.mechanical.speed = 100.0
        component = ShaftDynamics("shaft", FrictionModel(1.0, 0.01, 0.0))
        assert flows_of(component, state).derivatives.heat_input > 0.0

    def test_shaft_friction_can_be_sent_to_the_environment(self):
        state = SystemState()
        state.mechanical.speed = 100.0
        component = ShaftDynamics("shaft", FrictionModel(1.0, 0.01, 0.0),
                                  loss_to_thermal=False)
        assert flows_of(component, state).derivatives.heat_input == (
            pytest.approx(0.0))

    def test_shaft_dynamics_sets_the_inertia(self):
        engine = solid_engine()
        engine.add(ShaftDynamics("shaft", inertia=7.0))
        engine.step(0.1)
        assert engine.state.mechanical.inertia == pytest.approx(7.0)

    def test_mechanical_load_is_labelled_as_delivered(self):
        state = SystemState()
        state.mechanical.speed = 100.0
        component = MechanicalLoad("load", ViscousLoad(0.5))
        assert any(f.label == "load" for f in flows_of(component, state).flows)

    def test_mechanical_load_can_be_marked_a_loss(self):
        state = SystemState()
        state.mechanical.speed = 100.0
        component = MechanicalLoad("load", ViscousLoad(0.5), useful=False)
        assert all(f.label != "load" for f in flows_of(component, state).flows)

    def test_torque_source_is_power_limited(self):
        state = SystemState()
        state.mechanical.speed = 100.0
        component = TorqueSource("src", torque=100.0, max_power=1000.0)
        output = flows_of(component, state)
        assert output.derivatives.torque == pytest.approx(10.0)

    def test_negative_torque_brakes(self):
        state = SystemState()
        state.mechanical.speed = 100.0
        component = TorqueSource("src", torque=-10.0)
        output = flows_of(component, state)
        assert any(f.label == "shaft braking" for f in output.flows)

    def test_gearbox_component_reflects_the_load(self):
        state = SystemState()
        state.mechanical.speed = 200.0
        component = GearboxComponent("box", Gearbox(ratio=0.5, efficiency=0.95),
                                     QuadraticLoad(1e-3))
        assert flows_of(component, state).derivatives.torque < 0.0

    def test_gearbox_losses_become_heat(self):
        state = SystemState()
        state.mechanical.speed = 200.0
        component = GearboxComponent("box", Gearbox(ratio=0.5, efficiency=0.95),
                                     QuadraticLoad(1e-3))
        assert flows_of(component, state).derivatives.heat_input > 0.0

    def test_gearbox_without_a_load_does_nothing(self):
        component = GearboxComponent("box", Gearbox(ratio=0.5))
        assert not flows_of(component).flows


class TestSystemComponents:
    def test_generator_component_loads_the_shaft(self):
        state = SystemState()
        state.mechanical.speed = 157.08
        component = GeneratorComponent("gen", Generator(), demand=20_000.0)
        assert flows_of(component, state).derivatives.torque < 0.0

    def test_generator_component_produces_electricity(self):
        state = SystemState()
        state.mechanical.speed = 157.08
        component = GeneratorComponent("gen", Generator(), demand=20_000.0)
        assert net_into(flows_of(component, state),
                        EnergyDomain.ELECTRICAL) > 0.0

    def test_generator_losses_heat_the_machine(self):
        state = SystemState()
        state.mechanical.speed = 157.08
        component = GeneratorComponent("gen", Generator(), demand=20_000.0)
        assert flows_of(component, state).derivatives.heat_input > 0.0

    def test_stalled_generator_warns(self):
        state = SystemState()
        state.mechanical.speed = 0.0
        component = GeneratorComponent("gen", Generator(), demand=20_000.0)
        assert flows_of(component, state).severity is Severity.WARNING

    def test_overloaded_generator_reports_a_limit(self):
        state = SystemState()
        state.mechanical.speed = 157.08
        component = GeneratorComponent(
            "gen", Generator(GeneratorSpec(rated_power=1000.0)),
            demand=10_000_000.0)
        assert flows_of(component, state).severity is Severity.LIMIT

    def test_combustion_engine_component_drives_the_shaft(self, diesel_engine):
        state = SystemState()
        state.mechanical.speed = 157.08
        component = CombustionEngineComponent("ice", diesel_engine,
                                              fuel_flow=0.005)
        assert flows_of(component, state).derivatives.torque > 0.0

    def test_combustion_engine_component_consumes_fuel(self, diesel_engine):
        state = SystemState()
        state.mechanical.speed = 157.08
        component = CombustionEngineComponent("ice", diesel_engine,
                                              fuel_flow=0.005)
        assert flows_of(component, state).derivatives.fuel_burn_rate == (
            pytest.approx(0.005))

    def test_combustion_engine_chemical_balance_closes(self, diesel_engine):
        state = SystemState()
        state.mechanical.speed = 157.08
        component = CombustionEngineComponent("ice", diesel_engine,
                                              fuel_flow=0.005)
        assert net_into(flows_of(component, state),
                        EnergyDomain.CHEMICAL) == pytest.approx(0.0, abs=1e-6)

    def test_heater_component_tracks_its_duty(self):
        system = ElectricHeaterSystem(
            HeaterSpec(material=NICHROME, length=8.0, diameter=1.2e-3))
        component = HeaterComponent("heat", system)
        full = flows_of(component, **{"heat.duty": 1.0}).diagnostics["heat.power"]
        half = flows_of(component, **{"heat.duty": 0.5}).diagnostics["heat.power"]
        assert half == pytest.approx(0.5 * full, rel=1e-9)

    def test_heater_component_flags_a_service_limit(self):
        system = ElectricHeaterSystem(
            HeaterSpec(material=NICHROME, length=8.0, diameter=1.2e-3))
        state = SystemState()
        state.thermal.temperature = 3000.0
        assert flows_of(HeaterComponent("heat", system),
                        state).severity is Severity.LIMIT

    def test_hybrid_component_supplies_the_demand(self):
        controller = HybridController([SourceSpec("a", 50_000.0),
                                       SourceSpec("b", 50_000.0)])
        component = HybridComponent("hyb", controller, demand=30_000.0)
        assert net_into(flows_of(component), EnergyDomain.ELECTRICAL) > 0.0

    def test_hybrid_component_reports_unmet_demand(self):
        controller = HybridController([SourceSpec("a", 1000.0)])
        component = HybridComponent("hyb", controller, demand=50_000.0)
        output = flows_of(component)
        assert output.severity is Severity.LIMIT
        assert output.diagnostics["hyb.unmet"] > 0.0

    def test_recovery_component_generates_from_waste_heat(self):
        state = SystemState()
        state.thermal.temperature = 700.0
        component = RecoveryComponent("orc", WasteHeatRecovery(
            RecoverySpec(carnot_fraction=0.5, maximum_heat=20_000.0)))
        assert net_into(flows_of(component, state),
                        EnergyDomain.ELECTRICAL) > 0.0

    def test_recovery_component_draws_heat_from_the_body(self):
        state = SystemState()
        state.thermal.temperature = 700.0
        component = RecoveryComponent("orc", WasteHeatRecovery(
            RecoverySpec(carnot_fraction=0.5, maximum_heat=20_000.0)))
        assert flows_of(component, state).derivatives.heat_input < 0.0

    def test_recovery_component_is_idle_when_cold(self):
        state = SystemState()
        state.thermal.temperature = 320.0
        component = RecoveryComponent("orc", WasteHeatRecovery(
            RecoverySpec(minimum_source_temperature=500.0)))
        assert flows_of(component, state).derivatives.heat_input == (
            pytest.approx(0.0))


class TestIntegratedChains:
    def test_full_waterfall_from_fuel_to_load(self, diesel_engine):
        """CHEMICAL -> THERMAL -> MECHANICAL -> ELECTRICAL -> LOAD."""
        state = SystemState()
        state.thermal.mass = 50.0
        state.thermal.specific_heat = 500.0
        state.thermal.gas_constant = 0.0
        state.thermal.temperature = 350.0
        state.ambient_temperature = 300.0
        state.mechanical.inertia = 5.0
        state.mechanical.speed = 157.08
        engine = ElectroCombustionEngine(state,
                                         config=EngineConfig(scheme="rk4"))
        engine.add(CombustionEngineComponent("ice", diesel_engine,
                                             fuel_flow=0.005))
        engine.add(GeneratorComponent("gen", Generator(), demand=40_000.0))
        engine.add(ElectricalLoad("load", power=40_000.0))
        engine.add(SurfaceLoss("skin", ConvectionSurface(area=2.0,
                                                         coefficient=20.0)))
        engine.run(10.0, 0.01)
        labels = {name for name, _ in engine.ledger.waterfall()}
        assert "fuel input" in labels
        assert "thermal -> mechanical" in labels
        assert "mechanical -> electrical" in labels

    def test_full_chain_delivers_useful_energy(self, diesel_engine):
        state = SystemState()
        state.thermal.mass = 50.0
        state.thermal.specific_heat = 500.0
        state.thermal.gas_constant = 0.0
        state.thermal.temperature = 350.0
        state.mechanical.inertia = 5.0
        state.mechanical.speed = 157.08
        engine = ElectroCombustionEngine(state,
                                         config=EngineConfig(scheme="rk4"))
        engine.add(CombustionEngineComponent("ice", diesel_engine,
                                             fuel_flow=0.005))
        engine.add(GeneratorComponent("gen", Generator(), demand=40_000.0))
        engine.add(ElectricalLoad("load", power=40_000.0))
        engine.run(5.0, 0.01)
        assert engine.energy_summary()["delivered"] == pytest.approx(200_000.0,
                                                                     rel=1e-6)

    def test_full_chain_efficiency_is_plausible(self, diesel_engine):
        state = SystemState()
        state.thermal.mass = 50.0
        state.thermal.specific_heat = 500.0
        state.thermal.gas_constant = 0.0
        state.thermal.temperature = 350.0
        state.mechanical.inertia = 5.0
        state.mechanical.speed = 157.08
        engine = ElectroCombustionEngine(state,
                                         config=EngineConfig(scheme="rk4"))
        engine.add(CombustionEngineComponent("ice", diesel_engine,
                                             fuel_flow=0.005))
        engine.add(GeneratorComponent("gen", Generator(), demand=40_000.0))
        engine.add(ElectricalLoad("load", power=40_000.0))
        engine.run(5.0, 0.01)
        assert 0.15 < engine.efficiency() < 0.50

    def test_electrothermal_feedback_reaches_equilibrium(self):
        """Joule heating raises resistance, which lowers the heating."""
        engine = solid_engine(mass=0.5)
        resistor = Resistor("element", material=NICHROME,
                            geometry=Geometry.wire(5.0, 1e-3))
        engine.add(ResistiveHeater("heater", resistor, DCSource(50.0)))
        engine.add(SurfaceLoss("loss", ConvectionSurface(area=0.05,
                                                         coefficient=30.0)))
        engine.run(2000.0, 0.5)
        first = engine.state.thermal.temperature
        engine.run(200.0, 0.5)
        assert engine.state.thermal.temperature == pytest.approx(first, rel=1e-3)

    def test_burner_heats_a_mass_and_the_ledger_closes(self):
        engine = solid_engine(mass=20.0)
        engine.add(Burner("burner", METHANE, fuel_flow=1e-4))
        engine.add(SurfaceLoss("loss", ConvectionSurface(area=1.0,
                                                         coefficient=20.0)))
        engine.run(200.0, 0.05)
        summary = engine.energy_summary()
        residual = (summary["input"] - summary["losses"] - summary["stored"])
        assert residual == pytest.approx(0.0, abs=1.0)
