"""Material property models and the material library."""
from __future__ import annotations

import math

import pytest

from electrocombustion.materials import (
    AIR, ALUMINA, ALUMINIUM, COPPER, INCONEL_718, NICHROME, STAINLESS_304,
    STEEL_CARBON, TUNGSTEN, WATER,
)
from electrocombustion.materials.properties import (
    Arrhenius, Constant, LinearCoefficient, Polynomial, Table, as_property,
)


class TestPropertyModels:
    def test_constant_ignores_temperature(self):
        model = Constant(5.0)
        assert model(300.0) == pytest.approx(5.0)
        assert model(1500.0) == pytest.approx(5.0)

    def test_linear_coefficient_at_reference(self):
        model = LinearCoefficient(1.0, 0.004, 293.15)
        assert model(293.15) == pytest.approx(1.0)

    def test_linear_coefficient_rises(self):
        model = LinearCoefficient(1.0, 0.004, 293.15)
        assert model(393.15) == pytest.approx(1.4)

    def test_linear_coefficient_never_goes_negative(self):
        model = LinearCoefficient(1.0, 0.004, 293.15)
        assert model(1.0) >= 0.0

    def test_polynomial_evaluates(self):
        model = Polynomial((1.0, 2.0, 3.0))
        assert model(2.0) == pytest.approx(1.0 + 4.0 + 12.0)

    def test_table_interpolates(self):
        model = Table((300.0, 400.0), (10.0, 20.0))
        assert model(350.0) == pytest.approx(15.0)

    def test_table_clamps_below_range(self):
        model = Table((300.0, 400.0), (10.0, 20.0))
        assert model(200.0) == pytest.approx(10.0)

    def test_table_clamps_above_range(self):
        model = Table((300.0, 400.0), (10.0, 20.0))
        assert model(900.0) == pytest.approx(20.0)

    def test_table_rejects_unsorted_input(self):
        with pytest.raises(ValueError):
            Table((400.0, 300.0), (10.0, 20.0))

    def test_table_rejects_mismatched_lengths(self):
        with pytest.raises(ValueError):
            Table((300.0, 400.0), (10.0,))

    def test_arrhenius_is_monotonic_in_temperature(self):
        model = Arrhenius(1.0, 5000.0)
        assert model(1000.0) > model(500.0)

    def test_as_property_wraps_a_float(self):
        model = as_property(3.5)
        assert model(300.0) == pytest.approx(3.5)

    def test_as_property_passes_models_through(self):
        model = Constant(2.0)
        assert as_property(model) is model


class TestMaterialLibrary:
    def test_copper_resistivity_at_room_temperature(self):
        assert COPPER.rho_e(293.15) == pytest.approx(1.68e-8, rel=0.05)

    def test_copper_resistivity_rises_with_temperature(self):
        assert COPPER.rho_e(400.0) > COPPER.rho_e(293.15)

    def test_copper_conductivity_is_high(self):
        assert COPPER.k(300.0) > 350.0

    def test_nichrome_resistivity_is_far_above_copper(self):
        assert NICHROME.rho_e(293.15) > 50.0 * COPPER.rho_e(293.15)

    def test_nichrome_has_a_low_temperature_coefficient(self):
        cold = NICHROME.rho_e(293.15)
        hot = NICHROME.rho_e(1073.15)
        assert 1.0 < hot / cold < 1.3

    def test_air_density_is_about_one_two_hundredth_of_water(self):
        assert AIR.density < 2.0
        assert WATER.density > 900.0

    def test_water_specific_heat(self):
        assert WATER.cp(300.0) == pytest.approx(4180.0, rel=0.05)

    def test_alumina_is_an_insulator(self):
        assert ALUMINA.rho_e(300.0) > 1.0

    def test_emissivity_is_bounded(self):
        for material in (COPPER, ALUMINIUM, STEEL_CARBON, ALUMINA, INCONEL_718):
            assert 0.0 <= material.eps(300.0) <= 1.0

    def test_thermal_diffusivity_is_positive(self):
        assert COPPER.thermal_diffusivity(300.0) > 0.0

    def test_thermal_diffusivity_formula(self):
        expected = COPPER.k(300.0) / (COPPER.density * COPPER.cp(300.0))
        assert COPPER.thermal_diffusivity(300.0) == pytest.approx(expected)

    def test_service_limit_respected(self):
        assert STEEL_CARBON.within_service_limit(500.0)

    def test_service_limit_exceeded(self):
        assert not ALUMINIUM.within_service_limit(1500.0)

    def test_tungsten_has_the_highest_service_limit(self):
        assert TUNGSTEN.max_service_temperature > STAINLESS_304.max_service_temperature

    @pytest.mark.parametrize("material", [
        COPPER, ALUMINIUM, TUNGSTEN, NICHROME, STEEL_CARBON, STAINLESS_304,
        INCONEL_718, ALUMINA, AIR, WATER,
    ])
    def test_all_materials_have_positive_properties(self, material):
        assert material.density > 0.0
        assert material.cp(300.0) > 0.0
        assert material.k(300.0) > 0.0
