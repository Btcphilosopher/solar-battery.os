"""Fault injection, limit classification, sensors, logging and validation."""
from __future__ import annotations

import math
import os
import tempfile

import pytest

from electrocombustion.core.component import Context
from electrocombustion.core.engine import ElectroCombustionEngine, EngineConfig
from electrocombustion.core.events import EventBus, Severity, Threshold
from electrocombustion.core.state import EnergyDomain, PowerFlow, SystemState
from electrocombustion.faults import (
    CoolingLossFault, Diagnosis, FaultClassifier, FaultInjector,
    FuelInterruptionFault, LimitCheck, LimitRegistry, OverloadFault,
    ParasiticHeatFault, ResistanceDriftFault, SensorFault, TrendMonitor,
    standard_limits,
)
from electrocombustion.telemetry import (
    CSVReplay, RangeCheck, RateCheck, RingBuffer, Sensor, SensorArray,
    SensorSpec, StuckCheck, TelemetryLogger, TelemetryValidator,
    current_transducer, energy_balance_check, plausibility_check,
    pressure_transducer, thermocouple,
)


def hot_state(temperature: float = 1300.0) -> SystemState:
    state = SystemState()
    state.thermal.temperature = temperature
    return state


class TestLimits:
    def test_standard_limits_are_registered(self):
        registry = standard_limits()
        assert len(registry) >= 4

    def test_normal_state_breaches_nothing(self):
        registry = standard_limits(max_temperature=1200.0)
        assert not registry.breaches(SystemState())

    def test_over_temperature_is_a_fault(self):
        registry = standard_limits(max_temperature=1200.0)
        assert registry.worst(hot_state(1300.0)) is Severity.FAULT

    def test_approaching_the_limit_raises_a_warning(self):
        registry = standard_limits(max_temperature=1200.0)
        assert registry.worst(hot_state(1050.0)) is Severity.WARNING

    def test_tightest_margin_identifies_the_binding_limit(self):
        registry = standard_limits(max_temperature=1200.0)
        tightest = registry.tightest_margin(hot_state(1100.0))
        assert tightest is not None and tightest.name == "temperature"

    def test_duplicate_limit_names_are_rejected(self):
        registry = LimitRegistry()
        registry.add_simple("t", lambda s: s.thermal.temperature, limit=1.0)
        with pytest.raises(ValueError):
            registry.add_simple("t", lambda s: s.thermal.temperature, limit=2.0)

    def test_limit_check_serialises(self):
        check = LimitCheck("t", 500.0, Severity.WARNING, 20.0, "K")
        assert check.as_dict()["severity"] == "WARNING"

    def test_breached_flag(self):
        assert LimitCheck("t", 1.0, Severity.LIMIT, -1.0).breached
        assert not LimitCheck("t", 1.0, Severity.NORMAL, 1.0).breached

    def test_an_empty_registry_has_no_tightest_margin(self):
        assert LimitRegistry().tightest_margin(SystemState()) is None


class TestClassifier:
    def test_healthy_state_is_normal(self):
        classifier = FaultClassifier(standard_limits())
        assert classifier.classify(SystemState()).healthy

    def test_breach_is_classified(self):
        classifier = FaultClassifier(standard_limits(max_temperature=1200.0))
        assert not classifier.classify(hot_state(1300.0)).healthy

    def test_explanation_names_the_breached_limit(self):
        classifier = FaultClassifier(standard_limits(max_temperature=1200.0))
        assert "temperature" in classifier.classify(hot_state(1300.0)).explain()

    def test_healthy_explanation_says_so(self):
        classifier = FaultClassifier(standard_limits())
        assert "NORMAL" in classifier.classify(SystemState()).explain()

    def test_residual_anomaly_raises_a_warning(self):
        classifier = FaultClassifier(LimitRegistry(), anomaly_threshold=3.0)
        classifier.add_reference("t", lambda s: s.thermal.temperature,
                                 lambda s: 300.0, sigma=1.0)
        assert not classifier.classify(hot_state(400.0)).healthy

    def test_small_residual_is_not_an_anomaly(self):
        classifier = FaultClassifier(LimitRegistry(), anomaly_threshold=3.0)
        classifier.add_reference("t", lambda s: s.thermal.temperature,
                                 lambda s: 300.0, sigma=100.0)
        assert classifier.classify(hot_state(310.0)).healthy

    def test_zero_sigma_is_rejected(self):
        classifier = FaultClassifier()
        with pytest.raises(ValueError):
            classifier.add_reference("t", lambda s: 0.0, lambda s: 0.0, 0.0)

    def test_history_is_recorded(self):
        classifier = FaultClassifier(standard_limits())
        classifier.classify(SystemState())
        classifier.classify(SystemState())
        assert len(classifier.history) == 2

    def test_timeline_compresses_unchanged_states(self):
        classifier = FaultClassifier(standard_limits(max_temperature=1200.0))
        for _ in range(3):
            classifier.classify(SystemState())
        classifier.classify(hot_state(1300.0))
        assert len(classifier.timeline()) == 2

    def test_worst_severity_over_the_run(self):
        classifier = FaultClassifier(standard_limits(max_temperature=1200.0))
        classifier.classify(SystemState())
        classifier.classify(hot_state(1300.0))
        assert classifier.worst() is Severity.FAULT

    def test_events_are_published_to_the_bus(self):
        bus = EventBus()
        classifier = FaultClassifier(standard_limits(max_temperature=1200.0),
                                     bus=bus)
        classifier.classify(hot_state(1300.0))
        assert bus.history

    def test_reset_clears_the_history(self):
        classifier = FaultClassifier(standard_limits())
        classifier.classify(SystemState())
        classifier.reset()
        assert not classifier.history

    def test_diagnosis_serialises(self):
        classifier = FaultClassifier(standard_limits(max_temperature=1200.0))
        payload = classifier.classify(hot_state(1300.0)).as_dict()
        assert payload["severity"] == "FAULT"


class TestTrendMonitor:
    def test_flat_signal_is_not_drifting(self):
        monitor = TrendMonitor(window=10, slope_threshold=1e-3)
        for i in range(10):
            monitor.add(float(i), 5.0)
        assert not monitor.drifting

    def test_rising_signal_is_detected(self):
        monitor = TrendMonitor(window=10, slope_threshold=0.5)
        for i in range(10):
            monitor.add(float(i), float(i))
        assert monitor.drifting

    def test_slope_matches_the_gradient(self):
        monitor = TrendMonitor(window=10)
        for i in range(10):
            monitor.add(float(i), 2.0 * i)
        assert monitor.slope() == pytest.approx(2.0)

    def test_projection_extrapolates(self):
        monitor = TrendMonitor(window=10)
        for i in range(10):
            monitor.add(float(i), 2.0 * i)
        assert monitor.projected(5.0) == pytest.approx(28.0)

    def test_time_to_target(self):
        monitor = TrendMonitor(window=10)
        for i in range(10):
            monitor.add(float(i), 2.0 * i)
        assert monitor.time_to(28.0) == pytest.approx(5.0)

    def test_time_to_is_infinite_when_moving_away(self):
        monitor = TrendMonitor(window=10)
        for i in range(10):
            monitor.add(float(i), -2.0 * i)
        assert math.isinf(monitor.time_to(100.0))

    def test_window_is_bounded(self):
        monitor = TrendMonitor(window=5)
        for i in range(20):
            monitor.add(float(i), float(i))
        assert len(monitor.samples) == 5

    def test_tiny_window_is_rejected(self):
        with pytest.raises(ValueError):
            TrendMonitor(window=2)


class TestFaultInjection:
    def test_fault_is_inactive_before_its_start(self):
        fault = ParasiticHeatFault("f", power=1000.0, start_time=5.0)
        assert not fault.is_active(1.0)

    def test_fault_is_active_after_its_start(self):
        fault = ParasiticHeatFault("f", power=1000.0, start_time=5.0)
        assert fault.is_active(6.0)

    def test_fault_expires_after_its_duration(self):
        fault = ParasiticHeatFault("f", power=1000.0, start_time=1.0,
                                   duration=2.0)
        assert not fault.is_active(5.0)

    def test_ramped_fault_grows_gradually(self):
        fault = ParasiticHeatFault("f", power=1000.0, start_time=0.0, ramp=10.0)
        assert fault.intensity(5.0) == pytest.approx(0.5)

    def test_ramped_fault_saturates(self):
        fault = ParasiticHeatFault("f", power=1000.0, start_time=0.0, ramp=10.0)
        assert fault.intensity(50.0) == pytest.approx(1.0)

    def test_parasitic_heat_raises_the_temperature(self):
        state = SystemState()
        state.thermal.mass = 1.0
        state.thermal.specific_heat = 500.0
        state.thermal.gas_constant = 0.0
        engine = ElectroCombustionEngine(state)
        engine.add(ParasiticHeatFault("f", power=1000.0))
        before = engine.state.thermal.temperature
        engine.run(10.0, 0.1)
        assert engine.state.thermal.temperature > before

    def test_parasitic_heat_is_energy_accounted(self):
        state = SystemState()
        state.thermal.mass = 1.0
        state.thermal.specific_heat = 500.0
        state.thermal.gas_constant = 0.0
        engine = ElectroCombustionEngine(state)
        engine.add(ParasiticHeatFault("f", power=1000.0))
        engine.run(10.0, 0.1)
        assert engine.ledger.total_input == pytest.approx(10_000.0, rel=1e-9)

    def test_fault_publishes_an_event_once(self):
        state = SystemState()
        state.thermal.mass = 1.0
        state.thermal.gas_constant = 0.0
        engine = ElectroCombustionEngine(state)
        engine.add(ParasiticHeatFault("f", power=100.0))
        engine.run(1.0, 0.1)
        injected = [e for e in engine.bus.history if e.kind == "fault_injected"]
        assert len(injected) == 1

    def test_cooling_loss_degrades_the_commanded_flow(self):
        fault = CoolingLossFault("f", target_key="pump.flow")
        context = Context(inputs={"pump.flow": 1.0})
        fault.evaluate(SystemState(), 0.1, context)
        assert context.inputs["pump.flow"] == pytest.approx(0.0)

    def test_cooling_loss_can_leave_a_residual_flow(self):
        fault = CoolingLossFault("f", target_key="pump.flow",
                                 residual_flow=0.2)
        context = Context(inputs={"pump.flow": 1.0})
        fault.evaluate(SystemState(), 0.1, context)
        assert context.inputs["pump.flow"] == pytest.approx(0.2)

    def test_fuel_interruption_cuts_the_supply(self):
        fault = FuelInterruptionFault("f", fuel_key="burner.fuel_flow")
        context = Context(inputs={"burner.fuel_flow": 0.01})
        fault.evaluate(SystemState(), 0.1, context)
        assert context.inputs["burner.fuel_flow"] == pytest.approx(0.0)

    def test_overload_multiplies_the_input(self):
        fault = OverloadFault("f", target_key="load.demand", multiplier=1.5)
        context = Context(inputs={"load.demand": 1000.0})
        fault.evaluate(SystemState(), 0.1, context)
        assert context.inputs["load.demand"] == pytest.approx(1500.0)

    def test_resistance_drift_increases_the_resistance(self):
        from electrocombustion.electrical import Resistor
        resistor = Resistor("r", resistance=10.0)
        fault = ResistanceDriftFault("f", resistor, multiplier=2.0)
        fault.evaluate(SystemState(), 0.1, Context())
        assert resistor.resistance == pytest.approx(20.0)

    def test_sensor_fault_biases_the_reading(self):
        fault = SensorFault("f", channel="T", mode="bias", magnitude=25.0)
        assert fault.corrupt(300.0, 1.0) == pytest.approx(325.0)

    def test_stuck_sensor_reports_a_constant(self):
        fault = SensorFault("f", channel="T", mode="stuck", stuck_value=273.0)
        assert fault.corrupt(500.0, 1.0) == pytest.approx(273.0)

    def test_dropout_sensor_reports_nothing(self):
        fault = SensorFault("f", channel="T", mode="dropout")
        assert fault.corrupt(500.0, 1.0) == pytest.approx(0.0)

    def test_drift_grows_with_time(self):
        fault = SensorFault("f", channel="T", mode="drift", magnitude=1.0)
        assert fault.corrupt(300.0, 10.0) > fault.corrupt(300.0, 1.0)

    def test_unknown_sensor_mode_is_rejected(self):
        with pytest.raises(ValueError):
            SensorFault("f", channel="T", mode="telepathy")

    def test_inactive_sensor_fault_passes_the_value_through(self):
        fault = SensorFault("f", channel="T", mode="bias", magnitude=25.0,
                            start_time=100.0)
        assert fault.corrupt(300.0, 1.0) == pytest.approx(300.0)


class TestSensors:
    def test_ideal_sensor_is_transparent(self):
        sensor = Sensor(SensorSpec("T"))
        assert sensor.read(400.0) == pytest.approx(400.0)

    def test_bias_offsets_the_reading(self):
        sensor = Sensor(SensorSpec("T", bias=5.0))
        assert sensor.read(400.0) == pytest.approx(405.0)

    def test_scale_error_multiplies(self):
        sensor = Sensor(SensorSpec("T", scale_error=1.02))
        assert sensor.read(400.0) == pytest.approx(408.0)

    def test_range_clipping(self):
        sensor = Sensor(SensorSpec("T", range_min=0.0, range_max=100.0))
        assert sensor.read(500.0) == pytest.approx(100.0)

    def test_quantisation_snaps_to_the_resolution(self):
        sensor = Sensor(SensorSpec("T", resolution=0.5))
        assert sensor.read(400.3) == pytest.approx(400.5)

    def test_noise_produces_variation(self):
        sensor = Sensor(SensorSpec("T", noise_sigma=1.0), seed=0)
        readings = {sensor.read(400.0) for _ in range(20)}
        assert len(readings) > 1

    def test_lag_delays_the_response(self):
        sensor = Sensor(SensorSpec("T", time_constant=10.0))
        sensor.read(300.0, 0.1)
        assert sensor.read(400.0, 0.1) < 400.0

    def test_lag_eventually_catches_up(self):
        sensor = Sensor(SensorSpec("T", time_constant=1.0))
        sensor.read(300.0, 0.1)
        for _ in range(500):
            value = sensor.read(400.0, 0.1)
        assert value == pytest.approx(400.0, rel=1e-3)

    def test_drift_accumulates_with_elapsed_time(self):
        sensor = Sensor(SensorSpec("T", drift_rate=1.0))
        sensor.read(400.0, 10.0)
        assert sensor.read(400.0, 0.0) == pytest.approx(410.0)

    def test_error_reports_the_difference(self):
        sensor = Sensor(SensorSpec("T", bias=5.0))
        sensor.read(400.0)
        assert sensor.error(400.0) == pytest.approx(5.0)

    def test_calibration_removes_the_bias(self):
        sensor = Sensor(SensorSpec("T", bias=5.0))
        indicated = sensor.read(400.0)
        sensor.calibrate(400.0, indicated)
        assert sensor.read(400.0) == pytest.approx(400.0)

    def test_reset_clears_the_lag_state(self):
        sensor = Sensor(SensorSpec("T", time_constant=10.0))
        sensor.read(300.0, 0.1)
        sensor.reset()
        assert sensor.filtered is None

    def test_failure_probability_is_bounded(self):
        with pytest.raises(ValueError):
            SensorSpec("T", failure_probability=1.5)

    def test_inverted_range_is_rejected(self):
        with pytest.raises(ValueError):
            SensorSpec("T", range_min=100.0, range_max=0.0)

    def test_a_failed_sensor_stays_failed(self):
        sensor = Sensor(SensorSpec("T", range_min=0.0, failure_probability=1.0),
                        seed=0)
        sensor.read(400.0)
        assert sensor.failed
        assert sensor.read(400.0) == pytest.approx(0.0)

    def test_thermocouple_has_a_plausible_range(self):
        sensor = thermocouple("T", "K")
        assert sensor.spec.range_max > 1500.0

    def test_current_transducer_is_bipolar(self):
        sensor = current_transducer("I", rating=200.0)
        assert sensor.spec.range_min < 0.0

    def test_pressure_transducer_starts_at_zero(self):
        assert pressure_transducer("p").spec.range_min == pytest.approx(0.0)

    def test_sensor_array_samples_every_channel(self):
        array = SensorArray(seed=0)
        array.add(SensorSpec("T"), lambda s: s.thermal.temperature)
        array.add(SensorSpec("p"), lambda s: s.thermal.pressure)
        assert set(array.sample(SystemState(), 0.1)) == {"T", "p"}

    def test_sensor_array_reports_the_truth_too(self):
        array = SensorArray(seed=0)
        array.add(SensorSpec("T", bias=10.0), lambda s: s.thermal.temperature)
        state = SystemState()
        array.sample(state, 0.1)
        assert array.errors(state)["T"] == pytest.approx(10.0)

    def test_duplicate_sensor_names_are_rejected(self):
        array = SensorArray()
        array.add(SensorSpec("T"), lambda s: 0.0)
        with pytest.raises(ValueError):
            array.add(SensorSpec("T"), lambda s: 0.0)

    def test_failed_channels_are_listed(self):
        array = SensorArray(seed=0)
        array.add(SensorSpec("T", range_min=0.0, failure_probability=1.0),
                  lambda s: s.thermal.temperature)
        array.sample(SystemState(), 0.1)
        assert array.failed() == ["T"]


class TestLogging:
    def test_ring_buffer_keeps_the_latest(self):
        buffer = RingBuffer(capacity=3)
        for i in range(10):
            buffer.append({"i": i})
        assert buffer.latest(1)[0]["i"] == 9

    def test_ring_buffer_counts_what_it_dropped(self):
        buffer = RingBuffer(capacity=3)
        for i in range(10):
            buffer.append({"i": i})
        assert buffer.dropped == 7

    def test_ring_buffer_series(self):
        buffer = RingBuffer(capacity=10)
        for i in range(5):
            buffer.append({"i": float(i)})
        assert buffer.series("i") == [0.0, 1.0, 2.0, 3.0, 4.0]

    def test_zero_capacity_is_rejected(self):
        with pytest.raises(ValueError):
            RingBuffer(capacity=0)

    def test_logger_stride_decimates(self):
        logger = TelemetryLogger(stride=10)
        for i in range(100):
            logger.log({"time": float(i), "x": float(i)})
        assert len(logger) == 10

    def test_logger_statistics(self):
        logger = TelemetryLogger()
        for i in range(10):
            logger.log({"x": float(i)})
        assert logger.statistics("x")["mean"] == pytest.approx(4.5)

    def test_statistics_of_an_unknown_channel_raises(self):
        with pytest.raises(KeyError):
            TelemetryLogger().statistics("nothing")

    def test_field_filter_restricts_the_record(self):
        logger = TelemetryLogger(fields=["x"])
        logger.log({"x": 1.0, "y": 2.0})
        assert "y" not in logger.buffer[0]

    def test_csv_round_trip_through_replay(self):
        logger = TelemetryLogger()
        for i in range(10):
            logger.log({"time": float(i), "x": float(i) * 2.0})
        with tempfile.TemporaryDirectory() as directory:
            path = os.path.join(directory, "log.csv")
            logger.to_csv(path)
            replay = CSVReplay(path)
            assert len(replay) == 10
            assert replay.at(5.0)["x"] == pytest.approx(10.0)

    def test_replay_interpolates_between_records(self):
        logger = TelemetryLogger()
        for i in range(10):
            logger.log({"time": float(i), "x": float(i) * 2.0})
        with tempfile.TemporaryDirectory() as directory:
            path = os.path.join(directory, "log.csv")
            logger.to_csv(path)
            replay = CSVReplay(path)
            assert replay.interpolate(2.5, "x") == pytest.approx(5.0)

    def test_replay_reports_its_duration(self):
        logger = TelemetryLogger()
        for i in range(10):
            logger.log({"time": float(i), "x": 0.0})
        with tempfile.TemporaryDirectory() as directory:
            path = os.path.join(directory, "log.csv")
            logger.to_csv(path)
            assert CSVReplay(path).duration == pytest.approx(9.0)

    def test_missing_replay_file_raises(self):
        with pytest.raises(FileNotFoundError):
            CSVReplay("/tmp/definitely-not-here.csv")

    def test_writing_an_empty_log_raises(self):
        with pytest.raises(ValueError):
            TelemetryLogger().to_csv("/tmp/never.csv")

    def test_zero_stride_is_rejected(self):
        with pytest.raises(ValueError):
            TelemetryLogger(stride=0)


class TestValidation:
    def test_range_check_passes_inside_the_band(self):
        assert RangeCheck("T", 0.0, 100.0).check(50.0) is None

    def test_range_check_flags_an_excursion(self):
        issue = RangeCheck("T", 0.0, 100.0).check(150.0)
        assert issue is not None and issue.kind == "range"

    def test_range_check_flags_non_finite_values(self):
        issue = RangeCheck("T").check(float("nan"))
        assert issue is not None and issue.kind == "non_finite"

    def test_rate_check_needs_two_samples(self):
        check = RateCheck("T", max_rate=10.0)
        assert check.check(300.0, 0.0) is None

    def test_rate_check_flags_an_impossible_jump(self):
        check = RateCheck("T", max_rate=10.0)
        check.check(300.0, 0.0)
        assert check.check(700.0, 0.01) is not None

    def test_rate_check_passes_a_gradual_change(self):
        check = RateCheck("T", max_rate=100.0)
        check.check(300.0, 0.0)
        assert check.check(301.0, 1.0) is None

    def test_stuck_check_needs_a_full_window(self):
        check = StuckCheck("T", samples=5)
        for _ in range(4):
            assert check.check(300.0) is None

    def test_stuck_check_flags_a_frozen_channel(self):
        check = StuckCheck("T", samples=5)
        issue = None
        for _ in range(5):
            issue = check.check(300.0)
        assert issue is not None and issue.kind == "stuck"

    def test_stuck_check_passes_a_moving_channel(self):
        check = StuckCheck("T", samples=5)
        issue = None
        for i in range(5):
            issue = check.check(300.0 + i)
        assert issue is None

    def test_validator_reports_a_clean_record(self):
        validator = TelemetryValidator().add_range("T", 0.0, 1000.0)
        assert validator.validate({"time": 0.0, "T": 400.0}).valid

    def test_validator_reports_a_bad_record(self):
        validator = TelemetryValidator().add_range("T", 0.0, 1000.0)
        assert not validator.validate({"time": 0.0, "T": 2000.0}).valid

    def test_cross_channel_relation(self):
        validator = TelemetryValidator().add_relation(
            "ohm", lambda r: abs(r["P"] - r["V"] * r["I"]) < 1.0,
            "P should equal V times I")
        assert not validator.validate({"P": 100.0, "V": 10.0, "I": 5.0}).valid

    def test_a_failing_relation_predicate_is_itself_a_finding(self):
        validator = TelemetryValidator().add_relation(
            "bad", lambda r: r["missing"] > 0, "needs a missing channel")
        report = validator.validate({"P": 1.0})
        assert report.by_kind("relation_error")

    def test_failure_rate_is_tracked(self):
        validator = TelemetryValidator().add_range("T", 0.0, 1000.0)
        validator.validate({"T": 400.0})
        validator.validate({"T": 5000.0})
        assert validator.failure_rate() == pytest.approx(0.5)

    def test_summary_counts_by_kind(self):
        validator = TelemetryValidator().add_range("T", 0.0, 1000.0)
        validator.validate({"T": 5000.0})
        assert validator.summary()["by_kind"]["range"] == 1

    def test_reset_clears_the_state(self):
        validator = TelemetryValidator().add_range("T", 0.0, 1000.0)
        validator.validate({"T": 5000.0})
        validator.reset()
        assert validator.failure_rate() == pytest.approx(0.0)

    def test_energy_balance_passes_when_closed(self):
        ok, residual = energy_balance_check(1000.0, 800.0, 200.0)
        assert ok and residual == pytest.approx(0.0)

    def test_energy_balance_fails_on_a_leak(self):
        ok, residual = energy_balance_check(1000.0, 500.0, 0.0)
        assert not ok and residual > 0.0

    def test_plausibility_accepts_a_consistent_gas_state(self):
        from electrocombustion.core import units as U
        ok, _ = plausibility_check(300.0, U.R_AIR * 300.0, 1.0, 1.0, U.R_AIR)
        assert ok

    def test_plausibility_rejects_an_inconsistent_state(self):
        from electrocombustion.core import units as U
        ok, _ = plausibility_check(300.0, 1e7, 1.0, 1.0, U.R_AIR)
        assert not ok

    def test_plausibility_rejects_impossible_inputs(self):
        ok, residual = plausibility_check(0.0, 1e5, 1.0, 1.0, 287.0)
        assert not ok and math.isinf(residual)
