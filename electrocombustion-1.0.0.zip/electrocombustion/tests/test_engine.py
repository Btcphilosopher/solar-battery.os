"""The simulation engine: stepping, integration schemes and conservation."""
from __future__ import annotations

import math

import pytest

from electrocombustion.core.component import (
    CallableComponent, Component, ComponentGroup, ComponentOutput, Context,
    Derivatives,
)
from electrocombustion.core.engine import (
    ElectroCombustionEngine, EngineConfig, StepReport,
)
from electrocombustion.core.events import Severity, Threshold
from electrocombustion.core.state import EnergyDomain, PowerFlow, SystemState
from electrocombustion.electrical import (
    DCSource, ElectricalLoad, Geometry, GridSupply, Resistor, ResistiveHeater,
)
from electrocombustion.materials import NICHROME
from electrocombustion.mechanical import (
    ConstantTorque, MechanicalLoad, TorqueSource, ViscousLoad,
)
from electrocombustion.thermal import ConvectionSurface, SurfaceLoss


class ConstantHeater(Component):
    """A component that injects a fixed thermal power, for exact arithmetic."""

    order = 10

    def __init__(self, name: str = "heat", power: float = 1000.0) -> None:
        super().__init__(name)
        self.power = power

    def evaluate(self, state, dt, context) -> ComponentOutput:
        return ComponentOutput(
            flows=[PowerFlow(EnergyDomain.SOURCE, EnergyDomain.THERMAL,
                             self.power, "test heat", self.name)],
            derivatives=Derivatives(heat_input=self.power),
            diagnostics={f"{self.name}.power": self.power},
        )


@pytest.fixture
def solid_state() -> SystemState:
    state = SystemState()
    state.thermal.mass = 2.0
    state.thermal.specific_heat = 500.0
    state.thermal.gas_constant = 0.0
    state.thermal.temperature = 300.0
    state.ambient_temperature = 300.0
    return state


class TestComponentPrimitives:
    def test_derivatives_default_to_zero(self):
        d = Derivatives()
        assert d.heat_input == 0.0 and d.torque == 0.0

    def test_component_output_defaults_are_empty(self):
        out = ComponentOutput()
        assert out.flows == [] and out.severity is Severity.NORMAL

    def test_context_get_falls_back_to_the_default(self):
        context = Context(inputs={"a": 1.0})
        assert context.get("a", 0.0) == pytest.approx(1.0)
        assert context.get("b", 7.0) == pytest.approx(7.0)

    def test_callable_component_wraps_a_function(self):
        component = CallableComponent(
            "c", lambda state, dt, context: ComponentOutput(
                derivatives=Derivatives(heat_input=5.0)))
        out = component.evaluate(SystemState(), 0.1, Context())
        assert out.derivatives.heat_input == pytest.approx(5.0)

    def test_component_group_aggregates_flows(self):
        group = ComponentGroup("g", [ConstantHeater("a", 100.0),
                                     ConstantHeater("b", 200.0)])
        out = group.evaluate(SystemState(), 0.1, Context())
        assert sum(f.watts for f in out.flows) == pytest.approx(300.0)

    def test_component_group_sums_derivatives(self):
        group = ComponentGroup("g", [ConstantHeater("a", 100.0),
                                     ConstantHeater("b", 200.0)])
        out = group.evaluate(SystemState(), 0.1, Context())
        assert out.derivatives.heat_input == pytest.approx(300.0)


class TestEngineBasics:
    def test_engine_starts_at_time_zero(self, solid_state):
        assert ElectroCombustionEngine(solid_state).state.time == 0.0

    def test_adding_a_component_returns_it(self, solid_state):
        engine = ElectroCombustionEngine(solid_state)
        component = ConstantHeater()
        assert engine.add(component) is component

    def test_duplicate_component_names_are_rejected(self, solid_state):
        engine = ElectroCombustionEngine(solid_state)
        engine.add(ConstantHeater("heat"))
        with pytest.raises(ValueError):
            engine.add(ConstantHeater("heat"))

    def test_get_retrieves_by_name(self, solid_state):
        engine = ElectroCombustionEngine(solid_state)
        engine.add(ConstantHeater("heat"))
        assert engine.get("heat").name == "heat"

    def test_get_unknown_component_raises(self, solid_state):
        engine = ElectroCombustionEngine(solid_state)
        with pytest.raises(KeyError):
            engine.get("nothing")

    def test_step_advances_time(self, solid_state):
        engine = ElectroCombustionEngine(solid_state)
        engine.add(ConstantHeater())
        engine.step(0.1)
        assert engine.state.time == pytest.approx(0.1)

    def test_step_returns_a_report(self, solid_state):
        engine = ElectroCombustionEngine(solid_state)
        engine.add(ConstantHeater())
        report = engine.step(0.1)
        assert isinstance(report, StepReport)
        assert report.dt == pytest.approx(0.1)

    def test_negative_timestep_is_rejected(self, solid_state):
        engine = ElectroCombustionEngine(solid_state)
        with pytest.raises(ValueError):
            engine.step(-0.1)

    def test_describe_lists_components(self, solid_state):
        engine = ElectroCombustionEngine(solid_state)
        engine.add(ConstantHeater("heat"))
        assert "heat" in str(engine.describe())

    def test_reset_returns_to_the_initial_state(self, solid_state):
        engine = ElectroCombustionEngine(solid_state)
        engine.add(ConstantHeater())
        engine.run(10.0, 0.1)
        engine.reset()
        assert engine.state.time == pytest.approx(0.0)
        assert engine.state.thermal.temperature == pytest.approx(300.0)

    def test_snapshot_is_a_flat_mapping(self, solid_state):
        engine = ElectroCombustionEngine(solid_state)
        engine.add(ConstantHeater())
        engine.step(0.1)
        assert isinstance(engine.snapshot(), dict)


class TestIntegration:
    """Analytic checks: a fixed heat input into a fixed heat capacity."""

    def build(self, scheme: str, solid_state) -> ElectroCombustionEngine:
        engine = ElectroCombustionEngine(
            solid_state, config=EngineConfig(scheme=scheme))
        engine.add(ConstantHeater(power=1000.0))
        return engine

    @pytest.mark.parametrize("scheme", ["euler", "heun", "rk4"])
    def test_temperature_rise_matches_the_analytic_value(self, scheme,
                                                         solid_state):
        engine = self.build(scheme, solid_state)
        engine.run(100.0, 0.1)
        expected = 300.0 + 1000.0 * 100.0 / (2.0 * 500.0)
        assert engine.state.thermal.temperature == pytest.approx(expected,
                                                                 rel=1e-9)

    @pytest.mark.parametrize("scheme", ["euler", "heun", "rk4"])
    def test_ledger_input_matches_the_integral(self, scheme, solid_state):
        engine = self.build(scheme, solid_state)
        engine.run(100.0, 0.1)
        assert engine.ledger.total_input == pytest.approx(100_000.0, rel=1e-9)

    @pytest.mark.parametrize("scheme", ["euler", "heun", "rk4"])
    def test_energy_is_conserved_exactly(self, scheme, solid_state):
        engine = self.build(scheme, solid_state)
        engine.run(100.0, 0.1)
        summary = engine.energy_summary()
        residual = summary["input"] - summary["losses"] - summary["stored"]
        assert residual == pytest.approx(0.0, abs=1e-6)

    def test_unknown_scheme_is_rejected(self, solid_state):
        with pytest.raises(ValueError):
            ElectroCombustionEngine(solid_state,
                                    config=EngineConfig(scheme="magic"))

    def test_rk4_beats_euler_on_a_nonlinear_problem(self, solid_state):
        """Convective loss makes the problem nonlinear, so scheme order shows."""
        def build(scheme, dt):
            state = SystemState()
            state.thermal.mass = 2.0
            state.thermal.specific_heat = 500.0
            state.thermal.gas_constant = 0.0
            state.thermal.temperature = 800.0
            state.ambient_temperature = 300.0
            engine = ElectroCombustionEngine(state,
                                             config=EngineConfig(scheme=scheme))
            engine.add(SurfaceLoss("loss", ConvectionSurface(area=0.5,
                                                             coefficient=20.0)))
            engine.run(200.0, dt)
            return engine.state.thermal.temperature

        reference = build("rk4", 0.01)
        coarse_euler = abs(build("euler", 2.0) - reference)
        coarse_rk4 = abs(build("rk4", 2.0) - reference)
        assert coarse_rk4 < coarse_euler

    def test_run_reports_the_number_of_steps(self, solid_state):
        engine = self.build("rk4", solid_state)
        result = engine.run(10.0, 0.1)
        assert result.summary()["steps"] == 100

    def test_run_duration_is_exact(self, solid_state):
        engine = self.build("rk4", solid_state)
        result = engine.run(10.0, 0.1)
        assert result.duration == pytest.approx(10.0, rel=1e-9)

    def test_adaptive_run_reaches_the_end_time(self, solid_state):
        from electrocombustion.core.timestep import AdaptiveTimestep
        engine = self.build("rk4", solid_state)
        engine.run_adaptive(10.0, AdaptiveTimestep(dt=0.01))
        assert engine.state.time == pytest.approx(10.0, rel=1e-6)

    def test_adaptive_run_conserves_energy(self, solid_state):
        from electrocombustion.core.timestep import AdaptiveTimestep
        engine = self.build("rk4", solid_state)
        engine.run_adaptive(10.0, AdaptiveTimestep(dt=0.01))
        summary = engine.energy_summary()
        assert summary["input"] - summary["losses"] - summary["stored"] == (
            pytest.approx(0.0, abs=1e-6))


class TestInputsAndControl:
    def test_static_input_mapping_is_applied(self, solid_state):
        engine = ElectroCombustionEngine(solid_state)
        engine.add(TorqueSource("src", input_key="src.torque"))
        engine.state.mechanical.inertia = 1.0
        engine.run(1.0, 0.01, {"src.torque": 10.0})
        assert engine.state.mechanical.speed > 0.0

    def test_callable_inputs_receive_time_and_state(self, solid_state):
        seen = []

        def inputs(t, state):
            seen.append(t)
            return {}

        engine = ElectroCombustionEngine(solid_state)
        engine.add(ConstantHeater())
        engine.run(1.0, 0.1, inputs)
        assert len(seen) == 10

    def test_a_controller_can_drive_the_engine(self, solid_state):
        class Controller:
            def update(self, state, dt):
                return {"src.torque": 5.0}

        engine = ElectroCombustionEngine(solid_state)
        engine.state.mechanical.inertia = 1.0
        engine.add(TorqueSource("src", input_key="src.torque"))
        engine.run(1.0, 0.01, controller=Controller())
        assert engine.state.mechanical.speed == pytest.approx(5.0, rel=1e-6)


class TestThresholdsAndEvents:
    def test_threshold_fires_an_event(self, solid_state):
        engine = ElectroCombustionEngine(solid_state)
        engine.add(ConstantHeater(power=10_000.0))
        engine.add_threshold(Threshold("T", limit=400.0, direction="upper"),
                             lambda s: s.thermal.temperature)
        engine.run(100.0, 0.1)
        assert engine.bus.worst_severity() is not Severity.NORMAL

    def test_no_event_when_within_limits(self, solid_state):
        engine = ElectroCombustionEngine(solid_state)
        engine.add(ConstantHeater(power=10.0))
        engine.add_threshold(Threshold("T", limit=1000.0, direction="upper"),
                             lambda s: s.thermal.temperature)
        engine.run(10.0, 0.1)
        assert engine.bus.worst_severity() is Severity.NORMAL

    def test_component_severity_propagates_to_the_report(self, solid_state):
        class Warner(Component):
            order = 50

            def evaluate(self, state, dt, context):
                return ComponentOutput(severity=Severity.WARNING)

        engine = ElectroCombustionEngine(solid_state)
        engine.add(Warner("warner"))
        assert engine.step(0.1).severity is Severity.WARNING


class TestConservation:
    def test_electrothermal_loop_closes_exactly(self):
        """The reference case: joule heating into a mass with surface loss."""
        state = SystemState()
        state.thermal.mass = 2.0
        state.thermal.specific_heat = 450.0
        state.thermal.gas_constant = 0.0
        state.thermal.temperature = 300.0
        state.ambient_temperature = 300.0
        engine = ElectroCombustionEngine(state,
                                         config=EngineConfig(scheme="rk4"))
        resistor = Resistor("element", material=NICHROME,
                            geometry=Geometry.wire(5.0, 1e-3))
        engine.add(ResistiveHeater("heater", resistor, DCSource(230.0)))
        engine.add(SurfaceLoss("loss", ConvectionSurface(area=0.05,
                                                         coefficient=15.0)))
        engine.run(600.0, 0.05)
        summary = engine.energy_summary()
        assert summary["input"] - summary["losses"] - summary["stored"] == (
            pytest.approx(0.0, abs=1e-3))

    def test_resistance_rises_as_the_element_heats(self):
        state = SystemState()
        state.thermal.mass = 2.0
        state.thermal.specific_heat = 450.0
        state.thermal.gas_constant = 0.0
        state.thermal.temperature = 300.0
        engine = ElectroCombustionEngine(state)
        resistor = Resistor("element", material=NICHROME,
                            geometry=Geometry.wire(5.0, 1e-3))
        engine.add(ResistiveHeater("heater", resistor, DCSource(230.0)))
        cold = resistor.value(300.0)
        engine.run(300.0, 0.05)
        assert resistor.value(engine.state.thermal.temperature) > cold

    def test_delivered_load_is_counted_separately_from_losses(self, solid_state):
        engine = ElectroCombustionEngine(solid_state)
        engine.add(GridSupply("grid", power=1000.0))
        engine.add(ElectricalLoad("load", power=1000.0))
        engine.run(10.0, 0.1)
        summary = engine.energy_summary()
        assert summary["delivered"] == pytest.approx(10_000.0, rel=1e-6)

    def test_efficiency_is_delivered_over_input(self, solid_state):
        engine = ElectroCombustionEngine(solid_state)
        engine.add(GridSupply("grid", power=1000.0))
        engine.add(ElectricalLoad("load", power=1000.0))
        engine.run(10.0, 0.1)
        assert engine.efficiency() == pytest.approx(1.0, rel=1e-6)

    def test_mechanical_kinetic_energy_is_accounted(self, solid_state):
        engine = ElectroCombustionEngine(solid_state,
                                         config=EngineConfig(scheme="rk4"))
        engine.state.mechanical.inertia = 2.0
        engine.add(TorqueSource("src", torque=10.0))
        engine.run(5.0, 0.005)
        speed = engine.state.mechanical.speed
        assert speed == pytest.approx(25.0, rel=1e-6)
        assert engine.state.mechanical.kinetic_energy == pytest.approx(
            0.5 * 2.0 * 25.0 ** 2, rel=1e-9)

    def test_conservation_residual_is_reported_not_hidden(self, solid_state):
        engine = ElectroCombustionEngine(solid_state,
                                         config=EngineConfig(scheme="rk4"))
        engine.state.mechanical.inertia = 2.0
        engine.add(TorqueSource("src", torque=10.0))
        report = engine.step(0.1)
        assert isinstance(report.conservation_residual, float)

    def test_friction_heat_goes_to_the_thermal_domain(self, solid_state):
        from electrocombustion.mechanical import ShaftDynamics
        engine = ElectroCombustionEngine(solid_state,
                                         config=EngineConfig(scheme="rk4"))
        engine.state.mechanical.inertia = 2.0
        engine.state.mechanical.speed = 100.0
        engine.add(ShaftDynamics("shaft", damping=0.5))
        before = engine.state.thermal.temperature
        engine.run(5.0, 0.01)
        assert engine.state.thermal.temperature > before
        assert engine.state.mechanical.speed < 100.0


class TestSpeculativeEvaluation:
    def test_trial_does_not_mutate_the_engine(self, solid_state):
        engine = ElectroCombustionEngine(solid_state)
        engine.add(ConstantHeater(power=5000.0))
        before = engine.state.thermal.temperature
        engine._trial(engine.state, 1.0, {})
        assert engine.state.thermal.temperature == pytest.approx(before)

    def test_trial_returns_an_advanced_state(self, solid_state):
        engine = ElectroCombustionEngine(solid_state)
        engine.add(ConstantHeater(power=5000.0))
        result = engine._trial(engine.state, 1.0, {})
        assert result.thermal.temperature > engine.state.thermal.temperature

    def test_trial_publishes_no_events(self, solid_state):
        engine = ElectroCombustionEngine(solid_state)
        engine.add(ConstantHeater(power=100_000.0))
        engine.add_threshold(Threshold("T", limit=310.0, direction="upper"),
                             lambda s: s.thermal.temperature)
        engine._trial(engine.state, 10.0, {})
        assert not engine.bus.history
