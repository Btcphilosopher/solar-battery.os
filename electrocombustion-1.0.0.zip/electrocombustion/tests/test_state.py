"""Energy state, power flows and the conservation ledger."""
from __future__ import annotations

import math

import pytest

from electrocombustion.core.state import (
    ConservationError, EnergyDomain, EnergyLedger, PowerFlow, SystemState,
    component_balance_residual, domain_balance, flows_balance,
)


def flow(source, target, watts, label="test", component="c"):
    return PowerFlow(source, target, watts, label, component)


class TestPowerFlow:
    def test_same_domain_is_rejected(self):
        with pytest.raises(ValueError):
            PowerFlow(EnergyDomain.THERMAL, EnergyDomain.THERMAL, 5.0)

    def test_zero_power_is_allowed(self):
        assert PowerFlow(EnergyDomain.SOURCE, EnergyDomain.THERMAL, 0.0).watts == 0.0

    def test_negative_power_is_normalised_by_swapping_direction(self):
        f = PowerFlow(EnergyDomain.ELECTRICAL, EnergyDomain.THERMAL, -20.0)
        n = f.normalised()
        assert n.source is EnergyDomain.THERMAL
        assert n.target is EnergyDomain.ELECTRICAL
        assert n.watts == pytest.approx(20.0)

    def test_normalised_is_idempotent_for_positive_flows(self):
        f = flow(EnergyDomain.SOURCE, EnergyDomain.ELECTRICAL, 10.0)
        assert f.normalised() is f

    def test_loss_is_flagged_by_target_domain(self):
        assert flow(EnergyDomain.THERMAL, EnergyDomain.ENVIRONMENT, 1.0).is_loss
        assert not flow(EnergyDomain.SOURCE, EnergyDomain.THERMAL, 1.0).is_loss

    def test_scaled_preserves_direction(self):
        f = flow(EnergyDomain.SOURCE, EnergyDomain.ELECTRICAL, 100.0)
        s = f.scaled(0.25)
        assert s.watts == pytest.approx(25.0)
        assert s.source is f.source


class TestEnergyLedger:
    def test_starts_empty(self):
        ledger = EnergyLedger()
        assert ledger.total_input == 0.0
        assert ledger.total_losses == 0.0

    def test_accumulates_input(self):
        ledger = EnergyLedger()
        ledger.accumulate([flow(EnergyDomain.SOURCE, EnergyDomain.ELECTRICAL,
                                1000.0, "supply")], 2.0)
        assert ledger.total_input == pytest.approx(2000.0)

    def test_losses_leave_to_environment(self):
        ledger = EnergyLedger()
        ledger.accumulate([flow(EnergyDomain.THERMAL, EnergyDomain.ENVIRONMENT,
                                500.0, "heat rejection")], 1.0)
        assert ledger.total_losses == pytest.approx(500.0)

    def test_delivered_load_is_not_a_loss(self):
        ledger = EnergyLedger()
        ledger.accumulate([flow(EnergyDomain.ELECTRICAL,
                                EnergyDomain.ENVIRONMENT, 800.0, "load")], 1.0)
        assert ledger.labelled_total("load") == pytest.approx(800.0)

    def test_internal_transfer_is_neither_input_nor_loss(self):
        ledger = EnergyLedger()
        ledger.accumulate([flow(EnergyDomain.ELECTRICAL, EnergyDomain.THERMAL,
                                100.0, "joule")], 1.0)
        assert ledger.total_input == 0.0
        assert ledger.total_losses == 0.0

    def test_net_per_domain(self):
        ledger = EnergyLedger()
        ledger.accumulate([
            flow(EnergyDomain.SOURCE, EnergyDomain.ELECTRICAL, 100.0),
            flow(EnergyDomain.ELECTRICAL, EnergyDomain.THERMAL, 40.0),
        ], 1.0)
        assert ledger.net(EnergyDomain.ELECTRICAL) == pytest.approx(60.0)

    def test_waterfall_is_ordered_and_complete(self):
        ledger = EnergyLedger()
        ledger.accumulate([
            flow(EnergyDomain.SOURCE, EnergyDomain.CHEMICAL, 1000.0, "fuel"),
            flow(EnergyDomain.CHEMICAL, EnergyDomain.THERMAL, 900.0, "burn"),
        ], 1.0)
        rows = ledger.waterfall()
        assert len(rows) >= 2
        assert all(isinstance(name, str) for name, _ in rows)

    def test_balance_residual_zero_when_nothing_is_stored(self):
        ledger = EnergyLedger()
        ledger.accumulate([
            flow(EnergyDomain.SOURCE, EnergyDomain.ELECTRICAL, 100.0),
            flow(EnergyDomain.ELECTRICAL, EnergyDomain.ENVIRONMENT, 100.0,
                 "loss"),
        ], 1.0)
        state = SystemState()
        assert ledger.balance_residual(state, state.copy()) < 1e-9

    def test_balance_residual_detects_unstored_energy(self):
        ledger = EnergyLedger()
        ledger.accumulate([
            flow(EnergyDomain.SOURCE, EnergyDomain.THERMAL, 100.0),
        ], 1.0)
        state = SystemState()
        assert ledger.balance_residual(state, state.copy()) == pytest.approx(100.0)

    def test_useful_output_tracks_the_load_label(self):
        ledger = EnergyLedger()
        ledger.accumulate([flow(EnergyDomain.ELECTRICAL,
                                EnergyDomain.ENVIRONMENT, 40.0, "load")], 2.0)
        assert ledger.useful_output() == pytest.approx(80.0)

    def test_as_dict_round_trips_totals(self):
        ledger = EnergyLedger()
        ledger.accumulate([flow(EnergyDomain.SOURCE, EnergyDomain.THERMAL,
                                250.0)], 4.0)
        payload = ledger.as_dict()
        assert payload["total_input"] == pytest.approx(1000.0)

    def test_elapsed_time_accumulates(self):
        ledger = EnergyLedger()
        ledger.accumulate([flow(EnergyDomain.SOURCE, EnergyDomain.THERMAL,
                                10.0)], 1.5)
        ledger.accumulate([flow(EnergyDomain.SOURCE, EnergyDomain.THERMAL,
                                10.0)], 0.5)
        assert ledger.elapsed == pytest.approx(2.0)

    def test_transfers_are_keyed_by_domain_pair(self):
        ledger = EnergyLedger()
        ledger.accumulate([flow(EnergyDomain.ELECTRICAL, EnergyDomain.THERMAL,
                                60.0)], 2.0)
        key = (EnergyDomain.ELECTRICAL, EnergyDomain.THERMAL)
        assert ledger.transfers[key] == pytest.approx(120.0)


class TestBalanceHelpers:
    def test_component_balance_detects_a_leak(self):
        flows = [flow(EnergyDomain.SOURCE, EnergyDomain.ELECTRICAL, 100.0),
                 flow(EnergyDomain.ELECTRICAL, EnergyDomain.THERMAL, 60.0)]
        assert component_balance_residual(flows) == pytest.approx(100.0)

    def test_component_balance_accounts_for_storage(self):
        flows = [flow(EnergyDomain.SOURCE, EnergyDomain.ELECTRICAL, 100.0),
                 flow(EnergyDomain.ELECTRICAL, EnergyDomain.THERMAL, 60.0)]
        assert component_balance_residual(flows, 100.0) == pytest.approx(0.0)

    def test_domain_balance_sums_signed_flows(self):
        flows = [flow(EnergyDomain.SOURCE, EnergyDomain.THERMAL, 30.0),
                 flow(EnergyDomain.THERMAL, EnergyDomain.ENVIRONMENT, 12.0)]
        assert domain_balance(flows, EnergyDomain.THERMAL) == pytest.approx(18.0)

    def test_flows_balance_true_when_closed(self):
        flows = [flow(EnergyDomain.SOURCE, EnergyDomain.ELECTRICAL, 50.0),
                 flow(EnergyDomain.ELECTRICAL, EnergyDomain.ENVIRONMENT, 50.0)]
        assert flows_balance(flows)

    def test_flows_balance_false_when_open(self):
        flows = [flow(EnergyDomain.SOURCE, EnergyDomain.ELECTRICAL, 50.0)]
        assert not flows_balance(flows)


class TestSystemState:
    def test_defaults_are_physical(self):
        state = SystemState()
        assert state.thermal.temperature > 0.0
        assert state.thermal.pressure > 0.0

    def test_copy_is_independent(self):
        state = SystemState()
        clone = state.copy()
        clone.thermal.temperature += 100.0
        assert state.thermal.temperature != clone.thermal.temperature

    def test_thermal_stored_energy_matches_mcvt(self):
        state = SystemState()
        state.thermal.mass = 3.0
        state.thermal.specific_heat = 500.0
        state.thermal.gas_constant = 0.0
        state.thermal.temperature = 400.0
        assert state.thermal.internal_energy == pytest.approx(3.0 * 500.0 * 400.0)

    def test_mechanical_stored_energy_is_half_i_omega_squared(self):
        state = SystemState()
        state.mechanical.inertia = 2.0
        state.mechanical.speed = 10.0
        assert state.mechanical.kinetic_energy == pytest.approx(100.0)

    def test_solid_cv_equals_cp(self):
        state = SystemState()
        state.thermal.specific_heat = 450.0
        state.thermal.gas_constant = 0.0
        assert state.thermal.cv == pytest.approx(450.0)

    def test_gas_uses_cv_not_cp(self):
        state = SystemState()
        state.thermal.mass = 1.0
        state.thermal.specific_heat = 1005.0
        state.thermal.gas_constant = 287.0
        state.thermal.temperature = 300.0
        assert state.thermal.cv == pytest.approx(718.0)
        assert state.thermal.internal_energy == pytest.approx(718.0 * 300.0)

    def test_gamma_follows_from_cp_and_cv(self):
        state = SystemState()
        state.thermal.specific_heat = 1005.0
        state.thermal.gas_constant = 287.0
        assert state.thermal.gamma == pytest.approx(1005.0 / 718.0)

    def test_stored_energy_per_domain(self):
        state = SystemState()
        state.mechanical.inertia = 4.0
        state.mechanical.speed = 5.0
        assert state.stored_energy(EnergyDomain.MECHANICAL) == pytest.approx(50.0)

    def test_snapshot_is_json_friendly(self):
        snapshot = SystemState().snapshot()
        assert isinstance(snapshot, dict)
        assert all(isinstance(k, str) for k in snapshot)
