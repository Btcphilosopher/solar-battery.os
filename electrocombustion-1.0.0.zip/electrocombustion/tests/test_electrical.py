"""Electrical models: resistance, sources, networks, conversion, machines."""
from __future__ import annotations

import math

import pytest

from electrocombustion.electrical import (
    ACPower, ACSource, Battery, ContactResistance, CurrentLimiter, DCDCConverter,
    DCSource, DroopSource, EfficiencyCurve, ElectricalMachine, Geometry,
    Inverter, LossModel, MachineLosses, PowerBudget, PowerConverter, PWMSource,
    RampSource, Rectifier, Resistor, ResistiveNetwork, RLCircuit,
    SynchronousMachine, TimeVaryingSource, ohm_current, parallel,
    power_factor_correction, rms, series,
)
from electrocombustion.materials import COPPER, NICHROME


class TestResistor:
    def test_abstract_value_at_reference(self):
        r = Resistor("r", resistance=10.0, alpha=0.004, t_ref=293.15)
        assert r.value(293.15) == pytest.approx(10.0)

    def test_abstract_value_rises_with_temperature(self):
        r = Resistor("r", resistance=10.0, alpha=0.004, t_ref=293.15)
        assert r.value(393.15) == pytest.approx(14.0)

    def test_geometry_and_material(self):
        r = Resistor("r", material=NICHROME, geometry=Geometry.wire(5.0, 1e-3))
        assert r.value(298.15) == pytest.approx(7.008, rel=1e-3)

    def test_nichrome_element_rises_at_temperature(self):
        r = Resistor("r", material=NICHROME, geometry=Geometry.wire(5.0, 1e-3))
        assert r.value(1073.15) == pytest.approx(7.822, rel=1e-3)

    def test_both_specifications_is_rejected(self):
        with pytest.raises(ValueError):
            Resistor("r", resistance=10.0, material=COPPER,
                     geometry=Geometry.wire(1.0, 1e-3))

    def test_neither_specification_is_rejected(self):
        with pytest.raises(ValueError):
            Resistor("r")

    def test_temperature_for_resistance_inverts(self):
        r = Resistor("r", material=NICHROME, geometry=Geometry.wire(5.0, 1e-3))
        target = r.value(800.0)
        assert r.temperature_for_resistance(target) == pytest.approx(800.0, rel=1e-4)

    def test_dissipation_at_current(self):
        r = Resistor("r", resistance=10.0)
        assert r.dissipation(3.0, 293.15) == pytest.approx(90.0)

    def test_current_for_voltage(self):
        r = Resistor("r", resistance=10.0)
        assert r.current_for(100.0, 293.15) == pytest.approx(10.0)

    def test_conductance_is_the_reciprocal(self):
        r = Resistor("r", resistance=4.0)
        assert r.conductance(293.15) == pytest.approx(0.25)

    def test_material_resistor_is_physical(self):
        r = Resistor("r", material=NICHROME, geometry=Geometry.wire(1.0, 1e-3))
        assert r.is_physical

    def test_abstract_resistor_is_not_physical(self):
        assert not Resistor("r", resistance=1.0).is_physical

    def test_physical_resistor_has_mass(self):
        r = Resistor("r", material=NICHROME, geometry=Geometry.wire(1.0, 1e-3))
        assert r.mass() > 0.0

    def test_series_adds(self):
        a = Resistor("a", resistance=1.0)
        b = Resistor("b", resistance=2.0)
        assert series(a, b, temperature=293.15) == pytest.approx(3.0)

    def test_parallel_halves_equal_resistors(self):
        a = Resistor("a", resistance=10.0)
        b = Resistor("b", resistance=10.0)
        assert parallel(a, b, temperature=293.15) == pytest.approx(5.0)

    def test_contact_resistance_is_positive(self):
        assert ContactResistance(coefficient=1e-4, force=100.0).value() > 0.0

    def test_contact_resistance_falls_with_force(self):
        light = ContactResistance(force=10.0).value()
        firm = ContactResistance(force=1000.0).value()
        assert firm < light

    def test_contact_degradation_increases_resistance(self):
        clean = ContactResistance(degradation=1.0).value()
        dirty = ContactResistance(degradation=3.0).value()
        assert dirty > clean


class TestGeometry:
    def test_wire_area(self):
        g = Geometry.wire(1.0, 2e-3)
        assert g.area == pytest.approx(math.pi * 1e-6)

    def test_wire_surface_area(self):
        g = Geometry.wire(1.0, 2e-3)
        assert g.surface_area == pytest.approx(math.pi * 2e-3)

    def test_bar_geometry(self):
        g = Geometry(length=2.0, area=4e-4)
        assert g.area == pytest.approx(4e-4)

    def test_zero_length_is_rejected(self):
        with pytest.raises(ValueError):
            Geometry(length=0.0, area=1e-4)


class TestSources:
    def test_dc_source_is_constant(self):
        s = DCSource(24.0)
        assert s.voltage(0.0) == pytest.approx(24.0)
        assert s.voltage(1000.0) == pytest.approx(24.0)

    def test_dc_source_is_not_ac(self):
        assert not DCSource(24.0).is_ac

    def test_dc_terminal_voltage_sags_under_current(self):
        s = DCSource(24.0, internal_resistance=0.1)
        assert s.terminal_voltage(10.0, 0.0) == pytest.approx(23.0)

    def test_ac_source_starts_at_zero_phase(self):
        s = ACSource(230.0, frequency=50.0)
        assert s.voltage(0.0) == pytest.approx(0.0, abs=1e-9)

    def test_ac_source_quarter_cycle_is_peak(self):
        s = ACSource(100.0, frequency=50.0)
        assert s.voltage(0.005) == pytest.approx(100.0 * math.sqrt(2.0))

    def test_ac_source_rms_is_preserved(self):
        s = ACSource(230.0, frequency=50.0)
        assert s.rms() == pytest.approx(230.0)

    def test_ac_source_is_ac(self):
        assert ACSource(230.0, frequency=50.0).is_ac

    def test_ramp_source_endpoints(self):
        s = RampSource(0.0, 100.0, duration=10.0)
        assert s.voltage(0.0) == pytest.approx(0.0)
        assert s.voltage(10.0) == pytest.approx(100.0)

    def test_ramp_source_holds_after_duration(self):
        s = RampSource(0.0, 100.0, duration=10.0)
        assert s.voltage(50.0) == pytest.approx(100.0)

    def test_ramp_source_midpoint(self):
        s = RampSource(0.0, 100.0, duration=10.0)
        assert s.voltage(5.0) == pytest.approx(50.0)

    def test_pwm_source_switches(self):
        s = PWMSource(100.0, duty=0.25, switching_frequency=1000.0)
        assert s.voltage(0.0001) == pytest.approx(100.0)
        assert s.voltage(0.0009) == pytest.approx(0.0)

    def test_pwm_mean_matches_duty(self):
        s = PWMSource(100.0, duty=0.3, switching_frequency=1000.0)
        assert s.mean == pytest.approx(30.0)

    def test_pwm_rms_follows_the_square_root_of_duty(self):
        s = PWMSource(100.0, duty=0.25, switching_frequency=1000.0)
        assert s.rms() == pytest.approx(50.0)

    def test_pwm_duty_of_zero_gives_no_output(self):
        s = PWMSource(100.0, duty=0.0, switching_frequency=1000.0)
        assert s.mean == pytest.approx(0.0)

    def test_droop_source_falls_with_current(self):
        s = DroopSource(400.0, rated_current=100.0, droop=0.05)
        assert s.with_current(100.0) < s.with_current(0.0)

    def test_droop_at_rated_current(self):
        s = DroopSource(400.0, rated_current=100.0, droop=0.05)
        assert s.with_current(100.0) == pytest.approx(380.0)

    def test_time_varying_source_uses_the_callable(self):
        s = TimeVaryingSource(lambda t: 12.0 * t)
        assert s.voltage(3.0) == pytest.approx(36.0)


class TestCurrentAndNetworks:
    def test_ohm_current(self):
        assert ohm_current(12.0, 4.0) == pytest.approx(3.0)

    def test_ohm_current_rejects_zero_resistance(self):
        with pytest.raises(ValueError):
            ohm_current(12.0, 0.0)

    def test_rms_of_a_sine(self):
        samples = [math.sin(2 * math.pi * i / 1000) for i in range(1000)]
        assert rms(samples) == pytest.approx(1.0 / math.sqrt(2.0), rel=1e-3)

    def test_rms_of_constant(self):
        assert rms([5.0] * 10) == pytest.approx(5.0)

    def test_rms_of_empty_is_zero(self):
        assert rms([]) == pytest.approx(0.0)

    def test_resistive_network_divider(self):
        network = ResistiveNetwork()
        network.add_resistor("a", "b", Resistor("r1", resistance=100.0))
        network.add_resistor("b", "gnd", Resistor("r2", resistance=100.0))
        network.set_voltage("a", 10.0)
        voltages = network.solve()
        assert voltages["b"] == pytest.approx(5.0, rel=1e-6)

    def test_resistive_network_ground_is_zero(self):
        network = ResistiveNetwork()
        network.add_resistor("a", "gnd", Resistor("r", resistance=50.0))
        network.set_voltage("a", 24.0)
        assert network.solve()["gnd"] == pytest.approx(0.0)

    def test_resistive_network_power_dissipated(self):
        network = ResistiveNetwork()
        network.add_resistor("a", "gnd", Resistor("r", resistance=10.0))
        network.set_voltage("a", 10.0)
        network.solve()
        assert network.power_dissipated() == pytest.approx(10.0, rel=1e-6)

    def test_resistive_network_unequal_divider(self):
        network = ResistiveNetwork()
        network.add_resistor("a", "b", Resistor("r1", resistance=300.0))
        network.add_resistor("b", "gnd", Resistor("r2", resistance=100.0))
        network.set_voltage("a", 12.0)
        assert network.solve()["b"] == pytest.approx(3.0, rel=1e-6)

    def test_rl_circuit_time_constant(self):
        circuit = RLCircuit(resistance=10.0, inductance=0.1)
        assert circuit.time_constant == pytest.approx(0.01)

    def test_rl_circuit_steady_current(self):
        circuit = RLCircuit(resistance=10.0, inductance=0.01)
        assert circuit.steady_current(100.0) == pytest.approx(10.0)

    def test_rl_circuit_reaches_63_percent_in_one_tau(self):
        circuit = RLCircuit(resistance=10.0, inductance=0.1)
        value = circuit.current(circuit.time_constant, 100.0)
        assert value == pytest.approx(10.0 * (1.0 - math.exp(-1.0)))

    def test_rl_circuit_stored_energy(self):
        circuit = RLCircuit(resistance=1.0, inductance=2.0)
        assert circuit.stored_energy(3.0) == pytest.approx(9.0)

    def test_rl_derivative_is_zero_at_steady_state(self):
        circuit = RLCircuit(resistance=10.0, inductance=0.1)
        assert circuit.derivative(10.0, 100.0) == pytest.approx(0.0)

    def test_current_limiter_clamps(self):
        limiter = CurrentLimiter(limit=50.0)
        assert limiter.apply(80.0) == pytest.approx(50.0)

    def test_current_limiter_passes_below_limit(self):
        limiter = CurrentLimiter(limit=50.0)
        assert limiter.apply(20.0) == pytest.approx(20.0)

    def test_current_limiter_reports_limiting(self):
        limiter = CurrentLimiter(limit=50.0)
        limiter.apply(80.0)
        assert limiter.is_limiting


class TestPower:
    def test_from_vi_real_power(self):
        p = ACPower.from_vi(230.0, 10.0, 0.8)
        assert p.real == pytest.approx(1840.0)

    def test_from_vi_apparent_power(self):
        p = ACPower.from_vi(230.0, 10.0, 0.8)
        assert p.apparent == pytest.approx(2300.0)

    def test_from_vi_reactive_power(self):
        p = ACPower.from_vi(230.0, 10.0, 0.8)
        assert abs(p.reactive) == pytest.approx(2300.0 * 0.6)

    def test_power_factor_recovers_the_input(self):
        p = ACPower.from_vi(230.0, 10.0, 0.8)
        assert p.power_factor == pytest.approx(0.8)

    def test_lagging_flag(self):
        assert ACPower.from_vi(230.0, 10.0, 0.8, lagging=True).is_lagging

    def test_unity_power_factor_has_no_reactive_component(self):
        p = ACPower.from_vi(230.0, 10.0, 1.0)
        assert p.reactive == pytest.approx(0.0, abs=1e-9)

    def test_phase_angle_of_unity_pf_is_zero(self):
        assert ACPower.from_vi(230.0, 10.0, 1.0).phase_angle == pytest.approx(0.0)

    def test_power_factor_correction_is_positive(self):
        needed = power_factor_correction(10_000.0, 0.7, 0.95, 50.0, 230.0)
        assert needed > 0.0

    def test_no_correction_needed_when_already_at_target(self):
        needed = power_factor_correction(10_000.0, 0.95, 0.95, 50.0, 230.0)
        assert needed == pytest.approx(0.0, abs=1e-12)

    def test_power_budget_residual_closes(self):
        budget = PowerBudget()
        budget.add_supply(1000.0)
        budget.add_delivery(800.0)
        budget.add_loss(200.0)
        assert budget.residual == pytest.approx(0.0)

    def test_power_budget_efficiency(self):
        budget = PowerBudget()
        budget.add_supply(1000.0)
        budget.add_delivery(900.0)
        budget.add_loss(100.0)
        assert budget.efficiency == pytest.approx(0.9)

    def test_power_budget_detects_a_leak(self):
        budget = PowerBudget()
        budget.add_supply(1000.0)
        budget.add_delivery(500.0)
        assert budget.residual == pytest.approx(500.0)


class TestConversion:
    def test_loss_model_no_load(self):
        model = LossModel(rated_power=1000.0, no_load=10.0, linear=0.0,
                          quadratic=0.0)
        assert model.losses(0.0) == pytest.approx(10.0)

    def test_loss_model_quadratic_scaling(self):
        model = LossModel(rated_power=1000.0, no_load=0.0, linear=0.0,
                          quadratic=0.05)
        assert model.losses(1000.0) == pytest.approx(50.0)

    def test_loss_model_quadratic_quarters_at_half_load(self):
        model = LossModel(rated_power=1000.0, no_load=0.0, linear=0.0,
                          quadratic=0.04)
        assert model.losses(500.0) == pytest.approx(10.0)

    def test_loss_model_efficiency_below_one(self):
        model = LossModel(rated_power=1000.0, no_load=10.0)
        assert 0.0 < model.efficiency(500.0) < 1.0

    def test_peak_efficiency_is_at_partial_load(self):
        model = LossModel(rated_power=1000.0, no_load=10.0, linear=0.0,
                          quadratic=0.04)
        load, eta = model.peak_efficiency()
        assert 0.0 < load < 1.0
        assert eta > model.efficiency(1000.0)

    def test_converter_output_is_less_than_input(self):
        converter = PowerConverter("c", rated_power=1000.0, efficiency=0.95)
        assert converter.output_for_input(800.0) < 800.0

    def test_converter_input_inverts_output(self):
        converter = PowerConverter("c", rated_power=1000.0, efficiency=0.95)
        required = converter.input_for_output(500.0)
        assert converter.output_for_input(required) == pytest.approx(500.0, rel=1e-6)

    def test_converter_reports_overload(self):
        converter = PowerConverter("c", rated_power=1000.0)
        assert converter.overloaded(1500.0)

    def test_converter_load_fraction(self):
        converter = PowerConverter("c", rated_power=1000.0)
        assert converter.load_fraction(250.0) == pytest.approx(0.25)

    def test_efficiency_curve_interpolates(self):
        curve = EfficiencyCurve((0.25, 0.5, 1.0), (0.85, 0.92, 0.9))
        assert curve(0.375) == pytest.approx(0.885)

    def test_efficiency_curve_clamps(self):
        curve = EfficiencyCurve((0.25, 1.0), (0.85, 0.9))
        assert curve(0.0) == pytest.approx(0.85)
        assert curve(2.0) == pytest.approx(0.9)

    def test_efficiency_curve_rejects_impossible_values(self):
        with pytest.raises(ValueError):
            EfficiencyCurve((0.5, 1.0), (0.9, 1.5))

    def test_rectifier_and_inverter_both_lose_energy(self):
        rectifier = Rectifier("r", rated_power=1000.0)
        inverter = Inverter("i", rated_power=1000.0)
        assert rectifier.output_for_input(500.0) < 500.0
        assert inverter.output_for_input(500.0) < 500.0

    def test_rectifier_ac_current(self):
        rectifier = Rectifier("r", rated_power=1000.0, power_factor=0.9)
        assert rectifier.ac_current(900.0, 230.0) > 0.0

    def test_inverter_modulation_limits_ac_voltage(self):
        inverter = Inverter("i", rated_power=1000.0, modulation_limit=1.15)
        expected = 400.0 * 1.15 / (2.0 * math.sqrt(2.0)) * math.sqrt(3.0)
        assert inverter.max_ac_voltage(400.0) == pytest.approx(expected)

    def test_higher_dc_link_allows_more_ac_voltage(self):
        inverter = Inverter("i", rated_power=1000.0)
        assert inverter.max_ac_voltage(800.0) > inverter.max_ac_voltage(400.0)

    def test_dcdc_converter_scales_voltage(self):
        converter = DCDCConverter("dc", rated_power=1000.0)
        assert converter.output_voltage(12.0, 2.0) == pytest.approx(24.0)

    def test_dcdc_clamps_a_ratio_outside_its_limits(self):
        converter = DCDCConverter("dc", rated_power=1000.0,
                                  ratio_limits=(0.5, 2.0))
        assert converter.output_voltage(12.0, 20.0) == pytest.approx(24.0)

    def test_dcdc_output_current_conserves_power_less_losses(self):
        converter = DCDCConverter("dc", rated_power=1000.0)
        assert converter.output_current(100.0, 12.0, 2.0) > 0.0


class TestBattery:
    def test_starts_at_specified_soc(self):
        battery = Battery(capacity=3600.0, soc=0.5)
        assert battery.soc == pytest.approx(0.5)

    def test_discharging_reduces_soc(self):
        """Positive current is discharge: it flows *out* of the battery."""
        battery = Battery(capacity=3600.0, soc=1.0)
        battery.step(100.0, 10.0)
        assert battery.soc < 1.0

    def test_charging_increases_soc(self):
        battery = Battery(capacity=3600.0, soc=0.5)
        battery.step(-100.0, 10.0)
        assert battery.soc > 0.5

    def test_step_returns_the_current_actually_used(self):
        battery = Battery(capacity=3600.0, soc=0.5, max_current=50.0)
        assert battery.step(500.0, 1.0) == pytest.approx(50.0)

    def test_a_full_battery_cannot_be_charged_further(self):
        battery = Battery(capacity=3600.0, soc=1.0)
        assert battery.step(-100.0, 10.0) == pytest.approx(0.0)

    def test_soc_never_exceeds_one(self):
        battery = Battery(capacity=100.0, soc=0.99, max_current=1e6)
        for _ in range(1000):
            battery.step(-1000.0, 1.0)
        assert battery.soc <= 1.0

    def test_soc_never_falls_below_zero(self):
        battery = Battery(capacity=100.0, soc=0.01, max_current=1e6)
        for _ in range(1000):
            battery.step(1000.0, 1.0)
        assert battery.soc >= 0.0

    def test_open_circuit_voltage_rises_with_soc(self):
        low = Battery(capacity=3600.0, soc=0.1)
        high = Battery(capacity=3600.0, soc=0.9)
        assert high.open_circuit_voltage > low.open_circuit_voltage

    def test_terminal_voltage_sags_on_discharge(self):
        battery = Battery(capacity=3600.0, soc=0.5)
        assert battery.terminal_voltage(50.0) < battery.open_circuit_voltage

    def test_terminal_voltage_rises_on_charge(self):
        battery = Battery(capacity=3600.0, soc=0.5)
        assert battery.terminal_voltage(-50.0) > battery.open_circuit_voltage

    def test_internal_losses_are_positive_either_way(self):
        battery = Battery(capacity=3600.0, soc=0.5)
        assert battery.losses(50.0) > 0.0
        assert battery.losses(-50.0) > 0.0

    def test_round_trip_efficiency_is_below_one(self):
        battery = Battery(capacity=3600.0, soc=0.5)
        assert 0.0 < battery.round_trip_efficiency(50.0) < 1.0

    def test_stored_energy_is_positive(self):
        battery = Battery(capacity=3600.0, soc=0.5)
        assert battery.stored_energy() > 0.0

    def test_current_is_clamped_to_the_maximum(self):
        battery = Battery(capacity=36000.0, soc=0.5, max_current=100.0)
        battery.step(500.0, 1.0)
        assert battery.soc >= 0.5 - 100.0 / 36000.0 - 1e-9


class TestMachines:
    def test_motor_produces_mechanical_power(self):
        machine = ElectricalMachine("m", kt=0.5, rated_speed=157.0,
                                    rated_torque=50.0)
        result = machine.as_motor(48.0, 50.0)
        assert result["shaft_power"] > 0.0

    def test_motor_output_never_exceeds_input(self):
        machine = ElectricalMachine("m", kt=0.5, rated_speed=157.0,
                                    rated_torque=50.0)
        r = machine.as_motor(48.0, 50.0)
        assert r["shaft_power"] <= r["electrical_power"] + 1e-9

    def test_motor_losses_close_the_balance(self):
        machine = ElectricalMachine("m", kt=0.5, rated_speed=157.0,
                                    rated_torque=50.0)
        r = machine.as_motor(48.0, 50.0)
        assert r["shaft_power"] + r["loss_total"] == pytest.approx(
            r["electrical_power"], rel=1e-9)

    def test_motor_efficiency_matches_the_power_ratio(self):
        machine = ElectricalMachine("m", kt=0.5, rated_speed=157.0,
                                    rated_torque=50.0)
        r = machine.as_motor(48.0, 50.0)
        assert r["efficiency"] == pytest.approx(
            r["shaft_power"] / r["electrical_power"])

    def test_generator_produces_electrical_power(self):
        machine = ElectricalMachine("m", kt=0.5, rated_speed=157.0,
                                    rated_torque=50.0)
        result = machine.as_generator(157.0, 10.0)
        assert result["electrical_power"] > 0.0

    def test_generator_output_is_below_shaft_input(self):
        machine = ElectricalMachine("m", kt=0.5, rated_speed=157.0,
                                    rated_torque=50.0)
        r = machine.as_generator(157.0, 10.0)
        assert r["electrical_power"] <= r["shaft_power"] + 1e-9

    def test_back_emf_is_proportional_to_speed(self):
        machine = ElectricalMachine("m", kt=0.5)
        assert machine.back_emf(100.0) == pytest.approx(2.0 * machine.back_emf(50.0))

    def test_torque_is_proportional_to_current(self):
        machine = ElectricalMachine("m", kt=0.5)
        assert machine.torque(20.0) == pytest.approx(10.0)

    def test_current_for_torque_inverts_torque(self):
        machine = ElectricalMachine("m", kt=0.5)
        assert machine.current_for_torque(10.0) == pytest.approx(20.0)

    def test_no_load_speed_scales_with_voltage(self):
        machine = ElectricalMachine("m", kt=0.5)
        assert machine.no_load_speed(48.0) == pytest.approx(96.0)

    def test_stall_current_is_voltage_over_resistance(self):
        machine = ElectricalMachine("m", armature_resistance=0.1)
        assert machine.stall_current(48.0) == pytest.approx(480.0)

    def test_machine_losses_sum(self):
        losses = MachineLosses(copper=10.0, iron=5.0, windage=2.0, stray=1.0)
        assert losses.total == pytest.approx(18.0)

    def test_machine_losses_as_dict(self):
        losses = MachineLosses(copper=10.0)
        assert losses.as_dict()["copper"] == pytest.approx(10.0)

    def test_overload_detection(self):
        machine = ElectricalMachine("m", rated_torque=50.0, rated_speed=157.0)
        assert machine.is_overloaded(80.0, 100.0)
        assert not machine.is_overloaded(20.0, 100.0)

    def test_electrical_frequency_follows_pole_pairs(self):
        two = ElectricalMachine("m", pole_pairs=2)
        four = ElectricalMachine("m", pole_pairs=4)
        assert four.electrical_frequency(100.0) == pytest.approx(
            2.0 * two.electrical_frequency(100.0))

    def test_synchronous_pull_out_power_is_positive(self):
        machine = SynchronousMachine("s", synchronous_reactance=1.0,
                                     field_current=2.0)
        assert machine.pull_out_power(400.0, 157.0) > 0.0

    def test_power_angle_output_peaks_at_ninety_degrees(self):
        machine = SynchronousMachine("s", synchronous_reactance=1.0,
                                     field_current=2.0)
        peak = machine.power_angle_output(400.0, 157.0, math.pi / 2.0)
        assert peak >= machine.power_angle_output(400.0, 157.0, math.pi / 4.0)

    def test_excitation_voltage_scales_with_field_current(self):
        weak = SynchronousMachine("s", field_current=1.0)
        strong = SynchronousMachine("s", field_current=2.0)
        assert strong.excitation_voltage(157.0) > weak.excitation_voltage(157.0)
