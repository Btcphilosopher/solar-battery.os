"""Unit conversion and physical constants."""
from __future__ import annotations

import math

import pytest

from electrocombustion.core import units as U
from electrocombustion.core.units import UnitError, convert, from_si, to_si


class TestTemperature:
    def test_celsius_to_kelvin(self):
        assert to_si(0.0, "degC") == pytest.approx(273.15)

    def test_kelvin_to_celsius(self):
        assert from_si(373.15, "degC") == pytest.approx(100.0)

    def test_fahrenheit_freezing(self):
        assert to_si(32.0, "degF") == pytest.approx(273.15)

    def test_fahrenheit_boiling(self):
        assert to_si(212.0, "degF") == pytest.approx(373.15)

    def test_round_trip(self):
        for value in (-40.0, 0.0, 25.0, 1200.0):
            assert from_si(to_si(value, "degC"), "degC") == pytest.approx(value)

    def test_celsius_fahrenheit_crossover(self):
        assert convert(-40.0, "degC", "degF") == pytest.approx(-40.0)


class TestMultiplicative:
    @pytest.mark.parametrize("value,unit,expected", [
        (1.0, "km", 1000.0),
        (1.0, "mm", 1e-3),
        (1.0, "kW", 1000.0),
        (1.0, "MW", 1e6),
        (1.0, "bar", 1e5),
        (1.0, "h", 3600.0),
        (1.0, "kWh", 3.6e6),
    ])
    def test_to_si(self, value, unit, expected):
        assert to_si(value, unit) == pytest.approx(expected)

    def test_rpm_to_rad_per_second(self):
        assert to_si(60.0, "rpm") == pytest.approx(2.0 * math.pi)

    def test_convert_between_units(self):
        assert convert(1.0, "kWh", "MJ") == pytest.approx(3.6)

    def test_incompatible_units_raise(self):
        with pytest.raises(UnitError):
            convert(1.0, "m", "kg")

    def test_compatible_units_are_recognised(self):
        assert U.compatible("kWh", "MJ")
        assert not U.compatible("W", "J")

    def test_dimension_lookup(self):
        assert U.dimension_of("MW") == "power"
        assert U.dimension_of("degF") == "temperature"

    def test_unknown_unit_raises(self):
        with pytest.raises(UnitError):
            to_si(1.0, "furlong_per_fortnight")

    def test_coulomb_is_not_celsius(self):
        assert to_si(1.0, "C") == pytest.approx(1.0)
        assert to_si(1.0, "degC") == pytest.approx(274.15)


class TestConstants:
    def test_universal_gas_constant(self):
        assert U.R_UNIVERSAL == pytest.approx(8.314462618, rel=1e-9)

    def test_stefan_boltzmann(self):
        assert U.STEFAN_BOLTZMANN == pytest.approx(5.670374419e-8, rel=1e-9)

    def test_air_gas_constant_consistent(self):
        assert U.R_AIR == pytest.approx(U.R_UNIVERSAL / U.M_AIR, rel=1e-6)

    def test_inert_air_closes_the_mass_balance(self):
        """The derived inert molar mass must reproduce air exactly."""
        combined = (U.O2_MOLE_FRACTION_AIR * U.M_O2
                    + (1.0 - U.O2_MOLE_FRACTION_AIR) * U.M_INERT_AIR)
        assert combined == pytest.approx(U.M_AIR, rel=1e-12)

    def test_atmospheric_pressure(self):
        assert U.P_ATM == pytest.approx(101325.0)

    def test_absolute_zero_offset(self):
        assert U.ZERO_CELSIUS == pytest.approx(273.15)
