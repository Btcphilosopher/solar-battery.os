"""Torque models, inertia, shafts, gearing and cycle efficiencies."""
from __future__ import annotations

import math

import pytest

from electrocombustion.mechanical import (
    CallableTorque, Clutch, ConstantPowerLoad, ConstantTorque, CoulombFriction,
    Coupling, EfficiencyMap, FrictionModel, Gearbox, InertiaStack,
    QuadraticLoad, Shaft, TorqueCurve, ViscousLoad, annulus_inertia,
    brayton_efficiency, carnot_efficiency, chain_efficiency, combine,
    cylinder_inertia, diesel_efficiency, disc_inertia, equivalent_inertia,
    mechanical_efficiency, otto_efficiency, power_from_torque, rad_s_to_rpm,
    reflected_inertia, reflected_torque, rpm_to_rad_s, torque_from_power,
)


class TestTorqueBasics:
    def test_power_from_torque(self):
        assert power_from_torque(10.0, 100.0) == pytest.approx(1000.0)

    def test_torque_from_power_inverts(self):
        assert torque_from_power(1000.0, 100.0) == pytest.approx(10.0)

    def test_torque_from_power_is_safe_at_zero_speed(self):
        assert torque_from_power(1000.0, 0.0) == pytest.approx(0.0)

    def test_rpm_conversion_round_trip(self):
        assert rad_s_to_rpm(rpm_to_rad_s(1500.0)) == pytest.approx(1500.0)

    def test_1500_rpm_is_about_157_rad_per_second(self):
        assert rpm_to_rad_s(1500.0) == pytest.approx(157.08, rel=1e-4)


class TestTorqueModels:
    def test_constant_torque_ignores_speed(self):
        model = ConstantTorque(25.0)
        assert model.torque(0.0) == pytest.approx(25.0)
        assert model.torque(500.0) == pytest.approx(25.0)

    def test_viscous_load_is_linear_and_opposing(self):
        model = ViscousLoad(damping=0.02)
        assert model.torque(100.0) == pytest.approx(-2.0)

    def test_viscous_load_reverses_with_direction(self):
        model = ViscousLoad(damping=0.02)
        assert model.torque(-100.0) == pytest.approx(2.0)

    def test_quadratic_load_scales_with_the_square(self):
        model = QuadraticLoad(coefficient=1e-3)
        assert model.torque(100.0) == pytest.approx(-10.0)

    def test_quadratic_load_always_opposes_motion(self):
        model = QuadraticLoad(coefficient=1e-3)
        assert model.torque(-100.0) > 0.0

    def test_constant_power_load_torque_falls_with_speed(self):
        model = ConstantPowerLoad(rating=1000.0)
        assert abs(model.torque(200.0)) < abs(model.torque(100.0))

    def test_constant_power_load_is_zero_below_cut_in(self):
        model = ConstantPowerLoad(rating=1000.0, minimum_speed=10.0)
        assert model.torque(1.0) == pytest.approx(0.0)

    def test_constant_power_load_absorbs_its_rating(self):
        model = ConstantPowerLoad(rating=1000.0)
        assert model.power(100.0) == pytest.approx(-1000.0)

    def test_coulomb_friction_is_constant_above_stiction(self):
        model = CoulombFriction(magnitude=5.0, stiction_speed=0.1)
        assert model.torque(50.0) == pytest.approx(-5.0)

    def test_coulomb_friction_is_blended_near_standstill(self):
        model = CoulombFriction(magnitude=5.0, stiction_speed=0.1)
        assert model.torque(0.05) == pytest.approx(-2.5)

    def test_coulomb_friction_is_zero_at_rest(self):
        model = CoulombFriction(magnitude=5.0)
        assert model.torque(0.0) == pytest.approx(0.0)

    def test_torque_curve_interpolates(self):
        curve = TorqueCurve((0.0, 100.0, 200.0), (50.0, 80.0, 40.0))
        assert curve.torque(50.0) == pytest.approx(65.0)

    def test_torque_curve_clamps_outside_the_table(self):
        curve = TorqueCurve((0.0, 100.0), (50.0, 80.0))
        assert curve.torque(-10.0) == pytest.approx(50.0)
        assert curve.torque(500.0) == pytest.approx(80.0)

    def test_torque_curve_peak(self):
        curve = TorqueCurve((0.0, 100.0, 200.0), (50.0, 80.0, 40.0))
        speed, torque = curve.peak()
        assert speed == pytest.approx(100.0)
        assert torque == pytest.approx(80.0)

    def test_torque_curve_peak_power_is_above_peak_torque_speed(self):
        curve = TorqueCurve((0.0, 100.0, 200.0), (50.0, 80.0, 40.0))
        speed, _ = curve.peak_power()
        assert speed >= 100.0

    def test_torque_curve_rejects_unsorted_speeds(self):
        with pytest.raises(ValueError):
            TorqueCurve((100.0, 0.0), (50.0, 80.0))

    def test_torque_curve_rejects_mismatched_lengths(self):
        with pytest.raises(ValueError):
            TorqueCurve((0.0, 100.0), (50.0,))

    def test_callable_torque_delegates(self):
        model = CallableTorque(lambda w, t: 2.0 * w)
        assert model.torque(10.0) == pytest.approx(20.0)

    def test_combine_sums_models(self):
        total = combine(ConstantTorque(100.0), ViscousLoad(0.5))
        assert total(100.0) == pytest.approx(50.0)


class TestInertia:
    def test_disc_inertia_formula(self):
        assert disc_inertia(10.0, 0.2) == pytest.approx(0.2)

    def test_annulus_exceeds_the_solid_disc_of_the_same_mass(self):
        assert annulus_inertia(10.0, 0.1, 0.2) > disc_inertia(10.0, 0.2) * 0.99

    def test_annulus_rejects_inverted_radii(self):
        with pytest.raises(ValueError):
            annulus_inertia(10.0, 0.3, 0.2)

    def test_cylinder_inertia_is_positive(self):
        assert cylinder_inertia(7800.0, 0.05, 0.2) > 0.0

    def test_reflected_inertia_scales_with_the_square_of_the_ratio(self):
        assert reflected_inertia(4.0, 0.5) == pytest.approx(1.0)

    def test_reduction_makes_the_load_look_lighter(self):
        assert reflected_inertia(10.0, 0.1) < 10.0

    def test_reflected_torque_accounts_for_efficiency(self):
        assert reflected_torque(10.0, 0.5, 0.8) == pytest.approx(6.25)

    def test_reflected_torque_rejects_impossible_efficiency(self):
        with pytest.raises(ValueError):
            reflected_torque(10.0, 0.5, 1.5)

    def test_equivalent_inertia_of_a_translating_mass(self):
        assert equivalent_inertia(100.0, 0.3) == pytest.approx(9.0)

    def test_stack_totals(self):
        stack = InertiaStack().add(1.0).add(4.0, 0.5)
        assert stack.total == pytest.approx(2.0)

    def test_stack_kinetic_energy(self):
        stack = InertiaStack().add(2.0)
        assert stack.kinetic_energy(10.0) == pytest.approx(100.0)

    def test_stack_acceleration(self):
        stack = InertiaStack().add(2.0)
        assert stack.acceleration(10.0) == pytest.approx(5.0)

    def test_stack_spin_up_time(self):
        stack = InertiaStack().add(2.0)
        assert stack.spin_up_time(10.0, 100.0) == pytest.approx(20.0)

    def test_stack_rejects_negative_inertia(self):
        with pytest.raises(ValueError):
            InertiaStack().add(-1.0)


class TestShaft:
    def test_kinetic_energy_formula(self):
        shaft = Shaft(inertia=2.0, speed=10.0)
        assert shaft.kinetic_energy == pytest.approx(100.0)

    def test_rpm_conversion(self):
        shaft = Shaft(speed=rpm_to_rad_s(1500.0))
        assert shaft.rpm == pytest.approx(1500.0)

    def test_zero_inertia_is_rejected(self):
        with pytest.raises(ValueError):
            Shaft(inertia=0.0)

    def test_acceleration_from_torque(self):
        shaft = Shaft(inertia=2.0)
        assert shaft.acceleration(10.0) == pytest.approx(5.0)

    def test_damping_opposes_motion(self):
        shaft = Shaft(inertia=1.0, damping=0.1, speed=100.0)
        assert shaft.parasitic_torque() == pytest.approx(-10.0)

    def test_step_increases_speed_under_torque(self):
        shaft = Shaft(inertia=1.0)
        shaft.step(10.0, 0.1)
        assert shaft.speed == pytest.approx(1.0)

    def test_speed_is_capped(self):
        shaft = Shaft(inertia=0.1, max_speed=50.0)
        for _ in range(1000):
            shaft.step(100.0, 0.01)
        assert shaft.speed == pytest.approx(50.0)

    def test_steady_speed_balances_the_torque(self):
        shaft = Shaft(inertia=0.5, damping=0.01, friction_torque=0.2)
        speed = shaft.steady_speed(5.0)
        assert 5.0 + shaft.parasitic_torque(speed) == pytest.approx(0.0, abs=1e-6)

    def test_steady_speed_raises_when_no_equilibrium_exists(self):
        shaft = Shaft(inertia=1.0, damping=0.0)
        with pytest.raises(ValueError):
            shaft.steady_speed(10.0)

    def test_time_constant_is_infinite_without_damping(self):
        assert math.isinf(Shaft(inertia=1.0).time_constant())

    def test_time_constant_formula(self):
        assert Shaft(inertia=2.0, damping=0.5).time_constant() == pytest.approx(4.0)

    def test_angle_wraps(self):
        shaft = Shaft(inertia=1.0, speed=100.0)
        for _ in range(100):
            shaft.step(0.0, 0.01)
        assert 0.0 <= shaft.angle < 2.0 * math.pi


class TestGearing:
    def test_output_speed(self):
        assert Gearbox(ratio=0.25).output_speed(400.0) == pytest.approx(100.0)

    def test_input_speed_inverts(self):
        box = Gearbox(ratio=0.25)
        assert box.input_speed(box.output_speed(400.0)) == pytest.approx(400.0)

    def test_reduction_multiplies_torque(self):
        box = Gearbox(ratio=0.25, efficiency=1.0)
        assert box.output_torque(10.0) == pytest.approx(40.0)

    def test_efficiency_reduces_output_torque(self):
        lossy = Gearbox(ratio=0.25, efficiency=0.9)
        ideal = Gearbox(ratio=0.25, efficiency=1.0)
        assert lossy.output_torque(10.0) < ideal.output_torque(10.0)

    def test_input_torque_inverts_output_torque(self):
        box = Gearbox(ratio=0.25, efficiency=0.9)
        assert box.input_torque(box.output_torque(10.0)) == pytest.approx(10.0)

    def test_losses_are_positive(self):
        box = Gearbox(ratio=0.5, efficiency=0.95)
        assert box.losses(10.0, 100.0) == pytest.approx(50.0)

    def test_ideal_gearbox_has_no_losses(self):
        assert Gearbox(efficiency=1.0).losses(10.0, 100.0) == pytest.approx(0.0)

    def test_zero_ratio_is_rejected(self):
        with pytest.raises(ValueError):
            Gearbox(ratio=0.0)

    def test_impossible_efficiency_is_rejected(self):
        with pytest.raises(ValueError):
            Gearbox(efficiency=1.5)

    def test_reflected_inertia_includes_the_gearbox(self):
        box = Gearbox(ratio=0.5, inertia=0.1)
        assert box.reflected_inertia(4.0) == pytest.approx(1.1)


class TestCouplingAndClutch:
    def test_coupling_torque_is_proportional_to_twist(self):
        coupling = Coupling(stiffness=1000.0, damping=0.0)
        assert coupling.torque(0.01, 0.0) == pytest.approx(10.0)

    def test_coupling_damping_adds_torque(self):
        coupling = Coupling(stiffness=0.0, damping=5.0)
        assert coupling.torque(0.0, 2.0) == pytest.approx(10.0)

    def test_backlash_gives_no_torque_inside_the_gap(self):
        coupling = Coupling(stiffness=1000.0, damping=0.0, backlash=0.02)
        assert coupling.torque(0.005, 0.0) == pytest.approx(0.0)

    def test_backlash_engages_beyond_the_gap(self):
        coupling = Coupling(stiffness=1000.0, damping=0.0, backlash=0.02)
        assert coupling.torque(0.03, 0.0) == pytest.approx(20.0)

    def test_coupling_step_accumulates_twist(self):
        coupling = Coupling(stiffness=1000.0, damping=0.0)
        coupling.step(10.0, 0.0, 0.001)
        assert coupling.twist > 0.0

    def test_natural_frequency_formula(self):
        coupling = Coupling(stiffness=1000.0)
        assert coupling.natural_frequency(2.0, 2.0) == pytest.approx(
            math.sqrt(1000.0 / 1.0))

    def test_natural_frequency_rejects_zero_inertia(self):
        with pytest.raises(ValueError):
            Coupling().natural_frequency(0.0, 1.0)

    def test_clutch_locks_when_synchronised(self):
        clutch = Clutch(capacity=200.0)
        clutch.transmitted_torque(100.0, 0.0)
        assert clutch.locked

    def test_clutch_slips_when_overloaded(self):
        clutch = Clutch(capacity=100.0)
        assert clutch.transmitted_torque(500.0, 50.0) == pytest.approx(100.0)

    def test_slipping_generates_heat(self):
        clutch = Clutch(capacity=100.0)
        torque = clutch.transmitted_torque(500.0, 50.0)
        assert clutch.slip_power(torque, 50.0) == pytest.approx(5000.0)

    def test_locked_clutch_generates_no_heat(self):
        clutch = Clutch(capacity=200.0)
        torque = clutch.transmitted_torque(100.0, 0.0)
        assert clutch.slip_power(torque, 0.0) == pytest.approx(0.0)

    def test_partial_engagement_reduces_capacity(self):
        clutch = Clutch(capacity=200.0, engagement=0.25)
        assert clutch.transmitted_torque(500.0, 50.0) == pytest.approx(50.0)


class TestEfficiency:
    def test_chain_efficiency_multiplies(self):
        assert chain_efficiency(0.9, 0.9) == pytest.approx(0.81)

    def test_chain_efficiency_rejects_impossible_values(self):
        with pytest.raises(ValueError):
            chain_efficiency(1.2)

    def test_mechanical_efficiency_ratio(self):
        assert mechanical_efficiency(80.0, 100.0) == pytest.approx(0.8)

    def test_mechanical_efficiency_is_zero_without_input(self):
        assert mechanical_efficiency(80.0, 0.0) == pytest.approx(0.0)

    def test_friction_torque_grows_with_speed(self):
        model = FrictionModel()
        assert model.torque(500.0) > model.torque(100.0)

    def test_friction_torque_is_always_positive(self):
        model = FrictionModel()
        assert model.torque(-500.0) > 0.0

    def test_friction_power_formula(self):
        model = FrictionModel(constant=1.0, linear=0.0, quadratic=0.0)
        assert model.power(100.0) == pytest.approx(100.0)

    def test_resisting_torque_opposes_motion(self):
        model = FrictionModel(constant=1.0, linear=0.0, quadratic=0.0)
        assert model.resisting_torque(100.0) == pytest.approx(-1.0)
        assert model.resisting_torque(-100.0) == pytest.approx(1.0)

    def test_resisting_torque_is_zero_at_rest(self):
        assert FrictionModel().resisting_torque(0.0) == pytest.approx(0.0)

    def test_efficiency_map_interpolates(self):
        emap = EfficiencyMap((100.0, 200.0), (10.0, 20.0),
                             ((0.8, 0.85), (0.86, 0.9)))
        assert emap(150.0, 15.0) == pytest.approx(0.8525)

    def test_efficiency_map_clamps_outside_the_grid(self):
        emap = EfficiencyMap((100.0, 200.0), (10.0, 20.0),
                             ((0.8, 0.85), (0.86, 0.9)))
        assert emap(0.0, 0.0) == pytest.approx(0.8)
        assert emap(1000.0, 1000.0) == pytest.approx(0.9)

    def test_efficiency_map_best_point(self):
        emap = EfficiencyMap((100.0, 200.0), (10.0, 20.0),
                             ((0.8, 0.85), (0.86, 0.9)))
        speed, torque, eta = emap.best_point()
        assert (speed, torque, eta) == (200.0, 20.0, 0.9)

    def test_efficiency_map_rejects_values_above_one(self):
        with pytest.raises(ValueError):
            EfficiencyMap((100.0, 200.0), (10.0, 20.0),
                          ((0.8, 1.2), (0.86, 0.9)))

    def test_efficiency_map_rejects_a_ragged_grid(self):
        with pytest.raises(ValueError):
            EfficiencyMap((100.0, 200.0), (10.0, 20.0), ((0.8, 0.85),))


class TestCycleEfficiencies:
    def test_carnot_between_800_and_300(self):
        assert carnot_efficiency(800.0, 300.0) == pytest.approx(0.625)

    def test_carnot_is_zero_without_a_gradient(self):
        assert carnot_efficiency(300.0, 300.0) == pytest.approx(0.0)

    def test_carnot_rejects_non_physical_temperatures(self):
        with pytest.raises(ValueError):
            carnot_efficiency(-100.0, 300.0)

    def test_otto_at_compression_ratio_ten(self):
        assert otto_efficiency(10.0) == pytest.approx(0.6019, rel=1e-3)

    def test_otto_rises_with_compression_ratio(self):
        assert otto_efficiency(14.0) > otto_efficiency(10.0)

    def test_otto_rejects_a_ratio_below_one(self):
        with pytest.raises(ValueError):
            otto_efficiency(0.9)

    def test_diesel_at_eighteen_to_one(self):
        assert diesel_efficiency(18.0, 2.0) == pytest.approx(0.6316, rel=1e-3)

    def test_diesel_falls_as_cutoff_grows(self):
        assert diesel_efficiency(18.0, 3.0) < diesel_efficiency(18.0, 1.5)

    def test_diesel_reduces_to_otto_at_unit_cutoff(self):
        assert diesel_efficiency(10.0, 1.0) == pytest.approx(otto_efficiency(10.0))

    def test_brayton_at_pressure_ratio_twelve(self):
        assert brayton_efficiency(12.0) == pytest.approx(0.5083, rel=1e-3)

    def test_brayton_rises_with_pressure_ratio(self):
        assert brayton_efficiency(20.0) > brayton_efficiency(12.0)

    def test_all_cycles_stay_below_carnot(self):
        """No air-standard cycle may beat the Carnot bound for its extremes."""
        gamma = 1.4
        cr = 10.0
        t_cold, t_hot = 300.0, 300.0 * cr ** (gamma - 1.0) * 3.0
        assert otto_efficiency(cr, gamma) < carnot_efficiency(t_hot, t_cold)
