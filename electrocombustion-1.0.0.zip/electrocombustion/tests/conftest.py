"""Shared fixtures for the ELECTROCOMBUSTION test suite."""
from __future__ import annotations

import math
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from electrocombustion.combustion import DIESEL, METHANE, Mixture
from electrocombustion.core import (
    ElectroCombustionEngine, EngineConfig, SystemState,
)
from electrocombustion.electrical import DCSource, Geometry, Resistor
from electrocombustion.materials import COPPER, NICHROME, STEEL_CARBON
from electrocombustion.mechanical import FrictionModel
from electrocombustion.systems import (
    CombustionEngine, CycleModel, EngineSpec, Generator, GeneratorSpec,
)


@pytest.fixture
def thermal_state() -> SystemState:
    """A solid steel thermal mass at ambient."""
    state = SystemState()
    state.thermal.mass = 2.0
    state.thermal.specific_heat = 450.0
    state.thermal.gas_constant = 0.0
    state.thermal.temperature = 300.0
    state.ambient_temperature = 300.0
    return state


@pytest.fixture
def engine(thermal_state: SystemState) -> ElectroCombustionEngine:
    return ElectroCombustionEngine(thermal_state,
                                   config=EngineConfig(scheme="rk4"))


@pytest.fixture
def nichrome_element() -> Resistor:
    return Resistor("element", material=NICHROME,
                    geometry=Geometry.wire(5.0, 1e-3))


@pytest.fixture
def mains() -> DCSource:
    return DCSource(230.0)


@pytest.fixture
def diesel_engine() -> CombustionEngine:
    spec = EngineSpec(
        fuel=DIESEL, rated_power=100_000.0, rated_speed=157.08,
        cycle=CycleModel(kind="diesel", compression_ratio=18.0,
                         cutoff_ratio=2.2, gamma=1.35, quality=0.80),
        friction=FrictionModel(constant=15.0, linear=0.05, quadratic=2e-4),
    )
    return CombustionEngine(spec)


@pytest.fixture
def genset() -> Generator:
    return Generator(GeneratorSpec(rated_power=50_000.0, rated_speed=157.08))


@pytest.fixture
def stoichiometric_methane() -> Mixture:
    return Mixture(METHANE, 1.0)


def approx(value: float, expected: float, relative: float = 1e-9) -> bool:
    return abs(value - expected) <= relative * max(1.0, abs(expected))
