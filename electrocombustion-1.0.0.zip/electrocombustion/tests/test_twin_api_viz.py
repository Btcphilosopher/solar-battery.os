"""Digital twin, service layer, streaming and visualisation."""
from __future__ import annotations

import json
import math
import os
import tempfile

import pytest

from electrocombustion.api import (
    EngineService, RecordingSubscriber, ServiceError, SimpleAPIServer,
    StreamConfig, TelemetryBroadcaster, dumps, json_safe, websocket_adapter,
)
from electrocombustion.core.component import Component, ComponentOutput, Derivatives
from electrocombustion.core.engine import ElectroCombustionEngine, EngineConfig
from electrocombustion.core.state import EnergyDomain, PowerFlow, SystemState
from electrocombustion.faults import FaultClassifier, standard_limits
from electrocombustion.telemetry import (
    CSVReplay, TelemetryLogger, TelemetryValidator,
)
from electrocombustion.twin import EnergyTwin, TwinSnapshot
from electrocombustion.visualisation import (
    bar, energy_waterfall, format_energy, format_power, ledger_report,
    operating_map_text, severity_timeline, sparkline, table,
)
from electrocombustion.visualisation import plots


class Heater(Component):
    order = 10

    def __init__(self, name: str = "heat", power: float = 1000.0) -> None:
        super().__init__(name)
        self.power = power

    def evaluate(self, state, dt, context):
        power = context.get("heat.power", self.power)
        return ComponentOutput(
            flows=[PowerFlow(EnergyDomain.SOURCE, EnergyDomain.THERMAL, power,
                             "heat", self.name)],
            derivatives=Derivatives(heat_input=power),
            diagnostics={"heat.power": power},
        )


def build_engine() -> ElectroCombustionEngine:
    state = SystemState()
    state.thermal.mass = 1.0
    state.thermal.specific_heat = 500.0
    state.thermal.gas_constant = 0.0
    state.thermal.temperature = 300.0
    engine = ElectroCombustionEngine(state, config=EngineConfig(scheme="rk4"))
    engine.add(Heater())
    return engine


class TestEnergyTwin:
    def twin(self) -> EnergyTwin:
        return EnergyTwin(build_engine(),
                          {"temperature": lambda s: s.thermal.temperature})

    def test_step_advances_the_model(self):
        twin = self.twin()
        twin.step(1.0)
        assert twin.engine.state.time == pytest.approx(1.0)

    def test_snapshot_records_the_model_value(self):
        twin = self.twin()
        snapshot = twin.step(1.0)
        assert snapshot.modelled["temperature"] > 300.0

    def test_residual_is_model_minus_measurement(self):
        twin = self.twin()
        snapshot = twin.step(1.0, {"temperature": 300.0})
        assert snapshot.residuals["temperature"] == pytest.approx(
            snapshot.modelled["temperature"] - 300.0)

    def test_unknown_channels_are_ignored(self):
        twin = self.twin()
        snapshot = twin.step(1.0, {"nonsense": 1.0})
        assert "nonsense" not in snapshot.measured

    def test_residual_statistics_over_a_run(self):
        twin = self.twin()
        for _ in range(10):
            twin.step(0.1, {"temperature": 300.0})
        stats = twin.residual_statistics("temperature")
        assert stats["count"] == pytest.approx(10.0)
        assert stats["rms"] > 0.0

    def test_statistics_for_an_unmeasured_channel_raises(self):
        twin = self.twin()
        twin.step(1.0)
        with pytest.raises(KeyError):
            twin.residual_statistics("temperature")

    def test_worst_channel_identifies_the_biggest_gap(self):
        snapshot = TwinSnapshot(0.0, {"a": 10.0, "b": 1.0},
                                {"a": 0.0, "b": 0.0},
                                {"a": 10.0, "b": 1.0})
        assert snapshot.worst_channel()[0] == "a"

    def test_balance_check_passes_on_a_conserving_model(self):
        twin = self.twin()
        for _ in range(10):
            twin.step(0.1)
        ok, _ = twin.balance_check()
        assert ok

    def test_summary_contains_the_headline_numbers(self):
        twin = self.twin()
        twin.step(1.0)
        summary = twin.summary()
        assert set(summary) >= {"time", "energy_in", "efficiency", "balanced"}

    def test_report_is_readable_text(self):
        twin = self.twin()
        twin.step(1.0, {"temperature": 300.0})
        assert "digital twin" in twin.report()

    def test_classifier_severity_is_carried_through(self):
        twin = EnergyTwin(build_engine(),
                          {"temperature": lambda s: s.thermal.temperature},
                          classifier=FaultClassifier(
                              standard_limits(max_temperature=310.0)))
        for _ in range(20):
            snapshot = twin.step(1.0)
        assert snapshot.severity.value != "NORMAL"

    def test_validator_findings_raise_a_warning(self):
        validator = TelemetryValidator().add_range("temperature", 0.0, 310.0)
        twin = EnergyTwin(build_engine(),
                          {"temperature": lambda s: s.thermal.temperature},
                          validator=validator)
        snapshot = twin.step(1.0, {"temperature": 5000.0})
        assert snapshot.severity.value == "WARNING"

    def test_timeline_compresses_unchanged_severities(self):
        twin = self.twin()
        for _ in range(5):
            twin.step(0.1)
        assert len(twin.timeline()) == 1

    def test_reset_clears_the_history(self):
        twin = self.twin()
        twin.step(1.0)
        twin.reset()
        assert not twin.snapshots

    def test_replay_from_a_csv_uses_the_recorded_timestamps(self):
        logger = TelemetryLogger()
        for i in range(10):
            logger.log({"time": float(i) * 0.5, "temperature": 300.0 + i})
        with tempfile.TemporaryDirectory() as directory:
            path = os.path.join(directory, "log.csv")
            logger.to_csv(path)
            twin = self.twin()
            snapshots = twin.replay(CSVReplay(path), 0.5)
        assert len(snapshots) == 10
        assert twin.engine.state.time == pytest.approx(5.0, rel=1e-6)

    def test_channels_can_be_added_fluently(self):
        twin = EnergyTwin(build_engine())
        twin.add_channel("temperature", lambda s: s.thermal.temperature)
        assert "temperature" in twin.channels


class TestService:
    def service(self) -> EngineService:
        return EngineService(build_engine)

    def test_health_reports_ok(self):
        assert self.service().health()["status"] == "ok"

    def test_create_session_returns_an_id(self):
        assert "session_id" in self.service().create_session()

    def test_unknown_session_is_a_404(self):
        with pytest.raises(ServiceError) as excinfo:
            self.service().engine("nope")
        assert excinfo.value.status == 404

    def test_step_advances_the_session(self):
        service = self.service()
        session = service.create_session()["session_id"]
        result = service.step(session, 0.1)
        assert result["time"] == pytest.approx(0.1)

    def test_negative_step_is_rejected(self):
        service = self.service()
        session = service.create_session()["session_id"]
        with pytest.raises(ServiceError):
            service.step(session, -1.0)

    def test_run_returns_a_summary(self):
        service = self.service()
        session = service.create_session()["session_id"]
        result = service.run(session, 1.0, 0.1)
        assert result["summary"]["steps"] == 10

    def test_run_beyond_the_duration_limit_is_refused(self):
        service = EngineService(build_engine, max_duration=10.0)
        session = service.create_session()["session_id"]
        with pytest.raises(ServiceError) as excinfo:
            service.run(session, 100.0, 0.1)
        assert excinfo.value.status == 413

    def test_run_beyond_the_step_limit_is_refused(self):
        service = EngineService(build_engine, max_steps=10)
        session = service.create_session()["session_id"]
        with pytest.raises(ServiceError):
            service.run(session, 1.0, 1e-4)

    def test_inputs_reach_the_components(self):
        service = self.service()
        session = service.create_session()["session_id"]
        service.run(session, 1.0, 0.1, {"heat.power": 5000.0})
        assert service.energy(session)["summary"]["input"] == pytest.approx(
            5000.0, rel=1e-6)

    def test_energy_endpoint_returns_a_waterfall(self):
        service = self.service()
        session = service.create_session()["session_id"]
        service.run(session, 1.0, 0.1)
        assert service.energy(session)["waterfall"]

    def test_events_endpoint_returns_a_list(self):
        service = self.service()
        session = service.create_session()["session_id"]
        service.step(session, 0.1)
        assert "events" in service.events(session)

    def test_reset_restores_the_session(self):
        service = self.service()
        session = service.create_session()["session_id"]
        service.run(session, 1.0, 0.1)
        service.reset(session)
        assert service.state(session)["time"] == pytest.approx(0.0)

    def test_delete_removes_the_session(self):
        service = self.service()
        session = service.create_session()["session_id"]
        service.delete_session(session)
        with pytest.raises(ServiceError):
            service.state(session)

    def test_sessions_are_listed(self):
        service = self.service()
        service.create_session()
        service.create_session()
        assert len(service.list_sessions()["sessions"]) == 2

    def test_oldest_session_is_evicted_at_capacity(self):
        service = EngineService(build_engine, max_sessions=2)
        first = service.create_session()["session_id"]
        service.create_session()
        service.create_session()
        with pytest.raises(ServiceError):
            service.state(first)

    def test_optimise_through_the_service(self):
        service = self.service()
        result = service.optimise(
            lambda v: {"power": 100.0 - (v["x"] - 2.0) ** 2, "x": v["x"]},
            [{"name": "x", "lower": -10.0, "upper": 10.0, "initial": 0.0}],
            "power")
        assert result["summary"]["variables"]["x"] == pytest.approx(2.0, abs=1e-3)

    def test_optimise_with_a_constraint(self):
        service = self.service()
        result = service.optimise(
            lambda v: {"power": 100.0 - (v["x"] - 5.0) ** 2, "x": v["x"]},
            [{"name": "x", "lower": -10.0, "upper": 10.0, "initial": 0.0}],
            "power", constraints=[{"key": "x", "bound": 2.0, "kind": "upper"}])
        assert result["summary"]["variables"]["x"] <= 2.0 + 1e-6

    def test_malformed_design_variable_is_reported(self):
        service = self.service()
        with pytest.raises(ServiceError):
            service.optimise(lambda v: {"power": 0.0}, [{"name": "x"}], "power")

    def test_malformed_constraint_is_reported(self):
        service = self.service()
        with pytest.raises(ServiceError):
            service.optimise(
                lambda v: {"power": 0.0},
                [{"name": "x", "lower": 0.0, "upper": 1.0}], "power",
                constraints=[{"key": "x"}])


class TestJsonEncoding:
    def test_infinity_is_encoded_as_a_string(self):
        assert json_safe(math.inf) == "Infinity"

    def test_negative_infinity(self):
        assert json_safe(-math.inf) == "-Infinity"

    def test_nan_is_encoded(self):
        assert json_safe(math.nan) == "NaN"

    def test_nested_structures_are_walked(self):
        payload = json_safe({"a": [1.0, math.inf], "b": {"c": math.nan}})
        assert payload["a"][1] == "Infinity" and payload["b"]["c"] == "NaN"

    def test_dumps_produces_valid_json(self):
        text = dumps({"a": math.inf, "b": 1.0})
        assert json.loads(text)["a"] == "Infinity"


class TestSimpleAPIServer:
    def server(self) -> SimpleAPIServer:
        return SimpleAPIServer(EngineService(build_engine))

    def test_health_route(self):
        status, payload = self.server().handle("GET", "/health")
        assert status == 200 and payload["status"] == "ok"

    def test_session_creation_route(self):
        status, payload = self.server().handle("POST", "/sessions")
        assert status == 201 and "session_id" in payload

    def test_unknown_route_is_404(self):
        status, _ = self.server().handle("GET", "/nowhere")
        assert status == 404

    def test_step_route(self):
        server = self.server()
        _, created = server.handle("POST", "/sessions")
        session = created["session_id"]
        status, payload = server.handle("POST", f"/sessions/{session}/step",
                                        {"dt": 0.1})
        assert status == 200 and payload["time"] == pytest.approx(0.1)

    def test_run_route(self):
        server = self.server()
        _, created = server.handle("POST", "/sessions")
        session = created["session_id"]
        status, payload = server.handle("POST", f"/sessions/{session}/run",
                                        {"duration": 1.0, "dt": 0.1})
        assert status == 200 and payload["summary"]["steps"] == 10

    def test_energy_route(self):
        server = self.server()
        _, created = server.handle("POST", "/sessions")
        session = created["session_id"]
        server.handle("POST", f"/sessions/{session}/run",
                      {"duration": 1.0, "dt": 0.1})
        status, payload = server.handle("GET", f"/sessions/{session}/energy")
        assert status == 200 and payload["summary"]["input"] > 0.0

    def test_delete_route(self):
        server = self.server()
        _, created = server.handle("POST", "/sessions")
        session = created["session_id"]
        status, _ = server.handle("DELETE", f"/sessions/{session}")
        assert status == 200

    def test_missing_session_route_is_404(self):
        status, _ = self.server().handle("GET", "/sessions/ghost/state")
        assert status == 404

    def test_bad_payload_is_a_400(self):
        server = self.server()
        _, created = server.handle("POST", "/sessions")
        session = created["session_id"]
        status, _ = server.handle("POST", f"/sessions/{session}/step",
                                  {"dt": "quickly"})
        assert status == 400


class TestBroadcaster:
    def test_publish_reaches_subscribers(self):
        broadcaster = TelemetryBroadcaster(StreamConfig(interval=0.0))
        recorder = RecordingSubscriber()
        broadcaster.subscribe(recorder)
        broadcaster.publish(build_engine(), force=True)
        assert len(recorder) == 1

    def test_interval_throttles_publication(self):
        broadcaster = TelemetryBroadcaster(StreamConfig(interval=1.0))
        recorder = RecordingSubscriber()
        broadcaster.subscribe(recorder)
        engine = build_engine()
        broadcaster.publish(engine, force=True)
        engine.step(0.1)
        assert broadcaster.publish(engine) is None

    def test_message_carries_the_state(self):
        broadcaster = TelemetryBroadcaster(StreamConfig(interval=0.0))
        message = broadcaster.publish(build_engine(), force=True)
        assert "temperature" in message and "severity" in message

    def test_energy_can_be_included(self):
        broadcaster = TelemetryBroadcaster(
            StreamConfig(interval=0.0, include_energy=True))
        message = broadcaster.publish(build_engine(), force=True)
        assert "energy" in message

    def test_a_failing_subscriber_is_removed_not_fatal(self):
        broadcaster = TelemetryBroadcaster(StreamConfig(interval=0.0))

        def broken(message):
            raise RuntimeError("consumer died")

        broadcaster.subscribe(broken)
        good = RecordingSubscriber()
        broadcaster.subscribe(good)
        broadcaster.publish(build_engine(), force=True)
        assert broadcaster.failed and len(good) == 1

    def test_unsubscribe_stops_delivery(self):
        broadcaster = TelemetryBroadcaster(StreamConfig(interval=0.0))
        recorder = RecordingSubscriber()
        broadcaster.subscribe(recorder)
        broadcaster.unsubscribe(recorder)
        broadcaster.publish(build_engine(), force=True)
        assert len(recorder) == 0

    def test_json_publication_is_parseable(self):
        broadcaster = TelemetryBroadcaster(StreamConfig(interval=0.0))
        text = broadcaster.publish_json(build_engine(), force=True)
        assert json.loads(text)["temperature"] > 0.0

    def test_websocket_adapter_sends_json(self):
        sent = []
        subscriber = websocket_adapter(sent.append)
        subscriber({"a": 1.0})
        assert json.loads(sent[0])["a"] == 1.0

    def test_recording_subscriber_is_bounded(self):
        recorder = RecordingSubscriber(capacity=3)
        for i in range(10):
            recorder({"i": float(i)})
        assert len(recorder) == 3

    def test_recording_subscriber_series(self):
        recorder = RecordingSubscriber()
        for i in range(5):
            recorder({"i": float(i)})
        assert recorder.series("i") == [0.0, 1.0, 2.0, 3.0, 4.0]

    def test_zero_interval_is_rejected(self):
        with pytest.raises(ValueError):
            StreamConfig(interval=-1.0)


class TestVisualisation:
    def test_sparkline_length_matches_the_data(self):
        assert len(sparkline([1.0, 2.0, 3.0, 4.0])) == 4

    def test_sparkline_of_a_flat_series_is_uniform(self):
        line = sparkline([5.0] * 6)
        assert len(set(line)) == 1

    def test_sparkline_of_nothing_is_empty(self):
        assert sparkline([]) == ""

    def test_sparkline_downsamples_long_series(self):
        assert len(sparkline(list(range(1000)), width=20)) == 20

    def test_bar_is_full_at_the_maximum(self):
        assert bar(10.0, 10.0, width=10) == "█" * 10

    def test_bar_is_empty_at_zero(self):
        assert bar(0.0, 10.0, width=10) == "·" * 10

    def test_format_energy_uses_prefixes(self):
        assert "MJ" in format_energy(5e6)
        assert "kJ" in format_energy(5e3)
        assert "J" in format_energy(5.0)

    def test_format_power_uses_prefixes(self):
        assert "kW" in format_power(5e3)
        assert "MW" in format_power(5e6)

    def test_waterfall_lists_every_row(self):
        text = energy_waterfall([("input", 1000.0), ("loss", 300.0)])
        assert "input" in text and "loss" in text

    def test_waterfall_of_nothing_says_so(self):
        assert "no energy" in energy_waterfall([])

    def test_ledger_report_includes_the_efficiency(self):
        engine = build_engine()
        engine.run(1.0, 0.1)
        assert "efficiency" in ledger_report(engine.ledger)

    def test_table_renders_rows(self):
        text = table([{"a": 1.0, "b": 2.0}, {"a": 3.0, "b": 4.0}])
        assert "a" in text and "3" in text

    def test_table_of_nothing_says_so(self):
        assert table([]) == "(no rows)"

    def test_table_truncates_long_input(self):
        rows = [{"a": float(i)} for i in range(100)]
        assert "more rows" in table(rows, limit=10)

    def test_operating_map_marks_missing_cells(self):
        grid = [[1.0, math.nan], [2.0, 3.0]]
        assert "?" in operating_map_text([0.0, 1.0], [0.0, 1.0], grid)

    def test_operating_map_of_nothing_says_so(self):
        assert "no finite" in operating_map_text([0.0], [0.0], [[math.nan]])

    def test_severity_timeline_renders(self):
        assert "FAULT" in severity_timeline([(0.0, "NORMAL"), (1.0, "FAULT")])

    def test_severity_timeline_of_nothing_says_so(self):
        assert "no state changes" in severity_timeline([])

    def test_plot_availability_is_reported(self):
        assert isinstance(plots.available(), bool)

    def test_plots_write_a_file_when_matplotlib_is_present(self):
        if not plots.available():
            pytest.skip("matplotlib is not installed")
        with tempfile.TemporaryDirectory() as directory:
            path = os.path.join(directory, "plot.png")
            plots.plot_series([0.0, 1.0, 2.0], {"x": [1.0, 2.0, 3.0]}, path)
            assert os.path.getsize(path) > 0
