"""Assembled systems: generators, engines, hybrids, heaters and recovery."""
from __future__ import annotations

import math

import pytest

from electrocombustion.combustion import DIESEL, METHANE
from electrocombustion.materials import KANTHAL, NICHROME
from electrocombustion.mechanical import FrictionModel
from electrocombustion.systems import (
    CombustionEngine, CycleModel, ElectricHeaterSystem, EngineSpec, Generator,
    GeneratorSpec, HeaterSpec, HybridController, RecoverySpec, SourceSpec,
    WasteHeatRecovery,
)


class TestGenerator:
    def test_output_is_below_shaft_input(self, genset):
        assert genset.electrical_power(40_000.0, 157.08) < 40_000.0

    def test_efficiency_is_high_at_rated_load(self, genset):
        shaft = genset.shaft_power_for(50_000.0, 157.08)
        assert genset.efficiency(shaft, 157.08) > 0.9

    def test_efficiency_is_poor_at_light_load(self, genset):
        light = genset.shaft_power_for(5_000.0, 157.08)
        rated = genset.shaft_power_for(50_000.0, 157.08)
        assert (genset.efficiency(light, 157.08)
                < genset.efficiency(rated, 157.08))

    def test_efficiency_peaks_below_full_load(self, genset):
        curve = genset.efficiency_curve(points=20)
        best_fraction = max(curve, key=lambda row: row[1])[0]
        assert 0.5 <= best_fraction < 1.0

    def test_shaft_power_inverts_electrical_output(self, genset):
        shaft = genset.shaft_power_for(30_000.0, 157.08)
        assert genset.electrical_power(shaft, 157.08) == pytest.approx(
            30_000.0, rel=1e-6)

    def test_losses_split_into_named_components(self, genset):
        losses = genset.losses(40_000.0, 157.08)
        assert set(losses) >= {"copper", "iron", "windage", "total"}

    def test_copper_losses_scale_with_the_square_of_load(self, genset):
        half = genset.losses(25_000.0, 157.08)["copper"]
        full = genset.losses(50_000.0, 157.08)["copper"]
        assert full == pytest.approx(4.0 * half, rel=1e-9)

    def test_windage_scales_with_the_cube_of_speed(self, genset):
        slow = genset.losses(0.0, 78.54)["windage"]
        fast = genset.losses(0.0, 157.08)["windage"]
        assert fast == pytest.approx(8.0 * slow, rel=1e-9)

    def test_impossible_demand_is_reported(self, genset):
        with pytest.raises(ValueError):
            genset.shaft_power_for(5_000_000.0, 157.08)

    def test_terminal_current_is_positive(self, genset):
        assert genset.terminal_current(50_000.0) > 0.0

    def test_zero_rated_power_is_rejected(self):
        with pytest.raises(ValueError):
            Generator(GeneratorSpec(rated_power=0.0))


class TestCombustionEngine:
    def test_brake_power_is_below_chemical_input(self, diesel_engine):
        result = diesel_engine.evaluate(0.006, 157.08)
        assert result["brake_power"] < result["chemical_power"]

    def test_brake_efficiency_is_plausible_for_a_diesel(self, diesel_engine):
        result = diesel_engine.evaluate(0.006, 157.08)
        assert 0.30 < result["brake_efficiency"] < 0.50

    def test_bsfc_is_plausible(self, diesel_engine):
        assert 150.0 < diesel_engine.bsfc(0.006, 157.08) < 300.0

    def test_bsfc_is_infinite_without_output(self, diesel_engine):
        assert math.isinf(diesel_engine.bsfc(0.0, 157.08))

    def test_energy_balance_closes(self, diesel_engine):
        r = diesel_engine.evaluate(0.006, 157.08)
        accounted = (r["brake_power"] + r["friction_power"]
                     + r["rejected_power"] + r["unburned_power"])
        assert accounted == pytest.approx(r["chemical_power"], rel=1e-9)

    def test_fuel_for_power_inverts_the_model(self, diesel_engine):
        flow = diesel_engine.fuel_for_power(60_000.0, 157.08)
        assert diesel_engine.evaluate(flow, 157.08)["brake_power"] == (
            pytest.approx(60_000.0, rel=1e-5))

    def test_zero_target_needs_no_fuel(self, diesel_engine):
        assert diesel_engine.fuel_for_power(0.0, 157.08) == pytest.approx(0.0)

    def test_no_torque_below_the_minimum_speed(self, diesel_engine):
        assert diesel_engine.evaluate(0.006, 1.0)["torque"] == pytest.approx(0.0)

    def test_no_fuel_means_no_power(self, diesel_engine):
        assert diesel_engine.evaluate(0.0, 157.08)["brake_power"] == 0.0

    def test_more_fuel_gives_more_power(self, diesel_engine):
        low = diesel_engine.evaluate(0.003, 157.08)["brake_power"]
        high = diesel_engine.evaluate(0.006, 157.08)["brake_power"]
        assert high > low

    def test_efficiency_falls_at_very_light_load(self, diesel_engine):
        light = diesel_engine.evaluate(0.0005, 157.08)["indicated_efficiency"]
        heavy = diesel_engine.evaluate(0.006, 157.08)["indicated_efficiency"]
        assert light < heavy

    def test_operating_map_covers_the_grid(self, diesel_engine):
        rows = diesel_engine.operating_map([0.002, 0.004], [100.0, 157.0, 200.0])
        assert len(rows) == 6

    def test_rich_running_wastes_fuel(self, diesel_engine):
        lean = diesel_engine.evaluate(0.006, 157.08, 0.9)["brake_power"]
        rich = diesel_engine.evaluate(0.006, 157.08, 1.6)["brake_power"]
        assert rich < lean

    def test_a_spec_without_a_fuel_is_rejected(self):
        with pytest.raises(ValueError):
            EngineSpec(fuel=None)


class TestCycleModel:
    def test_otto_ideal_efficiency(self):
        model = CycleModel(kind="otto", compression_ratio=10.0, gamma=1.4)
        assert model.ideal_efficiency == pytest.approx(0.6019, rel=1e-3)

    def test_quality_derates_the_ideal(self):
        model = CycleModel(kind="otto", compression_ratio=10.0, gamma=1.4,
                           quality=0.75)
        assert model.indicated_efficiency == pytest.approx(
            0.75 * model.ideal_efficiency)

    def test_constant_cycle_returns_its_constant(self):
        model = CycleModel(kind="constant", constant_efficiency=0.4, quality=1.0)
        assert model.indicated_efficiency == pytest.approx(0.4)

    def test_unknown_cycle_is_rejected(self):
        with pytest.raises(ValueError):
            CycleModel(kind="wankel").ideal_efficiency

    def test_impossible_quality_is_rejected(self):
        with pytest.raises(ValueError):
            CycleModel(quality=1.5)

    def test_part_load_efficiency_is_lower(self):
        model = CycleModel()
        assert model.efficiency_at(0.05) < model.efficiency_at(1.0)

    def test_overspeed_efficiency_is_lower(self):
        model = CycleModel()
        assert model.efficiency_at(1.0, 2.5) < model.efficiency_at(1.0, 1.0)


class TestHybridController:
    def sources(self) -> list[SourceSpec]:
        return [SourceSpec("battery", 30_000.0, cost=0.4, efficiency=0.95),
                SourceSpec("genset", 80_000.0, cost=1.0, efficiency=0.33)]

    def test_dispatch_meets_the_demand(self):
        controller = HybridController(self.sources())
        allocation = controller.dispatch(60_000.0)
        assert sum(allocation.values()) == pytest.approx(60_000.0, rel=1e-6)

    def test_optimal_split_prefers_the_cheaper_source(self):
        controller = HybridController(self.sources(), "optimal_split")
        allocation = controller.dispatch(20_000.0)
        assert allocation["battery"] > allocation["genset"]

    def test_electric_priority_exhausts_the_first_source(self):
        controller = HybridController(self.sources(), "electric_priority")
        allocation = controller.dispatch(60_000.0)
        assert allocation["battery"] == pytest.approx(30_000.0)

    def test_fuel_priority_reverses_the_order(self):
        controller = HybridController(self.sources(), "fuel_priority")
        allocation = controller.dispatch(60_000.0)
        assert allocation["genset"] > allocation["battery"]

    def test_proportional_split_follows_capacity(self):
        controller = HybridController(self.sources(), "proportional")
        allocation = controller.dispatch(55_000.0)
        assert allocation["genset"] > allocation["battery"]

    def test_load_following_fills_the_sweet_spot_first(self):
        controller = HybridController(self.sources(), "load_following")
        allocation = controller.dispatch(15_000.0)
        assert allocation["battery"] == pytest.approx(15_000.0)

    def test_excess_demand_is_reported_as_unmet(self):
        controller = HybridController(self.sources())
        controller.dispatch(500_000.0)
        assert controller.unmet_demand(500_000.0) > 0.0

    def test_zero_demand_dispatches_nothing(self):
        controller = HybridController(self.sources())
        assert sum(controller.dispatch(0.0).values()) == pytest.approx(0.0)

    def test_unavailable_sources_are_skipped(self):
        sources = self.sources()
        sources[0].available = False
        controller = HybridController(sources)
        assert controller.dispatch(20_000.0)["battery"] == pytest.approx(0.0)

    def test_blended_efficiency_lies_between_the_sources(self):
        controller = HybridController(self.sources())
        controller.dispatch(60_000.0)
        assert 0.33 <= controller.blended_efficiency() <= 0.95

    def test_ramp_limits_restrict_a_step_change(self):
        sources = [SourceSpec("slow", 50_000.0, ramp_rate=1000.0),
                   SourceSpec("fast", 50_000.0)]
        controller = HybridController(sources, "electric_priority")
        controller.dispatch(40_000.0, dt=1.0)
        assert controller.last_dispatch["slow"] <= 1000.0 + 1e-6

    def test_total_cost_rises_with_demand(self):
        controller = HybridController(self.sources())
        cheap = controller.total_cost(controller.dispatch(10_000.0))
        dear = controller.total_cost(controller.dispatch(80_000.0))
        assert dear > cheap

    def test_an_empty_source_list_is_rejected(self):
        with pytest.raises(ValueError):
            HybridController([])

    def test_zero_capacity_is_rejected(self):
        with pytest.raises(ValueError):
            SourceSpec("bad", 0.0)


class TestHeaterSystem:
    def build(self) -> ElectricHeaterSystem:
        return ElectricHeaterSystem(
            HeaterSpec(material=NICHROME, length=8.0, diameter=1.2e-3,
                       supply_voltage=230.0))

    def test_cold_power_is_positive(self):
        assert self.build().spec.cold_power() > 0.0

    def test_steady_temperature_is_above_ambient(self):
        system = self.build()
        assert system.steady_temperature() > system.ambient

    def test_steady_state_balances_input_and_loss(self):
        system = self.build()
        t = system.steady_temperature()
        assert system.electrical_power(t) == pytest.approx(system.loss(t),
                                                           abs=1e-3)

    def test_lower_duty_gives_a_lower_temperature(self):
        system = self.build()
        assert system.steady_temperature(0.3) < system.steady_temperature(1.0)

    def test_duty_for_temperature_inverts(self):
        system = self.build()
        duty = system.duty_for_temperature(900.0)
        assert system.steady_temperature(duty) == pytest.approx(900.0, rel=1e-3)

    def test_power_falls_as_resistance_rises(self):
        system = self.build()
        assert system.electrical_power(1200.0) < system.electrical_power(300.0)

    def test_length_for_power_is_a_closed_form(self):
        spec = HeaterSpec(material=NICHROME, diameter=1e-3,
                          supply_voltage=230.0)
        length = spec.length_for_power(5000.0)
        sized = HeaterSpec(material=NICHROME, length=length, diameter=1e-3,
                           supply_voltage=230.0)
        assert sized.cold_power() == pytest.approx(5000.0, rel=1e-6)

    def test_service_limit_detection(self):
        system = self.build()
        assert system.exceeds_service_limit(3000.0)

    def test_a_spec_without_a_material_is_rejected(self):
        with pytest.raises(ValueError):
            HeaterSpec(material=None)

    def test_zero_target_power_is_rejected(self):
        spec = HeaterSpec(material=KANTHAL)
        with pytest.raises(ValueError):
            spec.length_for_power(0.0)


class TestWasteHeatRecovery:
    def test_efficiency_is_zero_below_the_threshold(self):
        recovery = WasteHeatRecovery(
            RecoverySpec(minimum_source_temperature=400.0))
        assert recovery.conversion_efficiency(350.0) == pytest.approx(0.0)

    def test_efficiency_rises_with_source_temperature(self):
        recovery = WasteHeatRecovery()
        assert (recovery.conversion_efficiency(800.0)
                > recovery.conversion_efficiency(500.0))

    def test_efficiency_stays_below_carnot(self):
        recovery = WasteHeatRecovery(RecoverySpec(carnot_fraction=0.55))
        result = recovery.breakdown(50_000.0, 650.0)
        assert result["efficiency"] < result["carnot_limit"]

    def test_orc_efficiency_is_plausible(self):
        recovery = WasteHeatRecovery(RecoverySpec(kind="orc",
                                                  carnot_fraction=0.55))
        assert 0.2 < recovery.conversion_efficiency(650.0) < 0.35

    def test_recuperator_produces_no_electricity(self):
        recovery = WasteHeatRecovery(RecoverySpec(kind="recuperator"))
        assert recovery.conversion_efficiency(800.0) == pytest.approx(0.0)

    def test_parasitics_are_subtracted(self):
        with_pump = WasteHeatRecovery(RecoverySpec(parasitic_power=500.0))
        without = WasteHeatRecovery(RecoverySpec(parasitic_power=0.0))
        assert with_pump.power(50_000.0, 650.0) < without.power(50_000.0, 650.0)

    def test_net_power_never_goes_negative(self):
        recovery = WasteHeatRecovery(RecoverySpec(parasitic_power=1e9))
        assert recovery.power(1000.0, 650.0) == pytest.approx(0.0)

    def test_captured_heat_is_capped(self):
        recovery = WasteHeatRecovery(RecoverySpec(maximum_heat=10_000.0))
        assert recovery.heat_captured(50_000.0, 650.0) == pytest.approx(10_000.0)

    def test_breakdown_conserves_the_captured_heat(self):
        recovery = WasteHeatRecovery()
        r = recovery.breakdown(50_000.0, 650.0)
        assert r["gross_power"] + r["rejected"] == pytest.approx(r["captured"],
                                                                 rel=1e-9)

    def test_payback_temperature_is_finite_for_a_modest_parasitic(self):
        recovery = WasteHeatRecovery(RecoverySpec(parasitic_power=500.0))
        assert math.isfinite(recovery.payback_temperature())

    def test_below_payback_the_device_produces_nothing(self):
        recovery = WasteHeatRecovery(RecoverySpec(parasitic_power=500.0))
        payback = recovery.payback_temperature()
        assert recovery.power(recovery.spec.maximum_heat, payback - 1.0) == (
            pytest.approx(0.0))

    def test_impossible_carnot_fraction_is_rejected(self):
        with pytest.raises(ValueError):
            RecoverySpec(carnot_fraction=1.5)
