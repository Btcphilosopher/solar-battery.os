"""Severity, thresholds and the event bus."""
from __future__ import annotations

import math

import pytest

from electrocombustion.core.events import Event, EventBus, Severity, Threshold


class TestSeverity:
    def test_ordering(self):
        order = [Severity.NORMAL, Severity.WARNING, Severity.LIMIT,
                 Severity.FAULT]
        assert Severity.worst(order) is Severity.FAULT

    def test_worst_of_empty_is_normal(self):
        assert Severity.worst([]) is Severity.NORMAL

    def test_worst_picks_the_highest(self):
        assert Severity.worst([Severity.NORMAL, Severity.LIMIT,
                               Severity.WARNING]) is Severity.LIMIT

    def test_values_are_strings(self):
        assert Severity.FAULT.value == "FAULT"


class TestThreshold:
    def test_upper_classification(self):
        t = Threshold("T", warning=80.0, limit=90.0, fault=100.0,
                      direction="upper")
        assert t.classify(50.0) is Severity.NORMAL
        assert t.classify(85.0) is Severity.WARNING
        assert t.classify(95.0) is Severity.LIMIT
        assert t.classify(105.0) is Severity.FAULT

    def test_lower_classification(self):
        t = Threshold("T", warning=20.0, limit=10.0, fault=5.0,
                      direction="lower")
        assert t.classify(50.0) is Severity.NORMAL
        assert t.classify(15.0) is Severity.WARNING
        assert t.classify(8.0) is Severity.LIMIT
        assert t.classify(1.0) is Severity.FAULT

    def test_exact_boundary_is_inclusive(self):
        t = Threshold("T", warning=80.0, direction="upper")
        assert t.classify(80.0) is Severity.WARNING

    def test_margin_is_positive_when_safe(self):
        t = Threshold("T", limit=100.0, direction="upper")
        assert t.margin(60.0) == pytest.approx(40.0)

    def test_margin_is_negative_when_breached(self):
        t = Threshold("T", limit=100.0, direction="upper")
        assert t.margin(130.0) == pytest.approx(-30.0)

    def test_non_monotonic_upper_levels_are_rejected(self):
        with pytest.raises(ValueError):
            Threshold("T", warning=100.0, limit=90.0, direction="upper")

    def test_non_monotonic_lower_levels_are_rejected(self):
        with pytest.raises(ValueError):
            Threshold("T", warning=10.0, limit=20.0, direction="lower")

    def test_unknown_direction_is_rejected(self):
        with pytest.raises(ValueError):
            Threshold("T", limit=1.0, direction="sideways")

    def test_partial_levels_are_allowed(self):
        t = Threshold("T", fault=100.0, direction="upper")
        assert t.classify(50.0) is Severity.NORMAL
        assert t.classify(120.0) is Severity.FAULT

    def test_margin_without_levels_is_infinite(self):
        t = Threshold("T", direction="upper")
        assert math.isinf(t.margin(1.0))


class TestEventBus:
    def test_publish_records_history(self):
        bus = EventBus()
        bus.publish(1.0, "test", "something happened", Severity.WARNING, "c")
        assert len(bus.history) == 1

    def test_worst_severity_across_events(self):
        bus = EventBus()
        bus.publish(0.0, "a", "", Severity.WARNING)
        bus.publish(1.0, "b", "", Severity.FAULT)
        assert bus.worst_severity() is Severity.FAULT

    def test_subscribers_are_notified_by_kind(self):
        bus = EventBus()
        seen = []
        bus.subscribe("a", seen.append)
        bus.publish(0.0, "a", "msg", Severity.LIMIT)
        assert len(seen) == 1
        assert seen[0].kind == "a"

    def test_subscribers_only_hear_their_own_kind(self):
        bus = EventBus()
        seen = []
        bus.subscribe("a", seen.append)
        bus.publish(0.0, "b", "msg", Severity.LIMIT)
        assert not seen

    def test_unsubscribe_stops_delivery(self):
        bus = EventBus()
        seen = []
        cancel = bus.subscribe("a", seen.append)
        cancel()
        bus.publish(0.0, "a", "msg", Severity.LIMIT)
        assert not seen

    def test_filter_by_severity(self):
        bus = EventBus()
        bus.publish(0.0, "a", "", Severity.WARNING)
        bus.publish(1.0, "b", "", Severity.FAULT)
        assert len(bus.filter(min_severity=Severity.FAULT)) == 1

    def test_filter_by_kind(self):
        bus = EventBus()
        bus.publish(0.0, "a", "", Severity.WARNING)
        bus.publish(1.0, "b", "", Severity.WARNING)
        assert len(bus.filter(kind="a")) == 1

    def test_filter_by_source(self):
        bus = EventBus()
        bus.publish(0.0, "a", "", Severity.WARNING, "heater")
        bus.publish(1.0, "a", "", Severity.WARNING, "pump")
        assert len(bus.filter(source="pump")) == 1

    def test_clear_resets_history(self):
        bus = EventBus()
        bus.publish(0.0, "a", "", Severity.WARNING)
        bus.clear()
        assert not bus.history
        assert bus.worst_severity() is Severity.NORMAL

    def test_event_carries_its_severity(self):
        event = Event(1.5, "kind", "message", Severity.LIMIT, "component")
        assert event.severity is Severity.LIMIT
        assert event.time == pytest.approx(1.5)

    def test_history_is_capped(self):
        bus = EventBus(history_limit=5)
        for i in range(20):
            bus.publish(float(i), "k", "", Severity.NORMAL)
        assert len(bus.history) <= 5
