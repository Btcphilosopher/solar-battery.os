"""Solvers, scenarios, sweeps and Monte Carlo studies."""
from __future__ import annotations

import math
import os
import tempfile

import numpy as np
import pytest

from electrocombustion.core.engine import ElectroCombustionEngine, EngineConfig
from electrocombustion.core.state import SystemState
from electrocombustion.mechanical import TorqueSource
from electrocombustion.simulation import (
    Distribution, MonteCarlo, Parameter, ParameterSweep, Scenario, Segment,
    SteadyStateSolver, SweepResult, TransientSolver, duty_cycle_scenario,
    euler_step, find_optimum, heun_step, implicit_euler_step, operating_map,
    ramp_scenario, recommend_method, rk4_step, step_scenario, stiffness_ratio,
)


def decay(t, y):
    return -2.0 * y


ANALYTIC_AT_2 = math.exp(-4.0)


class TestSteppers:
    def test_euler_step_formula(self):
        y = euler_step(decay, 0.0, np.array([1.0]), 0.1)
        assert y[0] == pytest.approx(0.8)

    def test_heun_is_more_accurate_than_euler(self):
        e = abs(euler_step(decay, 0.0, np.array([1.0]), 0.1)[0] - math.exp(-0.2))
        h = abs(heun_step(decay, 0.0, np.array([1.0]), 0.1)[0] - math.exp(-0.2))
        assert h < e

    def test_rk4_is_more_accurate_than_heun(self):
        h = abs(heun_step(decay, 0.0, np.array([1.0]), 0.1)[0] - math.exp(-0.2))
        r = abs(rk4_step(decay, 0.0, np.array([1.0]), 0.1)[0] - math.exp(-0.2))
        assert r < h

    def test_implicit_euler_is_stable_at_a_large_step(self):
        y = implicit_euler_step(lambda t, v: -1000.0 * v, 0.0, np.array([1.0]),
                                1.0)
        assert abs(y[0]) < 1.0


class TestTransientSolver:
    def test_rk4_matches_the_analytic_solution(self):
        result = TransientSolver("rk4").integrate(decay, [1.0], (0.0, 2.0), 0.01)
        assert result.final[0] == pytest.approx(ANALYTIC_AT_2, abs=1e-9)

    def test_adaptive_matches_the_analytic_solution(self):
        result = TransientSolver("rk4").adaptive(decay, [1.0], (0.0, 2.0), 0.01)
        assert result.final[0] == pytest.approx(ANALYTIC_AT_2, abs=1e-6)

    def test_adaptive_uses_fewer_steps_than_the_fixed_grid(self):
        fixed = TransientSolver("rk4").integrate(decay, [1.0], (0.0, 2.0), 0.01)
        adaptive = TransientSolver("rk4").adaptive(decay, [1.0], (0.0, 2.0), 0.01)
        assert adaptive.steps < fixed.steps

    def test_scipy_backend_matches_the_analytic_solution(self):
        result = TransientSolver("scipy").integrate(decay, [1.0], (0.0, 2.0),
                                                    0.01)
        assert result.final[0] == pytest.approx(ANALYTIC_AT_2, abs=1e-6)

    def test_implicit_euler_converges_with_a_fine_step(self):
        result = TransientSolver("implicit_euler").integrate(
            decay, [1.0], (0.0, 2.0), 0.001)
        assert result.final[0] == pytest.approx(ANALYTIC_AT_2, abs=1e-3)

    def test_unknown_method_is_rejected(self):
        with pytest.raises(ValueError):
            TransientSolver("crystal_ball")

    def test_backwards_time_span_is_rejected(self):
        with pytest.raises(ValueError):
            TransientSolver("rk4").integrate(decay, [1.0], (2.0, 0.0), 0.01)

    def test_zero_timestep_is_rejected(self):
        with pytest.raises(ValueError):
            TransientSolver("rk4").integrate(decay, [1.0], (0.0, 1.0), 0.0)

    def test_interpolation_between_samples(self):
        result = TransientSolver("rk4").integrate(decay, [1.0], (0.0, 2.0), 0.1)
        assert result.interpolate(1.0)[0] == pytest.approx(math.exp(-2.0),
                                                           rel=1e-3)

    def test_interpolation_clamps_outside_the_range(self):
        result = TransientSolver("rk4").integrate(decay, [1.0], (0.0, 2.0), 0.1)
        assert result.interpolate(-5.0)[0] == pytest.approx(1.0)

    def test_column_extracts_one_state(self):
        result = TransientSolver("rk4").integrate(
            lambda t, y: np.array([-y[0], -2.0 * y[1]]), [1.0, 1.0],
            (0.0, 1.0), 0.01)
        assert len(result.column(1)) == len(result.times)

    def test_two_state_system_integrates_independently(self):
        result = TransientSolver("rk4").integrate(
            lambda t, y: np.array([-y[0], -2.0 * y[1]]), [1.0, 1.0],
            (0.0, 1.0), 0.001)
        assert result.final[0] == pytest.approx(math.exp(-1.0), abs=1e-9)
        assert result.final[1] == pytest.approx(math.exp(-2.0), abs=1e-9)


class TestSteadyStateSolver:
    def test_scalar_root(self):
        x, ok, _ = SteadyStateSolver().solve(
            lambda y: np.array([y[0] ** 2 - 4.0]), [1.0])
        assert ok and x[0] == pytest.approx(2.0)

    def test_two_dimensional_root(self):
        def residual(y):
            return np.array([y[0] + y[1] - 3.0, y[0] - y[1] - 1.0])

        x, ok, _ = SteadyStateSolver().solve(residual, [0.0, 0.0])
        assert x[0] == pytest.approx(2.0) and x[1] == pytest.approx(1.0)

    def test_pure_python_newton_also_converges(self):
        x, ok, _ = SteadyStateSolver().solve(
            lambda y: np.array([y[0] ** 2 - 9.0]), [1.0], use_scipy=False)
        assert ok and x[0] == pytest.approx(3.0, rel=1e-6)

    def test_damping_must_be_in_range(self):
        with pytest.raises(ValueError):
            SteadyStateSolver(damping=1.5)

    def test_radiation_like_nonlinearity_converges_with_damping(self):
        def residual(y):
            return np.array([1000.0 - 5.67e-8 * 0.9 * (y[0] ** 4 - 300.0 ** 4)])

        x, ok, _ = SteadyStateSolver(damping=0.5).solve(residual, [500.0],
                                                        use_scipy=False)
        assert ok and x[0] > 300.0


class TestStiffness:
    def test_ratio_of_a_well_conditioned_system(self):
        assert stiffness_ratio(np.diag([-1.0, -2.0])) == pytest.approx(2.0)

    def test_ratio_of_a_stiff_system(self):
        assert stiffness_ratio(np.diag([-1.0, -1e6])) == pytest.approx(1e6)

    def test_recommend_implicit_for_stiff_systems(self):
        assert recommend_method(np.diag([-1.0, -1e6])) == "implicit_euler"

    def test_recommend_explicit_for_mild_systems(self):
        assert recommend_method(np.diag([-1.0, -2.0])) == "rk4"


class TestScenarios:
    def engine(self) -> ElectroCombustionEngine:
        state = SystemState()
        state.mechanical.inertia = 2.0
        engine = ElectroCombustionEngine(state,
                                         config=EngineConfig(scheme="rk4"))
        engine.add(TorqueSource("src", input_key="src.torque"))
        return engine

    def test_segment_duration_must_be_positive(self):
        with pytest.raises(ValueError):
            Segment("bad", 0.0)

    def test_segment_holds_its_value(self):
        segment = Segment("hold", 10.0, {"x": 5.0})
        assert segment.value_at("x", 5.0) == pytest.approx(5.0)

    def test_segment_ramps_linearly(self):
        segment = Segment("ramp", 10.0, {"x": 10.0}, ramp_from={"x": 0.0})
        assert segment.value_at("x", 5.0) == pytest.approx(5.0)

    def test_scenario_duration_sums_segments(self):
        scenario = Scenario("s").add("a", 5.0).add("b", 10.0)
        assert scenario.duration == pytest.approx(15.0)

    def test_scenario_inputs_change_between_segments(self):
        scenario = (Scenario("s").add("a", 5.0, x=1.0).add("b", 5.0, x=2.0))
        assert scenario.inputs_at(1.0)["x"] == pytest.approx(1.0)
        assert scenario.inputs_at(7.0)["x"] == pytest.approx(2.0)

    def test_step_scenario_has_two_segments(self):
        scenario = step_scenario("s", "x", 0.0, 1.0)
        assert len(scenario.segments) == 2

    def test_ramp_scenario_includes_a_settle(self):
        scenario = ramp_scenario("s", "x", 0.0, 1.0, settle=5.0)
        assert len(scenario.segments) == 2

    def test_duty_cycle_scenario_segment_count(self):
        scenario = duty_cycle_scenario("s", "x", 1.0, 0.0, 10.0, cycles=3)
        assert len(scenario.segments) == 6

    def test_duty_cycle_rejects_an_impossible_duty(self):
        with pytest.raises(ValueError):
            duty_cycle_scenario("s", "x", 1.0, 0.0, 10.0, duty=1.5)

    def test_running_a_scenario_advances_the_engine(self):
        engine = self.engine()
        scenario = step_scenario("s", "src.torque", 0.0, 10.0, hold=1.0, dt=0.01)
        scenario.run(engine)
        assert engine.state.time == pytest.approx(2.0, rel=1e-6)

    def test_scenario_result_reports_each_segment(self):
        engine = self.engine()
        result = step_scenario("s", "src.torque", 0.0, 10.0, hold=1.0,
                               dt=0.01).run(engine)
        assert len(result.segments) == 2

    def test_scenario_segment_lookup(self):
        engine = self.engine()
        result = step_scenario("s", "src.torque", 0.0, 10.0, hold=1.0,
                               dt=0.01).run(engine)
        assert result.segment("after")["t_end"] > result.segment("before")["t_end"]

    def test_unknown_segment_lookup_raises(self):
        engine = self.engine()
        result = step_scenario("s", "src.torque", 0.0, 10.0, hold=1.0,
                               dt=0.01).run(engine)
        with pytest.raises(KeyError):
            result.segment("nowhere")

    def test_scenario_summary_reports_energy(self):
        engine = self.engine()
        result = step_scenario("s", "src.torque", 0.0, 10.0, hold=1.0,
                               dt=0.01).run(engine)
        assert result.summary()["energy_in"] > 0.0


class TestSweeps:
    def model(self, point):
        return {"y": point["a"] ** 2 + point["b"]}

    def test_linear_parameter_endpoints(self):
        parameter = Parameter.linear("a", 0.0, 10.0, 11)
        assert parameter.values[0] == pytest.approx(0.0)
        assert parameter.values[-1] == pytest.approx(10.0)

    def test_logarithmic_parameter_spans_decades(self):
        parameter = Parameter.logarithmic("a", 1.0, 1000.0, 4)
        assert parameter.values[1] == pytest.approx(10.0)

    def test_logarithmic_rejects_non_positive_bounds(self):
        with pytest.raises(ValueError):
            Parameter.logarithmic("a", 0.0, 10.0, 3)

    def test_empty_parameter_is_rejected(self):
        with pytest.raises(ValueError):
            Parameter("a", [])

    def test_sweep_size_is_the_product(self):
        sweep = ParameterSweep(self.model,
                               [Parameter.linear("a", 0.0, 1.0, 5),
                                Parameter.linear("b", 0.0, 1.0, 4)])
        assert sweep.size == 20

    def test_sweep_produces_every_point(self):
        sweep = ParameterSweep(self.model,
                               [Parameter.linear("a", 0.0, 1.0, 5),
                                Parameter.linear("b", 0.0, 1.0, 4)])
        assert len(sweep.run()) == 20

    def test_sweep_is_deterministic(self):
        sweep = ParameterSweep(self.model, [Parameter.linear("a", 0.0, 1.0, 5),
                                            Parameter.linear("b", 0.0, 1.0, 4)])
        first = sweep.run().column("y")
        second = sweep.run().column("y")
        assert first == second

    def test_failures_are_captured_not_fatal(self):
        def flaky(point):
            if point["a"] > 0.5:
                raise RuntimeError("no convergence")
            return {"y": point["a"]}

        sweep = ParameterSweep(flaky, [Parameter.linear("a", 0.0, 1.0, 5)])
        result = sweep.run()
        assert result.failures and len(result.rows) < 5

    def test_stop_on_error_propagates(self):
        def flaky(point):
            raise RuntimeError("boom")

        sweep = ParameterSweep(flaky, [Parameter.linear("a", 0.0, 1.0, 3)])
        with pytest.raises(RuntimeError):
            sweep.run(stop_on_error=True)

    def test_best_finds_the_maximum(self):
        sweep = ParameterSweep(self.model, [Parameter.linear("a", 0.0, 4.0, 5),
                                            Parameter.linear("b", 0.0, 1.0, 2)])
        assert sweep.run().best("y")["a"] == pytest.approx(4.0)

    def test_best_can_minimise(self):
        sweep = ParameterSweep(self.model, [Parameter.linear("a", 0.0, 4.0, 5),
                                            Parameter.linear("b", 0.0, 1.0, 2)])
        assert sweep.run().best("y", maximise=False)["a"] == pytest.approx(0.0)

    def test_best_on_an_empty_sweep_raises(self):
        with pytest.raises(ValueError):
            SweepResult(["a"]).best("y")

    def test_to_grid_reshapes(self):
        result = operating_map(self.model, Parameter.linear("a", 0.0, 1.0, 3),
                               Parameter.linear("b", 0.0, 1.0, 4))
        xs, ys, grid = result.to_grid("a", "b", "y")
        assert grid.shape == (4, 3)

    def test_to_grid_marks_missing_points_as_nan(self):
        result = SweepResult(["a", "b"])
        result.rows.append({"a": 0.0, "b": 0.0, "y": 1.0})
        result.rows.append({"a": 1.0, "b": 1.0, "y": 2.0})
        _, _, grid = result.to_grid("a", "b", "y")
        assert math.isnan(grid[0][1])

    def test_csv_export_round_trips(self):
        result = operating_map(self.model, Parameter.linear("a", 0.0, 1.0, 3),
                               Parameter.linear("b", 0.0, 1.0, 2))
        with tempfile.TemporaryDirectory() as directory:
            path = os.path.join(directory, "sweep.csv")
            result.to_csv(path)
            with open(path, encoding="utf-8") as handle:
                lines = handle.readlines()
        assert len(lines) == 7

    def test_csv_export_of_nothing_raises(self):
        with pytest.raises(ValueError):
            SweepResult(["a"]).to_csv("/tmp/never-written.csv")

    def test_latin_hypercube_covers_the_range(self):
        sweep = ParameterSweep(self.model, [Parameter.linear("a", 0.0, 10.0, 2),
                                            Parameter.linear("b", 0.0, 5.0, 2)])
        result = sweep.latin_hypercube(50, seed=0)
        values = result.column("a")
        assert len(values) == 50
        assert max(values) - min(values) > 5.0

    def test_latin_hypercube_is_reproducible(self):
        sweep = ParameterSweep(self.model, [Parameter.linear("a", 0.0, 10.0, 2)])
        assert (sweep.latin_hypercube(20, seed=7).column("a")
                == sweep.latin_hypercube(20, seed=7).column("a"))

    def test_find_optimum_respects_constraints(self):
        result = operating_map(self.model, Parameter.linear("a", 0.0, 4.0, 5),
                               Parameter.linear("b", 0.0, 1.0, 2))
        best = find_optimum(result, "y", constraints={"a": (0.0, 2.0)})
        assert best["a"] <= 2.0

    def test_find_optimum_raises_when_nothing_qualifies(self):
        result = operating_map(self.model, Parameter.linear("a", 0.0, 4.0, 5),
                               Parameter.linear("b", 0.0, 1.0, 2))
        with pytest.raises(ValueError):
            find_optimum(result, "y", constraints={"a": (100.0, 200.0)})

    def test_a_thousand_point_sweep_completes(self):
        """Section 17 of the specification asks for thousand-run sweeps."""
        sweep = ParameterSweep(self.model,
                               [Parameter.linear("a", 0.0, 10.0, 40),
                                Parameter.linear("b", 0.0, 10.0, 25)])
        assert len(sweep.run()) == 1000


class TestMonteCarlo:
    def model(self, point):
        return {"y": 2.0 * point["a"] + point["b"]}

    def distributions(self):
        return [Distribution("a", "normal", 10.0, 1.0),
                Distribution("b", "uniform", 0.0, 4.0)]

    def test_normal_mean_is_recovered(self):
        study = MonteCarlo(self.model, self.distributions(), seed=0)
        stats = study.run(2000).statistics("y")
        assert stats["mean"] == pytest.approx(22.0, rel=0.02)

    def test_percentile_band_is_ordered(self):
        study = MonteCarlo(self.model, self.distributions(), seed=0)
        stats = study.run(1000).statistics("y")
        assert stats["p10"] < stats["p50"] < stats["p90"]

    def test_results_are_reproducible(self):
        first = MonteCarlo(self.model, self.distributions(), seed=3).run(200)
        second = MonteCarlo(self.model, self.distributions(), seed=3).run(200)
        assert first.values("y").tolist() == second.values("y").tolist()

    def test_different_seeds_give_different_samples(self):
        first = MonteCarlo(self.model, self.distributions(), seed=1).run(200)
        second = MonteCarlo(self.model, self.distributions(), seed=2).run(200)
        assert first.values("y").tolist() != second.values("y").tolist()

    def test_sensitivity_ranks_the_dominant_input(self):
        study = MonteCarlo(self.model, self.distributions(), seed=0)
        result = study.run(1000)
        assert result.sensitivity("y")["a"] > result.sensitivity("y")["b"]

    def test_probability_of_exceeding_a_threshold(self):
        study = MonteCarlo(self.model, self.distributions(), seed=0)
        result = study.run(2000)
        assert 0.0 < result.probability("y", 22.0) < 1.0

    def test_nominal_evaluates_at_the_central_values(self):
        study = MonteCarlo(self.model, self.distributions(), seed=0)
        assert study.nominal()["y"] == pytest.approx(22.0)

    def test_truncation_bounds_are_respected(self):
        distribution = Distribution("a", "normal", 10.0, 5.0, lower=8.0,
                                    upper=12.0)
        study = MonteCarlo(lambda p: {"y": p["a"]}, [distribution], seed=0)
        values = study.run(500).values("y")
        assert values.min() >= 8.0 and values.max() <= 12.0

    def test_lognormal_samples_are_positive(self):
        distribution = Distribution("a", "lognormal", 0.0, 1.0)
        study = MonteCarlo(lambda p: {"y": p["a"]}, [distribution], seed=0)
        assert study.run(200).values("y").min() > 0.0

    def test_triangular_respects_its_bounds(self):
        distribution = Distribution("a", "triangular", 1.0, 5.0, c=2.0)
        study = MonteCarlo(lambda p: {"y": p["a"]}, [distribution], seed=0)
        values = study.run(500).values("y")
        assert values.min() >= 1.0 and values.max() <= 5.0

    def test_fixed_distribution_never_varies(self):
        distribution = Distribution("a", "fixed", 7.0)
        study = MonteCarlo(lambda p: {"y": p["a"]}, [distribution], seed=0)
        assert study.run(50).statistics("y")["std"] == pytest.approx(0.0)

    def test_failures_are_captured(self):
        def flaky(point):
            if point["a"] > 10.0:
                raise RuntimeError("diverged")
            return {"y": point["a"]}

        study = MonteCarlo(flaky, self.distributions(), seed=0)
        result = study.run(200)
        assert result.failures

    def test_convergence_reports_settling_statistics(self):
        study = MonteCarlo(self.model, self.distributions(), seed=0)
        trace = study.convergence("y", samples=500, checkpoints=5)
        assert len(trace) == 5
        assert trace[-1][0] > trace[0][0]

    def test_inverted_uniform_bounds_are_rejected(self):
        with pytest.raises(ValueError):
            Distribution("a", "uniform", 5.0, 1.0)

    def test_negative_sigma_is_rejected(self):
        with pytest.raises(ValueError):
            Distribution("a", "normal", 0.0, -1.0)

    def test_triangular_mode_outside_bounds_is_rejected(self):
        with pytest.raises(ValueError):
            Distribution("a", "triangular", 1.0, 5.0, c=9.0)

    def test_zero_samples_is_rejected(self):
        study = MonteCarlo(self.model, self.distributions(), seed=0)
        with pytest.raises(ValueError):
            study.run(0)

    def test_no_distributions_is_rejected(self):
        with pytest.raises(ValueError):
            MonteCarlo(self.model, [])

    def test_missing_key_raises(self):
        study = MonteCarlo(self.model, self.distributions(), seed=0)
        with pytest.raises(KeyError):
            study.run(10).statistics("nothing")
