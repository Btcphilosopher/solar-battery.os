"""Fuels, mixtures, ignition, reaction kinetics, pressure and emissions."""
from __future__ import annotations

import math

import pytest

from electrocombustion.core import units as U
from electrocombustion.combustion import (
    AMMONIA, ArrheniusReaction, BIOGAS, CylinderGeometry, DIESEL, ETHANOL,
    EddyDissipation, EmissionsModel, FUEL_LIBRARY, Fuel, GASOLINE,
    HeatReleaseProfile, HeatSplit, HYDROGEN, IgnitionCriteria, IgnitionModel,
    Igniter, KEROSENE, METHANE, METHANOL, Mixture, PROPANE, PressureVessel,
    ReactionProgress, WiebeFunction, autoignition_delay, available_fuels,
    co2_per_kwh, co2_rate, co_fraction, constant_volume_pressure_rise,
    equivalence_ratio_from_lambda, fuel_rate_for_power, get_fuel,
    heat_release_rate, ideal_gas_pressure, ideal_gas_temperature,
    knock_integral, minimum_ignition_energy, mixture_from_flows,
    polytropic_pressure, polytropic_temperature, polytropic_work, register_fuel,
    specific_fuel_consumption, thermal_efficiency, thermal_nox_rate,
)

ALL_FUELS = [METHANE, PROPANE, HYDROGEN, GASOLINE, DIESEL, ETHANOL, METHANOL,
             AMMONIA, BIOGAS, KEROSENE]


class TestFuel:
    @pytest.mark.parametrize("fuel,expected", [
        (METHANE, 17.2), (PROPANE, 15.7), (DIESEL, 14.5), (HYDROGEN, 34.3),
        (ETHANOL, 9.0), (GASOLINE, 14.7),
    ])
    def test_stoichiometric_afr_matches_textbook(self, fuel, expected):
        assert fuel.stoichiometric_afr == pytest.approx(expected, rel=0.02)

    def test_ammonia_afr(self):
        assert AMMONIA.stoichiometric_afr == pytest.approx(6.05, rel=0.02)

    def test_molar_mass_of_methane(self):
        assert METHANE.molar_mass == pytest.approx(0.016043, rel=1e-3)

    def test_hydrogen_has_the_highest_lhv(self):
        assert HYDROGEN.lhv == max(f.lhv for f in ALL_FUELS)

    def test_hhv_exceeds_lhv_for_hydrogen_bearing_fuels(self):
        assert METHANE.hhv > METHANE.lhv

    def test_hydrogen_has_no_carbon_intensity(self):
        assert HYDROGEN.carbon_intensity == pytest.approx(0.0, abs=1e-12)

    def test_ammonia_has_no_carbon_intensity(self):
        assert AMMONIA.carbon_intensity == pytest.approx(0.0, abs=1e-12)

    def test_methane_carbon_intensity(self):
        expected = U.M_CO2 / METHANE.molar_mass
        assert METHANE.carbon_intensity == pytest.approx(expected, rel=1e-6)

    def test_oxygen_demand_of_methane(self):
        assert METHANE.oxygen_demand == pytest.approx(2.0, rel=1e-9)

    def test_oxygen_demand_of_hydrogen(self):
        assert HYDROGEN.oxygen_demand == pytest.approx(0.5, rel=1e-9)

    def test_burned_fraction_is_one_when_lean(self):
        assert METHANE.burned_fraction(0.5) == pytest.approx(1.0)

    def test_burned_fraction_falls_when_rich(self):
        assert METHANE.burned_fraction(2.0) < 1.0

    @pytest.mark.parametrize("fuel", ALL_FUELS)
    @pytest.mark.parametrize("phi", [0.05, 0.5, 1.0, 1.5, 3.0, 10.0])
    def test_product_mass_balance_closes(self, fuel, phi):
        """Every atom in and out must be accounted for, at any mixture strength."""
        assert abs(fuel.mass_balance_residual(phi)) < 1e-10

    def test_products_contain_co2_for_carbon_fuels(self):
        assert METHANE.products(1.0)["CO2"] > 0.0

    def test_rich_products_contain_carbon_monoxide(self):
        assert METHANE.products(1.5)["CO"] > 0.0

    def test_lean_products_contain_excess_oxygen(self):
        assert METHANE.products(0.5)["O2"] > 0.0

    def test_rich_products_contain_unburned_fuel(self):
        assert METHANE.products(3.0)["FUEL"] > 0.0

    def test_stoichiometric_leaves_no_free_oxygen(self):
        assert METHANE.products(1.0)["O2"] == pytest.approx(0.0, abs=1e-12)

    def test_registry_contains_the_library(self):
        assert "methane" in available_fuels()

    def test_get_fuel_returns_the_registered_object(self):
        assert get_fuel("methane") is METHANE

    def test_get_unknown_fuel_raises(self):
        with pytest.raises(KeyError):
            get_fuel("unobtainium")

    def test_register_a_custom_fuel(self):
        custom = Fuel(name="test_octane", carbon=8, hydrogen=18, lhv=44.0e6,
                      density=703.0)
        register_fuel(custom)
        assert get_fuel("test_octane") is custom

    def test_negative_lhv_is_rejected(self):
        with pytest.raises(ValueError):
            Fuel(name="bad", carbon=1, hydrogen=4, lhv=-1.0)


class TestMixture:
    def test_stoichiometric_lambda_is_one(self):
        assert Mixture(METHANE, 1.0).lambda_ == pytest.approx(1.0)

    def test_lean_lambda_exceeds_one(self):
        assert Mixture(METHANE, 0.5).lambda_ == pytest.approx(2.0)

    def test_lean_and_rich_flags(self):
        assert Mixture(METHANE, 0.8).is_lean
        assert Mixture(METHANE, 1.4).is_rich
        assert not Mixture(METHANE, 1.0).is_rich

    def test_excess_air_is_zero_at_stoichiometric(self):
        assert Mixture(METHANE, 1.0).excess_air == pytest.approx(0.0)

    def test_lambda_conversion_round_trip(self):
        assert equivalence_ratio_from_lambda(1.25) == pytest.approx(0.8)

    def test_afr_scales_inversely_with_phi(self):
        assert Mixture(METHANE, 0.5).afr == pytest.approx(
            2.0 * Mixture(METHANE, 1.0).afr)

    def test_combustion_efficiency_is_high_when_lean(self):
        assert Mixture(METHANE, 0.8).combustion_efficiency > 0.95

    def test_combustion_efficiency_falls_when_rich(self):
        assert (Mixture(METHANE, 1.5).combustion_efficiency
                < Mixture(METHANE, 1.0).combustion_efficiency)

    def test_adiabatic_flame_temperature_of_methane(self):
        t = Mixture(METHANE, 1.0).adiabatic_flame_temperature(298.15)
        assert t == pytest.approx(2226.0, rel=0.06)

    def test_adiabatic_flame_temperature_of_hydrogen(self):
        t = Mixture(HYDROGEN, 1.0).adiabatic_flame_temperature(298.15)
        assert t == pytest.approx(2483.0, rel=0.06)

    def test_flame_temperature_peaks_near_stoichiometric(self):
        """Rich mixtures must burn cooler, because CO holds unreleased energy."""
        peak = Mixture(METHANE, 1.0).adiabatic_flame_temperature(298.15)
        lean = Mixture(METHANE, 0.6).adiabatic_flame_temperature(298.15)
        rich = Mixture(METHANE, 1.6).adiabatic_flame_temperature(298.15)
        assert peak > lean and peak > rich

    def test_rich_release_is_debited_for_carbon_monoxide(self):
        """Fuel that only reaches CO must not be credited with its full LHV."""
        assert METHANE.released_fraction(1.2) < METHANE.burned_fraction(1.2)

    def test_lean_release_is_complete(self):
        assert METHANE.released_fraction(0.7) == pytest.approx(1.0)

    def test_release_falls_monotonically_when_rich(self):
        values = [METHANE.released_fraction(1.0 + 0.1 * i) for i in range(10)]
        assert all(b <= a + 1e-12 for a, b in zip(values, values[1:]))

    def test_preheating_raises_the_flame_temperature(self):
        cold = Mixture(METHANE, 1.0).adiabatic_flame_temperature(298.15)
        hot = Mixture(METHANE, 1.0).adiabatic_flame_temperature(600.0)
        assert hot > cold

    def test_gamma_is_physical(self):
        assert 1.1 < Mixture(METHANE, 1.0).gamma() < 1.5

    def test_density_falls_with_temperature(self):
        cold = Mixture(METHANE, 1.0, temperature=300.0).density()
        hot = Mixture(METHANE, 1.0, temperature=900.0).density()
        assert hot < cold

    def test_laminar_flame_speed_peaks_slightly_rich(self):
        lean = Mixture(METHANE, 0.8).laminar_flame_speed()
        peak = Mixture(METHANE, 1.05).laminar_flame_speed()
        assert peak > lean

    def test_mixture_from_flows_recovers_phi(self):
        mixture = mixture_from_flows(METHANE, fuel_flow=0.01,
                                     air_flow=0.01 * METHANE.stoichiometric_afr)
        assert mixture.equivalence_ratio == pytest.approx(1.0, rel=1e-9)

    def test_negative_equivalence_ratio_is_rejected(self):
        with pytest.raises(ValueError):
            Mixture(METHANE, -1.0)

    def test_fuel_fraction_is_below_one(self):
        assert 0.0 < Mixture(METHANE, 1.0).fuel_fraction < 1.0


class TestIgnition:
    def test_minimum_ignition_energy_is_lowest_near_stoichiometric(self):
        lean = minimum_ignition_energy(Mixture(METHANE, 0.6))
        best = minimum_ignition_energy(Mixture(METHANE, 1.0))
        assert best < lean

    def test_hydrogen_ignites_more_easily_than_methane(self):
        assert (minimum_ignition_energy(Mixture(HYDROGEN, 1.0))
                < minimum_ignition_energy(Mixture(METHANE, 1.0)))

    def test_autoignition_delay_falls_with_temperature(self):
        mixture = Mixture(METHANE, 1.0)
        assert (autoignition_delay(mixture, 1200.0, 3e6)
                < autoignition_delay(mixture, 800.0, 3e6))

    def test_autoignition_delay_falls_with_pressure(self):
        mixture = Mixture(METHANE, 1.0)
        assert (autoignition_delay(mixture, 1000.0, 6e6)
                < autoignition_delay(mixture, 1000.0, 1e6))

    def test_knock_integral_accumulates_with_history_length(self):
        mixture = Mixture(METHANE, 1.0)
        short = knock_integral([1000.0] * 10, [3e6] * 10, mixture, 1e-4)
        long = knock_integral([1000.0] * 20, [3e6] * 20, mixture, 1e-4)
        assert long > short

    def test_knock_integral_rejects_mismatched_histories(self):
        with pytest.raises(ValueError):
            knock_integral([1000.0], [3e6, 3e6], Mixture(METHANE, 1.0), 1e-4)

    def test_hot_history_knocks_sooner_than_a_cold_one(self):
        mixture = Mixture(METHANE, 1.0)
        hot = knock_integral([1400.0] * 100, [6e6] * 100, mixture, 1e-4)
        cold = knock_integral([900.0] * 100, [6e6] * 100, mixture, 1e-4)
        assert hot > cold

    def test_criteria_pass_in_good_conditions(self):
        criteria = IgnitionCriteria()
        assert criteria.satisfied(Mixture(METHANE, 1.0), 1200.0, U.P_ATM, 1.0)

    def test_criteria_fail_outside_flammability_limits(self):
        criteria = IgnitionCriteria()
        assert not criteria.satisfied(Mixture(METHANE, 0.01), 1200.0, U.P_ATM,
                                      1.0)

    def test_failure_reason_is_explanatory(self):
        criteria = IgnitionCriteria()
        reason = criteria.failure_reason(Mixture(METHANE, 0.01), 1200.0,
                                         U.P_ATM, 1.0)
        assert reason and isinstance(reason, str)

    def test_spark_igniter_delivers_power_while_firing(self):
        igniter = Igniter(energy=0.05, duration=1e-3)
        assert igniter.deposited(0.0) > 0.0

    def test_spark_igniter_is_silent_after_its_duration(self):
        igniter = Igniter(energy=0.05, duration=1e-3)
        assert igniter.deposited(1.0) == pytest.approx(0.0)

    def test_igniter_efficiency_reduces_the_deposited_power(self):
        igniter = Igniter(energy=0.05, duration=1e-3, efficiency=0.3)
        assert igniter.deposited(0.0) == pytest.approx(0.3 * igniter.power(0.0))

    def test_ignition_model_ignites_then_stays_lit(self):
        model = IgnitionModel(mode="continuous",
                              igniter=Igniter(energy=1.0, duration=1.0))
        mixture = Mixture(METHANE, 1.0)
        model.update(mixture, 1200.0, U.P_ATM, 0.0, 1e-3)
        assert model.ignited

    def test_ignition_model_reports_flame_out(self):
        model = IgnitionModel(mode="continuous",
                              igniter=Igniter(energy=1.0, duration=1.0))
        mixture = Mixture(METHANE, 1.0)
        model.update(mixture, 1200.0, U.P_ATM, 0.0, 1e-3)
        model.update(Mixture(METHANE, 0.001), 300.0, U.P_ATM, 1.0, 1e-3)
        assert not model.ignited


class TestReaction:
    def test_wiebe_starts_at_zero(self):
        assert WiebeFunction(duration=0.01).fraction(0.0) == pytest.approx(0.0)

    def test_wiebe_approaches_complete_burn(self):
        assert WiebeFunction(duration=0.01).fraction(0.01) == pytest.approx(
            0.999, rel=1e-3)

    def test_wiebe_is_monotonic(self):
        w = WiebeFunction(duration=0.01)
        values = [w.fraction(0.001 * i) for i in range(11)]
        assert all(b >= a for a, b in zip(values, values[1:]))

    def test_wiebe_state_form_reproduces_the_closed_form(self):
        """The state-based rate must integrate to the analytic burn curve.

        Without the ignition kernel this integration never leaves zero, because
        the Wiebe law has a fixed point at zero progress for any shape m > 0.
        """
        w = WiebeFunction(duration=0.02)
        mixture = Mixture(METHANE, 1.0)
        x, dt = 0.0, 1e-6
        for _ in range(20_000):
            x = min(1.0, x + w.rate(x, 1500.0, 1e5, mixture, dt) * dt)
        assert x == pytest.approx(w.fraction(0.02), rel=1e-3)

    def test_wiebe_with_no_kernel_stays_at_the_fixed_point(self):
        w = WiebeFunction(duration=0.02, kernel=0.0)
        mixture = Mixture(METHANE, 1.0)
        assert w.rate(0.0, 1500.0, 1e5, mixture, 1e-6) == pytest.approx(0.0)

    def test_arrhenius_rate_rises_with_temperature(self):
        reaction = ArrheniusReaction()
        mixture = Mixture(METHANE, 1.0)
        hot = reaction.rate(0.5, 2000.0, 1e5, mixture, 1e-4)
        cold = reaction.rate(0.5, 1000.0, 1e5, mixture, 1e-4)
        assert hot > cold

    def test_reaction_rate_is_zero_once_complete(self):
        reaction = ArrheniusReaction()
        mixture = Mixture(METHANE, 1.0)
        assert reaction.rate(1.0, 2000.0, 1e5, mixture, 1e-4) == pytest.approx(0.0)

    def test_eddy_dissipation_is_mixing_limited(self):
        reaction = EddyDissipation(mixing_time=1e-3)
        mixture = Mixture(METHANE, 1.0)
        assert reaction.rate(0.5, 2000.0, 1e5, mixture, 1e-4) > 0.0

    def test_progress_advances_when_active(self):
        progress = ReactionProgress(WiebeFunction(duration=0.01))
        progress.active = True
        mixture = Mixture(METHANE, 1.0)
        progress.step(1500.0, 1e5, mixture, 1e-4)
        assert progress.progress > 0.0

    def test_progress_does_not_advance_when_inactive(self):
        progress = ReactionProgress(WiebeFunction(duration=0.01))
        mixture = Mixture(METHANE, 1.0)
        progress.step(1500.0, 1e5, mixture, 1e-4)
        assert progress.progress == pytest.approx(0.0)

    def test_progress_never_exceeds_one(self):
        progress = ReactionProgress(WiebeFunction(duration=1e-4))
        progress.active = True
        mixture = Mixture(METHANE, 1.0)
        for _ in range(1000):
            progress.step(1500.0, 1e5, mixture, 1e-5)
        assert progress.progress <= 1.0

    def test_reset_returns_to_the_start(self):
        progress = ReactionProgress(WiebeFunction(duration=0.01))
        progress.active = True
        mixture = Mixture(METHANE, 1.0)
        progress.step(1500.0, 1e5, mixture, 1e-3)
        progress.reset()
        assert progress.progress == pytest.approx(0.0)


class TestHeatRelease:
    def test_heat_release_rate_is_flow_times_lhv(self):
        assert heat_release_rate(METHANE, 0.01) == pytest.approx(0.01 * METHANE.lhv)

    def test_combustion_efficiency_reduces_the_release(self):
        assert heat_release_rate(METHANE, 0.01, 0.9) == pytest.approx(
            0.9 * 0.01 * METHANE.lhv)

    def test_fuel_rate_inverts_heat_release(self):
        flow = fuel_rate_for_power(METHANE, 500_000.0)
        assert heat_release_rate(METHANE, flow) == pytest.approx(500_000.0)

    def test_negative_burn_rate_is_rejected(self):
        with pytest.raises(ValueError):
            heat_release_rate(METHANE, -0.01)

    def test_specific_fuel_consumption(self):
        assert specific_fuel_consumption(0.01, 100_000.0) == pytest.approx(1e-7)

    def test_specific_consumption_is_infinite_without_output(self):
        assert math.isinf(specific_fuel_consumption(0.01, 0.0))

    def test_thermal_efficiency_ratio(self):
        eta = thermal_efficiency(100_000.0, 0.01, METHANE)
        assert eta == pytest.approx(100_000.0 / (0.01 * METHANE.lhv))

    def test_heat_split_fractions_close(self):
        split = HeatSplit(work=0.35, coolant=0.28, exhaust=0.30)
        result = split.apply(1000.0)
        assert sum(result.values()) == pytest.approx(1000.0)

    def test_heat_split_rejects_impossible_fractions(self):
        with pytest.raises(ValueError):
            HeatSplit(work=0.6, coolant=0.6, exhaust=0.1)

    def test_heat_release_profile_releases_the_available_energy(self):
        profile = HeatReleaseProfile(Mixture(METHANE, 1.0), charge_mass=1e-3,
                                     mechanism=WiebeFunction(duration=1e-2))
        profile.activate()
        for _ in range(2000):
            profile.step(1500.0, 1e5, 1e-5)
        assert profile.released_energy == pytest.approx(profile.available_energy,
                                                        rel=1e-2)

    def test_residual_energy_falls_as_the_burn_proceeds(self):
        profile = HeatReleaseProfile(Mixture(METHANE, 1.0), charge_mass=1e-3,
                                     mechanism=WiebeFunction(duration=1e-2))
        profile.activate()
        before = profile.residual_energy()
        for _ in range(500):
            profile.step(1500.0, 1e5, 1e-5)
        assert profile.residual_energy() < before


class TestPressure:
    def test_ideal_gas_pressure(self):
        p = ideal_gas_pressure(1.0, 1.0, 300.0, U.R_AIR)
        assert p == pytest.approx(U.R_AIR * 300.0)

    def test_ideal_gas_round_trip(self):
        p = ideal_gas_pressure(1.2, 0.5, 350.0, U.R_AIR)
        assert ideal_gas_temperature(p, 0.5, 1.2, U.R_AIR) == pytest.approx(350.0)

    def test_polytropic_compression_raises_pressure(self):
        assert polytropic_pressure(1e5, 1e-3, 1e-4, 1.35) > 1e5

    def test_polytropic_compression_raises_temperature(self):
        assert polytropic_temperature(300.0, 1e-3, 1e-4, 1.35) > 300.0

    def test_polytropic_exponent_one_is_isothermal(self):
        assert polytropic_temperature(300.0, 1e-3, 1e-4, 1.0) == pytest.approx(300.0)

    def test_polytropic_work_is_negative_on_compression(self):
        assert polytropic_work(1e5, 1e-3, 1e-4, 1.35) < 0.0

    def test_isothermal_work_uses_the_logarithmic_form(self):
        w = polytropic_work(1e5, 1e-3, 2e-3, 1.0)
        assert w == pytest.approx(1e5 * 1e-3 * math.log(2.0))

    def test_constant_volume_heat_addition_raises_pressure(self):
        p = constant_volume_pressure_rise(1e5, 300.0, 1000.0, 1e-3, 718.0)
        assert p > 1e5

    def test_vessel_pressure_follows_the_ideal_gas_law(self):
        vessel = PressureVessel(volume=1e-3, mass=1.2e-3, temperature=300.0)
        assert vessel.pressure == pytest.approx(
            ideal_gas_pressure(1.2e-3, 1e-3, 300.0, vessel.gas_constant))

    def test_adding_heat_raises_pressure(self):
        vessel = PressureVessel()
        before = vessel.pressure
        vessel.add_heat(500.0)
        assert vessel.pressure > before

    def test_adding_mass_conserves_internal_energy(self):
        vessel = PressureVessel(mass=1e-3, temperature=300.0)
        before = vessel.internal_energy
        added = 1e-3
        vessel.add_mass(added, 600.0)
        expected = before + added * vessel.specific_heat_cv * 600.0
        assert vessel.internal_energy == pytest.approx(expected)

    def test_venting_removes_mass(self):
        vessel = PressureVessel(mass=1e-3)
        vessel.vent(5e-4)
        assert vessel.mass == pytest.approx(5e-4)

    def test_venting_returns_the_enthalpy_lost(self):
        vessel = PressureVessel(mass=1e-3, temperature=400.0)
        cp = vessel.specific_heat_cv + vessel.gas_constant
        assert vessel.vent(5e-4) == pytest.approx(5e-4 * cp * 400.0)

    def test_choked_flow_is_zero_without_a_pressure_difference(self):
        vessel = PressureVessel()
        assert vessel.choked_mass_flow(1e-4, vessel.pressure * 2.0) == 0.0

    def test_choked_flow_saturates(self):
        vessel = PressureVessel(mass=1e-2)
        deep = vessel.choked_mass_flow(1e-4, 1.0)
        shallow = vessel.choked_mass_flow(1e-4, 1e3)
        assert deep == pytest.approx(shallow, rel=1e-9)

    def test_overpressure_flag(self):
        vessel = PressureVessel(burst_pressure=1e5)
        vessel.add_heat(5000.0)
        assert vessel.is_overpressure

    def test_cylinder_compression_ratio(self):
        geometry = CylinderGeometry(compression_ratio=10.5)
        ratio = geometry.volume(math.pi) / geometry.volume(0.0)
        assert ratio == pytest.approx(10.5, rel=1e-6)

    def test_cylinder_displacement(self):
        geometry = CylinderGeometry(bore=0.086, stroke=0.086)
        expected = math.pi / 4.0 * 0.086 ** 2 * 0.086
        assert geometry.displacement == pytest.approx(expected)

    def test_volume_derivative_is_zero_at_top_dead_centre(self):
        geometry = CylinderGeometry()
        assert geometry.volume_derivative(0.0) == pytest.approx(0.0, abs=1e-9)

    def test_compression_ratio_must_exceed_one(self):
        with pytest.raises(ValueError):
            CylinderGeometry(compression_ratio=0.9)


class TestEmissions:
    def test_co2_rate_follows_carbon_content(self):
        assert co2_rate(METHANE, 0.01) == pytest.approx(
            0.01 * METHANE.carbon_intensity)

    def test_hydrogen_emits_no_co2(self):
        assert co2_rate(HYDROGEN, 0.01) == pytest.approx(0.0)

    def test_co2_per_kwh_falls_with_efficiency(self):
        assert co2_per_kwh(METHANE, 0.5) < co2_per_kwh(METHANE, 0.3)

    def test_co2_per_kwh_rejects_impossible_efficiency(self):
        with pytest.raises(ValueError):
            co2_per_kwh(METHANE, 1.5)

    def test_nox_is_negligible_below_1800_kelvin(self):
        assert thermal_nox_rate(1500.0, 0.01, 0.02) < 1e-3

    def test_nox_rises_steeply_with_flame_temperature(self):
        low = thermal_nox_rate(1900.0, 0.01, 0.02)
        high = thermal_nox_rate(2100.0, 0.01, 0.02)
        assert high > 5.0 * low

    def test_nox_is_zero_at_absurdly_low_temperature(self):
        assert thermal_nox_rate(100.0, 0.01, 0.02) == pytest.approx(0.0)

    def test_co_fraction_rises_when_rich(self):
        assert (co_fraction(Mixture(METHANE, 1.4), 2000.0)
                > co_fraction(Mixture(METHANE, 0.9), 2000.0))

    def test_emissions_model_reports_every_species(self):
        model = EmissionsModel()
        result = model.evaluate(Mixture(METHANE, 1.0), 0.01, 2000.0)
        for key in ("co2", "nox", "co", "unburned_fuel"):
            assert key in result

    def test_emissions_are_non_negative(self):
        model = EmissionsModel()
        result = model.evaluate(Mixture(METHANE, 1.0), 0.01, 2000.0)
        assert all(v >= 0.0 for v in result.values())

    def test_specific_emissions_are_infinite_without_output(self):
        model = EmissionsModel()
        result = model.specific_emissions(Mixture(METHANE, 1.0), 0.01, 2000.0,
                                          0.0)
        assert math.isinf(result["co2_per_kwh"])

    def test_more_residence_time_does_not_reduce_nox(self):
        short = EmissionsModel(residence_time=0.005)
        long = EmissionsModel(residence_time=0.05)
        a = short.evaluate(Mixture(METHANE, 1.0), 0.01, 2100.0)["nox"]
        b = long.evaluate(Mixture(METHANE, 1.0), 0.01, 2100.0)["nox"]
        assert b >= a
