#' Monte Carlo Simulation for Risk & Curtailment Probability
#' @param n_sims Number of stochastic scenarios (e.g., 2000)
#' @param mean_wind Mean wind generation (MW)
#' @param mean_demand Mean demand (MW)
#' @param spot_mean Expected spot price (£/MWh)
#' @param spot_sd Spot price volatility (£/MWh)
#' @return Risk metrics: expected value, VaR 95%, probability of curtailment & grid import
run_monte_carlo_dispatch <- function(n_sims = 2000, mean_wind = 150, mean_demand = 110, spot_mean = 85, spot_sd = 35) {
  set.seed(42) # Deterministic reproducible seed
  
  sim_wind <- pmax(0, rnorm(n_sims, mean = mean_wind, sd = mean_wind * 0.35))
  sim_demand <- pmax(10, rnorm(n_sims, mean = mean_demand, sd = mean_demand * 0.15))
  sim_spot <- rnorm(n_sims, mean = spot_mean, sd = spot_sd)
  
  surplus_wind <- pmax(0, sim_wind - sim_demand)
  deficit_demand <- pmax(0, sim_demand - sim_wind)
  
  curtailment_events <- surplus_wind > 50 # assuming 50 MW battery absorption cap
  grid_import_events <- deficit_demand > 0
  
  revenue <- (pmin(sim_wind, sim_demand) * pmax(20, sim_spot)) + 
             (pmin(50, surplus_wind) * pmax(0, sim_spot * 0.9)) - 
             (deficit_demand * sim_spot)
  
  var_95 <- quantile(revenue, 0.05)
  expected_val <- mean(revenue)
  
  return(list(
    n_simulations = n_sims,
    expected_value_gbp = round(expected_val, 2),
    var_95_gbp = round(var_95, 2),
    prob_curtailment_pct = round(100 * mean(curtailment_events), 1),
    prob_grid_import_pct = round(100 * mean(grid_import_events), 1),
    downside_risk_gbp = round(expected_val - var_95, 2)
  ))
}
