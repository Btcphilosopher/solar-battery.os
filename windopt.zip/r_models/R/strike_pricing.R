#' Strike Contract Optimal Execution & Option Value
#' Evaluates whether a strike contract should be exercised vs spot market vs battery arbitrage
#' @param spot_prices Numeric vector of forecasted spot electricity prices (£/MWh)
#' @param strike_price Strike contract price (£/MWh)
#' @param contract_vol MWh volume available under strike contract
#' @param battery_deg_cost Battery degradation cost (£/MWh)
#' @return List containing exercise decisions and total strike value created (£)
value_strike_contract <- function(spot_prices, strike_price, contract_vol, battery_deg_cost = 18.5) {
  num_periods <- length(spot_prices)
  decisions <- character(num_periods)
  savings <- numeric(num_periods)
  
  for (i in 1:num_periods) {
    p_spot <- spot_prices[i]
    if (p_spot > strike_price) {
      # Exercising strike avoids expensive spot purchases or generates arbitrage margin
      decisions[i] <- "EXERCISE_STRIKE"
      savings[i] <- (p_spot - strike_price) * contract_vol
    } else if (p_spot < (strike_price - battery_deg_cost)) {
      # Buy spot & charge battery or deliver spot directly
      decisions[i] <- "BUY_SPOT"
      savings[i] <- 0
    } else {
      decisions[i] <- "PASS_OR_DIRECT_WIND"
      savings[i] <- 0
    }
  }
  
  return(list(
    total_savings_gbp = sum(savings),
    decisions = decisions,
    mean_spot = mean(spot_prices),
    strike_price = strike_price,
    strike_in_the_money_pct = round(100 * sum(spot_prices > strike_price) / num_periods, 1)
  ))
}
