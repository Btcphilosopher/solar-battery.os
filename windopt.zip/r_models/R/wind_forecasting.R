#' Weibull Wind Speed & Power Curve Generation
#' @param mean_wind_speed Average wind speed in m/s
#' @param shape_k Weibull shape parameter (default 2.0 - Rayleigh)
#' @param num_steps Horizon length in 15-min or 30-min intervals
#' @return Numeric vector of wind generation forecasts (MW)
predict_wind_power <- function(mean_wind_speed, shape_k = 2.1, num_steps = 96, rated_mw = 200) {
  # Weibull scale parameter c from mean wind speed
  scale_c <- mean_wind_speed / gamma(1 + 1 / shape_k)
  
  # Auto-regressive wind speed simulation AR(1) with Weibull marginal distribution
  u <- numeric(num_steps)
  u[1] <- pweibull(mean_wind_speed, shape = shape_k, scale = scale_c)
  
  phi <- 0.88 # 15-min autocorrelation coefficient
  for (t in 2:num_steps) {
    z <- phi * qnorm(u[t-1]) + sqrt(1 - phi^2) * rnorm(1)
    u[t] <- pnorm(z)
  }
  
  wind_speeds <- qweibull(pmax(1e-5, pmin(0.99999, u)), shape = shape_k, scale = scale_c)
  
  # Power curve mapping (IEC Class II)
  power_mw <- sapply(wind_speeds, function(ws) {
    if (ws < 3.0 || ws >= 25.0) return(0.0)
    if (ws >= 12.0) return(rated_mw)
    return(rated_mw * ((ws - 3.0) / (12.0 - 3.0))^3)
  })
  
  return(list(
    wind_speed_ms = round(wind_speeds, 2),
    power_mw = round(power_mw, 2),
    capacity_factor = round(mean(power_mw) / rated_mw, 4)
  ))
}
