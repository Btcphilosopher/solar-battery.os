import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { DispatchOverview } from './components/DispatchOverview';
import { TurbineFarmMatrix } from './components/TurbineFarmMatrix';
import { BatteryDegradationPanel } from './components/BatteryDegradationPanel';
import { StrikePriceOptimiser } from './components/StrikePriceOptimiser';
import { MonteCarloRiskPanel } from './components/MonteCarloRiskPanel';
import { CodeArchitectureExplorer } from './components/CodeArchitectureExplorer';
import { DispatchAuditLog } from './components/DispatchAuditLog';

import { createDefaultWindFarm } from './engine/windEngine';
import { createDefaultBattery } from './engine/batteryEngine';
import { createDefaultFlexibleLoads } from './engine/demandEngine';
import { createDefaultStrikeContracts } from './engine/marketEngine';
import { runDispatchOptimization } from './engine/optimiser';
import { OptimizationRunOutput, TurbineState } from './engine/types';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('overview');

  const [farm, setFarm] = useState(createDefaultWindFarm());
  const [battery, setBattery] = useState(createDefaultBattery());
  const [flexibleLoads] = useState(createDefaultFlexibleLoads());
  const [strikeContracts, setStrikeContracts] = useState(createDefaultStrikeContracts());

  const [baseWindSpeed, setBaseWindSpeed] = useState<number>(11.5);
  const [baseDemand, setBaseDemand] = useState<number>(120.0);
  const [spotPrice, setSpotPrice] = useState<number>(96.0);

  const [isSimulating, setIsSimulating] = useState<boolean>(false);

  const [optRun, setOptRun] = useState<OptimizationRunOutput>(() =>
    runDispatchOptimization(
      farm,
      battery,
      flexibleLoads,
      strikeContracts,
      baseWindSpeed,
      baseDemand,
      spotPrice,
      24,
      15
    )
  );

  const runOptimization = async (
    wind = baseWindSpeed,
    demand = baseDemand,
    spot = spotPrice,
    updatedFarm = farm,
    updatedContracts = strikeContracts
  ) => {
    setIsSimulating(true);
    try {
      const res = await fetch('/api/optimise', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          horizonHours: 24,
          stepMinutes: 15,
          windSpeedMs: wind,
          demandMw: demand,
          spotPriceGbp: spot,
        }),
      });

      if (res.ok) {
        const json = await res.json();
        setOptRun(json);
      } else {
        // Fallback local calculation
        const localRun = runDispatchOptimization(
          updatedFarm,
          battery,
          flexibleLoads,
          updatedContracts,
          wind,
          demand,
          spot,
          24,
          15
        );
        setOptRun(localRun);
      }
    } catch (e) {
      const localRun = runDispatchOptimization(
        updatedFarm,
        battery,
        flexibleLoads,
        updatedContracts,
        wind,
        demand,
        spot,
        24,
        15
      );
      setOptRun(localRun);
    } finally {
      setIsSimulating(false);
    }
  };

  const handleScenarioUpdate = (wind: number, demand: number, spot: number) => {
    setBaseWindSpeed(wind);
    setBaseDemand(demand);
    setSpotPrice(spot);
    runOptimization(wind, demand, spot);
  };

  const handleUpdateTurbineState = (turbineId: string, newState: TurbineState) => {
    const updatedTurbines = farm.turbines.map((t) =>
      t.id === turbineId ? { ...t, state: newState } : t
    );
    const updatedFarm = { ...farm, turbines: updatedTurbines };
    setFarm(updatedFarm);
    runOptimization(baseWindSpeed, baseDemand, spotPrice, updatedFarm);
  };

  const handleAddStrikeContract = async (code: string, price: number, volume: number) => {
    try {
      const res = await fetch('/api/strike-contract', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contractCode: code,
          strikePriceGbpPerMwh: price,
          volumeMwh: volume,
        }),
      });
      if (res.ok) {
        const json = await res.json();
        setStrikeContracts(json.allContracts);
        runOptimization(baseWindSpeed, baseDemand, spotPrice, farm, json.allContracts);
      }
    } catch (e) {
      const newContract = {
        id: `sc-${Date.now()}`,
        contractCode: code,
        counterparty: 'Bilateral Counterparty',
        deliveryStart: '00:00',
        deliveryEnd: '23:59',
        volumeMwh: volume,
        strikePriceGbpPerMwh: price,
        minimumDeliveryPct: 95.0,
        settlementRule: 'PHYSICAL_OR_FINANCIAL' as const,
        isActive: true,
      };
      const updated = [...strikeContracts, newContract];
      setStrikeContracts(updated);
      runOptimization(baseWindSpeed, baseDemand, spotPrice, updated);
    }
  };

  useEffect(() => {
    runOptimization();
  }, []);

  return (
    <div className="min-h-screen bg-[#0F1115] text-[#E0E0E0] flex flex-col font-sans selection:bg-[#F27D26] selection:text-black">
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        systemValueGbp={optRun.summary.netSystemValueGbp}
        windUtilisationPct={optRun.summary.windUtilisationPct}
        conservationPassed={optRun.summary.conservationVerified}
        solverStatus="OPTIMAL"
        onRunOptimization={() => runOptimization()}
        isSimulating={isSimulating}
      />

      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 space-y-8">
        {activeTab === 'overview' && (
          <>
            <DispatchOverview
              optRun={optRun}
              onUpdateScenario={handleScenarioUpdate}
              baseWindSpeed={baseWindSpeed}
              baseDemand={baseDemand}
              spotPrice={spotPrice}
            />
            <DispatchAuditLog optRun={optRun} />
          </>
        )}

        {activeTab === 'turbines' && (
          <TurbineFarmMatrix farm={farm} onUpdateTurbineState={handleUpdateTurbineState} />
        )}

        {activeTab === 'battery' && <BatteryDegradationPanel battery={battery} />}

        {activeTab === 'strike' && (
          <StrikePriceOptimiser
            strikeContracts={strikeContracts}
            spotPriceGbp={spotPrice}
            onAddStrikeContract={handleAddStrikeContract}
          />
        )}

        {activeTab === 'montecarlo' && <MonteCarloRiskPanel />}

        {activeTab === 'architecture' && <CodeArchitectureExplorer />}
      </main>

      <footer className="mt-8 border-t border-[#2A2D35] bg-[#0F1115] py-6 max-w-7xl w-full mx-auto px-6 flex flex-wrap justify-between items-center text-[10px] font-mono text-[#6A6E7A]">
        <div className="flex gap-6 uppercase tracking-widest">
          <span>Rust Engine Active</span>
          <span>R Forecast Validated</span>
          <span>PostGIS Link Established</span>
        </div>
        <div className="bg-[#2A2D35] px-3 py-1 text-white uppercase tracking-tighter italic font-bold">
          HARD-TECH INDUSTRIAL SYSTEMS
        </div>
      </footer>
    </div>
  );
}
