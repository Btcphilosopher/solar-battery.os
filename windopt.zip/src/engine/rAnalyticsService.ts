import { MonteCarloScenarioResult } from './types';

export function runRMonteCarloAnalytics(
  numSimulations: number = 2000,
  baseWindMw: number = 150,
  baseDemandMw: number = 110,
  meanSpotPrice: number = 85.0,
  spotVolatility: number = 32.0
): MonteCarloScenarioResult {
  const outcomes: number[] = [];
  let curtailmentCount = 0;
  let gridImportCount = 0;

  for (let i = 0; i < numSimulations; i++) {
    // Normal / Weibull stochastic wind variation
    const windVariation = 1.0 + (Math.random() - 0.5) * 0.7;
    const simWindMw = Math.max(0, baseWindMw * windVariation);

    // Stochastic demand variation
    const demandVariation = 1.0 + (Math.random() - 0.5) * 0.3;
    const simDemandMw = Math.max(10, baseDemandMw * demandVariation);

    // Box-Muller normal spot price generator
    const u1 = Math.random();
    const u2 = Math.random();
    const z0 = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
    const simSpotPrice = meanSpotPrice + z0 * spotVolatility;

    const surplusWind = Math.max(0, simWindMw - simDemandMw);
    const deficitDemand = Math.max(0, simDemandMw - simWindMw);

    if (surplusWind > 50) curtailmentCount++;
    if (deficitDemand > 5) gridImportCount++;

    // Net value calculation
    const revenue =
      Math.min(simWindMw, simDemandMw) * Math.max(15, simSpotPrice) +
      Math.min(50, surplusWind) * Math.max(0, simSpotPrice * 0.88) -
      deficitDemand * Math.max(30, simSpotPrice * 1.1);

    outcomes.push(revenue);
  }

  outcomes.sort((a, b) => a - b);

  const sum = outcomes.reduce((acc, val) => acc + val, 0);
  const expectedSystemValueGbp = sum / numSimulations;

  // 95% Value at Risk (5th percentile outcome)
  const varIndex = Math.floor(numSimulations * 0.05);
  const var95Gbp = outcomes[varIndex];
  const downsideRiskGbp = expectedSystemValueGbp - var95Gbp;

  // Create histogram bins
  const binCount = 12;
  const minVal = outcomes[0];
  const maxVal = outcomes[outcomes.length - 1];
  const binWidth = (maxVal - minVal) / binCount;

  const histogramMap = new Map<number, number>();
  for (let b = 0; b < binCount; b++) {
    histogramMap.set(b, 0);
  }

  outcomes.forEach((val) => {
    let bIndex = Math.floor((val - minVal) / binWidth);
    if (bIndex >= binCount) bIndex = binCount - 1;
    histogramMap.set(bIndex, (histogramMap.get(bIndex) || 0) + 1);
  });

  const distributionHistogram = Array.from(histogramMap.entries()).map(([binIdx, count]) => {
    const binCenter = minVal + (binIdx + 0.5) * binWidth;
    return {
      binLabel: `£${Math.round(binCenter / 1000)}k`,
      count,
      valueGbp: Math.round(binCenter),
    };
  });

  return {
    numSimulations,
    expectedSystemValueGbp: Math.round(expectedSystemValueGbp),
    var95Gbp: Math.round(var95Gbp),
    downsideRiskGbp: Math.round(downsideRiskGbp),
    probCurtailmentPct: Number(((curtailmentCount / numSimulations) * 100).toFixed(1)),
    probGridImportPct: Number(((gridImportCount / numSimulations) * 100).toFixed(1)),
    distributionHistogram,
  };
}
