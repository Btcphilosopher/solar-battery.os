import { StrikeContract, WindShadowPriceResult } from './types';

export function createDefaultStrikeContracts(): StrikeContract[] {
  return [
    {
      id: 'sc-001',
      contractCode: 'STRIKE-PPA-2026-A',
      counterparty: 'Orsted Energy Trading UK',
      deliveryStart: '00:00',
      deliveryEnd: '23:59',
      volumeMwh: 50.0,
      strikePriceGbpPerMwh: 82.5,
      minimumDeliveryPct: 95.0,
      settlementRule: 'PHYSICAL_OR_FINANCIAL',
      isActive: true,
    },
    {
      id: 'sc-002',
      contractCode: 'STRIKE-PEAK-2026-B',
      counterparty: 'Centrica Energy Markets',
      deliveryStart: '17:00',
      deliveryEnd: '21:00',
      volumeMwh: 30.0,
      strikePriceGbpPerMwh: 115.0,
      minimumDeliveryPct: 90.0,
      settlementRule: 'PHYSICAL_OR_FINANCIAL',
      isActive: true,
    },
  ];
}

/**
 * Calculates Wind Shadow Price and Opportunity Cost
 * Evaluates immediate consumption, storage, export, strike contract, and future value
 */
export function calculateWindShadowPrice(
  spotPriceGbp: number,
  strikePriceGbp: number,
  batterySocPct: number,
  batteryDegradationCostGbp: number,
  isExcessWind: boolean
): WindShadowPriceResult {
  const immediateConsumptionValue = spotPriceGbp;
  
  // Storage value: expected future spot price minus round-trip loss (~8%) and degradation
  const futureExpectedSpot = spotPriceGbp * 1.15; // expected peak price
  const roundTripCoeff = 0.92;
  const batteryStorageValue = Math.max(
    0,
    futureExpectedSpot * roundTripCoeff - batteryDegradationCostGbp
  );

  const exportValue = spotPriceGbp * 0.98; // Grid export fee 2%
  const strikeExerciseValue = Math.max(spotPriceGbp, strikePriceGbp);
  const futureExpectedValue = Math.max(spotPriceGbp, 75.0);
  const curtailmentPenalty = isExcessWind ? -12.0 : 0.0; // Penalty for wasting clean energy

  // Shadow price is the maximum economic opportunity across all dispatch pathways
  const effectiveShadowPriceGbp = Math.max(
    immediateConsumptionValue,
    batteryStorageValue,
    exportValue,
    strikeExerciseValue
  );

  return {
    immediateConsumptionValue,
    batteryStorageValue,
    exportValue,
    strikeExerciseValue,
    futureExpectedValue,
    curtailmentPenalty,
    effectiveShadowPriceGbp,
  };
}

/**
 * Evaluates whether to exercise strike contract or trade on spot market
 */
export function evaluateStrikeDecision(
  spotPriceGbp: number,
  activeStrikeContracts: StrikeContract[]
): {
  strikeExercised: boolean;
  chosenPriceGbp: number;
  strikeSavingsGbp: number;
  activeContractCode: string;
} {
  const active = activeStrikeContracts.find((c) => c.isActive);

  if (!active) {
    return {
      strikeExercised: false,
      chosenPriceGbp: spotPriceGbp,
      strikeSavingsGbp: 0,
      activeContractCode: 'NONE',
    };
  }

  // If spot price exceeds strike price, exercising strike locks in higher guaranteed revenue or lower purchase cost
  if (spotPriceGbp > active.strikePriceGbpPerMwh) {
    const savings = (spotPriceGbp - active.strikePriceGbpPerMwh) * active.volumeMwh;
    return {
      strikeExercised: true,
      chosenPriceGbp: active.strikePriceGbpPerMwh,
      strikeSavingsGbp: savings,
      activeContractCode: active.contractCode,
    };
  }

  return {
    strikeExercised: false,
    chosenPriceGbp: spotPriceGbp,
    strikeSavingsGbp: 0,
    activeContractCode: active.contractCode,
  };
}
