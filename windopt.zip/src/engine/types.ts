export type TurbineState = 
  | 'OFF'
  | 'STARTING'
  | 'RUNNING'
  | 'RAMPING'
  | 'CURTAILED'
  | 'FAULT'
  | 'MAINTENANCE'
  | 'STOPPING';

export interface WindTurbine {
  id: string;
  code: string;
  model: string;
  ratedPowerMw: number;
  rotorDiameterM: number;
  hubHeightM: number;
  cutInSpeedMs: number;
  ratedSpeedMs: number;
  cutOutSpeedMs: number;
  efficiency: number; // e.g. 0.94
  availabilityPct: number;
  state: TurbineState;
  currentWindSpeedMs: number;
  activePowerMw: number;
  rotorRpm: number;
  generatorTempC: number;
  vibrationMmS: number;
  cumulativeOperatingHours: number;
  minRunTimeMins: number;
  minDowntimeMins: number;
  maxRampRateMwPerMin: number;
}

export interface WindFarmConfig {
  id: string;
  name: string;
  locationName: string;
  latitude: number;
  longitude: number;
  ratedCapacityMw: number;
  turbines: WindTurbine[];
  wakeLossFactor: number; // e.g. 0.04 (4% loss)
}

export interface BatteryState {
  id: string;
  name: string;
  maxCapacityMwh: number;
  currentCapacityMwh: number;
  socPct: number; // 0-100
  sohPct: number; // 0-100
  maxChargeMw: number;
  maxDischargeMw: number;
  roundTripEfficiency: number; // e.g. 0.92
  degradationCostPerMwh: number; // £/MWh
  temperatureC: number;
  totalCycles: number;
  totalThroughputMwh: number;
}

export interface FlexibleLoad {
  id: string;
  name: string;
  category: 'INDUSTRIAL' | 'COMMERCIAL' | 'EV_CHARGING' | 'DATA_CENTER' | 'THERMAL_STORE';
  powerMw: number;
  isMoveable: boolean;
  canWaitHours: number;
  mustRunByHour: number;
  priority: number;
  isCurrentActive: boolean;
}

export interface StrikeContract {
  id: string;
  contractCode: string;
  counterparty: string;
  deliveryStart: string;
  deliveryEnd: string;
  volumeMwh: number;
  strikePriceGbpPerMwh: number;
  minimumDeliveryPct: number;
  settlementRule: 'PHYSICAL_OR_FINANCIAL' | 'FINANCIAL_ONLY';
  isActive: boolean;
}

export interface MarketState {
  currentSpotPriceGbp: number;
  forecastSpotPrices: number[];
  strikeContracts: StrikeContract[];
  priceVolatilityIdx: number; // 0-100
}

export interface WindShadowPriceResult {
  immediateConsumptionValue: number;
  batteryStorageValue: number;
  exportValue: number;
  strikeExerciseValue: number;
  futureExpectedValue: number;
  curtailmentPenalty: number;
  effectiveShadowPriceGbp: number;
}

export interface ConservationCheck {
  totalSupplyMwh: number;
  totalSinkMwh: number;
  imbalanceMwh: number;
  passed: boolean;
  toleranceMwh: number;
}

export interface DispatchIntervalResult {
  timestamp: string;
  timeLabel: string;
  windSpeedMs: number;
  airDensityKgM3: number;
  availableWindMw: number;
  generatedWindMw: number;
  usefulWindMw: number;
  curtailedWindMw: number;
  
  baseDemandMw: number;
  flexibleLoadShiftMw: number;
  totalDemandServedMw: number;
  
  batteryChargeMw: number;
  batteryDischargeMw: number;
  batterySocPct: number;
  batteryDegradationCostGbp: number;
  
  gridImportMw: number;
  gridExportMw: number;
  
  spotPriceGbp: number;
  activeStrikePriceGbp: number;
  strikeExercised: boolean;
  strikeSavingsGbp: number;
  
  windShadowPriceGbp: number;
  
  windUtilisationPct: number; // useful / available
  turbineUtilisationPct: number;
  
  netRevenueGbp: number;
  systemValueGbp: number;
  solverStatus: 'OPTIMAL' | 'FEASIBLE' | 'RELAXED';
  conservation: ConservationCheck;
}

export interface OptimizationRunOutput {
  runId: string;
  timestamp: string;
  horizonHours: number;
  stepMinutes: number;
  intervals: DispatchIntervalResult[];
  
  summary: {
    totalAvailableWindMwh: number;
    totalGeneratedWindMwh: number;
    totalUsefulWindMwh: number;
    totalCurtailedWindMwh: number;
    windUtilisationPct: number;
    turbineUtilisationPct: number;
    
    totalDemandServedMwh: number;
    totalBatteryChargedMwh: number;
    totalBatteryDischargedMwh: number;
    totalGridImportMwh: number;
    totalGridExportMwh: number;
    
    totalSpotRevenueGbp: number;
    totalStrikeRevenueGbp: number;
    totalGridCostGbp: number;
    totalBatteryDegradationCostGbp: number;
    netSystemValueGbp: number;
    
    strikeOptimizationSavingsGbp: number;
    conservationVerified: boolean;
  };
}

export interface MonteCarloScenarioResult {
  numSimulations: number;
  expectedSystemValueGbp: number;
  var95Gbp: number; // Value at Risk 95%
  downsideRiskGbp: number;
  probCurtailmentPct: number;
  probGridImportPct: number;
  distributionHistogram: { binLabel: string; count: number; valueGbp: number }[];
}

export interface ScenarioPreset {
  id: string;
  name: string;
  description: string;
  windMultiplier: number;
  spotPriceMultiplier: number;
  demandMultiplier: number;
  batteryFault: boolean;
  gridOutage: boolean;
}
