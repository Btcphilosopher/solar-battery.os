import { BatteryState } from './types';

export function createDefaultBattery(): BatteryState {
  return {
    id: 'bess-megapack-1',
    name: 'Dogger BESS 100MW / 200MWh LiFePO4 System',
    maxCapacityMwh: 200.0,
    currentCapacityMwh: 142.0,
    socPct: 71.0,
    sohPct: 97.4,
    maxChargeMw: 100.0,
    maxDischargeMw: 100.0,
    roundTripEfficiency: 0.92, // 92% RTE
    degradationCostPerMwh: 16.8, // £16.80 per throughput MWh
    temperatureC: 23.5,
    totalCycles: 412,
    totalThroughputMwh: 82400,
  };
}

/**
 * Calculates dynamic battery degradation cost per MWh throughput
 * based on current SOC stress and C-rate
 */
export function calculateBatteryDegradationCost(
  battery: BatteryState,
  powerMw: number,
  intervalHours: number
): number {
  if (Math.abs(powerMw) < 0.01) return 0.0;

  const cRate = Math.abs(powerMw) / (battery.maxCapacityMwh / 2.0); // C-rate
  let socMultiplier = 1.0;

  if (battery.socPct > 85) {
    socMultiplier = 1.0 + (battery.socPct - 85) * 0.04;
  } else if (battery.socPct < 15) {
    socMultiplier = 1.0 + (15 - battery.socPct) * 0.03;
  }

  const cRateMultiplier = 1.0 + Math.max(0, cRate - 0.5) * 0.3;
  const throughputMwh = Math.abs(powerMw) * intervalHours;

  const dynamicCostPerMwh = battery.degradationCostPerMwh * socMultiplier * cRateMultiplier;
  return throughputMwh * dynamicCostPerMwh;
}

/**
 * Updates battery state after charging (+) or discharging (-) over an interval
 */
export function updateBatteryState(
  battery: BatteryState,
  powerMw: number, // positive = charge, negative = discharge
  intervalHours: number
): BatteryState {
  if (Math.abs(powerMw) < 0.001) return { ...battery };

  const throughputMwh = Math.abs(powerMw) * intervalHours;
  let newCapacityMwh = battery.currentCapacityMwh;

  if (powerMw > 0) {
    // Charging: input MWh * round-trip efficiency square root (~96% charge efficiency)
    const chargeEff = Math.sqrt(battery.roundTripEfficiency);
    newCapacityMwh += powerMw * intervalHours * chargeEff;
  } else {
    // Discharging: output MWh / discharge efficiency (~96%)
    const dischargeEff = Math.sqrt(battery.roundTripEfficiency);
    newCapacityMwh -= (Math.abs(powerMw) * intervalHours) / dischargeEff;
  }

  // Constrain to 5% - 95% SOC operational bounds
  const minMwh = battery.maxCapacityMwh * 0.05;
  const maxMwh = battery.maxCapacityMwh * 0.95;
  newCapacityMwh = Math.min(maxMwh, Math.max(minMwh, newCapacityMwh));

  const newSocPct = (newCapacityMwh / battery.maxCapacityMwh) * 100.0;
  const newThroughput = battery.totalThroughputMwh + throughputMwh;
  const newCycles = newThroughput / (battery.maxCapacityMwh * 2.0);

  // SOH fade: 0.0015% per cycle
  const newSohPct = Math.max(70.0, 100.0 - newCycles * 0.0015);

  return {
    ...battery,
    currentCapacityMwh: newCapacityMwh,
    socPct: newSocPct,
    sohPct: newSohPct,
    totalThroughputMwh: newThroughput,
    totalCycles: Math.round(newCycles),
  };
}
