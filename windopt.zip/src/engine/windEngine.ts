import { WindTurbine, WindFarmConfig, TurbineState } from './types';

export const STANDARD_AIR_DENSITY = 1.225; // kg/m^3

/**
 * Calculates theoretical kinetic wind power in MW
 */
export function calculateKineticPowerMw(
  windSpeedMs: number,
  rotorDiameterM: number,
  airDensityKgM3: number = STANDARD_AIR_DENSITY
): number {
  const radius = rotorDiameterM / 2;
  const sweptAreaM2 = Math.PI * radius * radius;
  // Kinetic energy flux = 0.5 * rho * A * v^3 (in Watts)
  const watts = 0.5 * airDensityKgM3 * sweptAreaM2 * Math.pow(windSpeedMs, 3);
  return watts / 1_000_000;
}

/**
 * Calculates electrical output MW of a single turbine taking into account
 * cut-in, rated, cut-out speed, density correction, and Betz efficiency
 */
export function calculateTurbineOutputMw(
  turbine: WindTurbine,
  windSpeedMs: number,
  airDensityKgM3: number = STANDARD_AIR_DENSITY
): number {
  if (
    turbine.state === 'OFF' ||
    turbine.state === 'FAULT' ||
    turbine.state === 'MAINTENANCE' ||
    turbine.state === 'STOPPING'
  ) {
    return 0;
  }

  if (windSpeedMs < turbine.cutInSpeedMs || windSpeedMs >= turbine.cutOutSpeedMs) {
    return 0;
  }

  // Air density normalization: v_eff = v * (rho / rho_0)^(1/3)
  const densityCorrection = Math.cbrt(airDensityKgM3 / STANDARD_AIR_DENSITY);
  const effectiveWindSpeed = windSpeedMs * densityCorrection;

  if (effectiveWindSpeed >= turbine.ratedSpeedMs) {
    let output = turbine.ratedPowerMw * turbine.efficiency;
    if (turbine.state === 'CURTAILED') {
      output = output * 0.2; // Curtailed to 20%
    }
    return output;
  }

  // Cubic curve interpolation between cut-in and rated speed
  const speedRatio =
    (effectiveWindSpeed - turbine.cutInSpeedMs) / (turbine.ratedSpeedMs - turbine.cutInSpeedMs);
  const powerCoeff = Math.min(1.0, Math.max(0.0, Math.pow(speedRatio, 3)));
  
  let output = turbine.ratedPowerMw * powerCoeff * turbine.efficiency;
  
  if (turbine.state === 'CURTAILED') {
    output = output * 0.2;
  }

  return Math.min(turbine.ratedPowerMw, output);
}

/**
 * Calculates total available & actual generation for a wind farm
 * including wake loss factor
 */
export function calculateWindFarmGeneration(
  farm: WindFarmConfig,
  baseWindSpeedMs: number,
  airDensityKgM3: number = STANDARD_AIR_DENSITY
): {
  availableWindMw: number;
  generatedWindMw: number;
  curtailedWindMw: number;
  activeTurbinesCount: number;
} {
  let rawAvailableMw = 0;
  let rawGeneratedMw = 0;
  let activeTurbinesCount = 0;

  farm.turbines.forEach((turbine, idx) => {
    // Micro-siting turbulence / spatial variation across array
    const spatialWindVar = 1.0 + Math.sin(idx * 0.7) * 0.05;
    const turbineWind = Math.max(0, baseWindSpeedMs * spatialWindVar);

    const avail = calculateTurbineOutputMw(
      { ...turbine, state: 'RUNNING' },
      turbineWind,
      airDensityKgM3
    );
    const actual = calculateTurbineOutputMw(turbine, turbineWind, airDensityKgM3);

    rawAvailableMw += avail;
    rawGeneratedMw += actual;

    if (turbine.state === 'RUNNING' || turbine.state === 'CURTAILED' || turbine.state === 'RAMPING') {
      activeTurbinesCount++;
    }
  });

  // Apply wake loss factor
  const wakeEfficiency = 1.0 - farm.wakeLossFactor;
  const availableWindMw = rawAvailableMw * wakeEfficiency;
  const generatedWindMw = rawGeneratedMw * wakeEfficiency;
  const curtailedWindMw = Math.max(0, availableWindMw - generatedWindMw);

  return {
    availableWindMw,
    generatedWindMw,
    curtailedWindMw,
    activeTurbinesCount,
  };
}

/**
 * Generates default 20-turbine Offshore / Onshore Wind Farm
 */
export function createDefaultWindFarm(): WindFarmConfig {
  const turbines: WindTurbine[] = [];
  const modelName = 'Siemens Gamesa SG 8.0-167';

  for (let i = 1; i <= 25; i++) {
    turbines.push({
      id: `turb-${i}`,
      code: `WTG-${i.toString().padStart(2, '0')}`,
      model: modelName,
      ratedPowerMw: 8.0,
      rotorDiameterM: 167.0,
      hubHeightM: 120.0,
      cutInSpeedMs: 3.0,
      ratedSpeedMs: 12.0,
      cutOutSpeedMs: 25.0,
      efficiency: 0.95,
      availabilityPct: i === 18 ? 0.0 : 98.5, // 1 turbine in maintenance
      state: i === 18 ? 'MAINTENANCE' : 'RUNNING',
      currentWindSpeedMs: 11.2,
      activePowerMw: 7.6,
      rotorRpm: 10.5,
      generatorTempC: 62.4,
      vibrationMmS: 1.2,
      cumulativeOperatingHours: 14200 + i * 110,
      minRunTimeMins: 30,
      minDowntimeMins: 15,
      maxRampRateMwPerMin: 1.5,
    });
  }

  return {
    id: 'farm-north-sea-1',
    name: 'North Sea Alpha Wind Array',
    locationName: 'Dogger Bank Zone 2, UK',
    latitude: 54.8123,
    longitude: 2.1456,
    ratedCapacityMw: 200.0, // 25 turbines * 8 MW = 200 MW
    turbines,
    wakeLossFactor: 0.045, // 4.5% wake interaction loss
  };
}
