import {
  WindFarmConfig,
  BatteryState,
  FlexibleLoad,
  StrikeContract,
  DispatchIntervalResult,
  OptimizationRunOutput,
  ConservationCheck,
} from './types';
import { calculateWindFarmGeneration, STANDARD_AIR_DENSITY } from './windEngine';
import { calculateBatteryDegradationCost, updateBatteryState } from './batteryEngine';
import { calculateFlexibleLoadPotential } from './demandEngine';
import { calculateWindShadowPrice, evaluateStrikeDecision } from './marketEngine';

export function runDispatchOptimization(
  farm: WindFarmConfig,
  battery: BatteryState,
  flexibleLoads: FlexibleLoad[],
  strikeContracts: StrikeContract[],
  baseWindSpeedMs: number,
  baseDemandMw: number,
  spotPriceGbp: number,
  horizonHours: number = 24,
  stepMinutes: number = 15
): OptimizationRunOutput {
  const stepsCount = (horizonHours * 60) / stepMinutes;
  const intervalHours = stepMinutes / 60.0;
  const intervals: DispatchIntervalResult[] = [];

  let currentBattery = { ...battery };
  let runId = `run-${Date.now()}`;

  let totalAvailableWindMwh = 0;
  let totalGeneratedWindMwh = 0;
  let totalUsefulWindMwh = 0;
  let totalCurtailedWindMwh = 0;
  
  let totalDemandServedMwh = 0;
  let totalBatteryChargedMwh = 0;
  let totalBatteryDischargedMwh = 0;
  let totalGridImportMwh = 0;
  let totalGridExportMwh = 0;

  let totalSpotRevenueGbp = 0;
  let totalStrikeRevenueGbp = 0;
  let totalGridCostGbp = 0;
  let totalBatteryDegradationCostGbp = 0;
  let strikeOptimizationSavingsGbp = 0;

  for (let i = 0; i < stepsCount; i++) {
    const timeOffsetMins = i * stepMinutes;
    const hour = (Math.floor(timeOffsetMins / 60) + 8) % 24; // starting 08:00
    const minute = timeOffsetMins % 60;
    const timeLabel = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;

    // Diurnal wind speed fluctuation + turbulence noise
    const windNoise = Math.sin(i * 0.15) * 2.2 + Math.cos(i * 0.05) * 1.5;
    const windSpeed = Math.max(2.5, baseWindSpeedMs + windNoise);

    // Diurnal demand profile
    const demandMultiplier = 1.0 + Math.sin(((hour - 6) / 24) * 2 * Math.PI) * 0.35;
    const stepDemandMw = Math.max(10, baseDemandMw * demandMultiplier);

    // Diurnal spot electricity price (£/MWh) with evening peak spike
    let stepSpotPriceGbp = spotPriceGbp;
    if (hour >= 17 && hour <= 20) {
      stepSpotPriceGbp *= 1.45; // Evening peak
    } else if (hour >= 1 && hour <= 5) {
      stepSpotPriceGbp *= 0.65; // Night low
    }
    stepSpotPriceGbp += Math.sin(i * 0.3) * 6.0;

    // 1. Calculate wind farm generation
    const windGen = calculateWindFarmGeneration(farm, windSpeed);
    const availableWindMw = windGen.availableWindMw;
    
    // 2. Determine raw surplus / deficit vs base demand
    const rawNetPowerMw = availableWindMw - stepDemandMw;

    let batteryChargeMw = 0;
    let batteryDischargeMw = 0;
    let gridImportMw = 0;
    let gridExportMw = 0;
    let usefulWindMw = 0;
    let curtailedWindMw = 0;
    let flexLoadShiftMw = 0;

    // 3. Evaluate Strike Contract Decision
    const strikeEval = evaluateStrikeDecision(stepSpotPriceGbp, strikeContracts);
    const activeStrikePrice = strikeEval.chosenPriceGbp;
    if (strikeEval.strikeExercised) {
      strikeOptimizationSavingsGbp += strikeEval.strikeSavingsGbp * intervalHours;
    }

    // 4. Dispatch Optimisation Logic
    if (rawNetPowerMw >= 0) {
      // SURPLUS WIND GENERATION
      // Priority A: Direct demand serving
      usefulWindMw = stepDemandMw;
      let surplusMw = rawNetPowerMw;

      // Priority B: Flexible load shifting to absorb surplus
      const flexResult = calculateFlexibleLoadPotential(flexibleLoads, surplusMw);
      flexLoadShiftMw = flexResult.activeShiftMw;
      usefulWindMw += flexLoadShiftMw;
      surplusMw -= flexLoadShiftMw;

      // Priority C: Battery charging if economically favorable vs degradation cost
      const degCostEstimate = currentBattery.degradationCostPerMwh;
      if (
        surplusMw > 0 &&
        currentBattery.socPct < 95.0 &&
        stepSpotPriceGbp > degCostEstimate * 0.5
      ) {
        const maxChargePossible = Math.min(
          currentBattery.maxChargeMw,
          (currentBattery.maxCapacityMwh * 0.95 - currentBattery.currentCapacityMwh) / intervalHours
        );
        batteryChargeMw = Math.min(surplusMw, maxChargePossible);
        usefulWindMw += batteryChargeMw;
        surplusMw -= batteryChargeMw;
      }

      // Priority D: Export remaining wind to grid
      if (surplusMw > 0) {
        gridExportMw = surplusMw;
        usefulWindMw += gridExportMw;
        surplusMw = 0;
      }

      curtailedWindMw = Math.max(0, availableWindMw - usefulWindMw);
    } else {
      // DEFICIT WIND GENERATION (Wind < Demand)
      usefulWindMw = availableWindMw;
      let deficitMw = stepDemandMw - availableWindMw;

      // Priority A: Battery discharging if spot price > degradation cost
      const degCostEstimate = currentBattery.degradationCostPerMwh;
      if (
        currentBattery.socPct > 10.0 &&
        stepSpotPriceGbp > degCostEstimate
      ) {
        const maxDischargePossible = Math.min(
          currentBattery.maxDischargeMw,
          (currentBattery.currentCapacityMwh - currentBattery.maxCapacityMwh * 0.05) * intervalHours
        );
        batteryDischargeMw = Math.min(deficitMw, maxDischargePossible);
        deficitMw -= batteryDischargeMw;
      }

      // Priority B: Grid import to cover remaining deficit
      if (deficitMw > 0) {
        gridImportMw = deficitMw;
      }
    }

    const generatedWindMw = usefulWindMw;

    // 5. Battery state update & degradation calculation
    const netBatteryPower = batteryChargeMw > 0 ? batteryChargeMw : -batteryDischargeMw;
    const intervalDegCost = calculateBatteryDegradationCost(
      currentBattery,
      netBatteryPower,
      intervalHours
    );

    currentBattery = updateBatteryState(currentBattery, netBatteryPower, intervalHours);

    // 6. Conservation of Energy Validation
    // Generation + Imports + Discharge == Demand + Charging + Exports + Curtailment
    const totalSupplyMwh = (generatedWindMw + gridImportMw + batteryDischargeMw) * intervalHours;
    const totalSinkMwh = (stepDemandMw + flexLoadShiftMw + batteryChargeMw + gridExportMw + curtailedWindMw) * intervalHours;
    const imbalanceMwh = Math.abs(totalSupplyMwh - totalSinkMwh);
    const conservationPassed = imbalanceMwh <= 0.005;

    const conservation: ConservationCheck = {
      totalSupplyMwh,
      totalSinkMwh,
      imbalanceMwh,
      passed: conservationPassed,
      toleranceMwh: 0.005,
    };

    // 7. Calculate Wind Shadow Price
    const shadowPrice = calculateWindShadowPrice(
      stepSpotPriceGbp,
      activeStrikePrice,
      currentBattery.socPct,
      intervalDegCost,
      curtailedWindMw > 1.0
    );

    // 8. Financials
    const spotRevenue = gridExportMw * stepSpotPriceGbp * intervalHours;
    const strikeRevenue = strikeEval.strikeExercised
      ? 50.0 * activeStrikePrice * intervalHours
      : 0;
    const gridCost = gridImportMw * stepSpotPriceGbp * intervalHours;
    const netRevenue = spotRevenue + strikeRevenue - gridCost - intervalDegCost;

    const windUtilisationPct = availableWindMw > 1e-3
      ? (usefulWindMw / availableWindMw) * 100.0
      : 0.0;

    const turbineUtilisationPct = (generatedWindMw / farm.ratedCapacityMw) * 100.0;

    // Accumulate totals
    totalAvailableWindMwh += availableWindMw * intervalHours;
    totalGeneratedWindMwh += generatedWindMw * intervalHours;
    totalUsefulWindMwh += usefulWindMw * intervalHours;
    totalCurtailedWindMwh += curtailedWindMw * intervalHours;

    totalDemandServedMwh += (stepDemandMw + flexLoadShiftMw) * intervalHours;
    totalBatteryChargedMwh += batteryChargeMw * intervalHours;
    totalBatteryDischargedMwh += batteryDischargeMw * intervalHours;
    totalGridImportMwh += gridImportMw * intervalHours;
    totalGridExportMwh += gridExportMw * intervalHours;

    totalSpotRevenueGbp += spotRevenue;
    totalStrikeRevenueGbp += strikeRevenue;
    totalGridCostGbp += gridCost;
    totalBatteryDegradationCostGbp += intervalDegCost;

    intervals.push({
      timestamp: new Date(Date.now() + timeOffsetMins * 60000).toISOString(),
      timeLabel,
      windSpeedMs: Number(windSpeed.toFixed(2)),
      airDensityKgM3: STANDARD_AIR_DENSITY,
      availableWindMw: Number(availableWindMw.toFixed(2)),
      generatedWindMw: Number(generatedWindMw.toFixed(2)),
      usefulWindMw: Number(usefulWindMw.toFixed(2)),
      curtailedWindMw: Number(curtailedWindMw.toFixed(2)),

      baseDemandMw: Number(stepDemandMw.toFixed(2)),
      flexibleLoadShiftMw: Number(flexLoadShiftMw.toFixed(2)),
      totalDemandServedMw: Number((stepDemandMw + flexLoadShiftMw).toFixed(2)),

      batteryChargeMw: Number(batteryChargeMw.toFixed(2)),
      batteryDischargeMw: Number(batteryDischargeMw.toFixed(2)),
      batterySocPct: Number(currentBattery.socPct.toFixed(1)),
      batteryDegradationCostGbp: Number(intervalDegCost.toFixed(2)),

      gridImportMw: Number(gridImportMw.toFixed(2)),
      gridExportMw: Number(gridExportMw.toFixed(2)),

      spotPriceGbp: Number(stepSpotPriceGbp.toFixed(2)),
      activeStrikePriceGbp: Number(activeStrikePrice.toFixed(2)),
      strikeExercised: strikeEval.strikeExercised,
      strikeSavingsGbp: Number(strikeEval.strikeSavingsGbp.toFixed(2)),

      windShadowPriceGbp: Number(shadowPrice.effectiveShadowPriceGbp.toFixed(2)),

      windUtilisationPct: Number(windUtilisationPct.toFixed(1)),
      turbineUtilisationPct: Number(turbineUtilisationPct.toFixed(1)),

      netRevenueGbp: Number(netRevenue.toFixed(2)),
      systemValueGbp: Number((netRevenue + shadowPrice.effectiveShadowPriceGbp * 10).toFixed(2)),
      solverStatus: 'OPTIMAL',
      conservation,
    });
  }

  const overallWindUtilisationPct =
    totalAvailableWindMwh > 0
      ? (totalUsefulWindMwh / totalAvailableWindMwh) * 100.0
      : 0.0;

  const overallTurbineUtilisationPct =
    (totalGeneratedWindMwh / (farm.ratedCapacityMw * horizonHours)) * 100.0;

  const netSystemValueGbp =
    totalSpotRevenueGbp + totalStrikeRevenueGbp - totalGridCostGbp - totalBatteryDegradationCostGbp;

  const conservationVerified = intervals.every((i) => i.conservation.passed);

  return {
    runId,
    timestamp: new Date().toISOString(),
    horizonHours,
    stepMinutes,
    intervals,
    summary: {
      totalAvailableWindMwh: Number(totalAvailableWindMwh.toFixed(2)),
      totalGeneratedWindMwh: Number(totalGeneratedWindMwh.toFixed(2)),
      totalUsefulWindMwh: Number(totalUsefulWindMwh.toFixed(2)),
      totalCurtailedWindMwh: Number(totalCurtailedWindMwh.toFixed(2)),
      windUtilisationPct: Number(overallWindUtilisationPct.toFixed(1)),
      turbineUtilisationPct: Number(overallTurbineUtilisationPct.toFixed(1)),

      totalDemandServedMwh: Number(totalDemandServedMwh.toFixed(2)),
      totalBatteryChargedMwh: Number(totalBatteryChargedMwh.toFixed(2)),
      totalBatteryDischargedMwh: Number(totalBatteryDischargedMwh.toFixed(2)),
      totalGridImportMwh: Number(totalGridImportMwh.toFixed(2)),
      totalGridExportMwh: Number(totalGridExportMwh.toFixed(2)),

      totalSpotRevenueGbp: Number(totalSpotRevenueGbp.toFixed(2)),
      totalStrikeRevenueGbp: Number(totalStrikeRevenueGbp.toFixed(2)),
      totalGridCostGbp: Number(totalGridCostGbp.toFixed(2)),
      totalBatteryDegradationCostGbp: Number(totalBatteryDegradationCostGbp.toFixed(2)),
      netSystemValueGbp: Number(netSystemValueGbp.toFixed(2)),

      strikeOptimizationSavingsGbp: Number(strikeOptimizationSavingsGbp.toFixed(2)),
      conservationVerified,
    },
  };
}
