import { FlexibleLoad } from './types';

export function createDefaultFlexibleLoads(): FlexibleLoad[] {
  return [
    {
      id: 'flex-1',
      name: 'Hydrogen Electrolyser Unit A',
      category: 'INDUSTRIAL',
      powerMw: 35.0,
      isMoveable: true,
      canWaitHours: 6,
      mustRunByHour: 22,
      priority: 1,
      isCurrentActive: true,
    },
    {
      id: 'flex-2',
      name: 'Green Data Center Compute Cluster',
      category: 'DATA_CENTER',
      powerMw: 25.0,
      isMoveable: true,
      canWaitHours: 4,
      mustRunByHour: 18,
      priority: 2,
      isCurrentActive: true,
    },
    {
      id: 'flex-3',
      name: 'District Thermal Storage Pump',
      category: 'THERMAL_STORE',
      powerMw: 18.0,
      isMoveable: true,
      canWaitHours: 12,
      mustRunByHour: 24,
      priority: 3,
      isCurrentActive: false,
    },
    {
      id: 'flex-4',
      name: 'EV Fleet Depot Fast Chargers',
      category: 'EV_CHARGING',
      powerMw: 15.0,
      isMoveable: true,
      canWaitHours: 3,
      mustRunByHour: 8,
      priority: 4,
      isCurrentActive: true,
    },
  ];
}

/**
 * Calculates total flexible load available for shift to absorb excess wind
 */
export function calculateFlexibleLoadPotential(
  loads: FlexibleLoad[],
  availableExcessWindMw: number
): {
  activeShiftMw: number;
  activatedLoadsCount: number;
} {
  let activeShiftMw = 0;
  let activatedLoadsCount = 0;
  let remainingSurplus = availableExcessWindMw;

  // Sort by priority (1 = highest priority to consume surplus wind)
  const sortedLoads = [...loads].sort((a, b) => a.priority - b.priority);

  for (const load of sortedLoads) {
    if (load.isMoveable && remainingSurplus > 5.0) {
      const takeMw = Math.min(load.powerMw, remainingSurplus);
      activeShiftMw += takeMw;
      remainingSurplus -= takeMw;
      activatedLoadsCount++;
    }
  }

  return { activeShiftMw, activatedLoadsCount };
}
