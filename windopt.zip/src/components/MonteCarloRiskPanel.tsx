import React, { useState, useEffect } from 'react';
import { BarChart3, RefreshCw, Layers } from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { MonteCarloScenarioResult } from '../engine/types';

export const MonteCarloRiskPanel: React.FC = () => {
  const [data, setData] = useState<MonteCarloScenarioResult | null>(null);
  const [sims, setSims] = useState<number>(2000);
  const [vol, setVol] = useState<number>(35.0);
  const [loading, setLoading] = useState<boolean>(false);

  const fetchMonteCarlo = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/monte-carlo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ numSimulations: sims, spotVolatility: vol }),
      });
      const json = await res.json();
      setData(json);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMonteCarlo();
  }, []);

  return (
    <div className="space-y-6 font-mono">
      {/* Header */}
      <div className="bg-[#16191E] border border-[#2A2D35] p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-mono font-bold text-[#F27D26] uppercase tracking-[0.2em] block mb-1">
            R STATISTICAL FORECASTING & STOCHASTIC MONTE CARLO LAYER
          </span>
          <h2 className="text-2xl font-black text-white italic flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-[#F27D26]" />
            R Monte Carlo Risk Analytics (2,000 Scenarios)
          </h2>
          <p className="text-xs text-[#6A6E7A]">
            Evaluating Value at Risk (VaR 95%), downside probability distribution & curtailment exposure
          </p>
        </div>

        <button
          onClick={fetchMonteCarlo}
          disabled={loading}
          className="bg-[#F27D26] hover:bg-[#d96c1e] text-black font-extrabold px-4 py-2 text-xs font-mono tracking-wider uppercase border border-[#F27D26] transition-colors flex items-center gap-2 disabled:opacity-50"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          {loading ? 'RE-RUNNING R ENGINE...' : 'RUN MONTE CARLO'}
        </button>
      </div>

      {data && (
        <>
          {/* Key Risk Indicators Grid matching Bold Typography Spec */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-4">
            <div className="bg-[#16191E] border border-[#2A2D35] p-4">
              <span className="text-[10px] text-[#6A6E7A] uppercase font-bold block mb-1">EXPECTED SYSTEM VALUE</span>
              <div className="text-3xl font-light tracking-tighter text-white">
                £{data.expectedSystemValueGbp.toLocaleString()}
              </div>
            </div>

            <div className="bg-[#16191E] border border-[#2A2D35] p-4">
              <span className="text-[10px] text-[#6A6E7A] uppercase font-bold block mb-1">VALUE AT RISK (VaR 95%)</span>
              <div className="text-3xl font-light tracking-tighter text-[#F27D26]">
                £{data.var95Gbp.toLocaleString()}
              </div>
            </div>

            <div className="bg-[#16191E] border border-[#2A2D35] p-4">
              <span className="text-[10px] text-[#6A6E7A] uppercase font-bold block mb-1">DOWNSIDE RISK GAP</span>
              <div className="text-3xl font-light tracking-tighter text-[#F27D26]">
                £{data.downsideRiskGbp.toLocaleString()}
              </div>
            </div>

            <div className="bg-[#16191E] border border-[#2A2D35] p-4">
              <span className="text-[10px] text-[#6A6E7A] uppercase font-bold block mb-1">CURTAILMENT PROBABILITY</span>
              <div className="text-3xl font-light tracking-tighter text-[#00FF41]">
                {data.probCurtailmentPct}%
              </div>
            </div>

            <div className="bg-[#16191E] border border-[#2A2D35] p-4">
              <span className="text-[10px] text-[#6A6E7A] uppercase font-bold block mb-1">GRID IMPORT PROBABILITY</span>
              <div className="text-3xl font-light tracking-tighter text-[#E0E0E0]">
                {data.probGridImportPct}%
              </div>
            </div>
          </div>

          {/* Probability Distribution Chart */}
          <div className="bg-[#16191E] border border-[#2A2D35] p-5">
            <h3 className="text-xs font-mono uppercase tracking-[0.2em] text-[#6A6E7A] mb-3 border-l-2 border-[#F27D26] pl-3 font-bold">
              System Revenue Stochastic Probability Distribution (Histogram)
            </h3>

            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data.distributionHistogram}>
                  <CartesianGrid strokeDasharray="2 2" stroke="#2A2D35" />
                  <XAxis dataKey="binLabel" stroke="#6A6E7A" tick={{ fontSize: 10 }} />
                  <YAxis stroke="#6A6E7A" tick={{ fontSize: 10 }} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#16191E', borderColor: '#2A2D35', borderRadius: '0px', color: '#E0E0E0', fontSize: '11px', fontFamily: 'monospace' }}
                  />
                  <Bar dataKey="count" name="Frequency Count" fill="#F27D26" radius={[0, 0, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
