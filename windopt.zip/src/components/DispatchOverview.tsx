import React, { useState } from 'react';
import {
  Wind,
  TrendingUp,
  ShieldCheck,
  CheckCircle2,
  Zap,
} from 'lucide-react';
import {
  ResponsiveContainer,
  ComposedChart,
  Area,
  Line,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
} from 'recharts';
import { OptimizationRunOutput, DispatchIntervalResult } from '../engine/types';

interface DispatchOverviewProps {
  optRun: OptimizationRunOutput;
  onUpdateScenario: (windSpeed: number, demand: number, spotPrice: number) => void;
  baseWindSpeed: number;
  baseDemand: number;
  spotPrice: number;
}

export const DispatchOverview: React.FC<DispatchOverviewProps> = ({
  optRun,
  onUpdateScenario,
  baseWindSpeed,
  baseDemand,
  spotPrice,
}) => {
  const currentInterval: DispatchIntervalResult =
    optRun.intervals[0] || ({
      availableWindMw: 184.0,
      generatedWindMw: 176.0,
      curtailedWindMw: 8.0,
      baseDemandMw: 121.0,
      flexibleLoadShiftMw: 0.0,
      batteryChargeMw: 42.0,
      batteryDischargeMw: 0.0,
      batterySocPct: 71.0,
      gridImportMw: 0.0,
      gridExportMw: 13.0,
      spotPriceGbp: 96.0,
      activeStrikePriceGbp: 82.5,
      windUtilisationPct: 95.6,
      turbineUtilisationPct: 95.7,
      systemValueGbp: 142850,
      solverStatus: 'OPTIMAL',
    } as any);

  const [localWind, setLocalWind] = useState(baseWindSpeed);
  const [localDemand, setLocalDemand] = useState(baseDemand);
  const [localSpot, setLocalSpot] = useState(spotPrice);

  const handleSliderChange = (wind: number, dem: number, spot: number) => {
    setLocalWind(wind);
    setLocalDemand(dem);
    setLocalSpot(spot);
    onUpdateScenario(wind, dem, spot);
  };

  const strikeDelta = currentInterval.spotPriceGbp - currentInterval.activeStrikePriceGbp;

  return (
    <div className="space-y-6">
      {/* 1. Top Section Grid matching Bold Typography Spec */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Col 1: Wind Utilisation + Live Dispatch Board */}
        <div className="md:col-span-4 flex flex-col gap-4">
          <div className="bg-[#16191E] border border-[#2A2D35] p-5 flex flex-col justify-between">
            <p className="text-[11px] font-mono text-[#F27D26] uppercase font-bold tracking-wider">
              Wind Utilisation
            </p>
            <div className="flex items-baseline gap-2 mt-2">
              <span className="text-6xl font-light tracking-tighter text-white">
                {currentInterval.windUtilisationPct.toFixed(1)}
              </span>
              <span className="text-2xl text-[#6A6E7A] font-mono">%</span>
            </div>
            <div className="mt-4 h-1.5 bg-[#2A2D35] w-full">
              <div
                className="h-full bg-[#F27D26]"
                style={{ width: `${Math.min(100, currentInterval.windUtilisationPct)}%` }}
              ></div>
            </div>
          </div>

          <div className="bg-[#16191E] border border-[#2A2D35] p-5">
            <p className="text-[11px] font-mono text-[#00FF41] uppercase mb-4 font-bold tracking-wider">
              Live Dispatch Board (MW)
            </p>
            <div className="space-y-3 font-mono text-xs">
              <div className="flex justify-between border-b border-[#2A2D35] pb-2">
                <span className="text-[#6A6E7A]">WIND → DEMAND</span>
                <span className="text-white font-bold">{currentInterval.generatedWindMw.toFixed(1)}</span>
              </div>
              <div className="flex justify-between border-b border-[#2A2D35] pb-2">
                <span className="text-[#6A6E7A]">WIND → BATTERY</span>
                <span className="text-white font-bold">{currentInterval.batteryChargeMw.toFixed(1)}</span>
              </div>
              <div className="flex justify-between border-b border-[#2A2D35] pb-2">
                <span className="text-[#6A6E7A]">WIND → GRID EXPORT</span>
                <span className="text-white font-bold">{currentInterval.gridExportMw.toFixed(1)}</span>
              </div>
              <div className="flex justify-between border-b border-[#2A2D35] pb-2">
                <span className="text-[#F27D26]">WIND → CURTAILMENT</span>
                <span className="text-[#F27D26] font-bold">{currentInterval.curtailedWindMw.toFixed(1)}</span>
              </div>
              <div className="flex justify-between pt-2 text-white font-bold">
                <span>TOTAL AVAILABLE OUTPUT</span>
                <span className="text-[#00FF41]">{currentInterval.availableWindMw.toFixed(1)}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Col 2: Market Pricing & Strike Opportunity Highlight */}
        <div className="md:col-span-8 flex flex-col gap-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-[#16191E] border border-[#2A2D35] p-5 flex flex-col justify-between">
              <span className="text-[11px] font-mono uppercase text-[#6A6E7A] tracking-wider font-bold">
                Market Spot Pricing
              </span>
              <div className="flex justify-between items-end mt-4">
                <div className="text-4xl font-black text-white font-mono">
                  £{currentInterval.spotPriceGbp.toFixed(2)}
                  <span className="text-xs font-normal text-[#6A6E7A] ml-1">/MWh</span>
                </div>
                <div className="text-right">
                  <p className="text-[10px] font-mono text-[#00FF41] font-bold">SPOT ACTIVE</p>
                  <p className="text-xs text-[#6A6E7A] font-mono">UK N2EX ZONE</p>
                </div>
              </div>
            </div>

            <div className="bg-[#F27D26] border border-[#F27D26] p-5 flex flex-col justify-between text-black">
              <span className="text-[11px] font-mono uppercase font-bold tracking-wider">
                Strike Opportunity Value
              </span>
              <div className="flex justify-between items-end mt-4">
                <div className="text-4xl font-black italic">
                  £{currentInterval.activeStrikePriceGbp.toFixed(2)}
                  <span className="text-xs font-normal ml-1">/MWh</span>
                </div>
                <div className="text-right">
                  <p className="text-[10px] font-mono font-bold">STRIKE DELTA</p>
                  <p className="text-xs font-bold">
                    {strikeDelta >= 0 ? `+£${strikeDelta.toFixed(2)} GAIN` : `£${strikeDelta.toFixed(2)} SPOT`}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Interactive Scenario Controls */}
          <div className="bg-[#16191E] border border-[#2A2D35] p-5 font-mono text-xs">
            <p className="text-[11px] font-mono text-[#6A6E7A] uppercase mb-3 tracking-wider font-bold">
              Dispatch Scenario Sliders
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="text-[#6A6E7A] block mb-1">
                  WIND SPEED: <span className="text-white font-bold">{localWind} m/s</span>
                </label>
                <input
                  type="range"
                  min="3"
                  max="25"
                  step="0.5"
                  value={localWind}
                  onChange={(e) => handleSliderChange(parseFloat(e.target.value), localDemand, localSpot)}
                  className="w-full accent-[#F27D26] cursor-pointer"
                />
              </div>
              <div>
                <label className="text-[#6A6E7A] block mb-1">
                  DEMAND: <span className="text-white font-bold">{localDemand} MW</span>
                </label>
                <input
                  type="range"
                  min="20"
                  max="250"
                  step="5"
                  value={localDemand}
                  onChange={(e) => handleSliderChange(localWind, parseFloat(e.target.value), localSpot)}
                  className="w-full accent-[#F27D26] cursor-pointer"
                />
              </div>
              <div>
                <label className="text-[#6A6E7A] block mb-1">
                  SPOT PRICE: <span className="text-[#00FF41] font-bold">£{localSpot}/MWh</span>
                </label>
                <input
                  type="range"
                  min="10"
                  max="300"
                  step="5"
                  value={localSpot}
                  onChange={(e) => handleSliderChange(localWind, localDemand, parseFloat(e.target.value))}
                  className="w-full accent-[#00FF41] cursor-pointer"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Main 24-Hour Horizon Power Dispatch & Market Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 1: Power Dispatch Horizon */}
        <div className="bg-[#16191E] p-5 border border-[#2A2D35]">
          <div className="flex items-center justify-between mb-4 border-b border-[#2A2D35] pb-3">
            <div>
              <h3 className="text-xs font-mono uppercase tracking-[0.2em] text-[#6A6E7A] border-l-2 border-[#F27D26] pl-3">
                Power Dispatch & Load Balancing
              </h3>
            </div>
            <span className="text-[10px] font-mono text-[#00FF41] bg-[#0F1115] border border-[#2A2D35] px-2 py-0.5">
              15-MIN MPC
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={optRun.intervals}>
                <CartesianGrid strokeDasharray="2 2" stroke="#2A2D35" />
                <XAxis dataKey="timeLabel" stroke="#6A6E7A" tick={{ fontSize: 10 }} />
                <YAxis stroke="#6A6E7A" tick={{ fontSize: 10 }} unit=" MW" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#16191E', borderColor: '#2A2D35', borderRadius: '0px', color: '#E0E0E0', fontSize: '11px', fontFamily: 'monospace' }}
                />
                <Legend wrapperStyle={{ fontSize: '10px', fontFamily: 'monospace', paddingTop: '8px' }} />
                <Area type="monotone" dataKey="availableWindMw" name="Available Wind" fill="#F27D26" fillOpacity={0.15} stroke="#F27D26" strokeWidth={2} />
                <Bar dataKey="generatedWindMw" name="Useful Generation" fill="#00FF41" radius={[0, 0, 0, 0]} />
                <Line type="monotone" dataKey="totalDemandServedMw" name="Total Demand" stroke="#FFFFFF" strokeWidth={2} dot={false} />
                <Bar dataKey="curtailedWindMw" name="Curtailment" fill="#F27D26" opacity={0.8} />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Electricity Spot vs Strike Price & Wind Shadow Price */}
        <div className="bg-[#16191E] p-5 border border-[#2A2D35]">
          <div className="flex items-center justify-between mb-4 border-b border-[#2A2D35] pb-3">
            <div>
              <h3 className="text-xs font-mono uppercase tracking-[0.2em] text-[#6A6E7A] border-l-2 border-[#00FF41] pl-3">
                Strike vs Spot Opportunity Cost
              </h3>
            </div>
            <span className="text-[10px] font-mono text-[#F27D26] bg-[#0F1115] border border-[#2A2D35] px-2 py-0.5">
              ECONOMIC SHADOW PRICE
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={optRun.intervals}>
                <CartesianGrid strokeDasharray="2 2" stroke="#2A2D35" />
                <XAxis dataKey="timeLabel" stroke="#6A6E7A" tick={{ fontSize: 10 }} />
                <YAxis stroke="#6A6E7A" tick={{ fontSize: 10 }} unit=" £" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#16191E', borderColor: '#2A2D35', borderRadius: '0px', color: '#E0E0E0', fontSize: '11px', fontFamily: 'monospace' }}
                />
                <Legend wrapperStyle={{ fontSize: '10px', fontFamily: 'monospace', paddingTop: '8px' }} />
                <Line type="monotone" dataKey="spotPriceGbp" name="Spot Price (£/MWh)" stroke="#00FF41" strokeWidth={2} dot={false} />
                <Line type="stepAfter" dataKey="activeStrikePriceGbp" name="Strike Price (£/MWh)" stroke="#F27D26" strokeWidth={2} strokeDasharray="4 4" />
                <Line type="monotone" dataKey="windShadowPriceGbp" name="Wind Shadow Price" stroke="#FFFFFF" strokeWidth={1.5} dot={false} />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* 3. Detailed Energy Accounting Summary Table */}
      <div className="bg-[#16191E] p-5 border border-[#2A2D35] font-mono text-xs">
        <h3 className="text-xs font-mono uppercase tracking-[0.2em] text-[#6A6E7A] mb-4 border-l-2 border-[#F27D26] pl-3 font-bold">
          Energy Accounting & System Margin Report
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-[#0F1115] p-4 border border-[#2A2D35]">
          <div>
            <span className="text-[#6A6E7A] block mb-2 text-[10px] uppercase font-bold tracking-wider">RENEWABLE GENERATION:</span>
            <div className="space-y-1.5 text-[#E0E0E0]">
              <div className="flex justify-between">
                <span>Total Available Wind:</span>
                <span className="text-white font-bold">{optRun.summary.totalAvailableWindMwh} MWh</span>
              </div>
              <div className="flex justify-between">
                <span>Total Useful Generation:</span>
                <span className="text-[#00FF41] font-bold">{optRun.summary.totalUsefulWindMwh} MWh</span>
              </div>
              <div className="flex justify-between">
                <span>Total Curtailed Wind:</span>
                <span className="text-[#F27D26] font-bold">{optRun.summary.totalCurtailedWindMwh} MWh</span>
              </div>
              <div className="flex justify-between pt-2 border-t border-[#2A2D35]">
                <span>Wind Utilisation Ratio:</span>
                <span className="text-[#F27D26] font-bold">{optRun.summary.windUtilisationPct}%</span>
              </div>
            </div>
          </div>

          <div>
            <span className="text-[#6A6E7A] block mb-2 text-[10px] uppercase font-bold tracking-wider">BATTERY & GRID BALANCING:</span>
            <div className="space-y-1.5 text-[#E0E0E0]">
              <div className="flex justify-between">
                <span>Battery Charge Throughput:</span>
                <span className="text-white font-bold">{optRun.summary.totalBatteryChargedMwh} MWh</span>
              </div>
              <div className="flex justify-between">
                <span>Battery Discharge Throughput:</span>
                <span className="text-white font-bold">{optRun.summary.totalBatteryDischargedMwh} MWh</span>
              </div>
              <div className="flex justify-between">
                <span>Total Grid Exports:</span>
                <span className="text-[#00FF41] font-bold">{optRun.summary.totalGridExportMwh} MWh</span>
              </div>
              <div className="flex justify-between pt-2 border-t border-[#2A2D35]">
                <span>Total Grid Imports:</span>
                <span className="text-[#F27D26] font-bold">{optRun.summary.totalGridImportMwh} MWh</span>
              </div>
            </div>
          </div>

          <div>
            <span className="text-[#6A6E7A] block mb-2 text-[10px] uppercase font-bold tracking-wider">SYSTEM MARGIN & FINANCIALS:</span>
            <div className="space-y-1.5 text-[#E0E0E0]">
              <div className="flex justify-between">
                <span>Spot Market Revenue:</span>
                <span className="text-[#00FF41] font-bold">£{optRun.summary.totalSpotRevenueGbp.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span>Strike Savings:</span>
                <span className="text-[#F27D26] font-bold">£{optRun.summary.strikeOptimizationSavingsGbp.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span>Battery Degradation Cost:</span>
                <span className="text-[#6A6E7A] font-bold">-£{optRun.summary.totalBatteryDegradationCostGbp.toLocaleString()}</span>
              </div>
              <div className="flex justify-between pt-2 border-t border-[#2A2D35]">
                <span className="font-bold text-white">NET SYSTEM VALUE:</span>
                <span className="text-2xl font-light tracking-tighter text-white">£{optRun.summary.netSystemValueGbp.toLocaleString()}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
