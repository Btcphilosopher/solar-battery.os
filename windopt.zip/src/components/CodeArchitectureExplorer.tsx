import React, { useState, useEffect } from 'react';
import { Terminal, FileCode, Database, Cpu } from 'lucide-react';

export const CodeArchitectureExplorer: React.FC = () => {
  const [rustCrates, setRustCrates] = useState<any[]>([]);
  const [rModels, setRModels] = useState<any[]>([]);
  const [postgresSchema, setPostgresSchema] = useState<string>('');
  const [activeTab, setActiveTab] = useState<'rust' | 'r' | 'sql'>('rust');
  const [selectedFile, setSelectedFile] = useState<string>('wind_engine');

  useEffect(() => {
    fetch('/api/rust-crates').then(r => r.json()).then(d => setRustCrates(d.crates || []));
    fetch('/api/r-models').then(r => r.json()).then(d => setRModels(d.models || []));
    fetch('/api/postgres-schema').then(r => r.json()).then(d => setPostgresSchema(d.ddl || ''));
  }, []);

  return (
    <div className="space-y-6 font-mono text-xs">
      <div className="bg-[#16191E] border border-[#2A2D35] p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-mono font-bold text-[#F27D26] uppercase tracking-[0.2em] block mb-1">
            INDUSTRIAL CODEBASE ARCHITECTURE
          </span>
          <h2 className="text-2xl font-black text-white italic flex items-center gap-2">
            <Cpu className="w-5 h-5 text-[#F27D26]" />
            Rust Crates + R Quantitative Models + PostgreSQL/PostGIS DDL
          </h2>
          <p className="text-[#6A6E7A] text-xs mt-1">
            Inspect high-performance Rust domain crates, R forecasting scripts, and PostGIS database tables
          </p>
        </div>

        <div className="flex items-center gap-1 bg-[#0F1115] p-1 border border-[#2A2D35]">
          <button
            onClick={() => setActiveTab('rust')}
            className={`px-3 py-1.5 font-mono font-bold uppercase transition-colors ${activeTab === 'rust' ? 'bg-[#F27D26] text-black' : 'text-[#6A6E7A] hover:text-white'}`}
          >
            Rust Workspace (12 Crates)
          </button>
          <button
            onClick={() => setActiveTab('r')}
            className={`px-3 py-1.5 font-mono font-bold uppercase transition-colors ${activeTab === 'r' ? 'bg-[#F27D26] text-black' : 'text-[#6A6E7A] hover:text-white'}`}
          >
            R Statistical Models
          </button>
          <button
            onClick={() => setActiveTab('sql')}
            className={`px-3 py-1.5 font-mono font-bold uppercase transition-colors ${activeTab === 'sql' ? 'bg-[#F27D26] text-black' : 'text-[#6A6E7A] hover:text-white'}`}
          >
            PostgreSQL / PostGIS Schema
          </button>
        </div>
      </div>

      <div className="bg-[#16191E] border border-[#2A2D35] overflow-hidden grid grid-cols-1 md:grid-cols-4 min-h-[480px]">
        {/* Sidebar file tree */}
        <div className="bg-[#0F1115] border-r border-[#2A2D35] p-4 space-y-1.5">
          <span className="text-[#6A6E7A] font-bold block mb-3 uppercase tracking-wider text-[10px]">
            {activeTab === 'rust' ? 'RUST CRATES' : activeTab === 'r' ? 'R SCRIPTS' : 'SQL SCHEMA'}
          </span>

          {activeTab === 'rust' &&
            rustCrates.map((crate) => (
              <button
                key={crate.name}
                onClick={() => setSelectedFile(crate.name)}
                className={`w-full text-left px-3 py-2 transition-all flex items-center gap-2 font-mono ${
                  selectedFile === crate.name ? 'bg-[#16191E] text-[#F27D26] font-bold border-l-2 border-[#F27D26]' : 'text-[#6A6E7A] hover:text-white hover:bg-[#16191E]'
                }`}
              >
                <Terminal className="w-3.5 h-3.5" />
                {crate.name}
              </button>
            ))}

          {activeTab === 'r' &&
            rModels.map((m) => (
              <button
                key={m.file}
                onClick={() => setSelectedFile(m.file)}
                className={`w-full text-left px-3 py-2 transition-all flex items-center gap-2 font-mono ${
                  selectedFile === m.file ? 'bg-[#16191E] text-[#F27D26] font-bold border-l-2 border-[#F27D26]' : 'text-[#6A6E7A] hover:text-white hover:bg-[#16191E]'
                }`}
              >
                <FileCode className="w-3.5 h-3.5" />
                {m.file}
              </button>
            ))}

          {activeTab === 'sql' && (
            <div className="text-[#00FF41] font-bold p-2 bg-[#16191E] border border-[#2A2D35] flex items-center gap-2">
              <Database className="w-3.5 h-3.5" /> 001_init.sql
            </div>
          )}
        </div>

        {/* Code View Area */}
        <div className="md:col-span-3 p-5 bg-[#0F1115] overflow-auto font-mono text-xs">
          <pre className="text-[#E0E0E0] leading-relaxed font-mono whitespace-pre-wrap">
            {activeTab === 'rust' &&
              (rustCrates.find((c) => c.name === selectedFile)?.libContent || '// Select a Rust crate to view lib.rs source code')}

            {activeTab === 'r' &&
              (rModels.find((m) => m.file === selectedFile)?.content || '// Select an R script to view model source code')}

            {activeTab === 'sql' && postgresSchema}
          </pre>
        </div>
      </div>
    </div>
  );
};
