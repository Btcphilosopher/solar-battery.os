import React, { useState } from 'react';
import { TrendingUp, Plus, ShieldCheck } from 'lucide-react';
import { StrikeContract } from '../engine/types';

interface StrikePriceOptimiserProps {
  strikeContracts: StrikeContract[];
  spotPriceGbp: number;
  onAddStrikeContract: (code: string, price: number, volume: number) => void;
}

export const StrikePriceOptimiser: React.FC<StrikePriceOptimiserProps> = ({
  strikeContracts,
  spotPriceGbp,
  onAddStrikeContract,
}) => {
  const [code, setCode] = useState('CFD-2026-UK-E01');
  const [price, setPrice] = useState(82.5);
  const [volume, setVolume] = useState(100);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddStrikeContract(code, price, volume);
  };

  return (
    <div className="space-y-6 font-mono text-xs">
      {/* Top Banner */}
      <div className="bg-[#16191E] border border-[#2A2D35] p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-mono font-bold text-[#F27D26] uppercase tracking-[0.2em] block mb-1">
            STRIKE CONTRACT & CFD ARBITRAGE SOLVER
          </span>
          <h2 className="text-2xl font-black text-white italic flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-[#F27D26]" />
            Bilateral Electricity Strike Contracts & CFD Hedging
          </h2>
          <p className="text-[#6A6E7A] text-xs">
            Optimising physical vs financial settlement to capture positive spread when Spot &gt; Strike
          </p>
        </div>

        <div className="bg-[#F27D26] text-black border border-[#F27D26] p-4 text-right">
          <span className="text-[10px] font-mono uppercase font-bold tracking-wider block">CURRENT SPOT PRICE</span>
          <span className="text-3xl font-black italic">£{spotPriceGbp.toFixed(2)} /MWh</span>
        </div>
      </div>

      {/* Contract Form & List */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Add Contract Form */}
        <div className="bg-[#16191E] border border-[#2A2D35] p-5 space-y-4">
          <h3 className="text-xs font-mono uppercase tracking-[0.2em] text-[#6A6E7A] border-l-2 border-[#F27D26] pl-3 font-bold">
            New Strike Contract
          </h3>

          <form onSubmit={handleSubmit} className="space-y-3">
            <div>
              <label className="text-[#6A6E7A] block mb-1 uppercase font-bold">Contract Code:</label>
              <input
                type="text"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                className="w-full bg-[#0F1115] border border-[#2A2D35] p-2 text-white font-mono focus:border-[#F27D26] outline-none"
              />
            </div>

            <div>
              <label className="text-[#6A6E7A] block mb-1 uppercase font-bold">Strike Price (£/MWh):</label>
              <input
                type="number"
                step="0.5"
                value={price}
                onChange={(e) => setPrice(parseFloat(e.target.value))}
                className="w-full bg-[#0F1115] border border-[#2A2D35] p-2 text-white font-mono focus:border-[#F27D26] outline-none"
              />
            </div>

            <div>
              <label className="text-[#6A6E7A] block mb-1 uppercase font-bold">Contract Volume (MWh):</label>
              <input
                type="number"
                step="10"
                value={volume}
                onChange={(e) => setVolume(parseFloat(e.target.value))}
                className="w-full bg-[#0F1115] border border-[#2A2D35] p-2 text-white font-mono focus:border-[#F27D26] outline-none"
              />
            </div>

            <button
              type="submit"
              className="w-full bg-[#F27D26] hover:bg-[#d96c1e] text-black font-extrabold py-2.5 uppercase font-mono tracking-wider transition-colors flex items-center justify-center gap-2"
            >
              <Plus className="w-4 h-4" /> Add Strike Contract
            </button>
          </form>
        </div>

        {/* Right: Contract Cards */}
        <div className="lg:col-span-2 space-y-3">
          <h3 className="text-xs font-mono uppercase tracking-[0.2em] text-[#6A6E7A] border-l-2 border-[#00FF41] pl-3 mb-4 font-bold">
            Active Strike Contracts ({strikeContracts.length})
          </h3>

          <div className="space-y-3">
            {strikeContracts.map((contract) => {
              const delta = spotPriceGbp - contract.strikePriceGbpPerMwh;
              const isFavorable = delta > 0;
              return (
                <div
                  key={contract.id}
                  className="bg-[#16191E] border border-[#2A2D35] p-4 flex flex-wrap items-center justify-between gap-4 font-mono"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-black text-white text-sm">{contract.contractCode}</span>
                      <span className="text-[10px] text-[#6A6E7A] border border-[#2A2D35] px-2 py-0.5 uppercase">
                        {contract.counterparty}
                      </span>
                    </div>
                    <p className="text-xs text-[#6A6E7A] mt-1">
                      Delivery Window: {contract.deliveryStart} - {contract.deliveryEnd} | Minimum Delivery: {contract.minimumDeliveryPct}%
                    </p>
                  </div>

                  <div className="flex items-center gap-6">
                    <div>
                      <span className="text-[#6A6E7A] block text-[10px] uppercase">STRIKE PRICE</span>
                      <span className="text-xl font-bold text-white">£{contract.strikePriceGbpPerMwh.toFixed(2)}</span>
                    </div>

                    <div>
                      <span className="text-[#6A6E7A] block text-[10px] uppercase">ARBITRAGE DELTA</span>
                      <span className={`text-xl font-bold ${isFavorable ? 'text-[#00FF41]' : 'text-[#F27D26]'}`}>
                        {isFavorable ? `+£${delta.toFixed(2)}` : `£${delta.toFixed(2)}`}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
