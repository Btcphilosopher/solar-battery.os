import React, { useState } from 'react';
import { Wind, Activity } from 'lucide-react';
import { WindTurbine, WindFarmConfig, TurbineState } from '../engine/types';

interface TurbineFarmMatrixProps {
  farm: WindFarmConfig;
  onUpdateTurbineState: (turbineId: string, newState: TurbineState) => void;
}

export const TurbineFarmMatrix: React.FC<TurbineFarmMatrixProps> = ({
  farm,
  onUpdateTurbineState,
}) => {
  const [selectedTurbine, setSelectedTurbine] = useState<WindTurbine | null>(farm.turbines[0] || null);
  const [filterState, setFilterState] = useState<string>('ALL');

  const getStateBadge = (state: TurbineState) => {
    switch (state) {
      case 'RUNNING':
        return <span className="px-2 py-0.5 text-[10px] font-mono font-bold text-[#00FF41] border border-[#00FF41]/40 bg-[#0F1115]">RUNNING</span>;
      case 'CURTAILED':
        return <span className="px-2 py-0.5 text-[10px] font-mono font-bold text-[#F27D26] border border-[#F27D26]/40 bg-[#0F1115]">CURTAILED</span>;
      case 'MAINTENANCE':
        return <span className="px-2 py-0.5 text-[10px] font-mono font-bold text-[#6A6E7A] border border-[#6A6E7A]/40 bg-[#0F1115]">MAINTENANCE</span>;
      case 'FAULT':
        return <span className="px-2 py-0.5 text-[10px] font-mono font-bold text-[#F27D26] border border-[#F27D26] bg-[#F27D26]/10">FAULT</span>;
      default:
        return <span className="px-2 py-0.5 text-[10px] font-mono font-bold text-[#6A6E7A] border border-[#2A2D35] bg-[#0F1115]">{state}</span>;
    }
  };

  const filteredTurbines = farm.turbines.filter((t) => {
    if (filterState === 'ALL') return true;
    return t.state === filterState;
  });

  return (
    <div className="space-y-6">
      {/* Header & Controls */}
      <div className="bg-[#16191E] border border-[#2A2D35] p-5 flex flex-wrap items-center justify-between gap-4 font-mono">
        <div>
          <span className="text-[10px] font-mono font-bold text-[#F27D26] uppercase tracking-[0.2em] block mb-1">
            Turbine Array State Matrix
          </span>
          <h2 className="text-2xl font-black text-white italic flex items-center gap-2 tracking-tight">
            <Wind className="w-5 h-5 text-[#F27D26]" />
            {farm.name} (25 x Siemens Gamesa 8.0MW)
          </h2>
          <p className="text-xs text-[#6A6E7A] mt-1">
            Location: {farm.locationName} | Rated Capacity: {farm.ratedCapacityMw} MW | Array Wake Loss: {(farm.wakeLossFactor * 100).toFixed(1)}%
          </p>
        </div>

        {/* Filter Buttons */}
        <div className="flex items-center gap-1 bg-[#0F1115] p-1 border border-[#2A2D35] text-xs">
          {['ALL', 'RUNNING', 'CURTAILED', 'MAINTENANCE', 'FAULT'].map((st) => (
            <button
              key={st}
              onClick={() => setFilterState(st)}
              className={`px-3 py-1.5 font-mono font-bold transition-colors ${
                filterState === st
                  ? 'bg-[#F27D26] text-black'
                  : 'text-[#6A6E7A] hover:text-white'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: 25-Turbine Array Grid Matrix */}
        <div className="lg:col-span-2 bg-[#16191E] border border-[#2A2D35] p-5 font-mono">
          <h3 className="text-xs font-mono uppercase tracking-[0.2em] text-[#6A6E7A] border-l-2 border-[#F27D26] pl-3 mb-4 font-bold">
            Turbine Telemetry Grid
          </h3>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
            {filteredTurbines.map((t) => {
              const isSelected = selectedTurbine?.id === t.id;
              return (
                <div
                  key={t.id}
                  onClick={() => setSelectedTurbine(t)}
                  className={`p-3 border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#0F1115] border-[#F27D26]'
                      : 'bg-[#0F1115] border-[#2A2D35] hover:border-[#6A6E7A]'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-white">{t.code}</span>
                    {getStateBadge(t.state)}
                  </div>

                  <div className="text-xl font-light tracking-tighter text-[#00FF41] mb-1">
                    {t.activePowerMw.toFixed(1)} <span className="text-xs text-[#6A6E7A] font-normal">MW</span>
                  </div>

                  <div className="text-[10px] text-[#6A6E7A] flex justify-between">
                    <span>Wind:</span>
                    <span className="text-white font-bold">{t.currentWindSpeedMs.toFixed(1)} m/s</span>
                  </div>
                  <div className="text-[10px] text-[#6A6E7A] flex justify-between">
                    <span>RPM:</span>
                    <span className="text-[#E0E0E0]">{t.rotorRpm.toFixed(1)}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Selected Turbine Details & Power Curve Physics */}
        {selectedTurbine && (
          <div className="bg-[#16191E] border border-[#2A2D35] p-5 space-y-4 font-mono text-xs">
            <div className="border-b border-[#2A2D35] pb-3 flex items-center justify-between">
              <div>
                <span className="text-[#F27D26] text-[10px] font-bold block uppercase tracking-wider">
                  TURBINE TELEMETRY
                </span>
                <h3 className="text-lg font-bold text-white">{selectedTurbine.code} ({selectedTurbine.model})</h3>
              </div>
              {getStateBadge(selectedTurbine.state)}
            </div>

            <div className="space-y-2 bg-[#0F1115] p-3 border border-[#2A2D35]">
              <div className="flex justify-between">
                <span className="text-[#6A6E7A]">Rated Output:</span>
                <span className="text-white font-bold">{selectedTurbine.ratedPowerMw} MW</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#6A6E7A]">Rotor Diameter:</span>
                <span className="text-white font-bold">{selectedTurbine.rotorDiameterM} m</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#6A6E7A]">Swept Area:</span>
                <span className="text-[#00FF41] font-bold">
                  {(Math.PI * Math.pow(selectedTurbine.rotorDiameterM / 2, 2)).toLocaleString('en-GB', { maximumFractionDigits: 0 })} m²
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#6A6E7A]">Cut-in / Rated / Cut-out:</span>
                <span className="text-[#F27D26] font-bold">
                  {selectedTurbine.cutInSpeedMs} / {selectedTurbine.ratedSpeedMs} / {selectedTurbine.cutOutSpeedMs} m/s
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#6A6E7A]">Generator Temp:</span>
                <span className="text-white font-bold">{selectedTurbine.generatorTempC} °C</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#6A6E7A]">Operating Hours:</span>
                <span className="text-[#00FF41] font-bold">{selectedTurbine.cumulativeOperatingHours.toLocaleString()} hrs</span>
              </div>
            </div>

            {/* State Machine Overrides */}
            <div>
              <span className="text-[#6A6E7A] text-[10px] font-bold block mb-2 uppercase tracking-wider">
                DISPATCH STATE OVERRIDE:
              </span>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => onUpdateTurbineState(selectedTurbine.id, 'RUNNING')}
                  className="bg-[#0F1115] hover:bg-[#2A2D35] text-[#00FF41] border border-[#00FF41]/40 py-2 rounded text-center font-bold"
                >
                  RUNNING
                </button>
                <button
                  onClick={() => onUpdateTurbineState(selectedTurbine.id, 'CURTAILED')}
                  className="bg-[#0F1115] hover:bg-[#2A2D35] text-[#F27D26] border border-[#F27D26]/40 py-2 rounded text-center font-bold"
                >
                  CURTAILED
                </button>
                <button
                  onClick={() => onUpdateTurbineState(selectedTurbine.id, 'MAINTENANCE')}
                  className="bg-[#0F1115] hover:bg-[#2A2D35] text-[#6A6E7A] border border-[#6A6E7A]/40 py-2 rounded text-center font-bold"
                >
                  MAINTENANCE
                </button>
                <button
                  onClick={() => onUpdateTurbineState(selectedTurbine.id, 'OFF')}
                  className="bg-[#0F1115] hover:bg-[#2A2D35] text-white border border-[#2A2D35] py-2 rounded text-center font-bold"
                >
                  OFF
                </button>
              </div>
            </div>

            {/* Physics Equation Card */}
            <div className="bg-[#0F1115] p-3 border border-[#2A2D35] text-[11px] space-y-1 text-[#6A6E7A]">
              <span className="text-[#F27D26] font-bold block uppercase">IEC Physics Equations:</span>
              <p className="font-mono text-white">P_avail = 0.5 * ρ * A * v³</p>
              <p className="font-mono text-white">v_eff = v * (ρ / 1.225)^(1/3)</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
