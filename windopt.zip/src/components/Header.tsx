import React from 'react';
import {
  Wind,
  BatteryCharging,
  TrendingUp,
  Activity,
  CheckCircle2,
  Sliders,
  Code2,
  BarChart3,
} from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  systemValueGbp: number;
  windUtilisationPct: number;
  conservationPassed: boolean;
  solverStatus: string;
  onRunOptimization: () => void;
  isSimulating: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  systemValueGbp,
  windUtilisationPct,
  conservationPassed,
  solverStatus,
  onRunOptimization,
  isSimulating,
}) => {
  return (
    <header className="bg-[#0F1115] border-b border-[#2A2D35] text-[#E0E0E0] sticky top-0 z-50">
      {/* Top Banner Ticker - Monospace High Density */}
      <div className="bg-[#16191E] px-4 py-2 border-b border-[#2A2D35] text-[10px] font-mono flex flex-wrap items-center justify-between text-[#6A6E7A] uppercase tracking-wider">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#00FF41] animate-pulse"></span>
            <span className="text-[#00FF41] font-bold tracking-widest">
              SYSTEM STATUS: {solverStatus} / NOMINAL
            </span>
          </div>
          <span className="text-[#2A2D35]">|</span>
          <div className="flex items-center gap-1.5 text-[#E0E0E0]">
            <span className="text-[#6A6E7A]">HORIZON:</span>
            <span className="text-[#F27D26] font-bold">05 MIN (MPC)</span>
          </div>
          <span className="text-[#2A2D35]">|</span>
          <div className="flex items-center gap-1.5 text-[#E0E0E0]">
            <span className="text-[#6A6E7A]">CONSERVATION:</span>
            {conservationPassed ? (
              <span className="text-[#00FF41] font-bold flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-[#00FF41] inline" /> VERIFIED (0.00 MWh)
              </span>
            ) : (
              <span className="text-[#F27D26]">CHECKING</span>
            )}
          </div>
        </div>

        <div className="flex items-center gap-6 font-mono text-[#E0E0E0]">
          <div>
            <span className="text-[#6A6E7A]">WIND UTIL:</span>{' '}
            <span className="text-[#F27D26] font-bold text-xs">{windUtilisationPct.toFixed(1)}%</span>
          </div>
          <span className="text-[#2A2D35]">|</span>
          <div>
            <span className="text-[#6A6E7A]">SYS VALUE:</span>{' '}
            <span className="text-white font-bold text-xs">
              £{systemValueGbp.toLocaleString('en-GB', { maximumFractionDigits: 0 })}
            </span>
          </div>
        </div>
      </div>

      {/* Main Header & Nav */}
      <div className="max-w-7xl mx-auto px-4 py-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div>
            <h1 className="text-4xl font-black tracking-tighter leading-none text-white italic">
              WINDOPT<span className="text-[#F27D26] not-italic ml-0.5">.</span>
            </h1>
            <p className="text-[10px] font-mono uppercase tracking-[0.25em] text-[#6A6E7A] mt-1">
              HIGH-PERFORMANCE DISPATCH PLATFORM v4.2.0
            </p>
          </div>
        </div>

        {/* Navigation Tabs - Bold Typography Style */}
        <nav className="flex items-center gap-1 bg-[#16191E] p-1 border border-[#2A2D35]">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-3 py-1.5 text-xs font-mono font-bold tracking-wider uppercase transition-colors flex items-center gap-1.5 ${
              activeTab === 'overview'
                ? 'bg-[#F27D26] text-black'
                : 'text-[#6A6E7A] hover:text-white hover:bg-[#2A2D35]'
            }`}
          >
            <Activity className="w-3.5 h-3.5" /> Dispatch
          </button>
          <button
            onClick={() => setActiveTab('turbines')}
            className={`px-3 py-1.5 text-xs font-mono font-bold tracking-wider uppercase transition-colors flex items-center gap-1.5 ${
              activeTab === 'turbines'
                ? 'bg-[#F27D26] text-black'
                : 'text-[#6A6E7A] hover:text-white hover:bg-[#2A2D35]'
            }`}
          >
            <Wind className="w-3.5 h-3.5" /> Turbines (25)
          </button>
          <button
            onClick={() => setActiveTab('battery')}
            className={`px-3 py-1.5 text-xs font-mono font-bold tracking-wider uppercase transition-colors flex items-center gap-1.5 ${
              activeTab === 'battery'
                ? 'bg-[#F27D26] text-black'
                : 'text-[#6A6E7A] hover:text-white hover:bg-[#2A2D35]'
            }`}
          >
            <BatteryCharging className="w-3.5 h-3.5" /> BESS
          </button>
          <button
            onClick={() => setActiveTab('strike')}
            className={`px-3 py-1.5 text-xs font-mono font-bold tracking-wider uppercase transition-colors flex items-center gap-1.5 ${
              activeTab === 'strike'
                ? 'bg-[#F27D26] text-black'
                : 'text-[#6A6E7A] hover:text-white hover:bg-[#2A2D35]'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5" /> Strike
          </button>
          <button
            onClick={() => setActiveTab('montecarlo')}
            className={`px-3 py-1.5 text-xs font-mono font-bold tracking-wider uppercase transition-colors flex items-center gap-1.5 ${
              activeTab === 'montecarlo'
                ? 'bg-[#F27D26] text-black'
                : 'text-[#6A6E7A] hover:text-white hover:bg-[#2A2D35]'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" /> Monte Carlo
          </button>
          <button
            onClick={() => setActiveTab('architecture')}
            className={`px-3 py-1.5 text-xs font-mono font-bold tracking-wider uppercase transition-colors flex items-center gap-1.5 ${
              activeTab === 'architecture'
                ? 'bg-[#F27D26] text-black'
                : 'text-[#6A6E7A] hover:text-white hover:bg-[#2A2D35]'
            }`}
          >
            <Code2 className="w-3.5 h-3.5" /> Rust/R
          </button>
        </nav>

        {/* Action Button - Orange Highlight */}
        <button
          onClick={onRunOptimization}
          disabled={isSimulating}
          className="bg-[#F27D26] hover:bg-[#d96c1e] text-black font-extrabold px-4 py-2 text-xs font-mono tracking-wider uppercase border border-[#F27D26] transition-colors flex items-center gap-2 disabled:opacity-50"
        >
          <Sliders className="w-4 h-4" />
          {isSimulating ? 'SOLVING HORIZON...' : 'RUN MPC SOLVER'}
        </button>
      </div>
    </header>
  );
};
