import React from 'react';
import { Download, CheckCircle2 } from 'lucide-react';
import { OptimizationRunOutput } from '../engine/types';

interface DispatchAuditLogProps {
  optRun: OptimizationRunOutput;
}

export const DispatchAuditLog: React.FC<DispatchAuditLogProps> = ({ optRun }) => {
  const downloadAuditJson = () => {
    const jsonStr = JSON.stringify(optRun, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `windopt-dispatch-audit-${optRun.runId}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6 font-mono text-xs">
      <div className="bg-[#16191E] border border-[#2A2D35] p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-mono font-bold text-[#F27D26] uppercase tracking-[0.2em] block mb-1">
            AUDITABLE DISPATCH DECISION LOG
          </span>
          <h2 className="text-2xl font-black text-white italic flex items-center gap-2">
            Rolling Horizon Dispatch Audit Trail
          </h2>
          <p className="text-[#6A6E7A] text-xs mt-1">
            Every decision logged with system state, shadow price, solver status, and conservation verification
          </p>
        </div>

        <button
          onClick={downloadAuditJson}
          className="bg-[#F27D26] hover:bg-[#d96c1e] text-black font-extrabold px-4 py-2 text-xs font-mono tracking-wider uppercase border border-[#F27D26] transition-colors flex items-center gap-2"
        >
          <Download className="w-4 h-4" /> DOWNLOAD AUDIT JSON
        </button>
      </div>

      {/* Log Table */}
      <div className="bg-[#16191E] border border-[#2A2D35] overflow-x-auto">
        <table className="w-full text-left border-collapse font-mono">
          <thead>
            <tr className="bg-[#0F1115] text-[#6A6E7A] border-b border-[#2A2D35] uppercase text-[10px] font-bold">
              <th className="p-3">TIME</th>
              <th className="p-3">WIND (AVAIL / GEN / CURT)</th>
              <th className="p-3">DEMAND SERVED</th>
              <th className="p-3">BATTERY (SOC / CHARGE / DISCHARGE)</th>
              <th className="p-3">GRID (IMPORT / EXPORT)</th>
              <th className="p-3">SPOT / STRIKE</th>
              <th className="p-3">SHADOW PRICE</th>
              <th className="p-3">CONSERVATION</th>
              <th className="p-3">SOLVER</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#2A2D35] text-[#E0E0E0]">
            {optRun.intervals.slice(0, 16).map((interval, idx) => (
              <tr key={idx} className="hover:bg-[#0F1115] transition-colors">
                <td className="p-3 font-bold text-white">{interval.timeLabel}</td>
                <td className="p-3">
                  <span className="text-white">{interval.availableWindMw}</span> /{' '}
                  <span className="text-[#00FF41] font-bold">{interval.generatedWindMw}</span> /{' '}
                  <span className="text-[#F27D26]">{interval.curtailedWindMw} MW</span>
                </td>
                <td className="p-3 font-bold text-white">{interval.totalDemandServedMw} MW</td>
                <td className="p-3">
                  <span className="text-[#00FF41]">{interval.batterySocPct}%</span> (
                  <span className="text-white">+{interval.batteryChargeMw}</span> /{' '}
                  <span className="text-white">-{interval.batteryDischargeMw}</span>)
                </td>
                <td className="p-3">
                  <span className="text-[#F27D26]">{interval.gridImportMw}</span> /{' '}
                  <span className="text-[#00FF41]">{interval.gridExportMw} MW</span>
                </td>
                <td className="p-3">
                  <span className="text-[#00FF41]">£{interval.spotPriceGbp}</span> /{' '}
                  <span className="text-[#F27D26]">£{interval.activeStrikePriceGbp}</span>
                  {interval.strikeExercised && (
                    <span className="ml-1 text-[9px] bg-[#F27D26]/20 text-[#F27D26] border border-[#F27D26]/40 px-1 font-bold">EXERCISED</span>
                  )}
                </td>
                <td className="p-3 font-bold text-white">£{interval.windShadowPriceGbp}</td>
                <td className="p-3">
                  {interval.conservation.passed ? (
                    <span className="text-[#00FF41] font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> PASSED
                    </span>
                  ) : (
                    <span className="text-[#F27D26]">CHECK</span>
                  )}
                </td>
                <td className="p-3">
                  <span className="px-2 py-0.5 text-[10px] font-bold bg-[#00FF41]/10 text-[#00FF41] border border-[#00FF41]/30">
                    {interval.solverStatus}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
