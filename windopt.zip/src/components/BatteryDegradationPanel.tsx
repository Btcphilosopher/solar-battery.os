import React from 'react';
import { BatteryCharging, Flame, Cpu, Zap } from 'lucide-react';
import { BatteryState } from '../engine/types';

interface BatteryDegradationPanelProps {
  battery: BatteryState;
}

export const BatteryDegradationPanel: React.FC<BatteryDegradationPanelProps> = ({ battery }) => {
  return (
    <div className="space-y-6 font-mono">
      {/* Header */}
      <div className="bg-[#16191E] border border-[#2A2D35] p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <span className="text-[10px] font-mono font-bold text-[#F27D26] uppercase tracking-[0.2em] block mb-1">
            BESS DEGRADATION & PHYSICAL CELL ENGINE
          </span>
          <h2 className="text-2xl font-black text-white italic flex items-center gap-2">
            <BatteryCharging className="w-5 h-5 text-[#F27D26]" />
            50MW / 100MWh Lithium-Ion (LFP) Battery Storage Array
          </h2>
          <p className="text-xs text-[#6A6E7A]">
            Dynamic throughput cost model tracking SOC depth of discharge, temperature, and cell degradation
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="bg-[#0F1115] px-3 py-2 border border-[#2A2D35] text-xs">
            <span className="text-[#6A6E7A] block">RTE EFFICIENCY</span>
            <span className="text-[#00FF41] font-bold text-sm">{(battery.roundTripEfficiency * 100).toFixed(1)}%</span>
          </div>
          <div className="bg-[#0F1115] px-3 py-2 border border-[#2A2D35] text-xs">
            <span className="text-[#6A6E7A] block">THROUGHPUT COST</span>
            <span className="text-[#F27D26] font-bold text-sm">£{battery.degradationCostPerMwh.toFixed(2)} /MWh</span>
          </div>
        </div>
      </div>

      {/* Main Grid matching Bold Typography Spec */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* SOC Card */}
        <div className="bg-[#16191E] border border-[#2A2D35] p-5 flex flex-col justify-between">
          <p className="text-[11px] font-mono uppercase text-[#6A6E7A] tracking-wider font-bold">
            State of Charge (SOC)
          </p>
          <div className="flex items-baseline gap-2 my-2">
            <span className="text-5xl font-light tracking-tighter text-white">{battery.socPct.toFixed(1)}</span>
            <span className="text-2xl text-[#00FF41] font-bold">%</span>
          </div>
          <div>
            <div className="flex justify-between text-xs text-[#6A6E7A] mb-1">
              <span>Energy Stored</span>
              <span className="text-white font-bold">{battery.currentEnergyMwh.toFixed(1)} / {battery.usableCapacityMwh} MWh</span>
            </div>
            <div className="h-2 bg-[#2A2D35] w-full">
              <div className="h-full bg-[#00FF41]" style={{ width: `${battery.socPct}%` }}></div>
            </div>
          </div>
        </div>

        {/* SOH Card */}
        <div className="bg-[#16191E] border border-[#2A2D35] p-5 flex flex-col justify-between">
          <p className="text-[11px] font-mono uppercase text-[#6A6E7A] tracking-wider font-bold">
            State of Health (SOH)
          </p>
          <div className="flex items-baseline gap-2 my-2">
            <span className="text-5xl font-light tracking-tighter text-white">{battery.sohPct.toFixed(2)}</span>
            <span className="text-2xl text-[#00FF41] font-bold">%</span>
          </div>
          <div>
            <div className="flex justify-between text-xs text-[#6A6E7A] mb-1">
              <span>Cell Capacity Fade</span>
              <span className="text-[#F27D26] font-bold">{(100 - battery.sohPct).toFixed(2)}% Loss</span>
            </div>
            <div className="h-2 bg-[#2A2D35] w-full">
              <div className="h-full bg-[#00FF41]" style={{ width: `${battery.sohPct}%` }}></div>
            </div>
          </div>
        </div>

        {/* Thermal & Stress Card */}
        <div className="bg-[#16191E] border border-[#2A2D35] p-5 flex flex-col justify-between">
          <p className="text-[11px] font-mono uppercase text-[#6A6E7A] tracking-wider font-bold">
            Cell Thermal State
          </p>
          <div className="flex items-baseline gap-2 my-2">
            <span className="text-5xl font-light tracking-tighter text-white">{battery.cellTempC.toFixed(1)}</span>
            <span className="text-2xl text-[#F27D26] font-bold">°C</span>
          </div>
          <div className="text-xs text-[#6A6E7A] space-y-1">
            <div className="flex justify-between">
              <span>Cooling System:</span>
              <span className="text-[#00FF41] font-bold">ACTIVE LIQUID</span>
            </div>
            <div className="flex justify-between">
              <span>Optimal Range:</span>
              <span className="text-white">18.0 - 28.0 °C</span>
            </div>
          </div>
        </div>

        {/* Cycle Life Card */}
        <div className="bg-[#16191E] border border-[#2A2D35] p-5 flex flex-col justify-between">
          <p className="text-[11px] font-mono uppercase text-[#6A6E7A] tracking-wider font-bold">
            Cumulative Cycles
          </p>
          <div className="flex items-baseline gap-2 my-2">
            <span className="text-5xl font-light tracking-tighter text-white">{battery.totalEquivalentCycles}</span>
            <span className="text-xs text-[#6A6E7A] font-bold">CYCLES</span>
          </div>
          <div className="text-xs text-[#6A6E7A] space-y-1">
            <div className="flex justify-between">
              <span>Max Capacity:</span>
              <span className="text-white font-bold">{battery.maxPowerMw} MW</span>
            </div>
            <div className="flex justify-between">
              <span>Operating Window:</span>
              <span className="text-[#F27D26] font-bold">{battery.minSocPct}% - {battery.maxSocPct}%</span>
            </div>
          </div>
        </div>
      </div>

      {/* Degradation Math Card */}
      <div className="bg-[#16191E] border border-[#2A2D35] p-5 text-xs text-[#6A6E7A]">
        <h3 className="text-xs font-mono uppercase tracking-[0.2em] text-[#6A6E7A] mb-3 border-l-2 border-[#F27D26] pl-3 font-bold">
          Lithium Degradation Equations & Cost Dynamics
        </h3>
        <p className="mb-2 text-[#E0E0E0]">
          The WINDOPT dispatch solver penalizes battery usage when the expected spot price gain is lower than the cell throughput degradation cost.
        </p>
        <div className="bg-[#0F1115] p-3 border border-[#2A2D35] font-mono text-white">
          <p>Degradation Cost = Base Cost (£16.80) * [ 1.0 + 0.5 * (SOC_depth - 0.5)² + 0.3 * (C_rate - 0.5)² ]</p>
        </div>
      </div>
    </div>
  );
};
