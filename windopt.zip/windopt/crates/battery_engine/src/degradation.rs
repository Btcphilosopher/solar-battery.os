use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BatteryDegradationModel {
    pub initial_capacity_mwh: f64,
    pub replacement_cost_gbp: f64,
    pub cycle_life: f64,              // e.g. 6000 cycles at 80% DoD
    pub calendar_aging_rate_per_year: f64, // e.g. 0.015
    pub c_rate_stress_factor: f64,
}

impl BatteryDegradationModel {
    /// Cost per throughput MWh derived from lithium iron phosphate cell degradation curves
    pub fn degradation_cost_per_mwh(&self, soc_pct: f64, c_rate: f64) -> f64 {
        let base_cost_per_mwh = self.replacement_cost_gbp / (self.initial_capacity_mwh * self.cycle_life * 0.8);
        
        // Accelerated aging at high/low SOC Extremes
        let soc_stress = if soc_pct > 85.0 {
            1.0 + (soc_pct - 85.0) * 0.04
        } else if soc_pct < 15.0 {
            1.0 + (15.0 - soc_pct) * 0.03
        } else {
            1.0
        };

        let rate_stress = 1.0 + (c_rate - 0.5).max(0.0) * self.c_rate_stress_factor;
        base_cost_per_mwh * soc_stress * rate_stress
    }
}
