use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PowerCurveSpec {
    pub cut_in_speed_ms: f64,    // e.g. 3.0 m/s
    pub rated_speed_ms: f64,     // e.g. 12.0 m/s
    pub cut_out_speed_ms: f64,   // e.g. 25.0 m/s
    pub rated_power_mw: f64,     // e.g. 6.0 MW
    pub rotor_diameter_m: f64,   // e.g. 154 m
    pub standard_air_density: f64, // 1.225 kg/m3
}

impl PowerCurveSpec {
    pub fn swept_area_m2(&self) -> f64 {
        std::f64::consts::PI * (self.rotor_diameter_m / 2.0).powi(2)
    }

    /// Calculates theoretical available kinetic wind power in MW
    pub fn kinetic_wind_power_mw(&self, wind_speed_ms: f64, air_density: f64) -> f64 {
        let area = self.swept_area_m2();
        let watts = 0.5 * air_density * area * wind_speed_ms.powi(3);
        watts / 1_000_000.0
    }

    /// Calculates electrical output in MW accounting for Betz limit (0.593) & drivetrain mechanical efficiency
    pub fn calculate_power_mw(&self, wind_speed_ms: f64, air_density: f64) -> f64 {
        if wind_speed_ms < self.cut_in_speed_ms || wind_speed_ms >= self.cut_out_speed_ms {
            return 0.0;
        }

        let density_ratio = air_density / self.standard_air_density;
        let corrected_wind = wind_speed_ms * density_ratio.cbrt();

        if corrected_wind >= self.rated_speed_ms {
            return self.rated_power_mw;
        }

        // Cubic power curve transition between cut-in and rated speed
        let norm = (corrected_wind - self.cut_in_speed_ms) / (self.rated_speed_ms - self.cut_in_speed_ms);
        let cp_eff = 0.46 * (norm.powi(3).clamp(0.0, 1.0));
        let power = self.kinetic_wind_power_mw(corrected_wind, self.standard_air_density) * cp_eff;
        power.min(self.rated_power_mw)
    }
}
