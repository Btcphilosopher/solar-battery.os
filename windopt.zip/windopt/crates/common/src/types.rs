use serde::{Deserialize, Serialize};
use chrono::{DateTime, Utc};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum TurbineState {
    Off,
    Starting,
    Running,
    Ramping,
    Curtailed,
    Fault,
    Maintenance,
    Stopping,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EnergyAccounting {
    pub available_wind_mwh: f64,
    pub generated_wind_mwh: f64,
    pub useful_wind_mwh: f64,
    pub curtailed_wind_mwh: f64,
    pub battery_charge_mwh: f64,
    pub battery_discharge_mwh: f64,
    pub grid_import_mwh: f64,
    pub grid_export_mwh: f64,
    pub demand_served_mwh: f64,
    pub thermal_loss_mwh: f64,
}

impl EnergyAccounting {
    /// Validates conservation of energy:
    /// Generation + Import + Discharge == Demand + Charge + Export + Losses + Curtailment
    pub fn validate_conservation(&self, tolerance_mwh: f64) -> bool {
        let supply = self.generated_wind_mwh + self.grid_import_mwh + self.battery_discharge_mwh;
        let demand_and_sink = self.demand_served_mwh + self.battery_charge_mwh + self.grid_export_mwh + self.thermal_loss_mwh + self.curtailed_wind_mwh;
        (supply - demand_and_sink).abs() <= tolerance_mwh
    }

    pub fn wind_utilisation(&self) -> f64 {
        if self.available_wind_mwh <= 1e-6 {
            0.0
        } else {
            (self.useful_wind_mwh / self.available_wind_mwh) * 100.0
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WindShadowPrice {
    pub immediate_consumption_value: f64,
    pub battery_value: f64,
    pub export_value: f64,
    pub strike_value: f64,
    pub future_value: f64,
    pub curtailment_penalty: f64,
    pub wind_shadow_price_per_mwh: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DispatchDecision {
    pub timestamp: DateTime<Utc>,
    pub wind_generation_mw: f64,
    pub curtailment_mw: f64,
    pub demand_mw: f64,
    pub battery_charge_mw: f64,
    pub battery_discharge_mw: f64,
    pub battery_soc_pct: f64,
    pub grid_import_mw: f64,
    pub grid_export_mw: f64,
    pub spot_price_per_mwh: f64,
    pub strike_price_per_mwh: f64,
    pub strike_exercised: bool,
    pub wind_utilisation_pct: f64,
    pub turbine_utilisation_pct: f64,
    pub system_estimated_value_gbp: f64,
    pub solver_status: String,
}
