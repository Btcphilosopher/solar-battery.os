import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';

import { createDefaultWindFarm } from './src/engine/windEngine';
import { createDefaultBattery } from './src/engine/batteryEngine';
import { createDefaultFlexibleLoads } from './src/engine/demandEngine';
import { createDefaultStrikeContracts } from './src/engine/marketEngine';
import { runDispatchOptimization } from './src/engine/optimiser';
import { runRMonteCarloAnalytics } from './src/engine/rAnalyticsService';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // In-memory state for active simulation
  let currentWindFarm = createDefaultWindFarm();
  let currentBattery = createDefaultBattery();
  let currentFlexibleLoads = createDefaultFlexibleLoads();
  let currentStrikeContracts = createDefaultStrikeContracts();

  let baseWindSpeed = 11.5;
  let baseDemand = 120.0;
  let spotPrice = 96.0;

  // 1. Core Industry API Routes
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'OK',
      system: 'WINDOPT Optimization Platform',
      rustEngineVersion: '0.1.0',
      rAnalyticsVersion: '0.1.0',
      timestamp: new Date().toISOString(),
    });
  });

  app.get('/api/wind-farms', (req, res) => {
    res.json(currentWindFarm);
  });

  app.get('/api/turbines', (req, res) => {
    res.json(currentWindFarm.turbines);
  });

  app.get('/api/battery', (req, res) => {
    res.json(currentBattery);
  });

  app.get('/api/demand', (req, res) => {
    res.json({
      baseDemandMw: baseDemand,
      flexibleLoads: currentFlexibleLoads,
    });
  });

  app.get('/api/prices', (req, res) => {
    res.json({
      currentSpotPriceGbp: spotPrice,
      strikeContracts: currentStrikeContracts,
      volatilityIndex: 34.2,
    });
  });

  app.get('/api/strike-contracts', (req, res) => {
    res.json(currentStrikeContracts);
  });

  app.get('/api/dispatch', (req, res) => {
    const optRun = runDispatchOptimization(
      currentWindFarm,
      currentBattery,
      currentFlexibleLoads,
      currentStrikeContracts,
      baseWindSpeed,
      baseDemand,
      spotPrice,
      24,
      15
    );
    res.json(optRun);
  });

  app.post('/api/optimise', (req, res) => {
    const { horizonHours = 24, stepMinutes = 15, windSpeedMs, demandMw, spotPriceGbp } = req.body || {};
    
    if (windSpeedMs !== undefined) baseWindSpeed = Number(windSpeedMs);
    if (demandMw !== undefined) baseDemand = Number(demandMw);
    if (spotPriceGbp !== undefined) spotPrice = Number(spotPriceGbp);

    const optRun = runDispatchOptimization(
      currentWindFarm,
      currentBattery,
      currentFlexibleLoads,
      currentStrikeContracts,
      baseWindSpeed,
      baseDemand,
      spotPrice,
      Number(horizonHours),
      Number(stepMinutes)
    );
    res.json(optRun);
  });

  app.post('/api/strike-contract', (req, res) => {
    const { contractCode, strikePriceGbpPerMwh, volumeMwh, counterparty } = req.body || {};
    if (!contractCode || !strikePriceGbpPerMwh) {
      res.status(400).json({ error: 'Missing contract parameters' });
      return;
    }

    const newContract = {
      id: `sc-${Date.now()}`,
      contractCode: String(contractCode),
      counterparty: String(counterparty || 'Bilateral Market Counterparty'),
      deliveryStart: '00:00',
      deliveryEnd: '23:59',
      volumeMwh: Number(volumeMwh || 40.0),
      strikePriceGbpPerMwh: Number(strikePriceGbpPerMwh),
      minimumDeliveryPct: 95.0,
      settlementRule: 'PHYSICAL_OR_FINANCIAL' as const,
      isActive: true,
    };

    currentStrikeContracts.push(newContract);
    res.json({ success: true, contract: newContract, allContracts: currentStrikeContracts });
  });

  app.post('/api/monte-carlo', (req, res) => {
    const { numSimulations = 2000, spotVolatility = 35.0 } = req.body || {};
    const monteCarloResult = runRMonteCarloAnalytics(
      Number(numSimulations),
      150.0,
      baseDemand,
      spotPrice,
      Number(spotVolatility)
    );
    res.json(monteCarloResult);
  });

  // 2. Real-Time Telemetry Event Stream (Server-Sent Events)
  app.get('/api/telemetry-stream', (req, res) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    const interval = setInterval(() => {
      const windSpeed = baseWindSpeed + (Math.random() - 0.5) * 1.2;
      const spot = spotPrice + (Math.random() - 0.5) * 4.0;
      const opt = runDispatchOptimization(
        currentWindFarm,
        currentBattery,
        currentFlexibleLoads,
        currentStrikeContracts,
        windSpeed,
        baseDemand,
        spot,
        1,
        15
      );

      const latestInterval = opt.intervals[0];
      res.write(`data: ${JSON.stringify(latestInterval)}\n\n`);
    }, 3000);

    req.on('close', () => {
      clearInterval(interval);
    });
  });

  // 3. Inspect Rust Crates Workspace Structure & Code
  app.get('/api/rust-crates', (req, res) => {
    const cratesDir = path.join(process.cwd(), 'windopt', 'crates');
    try {
      if (fs.existsSync(cratesDir)) {
        const crateNames = fs.readdirSync(cratesDir);
        const cratesList = crateNames.map((name) => {
          const cratePath = path.join(cratesDir, name);
          const libPath = path.join(cratePath, 'src', 'lib.rs');
          const hasLib = fs.existsSync(libPath);
          return {
            name,
            path: `windopt/crates/${name}`,
            libContent: hasLib ? fs.readFileSync(libPath, 'utf-8') : '',
          };
        });
        res.json({ crates: cratesList });
        return;
      }
    } catch (e) {
      // fallback response
    }
    res.json({ crates: [] });
  });

  // 4. Inspect R Quantitative Models Code
  app.get('/api/r-models', (req, res) => {
    const rDir = path.join(process.cwd(), 'r_models', 'R');
    try {
      if (fs.existsSync(rDir)) {
        const files = fs.readdirSync(rDir);
        const models = files.map((file) => {
          const content = fs.readFileSync(path.join(rDir, file), 'utf-8');
          return { file, content };
        });
        res.json({ models });
        return;
      }
    } catch (e) {
      // fallback
    }
    res.json({ models: [] });
  });

  // 5. Inspect PostgreSQL Schema DDL
  app.get('/api/postgres-schema', (req, res) => {
    const sqlPath = path.join(process.cwd(), 'migrations', '001_init.sql');
    try {
      if (fs.existsSync(sqlPath)) {
        const ddl = fs.readFileSync(sqlPath, 'utf-8');
        res.json({ ddl });
        return;
      }
    } catch (e) {
      // fallback
    }
    res.json({ ddl: '' });
  });

  // Vite Middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[WINDOPT] Engine Running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
