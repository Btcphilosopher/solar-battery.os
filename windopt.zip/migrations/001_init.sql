-- Enable PostGIS for wind-farm geographic spatial features
CREATE EXTENSION IF NOT EXISTS postgis;

-- 1. Wind Farms & Turbines
CREATE TABLE IF NOT EXISTS wind_farms (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(100) NOT NULL,
    location GEOMETRY(Point, 4326),
    rated_capacity_mw NUMERIC(10, 2) NOT NULL,
    num_turbines INT NOT NULL,
    commissioned_date DATE NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS turbines (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    wind_farm_id UUID REFERENCES wind_farms(id) ON DELETE CASCADE,
    turbine_code VARCHAR(50) UNIQUE NOT NULL,
    model_name VARCHAR(100) NOT NULL,
    rated_power_mw NUMERIC(6, 2) NOT NULL,
    rotor_diameter_m NUMERIC(6, 2) NOT NULL,
    hub_height_m NUMERIC(6, 2) NOT NULL,
    cut_in_speed_ms NUMERIC(4, 2) DEFAULT 3.0,
    rated_speed_ms NUMERIC(4, 2) DEFAULT 12.0,
    cut_out_speed_ms NUMERIC(4, 2) DEFAULT 25.0,
    state VARCHAR(20) DEFAULT 'RUNNING',
    cumulative_operating_hours NUMERIC(10, 2) DEFAULT 0.0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Telemetry Ingestion Log
CREATE TABLE IF NOT EXISTS turbine_telemetry (
    time TIMESTAMPTZ NOT NULL,
    turbine_id UUID REFERENCES turbines(id) ON DELETE CASCADE,
    wind_speed_ms NUMERIC(5, 2) NOT NULL,
    wind_direction_deg NUMERIC(5, 2),
    active_power_mw NUMERIC(6, 2) NOT NULL,
    reactive_power_mvar NUMERIC(6, 2),
    rotor_rpm NUMERIC(5, 2),
    generator_temp_c NUMERIC(5, 2),
    vibration_mm_s NUMERIC(5, 2),
    status_code INT DEFAULT 0,
    PRIMARY KEY (time, turbine_id)
);

-- 3. Battery Storage Facilities & State
CREATE TABLE IF NOT EXISTS batteries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(100) NOT NULL,
    max_capacity_mwh NUMERIC(8, 2) NOT NULL,
    max_charge_mw NUMERIC(8, 2) NOT NULL,
    max_discharge_mw NUMERIC(8, 2) NOT NULL,
    round_trip_efficiency NUMERIC(4, 3) DEFAULT 0.910,
    replacement_cost_gbp NUMERIC(12, 2) NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS battery_telemetry (
    time TIMESTAMPTZ NOT NULL,
    battery_id UUID REFERENCES batteries(id) ON DELETE CASCADE,
    soc_pct NUMERIC(5, 2) NOT NULL,
    soh_pct NUMERIC(5, 2) NOT NULL,
    temperature_c NUMERIC(5, 2) NOT NULL,
    charge_power_mw NUMERIC(8, 2) DEFAULT 0.0,
    discharge_power_mw NUMERIC(8, 2) DEFAULT 0.0,
    total_throughput_mwh NUMERIC(12, 2) DEFAULT 0.0,
    PRIMARY KEY (time, battery_id)
);

-- 4. Electricity Market & Strike Contracts
CREATE TABLE IF NOT EXISTS spot_prices (
    time TIMESTAMPTZ PRIMARY KEY,
    market_zone VARCHAR(50) DEFAULT 'UK_N2EX',
    price_gbp_per_mwh NUMERIC(8, 2) NOT NULL
);

CREATE TABLE IF NOT EXISTS strike_contracts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    contract_code VARCHAR(50) UNIQUE NOT NULL,
    counterparty VARCHAR(100) NOT NULL,
    delivery_start TIMESTAMPTZ NOT NULL,
    delivery_end TIMESTAMPTZ NOT NULL,
    volume_mwh NUMERIC(10, 2) NOT NULL,
    strike_price_gbp_per_mwh NUMERIC(8, 2) NOT NULL,
    minimum_delivery_pct NUMERIC(5, 2) DEFAULT 95.0,
    settlement_rule VARCHAR(50) DEFAULT 'PHYSICAL_OR_FINANCIAL',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5. Auditable Optimization Runs & Dispatch Decisions
CREATE TABLE IF NOT EXISTS optimisation_runs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    time_horizon_hours INT NOT NULL,
    timestep_minutes INT NOT NULL,
    solver VARCHAR(50) NOT NULL,
    solver_status VARCHAR(50) NOT NULL,
    objective_value_gbp NUMERIC(12, 2) NOT NULL,
    wind_utilisation_pct NUMERIC(5, 2) NOT NULL,
    curtailment_mwh NUMERIC(10, 2) NOT NULL
);

CREATE TABLE IF NOT EXISTS dispatch_decisions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    run_id UUID REFERENCES optimisation_runs(id) ON DELETE CASCADE,
    timestamp TIMESTAMPTZ NOT NULL,
    available_wind_mw NUMERIC(8, 2) NOT NULL,
    generated_wind_mw NUMERIC(8, 2) NOT NULL,
    curtailed_wind_mw NUMERIC(8, 2) NOT NULL,
    demand_mw NUMERIC(8, 2) NOT NULL,
    battery_charge_mw NUMERIC(8, 2) NOT NULL,
    battery_discharge_mw NUMERIC(8, 2) NOT NULL,
    battery_soc_pct NUMERIC(5, 2) NOT NULL,
    grid_import_mw NUMERIC(8, 2) NOT NULL,
    grid_export_mw NUMERIC(8, 2) NOT NULL,
    spot_price_gbp NUMERIC(8, 2) NOT NULL,
    strike_price_gbp NUMERIC(8, 2) NOT NULL,
    strike_exercised BOOLEAN DEFAULT FALSE,
    wind_shadow_price_gbp NUMERIC(8, 2) NOT NULL,
    energy_conservation_passed BOOLEAN DEFAULT TRUE
);
