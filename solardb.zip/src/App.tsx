import React, { useState } from 'react';
import { Header } from './components/Header';
import { FleetDashboard } from './components/FleetDashboard';
import { PanelCatalogue } from './components/PanelCatalogue';
import { DigitalTwin } from './components/DigitalTwin';
import { DataQualityStream } from './components/DataQualityStream';
import { RAnalyticsEngine } from './components/RAnalyticsEngine';
import { EconomicCalculator } from './components/EconomicCalculator';
import { CodeExplorer } from './components/CodeExplorer';
import { ReportGenerator } from './components/ReportGenerator';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [userRole, setUserRole] = useState<string>('ANALYTICS');

  return (
    <div className="min-h-screen bg-[#0F172A] text-slate-100 font-sans selection:bg-amber-400 selection:text-slate-900 flex flex-col justify-between">
      <div>
        <Header
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          userRole={userRole}
          setUserRole={setUserRole}
        />

        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          {activeTab === 'dashboard' && <FleetDashboard />}
          {activeTab === 'catalogue' && <PanelCatalogue />}
          {activeTab === 'twin' && <DigitalTwin />}
          {activeTab === 'telemetry' && <DataQualityStream />}
          {activeTab === 'analytics' && <RAnalyticsEngine />}
          {activeTab === 'economics' && <EconomicCalculator />}
          {activeTab === 'codebase' && <CodeExplorer />}
          {activeTab === 'reports' && <ReportGenerator />}
        </main>
      </div>

      {/* Footer - Geometric Balance Theme */}
      <footer className="h-12 bg-[#1E293B] border-t border-slate-700 flex items-center justify-between px-6 text-[10px] font-mono text-slate-400 mt-8">
        <div className="max-w-7xl mx-auto w-full flex flex-col sm:flex-row justify-between items-center gap-2">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5">
              <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-slate-300 font-bold">CORE: RUST-API-NODE-01</span>
            </div>
            <span>SQL: POSTGRES-POSTGIS</span>
            <span>R: ANALYTICS-V2.1</span>
          </div>
          <div className="text-slate-400 font-medium">
            SOLAR_DB ENGINE v1.4.2-STABLE | © 2026 SOLAROS FOUNDATION
          </div>
        </div>
      </footer>
    </div>
  );
}

