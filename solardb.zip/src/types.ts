export type PVTechnology = 'MONOCRYSTALLINE' | 'POLYCRYSTALLINE' | 'THIN_FILM' | 'BIFACIAL' | 'PEROVSKITE_TANDEM' | 'OTHER';

export interface PVPanel {
  panel_id: string;
  manufacturer: string;
  model: string;
  technology: PVTechnology;
  cell_type: string;
  nominal_power_w: number;
  efficiency_pct: number;
  voc: number;
  isc: number;
  vmpp: number;
  impp: number;
  temp_coeff_power: number;
  temp_coeff_voc: number;
  temp_coeff_isc: number;
  dimensions: {
    length_mm: number;
    width_mm: number;
    thickness_mm: number;
    weight_kg: number;
  };
  cell_count: number;
  warranty_years: number;
  degradation_rate_pct: number;
  is_bifacial: boolean;
  bifaciality_factor: number;
  status: string;
  price_usd: number;
}

export interface Inverter {
  inverter_id: string;
  manufacturer: string;
  model: string;
  rated_power_ac_kw: number;
  max_dc_power_kw: number;
  max_dc_voltage_v: number;
  mppt_range_min_v: number;
  mppt_range_max_v: number;
  max_input_current_a: number;
  euro_efficiency_pct: number;
  cec_efficiency_pct: number;
  mppt_channels: number;
  operating_temp_min_c: number;
  operating_temp_max_c: number;
  warranty_years: number;
  price_usd: number;
}

export interface Installation {
  installation_id: string;
  name: string;
  owner: string;
  type: 'RESIDENTIAL' | 'COMMERCIAL' | 'INDUSTRIAL' | 'UTILITY_SCALE';
  capacity_kw: number;
  commission_date: string;
  mounting_type: string;
  tilt_deg: number;
  azimuth_deg: number;
  location: {
    lat: number;
    lng: number;
    elevation_m: number;
  };
  panels_count: number;
  inverters_count: number;
}

export type QualityStatus = 'VALID' | 'SUSPECT' | 'INVALID' | 'MISSING' | 'SIMULATED';

export interface TelemetryObservation {
  sensor_id: string;
  timestamp: string;
  dc_voltage_v?: number;
  dc_current_a?: number;
  dc_power_w?: number;
  ac_power_w?: number;
  irradiance_w_m2?: number;
  module_temp_c?: number;
  is_simulated?: boolean;
}

export interface ValidationRecord {
  sensor_id: string;
  status: QualityStatus;
  flags: string[];
  timestamp: string;
}

export interface IVPoint {
  voltage_v: number;
  current_a: number;
  power_w: number;
}

export interface DegradationPoint {
  year: number;
  capacity_kw_exp: number;
  capacity_kw_lin: number;
  upper_bound_kw: number;
  lower_bound_kw: number;
  annual_mwh: number;
  retention_pct: number;
}

export interface LossStage {
  name: string;
  loss_pct: number;
  loss_kwh: number;
  output_kwh: number;
}

export interface CodebaseItem {
  name: string;
  path: string;
  type: 'file' | 'directory';
  children?: CodebaseItem[];
  content?: string;
}
