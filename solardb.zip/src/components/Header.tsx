import React from 'react';
import { Sun, Database, Shield, Cpu, Code, BarChart3, Activity, Layers, DollarSign, FileText } from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  userRole: string;
  setUserRole: (role: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ activeTab, setActiveTab, userRole, setUserRole }) => {
  const tabs = [
    { id: 'dashboard', label: 'Fleet Overview', icon: Activity },
    { id: 'catalogue', label: 'Panel & Inverters', icon: Database },
    { id: 'twin', label: 'Digital Twin', icon: Layers },
    { id: 'telemetry', label: 'Telemetry Stream', icon: Cpu },
    { id: 'analytics', label: 'R Analytics Engine', icon: BarChart3 },
    { id: 'economics', label: 'LCOE & Financials', icon: DollarSign },
    { id: 'codebase', label: 'Code & Schemas', icon: Code },
    { id: 'reports', label: 'Reports & Export', icon: FileText },
  ];

  return (
    <header className="bg-[#1E293B] border-b border-slate-700 text-slate-100 sticky top-0 z-50 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between py-3 gap-3">
          {/* Brand Logo & Tagline */}
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-amber-400 rounded-sm flex items-center justify-center font-bold text-slate-900 shadow">
              S
            </div>
            <div className="flex flex-col">
              <span className="text-white font-bold tracking-tight text-lg leading-tight flex items-center gap-1.5">
                SolarDB <span className="text-amber-400">OS</span>
                <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700 font-normal">
                  v1.4.2 STABLE
                </span>
              </span>
              <span className="text-[10px] uppercase tracking-widest text-slate-400 font-semibold">
                Production-Grade PV Infrastructure
              </span>
            </div>
          </div>

          {/* System Telemetry Badges & Database Role Switcher */}
          <div className="flex flex-wrap items-center gap-4 sm:gap-6">
            <div className="hidden lg:flex flex-col items-end">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider font-medium">Rust Ingestion</span>
              <span className="text-emerald-400 font-mono text-xs uppercase font-bold flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                12.4k OBS / SEC
              </span>
            </div>
            <div className="hidden lg:flex flex-col items-end">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider font-medium">PostgreSQL + PostGIS</span>
              <span className="text-sky-400 font-mono text-xs uppercase font-bold">SYNCED: 99.9%</span>
            </div>
            <div className="hidden lg:flex flex-col items-end">
              <span className="text-[10px] text-slate-400 uppercase tracking-wider font-medium">R Analytics Engine</span>
              <span className="text-amber-400 font-mono text-xs uppercase font-bold">READY / IDLE</span>
            </div>

            {/* Role Switcher */}
            <div className="flex items-center space-x-2 bg-slate-900/80 px-2.5 py-1 rounded border border-slate-700 text-xs font-mono">
              <Shield className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-slate-400 text-[10px] uppercase font-semibold">Role:</span>
              <select
                value={userRole}
                onChange={(e) => setUserRole(e.target.value)}
                className="bg-transparent text-xs text-amber-400 font-bold focus:outline-none cursor-pointer"
              >
                <option value="READ" className="bg-slate-900 text-slate-200">READ</option>
                <option value="WRITE" className="bg-slate-900 text-slate-200">WRITE</option>
                <option value="ANALYTICS" className="bg-slate-900 text-slate-200">ANALYTICS</option>
                <option value="ADMIN" className="bg-slate-900 text-slate-200">ADMIN</option>
              </select>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex space-x-1.5 overflow-x-auto py-2 border-t border-slate-800 scrollbar-none">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 px-3 py-1.5 text-xs rounded transition-all whitespace-nowrap cursor-pointer font-medium ${
                  isActive
                    ? 'bg-amber-400/10 text-amber-400 border border-amber-400/30 font-bold'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60 border border-transparent'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-amber-400' : 'text-slate-500'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};

