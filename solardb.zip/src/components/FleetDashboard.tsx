import React from 'react';
import { Sun, Zap, ShieldCheck, Activity, MapPin, Gauge, Cpu, CheckCircle2, AlertTriangle, XCircle } from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';

const mockDailyTelemetry = [
  { time: '06:00', generation_kw: 120, irradiance: 80, pr_pct: 78 },
  { time: '08:00', generation_kw: 1450, irradiance: 350, pr_pct: 81 },
  { time: '10:00', generation_kw: 5200, irradiance: 680, pr_pct: 83 },
  { time: '12:00', generation_kw: 8900, irradiance: 980, pr_pct: 84 },
  { time: '14:00', generation_kw: 7800, irradiance: 850, pr_pct: 82 },
  { time: '16:00', generation_kw: 3400, irradiance: 420, pr_pct: 80 },
  { time: '18:00', generation_kw: 450, irradiance: 90, pr_pct: 76 },
];

export const FleetDashboard: React.FC = () => {
  return (
    <div className="space-y-6">
      {/* Top Banner & Infrastructure Overview */}
      <div className="bg-slate-900 border border-slate-800 rounded p-5 text-slate-100 shadow-lg">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <span className="text-[10px] uppercase tracking-widest text-slate-500 font-bold block mb-1">
              Production Data Infrastructure
            </span>
            <h1 className="text-xl font-bold tracking-tight text-white flex items-center space-x-2">
              <span>SolarDB Fleet Overview & Telemetry Control</span>
            </h1>
            <p className="text-xs text-slate-400 mt-1 max-w-2xl">
              PostgreSQL + PostGIS authoritative system of record powering high-frequency telemetry ingestion with Rust, validated with strict data quality rules, and analyzed with R scientific engine.
            </p>
          </div>
          <div className="flex items-center space-x-3 bg-slate-950/80 p-3 rounded border border-slate-800">
            <Cpu className="w-6 h-6 text-amber-400 flex-shrink-0" />
            <div>
              <div className="text-[10px] uppercase text-slate-500 font-bold tracking-wider">Rust Ingestion Core</div>
              <div className="text-xs font-bold text-emerald-400 font-mono">1.2M msgs/sec batch pipeline</div>
            </div>
          </div>
        </div>
      </div>

      {/* Metric Cards Grid - Geometric Balance Style */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded flex flex-col justify-between h-32">
          <span className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">Installed DC Capacity</span>
          <span className="text-3xl font-light text-white font-mono">26.20 <span className="text-lg text-slate-500 font-normal">MWp</span></span>
          <div className="flex items-center gap-2 text-[10px] text-emerald-400 font-mono">
            <div className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>47,635 Active Panels</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded flex flex-col justify-between h-32">
          <span className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">Active Generation</span>
          <span className="text-3xl font-light text-amber-400 font-mono">8.90 <span className="text-lg text-slate-500 font-normal">MW</span></span>
          <div className="flex items-center gap-2 text-[10px] text-amber-400 font-mono">
            <span>IRRADIANCE: 980 W/m²</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded flex flex-col justify-between h-32">
          <span className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">System PR</span>
          <span className="text-3xl font-light text-white font-mono">0.824</span>
          <div className="flex items-center gap-2 text-[10px] text-slate-500 italic">
            <span>IEC 61724 Target: 0.850</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded flex flex-col justify-between h-32">
          <span className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">Data Quality Tagging</span>
          <span className="text-3xl font-light text-sky-400 font-mono">99.8%</span>
          <div className="flex items-center gap-2 text-[10px] text-sky-400 font-mono">
            <span>98.4% VALID · 1.2% SUSPECT</span>
          </div>
        </div>
      </div>

      {/* Main Chart Section & Site List */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded flex flex-col">
          <div className="p-3 border-b border-slate-800 flex justify-between items-center bg-slate-900/50">
            <span className="text-[11px] font-bold uppercase tracking-widest text-slate-400">
              Telemetry Stream <span className="text-slate-600 font-normal">— RUST CORE</span>
            </span>
            <span className="text-[10px] bg-slate-800 px-2 py-0.5 rounded text-slate-400 font-mono">
              Live Feed: 10s Poll
            </span>
          </div>

          <div className="p-4 flex-1">
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={mockDailyTelemetry}>
                  <defs>
                    <linearGradient id="colorGen" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.4} />
                      <stop offset="95%" stopColor="#f59e0b" stopOpacity={0.0} />
                    </linearGradient>
                    <linearGradient id="colorIrr" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#38bdf8" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#38bdf8" stopOpacity={0.0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="time" stroke="#94a3b8" fontSize={11} />
                  <YAxis yAxisId="left" stroke="#f59e0b" fontSize={11} label={{ value: 'Generation (kW)', angle: -90, position: 'insideLeft', fill: '#f59e0b', fontSize: 10 }} />
                  <YAxis yAxisId="right" orientation="right" stroke="#38bdf8" fontSize={11} label={{ value: 'Irradiance (W/m²)', angle: 90, position: 'insideRight', fill: '#38bdf8', fontSize: 10 }} />
                  <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '0.25rem', color: '#f8fafc' }} />
                  <Area yAxisId="left" type="monotone" dataKey="generation_kw" name="AC Power (kW)" stroke="#f59e0b" fillOpacity={1} fill="url(#colorGen)" strokeWidth={2} />
                  <Area yAxisId="right" type="monotone" dataKey="irradiance" name="Irradiance (W/m²)" stroke="#38bdf8" fillOpacity={1} fill="url(#colorIrr)" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Site Status List */}
        <div className="bg-slate-900 border border-slate-800 rounded flex flex-col justify-between">
          <div className="p-3 border-b border-slate-800 flex justify-between items-center bg-slate-900/50">
            <span className="text-[11px] font-bold uppercase tracking-widest text-slate-400">
              Registered Assets <span className="text-slate-600 font-normal">— POSTGIS</span>
            </span>
          </div>

          <div className="p-4 space-y-3 flex-1">
            <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-slate-200">Mojave Solar Farm Alpha</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-bold">UTILITY</span>
              </div>
              <div className="text-xs text-slate-400 font-mono">25.0 MWp · 228 Inverters · Single-Axis</div>
              <div className="text-[10px] text-slate-500 font-mono">PostGIS: POINT(-116.85 34.95 680m)</div>
            </div>

            <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-bold text-xs text-slate-200">Bavaria Agri-PV Park</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/30 font-bold">COMMERCIAL</span>
              </div>
              <div className="text-xs text-slate-400 font-mono">1.2 MWp · 11 Inverters · Fixed Ground 32°</div>
              <div className="text-[10px] text-slate-500 font-mono">PostGIS: POINT(11.58 48.13 520m)</div>
            </div>
          </div>

          <div className="p-3 bg-slate-950/80 border-t border-slate-800 text-[10px] font-mono text-slate-400">
            <span className="text-amber-400 font-bold">PROVENANCE:</span> All records linked via PostGIS spatial IDs and Rust data validation rules.
          </div>
        </div>
      </div>

      {/* Data Quality Engine Highlights */}
      <div className="bg-slate-900 border border-slate-800 rounded p-4 shadow-md">
        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-3">
          Rust Quality Engine Rule Tagging Status
        </span>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3 text-xs font-mono">
          <div className="p-2.5 rounded bg-slate-950 border border-emerald-500/30 flex items-center space-x-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <div>
              <div className="font-bold text-slate-200">VALID</div>
              <div className="text-slate-500 text-[10px]">In limits</div>
            </div>
          </div>
          <div className="p-2.5 rounded bg-slate-950 border border-amber-500/30 flex items-center space-x-2">
            <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0" />
            <div>
              <div className="font-bold text-slate-200">SUSPECT</div>
              <div className="text-slate-500 text-[10px]">P ≠ V × I</div>
            </div>
          </div>
          <div className="p-2.5 rounded bg-slate-950 border border-rose-500/30 flex items-center space-x-2">
            <XCircle className="w-4 h-4 text-rose-400 flex-shrink-0" />
            <div>
              <div className="font-bold text-slate-200">INVALID</div>
              <div className="text-slate-500 text-[10px]">Out of range</div>
            </div>
          </div>
          <div className="p-2.5 rounded bg-slate-950 border border-slate-800 flex items-center space-x-2">
            <div className="w-4 h-4 rounded-full border border-slate-600 text-slate-400 flex items-center justify-center text-[10px] font-bold">?</div>
            <div>
              <div className="font-bold text-slate-200">MISSING</div>
              <div className="text-slate-500 text-[10px]">Gaps</div>
            </div>
          </div>
          <div className="p-2.5 rounded bg-slate-950 border border-purple-500/30 flex items-center space-x-2">
            <Cpu className="w-4 h-4 text-purple-400 flex-shrink-0" />
            <div>
              <div className="font-bold text-slate-200">SIMULATED</div>
              <div className="text-slate-500 text-[10px]">Flagged</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

