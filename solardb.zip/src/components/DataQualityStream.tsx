import React, { useState } from 'react';
import { Cpu, Play, AlertTriangle, ShieldCheck, CheckCircle2, XCircle } from 'lucide-react';
import { ValidationRecord } from '../types';

export const DataQualityStream: React.FC = () => {
  const [validatedLogs, setValidatedLogs] = useState<ValidationRecord[]>([]);
  const [streaming, setStreaming] = useState<boolean>(false);
  const [stats, setStats] = useState({ total: 0, valid: 0, suspect: 0, invalid: 0 });

  const runBatchSimulatedIngestion = async (faultType?: string) => {
    setStreaming(true);

    const generateObservation = (id: string, overrideFault?: string) => {
      const now = new Date().toISOString();
      if (overrideFault === 'NEGATIVE_IRRADIANCE') {
        return { sensor_id: id, timestamp: now, dc_voltage_v: 720, dc_current_a: 10, dc_power_w: 7200, irradiance_w_m2: -25, module_temp_c: 42, is_simulated: false };
      }
      if (overrideFault === 'POWER_MISMATCH') {
        return { sensor_id: id, timestamp: now, dc_voltage_v: 720, dc_current_a: 10, dc_power_w: 4500, irradiance_w_m2: 950, module_temp_c: 42, is_simulated: false };
      }
      if (overrideFault === 'OVERVOLTAGE') {
        return { sensor_id: id, timestamp: now, dc_voltage_v: 1650, dc_current_a: 10, dc_power_w: 16500, irradiance_w_m2: 1000, module_temp_c: 45, is_simulated: false };
      }
      if (overrideFault === 'SIMULATED') {
        return { sensor_id: id, timestamp: now, dc_voltage_v: 700, dc_current_a: 10, dc_power_w: 7000, irradiance_w_m2: 900, module_temp_c: 35, is_simulated: true };
      }

      // Default normal observation
      return { sensor_id: id, timestamp: now, dc_voltage_v: 720, dc_current_a: 10.5, dc_power_w: 7560, irradiance_w_m2: 980, module_temp_c: 41, is_simulated: false };
    };

    const batch = [
      generateObservation('DESERT_INV1_STR1', faultType),
      generateObservation('DESERT_INV1_STR2'),
      generateObservation('DESERT_INV1_STR3', faultType === 'POWER_MISMATCH' ? 'POWER_MISMATCH' : undefined),
      generateObservation('DESERT_INV2_STR1'),
      generateObservation('DESERT_INV2_STR2', faultType === 'SIMULATED' ? 'SIMULATED' : undefined)
    ];

    try {
      const res = await fetch('/api/telemetry/stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ observations: batch })
      });
      const data = await res.json();

      setValidatedLogs(prev => [...data.validated_records, ...prev].slice(0, 30));
      setStats(prev => ({
        total: prev.total + data.total_processed,
        valid: prev.valid + data.valid_count,
        suspect: prev.suspect + data.suspect_count,
        invalid: prev.invalid + data.invalid_count
      }));
    } catch (err) {
      console.error('Ingestion error:', err);
    } finally {
      setStreaming(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Stream Controls */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded shadow-lg space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-0.5">
              Telemetry Validation & Pipeline Control
            </span>
            <h1 className="text-xl font-bold text-slate-100 flex items-center space-x-2">
              <Cpu className="w-5 h-5 text-amber-400" />
              <span>Rust Data Quality Stream & Rule Engine</span>
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              Append-only telemetry processing. Incoming observations are tagged with VALID, SUSPECT, INVALID, MISSING, or SIMULATED.
            </p>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => runBatchSimulatedIngestion()}
              disabled={streaming}
              className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold px-4 py-2 rounded text-xs transition-colors shadow flex items-center space-x-2 cursor-pointer"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>{streaming ? 'Ingesting...' : 'Ingest Normal Stream Batch'}</span>
            </button>
          </div>
        </div>

        {/* Fault Injection Triggers */}
        <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex flex-wrap items-center gap-2 text-xs font-mono">
          <span className="text-slate-400 font-semibold flex items-center space-x-1">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
            <span>Fault Injector:</span>
          </span>
          <button
            onClick={() => runBatchSimulatedIngestion('NEGATIVE_IRRADIANCE')}
            className="px-2.5 py-1 bg-rose-500/20 text-rose-300 border border-rose-500/40 rounded hover:bg-rose-500/30 transition-colors cursor-pointer"
          >
            Inject Negative Irradiance (&lt;0)
          </button>
          <button
            onClick={() => runBatchSimulatedIngestion('POWER_MISMATCH')}
            className="px-2.5 py-1 bg-amber-500/20 text-amber-300 border border-amber-500/40 rounded hover:bg-amber-500/30 transition-colors cursor-pointer"
          >
            Inject P ≠ V × I Mismatch
          </button>
          <button
            onClick={() => runBatchSimulatedIngestion('OVERVOLTAGE')}
            className="px-2.5 py-1 bg-rose-500/20 text-rose-300 border border-rose-500/40 rounded hover:bg-rose-500/30 transition-colors cursor-pointer"
          >
            Inject Overvoltage (&gt;1500V)
          </button>
          <button
            onClick={() => runBatchSimulatedIngestion('SIMULATED')}
            className="px-2.5 py-1 bg-purple-500/20 text-purple-300 border border-purple-500/40 rounded hover:bg-purple-500/30 transition-colors cursor-pointer"
          >
            Inject Simulated Observation
          </button>
        </div>
      </div>

      {/* Stream Statistics Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl">
          <span className="text-slate-400 block text-[10px] uppercase">Processed Observations</span>
          <span className="text-xl font-bold text-slate-100">{stats.total}</span>
        </div>
        <div className="bg-slate-900 border border-emerald-500/30 p-4 rounded-xl">
          <span className="text-emerald-400 block text-[10px] uppercase">VALID / SIMULATED</span>
          <span className="text-xl font-bold text-emerald-400">{stats.valid}</span>
        </div>
        <div className="bg-slate-900 border border-amber-500/30 p-4 rounded-xl">
          <span className="text-amber-400 block text-[10px] uppercase">SUSPECT</span>
          <span className="text-xl font-bold text-amber-400">{stats.suspect}</span>
        </div>
        <div className="bg-slate-900 border border-rose-500/30 p-4 rounded-xl">
          <span className="text-rose-400 block text-[10px] uppercase">INVALID</span>
          <span className="text-xl font-bold text-rose-400">{stats.invalid}</span>
        </div>
      </div>

      {/* Log Output Table */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-md space-y-3">
        <h2 className="text-sm font-bold text-slate-200 font-mono uppercase tracking-wider flex items-center space-x-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Rust Validator Telemetry Log Buffer</span>
        </h2>

        <div className="overflow-x-auto">
          <table className="w-full text-xs font-mono text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-slate-950">
                <th className="p-2.5">Sensor ID</th>
                <th className="p-2.5">Timestamp</th>
                <th className="p-2.5">Quality Status Tag</th>
                <th className="p-2.5">Validation Rule Flags</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80 text-slate-200">
              {validatedLogs.map((log, i) => (
                <tr key={i} className="hover:bg-slate-950/60">
                  <td className="p-2.5 font-bold text-amber-300">{log.sensor_id}</td>
                  <td className="p-2.5 text-slate-400">{new Date(log.timestamp).toLocaleTimeString()}</td>
                  <td className="p-2.5">
                    {log.status === 'VALID' && (
                      <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 font-bold inline-flex items-center space-x-1">
                        <CheckCircle2 className="w-3 h-3" />
                        <span>VALID</span>
                      </span>
                    )}
                    {log.status === 'SUSPECT' && (
                      <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold inline-flex items-center space-x-1">
                        <AlertTriangle className="w-3 h-3" />
                        <span>SUSPECT</span>
                      </span>
                    )}
                    {log.status === 'INVALID' && (
                      <span className="px-2 py-0.5 rounded bg-rose-500/20 text-rose-400 border border-rose-500/40 font-bold inline-flex items-center space-x-1">
                        <XCircle className="w-3 h-3" />
                        <span>INVALID</span>
                      </span>
                    )}
                    {log.status === 'SIMULATED' && (
                      <span className="px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/40 font-bold inline-flex items-center space-x-1">
                        <Cpu className="w-3 h-3" />
                        <span>SIMULATED</span>
                      </span>
                    )}
                  </td>
                  <td className="p-2.5 text-slate-400">
                    {log.flags.length > 0 ? (
                      <span className="text-amber-300 font-semibold">{log.flags.join(', ')}</span>
                    ) : (
                      <span className="text-slate-600">None</span>
                    )}
                  </td>
                </tr>
              ))}
              {validatedLogs.length === 0 && (
                <tr>
                  <td colSpan={4} className="p-6 text-center text-slate-500">
                    No telemetry records in memory buffer. Click 'Ingest Normal Stream Batch' or use Fault Injector.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
