import React, { useState } from 'react';
import { DollarSign, TrendingUp, Award, Calculator, Percent } from 'lucide-react';

export const EconomicCalculator: React.FC = () => {
  const [params, setParams] = useState({
    dc_capacity_kw: 1000,
    capex_per_watt: 0.85, // $0.85/W DC
    opex_per_kw_year: 12.0, // $12/kW/year
    discount_rate_pct: 6.5,
    project_lifetime_years: 25,
    specific_yield_kwh_kw: 1550,
    electricity_tariff_mwh: 65.0, // $65/MWh
    annual_degradation_pct: 0.40
  });

  const total_capex = params.dc_capacity_kw * 1000 * params.capex_per_watt;
  const annual_opex = params.dc_capacity_kw * params.opex_per_kw_year;

  // LCOE = (CAPEX + sum(OPEX_t / (1+r)^t)) / sum(Energy_t / (1+r)^t)
  let npv_costs = total_capex;
  let npv_energy = 0;
  let npv_revenue = 0;

  for (let t = 1; t <= params.project_lifetime_years; t++) {
    const discount = Math.pow(1 + params.discount_rate_pct / 100, t);
    const annual_energy_kwh = params.dc_capacity_kw * params.specific_yield_kwh_kw * Math.pow(1 - params.annual_degradation_pct / 100, t - 1);
    
    npv_costs += annual_opex / discount;
    npv_energy += (annual_energy_kwh / 1000) / discount; // MWh
    
    const annual_rev = (annual_energy_kwh / 1000) * params.electricity_tariff_mwh;
    npv_revenue += annual_rev / discount;
  }

  const lcoe_per_mwh = npv_costs / npv_energy;
  const npv = npv_revenue - npv_costs;
  const simple_payback = total_capex / (((params.dc_capacity_kw * params.specific_yield_kwh_kw / 1000) * params.electricity_tariff_mwh) - annual_opex);

  return (
    <div className="space-y-6">
      <div className="bg-slate-900 border border-slate-800 p-5 rounded shadow-lg space-y-2">
        <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-0.5">
          Asset Financial Valuation & Bankability
        </span>
        <h1 className="text-xl font-bold text-slate-100 flex items-center space-x-2">
          <DollarSign className="w-5 h-5 text-emerald-400" />
          <span>PV LCOE, NPV & Levelized Cost Engine</span>
        </h1>
        <p className="text-xs text-slate-400">
          Strict separation of physical measurements from financial assumptions. Computes Levelized Cost of Energy ($/MWh), NPV, and payback periods.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Financial Inputs */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-md space-y-4 text-xs font-mono">
          <h2 className="text-sm font-bold text-amber-300 uppercase tracking-wider flex items-center space-x-2">
            <Calculator className="w-4 h-4" />
            <span>Economic Parameters</span>
          </h2>

          <div className="space-y-3">
            <div>
              <label className="text-slate-400 block mb-1">Installed DC Capacity (kWp):</label>
              <input
                type="number"
                value={params.dc_capacity_kw}
                onChange={(e) => setParams({ ...params, dc_capacity_kw: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-700 text-slate-200 px-3 py-1.5 rounded"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Total CAPEX ($ / Wp):</label>
              <input
                type="number"
                step="0.05"
                value={params.capex_per_watt}
                onChange={(e) => setParams({ ...params, capex_per_watt: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-700 text-slate-200 px-3 py-1.5 rounded"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Annual OPEX ($ / kW / year):</label>
              <input
                type="number"
                value={params.opex_per_kw_year}
                onChange={(e) => setParams({ ...params, opex_per_kw_year: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-700 text-slate-200 px-3 py-1.5 rounded"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">PPA / Tariff Price ($ / MWh):</label>
              <input
                type="number"
                value={params.electricity_tariff_mwh}
                onChange={(e) => setParams({ ...params, electricity_tariff_mwh: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-700 text-slate-200 px-3 py-1.5 rounded"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Discount Rate WACC (%):</label>
              <input
                type="number"
                step="0.5"
                value={params.discount_rate_pct}
                onChange={(e) => setParams({ ...params, discount_rate_pct: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-700 text-slate-200 px-3 py-1.5 rounded"
              />
            </div>
          </div>
        </div>

        {/* Financial Metrics Cards */}
        <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-4 font-mono">
          <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-md space-y-2 flex flex-col justify-between">
            <div className="flex items-center justify-between text-slate-400">
              <span className="text-xs uppercase">Levelized Cost of Energy (LCOE)</span>
              <DollarSign className="w-5 h-5 text-emerald-400" />
            </div>
            <div className="text-3xl font-extrabold text-emerald-400">${lcoe_per_mwh.toFixed(2)} <span className="text-sm text-slate-400 font-normal">/ MWh</span></div>
            <div className="text-xs text-slate-400">Competitive utility-scale cost benchmark</div>
          </div>

          <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-md space-y-2 flex flex-col justify-between">
            <div className="flex items-center justify-between text-slate-400">
              <span className="text-xs uppercase">Net Present Value (NPV)</span>
              <TrendingUp className="w-5 h-5 text-amber-400" />
            </div>
            <div className="text-3xl font-extrabold text-amber-400">${(npv / 1000).toFixed(1)}k</div>
            <div className="text-xs text-slate-400">Discounted at {params.discount_rate_pct}% over {params.project_lifetime_years} yrs</div>
          </div>

          <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-md space-y-2 flex flex-col justify-between">
            <div className="flex items-center justify-between text-slate-400">
              <span className="text-xs uppercase">Simple Payback Period</span>
              <Award className="w-5 h-5 text-blue-400" />
            </div>
            <div className="text-3xl font-extrabold text-blue-400">{simple_payback.toFixed(1)} <span className="text-sm text-slate-400 font-normal">Years</span></div>
            <div className="text-xs text-slate-400">Initial CAPEX recovery horizon</div>
          </div>

          <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-md space-y-2 flex flex-col justify-between">
            <div className="flex items-center justify-between text-slate-400">
              <span className="text-xs uppercase">Total Initial CAPEX</span>
              <Percent className="w-5 h-5 text-purple-400" />
            </div>
            <div className="text-3xl font-extrabold text-slate-100">${(total_capex / 1000).toFixed(0)}k</div>
            <div className="text-xs text-slate-400">Modules, Inverters, BOS, EPC & Permitting</div>
          </div>
        </div>
      </div>
    </div>
  );
};
