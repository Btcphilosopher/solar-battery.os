import React, { useState, useEffect } from 'react';
import { Layers, MapPin, Zap, Activity, CheckCircle2, AlertTriangle, Cpu } from 'lucide-react';

export const DigitalTwin: React.FC = () => {
  const [topology, setTopology] = useState<any>(null);
  const [selectedString, setSelectedString] = useState<string>('STR_01_A');

  useEffect(() => {
    fetch('/api/installations/inst-mojave-01/topology')
      .then(res => res.json())
      .then(data => setTopology(data))
      .catch(err => console.error('Topology error:', err));
  }, []);

  return (
    <div className="space-y-6">
      <div className="bg-slate-900 border border-slate-800 p-5 rounded shadow-lg space-y-2">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-0.5">
              Physical Hierarchy & Structural Topology
            </span>
            <h1 className="text-xl font-bold text-slate-100 flex items-center space-x-2">
              <Layers className="w-5 h-5 text-amber-400" />
              <span>Solar Farm Digital Twin Array Topology</span>
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              Physical hierarchy tree connecting PostGIS coordinates, site boundaries, array strings, MPPT channels, and module string wiring.
            </p>
          </div>
          <span className="text-[10px] font-mono px-3 py-1 bg-amber-400/10 text-amber-400 rounded border border-amber-400/30 font-bold self-start sm:self-auto">
            SITE ➔ ARRAY ➔ INVERTER ➔ STRING ➔ PANEL
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Topology Hierarchy Tree Column */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-md space-y-4">
          <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wider font-mono flex items-center space-x-2">
            <MapPin className="w-4 h-4 text-emerald-400" />
            <span>Site Structural Hierarchy</span>
          </h2>

          <div className="space-y-3 font-mono text-xs">
            <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-slate-100 font-bold">
                <span>{topology?.site_name || 'Mojave Solar Farm Alpha'}</span>
                <span className="text-amber-400">{topology?.capacity_kw || 25000} kW DC</span>
              </div>
              <div className="text-[11px] text-slate-400">PostGIS: SRID 4326 POLYGON((-116.851 34.951, -116.849 34.951, ...))</div>

              {/* Arrays */}
              <div className="pl-3 border-l-2 border-amber-500/40 space-y-3 mt-3">
                {topology?.arrays?.map((arr: any) => (
                  <div key={arr.array_code} className="space-y-2">
                    <div className="flex items-center justify-between text-slate-200 font-semibold bg-slate-900 p-2 rounded">
                      <span>{arr.array_code}</span>
                      <span className="text-[10px] text-slate-400">{arr.inverter.model}</span>
                    </div>

                    {/* Strings */}
                    <div className="pl-3 space-y-1.5">
                      {arr.strings.map((str: any) => (
                        <button
                          key={str.string_code}
                          onClick={() => setSelectedString(str.string_code)}
                          className={`w-full text-left p-2 rounded flex items-center justify-between transition-colors cursor-pointer ${
                            selectedString === str.string_code
                              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold'
                              : 'bg-slate-950 text-slate-400 hover:text-slate-200 border border-slate-800'
                          }`}
                        >
                          <div className="flex items-center space-x-2">
                            {str.status === 'HEALTHY' ? (
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                            ) : (
                              <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                            )}
                            <span>{str.string_code} ({str.panels_count} Panels)</span>
                          </div>
                          <span className="text-amber-400">{str.power_kw} kW</span>
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* 2D/3D String Layout & Telemetry Overlay Canvas */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-md space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wider font-mono flex items-center space-x-2">
                <Activity className="w-4 h-4 text-amber-400" />
                <span>String Digital Twin Layout & Real-time Voltage/Current Map</span>
              </h2>
              <span className="text-xs font-mono text-amber-400 bg-slate-950 px-2.5 py-1 rounded border border-slate-800">
                Selected: {selectedString}
              </span>
            </div>

            {/* Panel Grid Visualizer */}
            <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 space-y-4">
              <div className="text-xs font-mono text-slate-400 flex items-center justify-between">
                <span>String Electrical Path (Series Wiring 26 Panels @ 40V nominal)</span>
                <span className="text-emerald-400 font-bold">1,040 V DC String Total</span>
              </div>

              {/* Grid of 26 panels */}
              <div className="grid grid-cols-6 sm:grid-cols-13 gap-1.5 pt-2">
                {Array.from({ length: 26 }).map((_, idx) => {
                  const isWarning = selectedString === 'STR_01_C' && idx > 18;
                  return (
                    <div
                      key={idx}
                      className={`h-16 rounded border flex flex-col items-center justify-center text-[10px] font-mono transition-all hover:scale-105 ${
                        isWarning
                          ? 'bg-amber-500/20 border-amber-500/50 text-amber-300'
                          : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                      }`}
                    >
                      <span className="font-bold text-[9px]">P-{idx + 1}</span>
                      <span className="text-[8px] opacity-80">{isWarning ? '36.2V' : '40.0V'}</span>
                      <span className="text-[8px] opacity-80">{isWarning ? '11.2A' : '12.8A'}</span>
                    </div>
                  );
                })}
              </div>

              <div className="flex items-center justify-between text-xs font-mono pt-3 border-t border-slate-800/80">
                <div className="flex items-center space-x-4">
                  <span className="flex items-center space-x-1">
                    <span className="w-3 h-3 rounded bg-emerald-500/20 border border-emerald-500/50 inline-block" />
                    <span className="text-slate-400 text-[11px]">Normal String Cell</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <span className="w-3 h-3 rounded bg-amber-500/20 border border-amber-500/50 inline-block" />
                    <span className="text-slate-400 text-[11px]">Soiling / Shading Derate</span>
                  </span>
                </div>
                <div className="text-slate-400 text-[11px]">MPPT Tracker #1 (SMA Pro)</div>
              </div>
            </div>
          </div>

          <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 text-xs text-slate-300 flex items-center justify-between font-mono">
            <span className="flex items-center space-x-2">
              <Cpu className="w-4 h-4 text-amber-400" />
              <span>PostGIS Spatial Coordinates: PointZ(-116.85042 34.95011 682m)</span>
            </span>
            <span className="text-amber-400 font-bold">Tilt: 25.0° · Azimuth: 180.0°</span>
          </div>
        </div>
      </div>
    </div>
  );
};
