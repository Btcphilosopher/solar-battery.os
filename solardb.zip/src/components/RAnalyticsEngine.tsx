import React, { useState, useEffect } from 'react';
import { BarChart3, Sliders, TrendingDown, Layers, Zap, Cpu } from 'lucide-react';
import { ResponsiveContainer, LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, Legend } from 'recharts';
import { IVPoint, DegradationPoint, LossStage } from '../types';

export const RAnalyticsEngine: React.FC = () => {
  const [activeModule, setActiveModule] = useState<'IV_CURVE' | 'DEGRADATION' | 'WATERFALL' | 'LAYOUT'>('IV_CURVE');

  // I-V Curve State
  const [ivParams, setIvParams] = useState({
    voc: 49.8,
    isc: 14.15,
    vmpp: 41.6,
    impp: 13.22,
    irradiance: 1000,
    temp_c: 25
  });
  const [ivCurveData, setIvCurveData] = useState<IVPoint[]>([]);
  const [ivSummary, setIvSummary] = useState<any>(null);

  // Degradation State
  const [degParams, setDegParams] = useState({
    initial_capacity_kw: 1000,
    annual_degradation_pct: 0.40,
    thermal_stress_factor: 1.1,
    humidity_stress_factor: 1.0
  });
  const [degData, setDegData] = useState<DegradationPoint[]>([]);

  // Waterfall State
  const [waterfallData, setWaterfallData] = useState<LossStage[]>([]);

  useEffect(() => {
    fetchIVCurve();
  }, [ivParams]);

  useEffect(() => {
    fetchDegradation();
  }, [degParams]);

  useEffect(() => {
    fetchWaterfall();
  }, []);

  const fetchIVCurve = async () => {
    try {
      const res = await fetch('/api/analytics/iv-curve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(ivParams)
      });
      const data = await res.json();
      setIvCurveData(data.curve || []);
      setIvSummary(data.summary || null);
    } catch (err) {
      console.error('IV Curve error:', err);
    }
  };

  const fetchDegradation = async () => {
    try {
      const res = await fetch('/api/analytics/degradation', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(degParams)
      });
      const data = await res.json();
      setDegData(data.forecast || []);
    } catch (err) {
      console.error('Degradation error:', err);
    }
  };

  const fetchWaterfall = async () => {
    try {
      const res = await fetch('/api/analytics/loss-waterfall');
      const data = await res.json();
      setWaterfallData(data.stages || []);
    } catch (err) {
      console.error('Waterfall error:', err);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded shadow-lg space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-0.5">
              Scientific Photovoltaic Modeling
            </span>
            <h1 className="text-xl font-bold text-slate-100 flex items-center space-x-2">
              <BarChart3 className="w-5 h-5 text-amber-400" />
              <span>R Analytics Engine (`solardb.analytics`)</span>
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              Single-diode I-V/P-V curves, 25-year degradation modeling with 95% CI, system loss cascades, and array layout optimization.
            </p>
          </div>

          {/* Module Switcher */}
          <div className="flex items-center space-x-1 bg-slate-950 p-1 rounded border border-slate-800 text-xs font-mono">
            <button
              onClick={() => setActiveModule('IV_CURVE')}
              className={`px-3 py-1.5 rounded transition-all cursor-pointer font-bold ${
                activeModule === 'IV_CURVE' ? 'bg-amber-400/20 text-amber-400 border border-amber-400/40' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              I-V / P-V Curves
            </button>
            <button
              onClick={() => setActiveModule('DEGRADATION')}
              className={`px-3 py-1.5 rounded transition-all cursor-pointer font-bold ${
                activeModule === 'DEGRADATION' ? 'bg-amber-400/20 text-amber-400 border border-amber-400/40' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              25-Yr Degradation
            </button>
            <button
              onClick={() => setActiveModule('WATERFALL')}
              className={`px-3 py-1.5 rounded transition-all cursor-pointer font-bold ${
                activeModule === 'WATERFALL' ? 'bg-amber-400/20 text-amber-400 border border-amber-400/40' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Loss Waterfall
            </button>
          </div>
        </div>
      </div>

      {/* MODULE 1: I-V & P-V CURVE ANALYZER */}
      {activeModule === 'IV_CURVE' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-md space-y-4">
            <h2 className="text-sm font-bold text-amber-300 font-mono uppercase tracking-wider flex items-center space-x-2">
              <Sliders className="w-4 h-4" />
              <span>Diode Operating Parameters</span>
            </h2>

            <div className="space-y-4 text-xs font-mono">
              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>Irradiance (W/m²):</span>
                  <span className="text-amber-400 font-bold">{ivParams.irradiance} W/m²</span>
                </div>
                <input
                  type="range"
                  min="100"
                  max="1200"
                  step="50"
                  value={ivParams.irradiance}
                  onChange={(e) => setIvParams({ ...ivParams, irradiance: Number(e.target.value) })}
                  className="w-full accent-amber-400 cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-slate-300 mb-1">
                  <span>Module Temperature (°C):</span>
                  <span className="text-amber-400 font-bold">{ivParams.temp_c} °C</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="75"
                  step="5"
                  value={ivParams.temp_c}
                  onChange={(e) => setIvParams({ ...ivParams, temp_c: Number(e.target.value) })}
                  className="w-full accent-amber-400 cursor-pointer"
                />
              </div>

              {ivSummary && (
                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-2 text-xs">
                  <div className="font-bold text-slate-200 border-b border-slate-800 pb-1">R Model Outputs</div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Pmax Output:</span>
                    <span className="text-amber-400 font-bold">{ivSummary.pmax_w} W</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Effective Voc:</span>
                    <span className="text-slate-200">{ivSummary.voc_v} V</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Effective Isc:</span>
                    <span className="text-slate-200">{ivSummary.isc_a} A</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Fill Factor (FF):</span>
                    <span className="text-emerald-400 font-bold">{(ivSummary.fill_factor * 100).toFixed(2)} %</span>
                  </div>
                </div>
              )}
            </div>
          </div>

          <div className="lg:col-span-2 bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-md space-y-3">
            <h2 className="text-sm font-bold text-slate-100 font-mono flex items-center space-x-2">
              <Zap className="w-4 h-4 text-amber-400" />
              <span>Photovoltaic I-V and P-V Characteristic Curves</span>
            </h2>

            <div className="h-80 w-full pt-2">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={ivCurveData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="voltage_v" stroke="#94a3b8" fontSize={11} label={{ value: 'Voltage (V)', position: 'insideBottom', offset: -5, fill: '#94a3b8' }} />
                  <YAxis yAxisId="left" stroke="#38bdf8" fontSize={11} label={{ value: 'Current (A)', angle: -90, position: 'insideLeft', fill: '#38bdf8' }} />
                  <YAxis yAxisId="right" orientation="right" stroke="#f59e0b" fontSize={11} label={{ value: 'Power (W)', angle: 90, position: 'insideRight', fill: '#f59e0b' }} />
                  <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '0.5rem', color: '#f8fafc' }} />
                  <Legend />
                  <Line yAxisId="left" type="monotone" dataKey="current_a" name="Current (A)" stroke="#38bdf8" strokeWidth={2} dot={false} />
                  <Line yAxisId="right" type="monotone" dataKey="power_w" name="Power (W)" stroke="#f59e0b" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {/* MODULE 2: DEGRADATION MODELING */}
      {activeModule === 'DEGRADATION' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-md space-y-4 font-mono text-xs">
            <h2 className="text-sm font-bold text-amber-300 uppercase tracking-wider flex items-center space-x-2">
              <TrendingDown className="w-4 h-4" />
              <span>Stress Factors</span>
            </h2>

            <div className="space-y-3">
              <div>
                <label className="text-slate-400 block mb-1">Base Annual Degradation Rate (%):</label>
                <input
                  type="number"
                  step="0.05"
                  value={degParams.annual_degradation_pct}
                  onChange={(e) => setDegParams({ ...degParams, annual_degradation_pct: Number(e.target.value) })}
                  className="w-full bg-slate-950 border border-slate-700 text-slate-200 px-3 py-1.5 rounded"
                />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">Thermal Stress Multiplier:</label>
                <input
                  type="number"
                  step="0.1"
                  value={degParams.thermal_stress_factor}
                  onChange={(e) => setDegParams({ ...degParams, thermal_stress_factor: Number(e.target.value) })}
                  className="w-full bg-slate-950 border border-slate-700 text-slate-200 px-3 py-1.5 rounded"
                />
              </div>
            </div>
          </div>

          <div className="lg:col-span-2 bg-slate-900 border border-slate-800 p-5 rounded-xl shadow-md space-y-3">
            <h2 className="text-sm font-bold text-slate-100 font-mono">25-Year Capacity Retention & 95% Confidence Forecast</h2>
            <div className="h-80 w-full pt-2">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={degData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="year" stroke="#94a3b8" fontSize={11} label={{ value: 'Operating Year', position: 'insideBottom', offset: -5, fill: '#94a3b8' }} />
                  <YAxis stroke="#f59e0b" fontSize={11} label={{ value: 'Capacity (kW)', angle: -90, position: 'insideLeft', fill: '#f59e0b' }} />
                  <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '0.5rem', color: '#f8fafc' }} />
                  <Legend />
                  <Line type="monotone" dataKey="capacity_kw_exp" name="Exponential Model (kW)" stroke="#f59e0b" strokeWidth={2.5} dot={false} />
                  <Line type="monotone" dataKey="upper_bound_kw" name="Upper 95% Bound" stroke="#34d399" strokeDasharray="4 4" dot={false} />
                  <Line type="monotone" dataKey="lower_bound_kw" name="Lower 95% Bound" stroke="#f87171" strokeDasharray="4 4" dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {/* MODULE 3: SYSTEM LOSS CASCADE WATERFALL */}
      {activeModule === 'WATERFALL' && (
        <div className="bg-slate-900 border border-slate-800 p-6 rounded-xl shadow-md space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
                <Layers className="w-5 h-5 text-amber-400" />
                <span>Standardized System Loss Hierarchy Waterfall</span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Full loss breakdown from gross incident solar energy down to net delivered AC grid energy.
              </p>
            </div>
            <span className="text-xs font-mono px-3 py-1 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
              PR: 81.60 %
            </span>
          </div>

          <div className="h-80 w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={waterfallData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis type="number" stroke="#94a3b8" fontSize={11} />
                <YAxis dataKey="name" type="category" stroke="#94a3b8" fontSize={10} width={180} />
                <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '0.5rem', color: '#f8fafc' }} />
                <Bar dataKey="output_kwh" name="Energy Remaining (kWh)" fill="#f59e0b" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}
    </div>
  );
};
