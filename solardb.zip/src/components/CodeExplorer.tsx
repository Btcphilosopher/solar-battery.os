import React, { useState, useEffect } from 'react';
import { Code, FileCode, Folder, ChevronRight, ChevronDown, Check } from 'lucide-react';
import { CodebaseItem } from '../types';

export const CodeExplorer: React.FC = () => {
  const [tree, setTree] = useState<CodebaseItem[]>([]);
  const [selectedFile, setSelectedFile] = useState<CodebaseItem | null>(null);
  const [expandedFolders, setExpandedFolders] = useState<Record<string, boolean>>({ 'solardb': true });
  const [copied, setCopied] = useState<boolean>(false);

  useEffect(() => {
    fetch('/api/codebase')
      .then(res => res.json())
      .then(data => {
        setTree(data.tree || []);
        // Select first file
        const findFirstFile = (items: CodebaseItem[]): CodebaseItem | null => {
          for (const item of items) {
            if (item.type === 'file') return item;
            if (item.children) {
              const f = findFirstFile(item.children);
              if (f) return f;
            }
          }
          return null;
        };
        const first = findFirstFile(data.tree || []);
        if (first) setSelectedFile(first);
      })
      .catch(err => console.error('Codebase error:', err));
  }, []);

  const toggleFolder = (path: string) => {
    setExpandedFolders(prev => ({ ...prev, [path]: !prev[path] }));
  };

  const copyContent = () => {
    if (selectedFile?.content) {
      navigator.clipboard.writeText(selectedFile.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const renderTree = (items: CodebaseItem[]) => {
    return items.map(item => {
      if (item.type === 'directory') {
        const isExpanded = expandedFolders[item.path] ?? true;
        return (
          <div key={item.path} className="pl-2">
            <button
              onClick={() => toggleFolder(item.path)}
              className="flex items-center space-x-1.5 py-1 px-1.5 rounded hover:bg-slate-800 text-slate-300 w-full text-left font-mono text-xs cursor-pointer"
            >
              {isExpanded ? <ChevronDown className="w-3.5 h-3.5 text-amber-400" /> : <ChevronRight className="w-3.5 h-3.5 text-slate-500" />}
              <Folder className="w-3.5 h-3.5 text-amber-400/80" />
              <span>{item.name}</span>
            </button>
            {isExpanded && item.children && renderTree(item.children)}
          </div>
        );
      } else {
        const isSelected = selectedFile?.path === item.path;
        return (
          <div key={item.path} className="pl-6">
            <button
              onClick={() => setSelectedFile(item)}
              className={`flex items-center space-x-2 py-1 px-2 rounded w-full text-left font-mono text-xs cursor-pointer transition-colors ${
                isSelected ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <FileCode className="w-3.5 h-3.5 opacity-80" />
              <span>{item.name}</span>
            </button>
          </div>
        );
      }
    });
  };

  return (
    <div className="space-y-6">
      <div className="bg-slate-900 border border-slate-800 p-5 rounded shadow-lg space-y-2">
        <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-0.5">
          Platform Architecture & Source Code
        </span>
        <h1 className="text-xl font-bold text-slate-100 flex items-center space-x-2">
          <Code className="w-5 h-5 text-amber-400" />
          <span>SolarDB Engine Codebase & SQL Schema</span>
        </h1>
        <p className="text-xs text-slate-400">
          Inspect production Rust modules, R packages, SQL schemas, migrations, JSON schemas, and test suites.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* Directory Tree Sidebar */}
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-md h-[500px] overflow-y-auto space-y-2">
          <div className="text-xs font-bold text-amber-400 uppercase tracking-wider font-mono border-b border-slate-800 pb-2 mb-2">
            `solardb/` Directory
          </div>
          {renderTree(tree)}
        </div>

        {/* File Content Viewer */}
        <div className="md:col-span-3 bg-slate-950 border border-slate-800 rounded-xl shadow-md flex flex-col h-[500px] overflow-hidden">
          {selectedFile ? (
            <>
              <div className="bg-slate-900 border-b border-slate-800 p-3 flex items-center justify-between font-mono text-xs">
                <span className="text-slate-200 font-bold flex items-center space-x-2">
                  <FileCode className="w-4 h-4 text-amber-400" />
                  <span>{selectedFile.path}</span>
                </span>
                <button
                  onClick={copyContent}
                  className="px-2.5 py-1 rounded bg-slate-800 text-slate-300 hover:text-slate-100 border border-slate-700 transition-colors flex items-center space-x-1 cursor-pointer"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : null}
                  <span>{copied ? 'Copied' : 'Copy File'}</span>
                </button>
              </div>

              <pre className="p-4 overflow-auto text-xs font-mono text-slate-300 leading-relaxed bg-slate-950 flex-1">
                <code>{selectedFile.content}</code>
              </pre>
            </>
          ) : (
            <div className="flex items-center justify-center h-full text-slate-500 font-mono text-xs">
              Select a file from the tree to view contents.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
