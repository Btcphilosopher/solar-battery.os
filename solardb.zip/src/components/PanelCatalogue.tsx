import React, { useState, useEffect } from 'react';
import { PVPanel, Inverter } from '../types';
import { Database, Filter, Search, CheckCircle, AlertTriangle, XCircle, Sliders, Cpu, ArrowRightLeft } from 'lucide-react';

export const PanelCatalogue: React.FC = () => {
  const [panels, setPanels] = useState<PVPanel[]>([]);
  const [inverters, setInverters] = useState<Inverter[]>([]);
  const [techFilter, setTechFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedPanelIds, setSelectedPanelIds] = useState<string[]>([]);

  // Inverter compatibility checker form state
  const [compatForm, setCompatForm] = useState({
    panel_voc: 49.8,
    panel_vmpp: 41.6,
    panel_isc: 14.15,
    panel_impp: 13.22,
    panels_per_string: 26,
    strings_per_mppt: 2,
    inverter_max_dc_voltage: 1100,
    inverter_mppt_min_v: 500,
    inverter_mppt_max_v: 850,
    inverter_max_current_a: 150,
    min_ambient_temp_c: -10,
    max_ambient_temp_c: 45,
    temp_coeff_voc_percent_per_c: -0.25
  });

  const [compatResult, setCompatResult] = useState<any>(null);
  const [checkingCompat, setCheckingCompat] = useState<boolean>(false);

  useEffect(() => {
    fetchPanels();
    fetchInverters();
  }, [techFilter, searchQuery]);

  const fetchPanels = async () => {
    try {
      const res = await fetch(`/api/panels?tech=${techFilter}&search=${encodeURIComponent(searchQuery)}`);
      const data = await res.json();
      setPanels(data.panels || []);
    } catch (err) {
      console.error('Failed to fetch panels:', err);
    }
  };

  const fetchInverters = async () => {
    try {
      const res = await fetch('/api/inverters');
      const data = await res.json();
      setInverters(data.inverters || []);
    } catch (err) {
      console.error('Failed to fetch inverters:', err);
    }
  };

  const handleRunInverterCheck = async () => {
    setCheckingCompat(true);
    try {
      const res = await fetch('/api/inverters/check-compatibility', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(compatForm)
      });
      const data = await res.json();
      setCompatResult(data);
    } catch (err) {
      console.error('Inverter check error:', err);
    } finally {
      setCheckingCompat(false);
    }
  };

  const togglePanelSelection = (id: string) => {
    if (selectedPanelIds.includes(id)) {
      setSelectedPanelIds(selectedPanelIds.filter(i => i !== id));
    } else {
      if (selectedPanelIds.length < 3) {
        setSelectedPanelIds([...selectedPanelIds, id]);
      }
    }
  };

  const selectedPanels = panels.filter(p => selectedPanelIds.includes(p.panel_id));

  return (
    <div className="space-y-8">
      {/* Search & Filter Header */}
      <div className="bg-slate-900 border border-slate-800 p-5 rounded shadow-lg space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-1">
              Asset Registry Catalogue
            </span>
            <h1 className="text-xl font-bold text-slate-100 flex items-center space-x-2">
              <Database className="w-5 h-5 text-amber-400" />
              <span>SolarDB Panel & Inverter Specifications</span>
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              Cell electrical parameters, dimensions, warranties, degradation curves, and bifaciality factors.
            </p>
          </div>

          <div className="flex items-center space-x-3">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search manufacturer, model..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-slate-950 border border-slate-700 text-slate-200 text-xs pl-9 pr-4 py-2 rounded w-64 focus:outline-none focus:border-amber-400 font-mono"
              />
            </div>

            <div className="flex items-center space-x-1 bg-slate-950 border border-slate-700 p-1 rounded text-xs font-mono">
              <Filter className="w-3.5 h-3.5 text-slate-400 ml-1" />
              {['ALL', 'MONOCRYSTALLINE', 'BIFACIAL', 'POLYCRYSTALLINE', 'THIN_FILM'].map(tech => (
                <button
                  key={tech}
                  onClick={() => setTechFilter(tech)}
                  className={`px-2 py-1 rounded transition-colors cursor-pointer ${
                    techFilter === tech ? 'bg-amber-400/20 text-amber-400 font-bold border border-amber-400/40' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {tech === 'ALL' ? 'ALL' : tech.slice(0, 4)}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Panel Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 pt-2">
          {panels.map((panel) => {
            const isSelected = selectedPanelIds.includes(panel.panel_id);
            return (
              <div
                key={panel.panel_id}
                className={`bg-slate-950 border rounded-xl p-4 transition-all flex flex-col justify-between space-y-3 ${
                  isSelected ? 'border-amber-400 ring-1 ring-amber-400/50' : 'border-slate-800 hover:border-slate-700'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[10px] font-mono uppercase tracking-wider px-2 py-0.5 rounded bg-slate-800 text-amber-300 font-semibold border border-slate-700">
                      {panel.technology}
                    </span>
                    <button
                      onClick={() => togglePanelSelection(panel.panel_id)}
                      className={`text-[10px] font-mono font-semibold px-2 py-0.5 rounded border transition-colors ${
                        isSelected
                          ? 'bg-amber-500 text-slate-950 border-amber-400'
                          : 'bg-slate-900 text-slate-400 border-slate-700 hover:text-slate-200'
                      }`}
                    >
                      {isSelected ? 'SELECTED' : '+ COMPARE'}
                    </button>
                  </div>

                  <h3 className="font-bold text-slate-100 text-sm mt-2">{panel.manufacturer}</h3>
                  <div className="text-xs text-slate-400 font-mono mb-3">{panel.model}</div>

                  <div className="grid grid-cols-2 gap-2 text-xs font-mono bg-slate-900/80 p-2.5 rounded-lg border border-slate-800">
                    <div>
                      <span className="text-slate-500 block text-[10px]">Pnom</span>
                      <span className="text-amber-400 font-bold text-sm">{panel.nominal_power_w} W</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[10px]">Efficiency</span>
                      <span className="text-emerald-400 font-bold text-sm">{panel.efficiency_pct} %</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[10px]">Voc / Vmpp</span>
                      <span className="text-slate-200">{panel.voc}V / {panel.vmpp}V</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[10px]">Isc / Impp</span>
                      <span className="text-slate-200">{panel.isc}A / {panel.impp}A</span>
                    </div>
                  </div>
                </div>

                <div className="border-t border-slate-800 pt-2 text-[11px] text-slate-400 space-y-1 font-mono">
                  <div className="flex justify-between">
                    <span>Temp Coeff (Pmax):</span>
                    <span className="text-slate-200">{panel.temp_coeff_power} %/°C</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Warranty / Degradation:</span>
                    <span className="text-slate-200">{panel.warranty_years} yrs ({panel.degradation_rate_pct}%/yr)</span>
                  </div>
                  {panel.is_bifacial && (
                    <div className="flex justify-between text-amber-300">
                      <span>Bifaciality Factor:</span>
                      <span className="font-bold">{(panel.bifaciality_factor * 100).toFixed(0)} %</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Comparison Engine Matrix */}
      {selectedPanels.length > 0 && (
        <div className="bg-slate-900 border border-amber-500/40 p-6 rounded-xl shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-amber-400 flex items-center space-x-2">
              <ArrowRightLeft className="w-5 h-5" />
              <span>Multi-Panel Technical & Financial Comparison Matrix</span>
            </h2>
            <button
              onClick={() => setSelectedPanelIds([])}
              className="text-xs text-slate-400 hover:text-slate-200 font-mono underline"
            >
              Clear Comparison ({selectedPanels.length})
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs font-mono text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 bg-slate-950">
                  <th className="p-3">Metric / Parameter</th>
                  {selectedPanels.map(p => (
                    <th key={p.panel_id} className="p-3 text-amber-300 font-bold">{p.manufacturer} ({p.model})</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 text-slate-200">
                <tr>
                  <td className="p-3 text-slate-400">Nominal Output & Efficiency</td>
                  {selectedPanels.map(p => (
                    <td key={p.panel_id} className="p-3 font-bold">{p.nominal_power_w} W @ {p.efficiency_pct}%</td>
                  ))}
                </tr>
                <tr>
                  <td className="p-3 text-slate-400">Power Density (W / m²)</td>
                  {selectedPanels.map(p => {
                    const area_m2 = (p.dimensions.length_mm * p.dimensions.width_mm) / 1000000;
                    const density = p.nominal_power_w / area_m2;
                    return <td key={p.panel_id} className="p-3 font-semibold text-emerald-400">{density.toFixed(1)} W/m²</td>;
                  })}
                </tr>
                <tr>
                  <td className="p-3 text-slate-400">Lifetime Energy Yield (25 yrs @ 1500 kWh/kWp)</td>
                  {selectedPanels.map(p => {
                    const lifetime_mwh = (p.nominal_power_w / 1000) * 1500 * 25 * (1 - (p.degradation_rate_pct / 100) * 12.5);
                    return <td key={p.panel_id} className="p-3 font-bold text-amber-400">{lifetime_mwh.toFixed(1)} MWh</td>;
                  })}
                </tr>
                <tr>
                  <td className="p-3 text-slate-400">Cost / Watt ($ / Wp)</td>
                  {selectedPanels.map(p => {
                    const cost_per_w = p.price_usd / p.nominal_power_w;
                    return <td key={p.panel_id} className="p-3">${cost_per_w.toFixed(2)} / W</td>;
                  })}
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Rust Inverter Compatibility Checker Workbench */}
      <div className="bg-slate-900 border border-slate-800 p-6 rounded-xl shadow-lg space-y-6">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div>
            <h2 className="text-base font-bold text-slate-100 flex items-center space-x-2">
              <Cpu className="w-5 h-5 text-amber-400" />
              <span>Rust Inverter Compatibility & Array Sizing Validator</span>
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Validates Voc overvoltage under minimum ambient temperatures, hot Vmpp window clipping, and MPPT string current limits.
            </p>
          </div>
          <button
            onClick={handleRunInverterCheck}
            disabled={checkingCompat}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-4 py-2 rounded-lg text-xs transition-colors shadow-md flex items-center space-x-2 cursor-pointer"
          >
            <Sliders className="w-4 h-4" />
            <span>{checkingCompat ? 'Validating Rust Service...' : 'Run Compatibility Audit'}</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Inputs Column */}
          <div className="space-y-3 text-xs font-mono bg-slate-950 p-4 rounded-xl border border-slate-800">
            <h3 className="font-bold text-amber-300 uppercase tracking-wider text-[11px] mb-2">PV Array & Ambient Inputs</h3>
            <div className="space-y-2">
              <div>
                <label className="text-slate-400 block text-[10px]">Panels Per String:</label>
                <input
                  type="number"
                  value={compatForm.panels_per_string}
                  onChange={(e) => setCompatForm({ ...compatForm, panels_per_string: Number(e.target.value) })}
                  className="w-full bg-slate-900 border border-slate-700 text-slate-200 px-2 py-1 rounded"
                />
              </div>
              <div>
                <label className="text-slate-400 block text-[10px]">Panel Voc (V) / Vmpp (V):</label>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="number"
                    value={compatForm.panel_voc}
                    onChange={(e) => setCompatForm({ ...compatForm, panel_voc: Number(e.target.value) })}
                    className="bg-slate-900 border border-slate-700 text-slate-200 px-2 py-1 rounded"
                  />
                  <input
                    type="number"
                    value={compatForm.panel_vmpp}
                    onChange={(e) => setCompatForm({ ...compatForm, panel_vmpp: Number(e.target.value) })}
                    className="bg-slate-900 border border-slate-700 text-slate-200 px-2 py-1 rounded"
                  />
                </div>
              </div>
              <div>
                <label className="text-slate-400 block text-[10px]">Min / Max Temperature (°C):</label>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="number"
                    value={compatForm.min_ambient_temp_c}
                    onChange={(e) => setCompatForm({ ...compatForm, min_ambient_temp_c: Number(e.target.value) })}
                    className="bg-slate-900 border border-slate-700 text-slate-200 px-2 py-1 rounded"
                  />
                  <input
                    type="number"
                    value={compatForm.max_ambient_temp_c}
                    onChange={(e) => setCompatForm({ ...compatForm, max_ambient_temp_c: Number(e.target.value) })}
                    className="bg-slate-900 border border-slate-700 text-slate-200 px-2 py-1 rounded"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Inverter Specs Column */}
          <div className="space-y-3 text-xs font-mono bg-slate-950 p-4 rounded-xl border border-slate-800">
            <h3 className="font-bold text-amber-300 uppercase tracking-wider text-[11px] mb-2">Inverter Limits</h3>
            <div className="space-y-2">
              <div>
                <label className="text-slate-400 block text-[10px]">Max DC Input Voltage (V):</label>
                <input
                  type="number"
                  value={compatForm.inverter_max_dc_voltage}
                  onChange={(e) => setCompatForm({ ...compatForm, inverter_max_dc_voltage: Number(e.target.value) })}
                  className="w-full bg-slate-900 border border-slate-700 text-slate-200 px-2 py-1 rounded"
                />
              </div>
              <div>
                <label className="text-slate-400 block text-[10px]">MPPT Range Min (V) / Max (V):</label>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="number"
                    value={compatForm.inverter_mppt_min_v}
                    onChange={(e) => setCompatForm({ ...compatForm, inverter_mppt_min_v: Number(e.target.value) })}
                    className="bg-slate-900 border border-slate-700 text-slate-200 px-2 py-1 rounded"
                  />
                  <input
                    type="number"
                    value={compatForm.inverter_mppt_max_v}
                    onChange={(e) => setCompatForm({ ...compatForm, inverter_mppt_max_v: Number(e.target.value) })}
                    className="bg-slate-900 border border-slate-700 text-slate-200 px-2 py-1 rounded"
                  />
                </div>
              </div>
              <div>
                <label className="text-slate-400 block text-[10px]">MPPT Max Current Limit (A):</label>
                <input
                  type="number"
                  value={compatForm.inverter_max_current_a}
                  onChange={(e) => setCompatForm({ ...compatForm, inverter_max_current_a: Number(e.target.value) })}
                  className="w-full bg-slate-900 border border-slate-700 text-slate-200 px-2 py-1 rounded"
                />
              </div>
            </div>
          </div>

          {/* Rust Output Results Column */}
          <div className="space-y-3 bg-slate-950 p-4 rounded-xl border border-slate-800 flex flex-col justify-between">
            <div>
              <h3 className="font-bold text-slate-200 uppercase tracking-wider text-[11px] mb-2 font-mono">Rust Service Audit Output</h3>
              {compatResult ? (
                <div className="space-y-3 font-mono text-xs">
                  <div className="flex items-center space-x-2">
                    {compatResult.is_compatible ? (
                      <span className="flex items-center space-x-1.5 px-2.5 py-1 rounded bg-emerald-500/20 text-emerald-400 font-bold border border-emerald-500/40">
                        <CheckCircle className="w-4 h-4" />
                        <span>COMPATIBLE</span>
                      </span>
                    ) : (
                      <span className="flex items-center space-x-1.5 px-2.5 py-1 rounded bg-rose-500/20 text-rose-400 font-bold border border-rose-500/40">
                        <XCircle className="w-4 h-4" />
                        <span>INCOMPATIBLE</span>
                      </span>
                    )}
                  </div>

                  <div className="bg-slate-900 p-2.5 rounded border border-slate-800 space-y-1 text-[11px]">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Cold String Voc:</span>
                      <span className="text-amber-400 font-bold">{compatResult.metrics?.max_string_voc_cold} V</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Hot String Vmpp:</span>
                      <span className="text-emerald-400 font-bold">{compatResult.metrics?.min_string_vmpp_hot} V</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">MPPT Current:</span>
                      <span className="text-slate-200">{compatResult.metrics?.max_mppt_current_a} A</span>
                    </div>
                  </div>

                  {compatResult.errors?.length > 0 && (
                    <div className="p-2 rounded bg-rose-500/10 border border-rose-500/30 text-rose-300 text-[11px]">
                      {compatResult.errors.map((e: string, i: number) => (
                        <div key={i} className="flex items-center space-x-1">
                          <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" />
                          <span>{e}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-xs text-slate-500 font-mono py-6 text-center">
                  Click 'Run Compatibility Audit' to execute the Rust rule engine.
                </div>
              )}
            </div>
            <div className="text-[10px] text-slate-500 font-mono text-right">Engine: {compatResult?.engine || 'Rust Axum Backend'}</div>
          </div>
        </div>
      </div>
    </div>
  );
};
