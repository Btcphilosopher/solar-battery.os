#' Single-Diode Model I-V and P-V Curve Generator for Photovoltaic Modules
#' @param voc Nominal Open Circuit Voltage (V) at STC (1000 W/m2, 25 C)
#' @param isc Nominal Short Circuit Current (A) at STC
#' @param vmpp Nominal Voltage at Maximum Power Point (V)
#' @param impp Nominal Current at Maximum Power Point (A)
#' @param irradiance Operating Plane-of-Array Irradiance (W/m2)
#' @param temp_c Operating Cell Temperature (deg C)
#' @param temp_coeff_voc Temperature coefficient for Voc (%/deg C)
#' @param temp_coeff_isc Temperature coefficient for Isc (%/deg C)
#' @return Data frame containing voltage, current, and power vectors

analyse_iv_curve <- function(voc = 49.5, 
                             isc = 11.35, 
                             vmpp = 41.2, 
                             impp = 10.68, 
                             irradiance = 1000, 
                             temp_c = 25, 
                             temp_coeff_voc = -0.27, 
                             temp_coeff_isc = 0.048) {
  
  # Adjust parameters for irradiance and temperature
  delta_t <- temp_c - 25
  G_ratio <- irradiance / 1000
  
  # Effective Isc scales linearly with irradiance and slightly with temp
  isc_eff <- isc * G_ratio * (1 + (temp_coeff_isc / 100) * delta_t)
  
  # Effective Voc drops with temperature and logarithmically with irradiance
  vt_stc <- 0.0259 # Thermal voltage at STC per cell
  voc_eff <- (voc * (1 + (temp_coeff_voc / 100) * delta_t)) + (vt_stc * log(pmax(G_ratio, 1e-4)))
  
  # Thermal diode voltage factor
  a <- 1.15
  v_thermal <- a * 0.0259 * 72 # Assuming 72 cells
  
  # Single diode I-V characteristic vector
  v_seq <- seq(0, pmax(voc_eff, 0.1), length.out = 100)
  
  # Calculate I for each V using modified diode equation
  i_seq <- isc_eff * (1 - exp((v_seq - voc_eff) / v_thermal))
  i_seq <- pmax(i_seq, 0)
  
  p_seq <- v_seq * i_seq
  
  p_max_idx <- which.max(p_seq)
  vmpp_calc <- v_seq[p_max_idx]
  impp_calc <- i_seq[p_max_idx]
  pmax_calc <- p_seq[p_max_idx]
  ff_calc <- pmax_calc / (voc_eff * isc_eff)
  
  list(
    curve = data.frame(
      voltage_v = round(v_seq, 3),
      current_a = round(i_seq, 3),
      power_w = round(p_seq, 3)
    ),
    summary = list(
      pmax_w = round(pmax_calc, 2),
      voc_v = round(voc_eff, 2),
      isc_a = round(isc_eff, 2),
      vmpp_v = round(vmpp_calc, 2),
      impp_a = round(impp_calc, 2),
      fill_factor = round(ff_calc, 4),
      operating_temp_c = temp_c,
      irradiance_w_m2 = irradiance
    )
  )
}
