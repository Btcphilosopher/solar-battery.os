#' Multi-Objective PV Array Layout & Orientation Optimizer
#' @param latitude Latitude of the site (deg)
#' @param available_area_m2 Ground or roof available area (m2)
#' @param objective Objective target: 'MAXIMISE_ENERGY', 'MINIMISE_COST', 'MAXIMISE_ROI', 'MINIMISE_LOSSES'
#' @param panel_wattage Wattage of selected candidate panel (W)
#' @param panel_length_m Panel length dimension (m)
#' @param panel_width_m Panel width dimension (m)
#' @return List with optimal tilt, azimuth, row pitch, string configuration, and energy yield

optimise_array <- function(latitude = 37.7749,
                           available_area_m2 = 5000,
                           objective = "MAXIMISE_ENERGY",
                           panel_wattage = 550,
                           panel_length_m = 2.278,
                           panel_width_m = 1.134) {
  
  # Rule of thumb optimal tilt for fixed tilt ~ latitude * 0.87 (for year-round energy)
  optimal_tilt <- round(abs(latitude) * 0.87, 1)
  
  # Optimal azimuth for Northern Hemisphere is 180 (South), Southern Hemisphere is 0 (North)
  optimal_azimuth <- ifelse(latitude >= 0, 180, 0)
  
  # Calculate row spacing (pitch) to avoid inter-row shading at winter solstice solar altitude
  solstice_alt_deg <- 90 - abs(latitude) - 23.45
  solstice_alt_rad <- pmax(solstice_alt_deg, 10) * (pi / 180)
  
  slant_height <- panel_length_m * sin(optimal_tilt * (pi / 180))
  min_row_spacing <- slant_height / tan(solstice_alt_rad)
  pitch <- panel_length_m * cos(optimal_tilt * (pi / 180)) + min_row_spacing
  
  # Module footprint area per panel considering row pitch
  area_per_panel <- pitch * panel_width_m
  max_panels <- floor(available_area_m2 / area_per_panel)
  installed_dc_kw <- (max_panels * panel_wattage) / 1000
  
  # Estimate annual generation yield
  base_yield_kwh_kwp <- 1550 - (abs(latitude - 25) * 12)
  annual_generation_mwh <- (installed_dc_kw * base_yield_kwh_kwp) / 1000
  
  list(
    site_parameters = list(
      latitude = latitude,
      available_area_m2 = available_area_m2,
      objective = objective
    ),
    optimal_geometry = list(
      tilt_deg = optimal_tilt,
      azimuth_deg = optimal_azimuth,
      row_pitch_m = round(pitch, 2),
      min_row_spacing_m = round(min_row_spacing, 2)
    ),
    system_layout = list(
      total_panels = max_panels,
      dc_capacity_kw = round(installed_dc_kw, 2),
      panels_per_string = 26,
      total_strings = ceiling(max_panels / 26),
      mppt_channels_required = ceiling((max_panels / 26) / 2)
    ),
    energy_estimates = list(
      annual_generation_mwh = round(annual_generation_mwh, 2),
      capacity_factor_pct = round((annual_generation_mwh * 1000) / (installed_dc_kw * 8760) * 100, 2),
      specific_yield_kwh_kwp = round(base_yield_kwh_kwp, 1)
    )
  )
}
