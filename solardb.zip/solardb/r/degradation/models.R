#' Photovoltaic Module Degradation Modeling & Lifetime Output Forecasting
#' @param initial_capacity_kw Rated DC capacity of system in kW
#' @param annual_degradation_pct Base annual degradation rate (e.g. 0.5% / year)
#' @param years Horizon in years (e.g. 25 or 30 years)
#' @param thermal_stress_factor Additional degradation penalty for high operating temperatures
#' @param humidity_stress_factor Potential Induced Degradation (PID) & moisture stress factor
#' @return Data frame with annual output, degradation loss, and upper/lower confidence bounds

analyse_degradation <- function(initial_capacity_kw = 1000,
                                annual_degradation_pct = 0.5,
                                years = 25,
                                thermal_stress_factor = 1.0,
                                humidity_stress_factor = 1.0) {
  
  effective_annual_rate <- (annual_degradation_pct / 100) * thermal_stress_factor * humidity_stress_factor
  
  year_vec <- 1:years
  
  # Year 1 initial light-induced degradation (LID) ~ 1.5%
  lid_factor <- 0.985
  
  # Exponential degradation model
  capacity_exp <- initial_capacity_kw * lid_factor * (1 - effective_annual_rate)^(year_vec - 1)
  
  # Linear degradation model
  capacity_lin <- initial_capacity_kw * lid_factor * (1 - effective_annual_rate * (year_vec - 1))
  
  # 95% Confidence bounds (+/- 0.15% per year variance)
  std_error <- 0.0015 * sqrt(year_vec)
  upper_bound <- capacity_exp * (1 + 1.96 * std_error)
  lower_bound <- capacity_exp * (1 - 1.96 * std_error)
  
  # Expected annual energy yield assuming 1450 kWh/kWp baseline
  specific_yield <- 1450
  annual_energy_mwh <- (capacity_exp * specific_yield) / 1000
  cumulative_energy_mwh <- cumsum(annual_energy_mwh)
  
  data.frame(
    year = year_vec,
    capacity_kw_exp = round(capacity_exp, 2),
    capacity_kw_lin = round(capacity_lin, 2),
    upper_bound_kw = round(upper_bound, 2),
    lower_bound_kw = round(lower_bound, 2),
    annual_energy_mwh = round(annual_energy_mwh, 2),
    cumulative_energy_mwh = round(cumulative_energy_mwh, 2),
    retention_pct = round((capacity_exp / initial_capacity_kw) * 100, 2)
  )
}
