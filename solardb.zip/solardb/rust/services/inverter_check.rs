use serde::{Deserialize, Serialize};

#[derive(Debug, Serialize, Deserialize)]
pub struct PanelCompatibilityRequest {
    pub panel_voc: f64,
    pub panel_vmpp: f64,
    pub panel_isc: f64,
    pub panel_impp: f64,
    pub panels_per_string: usize,
    pub strings_per_mppt: usize,
    pub inverter_max_dc_voltage: f64,
    pub inverter_mppt_min_v: f64,
    pub inverter_mppt_max_v: f64,
    pub inverter_max_current_a: f64,
    pub min_ambient_temp_c: f64,
    pub max_ambient_temp_c: f64,
    pub temp_coeff_voc_percent_per_c: f64,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct InverterCompatibilityResult {
    pub is_compatible: bool,
    pub max_string_voc_cold: f64,
    pub min_string_vmpp_hot: f64,
    pub max_string_vmpp_cold: f64,
    pub max_mppt_current: f64,
    pub warnings: Vec<String>,
    pub errors: Vec<String>,
}

pub struct InverterChecker;

impl InverterChecker {
    pub fn check(req: &PanelCompatibilityRequest) -> InverterCompatibilityResult {
        let mut warnings = Vec::new();
        let mut errors = Vec::new();

        // Voc increases at lower temperatures (STC is 25°C)
        let temp_diff_cold = req.min_ambient_temp_c - 25.0;
        let voc_cold_factor = 1.0 + (req.temp_coeff_voc_percent_per_c / 100.0) * temp_diff_cold;
        let string_voc_cold = (req.panels_per_string as f64) * req.panel_voc * voc_cold_factor;

        let temp_diff_hot = req.max_ambient_temp_c - 25.0;
        let vmpp_hot_factor = 1.0 + (req.temp_coeff_voc_percent_per_c / 100.0) * temp_diff_hot;
        let string_vmpp_hot = (req.panels_per_string as f64) * req.panel_vmpp * vmpp_hot_factor;
        let string_vmpp_cold = (req.panels_per_string as f64) * req.panel_vmpp * voc_cold_factor;

        let total_mppt_current = (req.strings_per_mppt as f64) * req.panel_impp;

        if string_voc_cold > req.inverter_max_dc_voltage {
            errors.push(format!(
                "Max cold Voc ({:.1}V) exceeds inverter max DC limit ({:.1}V)!",
                string_voc_cold, req.inverter_max_dc_voltage
            ));
        }

        if string_vmpp_hot < req.inverter_mppt_min_v {
            warnings.push(format!(
                "Min hot Vmpp ({:.1}V) drops below MPPT min threshold ({:.1}V). Inverter will clip or drop efficiency.",
                string_vmpp_hot, req.inverter_mppt_min_v
            ));
        }

        if string_vmpp_cold > req.inverter_mppt_max_v {
            warnings.push(format!(
                "Max cold Vmpp ({:.1}V) exceeds MPPT max threshold ({:.1}V).",
                string_vmpp_cold, req.inverter_mppt_max_v
            ));
        }

        if total_mppt_current > req.inverter_max_current_a {
            errors.push(format!(
                "String current ({:.1}A) exceeds MPPT input limit ({:.1}A)!",
                total_mppt_current, req.inverter_max_current_a
            ));
        }

        let is_compatible = errors.is_empty();

        InverterCompatibilityResult {
            is_compatible,
            max_string_voc_cold: string_voc_cold,
            min_string_vmpp_hot: string_vmpp_hot,
            max_string_vmpp_cold: string_vmpp_cold,
            max_mppt_current: total_mppt_current,
            warnings,
            errors,
        }
    }
}
