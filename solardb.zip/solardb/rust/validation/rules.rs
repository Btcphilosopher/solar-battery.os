use crate::validation::quality_tag::{QualityReport, QualityStatus};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TelemetryObservation {
    pub sensor_id: String,
    pub timestamp: chrono::DateTime<chrono::Utc>,
    pub dc_voltage_v: Option<f64>,
    pub dc_current_a: Option<f64>,
    pub dc_power_w: Option<f64>,
    pub ac_power_w: Option<f64>,
    pub irradiance_w_m2: Option<f64>,
    pub module_temp_c: Option<f64>,
    pub grid_frequency_hz: Option<f64>,
    pub is_simulated: bool,
}

pub struct TelemetryValidator;

impl TelemetryValidator {
    pub fn validate(obs: &TelemetryObservation) -> QualityReport {
        let mut flags = Vec::new();
        let mut is_invalid = false;
        let mut is_suspect = false;

        if obs.is_simulated {
            return QualityReport {
                status: QualityStatus::SIMULATED,
                flags: vec!["SIMULATED_DATA_SOURCE".to_string()],
                timestamp: chrono::Utc::now(),
            };
        }

        // Irradiance bounds
        if let Some(irr) = obs.irradiance_w_m2 {
            if irr < 0.0 {
                flags.push("NEGATIVE_IRRADIANCE".to_string());
                is_invalid = true;
            } else if irr > 1600.0 {
                flags.push("EXTREME_IRRADIANCE_EXCEEDS_SOLAR_CONSTANT".to_string());
                is_suspect = true;
            }
        } else {
            flags.push("MISSING_IRRADIANCE".to_string());
            is_suspect = true;
        }

        // Voltage bounds
        if let Some(v_dc) = obs.dc_voltage_v {
            if v_dc < 0.0 {
                flags.push("NEGATIVE_DC_VOLTAGE".to_string());
                is_invalid = true;
            } else if v_dc > 1500.0 {
                flags.push("DC_VOLTAGE_EXCEEDS_SAFETY_LIMIT_1500V".to_string());
                is_invalid = true;
            }
        }

        // Temperature bounds
        if let Some(temp) = obs.module_temp_c {
            if temp < -50.0 || temp > 120.0 {
                flags.push("OUT_OF_RANGE_TEMPERATURE".to_string());
                is_invalid = true;
            }
        }

        // Electrical consistency check: P_dc ~ V_dc * I_dc
        if let (Some(v), Some(i), Some(p)) = (obs.dc_voltage_v, obs.dc_current_a, obs.dc_power_w) {
            let calculated_p = v * i;
            if (calculated_p - p).abs() > (0.15 * p.max(10.0)) {
                flags.push("POWER_VOLTAGE_CURRENT_MISMATCH".to_string());
                is_suspect = true;
            }
        }

        let status = if is_invalid {
            QualityStatus::INVALID
        } else if is_suspect {
            QualityStatus::SUSPECT
        } else {
            QualityStatus::VALID
        };

        QualityReport {
            status,
            flags,
            timestamp: chrono::Utc::now(),
        }
    }
}
