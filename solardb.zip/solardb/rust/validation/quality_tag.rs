use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum QualityStatus {
    VALID,
    SUSPECT,
    INVALID,
    MISSING,
    SIMULATED,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct QualityReport {
    pub status: QualityStatus,
    pub flags: Vec<String>,
    pub timestamp: chrono::DateTime<chrono::Utc>,
}
