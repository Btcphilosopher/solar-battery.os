use crate::validation::rules::{TelemetryObservation, TelemetryValidator};
use serde::{Deserialize, Serialize};

#[derive(Debug, Serialize, Deserialize)]
pub struct BatchIngestRequest {
    pub installation_id: String,
    pub observations: Vec<TelemetryObservation>,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct BatchIngestResult {
    pub total_processed: usize,
    pub valid_count: usize,
    pub suspect_count: usize,
    pub invalid_count: usize,
    pub elapsed_ms: u128,
}

pub struct BatchIngestionEngine;

impl BatchIngestionEngine {
    pub async fn process_batch(req: BatchIngestRequest) -> BatchIngestResult {
        let start = std::time::Instant::now();
        let mut valid_count = 0;
        let mut suspect_count = 0;
        let mut invalid_count = 0;

        for obs in &req.observations {
            let report = TelemetryValidator::validate(obs);
            match report.status {
                crate::validation::quality_tag::QualityStatus::VALID => valid_count += 1,
                crate::validation::quality_tag::QualityStatus::SUSPECT => suspect_count += 1,
                crate::validation::quality_tag::QualityStatus::INVALID => invalid_count += 1,
                crate::validation::quality_tag::QualityStatus::MISSING => suspect_count += 1,
                crate::validation::quality_tag::QualityStatus::SIMULATED => valid_count += 1,
            }
        }

        BatchIngestResult {
            total_processed: req.observations.len(),
            valid_count,
            suspect_count,
            invalid_count,
            elapsed_ms: start.elapsed().as_millis(),
        }
    }
}
