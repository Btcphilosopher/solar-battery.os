# SolarDB R Analytics Regression and Numerical Accuracy Tests
library(solardb.analytics)

test_iv_curve <- function() {
  res <- analyse_iv_curve(voc = 49.5, isc = 11.35, vmpp = 41.2, impp = 10.68, irradiance = 1000, temp_c = 25)
  stopifnot(res$summary$pmax_w > 400 && res$summary$pmax_w < 500)
  stopifnot(res$summary$fill_factor > 0.70 && res$summary$fill_factor < 0.85)
  message("IV Curve test passed!")
}

test_degradation <- function() {
  res <- analyse_degradation(initial_capacity_kw = 1000, annual_degradation_pct = 0.5, years = 25)
  stopifnot(nrow(res) == 25)
  stopifnot(res$retention_pct[25] < 90.0 && res$retention_pct[25] > 80.0)
  message("Degradation test passed!")
}

test_iv_curve()
test_degradation()
