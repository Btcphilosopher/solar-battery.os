#[cfg(test)]
mod tests {
    use solardb::validation::quality_tag::QualityStatus;
    use solardb::validation::rules::{TelemetryObservation, TelemetryValidator};

    #[test]
    fn test_valid_telemetry() {
        let obs = TelemetryObservation {
            sensor_id: "SN_1001".to_string(),
            timestamp: chrono::Utc::now(),
            dc_voltage_v: Some(720.0),
            dc_current_a: Some(10.5),
            dc_power_w: Some(7560.0),
            ac_power_w: Some(7400.0),
            irradiance_w_m2: Some(950.0),
            module_temp_c: Some(42.0),
            grid_frequency_hz: Some(50.0),
            is_simulated: false,
        };

        let report = TelemetryValidator::validate(&obs);
        assert_eq!(report.status, QualityStatus::VALID);
        assert!(report.flags.is_empty());
    }

    #[test]
    fn test_negative_irradiance_invalid() {
        let obs = TelemetryObservation {
            sensor_id: "SN_1002".to_string(),
            timestamp: chrono::Utc::now(),
            dc_voltage_v: Some(720.0),
            dc_current_a: Some(10.5),
            dc_power_w: Some(7560.0),
            ac_power_w: Some(7400.0),
            irradiance_w_m2: Some(-15.0), // Invalid!
            module_temp_c: Some(42.0),
            grid_frequency_hz: Some(50.0),
            is_simulated: false,
        };

        let report = TelemetryValidator::validate(&obs);
        assert_eq!(report.status, QualityStatus::INVALID);
        assert!(report.flags.contains(&"NEGATIVE_IRRADIANCE".to_string()));
    }
}
