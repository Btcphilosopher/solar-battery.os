-- SolarDB Database Schema 004: Telemetry, Weather, & Irradiance Storage

-- Production Telemetry (High-frequency append-only)
CREATE TABLE production_telemetry (
    telemetry_id BIGSERIAL PRIMARY KEY,
    installation_id UUID NOT NULL REFERENCES installations(installation_id) ON DELETE CASCADE,
    installed_panel_id UUID REFERENCES installed_panels(installed_panel_id),
    recorded_at TIMESTAMPTZ NOT NULL,
    dc_voltage_v NUMERIC(7,2),
    dc_current_a NUMERIC(6,2),
    dc_power_w NUMERIC(9,2),
    ac_power_w NUMERIC(9,2),
    energy_kwh NUMERIC(12,3),
    module_temp_c NUMERIC(5,2),
    inverter_temp_c NUMERIC(5,2),
    poa_irradiance_w_m2 NUMERIC(7,2),
    grid_frequency_hz NUMERIC(5,2),
    grid_voltage_v NUMERIC(6,2),
    grid_current_a NUMERIC(6,2),
    quality_status quality_status_enum NOT NULL DEFAULT 'VALID',
    quality_flags TEXT[],
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Weather Observations
CREATE TABLE weather_observations (
    weather_id BIGSERIAL PRIMARY KEY,
    installation_id UUID NOT NULL REFERENCES installations(installation_id) ON DELETE CASCADE,
    recorded_at TIMESTAMPTZ NOT NULL,
    ambient_temp_c NUMERIC(5,2) NOT NULL,
    wind_speed_m_s NUMERIC(5,2),
    wind_direction_deg NUMERIC(5,2),
    relative_humidity_pct NUMERIC(5,2),
    precipitation_mm NUMERIC(6,2),
    cloud_cover_pct NUMERIC(5,2),
    barometric_pressure_hpa NUMERIC(7,2),
    data_source VARCHAR(100) NOT NULL,
    quality_status quality_status_enum NOT NULL DEFAULT 'VALID',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Irradiance Streams (GHI, DNI, DHI, POA)
CREATE TABLE irradiance_observations (
    irradiance_id BIGSERIAL PRIMARY KEY,
    installation_id UUID NOT NULL REFERENCES installations(installation_id) ON DELETE CASCADE,
    recorded_at TIMESTAMPTZ NOT NULL,
    ghi_w_m2 NUMERIC(7,2) NOT NULL,
    dni_w_m2 NUMERIC(7,2),
    dhi_w_m2 NUMERIC(7,2),
    poa_measured_w_m2 NUMERIC(7,2),
    poa_modelled_w_m2 NUMERIC(7,2),
    sensor_model VARCHAR(100),
    quality_status quality_status_enum NOT NULL DEFAULT 'VALID',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
