-- SolarDB Database Schema 003: Installations, Array Topology, & PostGIS Spatial Geometries

CREATE TABLE installations (
    installation_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(150) NOT NULL,
    owner_name VARCHAR(150) NOT NULL,
    installation_type installation_type_enum NOT NULL,
    capacity_kw NUMERIC(10,2) NOT NULL,
    commission_date DATE NOT NULL,
    mounting_type VARCHAR(50) NOT NULL, -- e.g. FIXED_GROUND, ROOFTOP, SINGLE_AXIS_TRACKER, DUAL_AXIS_TRACKER
    tilt_deg NUMERIC(5,2) NOT NULL,
    azimuth_deg NUMERIC(5,2) NOT NULL,
    location_geometry GEOMETRY(Point, 4326) NOT NULL,
    elevation_m NUMERIC(6,2),
    site_boundary GEOMETRY(Polygon, 4326),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Site Array Topologies (SITE -> ARRAY -> INVERTER -> STRING -> PANEL)
CREATE TABLE site_arrays (
    array_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    installation_id UUID NOT NULL REFERENCES installations(installation_id) ON DELETE CASCADE,
    array_code VARCHAR(50) NOT NULL,
    tilt_deg NUMERIC(5,2) NOT NULL,
    azimuth_deg NUMERIC(5,2) NOT NULL,
    inverter_id UUID NOT NULL REFERENCES inverter_catalogue(inverter_id)
);

CREATE TABLE array_strings (
    string_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    array_id UUID NOT NULL REFERENCES site_arrays(array_id) ON DELETE CASCADE,
    string_code VARCHAR(50) NOT NULL,
    mppt_channel INTEGER NOT NULL DEFAULT 1,
    panel_id UUID NOT NULL REFERENCES panel_catalogue(panel_id)
);

CREATE TABLE installed_panels (
    installed_panel_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    string_id UUID NOT NULL REFERENCES array_strings(string_id) ON DELETE CASCADE,
    panel_id UUID NOT NULL REFERENCES panel_catalogue(panel_id),
    row_number INTEGER NOT NULL,
    column_number INTEGER NOT NULL,
    position_geometry GEOMETRY(PointZ, 4326),
    serial_number VARCHAR(100) UNIQUE,
    installed_at DATE NOT NULL
);

-- Shading Objects in PostGIS
CREATE TABLE shading_objects (
    shading_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    installation_id UUID NOT NULL REFERENCES installations(installation_id) ON DELETE CASCADE,
    object_type VARCHAR(50) NOT NULL, -- TREE, BUILDING, TERRAIN, PARAPET, TRANSMISSION_LINE
    height_m NUMERIC(6,2) NOT NULL,
    geometry GEOMETRY(PolygonZ, 4326) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
