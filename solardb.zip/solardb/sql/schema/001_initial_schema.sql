-- SolarDB Database Schema 001: Core Extensions & Enums
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "postgis";

-- Quality status for physical observation telemetry
CREATE TYPE quality_status_enum AS ENUM (
    'VALID',
    'SUSPECT',
    'INVALID',
    'MISSING',
    'SIMULATED'
);

-- Cell & Panel technology types
CREATE TYPE pv_technology_enum AS ENUM (
    'MONOCRYSTALLINE',
    'POLYCRYSTALLINE',
    'THIN_FILM',
    'BIFACIAL',
    'PEROVSKITE_TANDEM',
    'OTHER'
);

-- Measurement condition types
CREATE TYPE test_condition_enum AS ENUM (
    'DATASHEET',
    'LABORATORY',
    'FIELD',
    'SIMULATED'
);

-- Installation types
CREATE TYPE installation_type_enum AS ENUM (
    'RESIDENTIAL',
    'COMMERCIAL',
    'INDUSTRIAL',
    'UTILITY_SCALE'
);
