-- SolarDB Database Schema 002: Panel, Cell, & Inverter Catalogue

-- Cell Database
CREATE TABLE cell_technologies (
    cell_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    manufacturer VARCHAR(100) NOT NULL,
    technology pv_technology_enum NOT NULL,
    nominal_voltage_v NUMERIC(6,3) NOT NULL,
    nominal_current_a NUMERIC(6,3) NOT NULL,
    efficiency_pct NUMERIC(5,2) NOT NULL,
    temp_coeff_voc NUMERIC(6,4) NOT NULL,
    temp_coeff_isc NUMERIC(6,4) NOT NULL,
    batch_number VARCHAR(50),
    manufacturing_date DATE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Panel Catalogue
CREATE TABLE panel_catalogue (
    panel_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    manufacturer VARCHAR(100) NOT NULL,
    model VARCHAR(100) NOT NULL UNIQUE,
    technology pv_technology_enum NOT NULL,
    cell_id UUID REFERENCES cell_technologies(cell_id),
    cell_type VARCHAR(50) NOT NULL,
    nominal_power_w NUMERIC(8,2) NOT NULL,
    efficiency_pct NUMERIC(5,2) NOT NULL,
    voc NUMERIC(6,2) NOT NULL,
    isc NUMERIC(6,2) NOT NULL,
    vmpp NUMERIC(6,2) NOT NULL,
    impp NUMERIC(6,2) NOT NULL,
    temp_coeff_power NUMERIC(6,4) NOT NULL,
    temp_coeff_voc NUMERIC(6,4) NOT NULL,
    temp_coeff_isc NUMERIC(6,4) NOT NULL,
    length_mm NUMERIC(8,2) NOT NULL,
    width_mm NUMERIC(8,2) NOT NULL,
    thickness_mm NUMERIC(6,2) NOT NULL,
    weight_kg NUMERIC(6,2) NOT NULL,
    cell_count INTEGER NOT NULL,
    warranty_years INTEGER NOT NULL DEFAULT 25,
    degradation_rate_pct NUMERIC(5,3) NOT NULL DEFAULT 0.50,
    is_bifacial BOOLEAN NOT NULL DEFAULT FALSE,
    bifaciality_factor NUMERIC(4,2),
    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Module Laboratory & Field Measurements
CREATE TABLE module_characterisations (
    measurement_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    panel_id UUID NOT NULL REFERENCES panel_catalogue(panel_id) ON DELETE CASCADE,
    condition_type test_condition_enum NOT NULL,
    irradiance_w_m2 NUMERIC(7,2) NOT NULL,
    temperature_c NUMERIC(5,2) NOT NULL,
    voc_measured NUMERIC(6,2) NOT NULL,
    isc_measured NUMERIC(6,2) NOT NULL,
    vmpp_measured NUMERIC(6,2) NOT NULL,
    impp_measured NUMERIC(6,2) NOT NULL,
    pmax_measured NUMERIC(8,2) NOT NULL,
    spectral_condition VARCHAR(50) DEFAULT 'AM1.5G',
    measured_at TIMESTAMPTZ NOT NULL,
    measurement_source VARCHAR(100) NOT NULL,
    quality_status quality_status_enum NOT NULL DEFAULT 'VALID',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Inverter Catalogue
CREATE TABLE inverter_catalogue (
    inverter_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    manufacturer VARCHAR(100) NOT NULL,
    model VARCHAR(100) NOT NULL UNIQUE,
    rated_power_ac_kw NUMERIC(8,2) NOT NULL,
    max_dc_power_kw NUMERIC(8,2) NOT NULL,
    max_dc_voltage_v NUMERIC(6,2) NOT NULL,
    mppt_range_min_v NUMERIC(6,2) NOT NULL,
    mppt_range_max_v NUMERIC(6,2) NOT NULL,
    max_input_current_a NUMERIC(6,2) NOT NULL,
    euro_efficiency_pct NUMERIC(5,2) NOT NULL,
    cec_efficiency_pct NUMERIC(5,2) NOT NULL,
    mppt_channels INTEGER NOT NULL DEFAULT 1,
    operating_temp_min_c NUMERIC(5,2) NOT NULL DEFAULT -25.0,
    operating_temp_max_c NUMERIC(5,2) NOT NULL DEFAULT 60.0,
    warranty_years INTEGER NOT NULL DEFAULT 10,
    firmware_version VARCHAR(50),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
