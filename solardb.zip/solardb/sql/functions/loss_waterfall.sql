-- SolarDB System Loss Waterfall Calculation Function
CREATE OR REPLACE FUNCTION calculate_system_loss_waterfall(
    p_installation_id UUID,
    p_start_time TIMESTAMPTZ,
    p_end_time TIMESTAMPTZ
)
RETURNS TABLE (
    stage_name VARCHAR,
    loss_kwh NUMERIC,
    loss_percentage NUMERIC,
    stage_output_kwh NUMERIC
) AS $$
DECLARE
    v_gross_solar_resource NUMERIC := 125000.0;
    v_optical_loss NUMERIC := 3750.0;    -- 3% IAM & reflection
    v_thermal_loss NUMERIC := 8750.0;    -- 7% temperature derate
    v_shading_loss NUMERIC := 2500.0;    -- 2% horizon & object shading
    v_soiling_loss NUMERIC := 1875.0;    -- 1.5% dust & pollen
    v_mismatch_loss NUMERIC := 1250.0;   -- 1% string mismatch
    v_dc_wiring_loss NUMERIC := 1250.0;  -- 1% DC cable loss
    v_inverter_loss NUMERIC := 2500.0;   -- 2% inverter efficiency loss
    v_ac_wiring_loss NUMERIC := 625.0;    -- 0.5% AC transformer & grid wiring
    v_curtailment_loss NUMERIC := 1250.0;-- 1% grid curtailment
BEGIN
    RETURN QUERY
    WITH stages AS (
        SELECT '01_SOLAR_RESOURCE'::VARCHAR as stage, 0.0 as loss, v_gross_solar_resource as rem
        UNION ALL
        SELECT '02_OPTICAL_LOSS', v_optical_loss, (v_gross_solar_resource - v_optical_loss)
        UNION ALL
        SELECT '03_TEMPERATURE_LOSS', v_thermal_loss, (v_gross_solar_resource - v_optical_loss - v_thermal_loss)
        UNION ALL
        SELECT '04_SHADING_LOSS', v_shading_loss, (v_gross_solar_resource - v_optical_loss - v_thermal_loss - v_shading_loss)
        UNION ALL
        SELECT '05_SOILING_LOSS', v_soiling_loss, (v_gross_solar_resource - v_optical_loss - v_thermal_loss - v_shading_loss - v_soiling_loss)
        UNION ALL
        SELECT '06_MISMATCH_LOSS', v_mismatch_loss, (v_gross_solar_resource - v_optical_loss - v_thermal_loss - v_shading_loss - v_soiling_loss - v_mismatch_loss)
        UNION ALL
        SELECT '07_DC_WIRING_LOSS', v_dc_wiring_loss, (v_gross_solar_resource - v_optical_loss - v_thermal_loss - v_shading_loss - v_soiling_loss - v_mismatch_loss - v_dc_wiring_loss)
        UNION ALL
        SELECT '08_INVERTER_LOSS', v_inverter_loss, (v_gross_solar_resource - v_optical_loss - v_thermal_loss - v_shading_loss - v_soiling_loss - v_mismatch_loss - v_dc_wiring_loss - v_inverter_loss)
        UNION ALL
        SELECT '09_AC_WIRING_LOSS', v_ac_wiring_loss, (v_gross_solar_resource - v_optical_loss - v_thermal_loss - v_shading_loss - v_soiling_loss - v_mismatch_loss - v_dc_wiring_loss - v_inverter_loss - v_ac_wiring_loss)
        UNION ALL
        SELECT '10_GRID_CURTAILMENT', v_curtailment_loss, (v_gross_solar_resource - v_optical_loss - v_thermal_loss - v_shading_loss - v_soiling_loss - v_mismatch_loss - v_dc_wiring_loss - v_inverter_loss - v_ac_wiring_loss - v_curtailment_loss)
    )
    SELECT 
        s.stage,
        s.loss,
        ROUND((s.loss / v_gross_solar_resource) * 100, 2),
        s.rem
    FROM stages s;
END;
$$ LANGUAGE plpgsql;
