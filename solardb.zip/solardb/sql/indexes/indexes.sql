-- SolarDB Database Indexes for High-Frequency Telemetry & Spatial Queries

-- Composite Index on Telemetry for Time-Series Queries per Installation
CREATE INDEX idx_telemetry_inst_time ON production_telemetry (installation_id, recorded_at DESC);

-- Partial Index for Non-Valid Telemetry Flags (Quick fault investigation)
CREATE INDEX idx_telemetry_faults ON production_telemetry (installation_id, recorded_at DESC) 
WHERE quality_status IN ('SUSPECT', 'INVALID');

-- PostGIS Spatial Index on Installation Location
CREATE INDEX idx_installations_spatial ON installations USING GIST (location_geometry);

-- PostGIS Spatial Index on Panel Geometries
CREATE INDEX idx_panels_spatial ON installed_panels USING GIST (position_geometry);

-- PostGIS Spatial Index on Shading Objects
CREATE INDEX idx_shading_spatial ON shading_objects USING GIST (geometry);

-- Index on Weather Time-Series
CREATE INDEX idx_weather_inst_time ON weather_observations (installation_id, recorded_at DESC);
