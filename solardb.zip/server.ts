import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';

const app = express();
app.use(express.json());

const PORT = 3000;

// ==========================================
// MOCK AUTHORITATIVE SYSTEM OF RECORD (SOLARDB)
// ==========================================

const PANELS = [
  {
    panel_id: 'pnl-mono-550',
    manufacturer: 'SolarTech Global',
    model: 'ST-550M-144',
    technology: 'MONOCRYSTALLINE',
    cell_type: 'N-Type TOPCon',
    nominal_power_w: 550,
    efficiency_pct: 22.8,
    voc: 49.8,
    isc: 14.15,
    vmpp: 41.6,
    impp: 13.22,
    temp_coeff_power: -0.30,
    temp_coeff_voc: -0.25,
    temp_coeff_isc: 0.045,
    dimensions: { length_mm: 2278, width_mm: 1134, thickness_mm: 30, weight_kg: 27.6 },
    cell_count: 144,
    warranty_years: 25,
    degradation_rate_pct: 0.40,
    is_bifacial: false,
    bifaciality_factor: 0.0,
    status: 'ACTIVE',
    price_usd: 125.00
  },
  {
    panel_id: 'pnl-bifacial-670',
    manufacturer: 'HelioPower Systems',
    model: 'HP-670B-132',
    technology: 'BIFACIAL',
    cell_type: 'HJT (Heterojunction)',
    nominal_power_w: 670,
    efficiency_pct: 23.2,
    voc: 45.6,
    isc: 18.75,
    vmpp: 38.2,
    impp: 17.54,
    temp_coeff_power: -0.26,
    temp_coeff_voc: -0.22,
    temp_coeff_isc: 0.038,
    dimensions: { length_mm: 2384, width_mm: 1303, thickness_mm: 33, weight_kg: 33.5 },
    cell_count: 132,
    warranty_years: 30,
    degradation_rate_pct: 0.30,
    is_bifacial: true,
    bifaciality_factor: 0.85,
    status: 'ACTIVE',
    price_usd: 165.00
  },
  {
    panel_id: 'pnl-poly-330',
    manufacturer: 'AeroSolar Tech',
    model: 'AS-330P-72',
    technology: 'POLYCRYSTALLINE',
    cell_type: 'Standard Poly-Si',
    nominal_power_w: 330,
    efficiency_pct: 17.1,
    voc: 46.2,
    isc: 9.35,
    vmpp: 38.1,
    impp: 8.66,
    temp_coeff_power: -0.39,
    temp_coeff_voc: -0.31,
    temp_coeff_isc: 0.050,
    dimensions: { length_mm: 1956, width_mm: 992, thickness_mm: 40, weight_kg: 22.0 },
    cell_count: 72,
    warranty_years: 25,
    degradation_rate_pct: 0.65,
    is_bifacial: false,
    bifaciality_factor: 0.0,
    status: 'ACTIVE',
    price_usd: 72.00
  },
  {
    panel_id: 'pnl-thin-115',
    manufacturer: 'SolarThin Sol',
    model: 'ST-115CdTe',
    technology: 'THIN_FILM',
    cell_type: 'CdTe (Cadmium Telluride)',
    nominal_power_w: 115,
    efficiency_pct: 18.2,
    voc: 108.5,
    isc: 1.58,
    vmpp: 86.8,
    impp: 1.32,
    temp_coeff_power: -0.28,
    temp_coeff_voc: -0.26,
    temp_coeff_isc: 0.040,
    dimensions: { length_mm: 1200, width_mm: 600, thickness_mm: 6.8, weight_kg: 12.0 },
    cell_count: 264,
    warranty_years: 25,
    degradation_rate_pct: 0.50,
    is_bifacial: false,
    bifaciality_factor: 0.0,
    status: 'ACTIVE',
    price_usd: 38.00
  }
];

const INVERTERS = [
  {
    inverter_id: 'inv-sma-110',
    manufacturer: 'SolarInvert AG',
    model: 'SI-110KW-PRO',
    rated_power_ac_kw: 110.0,
    max_dc_power_kw: 165.0,
    max_dc_voltage_v: 1100.0,
    mppt_range_min_v: 500.0,
    mppt_range_max_v: 850.0,
    max_input_current_a: 150.0,
    euro_efficiency_pct: 98.6,
    cec_efficiency_pct: 98.4,
    mppt_channels: 10,
    operating_temp_min_c: -25.0,
    operating_temp_max_c: 60.0,
    warranty_years: 12,
    price_usd: 4800.00
  },
  {
    inverter_id: 'inv-huawei-100',
    manufacturer: 'GridPulse Technologies',
    model: 'GP-100K-TL',
    rated_power_ac_kw: 100.0,
    max_dc_power_kw: 150.0,
    max_dc_voltage_v: 1100.0,
    mppt_range_min_v: 200.0,
    mppt_range_max_v: 1000.0,
    max_input_current_a: 160.0,
    euro_efficiency_pct: 98.8,
    cec_efficiency_pct: 98.5,
    mppt_channels: 10,
    operating_temp_min_c: -25.0,
    operating_temp_max_c: 60.0,
    warranty_years: 10,
    price_usd: 4200.00
  }
];

const INSTALLATIONS = [
  {
    installation_id: 'inst-mojave-01',
    name: 'Mojave Solar Farm Alpha',
    owner: 'Desert Clean Energy Ltd',
    type: 'UTILITY_SCALE',
    capacity_kw: 25000.0, // 25 MW
    commission_date: '2023-04-15',
    mounting_type: 'SINGLE_AXIS_TRACKER',
    tilt_deg: 25.0,
    azimuth_deg: 180.0,
    location: { lat: 34.95, lng: -116.85, elevation_m: 680 },
    panels_count: 45454,
    inverters_count: 228
  },
  {
    installation_id: 'inst-alps-02',
    name: 'Bavaria Agri-PV Park',
    owner: 'Green Bavaria GmbH',
    type: 'COMMERCIAL',
    capacity_kw: 1200.0, // 1.2 MW
    commission_date: '2024-01-10',
    mounting_type: 'FIXED_GROUND',
    tilt_deg: 32.0,
    azimuth_deg: 175.0,
    location: { lat: 48.13, lng: 11.58, elevation_m: 520 },
    panels_count: 2181,
    inverters_count: 11
  }
];

// ==========================================
// API ROUTES
// ==========================================

app.get('/api/health', (req: Request, res: Response) => {
  res.json({
    status: 'ok',
    system: 'SolarDB Infrastructure Core',
    version: '1.0.0-rust-r-pg',
    time: new Date().toISOString()
  });
});

// Panel catalogue search & filter
app.get('/api/panels', (req: Request, res: Response) => {
  const { tech, search } = req.query;
  let filtered = [...PANELS];
  if (tech && typeof tech === 'string' && tech !== 'ALL') {
    filtered = filtered.filter(p => p.technology === tech);
  }
  if (search && typeof search === 'string') {
    const q = search.toLowerCase();
    filtered = filtered.filter(p => 
      p.manufacturer.toLowerCase().includes(q) || 
      p.model.toLowerCase().includes(q) || 
      p.cell_type.toLowerCase().includes(q)
    );
  }
  res.json({ count: filtered.length, panels: filtered });
});

app.get('/api/inverters', (req: Request, res: Response) => {
  res.json({ count: INVERTERS.length, inverters: INVERTERS });
});

// Rust Inverter compatibility validator service
app.post('/api/inverters/check-compatibility', (req: Request, res: Response) => {
  const {
    panel_voc = 49.8,
    panel_vmpp = 41.6,
    panel_isc = 14.15,
    panel_impp = 13.22,
    panels_per_string = 26,
    strings_per_mppt = 2,
    inverter_max_dc_voltage = 1100,
    inverter_mppt_min_v = 500,
    inverter_mppt_max_v = 850,
    inverter_max_current_a = 150,
    min_ambient_temp_c = -10,
    max_ambient_temp_c = 45,
    temp_coeff_voc_percent_per_c = -0.25
  } = req.body;

  const temp_diff_cold = min_ambient_temp_c - 25;
  const voc_cold_factor = 1.0 + (temp_coeff_voc_percent_per_c / 100.0) * temp_diff_cold;
  const string_voc_cold = panels_per_string * panel_voc * voc_cold_factor;

  const temp_diff_hot = max_ambient_temp_c - 25;
  const vmpp_hot_factor = 1.0 + (temp_coeff_voc_percent_per_c / 100.0) * temp_diff_hot;
  const string_vmpp_hot = panels_per_string * panel_vmpp * vmpp_hot_factor;
  const string_vmpp_cold = panels_per_string * panel_vmpp * voc_cold_factor;

  const total_mppt_current = strings_per_mppt * panel_impp;

  const errors: string[] = [];
  const warnings: string[] = [];

  if (string_voc_cold > inverter_max_dc_voltage) {
    errors.push(`Cold string Voc (${string_voc_cold.toFixed(1)}V) exceeds inverter max DC limit (${inverter_max_dc_voltage}V)! Overvoltage damage risk.`);
  }
  if (string_vmpp_hot < inverter_mppt_min_v) {
    warnings.push(`Hot string Vmpp (${string_vmpp_hot.toFixed(1)}V) drops below MPPT min threshold (${inverter_mppt_min_v}V). Efficiency penalty or clipping.`);
  }
  if (string_vmpp_cold > inverter_mppt_max_v) {
    warnings.push(`Cold string Vmpp (${string_vmpp_cold.toFixed(1)}V) exceeds MPPT max window (${inverter_mppt_max_v}V).`);
  }
  if (total_mppt_current > inverter_max_current_a) {
    errors.push(`String current (${total_mppt_current.toFixed(1)}A) exceeds MPPT input current limit (${inverter_max_current_a}A)!`);
  }

  res.json({
    engine: 'Rust SolarDB::InverterChecker',
    is_compatible: errors.length === 0,
    metrics: {
      max_string_voc_cold: Number(string_voc_cold.toFixed(2)),
      min_string_vmpp_hot: Number(string_vmpp_hot.toFixed(2)),
      max_string_vmpp_cold: Number(string_vmpp_cold.toFixed(2)),
      max_mppt_current_a: Number(total_mppt_current.toFixed(2))
    },
    warnings,
    errors
  });
});

app.get('/api/installations', (req: Request, res: Response) => {
  res.json({ count: INSTALLATIONS.length, installations: INSTALLATIONS });
});

// Digital Twin Hierarchy topology
app.get('/api/installations/:id/topology', (req: Request, res: Response) => {
  const { id } = req.params;
  const inst = INSTALLATIONS.find(i => i.installation_id === id) || INSTALLATIONS[0];

  const topology = {
    site_id: inst.installation_id,
    site_name: inst.name,
    capacity_kw: inst.capacity_kw,
    arrays: [
      {
        array_code: 'ARRAY_01_NORTH',
        inverter: INVERTERS[0],
        strings: [
          { string_code: 'STR_01_A', panels_count: 26, status: 'HEALTHY', voltage_v: 1040, current_a: 12.8, power_kw: 13.31 },
          { string_code: 'STR_01_B', panels_count: 26, status: 'HEALTHY', voltage_v: 1038, current_a: 12.7, power_kw: 13.18 },
          { string_code: 'STR_01_C', panels_count: 26, status: 'SOILING_WARNING', voltage_v: 1012, current_a: 11.2, power_kw: 11.33 }
        ]
      },
      {
        array_code: 'ARRAY_02_SOUTH',
        inverter: INVERTERS[1],
        strings: [
          { string_code: 'STR_02_A', panels_count: 26, status: 'HEALTHY', voltage_v: 1042, current_a: 12.9, power_kw: 13.44 },
          { string_code: 'STR_02_B', panels_count: 26, status: 'HEALTHY', voltage_v: 1040, current_a: 12.8, power_kw: 13.31 }
        ]
      }
    ]
  };

  res.json(topology);
});

// Rust Data Quality Engine Validation Endpoint
app.post('/api/telemetry/stream', (req: Request, res: Response) => {
  const { observations = [] } = req.body;
  const results = observations.map((obs: any, idx: number) => {
    const flags: string[] = [];
    let status = 'VALID';

    if (obs.is_simulated) {
      return { sensor_id: obs.sensor_id || `SENS_${idx}`, status: 'SIMULATED', flags: ['SIMULATED_DATA_SOURCE'] };
    }

    if (obs.irradiance_w_m2 < 0) {
      flags.push('NEGATIVE_IRRADIANCE');
      status = 'INVALID';
    } else if (obs.irradiance_w_m2 > 1600) {
      flags.push('EXTREME_IRRADIANCE');
      status = 'SUSPECT';
    }

    if (obs.dc_voltage_v < 0 || obs.dc_voltage_v > 1500) {
      flags.push('OUT_OF_BOUNDS_DC_VOLTAGE');
      status = 'INVALID';
    }

    if (obs.module_temp_c < -50 || obs.module_temp_c > 120) {
      flags.push('OUT_OF_RANGE_TEMP');
      status = 'INVALID';
    }

    // P ~ V * I consistency
    if (obs.dc_voltage_v && obs.dc_current_a && obs.dc_power_w) {
      const calc_p = obs.dc_voltage_v * obs.dc_current_a;
      if (Math.abs(calc_p - obs.dc_power_w) > (0.15 * obs.dc_power_w)) {
        flags.push('POWER_VOLTAGE_CURRENT_MISMATCH');
        if (status === 'VALID') status = 'SUSPECT';
      }
    }

    return {
      sensor_id: obs.sensor_id || `SENS_${idx}`,
      status,
      flags,
      timestamp: obs.timestamp || new Date().toISOString()
    };
  });

  const valid_count = results.filter((r: any) => r.status === 'VALID' || r.status === 'SIMULATED').length;
  const suspect_count = results.filter((r: any) => r.status === 'SUSPECT').length;
  const invalid_count = results.filter((r: any) => r.status === 'INVALID').length;

  res.json({
    engine: 'Rust SolarDB::TelemetryValidator',
    total_processed: results.length,
    valid_count,
    suspect_count,
    invalid_count,
    processed_at: new Date().toISOString(),
    validated_records: results
  });
});

// R Analytical Engine - Single Diode I-V & P-V Curve Generator
app.post('/api/analytics/iv-curve', (req: Request, res: Response) => {
  const {
    voc = 49.8,
    isc = 14.15,
    vmpp = 41.6,
    impp = 13.22,
    irradiance = 1000,
    temp_c = 25,
    temp_coeff_voc = -0.25,
    temp_coeff_isc = 0.045
  } = req.body;

  const delta_t = temp_c - 25;
  const G_ratio = Math.max(irradiance / 1000, 0.001);

  const isc_eff = isc * G_ratio * (1 + (temp_coeff_isc / 100) * delta_t);
  const vt_stc = 0.0259;
  const voc_eff = (voc * (1 + (temp_coeff_voc / 100) * delta_t)) + (vt_stc * Math.log(G_ratio));

  const steps = 60;
  const curve = [];
  const v_max = Math.max(voc_eff, 0.1);

  let pmax = 0;
  let vmpp_calc = 0;
  let impp_calc = 0;

  for (let i = 0; i <= steps; i++) {
    const v = (v_max / steps) * i;
    // Diode equation approximation
    const v_thermal = 1.15 * 0.0259 * 72; // 72 cells
    const i_val = Math.max(0, isc_eff * (1 - Math.exp((v - voc_eff) / v_thermal)));
    const p_val = v * i_val;

    if (p_val > pmax) {
      pmax = p_val;
      vmpp_calc = v;
      impp_calc = i_val;
    }

    curve.push({
      voltage_v: Number(v.toFixed(2)),
      current_a: Number(i_val.toFixed(2)),
      power_w: Number(p_val.toFixed(2))
    });
  }

  const fill_factor = pmax / (voc_eff * isc_eff);

  res.json({
    engine: 'R solardb.analytics::analyse_iv_curve',
    summary: {
      pmax_w: Number(pmax.toFixed(2)),
      voc_v: Number(voc_eff.toFixed(2)),
      isc_a: Number(isc_eff.toFixed(2)),
      vmpp_v: Number(vmpp_calc.toFixed(2)),
      impp_a: Number(impp_calc.toFixed(2)),
      fill_factor: Number(fill_factor.toFixed(4)),
      irradiance_w_m2: irradiance,
      operating_temp_c: temp_c
    },
    curve
  });
});

// R Analytics - 25 Year Degradation Forecast
app.post('/api/analytics/degradation', (req: Request, res: Response) => {
  const {
    initial_capacity_kw = 1000,
    annual_degradation_pct = 0.40,
    years = 25,
    thermal_stress_factor = 1.0,
    humidity_stress_factor = 1.0
  } = req.body;

  const effective_rate = (annual_degradation_pct / 100) * thermal_stress_factor * humidity_stress_factor;
  const lid_factor = 0.985; // Initial light induced degradation

  const forecast = [];
  for (let y = 1; y <= years; y++) {
    const cap_exp = initial_capacity_kw * lid_factor * Math.pow(1 - effective_rate, y - 1);
    const cap_lin = initial_capacity_kw * lid_factor * (1 - effective_rate * (y - 1));
    const std_err = 0.0015 * Math.sqrt(y);
    const upper = cap_exp * (1 + 1.96 * std_err);
    const lower = cap_exp * (1 - 1.96 * std_err);
    const annual_mwh = (cap_exp * 1520) / 1000;

    forecast.push({
      year: y,
      capacity_kw_exp: Number(cap_exp.toFixed(2)),
      capacity_kw_lin: Number(cap_lin.toFixed(2)),
      upper_bound_kw: Number(upper.toFixed(2)),
      lower_bound_kw: Number(lower.toFixed(2)),
      annual_mwh: Number(annual_mwh.toFixed(2)),
      retention_pct: Number(((cap_exp / initial_capacity_kw) * 100).toFixed(2))
    });
  }

  res.json({
    engine: 'R solardb.analytics::analyse_degradation',
    inputs: { initial_capacity_kw, annual_degradation_pct, years, thermal_stress_factor, humidity_stress_factor },
    forecast
  });
});

// System Loss Cascade Waterfall
app.get('/api/analytics/loss-waterfall', (req: Request, res: Response) => {
  const gross = 100000; // kWh gross resource
  const stages = [
    { name: '01 Solar Resource Gross', loss_pct: 0, loss_kwh: 0, output_kwh: gross },
    { name: '02 Optical & Reflection Loss', loss_pct: 3.2, loss_kwh: gross * 0.032, output_kwh: gross * (1 - 0.032) },
    { name: '03 Temperature Derate', loss_pct: 6.8, loss_kwh: gross * 0.068, output_kwh: gross * (1 - 0.032 - 0.068) },
    { name: '04 Shading & Horizon Loss', loss_pct: 2.1, loss_kwh: gross * 0.021, output_kwh: gross * (1 - 0.032 - 0.068 - 0.021) },
    { name: '05 Soiling & Dirt Loss', loss_pct: 1.8, loss_kwh: gross * 0.018, output_kwh: gross * (1 - 0.032 - 0.068 - 0.021 - 0.018) },
    { name: '06 String Mismatch Loss', loss_pct: 1.2, loss_kwh: gross * 0.012, output_kwh: gross * (1 - 0.032 - 0.068 - 0.021 - 0.018 - 0.012) },
    { name: '07 DC Cabling Ohmic Loss', loss_pct: 1.1, loss_kwh: gross * 0.011, output_kwh: gross * (1 - 0.032 - 0.068 - 0.021 - 0.018 - 0.012 - 0.011) },
    { name: '08 Inverter Conversion Loss', loss_pct: 1.6, loss_kwh: gross * 0.016, output_kwh: gross * (1 - 0.032 - 0.068 - 0.021 - 0.018 - 0.012 - 0.011 - 0.016) },
    { name: '09 AC Transformer Loss', loss_pct: 0.6, loss_kwh: gross * 0.006, output_kwh: gross * (1 - 0.032 - 0.068 - 0.021 - 0.018 - 0.012 - 0.011 - 0.016 - 0.006) },
    { name: '10 Grid Net Electricity Output', loss_pct: 0.0, loss_kwh: 0, output_kwh: gross * 0.816 }
  ];

  res.json({
    engine: 'SolarDB PostgreSQL System Loss Waterfall',
    gross_kwh: gross,
    net_kwh: Number((gross * 0.816).toFixed(2)),
    overall_performance_ratio_pct: 81.6,
    stages
  });
});

// Codebase file inspector for Code Explorer view
app.get('/api/codebase', (req: Request, res: Response) => {
  const solardbDir = path.join(process.cwd(), 'solardb');

  function getFiles(dirPath: string): any[] {
    if (!fs.existsSync(dirPath)) return [];
    const items = fs.readdirSync(dirPath, { withFileTypes: true });
    return items.map(item => {
      const fullPath = path.join(dirPath, item.name);
      const relativePath = path.relative(process.cwd(), fullPath);
      if (item.isDirectory()) {
        return {
          name: item.name,
          path: relativePath,
          type: 'directory',
          children: getFiles(fullPath)
        };
      } else {
        return {
          name: item.name,
          path: relativePath,
          type: 'file',
          content: fs.readFileSync(fullPath, 'utf-8')
        };
      }
    });
  }

  res.json({ tree: getFiles(solardbDir) });
});

// ==========================================
// VITE MIDDLEWARE & SERVER INITIALIZATION
// ==========================================

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`SolarDB Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
